<?PHP
define('M4J_EMAIL_ROOT', 'you@your-domain.com' );
define('M4J_PREVIEW_WIDTH', '980' );
define('M4J_PREVIEW_HEIGHT', '600' );
define('M4J_MAX_OPTIONS', 10 );
define('M4J_CAPTCHA_DURATION', 5 );
define('M4J_FROM_NAME', 'Mad4Joomla' );
define('M4J_FROM_EMAIL', 'dont@reply.com' );
define('M4J_MAIL_ISO', 'iso-8859-1');
define('M4J_HELP_ICON', 3 );
define('M4J_HTML_MAIL', true );
define('M4J_SHOW_LEGEND', true );
define('M4J_CAPTCHA','CSS');

define('M4J_CLASS_HEADING', 'm4j_heading' );
define('M4J_CLASS_LIST_HEADING', 'm4j_list_heading' );
define('M4J_CLASS_LIST_INTRO', 'm4j_list_intro' );
define('M4J_CLASS_LIST_WRAP', 'm4j_list_wrap' );
define('M4J_CLASS_HEADER_TEXT', 'm4j_header_text' );
define('M4J_CLASS_FORM_WRAP', 'm4j_form_wrap' );
define('M4J_CLASS_FORM_TABLE', 'm4j_form_table' );
define('M4J_CLASS_ERROR', 'm4j_error' );
define('M4J_CLASS_SUBMIT_WRAP', 'm4j_submit_wrap' );
define('M4J_CLASS_SUBMIT', 'm4j_submit' );
define('M4J_CLASS_REQUIRED', 'm4j_required' );
?>
