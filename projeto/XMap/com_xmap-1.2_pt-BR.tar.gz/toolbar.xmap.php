<?php
/**
 * $Id: toolbar.xmap.php 8 2007-09-27 00:11:32Z root $
 * $LastChangedDate: 2007-09-26 18:11:32 -0600 (mié, 26 sep 2007) $
 * $LastChangedBy: root $
 * Xmap by Guillermo Vargas
 * a sitemap component for Joomla! CMS (http://www.joomla.org)
 * Author Website: http://joomla.vargas.co.cr
 * Project License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

