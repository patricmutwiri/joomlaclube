<?php
// $Id: index.php 87 2009-01-23 08:28:32Z fxstein $
/*-----------------------------------------------
this is a dummy file and intentionally left blank
do not remove from ditribution package
/*----------------------------------------------*/
?>