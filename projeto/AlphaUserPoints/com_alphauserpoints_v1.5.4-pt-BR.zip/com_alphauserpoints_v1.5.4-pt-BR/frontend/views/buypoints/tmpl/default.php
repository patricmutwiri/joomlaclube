<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008-2009 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

 // no direct access
defined('_JEXEC') or die('Restricted access');

if ( !$this->success ) 
{
	// Paypal account
	if ( $this->params->get( 'usepaypaltestaccount' ) )
	{
		// use test mode
		$paypal   = "https://www.sandbox.paypal.com";
		$business = $this->params->get('testaccountmail', '');
	}
	else
	{
		// use real account
		$paypal = "https://www.paypal.com";
		$business = $this->params->get('businessmail', '');
	}

	// start template
	if ( $this->params->def( 'show_page_title', 1 ) ) {
	?>
	<div class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ); ?>">
		<?php
		$page_title = ($this->params->get('page_title'))? $this->params->get('page_title') : $this->menuname ;
		echo $page_title;
		?>
	</div>
	<?php 
	}

	// Display error message if exists
	if ( $this->msg ) echo  $this->msg . "<br /><br />";
	
	if ( $this->title || $this->description ) {
	?>
	<table class="contentpaneopen<?php echo $this->params->get( 'pageclass_sfx' ); ?>" width="100%">
		<tr>	
			<td class="contentheading<?php echo $this->params->get( 'pageclass_sfx' ); ?>" width="100%">
			<?php echo JText::_( $this->title ); ?>
			</td>
		</tr>
		<tr>
			<td valign="top">
			<?php echo JHTML::_('content.prepare', $this->description ); ?>
			</td>
		</tr>
	</table>
	<?php
	}
	$currencyleft = "";
	$currencyright = "";
	if ( !$this->params->get('currency_position', '0') ) {
		$currencyleft = $this->params->get('currency_symbol', '$');
	} else $currencyright = $this->params->get('currency_symbol', '$');
	
	// prepare list points
	$javascript = 'onchange="actualize(\''.$currencyleft.'\',\''.$currencyright.'\');"';
	$listpoints = JHTML::_( 'select.integerlist', $this->params->get('rangelist_start', '1000'), $this->params->get('rangelist_end', '100000'), $this->params->get('rangelist_increment', '1000'), 'numpointstobuy', $javascript, '' );
	?>
	<div style="border-width:1px;border-style:solid;border-color:#990000;">
		<div style="padding:10px;">
			<h2><?php echo JText::_( 'AUP_CHOOSE_NUMBER_OF_POINTS' ); ?></h2>
			<p><?php echo sprintf(JText::_( 'AUP_YOURCURRENTTOTALPOINTS' ), $this->currenttotalpoints ); ?>
			<br /><?php echo sprintf(JText::_( 'AUP_INFORMATION_TEXT' ), $currencyleft.$this->params->get('amount_per_increment', '25').$currencyright, $this->params->get('rangelist_increment', '1000'), $this->params->get('rangelist_end', '100000')); ?></p>
			<p><b><?php echo JText::_( 'AUP_NUMBER_OF_POINTS_TO_BUY' ); ?></b></p>
			<form name="buypoints" method="post" action="">
			<?php echo $listpoints ; ?>
			<br />
			<br /><p><b>
			<?php
			$totalamount = "<input name=\"totalamount\" value=\"".$currencyleft.$this->params->get('amount_per_increment', '25').$currencyright."\" style=\"border:none;width:auto;color:red;\" onfocus=this.blur(); />";			
			echo JText::_( 'AUP_TOTAL_COST' ). " <font color=\"red\">" . $totalamount . "</font>";

			$returnsuccess = JURI::base(false) . "index.php?option=com_alphauserpoints&view=buypoints&task=success&refID=".$this->referreid."&Itemid=".$this->menuid;
			$cancelreturn = htmlentities(JURI::base(false) . "index.php?option=com_alphauserpoints&view=buypoints&task=cancel&Itemid=".$this->menuid);
			?>
			</b><br />
			<input type="hidden" id="abp_amount" name="abp_amount" value="<?php echo $this->params->get('amount_per_increment', '25'); ?>" />
			<input type="hidden" id="abp_tax" name="abp_tax" value="<?php echo $this->params->get('tax', '0'); ?>"/>
			<input type="hidden" id="rangelist_increment" name="rangelist_increment" value="<?php echo $this->params->get('rangelist_increment', '1000'); ?>"/>
			</form>
			</p><br />
			<form action="<?php echo $paypal; ?>/cgi-bin/webscr" method="post" name="frm_paypal">
			<input type="hidden" name="cmd" value="_xclick"/>
			<input type="hidden" name="business" value="<?php echo $business; ?>"/>
			<input type="hidden" name="item_name" value="<?php echo $this->params->get('item_name', ''); ?>"/>
			<?php  if ( $this->params->get('item_number') ) { ?>
			<input type="hidden" name="item_number" value="<?php echo $this->params->get('item_number'); ?>"/>
			<?php } ?>
			<input type="hidden" name="amount" value="<?php echo $this->params->get('amount_per_increment', '25'); ?>"/>
			<input type="hidden" name="tax" value="<?php echo $this->params->get('tax', '0'); ?>"/>
			<input type="hidden" name="no_shipping" value="0"/>
			<input type="hidden" name="return" value="<?php echo $returnsuccess; ?>"/>
			<input type="hidden" name="notify_url" value="<?php echo $returnsuccess; ?>"/>
			<input type="hidden" name="cancel_return" value="<?php echo $cancelreturn; ?>"/>
			<input type="hidden" name="logo_custom" value="<?php echo JURI::base(false); ?>components/com_alphauserpoints/assets/images/paypal_buttons/<?php echo $this->params->get('paypal_logo', 'x-click-but04.gif'); ?>"/>
			<input type="hidden" name="no_note" value="1"/>
			<input type="hidden" name="custom" value="<?php echo $this->params->get('rangelist_start', '1000'); ?>"/>
			<input type="hidden" name="currency_code" value="<?php echo $this->params->get('currency_code', 'USD'); ?>"/>
			<input type="hidden" name="lc" value="<?php echo $this->params->get('country', 'US'); ?>"/>
			<input type="hidden" name="bn" value="PP-BuyNowBF"/>
			<input type="image" src="<?php echo JURI::base(true); ?>/components/com_alphauserpoints/assets/images/paypal_buttons/<?php echo $this->params->get('paypal_logo', 'x-click-but04.gif'); ?>" border="0" name="submit" alt="<?php echo JText::_( 'AUP_PAYPAL_ALT_BUTTON' ); ?>"/>
			<img src="<?php echo $paypal; ?>/en_GB/i/scr/pixel.gif" width="1" height="1" alt="" border="0" />
			</form>
		</div>
	</div>
<?php
} 
 else 
{ 
	if ( $this->params->def( 'show_page_title', 1 ) ) {
	?>
	<div class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ); ?>">
		<?php
		$page_title = ($this->params->get('page_title'))? $this->params->get('page_title') : $this->menuname ;
		echo $page_title;
		?>
	</div>
	<?php 
	}
?>
	<table class="contentpaneopen<?php echo $this->params->get( 'pageclass_sfx' ); ?>" width="100%">
	<tr>	
		<td class="contentheading<?php echo $this->params->get( 'pageclass_sfx' ); ?>" width="100%">
		<?php echo JText::_( 'AUP_THANKS_FOR_YOUR_PAYMENT' ); ?>
		</td>
	</tr>
	<tr>	
		<td valign="top" width="100%">&nbsp;</td>
	</tr>
	<tr>	
		<td valign="top" width="100%">
		<b><?php echo JText::_( 'AUP_PAYMENT_DETAILS' ) ; ?></b><br /><br />
		<?php echo JText::_( 'AUP_NAME' ) . " " . $this->transaction['first_name'] . " " . $this->transaction['last_name'] ; ?><br />
		<?php echo JText::_( 'AUP_TRANSACTION_ID' ) . " " . $this->transaction['txn_id'] ; ?><br />
		<?php echo JText::_( 'AUP_TRANSACTION_COST' ) . " " . $this->transaction['mc_gross'] . " " . $this->transaction['mc_currency'] ; ?><br />
		<?php echo JText::_( 'AUP_TRANSACTION_DATE' ) . " " . $this->transaction['payment_date'] ; ?><br />
		</td>
	</tr>
	<tr>	
		<td valign="top">&nbsp;</td>
	</tr>
	<tr>	
		<td valign="top" width="100%">
		<?php echo JText::_( 'AUP_SUCCESSFULLYPAYMENT' ); ?><br /><br />
		<?php echo sprintf(JText::_( 'AUP_YOURCURRENTTOTALPOINTS' ), $this->currenttotalpoints ); ?>
		</td>
	</tr>
	</table>
<?php
}
?>
<?php
	/** 
	*
	*  Provide copyright on frontend
	*  If you remove or hide this line below,
	*  please make a donation if you find AlphaUserPoints usefull
	*  and want to support its continued development.
	*  Your donations help by hardware, hosting services and other expenses that come up as we develop,
	*  protect and promote AlphaUserPoints and other free components.
	*  You can donate on http://www.alphaplug.com
	*
	*/	
	getCopyrightNotice ();
?>