<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008-2009 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view' );
jimport( 'joomla.html.html.select');

class alphauserpointsViewbuypoints extends JView
{

	function _display($tpl = null) {		
		global $mainframe;	
		
		$document	= & JFactory::getDocument();		
		
		$javascript = "
			function actualize(currencyleft, currencyright) {
				var newTotal;
				var newTax;
				var newPoints;
				var numpointstobuy;
				newTotal = (document.buypoints.numpointstobuy.value * document.buypoints.abp_amount.value)/document.buypoints.rangelist_increment.value;
				document.buypoints.totalamount.value = currencyleft+newTotal.toString()+currencyright;
				numpointstobuy = document.buypoints.numpointstobuy.value;
				document.frm_paypal.amount.value = newTotal;					
				newTax = (document.buypoints.numpointstobuy.value * document.buypoints.abp_tax.value)/document.buypoints.rangelist_increment.value;
				document.frm_paypal.tax.value = newTax;
				newPoints = document.buypoints.numpointstobuy.value;
				document.frm_paypal.custom.value = newPoints;
			}
		";
		
		$document->addScriptDeclaration($javascript);	

		$this->assignRef( 'params',                         $this->params );
		$this->assignRef( 'referreid',	                 $this->referreid );
		$this->assignRef( 'currenttotalpoints', $this->currenttotalpoints );
		$this->assignRef( 'userid',                         $this->userid );
		$this->assignRef( 'menuid',                         $this->menuid );
		$this->assignRef( 'menuname',                     $this->menuname );
		$this->assignRef( 'title',                           $this->title );
		$this->assignRef( 'description',               $this->description );
		$this->assignRef( 'success',                       $this->success );
		$this->assignRef( 'msg',                               $this->msg );
		$this->assignRef( 'transaction',               $this->transaction );
		
		parent::display($tpl);
	}
	
}
?>