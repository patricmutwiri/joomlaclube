<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

defined( '_JEXEC' ) or die( 'Restricted access' );
$new_total = "";
?>
<script type="text/javascript">
<!--
	function validateForm( frm ) {
		var valid = document.formvalidator.isValid(frm);
		if (valid == false) {
			// do field validation
			if (frm.numpoints.invalid) {
				alert( "<?php echo JText::_( 'AUP_NUMPOINTS' );?>" );
			} else if (frm.username2points.invalid) {
				alert( "<?php echo JText::_( 'AUP_USERNAME', true ); ?>" );
			}
			return false;
		} else {
			frm.submit();
		}
	}
// -->
</script>
<?php if ( $this->params->get( 'show_page_title', 1 ) ) { ?>

	<div class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ); ?>">
		<?php echo $this->params->get( 'page_title' ); ?>
	</div>
<?php } ?>
<?php 
if ( $this->params->def( 'limitdonationpoints', 0 ) ) {
	$percent = $this->params->get( 'limitdonationpoints' );
	// limit the number of points a user can be redistribute to another user
	$new_total = $this->currenttotalpoints - intval( ($this->currenttotalpoints*$percent)/100 );
	echo JText::_( 'AUP_THE_NUMBER_OF_POINTS_TO_DONATE_IS_LIMITED' ) . " " . $new_total . " " . JText::_( 'AUP_POINTS' );;
} else echo JText::_('AUP_DONATEPOINTSTOFRIEND') ;
?>
<br /><br />
<form action="<?php echo JRoute::_( 'index.php' );?>" method="post" name="sendPointsForm" id="sendPointsForm" class="form-validate">
		<table class="contentpaneopen<?php echo $this->params->get( 'pageclass_sfx' ); ?>">
		<tr>
			<td width="180">
				<?php echo JText::_( 'AUP_NUMPOINTS' ); ?>
			</td>
		  <td>
				<input class="inputbox required" type="text" name="numpoints" id="numpoints" size="10" maxlength="255" value="" /> /
				<?php 
					if ( $this->params->get( 'limitdonationpoints' ) ) {
						echo $new_total . " " . JText::_( 'AUP_POINTS' );
						echo " <i>(" . sprintf(JText::_( 'AUP_YOURCURRENTTOTALPOINTS' ), $this->currenttotalpoints ) . ")</i>";
						$this->currenttotalpoints = $new_total;
					} else {
						echo $this->currenttotalpoints . " " .  JText::_( 'AUP_POINTS' );
					}
				?>
			</td>
		</tr>
		<tr>
			<td>
				<?php echo JText::_( 'AUP_USERNAMEOFYOURFRIEND' ); ?>:
			</td>
			<td>
				<input class="inputbox required" type="text" name="username2points" id="username2points" size="30" maxlength="255" value="" /> <span id="statusUSR"></span>
			</td>
		</tr>
		</table>
		<button class="button validate" type="submit"><?php echo JText::_('AUP_SEND'); ?></button>
	<input type="hidden" name="option" value="com_alphauserpoints" />
	<input type="hidden" name="view" value="user2userpoints" />
	<input type="hidden" name="referreid" value="<?php echo $this->referreid; ?>" />
	<input type="hidden" name="userid" value="<?php echo $this->userID; ?>" />
	<input type="hidden" name="currenttotalpoints" value="<?php echo $this->currenttotalpoints; ?>" />	
	<input type="hidden" name="menuid" value="<?php echo $this->menuid; ?>" />	
	<input type="hidden" name="task" value="sendpoints" />
</form>
<?php
	/** 
	*
	*  Provide copyright on frontend
	*  If you remove or hide this line below,
	*  please make a donation if you find AlphaUserPoints useful
	*  and want to support its continued development.
	*  Your donations help by hardware, hosting services and other expenses that come up as we develop,
	*  protect and promote AlphaUserPoints and other free components.
	*  You can donate on http://www.alphaplug.com
	*
	*/	
	getCopyrightNotice ();
?>