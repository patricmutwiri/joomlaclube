<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view' );

class alphauserpointsViewUser2userpoints extends JView
{

	function _display($tpl = null) {		
		global $mainframe;	
		
		$document	= & JFactory::getDocument();
		$document->addStyleSheet(JURI::base(true).'/components/com_alphauserpoints/assets/css/alphauserpoints_css.css');
		
		// Prevent loading Mootools Library after AlphaRegistration jQuery (conflict)
		JHTML::_('behavior.mootools');
		
		if  ($this->params->get('load_jQueryValidation', 1) ) {
			$document->addScript(JURI::base(true).'/components/com_alphauserpoints/assets/ajax/jquery-1.3.2.min.js');			
			$document->addScript(JURI::base(true).'/components/com_alphauserpoints/assets/ajax/ajax-check.js');		
		}		
		
		$this->assignRef( 'params', $this->params );
		$this->assignRef( 'referreid', $this->referreid );
		$this->assignRef( 'userID',	$this->userID );
		$this->assignRef( 'currenttotalpoints',	$this->currenttotalpoints );
		$this->assignRef( 'menuid', $this->menuid );
			
		JHTML::_('behavior.formvalidation');
		
		parent::display($tpl);
	}	

}
?>