<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view' );
jimport( 'joomla.html.pagination' );

class alphauserpointsViewUsers extends JView
{

	function _display($tpl = null) {		
		global $mainframe;	
		
		$document	= & JFactory::getDocument();
		$uri 		= &JFactory::getURI();		
		
		$this->assignRef( 'params', $this->params );
		$this->assignRef( 'rows', $this->rows );
		$this->assignRef( 'lists', $this->lists);
	
		$pagination = new JPagination( $this->total, $this->limitstart, $this->limit );
		$this->assignRef('limit', $this->limit);
		$this->assignRef('pagination', $pagination );
		$this->assignRef('action',	$uri->toString());		
		$this->assignRef('useAvatarFrom',  $this->useAvatarFrom );
		$this->assignRef( 'linkToProfile', $this->linkToProfile );
		
		parent::display($tpl);
	}
	
}
?>