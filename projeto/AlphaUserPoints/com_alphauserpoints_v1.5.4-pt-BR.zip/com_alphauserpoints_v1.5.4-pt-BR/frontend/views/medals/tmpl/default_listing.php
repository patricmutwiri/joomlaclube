<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008-2009 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

$user = & JFactory::getUser();
$colspan = 4;
if ( $this->params->get( 'usrname' )=='' ) $colspan = 6;
if ( $this->useAvatarFrom ) $colspan++;

?>
<form action="<?php echo JRoute::_( 'index.php' ); ?>" method="post" name="adminForm">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<!--
				<td class="sectiontableheader<?php echo $this->params->get( 'pageclass_sfx' ); ?>" width="3%">
					<?php echo JText::_( 'NUM' ); ?>
				</td>
				-->
				<?php if ( $this->useAvatarFrom ) { ?>
				<td class="sectiontableheader<?php echo $this->params->get( 'pageclass_sfx' ); ?>">&nbsp;
				</td>
				<?php } ?>				
				<td class="sectiontableheader<?php echo $this->params->get( 'pageclass_sfx' ); ?>" width="20">&nbsp;																						
				</td>
				<?php if ( $this->params->get( 'usrname' )=='' || $this->params->get( 'usrname' )=='name') { ?>			
				<td class="sectiontableheader<?php echo $this->params->get( 'pageclass_sfx' ); ?>" width="15%">
					<?php echo JText::_('AUP_NAME'); ?>
				</td>
				<?php } ?>
				<?php if ( $this->params->get( 'usrname' )=='' || $this->params->get( 'usrname' )=='username') { ?>	
				<td class="sectiontableheader<?php echo $this->params->get( 'pageclass_sfx' ); ?>" width="15%">
					<?php echo JText::_( 'AUP_USERNAME' ); ?>
				</td>
				<?php } ?>
				<td class="sectiontableheader<?php echo $this->params->get( 'pageclass_sfx' ); ?>" width="30%">
					<?php echo JText::_('AUP_DATE'); ?>
				</td>
				<td class="sectiontableheader<?php echo $this->params->get( 'pageclass_sfx' ); ?>">
					<?php echo JText::_( 'AUP_REASON_FOR_AWARD' ); ?>
				</td>
			</tr>
		<?php
			$k = 0;
			
			//if ( $this->useAvatarFrom ) {
				require_once (JPATH_SITE.DS.'components'.DS.'com_alphauserpoints'.DS.'helper.php');
			//}
			
			
			for ($i=0, $n=count( $this->detailrank ); $i < $n; $i++)			
			{
				$row 	=& $this->detailrank[$i];
				
				$_user_info = AlphaUserPointsHelper::getUserInfo ( $row->referreid );				
				$linktoprofil = getProfileLink( $this->linkToProfile, $_user_info );
				
				if ($row->icon ) {
					$pathicon = JURI::root() . 'components/com_alphauserpoints/assets/images/awards/icons/';
					$icone = '<img src="'.$pathicon . $row->icon.'" width="16" height="16" border="0" alt="" />';
				} else $icone = '';	
				
			?>
			<tr>	
			<!--
				<td>
					<?php echo $i+1+$this->pagination->limitstart;?>
				</td>		
			-->
			<?php
				// load avatar if need
				if ( $this->useAvatarFrom ) {					
					$avatar = getAvatar( $this->useAvatarFrom, $_user_info, $this->params->get( 'heightAvatar' ) );
					// add link to profil if need
					$startprofil = "";
					$endprofil   = "";
					if ( $this->params->get( 'show_links_to_users', 1) && $user->id ){
						//$profil = "index.php?option=com_alphauserpoints&amp;view=account&amp;userid=".$row->referreid;
						
						$startprofil =  "<a href=\"" . $linktoprofil . "\">";
						$endprofil   = "</a>";
					}					
					echo "<td>".$startprofil.$avatar.$endprofil."</td>";
				}			
			?>
				<td>
					<div align="center">
					<?php echo $icone; ?>
					</div>
				</td>
				<?php if ( $this->params->get( 'usrname' )=='' || $this->params->get( 'usrname' )=='name') { ?>			
				<td>				
					<?php //echo JText::_( $row->name ); ?>
					<?php
					
					if ( $this->params->get( 'show_links_to_users', 1) && $user->id ){
						//$profil = "index.php?option=com_alphauserpoints&amp;view=account&amp;userid=".$row->referreid;
						$profil =  "<a href=\"" . $linktoprofil . "\">" . $row->name . "</a>";
					} else $profil = $row->name ;
					// echo $row->usr_name;
						echo $profil;			 
					 ?>
					
				</td>
				<?php } ?>
				<?php if ( $this->params->get( 'usrname' )=='' || $this->params->get( 'usrname' )=='username') { ?>	
				<td>
					<?php //echo JText::_( $row->username ); ?>
					<?php
					
					if ( $this->params->get( 'show_links_to_users', 1) && $user->id ){
						//$profil = "index.php?option=com_alphauserpoints&amp;view=account&amp;userid=".$row->referreid;
						$profil =  "<a href=\"" . $linktoprofil . "\">" . $row->username . "</a>";
					} else $profil = $row->username ;
					// echo $row->usr_name;
						echo $profil;			 
					 ?>					
				</td>
				<?php } ?>
				<td>
					<?php 
					echo JHTML::_('date',  $row->dateawarded,  JText::_('DATE_FORMAT_LC') );
					?>
				</td>
				<td>					
					<?php 
					echo JText::_( $row->rank );
					if ( $row->reason ) echo ' - ' . JText::_( $row->reason ); 
					?>
				</td>
			</tr>
			<?php
				$k = 1 - $k;
				}
			?>
			<tr>
				<td colspan="<?php echo $colspan; ?>" align="center">
				<?php echo "<br />" . $this->pagination->getPagesLinks(); ?>
				</td>
			</tr>
			<tr>
				<td colspan="<?php echo $colspan; ?>" align="center">
				<?php echo $this->pagination->getPagesCounter(); ?>
				</td>
			</tr>		
	</table>
	<input type="hidden" name="option" value="com_alphauserpoints" />
	<input type="hidden" name="controller" value="medals" />
	<input type="hidden" name="task" value="detailsmedal" />
	<input type="hidden" name="cid" value="<?php echo $row->cid ; ?>" />
</form>
<br /><br />