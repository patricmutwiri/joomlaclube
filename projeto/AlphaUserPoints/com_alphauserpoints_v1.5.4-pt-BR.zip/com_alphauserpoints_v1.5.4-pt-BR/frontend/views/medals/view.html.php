<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008-2009 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view' );
jimport( 'joomla.html.pagination' );

class alphauserpointsViewMedals extends JView
{
		
	function _displaylist($tpl = null) {
		global $mainframe;
		
		$document	= & JFactory::getDocument();
		
		$this->assignRef( 'levelrank', $this->levelrank );
	
		$pagination = new JPagination( $this->total, $this->limitstart, $this->limit );		
		$this->assignRef( 'pagination', $pagination );
		$this->assignRef( 'params',  $this->params );
		
		parent::display( $tpl) ;
	}
	
	function  _displaydetailrank($tpl = null) {
		global $mainframe;
		
		$document	= & JFactory::getDocument();
		
		$this->assignRef( 'detailrank', $this->detailrank );
	
		$pagination = new JPagination( $this->total, $this->limitstart, $this->limit );		
		$this->assignRef( 'pagination', $pagination );
		$this->assignRef( 'params',  $this->params );
		$this->assignRef( 'useAvatarFrom',  $this->useAvatarFrom );
		$this->assignRef( 'linkToProfile', $this->linkToProfile );
		
		parent::display( "listing" );
	}
	
}
?>