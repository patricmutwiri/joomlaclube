<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008-2009 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );
jimport( 'joomla.application.component.view' );
class alphauserpointsModelRssactivity extends Jmodel {

	function __construct(){
		parent::__construct();
		
	}

	function _showRSSAUPActivity() {
		global $mainframe;

		$db			      =& JFactory::getDBO();
				
		$nullDate	= $db->getNullDate();
		$date =& JFactory::getDate();
		$now  = $date->toMySQL();
		
		$menus	    = &JSite::getMenu();
		$menu       = $menus->getActive();
		$menuid     = $menu->id;

		$params     = $menus->getParams($menuid);		
		
		$count      = JRequest::getVar('c', $params->get('count', 20), 'default', 'int');		
		$usrname 	= JRequest::getVar('u', $params->get('usrname', 'name'), 'default', 'string');
		$activity   = JRequest::getVar('a', $params->get('activity', 0), 'default', 'int');		
		
		// exclude specific users of this list
		$excludeuser = array();		
		$excludeusers = "";
		$query = "SELECT exclude_items FROM #__alpha_userpoints_rules WHERE `plugin_function`='sysplgaup_excludeusers' AND `published`='1'";
		$db->setQuery( $query );
		$result  = $db->loadResult();		
		if ( $result ) {		
			$excludeuser = explode( ",", $result);
			for ($i=0, $n=count($excludeuser); $i < $n; $i++) {		
				$excludeusers .= " AND aup.referreid!='" . trim($excludeuser[$i]) . "'";
			}			
		}
		
		$typeActivity = "";
		
		if ( $activity == 1 )
		{			
			$typeActivity = " AND a.points >= 1";		
		}
		elseif ( $activity == 2 ) 
		{
			$typeActivity = " AND a.points < 0";		
		}
						
		$query = "SELECT a.insert_date, a.referreid, a.points AS last_points, a.datareference, u.".$usrname." AS usrname, r.rule_name, r.plugin_function"
			   . " FROM #__alpha_userpoints_details AS a, #__alpha_userpoints AS aup, #__users AS u, #__alpha_userpoints_rules AS r"
			   . " WHERE aup.referreid=a.referreid AND aup.userid=u.id AND a.approved='1' AND (a.expire_date>='".$now."' OR a.expire_date='0000-00-00 00:00:00') AND r.id=a.rule"
			   . $excludeusers
			   . $typeActivity
			   . " ORDER BY a.insert_date DESC"
		 	   ;
		$db->setQuery($query, 0, $count);
		$rows = $db->loadObjectList();
	
		$this->showRSSActivity( $rows );				
	}
	
	function showRSSActivity( &$rows ) {
		global $mainframe;
	
		// Load feed creator class
		require_once (JPATH_SITE.DS.'includes'.DS.'feedcreator.class.php' );

		$rssfile = $mainframe->getCfg('tmp_path') . '/rssAUPactivity.xml';
		
		$rss = new UniversalFeedCreator();
		$rss->title = $mainframe->getCfg('sitename');
		$rss->description = JText::_('AUP_LASTACTIVITY');
		$rss->link = JURI::base();
		$rss->syndicationURL = JURI::base();
		$rss->cssStyleSheet = NULL;
		$rss->descriptionHtmlSyndicated = true;
		
		if ( $rows ) {
			foreach ( $rows as $row ) {				
				// exceptions private data
				if ( $row->plugin_function=='plgaup_getcouponcode_vm' || $row->plugin_function=='plgaup_alphagetcouponcode_vm' || $row->plugin_function=='sysplgaup_buypointswithpaypal') {
					$datareference = '';
				}
				switch ( $row->plugin_function ) {
					case 'sysplgaup_dailylogin':
						$row->datareference = JHTML::_('date', $row->datareference, JText::_('DATE_FORMAT_LC1') );
						break;
					case 'plgaup_getcouponcode_vm':
					case 'plgaup_alphagetcouponcode_vm':
					case 'sysplgaup_buypointswithpaypal':
						$row->datareference = ''; 
						break;
					default:
				}
				$datareference = ( $row->datareference!='' ) ? ' ('. $row->datareference . ')' : '' ;
				// special format
				//if ( $row->plugin_function=='sysplgaup_dailylogin' ) $datareference = '';
				
				$item = new FeedItem();
				$item->title = htmlspecialchars($row->usrname, ENT_QUOTES, 'UTF-8');
				$item->description = JText::_( $row->rule_name ) . "$datareference /  " . $row->last_points . " " .  JText::_('AUP_POINTS');
				$item->descriptionTruncSize = 250;
				$item->descriptionHtmlSyndicated = true;
				@$date = ( $row->insert_date ? date( 'r', strtotime($row->insert_date) ) : '' );
				$item->date = $date;
				$item->source = JURI::base();
				$rss->addItem( $item );
			}
		}	
		// save feed file
		$rss->saveFeed('RSS2.0', $rssfile);		
	}

}
?>