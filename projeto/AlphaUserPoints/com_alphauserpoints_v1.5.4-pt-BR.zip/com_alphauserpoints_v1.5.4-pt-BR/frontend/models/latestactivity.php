<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008-2009 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );

class alphauserpointsModelLatestactivity extends Jmodel {

	function __construct(){
		parent::__construct();
		
	}

	function _getLatestActivity($params) {
		global $mainframe;

		$db			      =& JFactory::getDBO();
		
		$nullDate	= $db->getNullDate();
		$date =& JFactory::getDate();
		$now  = $date->toMySQL();
		
		// exclude specific users of this list
		$excludeuser = array();		
		$excludeusers = "";
		$query = "SELECT exclude_items FROM #__alpha_userpoints_rules WHERE `plugin_function`='sysplgaup_excludeusers' AND `published`='1'";
		$db->setQuery( $query );
		$result  = $db->loadResult();		
		if ( $result ) {		
			$excludeuser = explode( ",", $result);
			for ($i=0, $n=count($excludeuser); $i < $n; $i++) {		
				$excludeusers .= "\nAND aup.referreid!='" . trim($excludeuser[$i]) . "'";
			}			
		}
		
		$activity   = $params->get('activity', 0);
		
		$typeActivity = "";
		
		if ( $activity == 1 )
		{			
			$typeActivity = " AND a.points >= 1";		
		}
		elseif ( $activity == 2 ) 
		{
			$typeActivity = " AND a.points < 0";		
		}

	
		// Get the pagination request variables
		$limit = $mainframe->getUserStateFromRequest('com_alphauserpoints.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
		// In case limit has been changed, adjust limitstart accordingly
		$limitstart = ( $limit != 0 ? (floor( $limitstart / $limit ) * $limit) : 0);		
		$query = "SELECT a.insert_date, a.referreid, a.points AS last_points, a.datareference, u.".$params->get('usrname', 'name')." AS usrname, r.rule_name, r.plugin_function, r.category"
			   . " FROM #__alpha_userpoints_details AS a, #__alpha_userpoints AS aup, #__users AS u, #__alpha_userpoints_rules AS r"
			   . " WHERE aup.referreid=a.referreid AND aup.userid=u.id AND a.approved='1' AND (a.expire_date>='".$now."' OR a.expire_date='0000-00-00 00:00:00') AND r.id=a.rule"
			   . $excludeusers
			   . $typeActivity
			   . " ORDER BY a.insert_date DESC"
		 	   ;
		$total = @$this->_getListCount($query);
		$result = $this->_getList($query, $limitstart, $limit);
		return array($result, $total, $limit, $limitstart);	
	
	}	

}
?>