<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008-2009 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * @package AlphaUserPoints
 */
class alphauserpointsControllerUser2userpoints extends alphauserpointsController
{
	/**
	 * Custom Constructor
	 */
 	function __construct()	{
		parent::__construct( );
	}
	
	function display() 
	{
		global $mainframe;		
		
		$user = & JFactory::getUser();
		
		$model      = &$this->getModel ( 'alphauserpoints' );	
		$view       = $this->getView  ( 'user2userpoints','html' );			
		
		// active user		
		$referrerid = $model->_checkUser();

		// rule enabled ?
		require_once (JPATH_SITE.DS.'components'.DS.'com_alphauserpoints'.DS.'helper.php');
		
		$plugin_rule = AlphaUserPointsHelper::checkRuleEnabled( 'sysplgaup_user2userpoints' );
		
		if ( !AlphaUserPointsHelper::checkRuleEnabled( 'sysplgaup_user2userpoints' ) ) {
			$msg = JText::_('AUP_THISRULEDISABLED' );
			$mainframe->redirect('index.php', $msg, 'error');
		}
		
		// check referre ID
		$_user_info = AlphaUserPointsHelper::getUserInfo ( $referrerid );
		$currenttotalpoints = $_user_info->points;
		
		// Get the parameters of the active menu item
		$params = $model->_getParamsAUP();
		
		$menus	    = &JSite::getMenu();
		$menu       = $menus->getActive();
		$menuid     = $menu->id;
				
		$view->assign('params', $params );
		$view->assign('referreid', $referrerid );
		$view->assign('userID', $user->id );
		$view->assign('currenttotalpoints', $currenttotalpoints );
		$view->assign('menuid', $menuid );
	
		// Display
		$view->_display();
	}
	
	
	function sendpoints () 
	{
		global $mainframe;		
		
		$model        = &$this->getModel ( 'alphauserpoints' );
		$view         = $this->getView  ( 'user2userpoints','html' );		
		
		$model->_sendXpoints2friend();
		
		// Get the parameters of the active menu item
		$params = $model->_getParamsAUP();
				
		$view->assign('params', $params );
		$view->assign('username', $username );
		$view->assign('xpoints', $xpoints );
		$view->assign('newcurrenttotalpoints', $newcurrenttotalpoints );
		
	}
	
}
?>