<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008-2009 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * @package AlphaUserPoints
 */
class alphauserpointsControllerLatestactivity extends alphauserpointsController
{
	/**
	 * Custom Constructor
	 */
 	function __construct()	{
		parent::__construct( );
	}
	
	function display() 
	{	
	
		$com_params = &JComponentHelper::getParams( 'com_alphauserpoints' );
		$_useAvatarFrom = $com_params->get('useAvatarFrom');	
		$_profilelink	= $com_params->get('linkToProfile');	

		$model      = &$this->getModel ( 'latestactivity' );
		$view       = $this->getView  ( 'latestactivity','html' );
	
		$menus	    = &JSite::getMenu();
		$menu       = $menus->getActive();
		$menuid     = $menu->id;

		$params     = $menus->getParams($menuid);		
		
		$_latestactivity = $model->_getLatestActivity($params);

		$view->assign('params', $params );
		$view->assign('latestactivity', $_latestactivity[0] );
		$view->assign('total', $_latestactivity[1] );
		$view->assign('limit', $_latestactivity[2] );
		$view->assign('limitstart', $_latestactivity[3] );
		$view->assign('useAvatarFrom', $_useAvatarFrom );
		$view->assign('linkToProfile', $_profilelink );
		
		$view->_display();
	}
	

}
?>