<?php
define( '_JEXEC', 1 );

if (stristr( $_SERVER['SERVER_SOFTWARE'], 'win32' )) {
	define( 'JPATH_BASE', realpath(dirname(__FILE__).'\..\..\..\..' ));
} else define( 'JPATH_BASE', realpath(dirname(__FILE__).'/../../../..' ));

define( 'DS', DIRECTORY_SEPARATOR );

require_once ( JPATH_BASE.DS.'includes'.DS.'defines.php' );
require_once ( JPATH_BASE.DS.'includes'.DS.'framework.php' );
$mainframe =& JFactory::getApplication('site');
$mainframe->initialise();

jimport( 'joomla.plugin.plugin' );

JPlugin::loadLanguage( 'com_alphauserpoints' );	

$username = JRequest::getVar( 'username2points', '', 'post', 'string' );

if ( $username!='')
	{

	$db	   =& JFactory::getDBO();	
	$query = "SELECT id FROM #__users WHERE `username`='".$username."' LIMIT 1";
	$db->setQuery( $query );
	$userexist = $db->loadResult();
	
	if( $userexist )
		{
		echo 'OK';
		}
		else
		{
		echo '<font color="red">'.JText::_( 'AUP_THIS_USERNAME_NOT_EXIST' ).'</font>';
		}
	}
	else 
	{	
	echo '';
	}
?>
