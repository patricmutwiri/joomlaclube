var myDomain = '';

if ( document.domain!='localhost' ) {
	myDomain = /(http?:\/\/[^\/]+)/.exec(window.location.href)[1] + '/';
}

pic1 = new Image(16, 16); 
pic1.src = myDomain+"components/com_alphauserpoints/assets/images/loader.gif";

$(document).ready(function(){   

	$("#username2points").keyup(function() { 
	
		var usr = $("#username2points").val();
		
		if(usr.length >= 4)
		{
			$("#statusUSR").html('<img src="'+myDomain+'components/com_alphauserpoints/assets/images/loader.gif" align="absmiddle">');
			
		$.ajax({  
		type: "POST",  
		url: myDomain+"components/com_alphauserpoints/assets/ajax/checkusername.php",  
		data: "username2points="+ usr,  
		success: function(msg){
	   
		$("#statusUSR").ajaxComplete(function(event, request, settings){ 

		if(msg == 'OK')
		{ 
			$("#username2points").removeClass('object_error'); // if necessary
			$("#username2points").addClass("inputbox");
			$(this).html('&nbsp;<img src="'+myDomain+'components/com_alphauserpoints/assets/images/tick.png" align="absmiddle">');
		}  
		else
		{  
			$("#username2points").removeClass('object_ok'); // if necessary
			$("#username2points").addClass("object_error");
			$(this).html(msg);
		}  
	   
	   });
	
	 } 
	   
	  }); 
	
	}
	
	});
	
	
	
});
