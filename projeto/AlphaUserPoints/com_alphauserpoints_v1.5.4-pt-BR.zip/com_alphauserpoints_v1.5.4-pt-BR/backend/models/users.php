<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );

class alphauserpointsModelUsers extends Jmodel {

	function __construct(){
		parent::__construct();
	}
	
	function _setmaxpoints() {
	
		$db			= & JFactory::getDBO();
		$maxpoints	= JRequest::getVar( 'setpointsperuser', 0, 'post', 'int' );

		$query = "UPDATE #__alpha_userpoints SET `max_points`='$maxpoints'";
		$db->setQuery($query);
		$db->query();
		
		return $maxpoints;
		
	}
	
	function _resetpoints() {
		
		$db	= & JFactory::getDBO();
				
		$jnow		=& JFactory::getDate();		
		$now		= $jnow->toMySQL();
			
		// main query
		$query = "UPDATE #__alpha_userpoints SET `points`='0', `last_update`='$now'";
		$db->setQuery( $query );
		$db->query();
		
		// main query
		$query = "DELETE FROM #__alpha_userpoints_details";
		$db->setQuery( $query );
		$db->query();
		
		return true;
		
	}
	
	function _recalculate_points () {
	
		$db	= & JFactory::getDBO();
		
		$jnow		=& JFactory::getDate();		
		$now		= $jnow->toMySQL();		
		
		// delete old points after expire date before recount 
		$query = "DELETE FROM #__alpha_userpoints_details WHERE `expire_date`!='0000-00-00 00:00:00' AND `expire_date`<='$now'";
		$db->setQuery( $query );
		$db->query();		
	
	}
	
	function _purge_expires () {
	
		$db	= & JFactory::getDBO();
		
		$jnow		=& JFactory::getDate();		
		$now		= $jnow->toMySQL();		
	
		// main query
		$query = "DELETE FROM #__alpha_userpoints_details WHERE `expire_date`!='0000-00-00 00:00:00' AND `expire_date`<='$now'";
		$db->setQuery( $query );
		$db->query();
		
		return true;
		
	}
	
	function _last_Activities() {

		$db			      =& JFactory::getDBO();
		
		$nullDate	= $db->getNullDate();
		$date =& JFactory::getDate();
		$now  = $date->toMySQL();
		
		$count		      = 10;
		
		// exclude specific users of this list
		$excludeuser = array();		
		$excludeusers = "";
		$query = "SELECT exclude_items FROM #__alpha_userpoints_rules WHERE `plugin_function`='sysplgaup_excludeusers' AND `published`='1'";
		$db->setQuery( $query );
		$result  = $db->loadResult();		
		if ( $result ) {		
			$excludeuser = explode( ",", $result);
			for ($i=0, $n=count($excludeuser); $i < $n; $i++) {		
				$excludeusers .= " AND aup.referreid!='" . trim($excludeuser[$i]) . "'";
			}
		}		
				
		$query = "SELECT a.insert_date, a.referreid, a.points AS last_points, u.username AS usrname, u.name AS uname, aup.userid AS userID, r.rule_name"
			   . " FROM #__alpha_userpoints_details AS a, #__alpha_userpoints AS aup, #__users AS u, #__alpha_userpoints_rules AS r"
			   . " WHERE aup.referreid=a.referreid AND aup.userid=u.id AND a.approved='1'"
			   . "  AND a.rule=r.id"
			   . "  AND (a.expire_date>='$now' OR a.expire_date='0000-00-00 00:00:00')"
			   . $excludeusers
			   . " ORDER BY a.insert_date DESC"		
		 	   ;
		$db->setQuery($query, 0, $count);
		$rows = $db->loadObjectList();
	
		return $rows;
	
	}
	
}
?>