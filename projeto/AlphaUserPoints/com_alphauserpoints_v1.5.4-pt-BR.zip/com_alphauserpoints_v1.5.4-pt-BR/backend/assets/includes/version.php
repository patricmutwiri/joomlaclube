<?php
/*
 * @component AlphaUserPoints
 * @copyright Copyright (C) 2008-2009 Bernard Gilly
 * @license : GNU/GPL
 * @Website : http://www.alphaplug.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// num version
if(!defined("_ALPHAUSERPOINTS_NUM_VERSION")) {
   DEFINE( "_ALPHAUSERPOINTS_NUM_VERSION", "1.5.4" );
}
?>