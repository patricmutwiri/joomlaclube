<?php

class AgoraInstaller
{
	function AgoraInstaller()
	{
		$this->__construct();
	}

	function __construct()
	{
		$this->db = & JFactory::getDBO();
		$this->db->debug(0);
		$this->logList = array();
	}

	function query($q)
	{
		$this->db->setQuery($q);
		$this->db->query();
	}

	function runSQLFile($file)
	{
		$path = JPath::clean(JPATH_ADMINISTRATOR.DS."components".DS.'com_agora'.DS.$file);
		$buffer = file_get_contents($path);

		if ( $buffer === false ) {
			$this->log('AgoraInstaller::runSQLFile: '.JText::_('File not found').' '.$file,'error');
//			JError::raiseWarning(1, 'AgoraInstaller::runSQLFile: '.JText::_('File not found').' '.$file);
			return false;
		}

		jimport('joomla.installer.helper');
		$queries = JInstallerHelper::splitSql($buffer);

		if (count($queries) == 0) {
			// No queries to process
			return true;
		}

		// Process each query in the $queries array (split out of sql file).
		foreach ($queries as $query)
		{
			$query = trim($query);
			if ($query != '' && $query{0} != '#') {
				$this->db->setQuery($query);
				if (!$this->db->query()) {
					$this->log('SQL "'.$query.'" failed','notice');
//					JError::raiseWarning(1, 'AgoraInstaller::runSQLFile: '.JText::_('SQL Error').' '.$this->db->stderr(true));
					//return false;
				}
			}
		}
		return count($queries);
	}

	function insert($table, $record)
	{
		$fields = array_map(array($this->db,'nameQuote'),array_keys($record));
		$values = array_map(array($this->db,'Quote'),array_values($record));

		$fields = implode(',',$fields);
		$values = implode(',',$values);

		$query = 'INSERT INTO '.$table.' ('.$fields.') VALUES ('.$values.')';
		$this->db->setQuery($query);
		if (!$this->db->query()) {
			$this->log('SQL "'.$query.'" failed','notice');
//			JError::raiseWarning(1, 'AgoraInstaller::insert(): '.JText::_('SQL Error').' '.$this->db->stderr(true));
			return -1;
		}
		return $this->db->insertid();
	}

	function old()
	{
		$this->log('This version of Agora is too old for automatic upgrade','error');
		return false;
	}

	function pantheon()
	{
		$this->log('Upgrading Agora Pantheon');
		$this->db->setQuery('SELECT * FROM #__agora_groups WHERE g_id NOT IN (1,2,3,4)');
		$old_groups = $this->db->loadAssocList();
		if (!$old_groups) {
			$old_groups = array();
		}

		$this->log('Found '.count($old_groups).' old user groups');
		$new_groups = array();
		foreach ($old_groups as $group) {
			$new_groups[] = array(
				'id'			=> $group['g_id'],
				'name'			=> $group['g_title'],
				'parent_id'		=> 0,
				'caps_message'	=> 1,
				'caps_subject'	=> 1,
				'sig_smilies'	=> 1,
				'sig_bbcode'	=> 1,
				'sig_bbcode_img'=> 1,
				'sig_caps'		=> 1,
				'sig_length'	=> 400,
				'sig_lines'		=> 4,
				'search'		=> $group['g_search'],
				'search_users'	=> $group['g_search_users'],
				'pm'			=> $group['g_pm'],
				'pm_limit'		=> $group['g_pm_limit'],
				//'rep'			=> $group['g_rep_enabled'],
				'rep_minus_min'	=> $group['g_rep_minus_min'],
				'rep_plus_min'	=> $group['g_rep_plus_min'],
				'access'		=> array (
					'read'			=> $group['g_read_board'],
					'bbcode'		=> 1,
					'bbcode_img'	=> 1,
					'read_rss'		=> $group['g_rss_enabled'],
					'post_reply'	=> $group['g_post_replies'],
					'post_poll'		=> $group['g_post_polls'],
					'post_topic'	=> $group['g_post_topics'],
					'delete_topics' => $group['g_delete_topics'],
					'delete_posts'	=> $group['g_delete_posts'],
					'use_captcha'	=> 0,
				)
			);
		}

		$this->db->setQuery('SELECT id, group_id FROM #__agora_users');
		$old_users = $this->db->loadAssocList();
		$user_group = array();
		foreach ($old_users as $user) {
			if ($user['group_id'] == 1) {
				$grp = 1;
				$role = 4;
			} elseif ($user['group_id'] == 2) {
				$grp = 1;
				$role = 3;
			} elseif ($user['group_id'] == 3) {
				$grp = 1;
				$role = 1;
			} elseif ($user['group_id'] == 4) {
				$grp = 1;
				$role = 2;
			} else {
				$grp = $user['group_id'];
				$role = 2;
			}

			$user_group[] = array (
				'user_id' => $user['id'],
				'group_id' => $grp,
				'role_id' => $role,
			);
		}

		$this->db->setQuery('SELECT * FROM #__agora_forum_perms');
		$perms = $this->db->loadAssocList();
		if (!$perms) {
			$perms = array();
		}

		$group_forum = array();
		foreach ($perms as $perm) {
			$dup = false;
			if ($perm['group_id'] == 1) {
				$grp = 1;
				$role = 4;
			} elseif ($perm['group_id'] == 2) {
				$grp = 1;
				$role = 3;
			} elseif ($perm['group_id'] == 3) {
				$grp = 1;
				$role = 1;
			} elseif ($perm['group_id'] == 4) {
				$grp = 1;
				$role = 2;
			} else {
				$grp = $perm['group_id'];
				$role = 1;
				$dup = true;
			}

			$new_group_forum = array (
				'forum_id'	=> $perm['forum_id'],
				'group_id'	=> $grp,
				'role_id'	=> $role,

				'access'	=> array (
					'read'			=> $perm['read_forum'],
					'bbcode'		=> 1,
					'bbcode_img'	=> 1,
					'read_rss'		=> $perm['rss_enabled'],
					'post_reply'	=> $perm['post_replies'],
					'post_poll'		=> $perm['post_polls'],
					'post_topic'	=> $perm['post_topics'],
					'delete_topics' => 1,
					'delete_posts'	=> 1,
					'use_captcha'	=> 0,
				),
			);
			$group_forum[] = $new_group_forum;
			if ($dup) {
				for ($i = 2; $i <= 4; $i++) {
					$new_group_forum['role_id'] = $i;
					$group_forum[] = $new_group_forum;
				}
			}
		}

		$this->db->setQuery('SELECT * FROM jos_agora_Ratings');
		$ratings = $this->db->loadAssocList();

/*		$this->db->setQuery('SELECT id FROM #__agora_forums');
		$forums = $this->db->loadAssocList();
		foreach ($forums as $forum_id) {

			$new_group_forum = array (
				'forum_id'	=> $forum_id,
				'group_id'	=> 1,

				'access'	=> array (
					'read'			=> $perm['read_forum'],
					'bbcode'		=> 1,
					'bbcode_img'	=> 1,
					'read_rss'		=> $perm['rss_enabled'],
					'post_reply'	=> $perm['post_replies'],
					'post_poll'		=> $perm['post_polls'],
					'post_topic'	=> $perm['post_topics'],
					'delete_topics' => 1,
					'delete_posts'	=> 1,
					'use_captcha'	=> 1,
				)
			);
			for ($role=1; $role <= 4; $role+=1) {
				$new_group_forum['role_id'] = $role;
				if ($role == 1) {
					//guest
					$new_group_forum['access']['post_reply'] = 0;
					$new_group_forum['access']['post_poll'] = 0;
					$new_group_forum['access']['post_topic'] = 0;
					$new_group_forum['access']['delete_topics'] = 0;
					$new_group_forum['access']['delete_posts'] = 0;
				} elseif ($role == 2) {
					//member
					$new_group_forum['access']['post_reply'] = 1;
					$new_group_forum['access']['post_poll'] = 1;
					$new_group_forum['access']['post_topic'] = 1;
					$new_group_forum['access']['delete_topics'] = 0;
					$new_group_forum['access']['delete_posts'] = 0;
				} else {
					//admin-moder
					$new_group_forum['access']['post_reply'] = 1;
					$new_group_forum['access']['post_poll'] = 1;
					$new_group_forum['access']['post_topic'] = 1;
					$new_group_forum['access']['delete_topics'] = 1;
					$new_group_forum['access']['delete_posts'] = 1;
				}
				$group_forum[$forum_id] = $new_group_forum;
			}
		}*/

		$this->log('Applying changes in metadata');

		if (!$this->runSQLFile('upgrade.pantheon.sql')) return false;

		$group_ids = array('1' => '1');

		$this->log('Creating groups ('.count($new_groups).' will be created)');

		foreach ($new_groups as $group) {
			$access = $group['access'];
			$old_id = $group['id'];
			unset($group['access']);
			unset($group['id']);

			$perm_guest = $this->insert('#__agora_permissions',$access);
			$perm_member = $this->insert('#__agora_permissions',$access);
			$perm_moder = $this->insert('#__agora_permissions',$access);
			$perm_admin = $this->insert('#__agora_permissions',$access);
			
			$group_ids[$old_id] = $this->insert('#__agora_group',$group);

			$perms = array('group_id'=>$group_ids[$old_id],'role_id'=>'1','access_id'=>$perm_guest);
			$this->insert('#__agora_group_permissions',$perms);

			$perms = array('group_id'=>$group_ids[$old_id],'role_id'=>'2','access_id'=>$perm_member);
			$this->insert('#__agora_group_permissions',$perms);

			$perms = array('group_id'=>$group_ids[$old_id],'role_id'=>'3','access_id'=>$perm_moder);
			$this->insert('#__agora_group_permissions',$perms);

			$perms = array('group_id'=>$group_ids[$old_id],'role_id'=>'4','access_id'=>$perm_admin);
			$this->insert('#__agora_group_permissions',$perms);
		}

		foreach ($user_group as $record) {
			if (!isset($group_ids[$record['group_id']])) continue;

			$record['group_id'] = $group_ids[$record['group_id']];
			$this->insert('#__agora_user_group',$record);
		}

		foreach ($group_forum as $record) {
			if (!isset($group_ids[$record['group_id']])) continue;

			$access = $record['access'];
			unset($record['access']);
			
			$record['access_id'] = $this->insert('#__agora_permissions',$access);
			$record['role_id'] = 1;
			$record['group_id'] = $group_ids[$record['group_id']];
			$this->insert('#__agora_group_forum',$record);

			$record['access_id'] = $this->insert('#__agora_permissions',$access);
			$record['role_id'] = 2;
			$record['group_id'] = $group_ids[$record['group_id']];
			$this->insert('#__agora_group_forum',$record);

			$record['access_id'] = $this->insert('#__agora_permissions',$access);
			$record['role_id'] = 3;
			$record['group_id'] = $group_ids[$record['group_id']];
			$this->insert('#__agora_group_forum',$record);

			$record['access_id'] = $this->insert('#__agora_permissions',$access);
			$record['role_id'] = 4;
			$record['group_id'] = $group_ids[$record['group_id']];
			$this->insert('#__agora_group_forum',$record);
		}

		foreach ($ratings as $record) {
			$this->insert('#__agora_ratings',$record);
		}

		return true;

	}

	function log($mess,$type='info')
	{
		$entry = new stdClass();
		$entry->message = $mess;
		$entry->type = $type;
		$this->logList[] = $entry;
	}

	function olympus()
	{
		$this->log('Upgrading previous Agora Olympus installation');
		
		$path = JPath::clean(JPATH_ADMINISTRATOR.DS."components".DS.'com_agora'.DS.'upgrade.php');
		include_once($path);
		$upgrader = new AgoraDatabaseUpgrade();

		$old_debug = $this->db->_debug;
		$this->db->debug(0);
		$this->db->setQuery('SELECT conf_value FROM #__agora_config WHERE conf_name = \'o_database_revision\'');
		$current_revision = $this->db->loadResult();
		$this->log('Detected database metadata revision: '.intval($current_revision));
		
		$sts = $upgrader->getStatements($current_revision);

		foreach ($sts as $st) {
			if (method_exists($upgrader, $st)) {
				$upgrader->$st($this->db);
				continue;
			}
			
			$this->db->setQuery($st);
			$this->db->query();
		}
		$this->db->debug($old_debug);
		return true;
	}

	function fresh()
	{
		$this->log('Performing fresh installation');
		return $this->runSQLFile('upgrade.fresh.sql');
	}

	function run()
	{
		$this->db->setQuery('SELECT conf_value FROM #__agora_config WHERE conf_name=\'o_cur_version\'');
		$old_version = $this->db->loadResult();
		
		$this->log('Detecting old version: '.htmlentities($old_version));

		if (is_null($old_version)) {
			$result = $this->fresh();
		} elseif (strpos($old_version,'3.0.') !== FALSE) {
			$result = $this->olympus();
		} elseif (strpos($old_version,'2.5.') !== FALSE) {
			$result = $this->pantheon();
		} else {
			$result = $this->old();
		}

		if ($result) {
			$this->log('Complete');
		} else {
			$this->log('Serious error detected. Installer failed and cannot continue');
			$this->log('Please send this log to Agora support team');
		}

		return $result;
	}

	function display()
	{
		$doc = & JFactory::getDocument();
		$doc->addScript(JURI::root().'components/com_agora/js/jquery-1.3.2.min.js');
		$doc->addScriptDeclaration('$j=jQuery.noConflict();');
		$doc->addScript(JURI::base().'components/com_agora/js/service.js');
		
		?>
		<script type="text/javascript">
			$j(function() {
				ag_checkDirs();
				ag_syncUsers();
			});

		</script>
		<div style="width: 100%">
			<div style="width: 35%; float: left">
			<fieldset>
				<legend>Installer actions</legend>
				<a href="javascript:void(0)" onClick="ag_checkDirs()">Check directory permissions</a>
				<br/><br/>
				<a href="javascript:void(0)" onClick="ag_syncUsers()">Syncronise Joomla<->Agora users</a>
				<br/><br/>
				<a href="javascript:void(0)" onClick="ag_installClean()">Install clean database</a>
				<br/><br/>
				<a href="javascript:void(0)" onClick="$j('#agora_log').html('')">Clear log</a>
			</fieldset>
			</div>
			<div style="font-size : 120%; width: 63%; float: left; margin-left: 2%;">
			<fieldset>
				<legend>Installer log</legend>
				<div id="agora_log" style="overflow: auto; max-height: 300px">
					<h2>Performed operations</h2>
				<?php
					foreach ($this->logList as $logs) {
						switch ($logs->type) {
							case 'error': $color = '#FF0000'; break;
							case 'info': $color = '#0000FF'; break;
							default: $color = '#000000';
						}
						echo '<span color="'.$color.'">'.$logs->message.'</span><br/>'."\n";
					}
				?>
				</div>
			</fieldset>
			</div>
		</div>
		<?php
	}
}

function com_install() {
	$installer = new AgoraInstaller();
	$installer->run();
	$installer->display();
}

?>