<?php

ainclude('view|view');
ainclude('include|string');

class AHTMLAdminForm
{
    function string($params, &$smarty)
    {
        $caption = Agora::lang($params['caption']);
        $description = isset($params['desc']) ? Agora::lang($params['desc']) : '';

        if (!isset($params['value'])) {
            $value = htmlspecialchars($smarty->_tpl_vars['agora_config'][$var],ENT_QUOTES,'UTF-8');
        } else {
            $value = AString::escape($params['value']);
        }

        $attribs  = '';
        foreach($params as $attr_name=>$attr_value)
        {
            $arribs .= $attr_name.'="'.$attr_value.'" ';
        }

        if (!empty($description)) {
            $title = 'title="'.$caption.'::'.$description.'"';
            $tip = 'editlinktip hasTip';
        } else {
            $title = '';
            $tip = '';
        }

        return
        '<tr>'.
        '  <td align="right" class="key '.$tip.'" '.$title.'>'.
        '	  <strong>'.$caption.':</strong>'.
        '  </td>'.
        '  <td align="left">'.
        '    '.$value.
        '  </td>'.
        '<tr>';


    }

    function text($params, &$smarty)
    {
        $var = $params['var'];
        $caption = Agora::lang($params['caption']);
        $description = isset($params['desc']) ? Agora::lang($params['desc']) : '';
        unset($params['var']);
        unset($params['caption']);
        unset($params['desc']);

        if (!isset($params['value'])) {
            $value = htmlspecialchars($smarty->_tpl_vars['agora_config'][$var],ENT_QUOTES,'UTF-8');
        } else {
            $value = AString::escape($params['value']);
        }

        unset($params['value']);

        $attribs  = '';
        foreach($params as $attr_name=>$attr_value)
        {
            $arribs .= $attr_name.'="'.$attr_value.'" ';
        }

        if (!empty($description)) {
            $title = 'title="'.$caption.'::'.$description.'"';
            $tip = 'editlinktip hasTip';
        } else {
            $title = '';
            $tip = '';
        }

        return
        '<tr>'.
        '  <td align="right" class="key '.$tip.'" '.$title.'>'.
        '	  <strong>'.$caption.':</strong>'.
        '  </td>'.
        '  <td align="left">'.
        '    <input type="text" name="form['.$var.']" value="'.$value.'" '.$attribs.'/>'.
        '  </td>'.
        '<tr>';


    }
    function etext($params, &$smarty)
    {
        $var = $params['var'];
        $caption = Agora::lang($params['caption']);
        $description = isset($params['desc']) ? Agora::lang($params['desc']) : '';
        unset($params['var']);
        unset($params['caption']);
        unset($params['desc']);

        if (!isset($params['value'])) {
            $value = htmlspecialchars($smarty->_tpl_vars['agora_config'][$var],ENT_QUOTES,'UTF-8');
        } else {
            $value = AString::escape($params['value']);
        }

        unset($params['value']);

        $attribs  = '';
        foreach($params as $attr_name=>$attr_value)
        {
            $arribs .= $attr_name.'="'.$attr_value.'" ';
        }

        if (!empty($description)) {
            $title = 'title="'.$caption.'::'.$description.'"';
            $tip = 'editlinktip hasTip';
        } else {
            $title = '';
            $tip = '';
        }

        return
        '  <td align="right" class="key '.$tip.'" '.$title.'>'.
        '	  <strong>'.$caption.':</strong>'.
        '  </td>'.
        '  <td align="left">'.
        '    <input type="text" name="form['.$var.']" value="'.$value.'" '.$attribs.'/>'.
        '  </td>';



    }
    function editor($params, &$smarty, $width = '100%', $hight = '100%', $col = '60', $row = '30', $buttons = 'True', $eparams =  array())
    {
        $var = $params['var'];
        $caption = Agora::lang($params['caption']);
        $description = isset($params['desc']) ? Agora::lang($params['desc']) : '';
        unset($params['var']);
        unset($params['caption']);
        unset($params['desc']);

        if (!isset($params['value'])) {
            $value = htmlspecialchars($smarty->_tpl_vars['agora_config'][$var],ENT_QUOTES,'UTF-8');
        } else {
            $value = AString::escape($params['value']);
        }

        unset($params['value']);

        $attribs  = '';
        foreach($params as $attr_name=>$attr_value)
        {
            $arribs .= $attr_name.'="'.$attr_value.'" ';
        }

        if (!empty($description)) {
            $title = 'title="'.$caption.'::'.$description.'"';
            $tip = 'editlinktip hasTip';
        } else {
            $title = '';
            $tip = '';
        }
        $editor =& JFactory::getEditor();
        //echo 'Var='.$var;
        return
        '  <td align="right" class="key '.$tip.'" '.$title.'>'.
        '	  <strong>'.$caption.':</strong>'.
        '  </td>'.
        '  <td align="left">'.
        '    '.$editor->display('form['.$var.']', $value, $width, $hight, $col, $row, $buttons, $eparams).
        '  </td>';



    }

    function textarea($params, &$smarty)
    {
        $var = $params['var'];
        $caption = Agora::lang($params['caption']);
        $description = isset($params['desc']) ? Agora::lang($params['desc']) : '';
        unset($params['var']);
        unset($params['caption']);
        unset($params['desc']);

        if (!isset($params['value'])) {
            $value = AString::escape($smarty->_tpl_vars['agora_config'][$var]);
        } else {
            $value = AString::escape($params['value']);
            unset($params['value']);
        }

        $attribs  = '';
        foreach($params as $attr_name=>$attr_value)
        {
            $arribs .= $attr_name.'="'.$attr_value.'" ';
        }

        if (!empty($description)) {
            $title = 'title="'.$caption.'::'.$description.'"';
            $tip = 'editlinktip hasTip';
        } else {
            $title = '';
            $tip = '';
        }

        return
        '<tr>'.
        '  <td align="right" class="key '.$tip.'" '.$title.'>'.
        '	  <strong>'.$caption.':</strong>'.
        '  </td>'.
        '  <td align="left">'.
        '    <textarea name="form['.$var.']" '.$attribs.'>'.$value.'</textarea>'.
        '  </td>'.
        '<tr>';


    }

    function select($params, &$smarty)
    {
        $var = $params['var'];

        if (isset($params['keys'])) {
            $keys = $params['keys'];
        } else {
            $values = $params['values'];
        }

        $caption = Agora::lang($params['caption']);
        $description = isset($params['desc']) ? Agora::lang($params['desc']) : '';

        if (isset($params['selected'])) {
            $selected = $params['selected'];
        } else {
            $selected = '';
        }

        unset($params['var']);
        unset($params['values']);
        unset($params['keys']);
        unset($params['caption']);
        unset($params['desc']);
        unset($params['selected']);

        $attribs  = '';
        foreach($params as $attr_name=>$attr_value)
        {
            $attribs .= $attr_name.'="'.$attr_value.'" ';
        }

/*		$a = func_get_args();
        var_dump($a);*/
        $options = '';
        if (isset($keys)) {
            foreach ($keys as $key=>$value) {
                if ($selected == $key) {
                    $options .= '<option value='.$key.' selected="selected">'.$value.'</option>';
                } else {
                    $options .= '<option value='.$key.'>'.$value.'</option>';
                }
            }
        } else {
            foreach ($values as $value) {
                if ($selected == $value) {
                    $options .= '<option value='.$value.' selected="selected">'.$value.'</option>';
                } else {
                    $options .= '<option value='.$value.'>'.$value.'</option>';
                }
            }
        }

        if (!empty($description)) {
            $title = 'title="'.$caption.'::'.$description.'"';
            $tip = 'editlinktip hasTip';
        } else {
            $title = '';
            $tip = '';
        }

        return
        '<tr>'.
        '	<td align="right" class="key '.$tip.'" '.$title.'>'.
        '		<strong>'.$caption.'</strong>'.
        '	</td>'.
        '	<td align="left">'.
        '		<select '.$attribs.' name="form['.$var.']">'.
        $options.
        '		</select>'.
        '	</td>'.
        '</tr>';
    }

    function radio($params, &$smarty)
    {
        $var = $params['var'];
        $values = $params['values'];
        $caption = Agora::lang($params['caption']);
        $description = isset($params['desc']) ? Agora::lang($params['desc']) : '';
        unset($params['var']);
        unset($params['caption']);
        unset($params['desc']);

        $attribs  = '';
        foreach($params as $attr_name=>$attr_value)
        {
            $arribs .= $attr_name.'="'.$attr_value.'" ';
        }

        if (!empty($description)) {
            $title = 'title="'.$caption.'::'.$description.'"';
            $tip = 'editlinktip hasTip';
        } else {
            $title = '';
            $tip = '';
        }

        if (!isset($params['value'])) {
            $value = $smarty->_tpl_vars['agora_config'][$var];
        } else {
            $value = $params['value'];
            unset($params['value']);
        }

        return
        '<tr>'.
        '	<td align="right" class="key '.$tip.'" '.$title.'>'.
        '		<strong>'.$caption.'</string>'.
        '	</td>'.
        '	<td align="left">'.
        JHTML::_('select.booleanlist',  'form['.$var.']', 'class="inputbox"', $value ).
        '	</td>'.
        '</tr>';
    }

}

class AHTMLForm
{
    function param($name,$value)
    {
        return '<input type="hidden" name="'.$name.'" value="'.$value.'"/>';
    }

    function toggle($row, $value, $action_true, $action_false, $task_true, $task_false)
    {
        $img 	= $value ? 'tick.png' : 'publish_x.png';
        $task 	= $value ? $task_false : $task_true;
        $alt 	= $value ? Agora::lang( $action_false ) : Agora::lang( $action_true );
        $action = $alt;

        $href  = '<a href="javascript:void(0);" onclick="return listItemTask(\'cb'. $row .'\',\''. $task .'\')" title="'. $action .'">';
        $href .= '<img src="images/'. $img .'" border="0" alt="'. $alt .'" /></a>';

        return $href;
    }

    function treename($row, $type=1, $name_field='name', $level_field='level')
    {
        if ($row[$level_field] == 0) {
            return $row[$name_field];
        }

        if ( $type ) {
            $pre 	= '<sup>|_</sup>&nbsp;';
            $spacer = '.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        } else {
            $pre 	= '- ';
            $spacer = '&nbsp;&nbsp;';
        }

        return str_repeat($spacer,$row[$level_field]).$pre.$row[$name_field];
    }
}

class AHTMLToolBar
{
    function AHTMLToolBar()
    {
        if (floatval(PHP_VERSION) >= 5.0) return;
        overload('AHTMLToolBar');
    }

    function __call($func,$args = array())
    {
        $result = call_user_func_array(array('JToolBarHelper',$func), $args);
        if (floatval(PHP_VERSION) >= 5.0) return $result;
        return true;
    }

    function popupAdd($width=500, $height=300)
    {
        AHTMLToolBar::popup('add','New','new',$width,$height);
    }

    function popup($task, $text, $icon, $width=500, $height=300)
    {
        $bar = & JToolBar::getInstance('toolbar');
        // Add a configuration button
        $current_task = Agora::getVar('task','index');
        $current_page = Agora::getVar('page');
        $action = $task;

        $url = array(
                'task'		=> $current_task,
                'action'	=> $task,
                'type'		=> 'clean',
        );

        if ($current_page) {
            $url['page'] = $current_page;
        }

        $num_args = func_num_args();
        if ($num_args > 5 && $num_args % 2 == 1) {
            for ($arg_num = 5; $arg_num < $num_args; $arg_num += 2) {
                $key = func_get_arg($arg_num);
                $value = func_get_arg($arg_num+1);

                $url[$key] = $value;
            }
        }

        $url = Agora::makeURL($url);

        $bar->appendButton( 'Popup', $icon, $text, $url, $width, $height );
    }

}

class AModule
{
    function AModule()
    {
        $this->__construct();
    }

    function __construct()
    {
        $this->toolbar = new AHTMLToolBar();
        $this->form = new AHTMLForm();
        $this->submenu = & JToolBar::getInstance('submenu');
    }

    function jhtml()
    {
        $args = func_get_args();
        return call_user_func_array(array('JHTML','_'), $args);
    }

/*	static function toolbar()
    {
        $args = func_get_args();
    }*/
}

class AdminView extends View
{
    function __construct()
    {
        parent::__construct();
        $module = new AModule();
        $this->smarty->assign_by_ref('html',$module);

        $adminform = new AHTMLAdminForm;
        $this->smarty->register_object('adminform',$adminform);

        // build submenu toolbar
        // need to be built by Joomla and commented out in production version
        $task = Agora::getRequestVar('task','index');

        $lang = & JFactory::getLanguage();
        $lang->load('com_agora',JPATH_ROOT);

        $module->submenu->appendButton(JText::_( 'Control Panel' ), 'index.php?option=com_agora&amp;task=index', $task === 'index');
        $module->submenu->appendButton(JText::_( 'OPTIONS' ), 'index.php?option=com_agora&amp;task=options', $task === 'options');
        $module->submenu->appendButton(JText::_( 'CONFIGURATION' ), 'index.php?option=com_agora&amp;task=configuration&amp;page=smilies', $task === 'configuration');
        $module->submenu->appendButton(JText::_( 'FORUMS' ), 'index.php?option=com_agora&amp;task=forums', $task === 'forums');
        $module->submenu->appendButton(JText::_( 'USER' ), 'index.php?option=com_agora&amp;task=users', $task === 'users');
        $module->submenu->appendButton(JText::_( 'GROUPS' ), 'index.php?option=com_agora&amp;task=groups', $task === 'groups');
        $module->submenu->appendButton(JText::_( 'MAINTENANCE' ), 'index.php?option=com_agora&amp;task=maintenance', $task === 'maintenance');
        $module->submenu->appendButton(JText::_( 'HELP' ), 'http://jVitals.com/docs/index.php?title=Main_Page "target=_blank"');
    }

    function display()
    {
        if (Agora::getVar('type') === 'clean')
        JRequest::setVar('tmpl', 'component'); //force the component template

        $this->doc->addStyleSheet(Agora::getRoot() . 'css/admin.css');
        $this->smarty->display($this->template.'.tpl');
    }
}

?>

