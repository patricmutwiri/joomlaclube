<?php
	defined ('IN_AGORA') or die;
	ainclude('include|controller.php');

	class AgoraAdminController extends AgoraCommonController
	{
		function __construct()
		{
			parent::__construct();
			$this->loadView('AdminView','adminview.php');

			if (method_exists($this,'loadModel')) {
				$this->loadModel();
			}

		}

		function setPagination($total)
		{
			$app = &JFactory::getApplication();
			$limit		= $app->getUserStateFromRequest( 'global.list.limit',	'limit',		$app->getCfg( 'list_limit' ),	'int' );
			$limitstart	= $app->getUserStateFromRequest( 'com_agora.limitstart','limitstart',	0,								'int' );
			
			jimport('joomla.html.pagination');
			$this->pagination = new JPagination( $total, $limitstart, $limit );
			if ($limit > 0) {
				$this->pagination->page = $limitstart / $limit + 1;
				$this->pagination->per_page = $limit;
			} else {
				$this->pagination->page = 1;
				$this->pagination->per_page = $total;
			}

			$this->view->assign('pagination',$this->pagination);
		}

	}

?>
