<?php

class TaskController extends AgoraCommonController
{
	function TaskController()
	{
		$this->__construct();
	}

	function _execute()
	{
	}
	
	function __construct()
	{
		$this->db = & JFactory::getDBO();
        $lang = & JFactory::getLanguage();
        $lang->load('com_agora',JPATH_ROOT);
	}

	function checkPath($path)
	{
		if ($path[0] !== '/')
			$path = JPath::clean(JPATH_ROOT.DS.$path);

		if (!file_exists($path)) {
			echo '<span style="color: #FF0000">'.Agora::lang('DIR_NOT_FOUND').'</span>';
			@mkdir($path, 0777,true);
			if (!file_exists($path)) {
				echo '<span style="color: #FF0000">'.Agora::lang('DIR_CREATE_FAILED').'</span>';
			}

		}

		$r = false;

		if (is_dir($path) && is_writable($path)) {
			echo '<span style="color: #00FF00">Ok</span>';
			$r = true;
		} elseif (file_exists($path) && !is_dir($path)) {
			echo '<span style="color: #FF0000">'.Agora::lang('DIR_NOT_DIR').'</span>';
		} elseif (file_exists($path)) {
			echo '<span style="color: #0000FF">'.Agora::lang('DIR_NOT_WRITABLE').'</span>';
			JPath::setPermissions($path,'0777','0777');
			if (is_writable($path)) {
				echo '<span style="color: #00FF00">Ok</span>';
				$r = true;
			} else {
				echo '<span style="color: #F00F00">'.Agora::lang('DIR_CHMOD_FAILED').'</span>';
			}
		}
		echo "<br/>\n";

		if (!$r) {
			echo '<strong>';
			$link = '<a href="javascript:void(0);" onClick="agora_checkDirs()">'.Agora::lang('CHECK_DIR_PERMISSIONS').'</a>';
			echo Agora::lang('DIR_PERMISSIONS_FAILED',$link);
			echo '</strong><br/><br/>'."\n";
		}
		return $r;
	}

	function checkDirs()
	{
/*		$uri = & JFactory::getURI();
		$uri = $uri->toString();*/

		echo '<h2>'.Agora::lang('Directory_permissions').'</h2>';

		$this->db->setQuery('SELECT conf_value FROM #__agora_config WHERE conf_name=\'o_avatars_dir\'');
		$path = $this->db->loadResult();
		echo Agora::lang('CHECK_AVATARS',$path).' ';
		$this->checkPath($path);

		$path = 'cache' . DS . 'com_agora';
		echo Agora::lang('CHECK_CACHE',$path).' ';
		$this->checkPath($path);

		$path = 'components' . DS . 'com_agora'. DS. 'img'. DS. 'members';
		echo Agora::lang('CHECK_UPLOADS',$path).' ';
		$this->checkPath($path);

		$path = 'components' . DS . 'com_agora'. DS. 'img'. DS. 'members'.DS.'*';
		$dirs = glob(JPATH_ROOT.DS.$path,GLOB_NOSORT | GLOB_ONLYDIR | GLOB_NOESCAPE);
		if (!$dirs) return;
		foreach ($dirs as $dir) {
			$dir = str_replace(JPATH_ROOT.DS, '', $dir);
			echo Agora::lang('CHECK_EXISTING_UPLOADS',$dir).' ';
			$this->checkPath($dir);
		}
	}

	function installClean()
	{
		echo '<h2>'.Agora::lang('CLEAN_DATABASE').'</h2>';

		$this->db->setQuery('SHOW TABLES LIKE \'%\_agora\_%\'');
		$tables = $this->db->loadResultArray();
		echo Agora::lang('FOUND_OLD_TABLES',count($tables))."<br/>\n";

		$dropped = 0;
		foreach ($tables as $table) {
			$this->db->setQuery('DROP TABLE '.$table);
			if ($this->db->query()) {
				$dropped += 1;
			}
		}
		echo Agora::lang('DROPPED_OLD_TABLES',$dropped)."<br/>\n";

		echo Agora::lang('RUNNING_SQL_FILES')."<br/>\n";
		require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'install.agora.php');
		$installer = new AgoraInstaller();

		$cnt = $installer->runSQLFile('install.agora.sql');
		echo 'install.agora.sql: '.$cnt.' '.Agora::lang('QUERIES_PROCESSED')."<br/>\n";

		$cnt = $installer->runSQLFile('upgrade.fresh.sql');
		echo 'upgrade.fresh.sql: '.$cnt.' '.Agora::lang('QUERIES_PROCESSED')."<br/>\n";

		foreach ($installer->logList as $logs) {
			switch ($logs->type) {
				case 'error': $color = '#FF0000'; break;
				case 'info': $color = '#0000FF'; break;
				default: $color = '#000000';
			}
			echo '<span color="'.$color.'">'.$logs->message.'</span><br/>'."\n";
		}
	}

	function syncUsers()
	{
		echo '<h2>'.Agora::lang('SYNC_USERS').'</h2>';
		// remove delete users from Agora tables
		$users_model = & Model::getInstance('UserModel');

		$this->db->setQuery('SELECT ag.id'.
						' FROM #__agora_users AS ag'.
						' LEFT JOIN #__users AS jos'.
						'  ON jos.id=ag.jos_id'.
						' WHERE jos.id IS NULL');
		$deleted = $this->db->loadResultArray();
		$users_model->deleteList($deleted);

		echo Agora::lang('DELETED_USERS',$deleted)."<br/>\n";
		
		// add new users to Agora
		$this->db->setQuery('SELECT jos.id, jos.lastvisitDate, jos.registerDate, jos.username, jos.email, jos.usertype'.
						' FROM #__agora_users AS ag'.
						' RIGHT JOIN #__users AS jos'.
						'  ON jos.id=ag.jos_id'.
						' WHERE ag.jos_id IS NULL');

		$new = $this->db->loadObjectList();

		foreach ($new as $user) {
			$users_model->createUserFromJoomla($user);
		}
		echo Agora::lang('ADDED_USERS',count($new))."<br/>\n";
	}

	function optimize()
	{
		echo '<h2>'.Agora::lang('Optimize database').'</h2>';
		$service_model = & Model::getInstance('ServiceModel');
		
		$start = microtime(true);
		echo Agora::lang('RUNNING_ON_ALL_TABLES','OPTIMIZE TABLE');
		$service_model->optimize();
		echo ' '.Agora::lang('SERVICE_OK',floatval(microtime(true)-$start))."<br/>\n";

		$start = microtime(true);
		echo Agora::lang('RUNNING_ON_ALL_TABLES','ANALYZE TABLE');
		$service_model->analyze();
		echo ' '.Agora::lang('SERVICE_OK',floatval(microtime(true)-$start))."<br/>\n";
	}
}

?>
