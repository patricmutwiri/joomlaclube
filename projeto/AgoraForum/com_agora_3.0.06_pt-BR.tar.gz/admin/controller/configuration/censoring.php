<?php
    defined ('IN_AGORA') or die;

	class TaskController extends AgoraAdminController
	{
		function loadModel()
		{
			$this->model = & Model::getInstance('CensoringModel');
		}

		function _default()
		{
			$this->setPagination($this->model->loadAllCount());
			$censors = $this->model->loadAll('',$this->pagination->per_page,$this->pagination->page);
			
			$this->view->assign('censoring',$censors);
			$this->view->template='configuration/censoring';
		}

		function remove()
		{
			$cid = Agora::getPostVar('cid',array());

			foreach ($cid as $id) {
				$this->model->delete($id);
			}
			$this->redirect();
		}
		function save()
		{
			$this->model->add(Agora::getPostVar('form',array()));
			$this->redirect();
		}

		function add()
		{
			//show new censor page
			$this->view->template = 'configuration/add_censor';
		}
	}
?>
