<?php

class TaskController extends AgoraAdminController
{
	function loadModel()
	{
		$this->model = & Model::getInstance('RanksModel');
	}

	function _default()
	{
		$this->setPagination($this->model->loadAllCount());

		$this->model->setOrder('ORDER BY min_posts ASC');
		$ranks = $this->model->loadAll('',$this->pagination->per_page,$this->pagination->page);

		foreach ($ranks as $key=>$rank) {
			if ($rank['image'])
				$ranks[$key]['image'] = Agora::getSite().'img/ranks/'.$rank['image'];
		}

		$this->view->assign('ranks',$ranks);
		$this->view->template='configuration/ranks';
	}

	function add()
	{
		$rank = array('id'=>0,'min_posts'=>'','rank'=>'');
		$images = $this->model->loadImages();

		$this->view->assign('images',$images);
		$this->view->assign('rank',$rank);
		$this->view->assign('type','clean');
		$this->view->template='configuration/edit_rank';
	}

	function edit()
	{
		$cid = Agora::getPostVar('cid');
		if (is_array($cid)) {
			$id = array_shift($cid);
		} else {
			$id = Agora::getVar('id');
		}
		$rank = $this->model->load($id);
		$images = $this->model->loadImages();

		$this->view->assign('rank',$rank);
		$this->view->assign('images',$images);
		$this->view->template='configuration/edit_rank';
	}

	function save()
	{
		$rank = Agora::getPostVar('form',array());
		$id = Agora::getPostVar('id',0);

		if (trim($rank['min_posts']) == '') {
			Agora::showError('Rank cannot be empty');
			$this->redirect('task=configuration');
		}

		if (!$id) {
			$rank['min_posts'] = intval($rank['min_posts']);
			$exists = $this->model->load($rank['min_posts'],'min_posts');
			if ($exists) {
				Agora::showError('Rank with this post numbers already exists');
				$this->redirect('task=configuration');
			}
			$this->model->add($rank);
		} else {
			$this->model->edit($id,$rank);
		}

		Agora::showMessage('Rank saved');
		$this->redirect('task=configuration');
	}

	function cancel()
	{
		$this->redirect('task=configuration');
	}

	function remove()
	{
		$ids = Agora::getPostVar('cid',array());
		if (!is_array($ids)) {
			Agora::showError('Bad request');
			$this->redirect();
		}

		foreach($ids as $id) {
			$this->model->delete($id);
		}

		$this->redirect();
	}
}

?>