<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraAdminController
	{
		function loadModel()
		{
			$this->model = Model::getInstance('WarningModel');
		}
		function _default()
		{
			$this->view->template = 'configuration/warning';
			$this->setPagination($this->model->loadAllCount());
			$warnings = $this->model->loadAll('',$this->pagination->per_page,$this->pagination->page);
			foreach ($warnings as $key=>$warning) {
				$warnings[$key]['expire'] = getdate($warning['expire'] - intval(date('Z')));
			}
			$this->view->assignRef('warnings',$warnings);
		}

		function add()
		{
			$this->view->template = 'configuration/add_warning';

		}

		function edit()
		{
			$this->view->template = 'configuration/edit_warning';
			$cid = Agora::getPostVar('cid');
			$id = array_shift($cid);

			$warning = $this->model->load($id);
			$warning['expire'] = getdate($warning['expire'] - intval(date('Z')));
			$this->view->assign('warning',$warning);
		}

		function save()
		{
			$form = Agora::getPostVar('form');

			$e = & $form['expire'];
			$expire = intval($e['days'])*3600 * 24 + intval($e['hours']) * 3600 + intval($e['minutes']) * 60;
			$form['expire'] = $expire;

			if (isset($form['id'])) {
				$this->model->edit($form['id'],$form);
			} else {
				$this->model->add($form);
			}

			$this->redirect();
		}

		function remove()
		{
			$cid = Agora::getPostVar('cid');
			foreach ($cid as $id) {
				$this->model->delete($id);
			}
			$this->redirect();
		}

		function copy()
		{
			$id = Agora::getVar('id');
			if (!isset($id)) {
				$this->redirect();
			}

			$warning_model = & Model::getInstance('WarningModel');
			$warning_model->copy($id);
			$this->redirect();
		}
	}
		if (Agora::getRequestVar('part','bans') === 'warnings') {
		ainclude('controller|configuration|bans|warnings');
	} else {
		ainclude('controller|configuration|bans|bans');
	}
?>
