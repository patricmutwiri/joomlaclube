<?php

	defined ('IN_AGORA') or die;

	class TaskController extends AgoraAdminController
	{
		function loadModel()
		{
			$this->model = & Model::getInstance('SmiliesModel');
		}

		function _default()
		{
			$this->view->template='configuration/smilies';

			$this->setPagination($this->model->loadAllCount());

			$smilies = $this->model->loadAll('',$this->pagination->per_page,$this->pagination->page);
			
			$this->view->assign('smilies',$smilies);
		}

		function remove()
		{
			$ids = Agora::getPostVar('cid',array());
			if (!is_array($ids)) {
				Agora::showError('Bad request');
				$this->redirect();
			}

			foreach($ids as $id) {
				$this->model->delete($id);
			}

			$this->redirect();
		}

		function add()
		{
			$this->view->template='configuration/add_smile';
		}

		function cancel()
		{
			$this->redirect();
		}

		function save()
		{
			$s_id = Agora::getPostVar('id');
			$s_image = Agora::getPostVar('smiley_image','');
			$s_text = Agora::getPostVar('smiley_code','');

			if (trim($s_image) == '' || trim($s_text) == '') {
				Agora::showError('You cannot have blank smilies');
				$this->redirect();
			}

			if ($s_id) {
				$this->model->edit($s_id, array (
						'text'=>$s_text,
						'image'=>$s_image
					));
				
			} else {
				$this->model->add($s_image,$s_text);
			}
			$this->redirect();
		}

		function edit()
		{
			$cid = Agora::getPostVar('cid');
			$id = array_shift($cid);
			$form = $this->model->load($id);
			$this->view->assign('form',$form);
			$this->view->template = 'configuration/edit_smile';
		}
	}

?>
