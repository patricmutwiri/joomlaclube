<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraAdminController
	{
		function loadModel()
		{
			$this->model = & Model::getInstance('AggregatorModel');
		}

		function _default()
		{
			$this->setPagination($this->model->loadAllCount());

			$feeds = $this->model->loadFeeds($this->pagination->per_page,$this->pagination->page);

			$this->view->assign('feeds',$feeds);
			$this->view->template='configuration/aggregator';
		}

/*		function change_settings()
		{
			$form = Agora::getPostVar('form');

			$conf = array();
			if ($form['o_rss_cron_builtin'] != $this->agora_config['o_rss_cron_builtin']) {
				$conf['o_rss_cron_builtin'] = $form['o_rss_cron_builtin'];
			}

			if ($form['o_rss_cron_interval'] != $this->agora_config['o_rss_cron_interval']) {
				$conf['o_rss_cron_interval'] = $form['o_rss_cron_interval'];
			}

			if (!empty($conf)) {
				Model::getInstance('ConfigModel')->save($conf);
			}
			$this->redirect();
		}*/

		function add()
		{
			$this->view->template='configuration/add_feeds';
		}
		
		function save()
		{
			$form = Agora::getPostVar('form');
			
			$url = $form['url'];
			$max = $form['max'];
			$closed = $form['closed'];
			$forum_id = $form['forum_id'];

			if ($this->model->feedExists($url)) {
				Agora::showError('Feed with this url already exists');
				$this->redirect();
			}

			$this->model->addFeed($url, $forum_id, $max, $closed);
			$this->redirect();
		}

		function remove()
		{
			$cid = Agora::getPostVar('cid');

			foreach ($cid as $url) {
				$this->model->delete($url);
			}

			$this->redirect();
		}
	}
?>
