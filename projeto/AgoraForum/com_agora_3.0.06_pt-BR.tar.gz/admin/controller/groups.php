<?php

class TaskController extends AgoraAdminController
{
	function _default()
	{
		$groups_model = & Model::getInstance('GroupModel');

		$this->setPagination($groups_model->loadAllCount());
		
		$groups = $groups_model->loadAll();
		$groups = parseTree($groups,0,0,'id','parent_id', true);
		$groups = array_slice($groups,$this->pagination->limitstart,$this->pagination->per_page);
		
		$this->view->assign('groups',$groups);
		$this->view->template = 'groups/list';
		
	}

	function edit_permissions()
	{
		$group_id = Agora::getVar('group_id');
		$role_id = Agora::getVar('role_id');

		$access_model = & Model::getInstance('AccessModel');

		$group_perm = $access_model->getGroupPermissions($group_id);
		$group_perm = $group_perm[$role_id];

		$this->view->assign('permissions',$group_perm);

		$this->view->assign('group_id',$group_id);
		$this->view->assign('role_id',$role_id);

		$this->view->template = 'groups/permissions';
	}

	function save_permissions()
	{
		$form = Agora::getPostVar('form');
		$group_id = $form['group_id'];
		$role_id = $form['role_id'];

		$access_model = & Model::getInstance('AccessModel');
		$group_perm = $access_model->getGroupPermissions($group_id);
		$group_perm = $group_perm[$role_id];

		foreach ($group_perm as $permission=>$value) {
			$group_perm[$permission] = 0;
		}

		foreach ($form as $perm_name=>$permission) {
			// $form has other data except permissions - role_id, group_id, etc.
			// here we ensure we update permission only
			if (isset($group_perm[$perm_name]))
				$group_perm[$perm_name] = 1;
		}

		$access_model->setGroupPermissions($group_id,$role_id,$group_perm);
		$this->redirect('action=edit','group_id');

	}

	function edit()
	{
		$cid = Agora::getPostVar('cid');
		if (is_array($cid)) {
			$group_id = array_shift($cid);
			$this->redirect('action=edit','group_id='.$group_id);
			return;
		}

		$group_id = Agora::getVar('group_id');
		$group_model = & Model::getInstance('GroupModel');
		$group = $group_model->load($group_id);

		$groups = $group_model->loadAll('id');
		unset($groups[$group_id]);
		$groups = parseTree($groups, 0, 1,'id','parent_id', true);

		$access_model = &Model::getInstance('AccessModel');
		$permissions = $access_model->getGroupPermissions($group_id);

		$access = array();
		foreach ($permissions as $role_key=>$role) {
			$access[$role_key] = array();
			foreach ($role as $perm_key => $value) {
				if ($value) {
					$access[$role_key][] = $perm_key;
				}
			}
		}
		
		$roles = array();
		foreach ($access_model->roles as $role_id => $role_name) {
			$roles[$role_id] = Agora::lang(str_replace('AGORA_ROLE_','',$role_name));
		}

		$this->view->assign('roles',$roles);

		$this->view->assign('permissions',$access);
		$this->view->assign('groups',$groups);
		$this->view->assign('group',$group);
		$this->view->template = 'groups/edit';
	}

	function add()
	{
		$group_model = & Model::getInstance('GroupModel');
		$groups = $group_model->loadAll('id');
		$groups = parseTree($groups, 0, 1,'id','parent_id', true);

		$group = array(
			'id' => '0',
			'name' => '',
			'parent_id' => '0'
		);

		$this->view->assign('group',$group);
		$this->view->assign('groups',$groups);
		
		$this->view->template = 'groups/edit';
	}
	
	function save()
	{
		$form = Agora::getPostVar('form');
		$group_id = $form['group_id'];
		unset($form['group_id']);

		$group_model = & Model::getInstance('GroupModel');

		if ($group_id == 0) {
			$group_model->add($form['name'],$form['parent_id']);
		} else {
			$group_model->edit($group_id,$form);
		}

		$this->redirect();
	}

	function remove()
	{
		$cid = Agora::getPostVar('cid',array());

		$group_model = &Model::getInstance('GroupModel');
		foreach ($cid as $group_id) {
			if ($group_id == 1) {	//trying to delete group 1
				JError::raiseWarning( 0, JText::_('WARNING YOU CAN NOT DELETE DEFAULT GROUP') );
			} 
			else {
				$group_model->delete($group_id);
			}
		}
		$this->redirect();
	}
}

?>
