<?php
class TaskController extends AgoraAdminController
{
	function _default()
	{
//		echo 123;
		$page = Agora::getVar('page','essentials');
		$this->view->template = 'options'.DS.$page;

		$model = & Model::getInstance('ConfigModel');
		$conf = $model->load();
		$this->view->assign('agora_config',$conf);

		if ($page === 'essentials') {
			$styles_model = & Model::getInstance('StylesModel');
		    $this->view->smarty->assign_by_ref('styles',$styles_model->loadAll());
		}
		if ($page === 'disp') {
			$defaultview = array(
				'topic'=>JText::_('CC_TOPIC_VIEW'),
				'forum'=>JText::_('CC_FORUM_VIEW'),
			);
		
	    	$this->view->smarty->assign_by_ref('defaultview',$defaultview);
		}
	}

	function _save()
	{
		if (Agora::getRequestVar('action') === 'cancel') {
			$this->redirect();
			return;
		}

		header('content-type: text/plain');

		$form = Agora::getPostVar('form',array(),true);

		$model = & Model::getInstance('ConfigModel');

		$conf = $model->load();
		$changed_data = array();

		foreach ($form as $var=>$value)
		{
			if ($var === 'o_maintenance_message' || $var === 'o_rules_message') {
				$value = Agora::linebreaks($value);
			}
			
			if ($conf[$var] != $value) {
				$changed_data[$var] = $value;
			}
		}

		$model->save($changed_data);
		Agora::showMessage('Saved');
		$this->redirect();
	}

}

?>
