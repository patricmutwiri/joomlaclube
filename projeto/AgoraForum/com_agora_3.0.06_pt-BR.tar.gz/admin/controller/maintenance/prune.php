<?php

	defined ('IN_AGORA') or die;

	class TaskController extends AgoraAdminController
	{
		function _default()
		{
			$this->view->template = 'maintenance/prune';
		}

		function confirm()
		{
			$form = Agora::getPostVar('form',array('days'=>10,'forum'=>-1,'sticky'=>0));
			$service_model = & Model::getInstance('ServiceModel');
			$forums = $service_model->getPruneCount($form['days'],$form['forum'],$form['sticky']);

			$this->view->assign('forums',$forums);
			$this->view->assign('form',$form);
			$this->view->template = 'maintenance/prune_confirm';
		}
		
		function prune()
		{ 	
			$form = Agora::getPostVar('form',array('days'=>10,'forum'=>-1,'sticky'=>0));
			$service_model = & Model::getInstance('ServiceModel');
			$topics_deleted = $service_model->prune($form['days'],$form['forum'],$form['sticky']);
			$this->view->assign('topics_deleted',$topics_deleted);
			$this->view->template = 'maintenance/prune';
		}
	}
?>