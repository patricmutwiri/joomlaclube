<?php

	defined ('IN_AGORA') or die;

	class TaskController extends AgoraAdminController
	{
		function _default()
		{
			$this->view->template = 'maintenance/tools';
		}

	}

?>
