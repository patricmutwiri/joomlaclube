<?php
  include('polls.php');
?>