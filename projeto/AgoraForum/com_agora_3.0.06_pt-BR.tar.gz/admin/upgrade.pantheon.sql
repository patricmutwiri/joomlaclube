DROP TABLE `#__agora_forum_perms`;
DROP TABLE `#__agora_groups`;
DROP TABLE `#__agora_online`;
DROP TABLE `#__agora_search_cache`;
DROP TABLE `#__agora_search_matches`;
DROP TABLE `#__agora_search_words`;
DROP TABLE `#__agora_Ratings`;

ALTER TABLE `#__agora_feeds` DROP PRIMARY KEY;
ALTER TABLE `#__agora_feeds` MODIFY COLUMN url varchar(255) NOT NULL DEFAULT '';
ALTER TABLE `#__agora_feeds` ADD COLUMN id int(10) unsigned NOT NULL PRIMARY KEY auto_increment;
ALTER TABLE `#__agora_forums` MODIFY COLUMN forum_name varchar(80) NOT NULL;
ALTER TABLE `#__agora_forums` ADD COLUMN enable tinyint(1) NOT NULL DEFAULT 1;
ALTER TABLE `#__agora_categories` ADD COLUMN enable tinyint(1) NOT NULL DEFAULT 1;
ALTER TABLE `#__agora_polls` MODIFY COLUMN created int(10) unsigned NOT NULL;
ALTER TABLE `#__agora_smilies` CHANGE COLUMN Id id int(10) NOT NULL auto_increment;
ALTER TABLE `#__agora_topics` MODIFY COLUMN icon_topic tinyint(1) NOT NULL DEFAULT 0;
ALTER TABLE `#__agora_users` MODIFY COLUMN jos_id int(10) NOT NULL;
ALTER TABLE `#__agora_users` DROP COLUMN membergroupids;
ALTER TABLE `#__agora_users` DROP COLUMN password;
ALTER TABLE `#__agora_users` DROP COLUMN email_setting;
ALTER TABLE `#__agora_users` DROP COLUMN save_pass;
ALTER TABLE `#__agora_users` DROP COLUMN timezone;
ALTER TABLE `#__agora_users` DROP COLUMN language;
ALTER TABLE `#__agora_users` DROP COLUMN registration_ip;
ALTER TABLE `#__agora_users` DROP COLUMN activate_string;
ALTER TABLE `#__agora_users` DROP COLUMN activate_key;
ALTER TABLE `#__agora_users` MODIFY COLUMN skype varchar(30) NULL;
ALTER TABLE `#__agora_users` MODIFY COLUMN xfire varchar(30) NULL;
ALTER TABLE `#__agora_users` MODIFY COLUMN reverse_posts tinyint(1) NOT NULL DEFAULT 0;
ALTER TABLE `#__agora_users` DROP COLUMN read_topics;
ALTER TABLE `#__agora_users` MODIFY COLUMN rep_minus int(11) unsigned NOT NULL DEFAULT 0;
ALTER TABLE `#__agora_users` MODIFY COLUMN rep_plus int(11) unsigned NOT NULL DEFAULT 0;
ALTER TABLE `#__agora_users` MODIFY COLUMN reputation_enable tinyint(1) NOT NULL DEFAULT 0;
ALTER TABLE `#__agora_users` DROP COLUMN reputation_enable_adm;
ALTER TABLE `#__agora_users` DROP COLUMN email_alert;

INSERT INTO `#__agora_roles` (name) VALUES ('guest'), ('member'), ('moderator'), ('admin');
INSERT INTO `#__agora_group` (name) VALUES ('Global');

INSERT INTO `#__agora_permissions` (
			`read`,`read_rss`,`bbcode`,`bbcode_img`,
			`post_reply`,`post_poll`,`post_topic`,`edit_topic`,
			`edit_posts`,`delete_topics`, `delete_posts`,`make_sticky`,
			`close_topic`, `use_captcha`)
			VALUES (1,1,0,0,0,0,0,0,0,0,0,0,0,0);

INSERT INTO `#__agora_permissions` (
			`read`,`read_rss`,`bbcode`,`bbcode_img`,
			`post_reply`,`post_poll`,`post_topic`,`edit_topic`,
			`edit_posts`,`delete_topics`, `delete_posts`,`make_sticky`,
			`close_topic`, `use_captcha`)
			VALUES (1,1,1,1,1,1,1,1,1,0,0,0,1,0);

INSERT INTO `#__agora_permissions` (
			`read`,`read_rss`,`bbcode`,`bbcode_img`,
			`post_reply`,`post_poll`,`post_topic`,`edit_topic`,
			`edit_posts`,`delete_topics`, `delete_posts`,`make_sticky`,
			`close_topic`, `use_captcha`)
			VALUES (1,1,1,1,1,1,1,1,1,1,1,1,1,0);

INSERT INTO `#__agora_permissions` (
			`read`,`read_rss`,`bbcode`,`bbcode_img`,
			`post_reply`,`post_poll`,`post_topic`,`edit_topic`,
			`edit_posts`,`delete_topics`, `delete_posts`,`make_sticky`,
			`close_topic`, `use_captcha`)
			VALUES (1,1,1,1,1,1,1,1,1,1,1,1,1,0);

INSERT INTO `#__agora_group_permissions` (group_id,role_id,access_id) VALUES (1,1,1);
INSERT INTO `#__agora_group_permissions` (group_id,role_id,access_id) VALUES (1,2,2);
INSERT INTO `#__agora_group_permissions` (group_id,role_id,access_id) VALUES (1,3,3);
INSERT INTO `#__agora_group_permissions` (group_id,role_id,access_id) VALUES (1,4,4);

UPDATE `#__agora_config`  SET conf_value = '3.0.0 RC1 Rev.4' WHERE conf_name = 'o_cur_version';

INSERT INTO `#__agora_config`  (conf_name, conf_value) VALUES
('o_rss_cron_builtin',		'1'),
('o_rss_cron_interval',			'180'),
('o_rss_cron_last',				'0'),
('o_community_builder',			'0'),
('o_jomsocial',					'0'),
('o_joomunity',					'0');
