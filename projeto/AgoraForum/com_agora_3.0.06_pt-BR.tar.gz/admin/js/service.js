var loading_message = 'Loading';

function ag_callService(s_name,params)
{
	if (!params) {
		params = {};
	}

	var log = $j('#agora_log');
	log.append('<div id="loading_icon"><img src="components/com_agora/image/loading.gif" alt="loading"/>'+loading_message+'</div>');
	log.get(0).scrollTop = 1000;

	params.option = 'com_agora';
	params.task = 'service';
	params.format = 'raw';
	params.action = s_name;

	$j.get('index.php',params,function(result){
		$j('#loading_icon').remove();
		log.append(result);
		log.get(0).scrollTop = 1000;
	})
}

function ag_checkDirs()
{
	ag_callService('checkDirs');
}

function ag_syncUsers()
{
	ag_callService('syncUsers');
}

function ag_optimize()
{
	ag_callService('optimize');
}

function ag_installClean()
{
	if (!confirm('WARNING! This will unconditionally destroy ALL agora tables. Are you sure?')) return;

	ag_callService('installClean');
}
