<?php

// This is to debug installation script. Need to be removed in production version
/*if (@$_GET['task'] !== 'service') {
	require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'install.agora.php');
	com_install();return;
}*/

if (isset($_REQUEST['agora_task']))
{
	// We need this to handle Joomla buttons like 'remove'
	// They set task option and we have no way to override this (hello Joomla develpers :)
	$_REQUEST['action'] = $_REQUEST['task'];
	$_REQUEST['task'] = $_REQUEST['agora_task'];
}

require_once(JPATH_COMPONENT.DS.'upgrade.php');

if (@$_GET['task'] !== 'service') {
	$up = new AgoraDatabaseUpgrade();
	$up->upgrade();
}

require_once(JPATH_COMPONENT_SITE.DS.'agora.php');

?>
