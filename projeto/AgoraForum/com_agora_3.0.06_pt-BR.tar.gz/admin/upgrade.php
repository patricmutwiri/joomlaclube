<?php

@define ('AGORA_VERSION', 'Agora 3.0.06');

class AgoraDatabaseUpgrade
{
	var $statements = array(
		1 => array(
			'INSERT INTO `#__agora_config` (conf_name, conf_value) VALUES (\'o_database_revision\', \'1\')',
		),
		array(
			'DROP TABLE IF EXISTS `#__agora_annonces`',
			'ALTER TABLE `#__agora_forums` DROP COLUMN `guest_access`',
			'ALTER TABLE `#__agora_permissions` ADD `use_captcha`	BOOL NOT NULL DEFAULT 0',
			'ALTER TABLE `#__agora_permissions` ALTER COLUMN `use_captcha`	SET DEFAULT 0',
			'ALTER TABLE `#__agora_permissions` ADD `edit_topic`	BOOL NOT NULL DEFAULT 1',
			'ALTER TABLE `#__agora_permissions` ADD `edit_posts`	BOOL NOT NULL DEFAULT 1',
			'ALTER TABLE `#__agora_permissions` ADD `make_sticky`	BOOL NOT NULL DEFAULT 1',
			'ALTER TABLE `#__agora_permissions` ADD `close_topic`	BOOL NOT NULL DEFAULT 1',
		),
		array(
			'ALTER TABLE `#__agora_subscriptions` ADD `forum_id` INT( 10 ) UNSIGNED NOT NULL DEFAULT \'0\' ADD `category_id` INT( 10 ) UNSIGNED NOT NULL DEFAULT \'0\'',
			'INSERT INTO `#__agora_config` (conf_name, conf_value) VALUES (\'o_avatars_dheight\', \'100\')',
			'INSERT INTO `#__agora_config` (conf_name, conf_value) VALUES (\'o_avatars_dwidth\', \'100\')',
			'INSERT INTO `#__agora_config` (conf_name, conf_value) VALUES (\'o_avatars_ratio\', \'1\')',
		),
		array(
			'ALTER TABLE `#__agora_subscriptions` ADD `forum_id` INT( 10 ) UNSIGNED NOT NULL DEFAULT \'0\'',
			'ALTER TABLE `#__agora_subscriptions` ADD `category_id` INT( 10 ) UNSIGNED NOT NULL DEFAULT \'0\'',
			'ALTER TABLE `#__agora_subscriptions` DROP PRIMARY KEY',
			'ALTER TABLE `#__agora_subscriptions` ADD PRIMARY KEY ( `user_id` , `topic_id` , `forum_id` , `category_id` )',
		),
		array(
			'UPDATE `#__agora_config` SET conf_value = \'10\' WHERE conf_name=\'o_timeout_visit\' AND conf_value=\'600\'',
		),
		array(
			'ALTER TABLE `#__agora_group` DROP COLUMN `access_id`',
			'CREATE TABLE `#__agora_group_permissions`
			(
				`id` int(10) unsigned NOT NULL auto_increment,
				`group_id` int(10) unsigned NOT NULL,
				`role_id` int(10) unsigned NOT NULL,
				`access_id` int(10) unsigned NOT NULL,
				PRIMARY KEY(`id`),
				UNIQUE(`group_id`,`role_id`),
				UNIQUE(`access_id`)
			) Type=MyISAM',
			'setDefaultPermissions',
		),

		array(
			'UPDATE `#__agora_config` SET conf_value=\'txt,jpg,jpeg,png,gif,doc,mp3,pdf,zip,rar\' WHERE conf_name = \'o_uploadile_laws\'',
		),
		// Version bump - it's RC2 now
		array(
			'INSERT INTO `#__agora_config` (conf_name, conf_value) VALUES (\'o_auto_subscriptions\', \'1\')',
			'ALTER TABLE `#__agora_users` ADD `auto_subscriptions` tinyint(1) NULL  DEFAULT \'1\'',
		),
		array(
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_default_view\', \'forum\')',
		),
		array(
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_bbcode_quickpost\', \'0\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_quickjump_footer\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_prof_title\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_prof_location\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_prof_website\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_prof_gender\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_prof_dob\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_prof_interests\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_prof_about\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_prof_sig\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_prof_messaging\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_prof_gallery\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_prof_attach\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_allow_attach\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_main_menu\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_bstats\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_user_guest\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_binfo\', \'1\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_pm_subject\', \'PM Subject\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_pm_messg\', \'<p>Hello [username]<br />You have received a Private message from [sitename] at [site] from [username]<br />The PM Reads as follows;</p>
<p>[title]</p>
<p>[message]</p>
<p>please login at [site] and view your message</p>
<p>Thank You<br />Site Administration</p>\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_subscr_subject\', \'Subscription Subject\')',
			'INSERT INTO #__agora_config (conf_name, conf_value) VALUES (\'o_subscr_messg\', \'<p>Hello [username]<br /> <br />[poster] replied to to your post on [sitename] to ([title]) which you are subscribed to. <br />[poster] Wrote: <br />[message]<br /> <br />Please click [topic] to view the post <br />Or <br />Please click here to [unsubscribe]<br /> <br /> [site]</p>
<p>Thank You<br />Site Administration</p>\')',
		),
		array (
			'ALTER TABLE `#__agora_ranks` ADD `image` varchar(50) DEFAULT \'\'',
		),
				// Version bump - it's RC1 now
		array(
			'UPDATE `#__agora_config` SET conf_value = \'Agora 3.0.02\' WHERE conf_name=\'o_cur_version\'',
		),
		array(
			'UPDATE `#__agora_config` SET conf_value = \'Agora 3.0.03\' WHERE conf_name=\'o_cur_version\'',
		),
		array(
			'ALTER TABLE `#__agora_users` ADD INDEX `#__id_index` (`jos_id`)',
		),
		array(
			'INSERT INTO `#__agora_config` (conf_name, conf_value) VALUES (\'o_guest_userlist\', \'1\')',
		),
		array(
			'UPDATE `#__agora_config` SET conf_value = \'Agora 3.0.04\' WHERE conf_name=\'o_cur_version\'',
		),
		array(
			'UPDATE `#__agora_config` SET conf_value = \'Agora 3.0.05\' WHERE conf_name=\'o_cur_version\'',
		),
		array(
			'UPDATE `#__agora_config` SET conf_value = \'Agora 3.0.06\' WHERE conf_name=\'o_cur_version\'',
		),
		array(
			'INSERT INTO `#__agora_config` (conf_name, conf_value) VALUES (\'o_rss_enabled\', \'1\')',
			'INSERT INTO `#__agora_config` (conf_name, conf_value) VALUES (\'o_legend_enabled\', \'1\')',
		),
		array(
			'INSERT INTO `#__agora_config` (conf_name, conf_value) VALUES (\'o_bbcode_video_width\', \'425\')',
			'INSERT INTO `#__agora_config` (conf_name, conf_value) VALUES (\'o_bbcode_video_height\', \'350\')',
		)
	);

	function setDefaultPermissions(&$db)
	{
		$db->setQuery('SELECT * FROM #__agora_group');
		$groups = $db->loadAssocList();

		$db->setQuery('SELECT * FROM #__agora_roles');
		$roles = $db->loadAssocList();

		$default = array(
			'guest' => array (
				'read'			=> 1,
				'read_rss'		=> 1,
				'bbcode'		=> 0,
				'bbcode_img'	=> 0,
				'post_reply'	=> 0,
				'post_poll'		=> 0,
				'post_topic'	=> 0,
				'edit_topic'	=> 0,
				'edit_posts'	=> 0,
				'delete_topics'	=> 0,
				'delete_posts'	=> 0,
				'make_sticky'	=> 0,
				'close_topic'	=> 0,
				'use_captcha'	=> 0,
			),
			'member' => array (
				'read'			=> 1,
				'read_rss'		=> 1,
				'bbcode'		=> 1,
				'bbcode_img'	=> 1,
				'post_reply'	=> 1,
				'post_poll'		=> 1,
				'post_topic'	=> 1,
				'edit_topic'	=> 1,
				'edit_posts'	=> 1,
				'delete_topics'	=> 0,
				'delete_posts'	=> 0,
				'make_sticky'	=> 0,
				'close_topic'	=> 0,
				'use_captcha'	=> 0,
			),
			'moderator' => array (
				'read'			=> 1,
				'read_rss'		=> 1,
				'bbcode'		=> 1,
				'bbcode_img'	=> 1,
				'post_reply'	=> 1,
				'post_poll'		=> 1,
				'post_topic'	=> 1,
				'edit_topic'	=> 1,
				'edit_posts'	=> 1,
				'delete_topics'	=> 1,
				'delete_posts'	=> 1,
				'make_sticky'	=> 1,
				'close_topic'	=> 1,
				'use_captcha'	=> 0,
			),
			'admin' => array (
				'read'			=> 1,
				'read_rss'		=> 1,
				'bbcode'		=> 1,
				'bbcode_img'	=> 1,
				'post_reply'	=> 1,
				'post_poll'		=> 1,
				'post_topic'	=> 1,
				'edit_topic'	=> 1,
				'edit_posts'	=> 1,
				'delete_topics'	=> 1,
				'delete_posts'	=> 1,
				'make_sticky'	=> 1,
				'close_topic'	=> 1,
				'use_captcha'	=> 0,
			),
		);
		foreach ($groups as $group) {
			$group_id = intval($group['id']);
			foreach ($roles as $role) {
				$role_id = intval($role['id']);
				$db->setQuery('SELECT access_id'.
							' FROM #__agora_group_permissions'.
							' WHERE group_id = '.$group_id.
							'   AND role_id = '.$role_id.
							' LIMIT 1'
							);
				$access_id = $db->loadResult();
				if (!is_null($access_id)) continue;
				$role_name = strtolower(trim($role['name']));

				if (!isset($default[$role_name])) continue;
				$sql = 'INSERT INTO #__agora_permissions SET ';

				$fields = array();
				foreach ($default[$role_name] as $name=>$value) {
					$fields[] = $db->nameQuote($name).'='.$db->Quote($value);
				}
				$sql .= implode(', ',$fields);
				$db->setQuery($sql);
				if (!$db->query()) {
					continue;
				}
				
				$access_id = $db->insertid();

				$sql = 'INSERT INTO #__agora_group_permissions SET '.
								'group_id = '.$group_id.','.
								'role_id = '.$role_id.','.
								'access_id = '.$access_id;
				$db->setQuery($sql);
				$db->query();
			}
		}
	}

	function getStatements($current_revision)
	{
		$stmts = array();
		$last = 1;
		foreach ($this->statements as $rev=>$st_list) {
			$last = $rev;
			if ($rev <= $current_revision) continue;

			foreach ($st_list as $st)
				$stmts[] = $st;

		}

		if ($current_revision != $last) {
			$stmts[] = 'UPDATE `#__agora_config` SET conf_value = '.$last.' WHERE conf_name = \'o_database_revision\'';

			// if something changed in database - version may be updated too
			$stmts[] = 'UPDATE `#__agora_config` SET conf_value = "'.AGORA_VERSION.'" WHERE conf_name = \'o_cur_version\'';
		}
		
		return $stmts;
	}

	function upgrade()
	{
		$db = & JFactory::getDBO();
		$old_debug = $db->_debug;
		$db->debug(0);
		$db->setQuery('SELECT conf_value FROM #__agora_config WHERE conf_name = \'o_database_revision\'');
		$current_revision = $db->loadResult();
		$sts = $this->getStatements($current_revision);

		foreach ($sts as $st) {
			if (method_exists($this, $st)) {
				$this->$st($db);
				continue;
			}

			$db->setQuery($st);
			$db->query();
		}
		$db->debug($old_debug);
	}
};

?>
