function resize_message(dy)
{
    msgfield = (document.all) ? document.all.req_message : document.forms['post']['req_message'];
    var box = msgfield;
    var cur_height = parseInt( box.style.height ) ? parseInt( box.style.height ) : 100;
    var new_height = cur_height + dy;
    if (new_height > 100)
    {
        box.style.height = new_height + "px";
    }
    else
        box.style.height = "100px";
    return false;
}

function insert_text(open, close)
{
	msgfield = (document.all) ? document.all.req_message : document.forms['post']['req_message'];
	// IE support
	if (document.selection && document.selection.createRange)
	{
		msgfield.focus();
		sel = document.selection.createRange();
		sel.text = open + sel.text + close;
		msgfield.focus();
	}
	// Moz support
	else if (msgfield.selectionStart || msgfield.selectionStart == '0')
	{
		var startPos = msgfield.selectionStart;
		var endPos = msgfield.selectionEnd;
		msgfield.value = msgfield.value.substring(0, startPos) + open + msgfield.value.substring(startPos, endPos) + close + msgfield.value.substring(endPos, msgfield.value.length);
		msgfield.selectionStart = msgfield.selectionEnd = endPos + open.length + close.length;
		msgfield.focus();
	}
	// Fallback support for other browsers
	else
	{
		msgfield.value += open + close;
		msgfield.focus();
	}
	return;
}

function toggleDisplay(divId) {
	var div = document.getElementById(divId);
	div.style.display = (div.style.display=="block" ? "none" : "block");
}
///The counter of symbols of fields of the form 
function textCount(field,counterfield,max) {
	if (field.value.length > max) // if too long...trim it!
		field.value = field.value.substring(0, max);
	else
	counterfield.value = max - field.value.length;
}
