
  // this is for ze sliding, change the duration value to speed up or slow down the slide (default: 400 / smaller = faster)
  window.addEvent("domready", function(){

  	$$(".slideContainer").each(function(container){
  		var mySlide = new Fx.Slide(container.getElement(".SlideText"), {duration: 400}).hide();
  		container.getElement("a.HideHidden").addEvent("click", function(e){
  			new Event(e).stop();
  			mySlide.slideOut();
  		});
  		container.getElement("a.ShowHidden").addEvent("click", function(e){
  			new Event(e).stop();
  			mySlide.slideIn();
  		});
  	});
  });

  // this is the function for adding the hide tags to the comment box
 // function HiddenText(objTextArea) {
 //   objTextArea.value += '[hide][/hide]';
 // }
 
 
 
/*****************Quote paste*********************/

var txt = ''

function copyQ(nick) { 
	txt = '' 
	if (document.getSelection) {
		txt = document.getSelection()
	} else 
	if (document.selection) {
		txt = document.selection.createRange().text;
	} 
	if (txt!='') 
	txt = '[quote=' + nick + ']' + txt + '[/quote]\n'
}

function insertAtCaret (textObj, textFieldValue) { 
	if (document.all) { 
		if (textObj.createTextRange && textObj.caretPos && !window.opera) { 
			var caretPos = textObj.caretPos; 
			caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?textFieldValue + ' ' : textFieldValue; 
		} else { 
			textObj.value += textFieldValue; 
		} 
	} else { 
		if (textObj.selectionStart) { 
			var rangeStart = textObj.selectionStart; 
			var rangeEnd = textObj.selectionEnd; 
			var tempStr1 = textObj.value.substring(0, rangeStart); 
			var tempStr2 = textObj.value.substring(rangeEnd, textObj.value.length); 
			textObj.value = tempStr1 + textFieldValue + tempStr2; 
			textObj.selectionStart = textObj.selectionEnd = rangeStart + textFieldValue.length;
			
		} else { 
			textObj.value += textFieldValue; 
		} 
	} 
}

function pasteQ() {
    
	if (txt!='' && document.forms['post']['req_message']) 
	insertAtCaret(document.forms['post']['req_message'], txt); 
	document.forms['post']['req_message'].focus();

} 

function pasteN(text) { 
	if (text != '' && document.forms['post']['req_message'])
	insertAtCaret(document.forms['post']['req_message'], "[b]" + text + ",[/b]\n");
	document.forms['post']['req_message'].focus();
}