<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

@define ('IN_AGORA',1);
@define ('AGORA_DEBUG',0);
@define ('AGORA_TIME',time());
//define ('AGORA_HELP_TRANSLATE',1);

if (@AGORA_DEBUG === 1) {
	error_reporting(E_ALL);
	$dbo = & JFactory::getDBO();
	
	$dbo->debug(1);
	$begin_q = $dbo->getTicker();
	$begin = microtime(true);
}

define ('AGORA_PATH',JPATH_COMPONENT_SITE.DS);
define ('AGORA_CURRENT_PATH',JPATH_COMPONENT.DS);


require(AGORA_PATH.'include'.DS.'utils.php');
//ainclude('include|controller');
ainclude('model|model');
ainclude('include|agora.j15');
ainclude('include|dispatcher.j15');


$disp = AgoraDispatcher::getInstance();
$disp->route();
//$dispatcher->route($allowed_tasks);

$raw = JRequest::getVar('format') === 'raw';

if (@AGORA_DEBUG === 1 && !$raw) {
	$end = microtime(true);
	// $dbo was defined in line 11
	$end_q = $dbo->getTicker();

	print "Generated in ". round($end - $begin,3) . " sec. Queries: " . ($end_q - $begin_q);
}


?>
