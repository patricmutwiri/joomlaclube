<?php
defined ('IN_AGORA') or die;

class TaskController extends AgoraPollsController
{
    function _default()
    {
        $catnav_helper = & $this->helper('catnav');
        $catnav_helper->fromForum($this->id);

		$access_helper = & $this->helper('access');
		$access = $access_helper->getForumAccess($this->id);
		$this->view->assign('access',$access);

        $this->view->template = 'poll/multi_yes_no';
    }

    function create()
    {
		if (!$this->agora_user['is_superadmin'] &&
			$this->access_model->authenticate($this->agora_user['id'],$this->id,'use_captcha')) {
			$captcha = Agora::getPostVar('captcha');
			$c_key = Agora::getSessionVar('captcha');

			if (trim($captcha) !== trim($c_key)) {
				Agora::showMessage('Bad captcha');
				Agora::redirect(Agora::getRefferer());
			}
		}
		
        $poll_options = Agora::getPostVar('poll_option',array());
        $opt = array();
        foreach ($poll_options as $option) {
            $option = trim($option);
            if (!empty($option)) {
                $opt[] = $option;
            }
        }

        if (count($opt) < 2) {
            Agora::showMessage('You need to set at least 2 options');
            Agora::redirect(Agora::getRefferer());
        }

        if (trim(Agora::getPostVar('subject',''))=='') {
            Agora::showMessage('You need to set subject');
            Agora::redirect(Agora::getRefferer());
        }

        $poll_yes = Agora::getPostVar('poll_yes','yes');
        $poll_no = Agora::getPostVar('poll_no','no');

        $poll_yes = trim($poll_yes);
        $poll_no = trim($poll_no);

        if (!$poll_yes || !$poll_no) {
            Agora::showMessage('You need to set values for both YES and NO fields');
            Agora::redirect(Agora::getRefferer());
        }

        $topic_model = & Model::getInstance('TopicModel');

        $topic_id = $topic_model->addPoll(
            $this->id,
            Agora::getPostVar('subject','No subject'),
            Agora::getPostVar('desc',''),
            intval(Agora::getPostVar('topic_icon',0)),
            $this->agora_user['username'],
            Agora::getPostVar('req_question','no question'),
            $poll_yes,
            $poll_no
        );

        $topic_model->addPost(
            $topic_id,
            $this->id,
            Agora::getPostVar('req_message','',true),
            $this->agora_user['id'],
            $this->agora_user['username'],
            Agora::getPostVar('hide_smilies',0)
        );

        $this->model->add($topic_id, $opt,	3);
        Agora::redirect(Agora::makeUrl(array('task'=>'topic','id'=>$topic_id)));
    }

    function vote()
    {
        $poll = $this->model->load($this->id,'pollid');

        if (!$poll) {
            Agora::showError(Agora::lang('Invalid request (bad poll id)'));
            $this->redirect();
        }
        if ($poll['ptype'] != '3') {
            Agora::showError(Agora::lang('Invalid request (bad poll type)'));
            $this->redirect();
        }

        $voters = $poll['voters'];
        $votes = $poll['votes'];
        $voter = intval($this->agora_user['id']);

        if (!is_array($votes)) $votes = array();
        if (!is_array($voters)) $voters = array();

        if (in_array($voter,$voters)) {
            Agora::showError(Agora::lang('You already voted'));
            $this->redirect();
        }

        if (Agora::getPostVar('submit')) {
            $options = Agora::getPostVar('options',array());

            foreach ($options as $key=>$value) {

                if ($value == "yes")
                {
                    if (isset($votes[$key]['yes']))
                    $votes[$key]['yes']++;
                    else
                    $votes[$key]['yes'] = 1;
                } else {
                    if (isset($votes[$key]['no']))
                    $votes[$key]['no']++;
                    else
                    $votes[$key]['no'] = 1;
                }
            }
        }

        $voters[] = $voter;

        $this->model->setVotes($this->id, $votes,$voters);

        Agora::showMessage(Agora::lang('You vote accepted'));
        $this->redirect();
    }
}
?>
