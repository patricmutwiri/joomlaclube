<?php
    defined ('IN_AGORA') or die;

	class AgoraPollsController extends AgoraController {

		function __construct()
		{
			parent::__construct();
			$this->loadDefaultView();

			$this->id = Agora::getVar('id');

			if (!$this->id && Agora::getVar('action') !== 'select_forum' ) {
				Agora::showError(Agora::lang('Bad request'));
				Agora::redirect(Agora::getRefferer());
			}
			$this->model = & Model::getInstance('PollModel');

			$smilies_model = & Model::getInstance('SmiliesModel');
			$smilies = $smilies_model->loadAll();

			$this->view->assignRef('smilies',$smilies);

			$icons_model = & Model::getInstance('TopicIconsModel');
			$topic_icons = $icons_model->loadAll();

			$this->view->assignRef('topic_icons',$topic_icons);
			$this->view->assign('cur_forum_id',$this->id);
		}

		function redirect()
		{
			Agora::redirect(Agora::makeURL(
				array(
				'task'	=>'topic',
				'id'	=>$this->id)
			));
		}

	}
?>
