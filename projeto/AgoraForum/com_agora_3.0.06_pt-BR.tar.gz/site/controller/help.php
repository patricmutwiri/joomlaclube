<?php
    defined ('IN_AGORA') or die;

	class TaskController extends AgoraController {
		
		function __construct()
		{
			parent::__construct();
			$this->loadDefaultView();
		}

		function execute()
		{
			$this->display('help');
		}
	}
?>