<?php
defined ('IN_AGORA') or die;

class TaskController extends AgoraController
{
	function __construct()
	{
		parent::__construct();
		$this->loadDefaultView();
	}

	function _topicView()
	{
		$topic_model = & Model::getInstance('TopicModel');

		if ($this->agora_user['is_superadmin']) {
			$allowed_forums = null;
		} else {
			$allowed_forums = $this->access_model->getAllowedForums($this->agora_user['id']);
		}
		
		$per_page = intval($this->agora_user['disp_topics']) > 0 ? $this->agora_user['disp_topics'] : intval($this->agora_config['o_disp_topics_default']);
		$page_num = ceil(($topic_model->loadAllCount($allowed_forums) + 1) / $per_page);
		$this->setPagination($page_num);

		$pathway = $this->helper('pathway');
		$pathway->add(Agora::lang('All topics'),'');
		
		$topic_model->setOrder('ORDER BY last_post DESC');
		$topics = $topic_model->loadAll('',$per_page,Agora::getPage($page_num),$allowed_forums);

		// we get forum names from forumList - to not make additional queries or break models
		$forums = array();
		foreach ($this->forumList as $cat) {
			foreach ($cat['forums'] as $forum) {
				$forums[$forum['id']] = $forum['forum_name'];
			}
		}

		// don't do this in prepareTopic - later we will use helper instead of prepareTopic - it's redundant in this controller
		foreach ($topics as $id=>$topic) {
			if (!isset($forums[$topic['forum_id']])) {
				unset($topics[$id]);
			}
		}

		$topic_helper = & $this->helper('topic');
		$topics = $topic_helper->processRatings($topics);
		$topics = $topic_helper->processTopics($topics);

//		$topics = $this->_prepareTopics($topics);
		$this->view->assign('star_path',Agora::getRoot()."img/rate_stars/default_stars/");
		$this->view->assignRef('topics',$topics);
	}

	function _forumView()
	{
		$cat_id = Agora::getVar('id',null);

		$cat_list = null;

		if (is_null($cat_id)) {
			$cat_list = $this->forumList;
		} else {
			$catnav_helper = & $this->helper('catnav');
			$catnav_helper->fromCategory($cat_id);
			$current_category = $this->forumList[$cat_id]['cat_name'];

			$pathway = & $this->helper('pathway');
			$pathway->push($current_category,Agora::makeURL(array('id' => $cat_id)));
			
			$cat_list = array($cat_id => $this->forumList[$cat_id]);
		}

		if (!$this->agora_user['is_guest'] && $this->agora_user['disp_posts'] > 0) {
			$per_page = intval($this->agora_user['disp_posts']);
		} else {
			$per_page = intval($this->agora_config['o_disp_posts_default']);
		}

		// array of top-level forum ids
		$ids = array();

		// We just rebuild $this->forumList to avoid more queries
		foreach ($cat_list as $id=>$cat) {
			$cat_list[$id]['id'] = $cat['cat_id'];
			foreach ($cat['forums'] as $forum_id => $forum) {
				if ($forum['level'] > 1) {
					unset($cat_list[$id]['forums'][$forum_id]);
					continue;
				}

				if ($forum['level'] == 0) {
					$ids[] = $forum['id'];
					$parent = & $cat_list[$id]['forums'][$forum_id];
					$parent['subforums'] = array();
					continue;
				}

				if ($forum['level'] == 1 && isset($parent)) {
					$parent['subforums'][] = $forum;
					unset($cat_list[$id]['forums'][$forum_id]);
				}
			}
		}

		$forum_model = & Model::getInstance('ForumModel');

		// collect latest posts for top-level forums
		$posts = array();
		foreach ($cat_list as $cat) {
			foreach ($cat['forums'] as $forum) {
				if ($forum['last_post_id']) {
					$posts[] = $forum['last_post_id'];
				}
			}
		}

		$topic_model = & Model::getInstance('TopicModel');
		$subjects = $topic_model->loadSubjectsMess($posts);

		$topics = array();
		foreach ($subjects as $subject) {
			$topics[] = $subject['topic_id'];
		}

		$unread = $topic_model->filterRead($topics, $this->agora_user['id']);

		$read_timeout = AGORA_TIME - intval($this->agora_config['o_timeout_visit']) * 86400;

		foreach ($subjects as $subject) {
			$cat_id = $subject['cat_id'];

			$forum_id = $subject['forum_id'];

			// forum from subject may be one of subforums
			// we go to top-level forum here. A little hard to read, but should be php4 compatible (
			
			while ($this->forumList[$cat_id]['forums'][$forum_id]['parent_forum_id'] && isset($this->forumList[$cat_id]['forums'][$this->forumList[$cat_id]['forums'][$forum_id]['parent_forum_id']])) {
				$forum_id = $this->forumList[$cat_id]['forums'][$forum_id]['parent_forum_id'];
			}


			$num_pages = ceil(($subject['num_replies'] + 1) / $per_page);

			/*foreach ($cat_list as $cat) {
				if ($cat['id'] == $cat_id) {
					$category = & $cat;
					break;
				}
			}*/
			$mess_text = $subject['message'];
			
			$mess_text = preg_replace('#\[quote(.*?)\[/quote\]#si', '', $mess_text);
			$mess_text = preg_replace('|[[\/\!]*?[^\[\]]*?]|si', '', $mess_text);
			$mess_text = strip_tags($mess_text);
			
			$length = strlen($mess_text);
			
			if ($length > 90)
			{
				$mess_text = JString::substr($mess_text, 0, 90).'...';
			}
			
			$subject['message'] = $mess_text;
			
			if (!isset($cat_list[$cat_id])) continue;
			$category = & $cat_list[$cat_id];

			$forum = & $category['forums'][$forum_id];
/*			while ($forum['parent_forum_id'] && isset($category['forums'][$forum['parent_forum_id']])) {
				$forum = & $category['forums'][$forum['parent_forum_id']];
			}*/
//			$forum = & $category['forums'][$forum_id];

/*			if (count($forum['subforums']) > 0) {
				list($num_topics,$num_posts) = $forum_model->loadSubforumsCounters($forum_id);
				$forum['num_topics'] += $num_topics;
				$forum['num_posts'] += $num_posts;
			}*/

			$forum['subject'] = $subject['subject'];

			$topic_id = $subject['topic_id'];
			$forum['last_post_topic_id'] = $topic_id;
			$forum['num_pages'] = $num_pages;
			$forum['title'] = $subject['message'];


			$status = '';
			if ($this->agora_user['id'] && in_array($topic_id,$unread) && $forum['last_post'] > $read_timeout) {
				$status = 'new';
			}

            if ($subject['sticky']) $status .= 'sticky';
            if ($subject['closed']) $status .= 'closed';
            if ($subject['num_replies'] >= 19) $status .= 'hot';

			if (!$status) {
				$status = 'icon';
			}

			$forum['status'] = $status;

		}

/*		unset($category);
		
		foreach ($cat_list as $cat_id=>$category) {
			foreach ($category['forums'] as $forum_id=>$cur_forum) {
				$forum = & $cat_list[$cat_id]['forums'][$forum_id];

				if ($forum['num_topics'] > 0) continue;

				// it's possible we skipped this forum because it has no topics

				if (count($forum['subforums']) > 0) {
					list($num_topics,$num_posts) = $forum_model->loadSubforumsCounters($forum_id);
					$forum['num_topics'] += $num_topics;
					$forum['num_posts'] += $num_posts;
				}

			}
		}*/

		$this->view->assign('categories',$cat_list);
	}

	function setview()
	{
		$view = Agora::getVar('view');
		if ($view === 'topic') {
			Agora::setSessionVar('view','topic');
		} elseif ($view === 'forum') {
			Agora::setSessionVar('view','forum');
		} else {
			Agora::show404();
		}

        if (isset($_SERVER['HTTP_REFERER'])) {
			Agora::redirect($_SERVER['HTTP_REFERER']);
        } else {
        	Agora::redirect(Agora::makeURL(
				array(
					'task'	=>'index'
					))
				);
	    }
	}

	function _default()
	{
		$view = Agora::getSessionVar('view','forum');
		if ($view === 'topic') {
			$this->_topicView();
			$this->view->template = 'index_topics';
		} else {
			$this->_forumView();
			$this->view->template = 'index_forums';
		}
		if ($this->agora_user['is_superadmin']) {
			$this->view->assign('post_poll',1);
			$this->view->assign('post_topic',1);
		} else {
			$post_poll = $this->access_model->getAllowedForums($this->agora_user['id'],'post_poll');
			$post_topic = $this->access_model->getAllowedForums($this->agora_user['id'],'post_topic');
			$this->view->assign('post_poll',count($post_poll) > 0);
			$this->view->assign('post_topic',count($post_topic) > 0);
		}
	}
	
	function mark_read()
	{
		$topic_model = & Model::getInstance('TopicModel');
		$topic_model->markAllRead($this->agora_user['id'],  $this->agora_config['o_timeout_visit'] * 86400);
		Agora::redirect(Agora::getRefferer());
	}
}

?>
