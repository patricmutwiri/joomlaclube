<?php
	defined ('IN_AGORA') or die;

/*	class TaskController extends AgoraProfileController
	{
		function __construct()
		{
			parent::__construct();
			if ($this->user_id != $this->agora_user['id']) {
				Agora::redirect(Agora::makeURL(array('task'=>'profile','page'=>'personal','user_id'=>$this->user_id)));
			} else {
				Agora::redirect(Agora::makeURL(array('task'=>'profile','page'=>'personal')));
			}
		}
	}*/
	ainclude('controller|profile|personal');

?>
