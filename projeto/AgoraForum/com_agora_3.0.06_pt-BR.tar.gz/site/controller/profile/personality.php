<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraProfileController
	{
		function _default()
		{
			//Agora::prepareUser($this->user,$this->agora_config['o_ranks']);
			$user_helper = &$this->helper('user');
			$this->user = $user_helper->prepareUserAvatar($this->user);
			$this->user = $user_helper->prepareUserTitle($this->user);

			$parser = & $this->helper('parser');
			$signature_preview = $parser->parseSignature($this->user['signature']);
			$this->view->assign('signature_preview',$signature_preview);
		}

		function _save()
		{
			$form = Agora::getPostVar('form',array());

			if (isset($form['signature'])) {

				$form['signature'] = Agora::linebreaks(trim($form['signature']));

				if (strlen($form['signature']) > $this->agora_config['p_sig_length']) {
					$form['signature'] = substr($form['signature'],0,$this->agora_config['p_sig_length']);
				}

				while (substr_count($form['signature'], "\n") > $this->agora_config['p_sig_lines']-1) {
					$form['signature'] = substr($form['signature'],0,strrpos($form['signature'],"\n"));
				}
				if ($this->agora_config['p_sig_all_caps'] == '0' && strtoupper($form['signature']) == $form['signature']) {
					$form['signature'] = ucwords(strtolower($form['signature']));
				}

			} else {
				$form['signature'] = '';
			}

			if (!isset($form['use_avatar']) || $form['use_avatar'] != '1')
				$form['use_avatar'] = 0;

			$this->model->edit($this->user_id,$form);
			$this->redirect();
		}
	}
?>
