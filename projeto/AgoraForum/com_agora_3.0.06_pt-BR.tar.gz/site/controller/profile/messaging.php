<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraProfileController
	{
		function save()
		{
			$form = Agora::getPostVar('form',array());
			$this->model->edit($this->user_id,$form);
			$this->redirect();

		}
	}
?>
