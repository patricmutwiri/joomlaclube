<?php
defined ('IN_AGORA') or die;

class TaskController extends AgoraProfileController
{
    function _default()
    {

        $style = $this->agora_config['o_default_style'];

        $document = & JFactory::getDocument ();

        $my = & JFactory::getUser();

        $user_helper = &$this->helper('user');

        $this->user = $user_helper->prepareUserTitle($this->user);

        $gallery_path =  DS. 'components'.DS.'com_agora'.DS.'img'.DS.'members'.DS.$this->user['id'];

        $files = $this->getFilesystemFilesFromFolder('components'.DS.'com_agora'.DS.'img'.DS.'members'.DS.$this->user['id'], $this->toShow());

        $this->view->assign('gallery_path',$gallery_path);

        $this->view->assign('images',$files);

        $document->addScript(JURI::base () . 'components' .DS. 'com_agora' .DS. 'js' .DS. 'pikachoose-min.js');

        $document->addStyleSheet(JURI::base () . 'components' .DS. 'com_agora' .DS. 'style' .DS. $style .DS. 'js_css' .DS. 'gallery.css');

        $document->addScriptDeclaration('$j(document).ready(function (){$j("#pikame").PikaChoose({show_captions:true, slide_enabled:true, auto_play: false, thumb_width:75, thumb_height:75});});');


    }
    function toShow()
    {
        $ret = false;

        $my = & JFactory::getUser();


        if ($this->user['username']== $my->username){

            $ret = true;

        }else{

            $ret= false;

        }



        return $ret;

    }

    function getFilesystemFilesFromFolder($folder, $show=true) {
        jimport('joomla.filesystem.folder');
        jimport('joomla.filesystem.file');
        $files = array();
        if (JFolder::exists(JPATH_BASE.DS.$folder)) {
            $fileList = JFolder::files(JPATH_BASE.DS.$folder);
            if (count($fileList) > 0) {
                foreach($fileList as $file) {
                    if (!strstr( strtolower($file), 'mini')){
                        if ($show==true){
                            if ( strtolower(JFile::getExt($file)) == 'jpg' || strtolower(JFile::getExt($file)) == 'png' || strtolower(JFile::getExt($file)) =='gif') {
                                $files[] = JURI::base (false) .$folder. DS.$file;
                            }
                        }else{
                            if (!strstr(strtolower($file), 'hide')){
                                if ( strtolower(JFile::getExt($file)) == 'jpg' || strtolower(JFile::getExt($file)) == 'png' || strtolower(JFile::getExt($file)) =='gif') {
                                    $files[] = JURI::base (false) .$folder. DS.$file;
                                }
                            }
                        }
                    }
                }
            }
        }
        return $files;
    }

}
?>
