<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraProfileController
	{
	}
?>
