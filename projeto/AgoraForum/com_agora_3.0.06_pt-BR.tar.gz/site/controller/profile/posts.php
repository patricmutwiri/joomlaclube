<?php
defined ('IN_AGORA') or die;

class TaskController extends AgoraProfileController
{

    function _default()
    {

        $topics_model = & Model::getInstance('ProfilePostsModel');
        $access_model = & Model::getInstance('AccessModel');


        $allow_forum = $access_model->getAllowedForums($this->user['id']);
        // create pagination with respect to current page

        $per_page = intval($this->agora_user['disp_posts']) > 0 ? $this->agora_user['disp_posts'] : intval($this->agora_config['o_disp_posts_default']);
        $num_pages 		= ceil( $topics_model->getTopicCount($this->user['id'], $allow_forum) / $per_page);
        $this->setPagination($num_pages);
        $page 			= Agora::getPage($num_pages);


        // get posts and process then
        $posts = $topics_model->loadAll('', $per_page, $page,$this->user['id'], $allow_forum);

        $this->view->assign('topics',$posts);
    }
}
?>
