<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraController {
		
		function __construct()
		{
			parent::__construct();
			if ($this->agora_user['is_guest'] && !$this->agora_config['o_guest_userlist']) {
				Agora::showMessage('Access denied');
				Agora::redirect(Agora::getRefferer());
			}

			$this->loadDefaultView("userlist");
			$pathway_helper = & $this->helper('pathway');
			$pathway_helper->add(Agora::lang('User list'),Agora::makeUrl(array('task'=>'userlist')));
		}

		function _displayUsers(& $users)
		{
			$user_helper = & $this->helper('user');
			foreach ($users as $key=>$user) {
				$user = $user_helper->prepareUserAvatar($user);
				$user = $user_helper->prepareUserTitle($user);
				
				//for PHP4
				$users[$key] = $user;
			}

			 $this->view->smarty->assign('users',$users);

			$group_model = & Model::getInstance('GroupModel');
			$groups = $group_model->loadTree();
			
			$this->view->smarty->assign('groups',$groups); 
		}

		function search()
		{
			$form = Agora::getVar('form',array());
			$this->view->smarty->assign('form',$form);

			$username = $form['username'];
			$sort_by = $form['sort_by'];
			$sort_dir = $form['sort_dir'];
			$group = $form['show_group'];

			if ($sort_dir !== 'DESC' && $sort_dir !== 'ASC') {
				$sort_dir = 'DESC';
			}

			if ($sort_by !== 'username' && $sort_dir !== 'registered') {
				$sort_by = 'username';
			}


			$user_model = & Model::getInstance('UserModel');

			$total_users = $user_model->searchUsersCount($username,$group);
			$page_count = ceil($total_users / 50);

			$users = $user_model->searchUsers($username,$group,$sort_by,$sort_dir,50, Agora::getPage($page_count));

			$this->setPagination($page_count);

			$this->_displayUsers($users);
		}

		function _default()
		{
			$user_model = & Model::getInstance('UserModel');

			$total_users = $user_model->loadAllCount();
			$pages = ceil($total_users / 50);

			$users = $user_model->loadAll('', 50, Agora::getPage($pages));

			$this->setPagination($pages);
			$this->_displayUsers($users);
		}

		function _execute()
		{
			$this->view->display('userlist');
		}
	}
?>