<?php

	defined ('IN_AGORA') or die;

	class TaskController extends AgoraPMSController
	{
		function _default()
		{
			$id = Agora::getVar('id');

			$pm_model = & Model::getInstance('PMSModel');
			$user_model = & Model::getInstance('UserModel');

			$post = $pm_model->load($id);

			if (!$post) {
				Agora::showError('Requested message not found');
				$this->redirect('!page');
			}
			
			if ($post['status'] != 0) {
				$user = $this->agora_user['id'];
				$box = 'sent';

			} else {
				$user = $post['sender_id'];
				$box = 'inbox';

			}

			if ($post['sender_id'] != $this->agora_user['id'] && $post['owner'] != $this->agora_user['id']) {
				Agora::showError('Permission denied');
				$this->redirect('!page');
			}

			$pm_model->markRead($id);

			$user = $user_model->load($user);

			$user_helper = & $this->helper('user');
			$user = $user_helper->prepareUserAvatar($user);
			$user = $user_helper->prepareUserTitle($user);

			$parser = & $this->helper('parser');
			$post['message'] = $parser->parseMessage($post['message'],0);

			$this->view->assign('pm_count',$pm_model->getUnreadCount($this->agora_user['id']));

			$this->view->assign('box',$box);
			$this->view->assign('post',$post);
			$this->view->assign('user',$user);

			$pathway_helper = & $this->helper('pathway');
			$pathway_helper->add(Agora::lang('PMS'),Agora::makeURL(array('task'=>'pms')));
			$pathway_helper->add(Agora::lang('View message'),'');

			$this->view->template = 'pms/view';
		}

	}
?>
