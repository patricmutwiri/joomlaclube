<?php

	defined ('IN_AGORA') or die;

	class TaskController extends AgoraPMSController
	{
		function _default()
		{
			$id = Agora::getVar('id');
			$pm_model = & Model::getInstance('PMSModel');


			$post = $pm_model->load($id);

			if ($post['sender_id'] != $this->agora_user['id'] && $post['owner'] != $this->agora_user['id']) {
				Agora::showError('Permission denied');
				$this->redirect('!page');
				return;
			}
			
			$string=substr($post['subject'],0,3);
		
			if ($string != 'RE:') {
				$subject_prefix = 'RE:';
				$this->view->assign('subject_prefix',$subject_prefix);
			}

			$this->helper('pathway')->add(Agora::lang('PMS'),Agora::makeURL(array('task'=>'pms')));
			$this->helper('pathway')->add(Agora::lang('Reply'),'');

			$this->view->assign('post',$post);
			$this->view->template = 'pms/reply';
		}
	}
?>
