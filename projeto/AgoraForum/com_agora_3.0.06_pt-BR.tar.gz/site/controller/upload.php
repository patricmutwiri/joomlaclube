<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraController
	{
		function __construct()
		{
			parent::__construct();
			if (!$this->agora_user['id']) {
				Agora::showError('Access denied');
				Agora::redirect(Agora::getRefferer());
			}

			$this->loadDefaultView();
			$this->upload_model = & Model::getInstance('UploadModel');
		}

		function _default()
		{
			$uploads = $this->upload_model->loadUser($this->agora_user['id'],$this->agora_config['o_uploadile_laws']);
			$this->view->assignRef('uploads',$uploads);
			$this->view->template = 'upload';
		}

		function delete()
		{
			$id = Agora::getVar('id');
			$this->upload_model->delete($this->agora_user['id'],$id,$this->agora_config['o_uploadile_laws']);
			$this->redirect('type','!page','!action');
		}

		function add()
		{
			if (!isset($_FILES['upload']) || $_FILES['upload']['error'] != 0) return;

			$upload = $_FILES['upload'];

			$user_model = & Model::getInstance('UserModel');
			$moderator = $user_model->moderateAny($this->agora_user['id']);

			if ($moderator) {
				$maxsize = $this->agora_config['o_uploadile_maxsize_modo'];
				$limit = $this->agora_config['o_uploadile_limit_modo'];
			} else {
				$maxsize = $this->agora_config['o_uploadile_maxsize_member'];
				$limit = $this->agora_config['o_uploadile_limit_member'];
			}

			if($upload['size'] > $maxsize) {
				Agora::showError('Upload too big');
				$this->redirect('type');
			}

			if (!isset($this->agora_user['upload'])) {
				$this->agora_user['upload'] = 0;
			}

			if($upload['size']+$this->agora_user['upload'] > $limit) {
				Agora::showError('Upload too big');
				$this->redirect('type');
			}

			$upload_name = Agora::getPostVar('upload_name');

			$file_name = $this->upload_model->add($this->agora_user['id'],$upload,$upload_name,$this->agora_config['o_uploadile_laws']);

			if ($file_name === FALSE) {
				Agora::showError(Agora::lang('Upload error'));
				$this->redirect('type');
			}

			if ($this->agora_config['o_uploadile_thumb'] == '1') {
				$this->upload_model->makeThumb($this->agora_user['id'], $file_name, $this->agora_config['o_uploadile_thumb_size']);
			}

			$this->redirect('type','!page','!action');
		}
	}
?>
