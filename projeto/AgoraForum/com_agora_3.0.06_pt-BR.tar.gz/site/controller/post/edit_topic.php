<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraPostController
	{
		function _default()
		{
			$this->authenticateTopic($this->id,'edit_topic');

			$icons_model = & Model::getInstance('TopicIconsModel');
			$this->view->assign('topic_id',intval($this->id));
			$this->view->assignRef('topic_icons',$icons_model->loadAll());

			$this->view->template = 'post/edit_topic';

			$topic_model = & Model::getInstance('TopicModel');
			$topic = $topic_model->load($this->id);

			$catnav_helper = & $this->helper('catnav');
			$catnav_helper->fromForum($topic['forum_id']);

			$subject = Agora::getPostVar('subject');
			$desc = Agora::getPostVar('desc');
			$icon = Agora::getPostVar('topic_icon');

			if ($subject) $topic['subject'] = $subject;
			if ($desc) $topic['descrip_t'] = $desc;
			if ($icon) $topic['icon_topic'] = $icon;

			$this->view->assign('topic',$topic);

			$post_model = & Model::getInstance('PostModel');

			$post_id = Agora::getRequestVar('post_id');
			$post = $post_model->load($post_id);

			$message = Agora::getPostVar('req_message', '', true);
			if ($message) $post['message'] = $message;

			$this->view->assign('post_id',$post_id);
			$this->view->assign('post_body',$post['message']);
		}

		function preview()
		{
			$topic_icon = intval(Agora::getPostVar('topic_icon',0));
			$desc = Agora::getPostVar('desc','');
			$subject = Agora::getPostVar('subject','');

			$raw_message = Agora::getPostVar('req_message','', true);
			$message = $raw_message;
			$hide_smilies = Agora::getPostVar('hide_smilies',0);

			$post_id = Agora::getRequestVar('post_id');
			$topic_id = Agora::getRequestVar('id');

			$parser = $this->helper('parser');

			$message = $parser->parseMessage($raw_message, $hide_smilies);

			$signature = '';
			if ($this->agora_user['show_sig']) {
				$signature = $parser->parseSignature($this->agora_user['signature']);
			}

			$post_model = & Model::getInstance('PostModel');
			$user_model = & Model::getInstance('UserModel');
			$topic_model = & Model::getInstance('TopicModel');
			
			$post = $post_model->load($post_id);
			$post['user'] = $user_model->load($post['poster_id']);

			$user_helper = &$this->helper('user');

			$post['user'] = $user_helper->prepareUserAvatar($post['user']);
			$post['user'] = $user_helper->prepareUserTitle($post['user']);
			
//			$post['id'] = 0;
/*			$post['poster_id'] = $this->agora_user['id'];
			$post['poster'] = $this->agora_user['username'];
			$post['posted'] = time();*/

			$post['message'] = $message;
			$post['user']['signature'] = $signature;

			$topic = $topic_model->load($topic_id);
			$topic['status'] = 'new';
			// we don't know id now
			$topic['icon_topic'] = $topic_icon;
			$topic['subject'] = $subject;
			$topic['descrip_t'] = $desc;

			$this->view->assignRef('topic',$topic);

			$this->view->assignRef('post',$post);
			$this->view->assign('access',array());
			$this->view->assign('post_num','-');
			$this->view->assign('topic_id',$topic_id);
			$this->view->assign('post_id',$post_id);

			$this->view->assign('topic_icon',$topic_icon);
			$this->view->assign('raw_message',$raw_message);
			$this->view->assign('hide_smilies',$hide_smilies);

/*			$this->view->assign('merge',$merge);
			$this->view->assign('subscribe',$subscribe);*/

			$this->view->template = 'post/preview_topic';

			$this->display();
			jexit(0);
		}
		
		function _save()
		{
			if (Agora::getPostVar('preview')) {
				$this->_preview();
				return;
			}

			$this->authenticateTopic($this->id,'edit_topic');
			
			$topic_model = & Model::getInstance('TopicModel');

			$subject = Agora::getPostVar('subject','No subject');
			$desc = Agora::getPostVar('desc','');

			$message = Agora::getPostVar('req_message','',true);
//			$subscribe = Agora::getPostVar('subscribe',0);
			$hide_smilies = Agora::getPostVar('hide_smilies',0);
			$silent = Agora::getPostVar('silent',0);
			
			$topic_icon = intval(Agora::getPostVar('topic_icon',0));

			$topic_model->edit($this->id, $subject,$desc, $topic_icon, $message, $hide_smilies);

			$post_id = Agora::getRequestVar('post_id');
			$post_model = & Model::getInstance('PostModel');
			
			$post_model->edit($post_id,$message,$silent, $this->agora_user['username']);

//			$topic_model->addPost($topic_id, $this->id, $message, $this->agora_user['id'], $this->agora_user['username'], $hide_smilies);

			$this->redirect('task=topic','id='.$this->id,'!page');
		}

		function saved()
		{
			$this->_default();
		}

	}
?>
