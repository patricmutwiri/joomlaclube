<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraPostController
	{
		function _default()
		{
			$this->authenticatePost($this->id,'delete_posts');

			$post_model = & Model::getInstance('PostModel');
			$post = $post_model->load($this->id);

			$topic_model = & Model::getInstance('TopicModel');
			$forum_id = $topic_model->getForumId($post['topic_id']);

			$catnav_helper = & $this->helper('catnav');
			$catnav_helper->fromForum($forum_id);

			$this->view->assignRef('post',$post);

			$this->view->template = 'post/delete';
		}

		function _save()
		{
			$this->authenticatePost($this->id,'delete_posts');
			
			$post_model = & Model::getInstance('PostModel');
			$topic_id = $post_model->getTopicId($this->id);

			$post_model->delete($this->id);

			$topic_model = & Model::getInstance('TopicModel');

			if ($topic_model->getPostCount($topic_id) == 0) {
				$forum_id = $topic_model->getForumId($topic_id);
				$topic_model->delete($topic_id);

				$this->redirect('task=forum','id='.$forum_id,'!page','!action');

			} else {
				Agora::redirect(Agora::makeURL(
					array(
					'task'	=>'topic',
					'id'	=>$topic_id)
				));
			}
			return;
		}
	}
?>
