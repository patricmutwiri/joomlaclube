<?php
defined ('IN_AGORA') or die;

class TaskController extends AgoraPostController {
	function _default() {
		$topic = $this->topic_model->load($this->id);
		$this->authenticate($topic['forum_id'],'post_reply');

		$forum_model = & Model::getInstance('ForumModel');
		$forum = $forum_model->load($topic['forum_id']);

		if (!$topic) {
			Agora::show404();
			return;
		}

		$catnav_helper = & $this->helper('catnav');
		$catnav_helper->fromForum($topic['forum_id']);

		$parser = & $this->helper('parser');
		$posts = $this->topic_model->loadPosts($this->id,10,1,true,$topic['num_replies'] + 1);
		$post_helper = &$this->helper('post');
		$posts = $post_helper->processPosts($posts, $parser);

		$access_helper = & $this->helper('access');
		$access = $access_helper->getForumAccess($topic['forum_id']);
		
		$this->view->assign('access',$access);
		$this->view->assign('posts',$posts);
		$this->view->assign('forum',$forum);

		$this->view->template = 'post/reply';
		$this->view->assign('topic_id',intval($this->id));
	}

	function preview() {
		$this->_preview();
		$this->display();
		jexit(0);
	}

	function _preview() {
		$topic = $this->topic_model->load($this->id);
		$this->authenticate($topic['forum_id'],'post_reply');

		$forum_model = & Model::getInstance('ForumModel');
		$forum = $forum_model->load($topic['forum_id']);

/*		if (!$this->agora_user['is_superadmin'] &&
			$this->access_model->authenticate($this->agora_user['id'],$forum['id'],'use_captcha')) {
			$captcha = Agora::getPostVar('captcha');
			$c_key = Agora::getSessionVar('captcha');

			if (trim($captcha) !== trim($c_key)) {
				Agora::showMessage('Bad captcha');
				Agora::redirect(Agora::getRefferer());
			}
			$post['captcha'] = $captcha;
		}*/

		$raw_message = Agora::getPostVar('req_message','', true);
		$message = $raw_message;
		$hide_smilies = Agora::getPostVar('hide_smilies',0);

		$parser = & $this->helper('parser');

		$message = $parser->parseMessage($message,$hide_smilies);

		$signature = '';
		if ($this->agora_user['show_sig']) {
			$signature = $parser->parseSignature($this->agora_user['signature']);
		}

		$post = array();
		$post['user'] = $this->agora_user;
		//Agora::prepareUser($post['user'],$this->agora_config['o_ranks']);
		$user_helper = & $this->helper('user');
		$post['user'] = $user_helper->prepareUserAvatar($post['user']);
		$post['user'] = $user_helper->prepareUserTitle($post['user']);

		$post['id'] = 1;
		$post['poster_id'] = $this->agora_user['id'];
		$post['poster'] = $this->agora_user['username'];
		$post['posted'] = time();

		$post['message'] = & $message;
		$post['user']['signature'] = & $signature;

		$this->view->assign('post',$post);
		$this->view->assign('access',array());
		$this->view->assign('post_num','-');
		$this->view->assign('topic_id',$this->id);

		$this->view->assign('raw_message',$raw_message);
		$this->view->assign('hide_smilies',$hide_smilies);

/*			$this->view->assign('merge',$merge);
			$this->view->assign('subscribe',$subscribe);*/

		$this->view->template = 'post/preview';
	}

	function _save() {
		if (Agora::getPostVar('preview')) {
			$this->_preview();
			return;
		}

		$topic = $this->topic_model->load($this->id);
		$this->authenticate($topic['forum_id'],'post_reply');

		$forum_model = & Model::getInstance('ForumModel');
		$forum = $forum_model->load($topic['forum_id']);

		if (!$this->agora_user['is_superadmin'] &&
			$this->access_model->authenticate($this->agora_user['id'],$forum['id'],'use_captcha')) {
			$captcha = Agora::getPostVar('captcha');
			$c_key = Agora::getSessionVar('captcha');

			if (trim($captcha) !== trim($c_key)) {
				Agora::showMessage('Bad captcha');
				Agora::redirect(Agora::getRefferer());
			}
		}

		$message = Agora::getPostVar('req_message','', true);
		$merge = intval(Agora::getPostVar('merge',0));
		$subscribe = Agora::getPostVar('subscribe',0);
		$hide_smilies = Agora::getPostVar('hide_smilies',0);

		$post_id = $this->topic_model->addPost($this->id,$topic['forum_id'],$message,$this->agora_user['id'], $this->agora_user['username'],$hide_smilies);
		$api_AUP = JPATH_SITE.DS.'components'.DS.'com_alphauserpoints'.DS.'helper.php';
		
		if (file_exists($api_AUP))	{
			require_once ($api_AUP);
			AlphaUserPointsHelper::newpoints( 'plgaup_reply_agora', '', '', Agora::lang('AUP_REPLY') );
		}

		// send mail
		$subscription_helper = &$this->helper('subscription');
		$subscription_helper->newPost($post_id,$topic['forum_id']);
		// Add subscription?
		if ( $subscribe ) {
			$subscription_model = & Model::getInstance('SubscriptionModel');
			$user_id = $this->agora_user['id'];

			if (!$subscription_model->isSubscribed($user_id,$topic['id'])) {
				$subscription_model->add(array('user_id'=>$user_id,'topic_id'=>$topic['id']));
				Agora::showMessage('You are now subscribed on topic '.AString::escape($topic['subject']));
			} else {
				Agora::showMessage('You are already subscribed on topic '.AString::escape($topic['subject']));
			}

		}

		$url = array('task'	=>'topic', 'id'	=>$this->id);

		if (!$this->agora_user['reverse_posts']) {
			$posts = $topic['num_replies'];

			$per_page = intval($this->agora_user['disp_posts']) > 0 ? $this->agora_user['disp_posts'] : intval($this->agora_config['o_disp_posts_default']);
			$num_pages = ceil(($posts+2) / $per_page);

			if ($num_pages > 1) {
				$url['p'] = $num_pages;
			}
		}

		Agora::redirect(Agora::makeURL($url). "#p$post_id");
	}

	function quote() {
		$post_model = & Model::getInstance('PostModel');
		$post = $post_model->load($this->id);
		$this->id = $post['topic_id'];

		$this->view->assign('post_body','[quote='.$post['poster'].']'.$post['message'].'[/quote]');
		$this->_default();
	}
}
?>
