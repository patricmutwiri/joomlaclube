<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraPostController
	{
		function _default()
		{
			$this->authenticateTopic($this->id,'delete_topics');

			$topic_model = & Model::getInstance('TopicModel');
			$forum_id = $topic_model->getForumId($this->id);

			$catnav_helper = & $this->helper('catnav');
			$catnav_helper->fromForum($forum_id);
		
			$this->view->template = 'post/delete_topic';
		}

		function _save()
		{
			$this->authenticateTopic($this->id,'delete_topics');
			
			$topic_model = & Model::getInstance('TopicModel');
			$forum_id = $topic_model->getForumId($this->id);
			$topic_model->delete($this->id);
			$this->redirect('task=forum','id='.$forum_id,'!page','!action');
		}
	}
?>
