<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraPostController
	{
		function _default()
		{
			$this->authenticatePost($this->id,'edit_posts');

			$post_model = & Model::getInstance('PostModel');
			$post = $post_model->load($this->id);

			// member cannot edit other posts even when he 'edit_posts' permission
			if (!$this->agora_user['is_superadmin'] && $post['poster_id'] != $this->agora_user['id']) {
				Agora::showMessage('Access denied');
				Agora::redirect(Agora::getRefferer());
			}

			$topic_model = & Model::getInstance('TopicModel');
			$forum_id = $topic_model->getForumId($post['topic_id']);
			
			$catnav_helper = & $this->helper('catnav');
			$catnav_helper->fromForum($forum_id);

			$this->view->assign('post_id',$post['id']);
			$this->view->assign('post_body',$post['message']);
			$this->view->template = 'post/edit';
		}

		function unsaved()
		{
			$this->view->assign('topic_id',Agora::getPostVar('id'));
			$this->view->assign('post_body',Agora::getPostVar('req_message','',true));
			$this->view->assign('edit_unsaved',1);
			$this->view->template = 'post/edit';
		}

		function preview()
		{
			$raw_message = Agora::getPostVar('req_message','',true);
			$message = $raw_message;
			$hide_smilies = Agora::getPostVar('hide_smilies',0);
			$post_id = Agora::getPostVar('post_id');
			$this->id = $post_id;

			$parser = & $this->helper('parser');
			$message = $parser->parseMessage($message, $hide_smilies);

			$signature = '';
			if ($this->agora_user['show_sig']) {
				$signature = $parser->parseSignature($this->agora_user['signature']);
			}

			if ($post_id) {
				$post_model = &Model::getInstance('PostModel');
				$post = $post_model->load($post_id);

				$user_model = &Model::getInstance('UserModel');
				$post['user'] = $user_model->load($post['poster_id']);
			} else {
				$post = array();
				$post['user'] = $this->agora_user;
				$post['id'] = 0;
				
				$post['poster_id'] = $this->agora_user['id'];
				$post['poster'] = $this->agora_user['username'];
				$post['posted'] = time();
			}

			$user_helper = &$this->helper('user');

			$post['user'] = $user_helper->prepareUserAvatar($post['user']);
			$post['user'] = $user_helper->prepareUserTitle($post['user']);
			
			if ($this->id) {
				$this->authenticatePost($this->id,'edit_posts');
				$this->view->assign('post_id',$this->id);
			}

			$post['message'] = $message;
			$post['user']['signature'] = $signature;

			$this->view->assignRef('post',$post);
			$this->view->assign('access',array());
			$this->view->assign('post_num','-');
			$this->view->assign('topic_id',$this->id);

			$this->view->assign('raw_message',$raw_message);
			$this->view->assign('hide_smilies',$hide_smilies);

/*			$this->view->assign('merge',$merge);
			$this->view->assign('subscribe',$subscribe);*/

			$this->view->template = 'post/preview';
			
			$this->display();
			jexit(0);
		}

		function saved()
		{
			$this->_default();
		}

		function _save()
		{
			$this->authenticatePost($this->id,'edit_posts');
			if ($this->agora_user['is_guest']) {
				$captcha = Agora::getPostVar('captcha');
				$c_key = Agora::getSessionVar('captcha');

				if (trim($captcha) !== trim($c_key)) {
					Agora::showMessage('Bad captcha');
					Agora::redirect(Agora::getRefferer());
				}
			}

			$post_model = & Model::getInstance('PostModel');
			$post = $post_model->load($this->id);

			if (!$post) {
				Agora::show404();
				Agora::redirect(Agora::makeURL(''));
			}

			if (!$this->agora_user['is_superadmin'] && $post['poster_id'] != $this->agora_user['id']) {
				Agora::showMessage('Access denied');
				Agora::redirect(Agora::getRefferer());
			}
			
			$message = Agora::getPostVar('req_message','', true);
			
			$silent = Agora::getPostVar('silent','0');
			$post_model->edit($post['id'],$message, $silent, $this->agora_user['username']);
			
			$topic_model = & Model::getInstance('TopicModel');
			$topic = $topic_model->load($post['topic_id']);
			$posts = $topic['num_replies'];

			$per_page = intval($this->agora_user['disp_posts']) > 0 ? $this->agora_user['disp_posts'] : intval($this->agora_config['o_disp_posts_default']);
			$num_pages = ceil(($posts+1) / $per_page);

			$url = array('task'	=>'topic', 'id'	=> $post['topic_id']);
			if ($num_pages > 1) {
				$url['p'] = $num_pages;
			}

			Agora::redirect(Agora::makeURL($url). '#p'.$this->id);

		}
		
	}
?>
