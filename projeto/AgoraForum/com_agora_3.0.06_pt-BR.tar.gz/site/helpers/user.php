<?php

class AUserHelper {

	function checkSize($img_size)
	{
		switch (intval($this->agora_config['o_avatars_ratio']) ) {
			case '3':  // exact
				$height 	= " height=\"". intval($this->agora_config['o_avatars_dheight']) ."\"";
				$width 	= " width=\"". intval($this->agora_config['o_avatars_dwidth']) ."\"";
				break;
			case '2': // both
				$width 	= intval($this->agora_config['o_avatars_dwidth']);
				$ratio 	= $width / $img_size[0];
				$height	= intval($img_size[1] * $ratio);

				if ($height > intval($this->agora_config['o_avatars_dheight'])) {
					$ratio	= intval($this->agora_config['o_avatars_dheight']) / $height;
					$height 	= intval($this->agora_config['o_avatars_dheight']);
					$width	= intval($width * $ratio);
				}
				$width 	= " width=\"". $width ."\"";
				$height 	= " height=\"". $height ."\"";
				break;

			case '1':  // height
				$height 	= intval($this->agora_config['o_avatars_dheight']);
				$ratio 	= $height / $img_size[1];
				$width 	= " width=\"". intval($img_size[0] * $ratio)."\"";
				$height 	= " height=\"". $height ."\"";
				break;

			case '0':
			default :
				$width 	= intval($this->agora_config['o_avatars_dwidth']);
				$ratio 	= $width / $img_size[0];
				$height 	= " height=\"". intval($img_size[1] * $ratio)."\"";
				$width 	= " width=\"". $width ."\"";
				break;
		}
		return $width.$height;
	}

	function prepareUserAvatar($user)  // prepares users Avatar for display
	{
		if (intval($this->agora_config['o_community_builder'])) {

			$cb_model = &Model::getInstance('CbModel');

			$cb_avatar = $cb_model->getCbAvatar($user['jos_id']);
			if ($cb_avatar) {

				$cb_avatarSz = JPATH_BASE . DS . 'images'. DS . 'comprofiler'. DS. $cb_avatar;

				if ($img_size = @getimagesize($cb_avatarSz))
					$user['avatar_size'] = $img_size[3];

				$cb_avatar = JURI::root(). 'images/comprofiler/'. $cb_avatar .'"'.$this->checkSize($img_size);

			}
			else {
				$cb_avatar =Agora::getRoot().'img/pre_avatars/noavatar.jpg';
			}

			$user['avatar'] = $cb_avatar;

		}
		else if (intval($this->agora_config['o_jomsocial'])) {

				$Jomsocial_model = &Model::getInstance('JomsocialModel');

				$Jomsocial_avatar = $Jomsocial_model->getJomsocialAvatar($user['jos_id']);
				if ($Jomsocial_avatar) {

					$Jomsocial_avatarSz = JPATH_BASE . DS . $Jomsocial_avatar;

					if ($img_size = @getimagesize($Jomsocial_avatarSz))
						$user['avatar_size'] = $img_size[3];

					$Jomsocial_avatar = JURI::root(). $Jomsocial_avatar.'"'.$this->checkSize($img_size);

				}
				else {
					$Jomsocial_avatar =Agora::getRoot().'img/pre_avatars/noavatar.jpg';
				}

				$user['avatar'] = $Jomsocial_avatar;

			}
			else if (intval($this->agora_config['o_joomunity'])) {

					$joomunity_model = &Model::getInstance('JoomunityModel');
					$joomunity_avatar = $joomunity_model->getJoomunityAvatar($user['jos_id']);
					if ($joomunity_avatar) {
					//components/com_joomunity/files/avatars/
						$joomunity_avatarSz = JPATH_BASE . DS . 'components'. DS . 'com_joomunity'. DS. 'files'  . DS. 'avatars' . DS. $joomunity_avatar;

						if ($img_size = @getimagesize($joomunity_avatarSz))
							$user['avatar_size'] = $img_size[3];

						$joomunity_avatar = JURI::root(). 'components/com_joomunity/files/avatars/'. $joomunity_avatar.'"'.$this->checkSize($img_size);

					}
					else {
						$joomunity_avatar =Agora::getRoot().'img/pre_avatars/noavatar.jpg';
					}

					$user['avatar'] = $joomunity_avatar;

				}
				else {
					$a_path = JPATH_BASE . DS . $this->agora_config['o_avatars_dir'] .DS. $user['id'];

					if ($img_size = @getimagesize($a_path.'.gif'))
					//$avatar = Agora::getRoot().'img/pre_avatars/'.$user['id'].'.gif';
						$avatar = JURI::root(). $this->agora_config['o_avatars_dir'] .'/'.$user['id'].'.gif';
					else if ($img_size = @getimagesize($a_path.'.jpg'))
						//$avatar = Agora::getRoot().'img/pre_avatars/'.$user['id'].'.jpg';
							$avatar = JURI::root(). $this->agora_config['o_avatars_dir'] .'/'.$user['id'].'.jpg';
						else if ($img_size = @getimagesize($a_path.'.png'))
							//$avatar = Agora::getRoot().'img/pre_avatars/'.$user['id'].'.png';
								$avatar = JURI::root(). $this->agora_config['o_avatars_dir'] .'/'.$user['id'].'.png';

					if (isset($avatar)) {
						$user['avatar'] = $avatar;
						$user['avatar_size'] = $img_size[3];
					} else {
						$user['avatar'] =Agora::getRoot().'img/pre_avatars/noavatar.jpg';
						$user['avatar_size'] = '';
					}
				}
		return $user;
	}

	function prepareUserTitle($user)  // prepars user Title and Ranks
	{
		static $ranks = null;
		$use_ranks = intval($this->agora_config['o_ranks']);

		if ($use_ranks) {
			if (is_null($ranks)) {
				$ranks_model = & Model::getInstance('RanksModel');
				$ranks = $ranks_model->loadAll();
			}
		} else {
			$ranks = array();
		}

		$user['rank_image'] = '';

		if (!isset($user['id'])) {
			$user['id'] = 0;
		}

		if ($user['id'] == 0) {
			$user['title'] = Agora::lang('Guest');
			return $user;
		}

		if ($user['title'] != '')
			$user_title = Agora::escape($user['title']);
		elseif (isset($user['banned']) && $user['banned'])
		// If the user is banned
			$user_title = Agora::lang('Banned');
		elseif (isset($user['is_guest']) && $user['is_guest'])
		// If the user is a guest
			$user_title = Agora::lang('Guest');
		else
			$user_title = '';

		$user['title'] = $user_title;
		// Are there any ranks?

		if ($use_ranks) {
			foreach ($ranks as $rank) {
				if (intval($user['num_posts']) >= intval($rank['min_posts'])) {
					$user['rank'] = Agora::escape($rank['rank']);
					if ($rank['image']) {
						$user['rank_image'] = $rank['image'];
					}
				}
			}
			if (!isset($user['rank'])) {
				$user['rank'] = '';
			}

			if (!isset($user['rank_image'])) {
				$user['rank_image'] = '';
			}
		}

		return $user;
	}

	function prepareUserUrl($user)  // Check and prepare url
	{
		if ($user['url'] && !stristr($user['url'],'http://')) {
			$user['url'] = "http://" . $user['url'];
		}

		return $user;
	}


}


?>
