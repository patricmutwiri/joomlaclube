<?php
class APostHelper {
	function processPosts($posts, & $parser)
	{
		$signature_cache = array();

		$user_helper = & $this->controller->helper('user');

		$user_cache = array();
		
		foreach ($posts as $key=>$post) {
			$posts[$key]['message'] = $parser->parseMessage($post['message'], $post['hide_smilies']);

			if ($post['user']['show_sig']) {
				if (!isset($signature_cache[$post['user']['id']])) {
					$signature_cache[$post['user']['id']] = $parser->parseSignature($post['user']['signature']);
				}
				$posts[$key]['user']['signature'] = $signature_cache[$post['user']['id']];
			}
			// Agora::prepareUser($post['user'],$this->agora_config['o_ranks']);

			// The following is duplicated in helpers\user.php
			// Is this good pracice?

			//   this was ugly practice (Evgeny)
			$user_id = $post['user']['id'];
			if (!isset($user_cache[$user_id])) {
				$user_cache[$user_id] = $user_helper->prepareUserAvatar($posts[$key]['user']);
				$user_cache[$user_id] = $user_helper->prepareUserTitle($user_cache[$user_id]);
				$user_cache[$user_id] = $user_helper->prepareUserUrl($user_cache[$user_id]);
			}

			$posts[$key]['user'] = $user_cache[$user_id];

		}
		return $posts;
	}
}
?>
