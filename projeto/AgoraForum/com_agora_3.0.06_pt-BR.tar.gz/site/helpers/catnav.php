<?php
class ACatnavHelper
{
	function fromForum($forum_id)
	{
		foreach ($this->controller->forumList as $cat) {
			if (isset($cat['forums'][$forum_id])) {
				$current_category = $cat['cat_name'];
				$current_category_id = $cat['cat_id'];
				$this->view->assign('current_category',$current_category);
				$this->view->assign('current_category_id',$current_category_id);
				break;
			}
		}
	}

	function fromCategory($category_id)
	{
		$current_category = $this->controller->forumList[$category_id]['cat_name'];
		$current_category_id = $category_id;
		$this->view->assign('current_category',$current_category);
		$this->view->assign('current_category_id',$current_category_id);
	}

	
	function assign(& $view)
	{
		$this->view = $view;
	}
}
?>
