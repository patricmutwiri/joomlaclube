<?php

class ASubscriptionHelper
{
    function newPost($post_id, $forum_id)
    {

        $config =& JFactory::getConfig();
        $parser = & $this->helper('parser');
        $eprocess = & $this->helper('emailprocessor');
        $parser->enable_img = 'True';

        $post_model = &Model::getInstance('PostModel');
        $post = $post_model->load($post_id);
        $topic_id = $post['topic_id'];

        $s_model = &Model::getInstance('SubscriptionModel');
        $subscribers = $s_model->loadSubscribers($topic_id, $forum_id);

        $topic_model = &Model::getInstance('TopicModel');
        $topic = $topic_model->load($topic_id);

/*
$username - name of user posted message
$subject - topic subject
$message - posted message
$url - post url
$unsubscribe - unsubscribe url
*/
        $num_posts = $topic['num_replies'] + 1;


        //		Agora::redirect(Agora::makeURL($url). "#p$post_id");

        //		Agora::showMessage('User Name='.$post['poster']);
        //$this->view->assign('username',$post['poster']);
        //$this->view->assign('subject',$topic['subject']);
        //$this->view->assign('message',$post['message']);

        //		$u_url = Agora::makeURL(array('task'=>'topic','action'=>'unsubscribe','id'=>$topic_id));
        //		$this->view->assign('unsubscribe',$u_url);



        foreach ($subscribers as $user) {


            if ($post['poster_id']!= $user['id']){

                $per_page = intval($user['disp_posts']) > 0 ? $user['disp_posts'] :  $this->agora_config['o_disp_posts_default'];
                $num_pages = ceil($num_posts / $per_page);
                $page = $num_pages;
                $url = array('task'	=>'topic', 'id'	=>$topic_id);

                if ($num_pages > 1) {
                    $url['p'] = $num_pages;
                }

                //$u_url = Agora::makeURL(array('task'=>'profile','page'=>'subscriptions','id'=>$user['id']),false);
                //$this->view->assign('unsubscribe',$u_url);

                //$this->view->assign('url',Agora::makeURL($url,false).'#p'.$post_id);

                //				$body = $this->view->fetchTemplate('email'.DS.Agora::getCurrentLanguage().DS.'topic_subscription.tpl');

                $post['message'] = $parser->bbcode($parser->links($parser->smilies($post['message'])));

                $body = $this->processBody($eprocess, $this->agora_config['o_subscr_messg'], $user['id'], $user['username'], $user['email'], $post['poster'], $config->getValue( 'config.sitename' ), JURI::root(), $topic['subject'], $post['message'], $forum_id, $topic_id, $post_id, $page);
                $emailSubject = $this->processBody($eprocess, $this->agora_config['o_subscr_subject'], $user['id'], $user['username'], $user['email'], $post['poster'], $config->getValue( 'config.sitename' ), JURI::root(), $topic['subject'], $post['message'], $forum_id, $topic_id, $post_id, $page);




                //= $this->view->fetchTemplate('email'.DS.'en-GB'.DS.'topic_subscription.tpl');

                $mail = JFactory::getMailer();
                $mail->addRecipient( $user['email']);
                //				$mail->setSender( array( $email, $name ) );
                //$mail->setSubject( 'Agora forum: '. Agora::lang('new post in topic').' '. $topic['subject'] );
                $mail->setSubject($emailSubject);
                $mail->setBody( $body );

                $mail->AltBody = $eprocess->getPlainData();
                $mail->IsHTML(true);
                $mail->Send();
            }
        }
    }
    function processBody($eprocess, $body, $userid, $username, $useremail, $poster,  $sitename, $siteurl, $title, $message, $forum, $topic, $post, $postpage){

        $eprocess = & $this->helper('emailprocessor');

        $eprocess->setData($body);

        $eprocess->setUserId($userid);

        $eprocess->setUserName($username);

        $eprocess->setEmail($useremail);

        $eprocess->setSiteName($sitename);

        $eprocess->setSiteURL($siteurl);

        $eprocess->setItemId(JRequest::getVar('Itemid'));

        $eprocess->setTitle($title);

        $eprocess->setMessage($message);

        $eprocess->setForumId($forum);

        $eprocess->setTopicId($topic);

        $eprocess->setPostId($post);

        $eprocess->setPoster($poster);

        $eprocess->setPostPage($postpage);

        return $eprocess->Process();

    }
    function & helper($name)
    {
        static $loaded;
        if (!isset($loaded[$name])) {
            ainclude('helpers|'.$name);
            $classname = 'A'.ucfirst($name).'Helper';
            $helper = new $classname;
            $loaded[$name] = & $helper;

            $helper->agora_config = $this->agora_config;
            $helper->agora_user = $this->agora_user;
            $helper->controller = $this;
            if (method_exists($helper,'assign'))
            $helper->assign($this->view);
        }

        return $loaded[$name];
    }
    function assign(& $view)
    {
        $this->view = & $view;
    }
}

?>
