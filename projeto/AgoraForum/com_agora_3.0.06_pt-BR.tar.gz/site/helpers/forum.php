<?php

// helper to prepare forums in index view and subforums in forum view

class AForumHelper
{
	function processForums($forums)
	{
		$forum_model = & Model::getInstance('ForumModel');
//		$subjects = $forum_model->loadSubjectsMess(array_keys($forums));

		// process new topics in forums
		$posts = array();
		$plain_forums = array();
		foreach ($forums as $forum_id => $forum) {
			if ($forum['last_post_id']) {
				$posts[] = $forum['last_post_id'];
			}
			$plain_forums[$forum['id']] = & $forums[$forum_id];

			foreach ($forum['subforums'] as $subforum_id => $subforum) {
				if ($subforum['last_post_id']) {
					$posts[] = $subforum['last_post_id'];
				}
				$plain_forums[$subforum['id']] = & $forums[$forum_id]['subforums'][$subforum_id];
			}
		}

		$topic_model = & Model::getInstance('TopicModel');
		$subjects = $topic_model->loadSubjectsMess($posts);

		$topics = array();
		foreach ($subjects as $subject) {
			$topics[] = $subject['topic_id'];
		}

		$unread = $topic_model->filterRead($topics, $this->agora_user['id']);

		$read_timeout = AGORA_TIME - intval($this->agora_config['o_timeout_visit']) * 86400;

		if (!$this->agora_user['is_guest'] && $this->agora_user['disp_posts'] > 0) {
			$per_page = intval($this->agora_user['disp_posts']);
		} else {
			$per_page = intval($this->agora_config['o_disp_posts_default']);
		}

		$f_list = & $this->controller->forumList;

		foreach ($subjects as $subject) {
			$forum_id = $subject['forum_id'];
			$cat_id = $subject['cat_id'];

/*			$forum = & $plain_forums[$forum_id];
			while ($forum['parent_forum_id'] && isset($plain_forums[$forum['parent_forum_id']])) {
				$forum = & $plain_forums[$forum['parent_forum_id']];
			}*/
			while ($f_list[$cat_id]['forums'][$forum_id]['parent_forum_id'] && isset($f_list[$cat_id]['forums'][$f_list[$cat_id]['forums'][$forum_id]['parent_forum_id']])) {
				if (isset($forums[$forum_id])) break;
				$forum_id = $f_list[$cat_id]['forums'][$forum_id]['parent_forum_id'];
			}
			$forum = & $forums[$forum_id];

			$num_pages = ceil(($subject['num_replies'] + 1) / $per_page);

/*			if (count($forum['subforums']) > 0) {
				list($num_topics,$num_posts) = $forum_model->loadSubforumsCounters($forum_id);
				$forum['num_topics'] += $num_topics;
				$forum['num_posts'] += $num_posts;
			}*/

			$topic_id = $subject['topic_id'];
			$forum['subject'] = $subject['subject'];
			$forum['last_post_topic_id'] = $topic_id;
			$forum['num_pages'] = $num_pages;

			$status = '';
			if (in_array($topic_id,$unread) && $forum['last_post'] > $read_timeout) {
				$status = 'new';
			}

            if ($subject['sticky']) $status .= 'sticky';
            if ($subject['closed']) $status .= 'closed';
            if ($subject['num_replies'] >= 19) $status .= 'hot';

			if (!$status) {
				$status = 'icon';
			}

			$forum['status'] = $status;

			// to remove reference
		}

/*		foreach ($forums as $forum_id=>$cur_forum) {
			$forum = & $forums[$forum_id];

			if ($forum['num_topics'] > 0) continue;

			// it's possible we skipped this forum because it has no topics

			if (count($forum['subforums']) > 0) {
				list($num_topics,$num_posts) = $forum_model->loadSubforumsCounters($forum_id);
				$forum['num_topics'] += $num_topics;
				$forum['num_posts'] += $num_posts;
			}

		}*/


		return $forums;

	}
}

?>