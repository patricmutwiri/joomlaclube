<?php

class APathwayHelper
{
	function APathwayHelper()
	{
		$this->__construct();
	}

	function __construct()
	{
		$this->breadcrumbs = array();
		
		$app = & JFactory::getApplication();
		$this->j_pathway	= &$app->getPathway();
		$this->j_path = & $this->j_pathway->_pathway;

		$this->j_items = array();
		// N.B. - not a reference here - we need COPY
		$this->j_initialpath = $this->j_pathway->_pathway;
	}

	function push($caption, $url, $type='link')
	{
		array_unshift($this->breadcrumbs,array('caption' => $caption,'url' => $url, 'type'=>$type));
		array_unshift($this->j_items,$this->j_pathway->_makeItem($caption,$url));
		$this->j_path = array_merge($this->j_initialpath,$this->j_items);
		$this->j_pathway->_count ++;
	}

	function add($caption, $url, $type='link')
	{
		$this->breadcrumbs[] = array('caption' => $caption,'url' => $url, 'type'=>$type);
		$this->j_pathway->addItem($caption,$url);
	}

	function assign(& $view)
	{
		$view->assignRef('breadcrumbs',$this->breadcrumbs);
	}
}

?>
