<?php

class AParserHelper
{
    function handle_img_tag($url, $width, $height)
    {

        $url2 = str_replace('mini_','',$url);
        if (!$this->enable_img) {
            $target = ($this->agora_config['o_new_window_link'] == 1) ? ' target="_blank"' : '';
            $img_tag = "<a href=\"$url\"$target >&lt;".Agora::lang('Image link')."&gt;</a>";
        } else {
            if ($width != '' || $height != '') {
                $size = " $width $height";
            } else {
                $size = '';
            }
            $img_tag = "<a href=\"$url2\" rel=\"lightbox\"><img$size class=\"ag_postimage\" src=\"$url\" alt=\"".htmlspecialchars($url)."\" height=\"100\"/></a>";
        }
        return $img_tag;
    }

    function handle_url_tag($url, $link = '')
    {
        $full_url = str_replace(array(' ', '\'', '`', '"'), array('%20', '', '', ''), $url);
        if (strpos($url, 'www.') === 0)			// If it starts with www, we add http://
        $full_url = 'http://'.$full_url;
        else if (strpos($url, 'ftp.') === 0)	// Else if it starts with ftp, we add ftp://
        $full_url = 'ftp://'.$full_url;
        else if (!preg_match('#^([a-z0-9]{3,6})://#', $url, $bah)) 	// Else if it doesn't start with abcdef://, we add http://
        $full_url = 'http://'.$full_url;

        // Ok, not very pretty :-)
        $link = ($link == '' || $link == $url) ? ((strlen($url) > 55) ? substr($url, 0 , 39).' &hellip; '.substr($url, -10) : $url) : stripslashes($link);

        // This is the original to follow links Edited by Hazzaa
        $target = ($this->agora_config['o_new_window_link'] == 1) ? ' target="_blank"' : '';
        //return '<a href="'.$full_url.'"'.$target.'>'.$link.'</a>';
        // Hide Links From Guests 1.0
        return "<a href=\"$full_url\"$target >$link</a>";
    }

	function censor($text)
	{
		static $search_for, $replace_with;
		// If not already built in a previous call, build an array of censor words and their replacement text
		if (!isset($search_for)) {
			$censor_model = & Model::getInstance('CensoringModel');
			$words = $censor_model->loadAll();

			$search_for = array();
			$replace_with = array();
			foreach ($words as $pair) {
				$replace_with[] = $pair['replace_with'];
				$search_for[] = '/\b('.str_replace('\*', '\w*?', preg_quote($pair['search_for'], '/')).')\b/i';
			}
		}
		if (!empty($search_for))
			$text = substr(preg_replace($search_for, $replace_with, ' '.$text.' '), 1, -1);
		return $text;

	}

    function parseMessage($text, $hide_smilies)
    {
        $text = AString::escape($text);

		if ($this->agora_config['o_censoring'])
			$text = $this->censor($text);

		$show_smilies = $this->agora_config['o_smilies'] && $this->agora_user['show_smilies'] && $hide_smilies == '0';

        if ($this->agora_config['p_message_bbcode'] == '1' && strpos($text, '[') !== false && strpos($text, ']') !== false)
        {
            $this->enable_img = intval($this->agora_config['p_message_img_tag']) && intval($this->agora_user['show_img']);
            $text = $this->bbcode($text, $show_smilies);
        } else {
	        if ($this->agora_config['o_make_links']) {
		        $text = $this->links($text);
			}

			if ($show_smilies) {
	            $text = $this->smilies($text);
	        }
		}

        return $this->cleanup($text);
    }

    function parseSignature($text)
    {
        $text = AString::escape($text);

		if ($this->agora_config['o_censoring'])
			$text = $this->censor($text);

		$show_smilies = $this->agora_config['o_smilies_sig'] && $this->agora_user['show_smilies'];

        if ($this->agora_config['p_sig_bbcode'] == '1' && strpos($text, '[') !== false && strpos($text, ']') !== false) {
            $this->enable_img = intval($this->agora_config['p_sig_img_tag']) && intval($this->agora_user['show_img_sig']);
            $text = $this->bbcode($text, $show_smilies);
        } else {
			if ($this->agora_config['o_make_links']) {
			    $text = $this->links($text);
		    }

	        if ($show_smilies) {
		        $text = $this->smilies($text);
	        }
		}

        return $this->cleanup($text);
    }

    function smilies($text)
    {
        static $smiley_text, $smiley_img;

        if (!isset($smiley_text)) {
            $model = & Model::getInstance('SmiliesModel');
            $smilies = $model->loadAll();

            $smiley_text = array();
            $smiley_img = array();

            foreach ($smilies as $db_smilies)
            {
                $smiley_text_array = array($db_smilies['text']);
                $smiley_text = array_merge($smiley_text, $smiley_text_array);

                $smiley_img_array = array($db_smilies['image']);
                $smiley_img = array_merge($smiley_img, $smiley_img_array);
            }

        }

        $text = ' '.$text.' ';

        $num_smilies = count($smiley_text);
        for ($i = 0; $i < $num_smilies; ++$i)
        $text = preg_replace("#(?<=.\W|\W.|^\W)".preg_quote($smiley_text[$i], '#')."(?=.\W|\W.|\W$)#m", '$1<img src="'.Agora::getRoot().'/img/smilies/'.$smiley_img[$i].'"  alt="'.substr($smiley_img[$i], 0, strrpos($smiley_img[$i], '.')).'" />$2', $text);

        return substr($text, 1, -1);
    }

    function cleanup($text)
    {
        $space_pattern = array("\n", "\t", '  ', '  ','<p></p>');
        $space_replace = array('<br />', '&nbsp; &nbsp; ', '&nbsp; ', ' &nbsp;','');
        $text = str_replace($space_pattern, $space_replace, $text);
        return '<p>'.$text.'</p>';
    }

    function links($text)
    {
        $text = ' '.$text;

        $text = preg_replace('#([\s\(\)])(https?|ftp|news){1}://([\w\-]+\.([\w\-]+\.)*[\w]+(:[0-9]+)?(/[^"\s\(\)<\[]*)?)#ie', '\'$1\'.$this->handle_url_tag(\'$2://$3\')', $text);
        $text = preg_replace('#([\s\(\)])(www|ftp)\.(([\w\-]+\.)*[\w]+(:[0-9]+)?(/[^"\s\(\)<\[]*)?)#ie', '\'$1\'.$this->handle_url_tag(\'$2.$3\', \'$2.$3\')', $text);

        return $text;
    }

    function split_text($text, $start, $end)
    {
        $tokens = explode($start, $text);

        $outside[] = $tokens[0];

        $num_tokens = count($tokens);
        for ($i = 1; $i < $num_tokens; ++$i)
        {
            $temp = explode($end, $tokens[$i]);
            $inside[] = $temp[0];
            $outside[] = $temp[1];
        }

        if ($this->agora_config['o_indent_num_spaces'] != 8 && $start == '[code]')
        {
            $spaces = str_repeat(' ', $this->agora_config['o_indent_num_spaces']);
            $inside = str_replace("\t", $spaces, $inside);
        }

        return array($inside, $outside);
    }

    function bbcode($text, $show_smilies)
    {
        static $replace, $pattern, $code_pattern, $code_replace;


        if (strpos($text, '[CODE]') !== false && strpos($text, '[/CODE]') !== false)
        {

            $text = str_replace("[CODE]", "[code]", $text);
            $text = str_replace("[/CODE]", "[/code]",$text);
            if (strpos($text, '[code]') !== false && strpos($text, '[/code]') !== false)
            {
                list($inside, $outside) = $this->split_text($text, '[code]', '[/code]');
                $outside = array_map('ltrim', $outside);
                $text = implode('<">', $outside);
            }
        }
        if (strpos($text, '[code]') !== false && strpos($text, '[/code]') !== false)
        {
            list($inside, $outside) = $this->split_text($text, '[code]', '[/code]');
            $outside = array_map('ltrim', $outside);
            $text = implode('<">', $outside);
        }


        if (!isset($replace) || !isset($pattern)) {
			$bbvideo_width = $this->agora_config['o_bbcode_video_width'];
			$bbvideo_height = $this->agora_config['o_bbcode_video_height'];

            include(AGORA_PATH.DS.'include'.DS.'parser_patterns.php');
        }

        if ($this->agora_config['o_make_links']) {
            $text = $this->links($text);
        }

        if ($show_smilies) {
            $text = $this->smilies($text);
        }

        if (strpos($text, 'QUOTE') !== false)
        {

            $text = str_replace("[QUOTE]", "[quote]", $text);
            $text = str_replace("[/QUOTE]", "[/quote]",$text);

            {
                $text = str_replace('[quote]', '<blockquote><div class="incqbox">', $text);
                $text = preg_replace('#\[quote=(&quot;|"|\'|)(.*)\\1\]#seU', '"<blockquote><div class=\"incqbox\"><h4>".str_replace(array(\'[\', \'\\"\'), array(\'&#91;\', \'"\'), \'$2\')." ".Agora::lang(\'wrote\').":</h4>"', $text);
                $text = preg_replace('#\[\/quote\]\s*#', '</div></blockquote>', $text);
            }
        }

        if (strpos($text, 'quote') !== false)
        {
            //			$text = $this->sm_parse_start($text);
            $text = str_replace('[quote]', '<blockquote><div class="incqbox">', $text);
            $text = preg_replace('#\[quote=(&quot;|"|\'|)(.*)\\1\]#seU', '"<blockquote><div class=\"incqbox\"><h4>".str_replace(array(\'[\', \'\\"\'), array(\'&#91;\', \'"\'), \'$2\')." ".Agora::lang(\'wrote\').":</h4>"', $text);
            $text = preg_replace('#\[\/quote\]\s*#', '</div></blockquote>', $text);
        }

        if (strpos($text, 'SPOILER') !== false)
        {
            $text = str_replace("[SPOILER]", "[spoiler]", $text);
            $text = str_replace("[/SPOILER]", "[/spoiler]",$text);

            if (strpos($text, 'spoiler') !== false)
            {
                $text = str_replace('[spoiler]', '<div class="slideContainer"><div class="toolbar">&nbsp;'.Agora::lang('Spoiler').'&nbsp;<a href="#" class="ShowHidden"><img src="'.Agora::getRoot().'img/agoraBBCode/warn_add.gif" border="0" alt="Show Spoiler"/></a> / <a href="#" class="HideHidden"><img src="'.Agora::getRoot().'img/agoraBBCode/warn_minus.gif" border="0" alt="Hide Spoiler" /></a></div><div class="SlideText">'.""."&nbsp;", $text);

                $text = preg_replace('#\[\/spoiler\]\s*#', "</div></div>", $text);
            }
        }

        if (strpos($text, 'spoiler') !== false)
        {
            $text = str_replace('[spoiler]', '<div class="slideContainer"><div class="toolbar">&nbsp;'.Agora::lang('Spoiler').'&nbsp;<a href="#" class="ShowHidden"><img src="'.Agora::getRoot().'img/agoraBBCode/warn_add.gif" border="0" alt="Show Spoiler"/></a> / <a href="#" class="HideHidden"><img src="'.Agora::getRoot().'img/agoraBBCode/warn_minus.gif" border="0" alt="Hide Spoiler" /></a></div><div class="SlideText">'.""."&nbsp;", $text);

            $text = preg_replace('#\[\/spoiler\]\s*#', "</div></div>", $text);
        }

        if (strpos($text, 'IMG') !== false)
        {
            $text = str_replace("[IMG", "[img", $text);
            $text = str_replace("[/IMG]", "[/img]",$text);
        }

        $upattern = $this->capitalizeArray($pattern);

        $text = preg_replace($upattern, $replace, $text);

        $text = preg_replace($pattern, $replace, $text);



        if (isset($inside))
        {
            $outside = explode('<">', $text);
            $text = '';

            $num_tokens = count($outside);

            for ($i = 0; $i < $num_tokens; ++$i)
            {
                $text .= $outside[$i];
                if (isset($inside[$i]))
                {
                    $num_lines = ((substr_count($inside[$i], "\n")) + 3) * 1.5;
                    $height_str = ($num_lines > 35) ? '35em' : $num_lines.'em';
                    $text .= '</p><div class="ag_codebox"><div class="ag_incqbox"><h4>'.Agora::lang('Code').':</h4><div class="ag_scrollbox"><pre>'.$inside[$i].'</pre></div></div></div><p>';
                }
            }
        }

        return $text;
    }



    function capitalizeArray($array) {

        foreach($array as $item)
        {
            $item = strtoupper($item);
            $newworkdata[] = str_replace("#S", "#s", str_replace("#E", "#e", $item));

        }
        return $newworkdata;
    }

}
?>
