<?php
    defined ('IN_AGORA') or die;

	require_once ('view.php');

	class IndexView extends View
	{
		function display()
		{
			if (isset($_COOKIE['agora_forum_view'])) {
				$forum_view = intval($_COOKIE['agora_forum_view']);
			} else {
				$forum_view = 1;
			}
			
			if ($forum_view == 1) {
				parent::display('index_forums');
			} else {
				parent::display('index_topics');
			}
		}
	}
?>
