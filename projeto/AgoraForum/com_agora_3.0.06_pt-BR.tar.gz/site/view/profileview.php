<?php
defined ('IN_AGORA') or die;

require_once('view.php');

class ProfileView extends View
{
    var	$config;
    var $pane;

    function __construct($template = NULL)
    {
        parent::__construct($template);
        $this->smarty->register_function('radio_option',array(&$this,'radioOption'));
        $this->smarty->register_function('text_option',array(&$this,'textOption'));
        $this->config = NULL;
        $this->clean_view = false;
    }

    function textOption($params, & $smarty)
    {
        if (!$this->config) {
            $this->config = & $smarty->get_template_vars('agora_config');
        }

        $caption = Agora::lang($params['caption']);
        $var = $params['var'];
        $desc = Agora::lang($params['desc']);
        $colspan = isset($params['colspan']) ? ' colspan='.$params['colspan'] : '';

        $opts = '';
        unset($params['desc']);
        unset($params['caption']);
        unset($params['var']);
        unset($params['colspan']);
        foreach ($params as $opt_name => $opt_val) {
            $opts .= "$opt_name=\"$opt_val\" ";
        }

        if (!isset($this->config['o_'.$var])) {
            $this->smarty->trigger_error("Variable o_$var not found in agora_config");
        }

        $value=$this->config['o_'.$var];

        return <<<EOT
                <tr><th scope="row">$caption</th>
                    <td$colspan>
                        <input type="text" name="form[$var]" value="$value" $opts/>
                        <span>$desc</span>
                    </td>
                </tr>
EOT;
    }

    function radioOption($params, & $smarty)
    {
        if (!$this->config) {
            $this->config = & $smarty->get_template_vars('agora_config');
        }

        $caption = $params['caption'];
        $var = $params['var'];
        $desc = $params['desc'];

        $colspan = isset($params['colspan']) ? ' colspan='.$params['colspan'] : '';

        if (!isset($this->config['o_'.$var])) {
            $this->smarty->trigger_error("Variable o_$var not found in agora_config");
        }

        if ($this->config['o_'.$var]) {
            $checked_1 = ' checked="checked"';
            $checked_0 = '';
        } else {
            $checked_1 = '';
            $checked_0 = ' checked="checked"';
        }
        return <<<EOT
                <tr>
                    <th scope="row">$caption</th>
                    <td$colspan>
                        <input type="radio" name="form[$var]" value="1"$checked_1 />&nbsp;
                            <strong>Yes</strong>&nbsp;&nbsp;&nbsp;
                        <input type="radio" name="form[$var]" value="0"$checked_0 />&nbsp;
                            <strong>No</strong>
                        <span>$desc</span>
                    </td>
                </tr>
EOT;
    }

    function prepareMenu()
    {
        $this->pages = array(
                'Personal'			=> array('personal',		'personal.png'),
                'Messaging'			=> array('messaging',		'messaging.png'),
                'Personality'		=> array('personality',		'pers.png'),
                'Gallery'		=> array('gallery',		'gallery.png'),
                'Attachments'		=> array('attachments',		'attach.png'),
                'Display'			=> array('display',			'display.png'),
                'Privacy'			=> array('privacy',			'privacy.png'),
        );

    }

    function display($template = NULL)
    {
        if (Agora::getVar('type') === 'clean') {
            JRequest::setVar('tmpl', 'component'); //force the component template
            if ($this->template) {
                $template = $this->template;
            }
            $this->smarty->display("profile/$template.tpl");
            return;
        }

        $this->smarty->display('header.tpl');

        //			$this->smarty->caching = 1;

        $this->prepareMenu();

        $this->smarty->assign_by_ref('pages', $this->pages);

        $this->smarty->display('profile/header.tpl');
        //			$this->smarty->caching = false;

        if ($this->template)
        $this->smarty->display("profile/{$this->template}.tpl");
        elseif ($template)
        $this->smarty->display("profile/$template.tpl");

        //			$this->smarty->display('admin/footer.tpl');
        $this->smarty->display('footer.tpl');
    }
}
?>
