<?php
	class AgoraGroupsModel extends Model
	{
		function __construct()
		{
			parent::__construct('');
		}

		function isInstalled()
		{
			$this->db->setQuery('SHOW TABLES LIKE \'#__agoragroups\'');
			return $this->db->loadResult() ? true : false;
		}

		function getUserGroups($user_id)
		{
			$this->db->bind('user_id',$user_id,'integer');
			$this->db->setQuery('SELECT g.id,g.name FROM ##__group AS g'.
							' INNER JOIN ##__user_group AS ug'.
							'  ON ug.group_id = g.id'.
							' INNER JOIN #__agoragroups AS ag'.
							'  ON ag.group_id = g.id'.
							' WHERE ug.user_id = :user_id');
			return $this->db->loadAssocList();
		}
	}

?>
