<?php
	defined ('IN_AGORA') or die;

	class SmiliesModel extends Model
	{
		function __construct()
		{
			parent::__construct("smilies");
		}

		function delete($id)
		{
			$this->db->setQuery('DELETE FROM ##__smilies WHERE Id = '.intval($id));
			if (!$this->db->query()) {
				print $this->db->getErrorMsg();
				die;
			}
		}

		function add($image, $text)
		{
			$this->db->bind('image',$image,'string');
			$this->db->bind('text',$text,'string');
			$this->db->setQuery('INSERT INTO ##__smilies (image, text) VALUES(:image,:text)');
			if (!$this->db->query()) {
				print $this->db->getErrorMsg();
				die;
			}
		}
	}
?>
