<?php
	defined ('IN_AGORA') or die;

	class SearchModel extends Model
	{
		var $_level;

		function __construct()
		{
			parent::__construct('posts');
		}

		function loadForumChildren(& $raw_data, $parent, & $result)
		{
			if (is_null($parent)) $parent = 0;

			foreach ($raw_data as $forum) {
				if ($forum['parent_forum_id'] == $parent) {

					$this_children = array();
					$this->_level++;
					$this->loadForumChildren($raw_data, $forum['id'],$this_children);
					$this->_level--;

					$forum['level'] = $this->_level;
					
					$cat = $forum['cat_name'];
					unset($forum['cat_name']);
					unset($forum['parent_forum_id']);

					if ($parent == 0) {

						$result[$cat][] = $forum;
						$result[$cat] = array_merge($result[$cat],$this_children);
					} else {
						$result[] = $forum;
						$result = array_merge($result,$this_children);
					}


				}
			}
		}

		function loadForumList()
		{
			$this->db->setQuery("SELECT f.id, f.parent_forum_id, f.forum_name,c.cat_name FROM".
						" {$this->prefix}forums AS f".
						" INNER JOIN {$this->prefix}categories AS c".
						" ON f.cat_id = c.id");

			$forum = $this->db->loadAssocList();

			$result = array();

			$this->_level = 0;
			$this->loadForumChildren($forum,0,$result);
			return $result;
		}

		function count_latest($hrs)
		{
			$match_sql = 't.last_post > '.(AGORA_TIME - $hrs*3600);
			$sql = "SELECT COUNT(DISTINCT t.id)".
				' FROM ##__posts AS p '.
				' INNER JOIN ##__topics AS t'.
				' ON p.topic_id = t.id'.
				' INNER JOIN ##__forums AS f'.
				' ON t.forum_id = f.id'.
				" WHERE $match_sql";
			$this->db->setQuery($sql);
			return $this->db->loadResult();
		}

		function getLatest($hrs,$per_page = null, $page = null)
		{
			$limit = $this->getLimit($per_page, $page);

			$fields = 't.id AS id,'.
					' t.poster,'.
					' t.subject,'.
					' t.question,'.
					' t.last_post,'.
					' t.last_post_id,'.
					' t.last_poster,'.
					' t.num_replies,'.
					' t.num_views,'.
					' t.closed,'.
					' t.sticky,'.
					' t.forum_id';

			$group_by_sql = ' GROUP BY t.id, t.poster, t.subject, t.last_post, t.last_post_id, t.last_poster, t.num_replies, t.closed, t.forum_id, t.sticky';
			$sort_by_sql = 't.last_post';
			$match_sql = 't.last_post > '.(AGORA_TIME - $hrs*3600);
			$sql = "SELECT $fields".
				' FROM ##__posts AS p '.
				' INNER JOIN ##__topics AS t'.
				' ON p.topic_id = t.id'.
				' INNER JOIN ##__forums AS f'.
				' ON t.forum_id = f.id'.
				" WHERE $match_sql $group_by_sql ORDER BY $sort_by_sql DESC";
			$sql .= $limit;

			$this->db->setQuery($sql);
			return $this->db->loadAssocList();
		}

		function count_unanswered()
		{
			$match_sql = 't.num_replies = 0 ';
			$sql = 'SELECT COUNT(*)'.
				' FROM ##__topics AS t '.
				' INNER JOIN ##__forums AS f'.
				' ON t.forum_id = f.id'.
				" WHERE $match_sql";

			$this->db->setQuery($sql);
			return $this->db->loadResult();
		}

		function getUnanswered($per_page = null, $page = null)
		{
			$limit = $this->getLimit($per_page, $page);

			$fields = 't.id AS id,'.
					' t.poster,'.
					' t.subject,'.
					' t.question,'.
					' t.last_post,'.
					' t.last_post_id,'.
					' t.last_poster,'.
					' t.num_replies,'.
					' t.num_views,'.
					' t.closed,'.
					' t.sticky,'.
					' t.forum_id';

			$group_by_sql = ' GROUP BY t.id, t.poster, t.subject, t.last_post, t.last_post_id, t.last_poster, t.num_replies, t.closed, t.forum_id, t.sticky';
			$sort_by_sql = 't.posted';
			$match_sql = 't.num_replies = 0 ';
			$sql = "SELECT $fields".
				' FROM ##__topics AS t '.
				' INNER JOIN ##__forums AS f'.
				' ON t.forum_id = f.id'.
				" WHERE $match_sql $group_by_sql ORDER BY $sort_by_sql DESC";
			$sql .= $limit;

			$this->db->setQuery($sql);
			return $this->db->loadAssocList();
		}

		function search($params,$per_page = null, $page = null)
		{
			$limit = $this->getLimit($per_page, $page);
			
			$keywords = $this->db->Quote($params['keywords']);
			$author = $this->db->Quote($params['author']);
			$sort_by = $params['sort_by'];
			$forum = $params['forum'];
			$show_as = $params['show_as'];
			$sort_dir = $params['sort_dir'];

			$fields = '';
			$group_by_sql = '';

			$forum_sql = ($forum != -1) ? " AND f.forum_name = '".$forum."'" : '';

			switch ($sort_by)
			{
				case 1:
					$sort_by_sql = ($show_as == 'topics') ? 't.poster' : 'p.poster';
					break;
				case 2:
					$sort_by_sql = 't.subject';
					break;
				case 3:
					$sort_by_sql = 't.forum_id';
					break;
				default:
					{
						$sort_by_sql = ($show_as == 'topics') ? 't.posted' : 'p.posted';
						if ($show_as == 'topics')
							$group_by_sql = ', t.posted';
						break;
					}
			}

			if(!empty($params['author']) && !empty($params['keywords'])) {
				$author_sql = " AND p.poster = $author";
			} else {
				$author_sql = '';
			}

			$select_sql = '';
			$group_by_sql = '';

			if ($show_as == 'posts') {

				if (!empty($params['keywords'])) {
					$match_msg = "MATCH (p.message) AGAINST ($keywords)";

					if ($sort_by == 5) {
						$sort_by_sql = 'score';
					}

					$fields = "$match_msg AS score, ";
					$match_sql = $match_msg;
				} else {
					// Author search
					$match_sql = "p.poster = $author";

					if($sort_by == 5)
						$sort_by_sql = 'p.posted';
				}

				$fields .= 'p.id AS pid,'.
						' p.poster AS pposter,'.
						' p.posted AS pposted,'.
						' p.poster_id,'.
						' SUBSTRING(p.message, 1, 1000) AS message,'.
						' t.id AS tid,'.
						' t.poster,'.
						' t.subject,'.
						' t.question,'.
						' t.last_post,'.
						' t.last_post_id,'.
						' t.last_poster,'.
						' t.num_replies,'.
						' t.forum_id';
			} else {
				if(!empty($params['keywords']))
				{
					// Keyword search
					$match_msg = "MATCH (p.message) AGAINST ($keywords)";
					$match_subject = "MATCH (t.subject) AGAINST ($keywords)";

					if($sort_by == 5)
						$sort_by_sql = 'score';

					$fields = $match_msg.' + '.$match_subject.' AS score, ';
					$match_sql = "($match_msg OR $match_subject)";
				}
				else
				{
					// Author search
					$match_sql = "p.poster = $author";

					if($sort_by == 5)
						$sort_by_sql = 't.posted';
				}

				$fields .= 't.id AS id,'.
						' t.poster,'.
						' t.subject,'.
						' t.question,'.
						' t.last_post,'.
						' t.last_post_id,'.
						' t.last_poster,'.
						' t.num_replies,'.
						' t.num_views,'.
						' t.closed,'.
						' t.forum_id';
				$group_by_sql = ' GROUP BY t.id, t.poster, t.subject, t.last_post, t.last_post_id, t.last_poster, t.num_replies, t.closed, t.forum_id'.$group_by_sql;
			}


			$sql = "SELECT $fields".
				" FROM {$this->prefix}posts AS p ".
				" INNER JOIN {$this->prefix}topics AS t".
				" ON p.topic_id = t.id".
				" INNER JOIN {$this->prefix}forums AS f".
				" ON t.forum_id = f.id".
				" WHERE $match_sql $forum_sql $author_sql $group_by_sql ORDER BY $sort_by_sql $sort_dir";
			$sql .= $limit;
			$this->db->setQuery($sql);
			
			return $this->db->loadAssocList();

		}
		
		function count_search($params)
		{
			
			$keywords = $this->db->Quote($params['keywords']);
			$author = $this->db->Quote($params['author']);
			$sort_by = $params['sort_by'];
			$forum = $params['forum'];
			$show_as = $params['show_as'];
			$sort_dir = $params['sort_dir'];

			$fields = '';
			$group_by_sql = '';

			$forum_sql = ($forum != -1) ? " AND f.forum_name = '".$forum."'" : '';

			switch ($sort_by)
			{
				case 1:
					$sort_by_sql = ($show_as == 'topics') ? 't.poster' : 'p.poster';
					break;
				case 2:
					$sort_by_sql = 't.subject';
					break;
				case 3:
					$sort_by_sql = 't.forum_id';
					break;
				default:
					{
						$sort_by_sql = ($show_as == 'topics') ? 't.posted' : 'p.posted';
						if ($show_as == 'topics')
							$group_by_sql = ', t.posted';
						break;
					}
			}

			if(!empty($params['author']) && !empty($params['keywords'])) {
				$author_sql = " AND p.poster = $author";
			} else {
				$author_sql = '';
			}

			$select_sql = '';
			$group_by_sql = '';

			if ($show_as == 'posts') {

				if (!empty($params['keywords'])) {
					$match_msg = "MATCH (p.message) AGAINST ($keywords)";

					if ($sort_by == 5) {
						$sort_by_sql = 'score';
					}

					$fields = "$match_msg AS score, ";
					$match_sql = $match_msg;
				} else {
					// Author search
					$match_sql = "p.poster = $author";

					if($sort_by == 5)
						$sort_by_sql = 'p.posted';
				}

				$fields .= 'p.id AS pid,'.
						' p.poster AS pposter,'.
						' p.posted AS pposted,'.
						' p.poster_id,'.
						' SUBSTRING(p.message, 1, 1000) AS message,'.
						' t.id AS tid,'.
						' t.poster,'.
						' t.subject,'.
						' t.question,'.
						' t.last_post,'.
						' t.last_post_id,'.
						' t.last_poster,'.
						' t.num_replies,'.
						' t.forum_id';
			} else {
				if(!empty($params['keywords']))
				{
					// Keyword search
					$match_msg = "MATCH (p.message) AGAINST ($keywords)";
					$match_subject = "MATCH (t.subject) AGAINST ($keywords)";

					if($sort_by == 5)
						$sort_by_sql = 'score';

					$fields = $match_msg.' + '.$match_subject.' AS score, ';
					$match_sql = "($match_msg OR $match_subject)";
				}
				else
				{
					// Author search
					$match_sql = "p.poster = $author";

					if($sort_by == 5)
						$sort_by_sql = 't.posted';
				}

				$fields .= 't.id AS id,'.
						' t.poster,'.
						' t.subject,'.
						' t.question,'.
						' t.last_post,'.
						' t.last_post_id,'.
						' t.last_poster,'.
						' t.num_replies,'.
						' t.num_views,'.
						' t.closed,'.
						' t.forum_id';
				$group_by_sql = ' GROUP BY t.id, t.poster, t.subject, t.last_post, t.last_post_id, t.last_poster, t.num_replies, t.closed, t.forum_id'.$group_by_sql;
			}


			$sql = "SELECT $fields".
				" FROM {$this->prefix}posts AS p ".
				" INNER JOIN {$this->prefix}topics AS t".
				" ON p.topic_id = t.id".
				" INNER JOIN {$this->prefix}forums AS f".
				" ON t.forum_id = f.id".
				" WHERE $match_sql $forum_sql $author_sql $group_by_sql ORDER BY $sort_by_sql $sort_dir";
			
			
			$this->db->setQuery($sql);
			$res = $this->db->loadAssocList();

			return $this->db->getAffectedRows();
			 
		}
	}
?>