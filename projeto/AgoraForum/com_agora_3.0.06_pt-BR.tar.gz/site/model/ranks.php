<?php

class RanksModel extends Model
{
	function __construct()
	{
		parent::__construct('ranks');
	}

	function loadAll($key='')
	{
		$this->setOrder('ORDER BY min_posts ASC');
		return parent::loadAll($key);
	}

	function _sort_images($a, $b)
	{
		return strcmp($a['name'],$b['name']);
	}

	function loadImages()
	{
		$dir = opendir(AGORA_PATH.DS.'img'.DS.'ranks');
		$images = array();
		while ($file = readdir($dir)) {
			if (preg_match('/.+\.(gif|png|jpg|jpeg)/i',$file)) {
				$images[] = array(
					'name'=> $file,
					'url' => Agora::getSite().'img/ranks/'.$file,
				);
			}
		}
		usort($images, array($this,'_sort_images'));
		closedir($dir);
		return $images;
	}
}
?>
