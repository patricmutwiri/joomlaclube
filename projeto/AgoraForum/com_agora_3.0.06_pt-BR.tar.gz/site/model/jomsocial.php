<?php
	defined ('IN_AGORA') or die;

	class JomsocialModel extends Model
	{
		function getJomsocialAvatar($jos_id)
		{
			$this->db->setQuery('SELECT avatar FROM #__community_users WHERE userid = '.intval($jos_id));
			return $this->db->loadResult();
		}
		
		function getJomsocialThumb($jos_id)
		{
			$this->db->setQuery('SELECT thumb FROM #__community_users WHERE userid = '.intval($jos_id));
			return $this->db->loadResult();
		}
	}
?>
