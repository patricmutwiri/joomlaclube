<?php
	defined ('IN_AGORA') or die;

	class BoardModel extends Model
	{
/*		var $_level;

		function _loadForumChildren($raw_data, $parent, & $result)
		{
			if (is_null($parent)) $parent = 0;

			foreach ($raw_data as $forum) {
				if ($forum['parent_forum_id'] == $parent) {

					if ($forum['id']) {
						$this_children = array();
						$this->_level++;
						$this->_loadForumChildren($raw_data, $forum['id'],$this_children);
						$this->_level--;
					}

					$forum['level'] = $this->_level;
					
//					$cat = $forum['cat_name'];
					$cat_id = $forum['cat_id'];
//					unset($forum['cat_name']);


					if ($parent == 0) {
						$result[$cat_id]['cat_name'] = $forum['cat_name'];
						$result[$cat_id]['cat_id'] = $cat_id;
						$result[$cat_id]['enable'] = $forum['cat_enable'];
						$result[$cat_id]['disp_position'] = $forum['cat_disp_position'];
						
						if ($forum['id']) {
							$result[$cat_id]['forums'][$forum['id']] = & $forum;
							$result[$cat_id]['forums'] += $this_children;
						} else {
							$result[$cat_id]['forums'] = array();
						}
					} else {
						$result[$forum['id']] = $forum;
						$result += $this_children;
					}

				}
			}
		}
		function loadForumList()
		{
/*			$this->db->setQuery('SELECT'.
						' f.id,f.enable,'.
						' f.parent_forum_id,'.
						' f.forum_name,f.disp_position, c.cat_name,c.id as cat_id, c.disp_position as cat_disp_position, c.enable as cat_enable,'.
						' f.num_posts, f.num_topics, f.forum_desc, f.last_post, f.last_post_id, '.
						' FROM ##__forums AS f'.
						' RIGHT JOIN ##__categories AS c ON f.cat_id = c.id'.
						' ORDER BY cat_disp_position, f.disp_position'
						);
			$this->db->setQuery('SELECT'.
						' f.*,'.
						' c.cat_name,c.id as cat_id, c.disp_position as cat_disp_position, c.enable as cat_enable'.
						' FROM ##__forums AS f'.
						' RIGHT JOIN ##__categories AS c ON f.cat_id = c.id'.
						' ORDER BY cat_disp_position, f.disp_position'
						);
			//print $this->db->_sql;die;
			$forum = $this->db->loadAssocList();
//			dump($forum);
			$result = array();

			$this->_level = 0;
			$this->_loadForumChildren($forum,0,$result);
			return $result;
		}
*/
		function _checkLastPost(&$forums, & $forum)
		{
			if (!$forum['parent_forum_id']) return;

			$parent = &$forums[$forum['parent_forum_id']];
			if ($parent['last_post'] < $forum['last_post']) {
				$parent['last_post'] = $forum['last_post'];
				$parent['last_post_id'] = $forum['last_post_id'];
				$parent['last_poster'] = $forum['last_poster'];

				$parent['num_topics'] += $forum['num_topics'];
				$parent['num_posts'] += $forum['num_posts'];
			}

			$this->_checkLastPost($forums, $parent);
		}
		

		function loadForumList($hide_disabled = true)
		{
			if ($hide_disabled) {
				$where = 'WHERE enable=1';
			} else {
				$where = '';
			}

			$this->db->setQuery('SELECT * FROM ##__categories '.$where.' ORDER BY disp_position');
			$categories = $this->db->loadAssocList('id');

			$this->db->setQuery('SELECT * FROM ##__forums '.$where.' ORDER BY disp_position');
			$forums = $this->db->loadAssocList();

			$forum_cat = $categories;
			foreach ($forum_cat as $cat_id => $cat) {
				$forum_cat[$cat_id]['cat_id'] = $cat_id;
				$forum_cat[$cat_id]['forums'] = array();
			}
			
			foreach ($forums as $forum) {
				$cat_id = $forum['cat_id'];
				if (!isset($forum_cat[$cat_id])) continue;
				if (!isset($forum_cat[$cat_id]['forums'])) {
//					$forum_cat[$cat_id] = $categories[$cat_id];
				}
				$forum_cat[$cat_id]['forums'][$forum['id']] = $forum;
			}

			foreach ($forum_cat as $cat_id => $category) {
				$forum_cat[$cat_id]['forums'] = parseTree($category['forums'], 0, 0, 'id', 'parent_forum_id', true);

				$forums = &$forum_cat[$cat_id]['forums'];
				foreach ($forums as $forum) {
					$lowest = true;
					foreach ($forums as $search_lowest) {
						if ($search_lowest['parent_forum_id'] == $forum['id']) {
							$lowest = false;
							break;
						}
					}

					if ($lowest)
						$this->_checkLastPost($forums, $forum);
				}
			}

			return $forum_cat;
		}
	}
?>