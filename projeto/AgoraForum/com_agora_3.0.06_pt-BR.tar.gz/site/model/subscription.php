<?php

	class SubscriptionModel extends Model
	{
		function __construct()
		{
			parent::__construct('subscriptions');
		}

		function isSubscribed($user_id, $topic_id)
		{
			$this->db->bind('user_id',$user_id,'integer');
			$this->db->bind('topic_id',$topic_id,'integer');

			$this->db->setQuery('SELECT COUNT(*) FROM ##__subscriptions'.
							' WHERE user_id=:user_id'.
							' AND topic_id=:topic_id');
			return intval($this->db->loadResult());
		}

		function delete($user_id, $topic_id)
		{
			$this->db->bind('user_id',$user_id,'integer');
			$this->db->bind('topic_id',$topic_id,'integer');

			$this->db->setQuery('DELETE FROM ##__subscriptions'.
							' WHERE user_id=:user_id'.
							' AND topic_id=:topic_id');
			$this->db->query();
		}
		
		function delete_forum($user_id, $forum_id)
		{
			$this->db->bind('user_id',$user_id,'integer');
			$this->db->bind('forum_id',$forum_id,'integer');

			$this->db->setQuery('DELETE FROM ##__subscriptions'.
							' WHERE user_id=:user_id'.
							' AND forum_id=:forum_id');
			$this->db->query();
		}


		function loadSubscribers($topic_id, $forum_id)
		{
			$this->db->bind('topic_id',$topic_id,'integer');
			$this->db->bind('forum_id',$forum_id,'integer');

			$this->db->setQuery('SELECT DISTINCT user.id, email, username, disp_posts'.
							' FROM ##__users AS user'.
							' INNER JOIN ##__subscriptions AS s'.
							'  ON s.user_id = user.id'.
							' WHERE (s.topic_id=:topic_id OR s.forum_id=:forum_id)');
			return $this->db->loadAssocList();
		}
		
		function getSubscribedTopics($user_id, $per_page = null, $page = null)
		{
			$limit = $this->getLimit($per_page, $page);
			
			$this->db->bind('user_id',$user_id,'integer');

			$this->db->setQuery('SELECT topics.id, topics.subject, topics.poster, topics.num_replies'.
							' FROM ##__topics AS topics'.
							' INNER JOIN ##__subscriptions AS s'.
							' ON s.topic_id = topics.id'.
							' WHERE s.user_id=:user_id ' . $limit );
			return $this->db->loadAssocList();
		}
		
		function countSubscribedTopics($user_id)
		{
			$this->db->bind('user_id',$user_id,'integer');

			$this->db->setQuery('SELECT COUNT(*)'.
							' FROM ##__topics AS topics'.
							' INNER JOIN ##__subscriptions AS s'.
							' ON s.topic_id = topics.id'.
							' WHERE s.user_id=:user_id ');
			return $this->db->loadResult();
		}
		
		function getSubscribedForums($user_id)
		{
			$this->db->bind('user_id',$user_id,'integer');

			$this->db->setQuery('SELECT forums.id, forums.forum_name, forums.num_posts, forums.num_topics,'.
							' forums.forum_desc FROM ##__forums AS forums'.
							' INNER JOIN ##__subscriptions AS s'.
							' ON s.forum_id = forums.id'.
							' WHERE s.user_id=:user_id ');
			return $this->db->loadAssocList();
		}
		
		function countSubscribedForums($user_id)
		{
			$this->db->bind('user_id',$user_id,'integer');

			$this->db->setQuery('SELECT COUNT(*)'.
							' FROM ##__forums AS forums'.
							' INNER JOIN ##__subscriptions AS s'.
							' ON s.forum_id = forums.id'.
							' WHERE s.user_id=:user_id ');
			return $this->db->loadResult();
		}

	}
?>
