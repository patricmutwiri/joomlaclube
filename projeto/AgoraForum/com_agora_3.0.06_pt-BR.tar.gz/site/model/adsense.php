<?php
	defined ('IN_AGORA') or die;

	class AdSenseModel extends Model
	{
		function __construct()
		{
			parent::__construct('adsense_config');
		}

		function load()
		{
			$sql = "SELECT conf_name,conf_value FROM {$this->table}";
			$this->db->setQuery($sql);
			$list = $this->db->loadRowList();
			if (!$list) return false;
			$data = array();
			foreach ($list as $result) {
				$fname = $result[0];
				$fvalue = $result[1];
				$data[$fname] = $fvalue;
			}
			return $data;
		}
	
	    function save($data)
	    {
	    	foreach ($data as $key => $value) {
	    		$this->db->setQuery('UPDATE ##__adsense_config SET conf_value = '.$this->db->Quote($value).' WHERE conf_name = '.$this->db->Quote($key));
	    		if (!$this->db->query()) {
	    			print $this->db->getErrorMsg();
	    			die;
	    		}
	    	}
	    }
	}
?>