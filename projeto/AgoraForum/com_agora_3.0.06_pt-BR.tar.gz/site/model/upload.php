<?php
	class UploadModel
	{
		function loadUser($user_id, $allowed_extensions)
		{
			$dir = AGORA_PATH.DS.'img'.DS.'members'.DS.$user_id.DS;
			$web_dir = Agora::getSite().'img/members/'.$user_id.'/';

			$uploads = array();
			if(is_dir($dir))
			{
				$open = opendir($dir);
				$files = array();
				while(false !== ($file = readdir($open)))
				{
					if(is_file($dir.$file))
					{
						$extension = strtolower(substr(strrchr($file,  "." ), 1));
						$extsupport = explode(',', $allowed_extensions.','.strtoupper($allowed_extensions));
						if(in_array($extension, $extsupport)&& ($file[0] != "#") && strpos($file,'mini_') !== 0)
							$files[] = $file;
					}
				}
				closedir($open);
				$id = 1;
				foreach($files as $file)
				{
					$upload = array();
					$upload['id'] = $id;
					$upload['size'] = ceil((filesize($dir.$file)*1024)/1048576);
					$upload['name'] = $file;

//					if (getimagesize($dir.$file)) {
						$upload['path'] = $web_dir.$file;
/*					} else {
						$upload['path'] = '';
					}*/

					$mini_file = $dir.'mini_'.$file;
					if (is_file($mini_file) && getimagesize($mini_file)) {
						$upload['mini'] = $web_dir.'mini_'.$file;
						$upload['size'] += ceil((filesize($mini_file)*1024)/1048576);
					} else {
						$upload['mini'] = '';
					}
					$uploads[$id] = $upload;
					
					$id += 1;
				}
			}
			return $uploads;
		}

		function deleteList($user_id,$uploads, $allowed_extensions)
		{
			$dir = AGORA_PATH.DS.'img'.DS.'members'.DS.$user_id.DS;
			if(!is_dir($dir)) return;

			$open = opendir($dir);
			$n = 1;
			$f_name = null;
			$files = array();
			while(false !== ($file = readdir($open)))
			{
				if(is_file($dir.$file))
				{
					$extension = strtolower(substr(strrchr($file,  "." ), 1));
					$extsupport = explode(',', $allowed_extensions.','.strtoupper($allowed_extensions));
					if(in_array($extension, $extsupport)&& ($file[0] != "#") && strpos($file,'mini_') !== 0) {
						$files[$n] = $file;
						$n += 1;
					}
				}
			}
			closedir($open);

			foreach($uploads as $upload_id) {
				$f_name = $files[$upload_id];
				@unlink($dir.$f_name);
				@unlink($dir.'mini_'.$f_name);
			}

		}

		function delete($user_id,$upload_id, $allowed_extensions)
		{
			$upload_id = intval($upload_id);
			if ($upload_id <= 0) return;

			$dir = AGORA_PATH.DS.'img'.DS.'members'.DS.$user_id.DS;
			if(!is_dir($dir)) return;

			$open = opendir($dir);
			$n = 1;
			$f_name = null;
			while(false !== ($file = readdir($open)))
			{
				if(is_file($dir.$file))
				{
					$extension = strtolower(substr(strrchr($file,  "." ), 1));
					$extsupport = explode(',', $allowed_extensions.','.strtoupper($allowed_extensions));
					if(in_array($extension, $extsupport)&& ($file[0] != "#") && strpos($file,'mini_') !== 0) {
						if ($n === $upload_id) {
							$f_name = $file;
							break;
						}
						$n += 1;
					}
				}
			}
			closedir($open);
			
			if (!is_null($f_name)) {
				@unlink($dir.$f_name);
				@unlink($dir.'mini_'.$f_name);
			}
		}

		function add($user_id, $upload, $upload_name, $allowed_extensions)
		{
			$extensions_valid = explode(',', $allowed_extensions.','.strtoupper($allowed_extensions));
			$extension_uploaded = substr(strrchr($upload['name'], '.'), 1);

			if(!in_array($extension_uploaded,$extensions_valid)) return FALSE;

			if (is_null($upload_name) || empty($upload_name))
				$upload_name = $upload['name'];

			$f_name = explode('.', $upload_name);
			$name = $f_name[0];
			$ext = '';
			if (count($f_name) > 1) {
				$ext = $f_name[count($f_name) - 1];
			} else {
				$name = $f_name[0];
				$upload_mime = explode('/', $upload['type']);
				$upload_mime = $upload_mime[count($upload_mime)-1];
				switch ($upload_mime) {
					case 'x-shockwave-flash': $ext = 'swf'; break;
					case 'msword': $ext = 'doc'; break;
					case 'vnd.oasis.opendocument.text': $ext = 'odt'; break;
					case 'vnd.ms-excel': $ext = 'xls'; break;
					case 'vnd.oasis.opendocument.spreadsheet': $ext = 'ods'; break;
					case 'vnd.ms-powerpoint': $ext = 'ppt'; break;
					case 'ppt.vnd.oasis.opendocument.presentation': $ext = 'odp'; break;
					case 'pjpeg': $ext = 'jpg'; break;
					case 'x-png': $ext = 'png'; break;
					case 'x-emf': $ext = 'emf'; break;
					case 'x-wmf': $ext = 'wmf'; break;
					case 'x-zip-compressed': $ext = 'zip'; break;
					case 'x-gzip-compressed': $ext = 'gz'; break;
					case 'x-compressed': $ext = 'tar'; break;
					case 'x-aiff': $ext = 'aiff'; break;
					default: $ext = $upload_mime;
				}
			}

			if(!in_array($ext,$extensions_valid)) return FALSE;
			if (strtolower($ext) == 'php') return FALSE;

			$real_mime = exec('file -ib '.escapeshellarg($upload['tmp_name']).' 2>/dev/null');
			preg_match('|^(\S+/\S+)|',preg_quote($real_mime,'|'), $parts);

			if (isset($parts[1])) {
				$real_mime = $parts[1];
			} else {
				$real_mime = mime_content_type($upload['tmp_name']);
			}

			if (!$real_mime) return FALSE;

			if ($real_mime == 'text/x-php') return FALSE;
			if ($real_mime == 'application/x-shockwave-flash' && !in_array('swf',$extensions_valid)) return FALSE;

			$file_name = $this->_parse_file($name).'.'.$ext;

			$dir = AGORA_PATH.DS.'img'.DS.'members'.DS;

			if(!is_dir($dir))
				mkdir($dir, 0755);

			$dir .= $user_id.DS;

			if(!is_dir($dir))
				mkdir($dir, 0755);

			if (!is_dir($dir)) {
				return FALSE;
			}

			$img = $dir.$file_name;

			while (is_file($img)) {
				$file_name = date('dmY\-Hi', time()).'_'.$file_name;
				$img = $dir.$file_name;
			}

			if (move_uploaded_file($upload['tmp_name'],$img)) {
				return $file_name;
			} else {
				return FALSE;
			}

		}

		function makeThumb($user_id, $file_name, $dest_height)
		{
			$width_orig = null;
			$height_orig = null;
			$image_type = null;
			
			$dir = AGORA_PATH.DS.'img'.DS.'members'.DS.$user_id.DS;
			$img = $dir.$file_name;
			
			list($width_orig, $height_orig, $image_type) = getimagesize($img);

			switch ($image_type)
			{
				case IMAGETYPE_GIF: $image = imagecreatefromgif($img); break;
				case IMAGETYPE_JPEG: $image = imagecreatefromjpeg($img);  break;
				case IMAGETYPE_PNG: $image = imagecreatefrompng($img); break;
				default: return;
			}

			if(isset($image)) {
				if($height_orig > $dest_height) {
					$scale = $dest_height/$height_orig;
					$dest_width = $width_orig*$scale;

					$dest_image = imagecreatetruecolor($dest_width, $dest_height);
					imagecopyresampled($dest_image, $image, 0, 0, 0, 0, $dest_width, $dest_height, $width_orig, $height_orig);
					switch ($image_type)
					{
						case 1: imagegif($dest_image, $dir.'mini_'.$file_name); break;
						case 2: imagepng($dest_image, $dir.'mini_'.$file_name); break;
						case 3: imagejpeg($dest_image, $dir.'mini_'.$file_name); break;
					}
					imagedestroy($dest_image);
				} else {
					switch ($image_type)
					{
						case IMAGETYPE_GIF: imagegif($image, $dir.'mini_'.$file_name); break;
						case IMAGETYPE_PNG: imagepng($image, $dir.'mini_'.$file_name); break;
						case IMAGETYPE_JPEG: imagejpeg($image, $dir.'mini_'.$file_name); break;
					}
				}
				imagedestroy($image);
			}
		}
		
		function _parse_file($file_name)
		{
			$file_name = preg_replace('![_@=\' ]!i', '-', $file_name);
			$file_name = preg_replace('![&\$ \?\!\.,;:\*\+\/\\\^\(\)%"~\[\]\{\}]!i', '', $file_name);
			$file_name = preg_replace('!([авд])!i', 'a', $file_name);
			$file_name = preg_replace('!([йикл])!i', 'e', $file_name);
			$file_name = preg_replace('!([оп])!i', 'i', $file_name);
			$file_name = preg_replace('!([фц])!i', 'o', $file_name);
			$file_name = preg_replace('!([щьы])!i', 'u', $file_name);
			$file_name = preg_replace('!я!i', 'y', $file_name);
			$file_name = preg_replace('!з!i', 'c', $file_name);
			return $file_name;
		}
	}
?>
