<?php
	defined ('IN_AGORA') or die;

	class PostModel extends Model
	{
		function __construct()
		{
			parent::__construct('posts');
		}

		function getTopicId($post_id)
		{
			$this->db->setQuery('SELECT topic_id FROM ##__posts WHERE id = '.intval($post_id));
			return $this->db->loadResult();
		}

		function delete($id)
		{
			$this->setQuery('SELECT p.poster_id,topic_id,forum_id'.
							' FROM ##__posts AS p'.
							' INNER JOIN ##__topics AS t'.
							'  ON p.topic_id = t.id'.
							' INNER JOIN ##__forums AS f'.
							'  ON t.forum_id = f.id'.
							' WHERE p.id = '.intval($id).' LIMIT 1');
			
			list($user_id, $topic_id, $forum_id) = $this->db->loadRow();

			$this->setQuery('DELETE FROM ##__posts WHERE id = '.intval($id));
			$this->db->query();

			if ($topic_id) {
				$this->setQuery('UPDATE ##__topics SET num_replies = num_replies-1 WHERE id = '.$topic_id);
				$this->db->query();

				$this->setQuery('SELECT id, poster, posted FROM ##__posts WHERE topic_id = '.$topic_id.' ORDER BY posted DESC LIMIT 1');
				list($last_post_id, $last_poster, $last_post) = $this->db->loadRow();

				$this->setQuery('UPDATE ##__topics SET'.
							' last_post_id='.intval($last_post_id).','.
							' last_poster='.$this->db->Quote($last_poster).','.
							' last_post='.intval($last_post).
							' WHERE id='.intval($topic_id));
				$this->db->query();
			}

			if ($forum_id) {
				$this->setQuery('UPDATE ##__forums SET num_posts = num_posts-1 WHERE id = '.$forum_id);
				$this->db->query();

				$this->setQuery('SELECT p.id, p.poster, p.posted'.
								' FROM ##__posts AS p'.
								' INNER JOIN ##__topics AS t'.
								'  ON t.id=p.topic_id'.
								' WHERE t.forum_id = '.$forum_id.
								' ORDER BY p.posted DESC LIMIT 1');

				list($last_post_id, $last_poster, $last_post) = $this->db->loadRow();

				$this->setQuery('UPDATE ##__forums SET'.
							' last_post_id='.intval($last_post_id).','.
							' last_poster='.$this->db->Quote($last_poster).','.
							' last_post='.intval($last_post).
							' WHERE id='.intval($forum_id));
				$this->db->query();
			}

			if ($user_id) {
				$this->setQuery('SELECT posted FROM ##__posts WHERE poster_id='.$user_id.' ORDER BY posted DESC LIMIT 1');
				$last_post = $this->db->loadResult();

				if (is_null($last_post)) $last_post = 'NULL'; else $last_post = intval($last_post);
				
				$this->setQuery('UPDATE ##__users SET num_posts = num_posts-1, last_post = '.$last_post.' WHERE id = '.$user_id);
				$this->db->query();
			}

		}

		function edit($post_id,$message,$silent, $editor_name)
		{
			$this->db->bind('post_id',$post_id,'integer');
			$this->db->bind('message',$message,'string');
			if ($silent) {
				$sql = 'UPDATE ##__posts SET message = :message WHERE id = :post_id';
			} else {
				$this->db->bind('editor_name',$editor_name,'string');
				$sql = 'UPDATE ##__posts SET' .
					' message = :message,'.
					' edited = '.AGORA_TIME.','.
					' edited_by = :editor_name'.
					' WHERE id = :post_id';
			}
			$this->db->setQuery($sql);
			$this->db->query();
		}
	}
?>