<?php
	defined ('IN_AGORA') or die;

	class OnlineModel extends Model
	{
		function __construct()
		{
			parent::__construct('users');
		}

		function getOnline()
		{
			$sessions = null;
			// calculate number of guests and members
			$user_array  = array();
			$guest_count = 0;

			$this->db->setQuery('SELECT COUNT(*) FROM #__session WHERE guest=1');
			$guest_count = $this->db->loadResult();
			
			$query = 'SELECT a.id, a.username' .
						' FROM #__session AS s INNER JOIN ##__users AS a ON s.userid=a.jos_id' .
						' WHERE client_id = 0 AND s.guest=0';

			$this->db->setQuery($query);
			$sessions = $this->db->loadObjectList();

			if (count($sessions)) {
			    foreach ($sessions as $session) {
					$user_array[] = array('id' => $session->id, 'name' => $session->username);
				}
			}

			$result      = array();
			$result['users']  = $user_array;
			$result['user_count']  = count($user_array);
			$result['guest_count'] = $guest_count;

			return $result;
		}

	};
?>