<?php
	defined ('IN_AGORA') or die;

	class JoomunityModel extends Model
	{
		function getJoomunityAvatar($jos_id)
		{
			$this->db->setQuery('SELECT user_picture FROM #__joom_users WHERE user_id = '.intval($jos_id));
			return $this->db->loadResult();
		}
	}
?>
