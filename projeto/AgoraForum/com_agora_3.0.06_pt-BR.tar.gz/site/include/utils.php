<?php

	function ainclude($path)
	{
		$path = str_replace('|', DS, $path);
		if (stristr($path,'.php') !== '.php') {
			$path .= '.php';
		}
		if (is_file(AGORA_CURRENT_PATH.$path)) {
			include_once(AGORA_CURRENT_PATH.$path);
		} elseif (is_file(AGORA_PATH.$path)) {
			include_once(AGORA_PATH.$path);
		}

	}

	function parseTree($data,$parent_id=0, $level = 0, $id='id', $parent = 'parent_id', $preserve_key = false)
	{
		$result = array();
		
		foreach ($data as $key => $item) {
			if ($item[$parent] == $parent_id) {
				$item['level'] = $level;
				if ($preserve_key) {
					$result[$key] = $item;
				} else {
					$result[] = $item;
				}
				$children = parseTree($data, $item[$id], $level + 1, $id, $parent, $preserve_key);
//				var_dump($children);
//				$result = array_merge($result,$children);
				$result += $children;
			}
		}
		return $result;
	}

	// to test parseTree
	// TODO: remove in final version
/*	$test_data = array(
		array('id'=>1, 'parent_id'=>0, 'name'=>'test1'),
		array('id'=>2, 'parent_id'=>0, 'name'=>'test2'),
		array('id'=>3, 'parent_id'=>0, 'name'=>'test3'),
		array('id'=>4, 'parent_id'=>1, 'name'=>'test1.1'),
		array('id'=>5, 'parent_id'=>1, 'name'=>'test1.2'),
		array('id'=>6, 'parent_id'=>1, 'name'=>'test1.3'),
		array('id'=>7, 'parent_id'=>2, 'name'=>'test2.1'),
		array('id'=>8, 'parent_id'=>2, 'name'=>'test2.2'),
		array('id'=>9, 'parent_id'=>2, 'name'=>'test2.3'),
		array('id'=>10, 'parent_id'=>4, 'name'=>'test1.1.1'),
		array('id'=>11, 'parent_id'=>4, 'name'=>'test1.1.2'),
	);

	$test_data = parseTree($test_data);
	var_dump($test_data);
	die;*/
?>
