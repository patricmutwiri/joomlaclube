<?php

class AgoraDatabase extends AgoraCommonDatabase
{
	function AgoraDatabase($prefix)
	{
		overload('AgoraDatabase');
		parent::__construct($prefix);
	}

	function __call($name,$args, & $return)
	{
		$return = call_user_func_array(array($this->_db,$name),$args);
		return true;
	}

}

?>
