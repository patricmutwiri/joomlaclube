<?php
	defined('IN_AGORA') or die;
	
	class AgoraMailer
	{
		function notifyPost($post_id, & $smarty)
		{
			
		}
	}
?>