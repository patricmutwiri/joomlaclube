<?php
	defined('IN_AGORA') or die;

	class AgoraParser
	{
		var $spoiler_level;
		var $new_window_link;
		
		function sm_parse_start($string){
			$this->spoiler_level;
			$this->spoiler_level = 0;

			$text = array('first' => '', 'current' => $string);
			//$t=microtime();
			if (strpos($string, '[spoiler]') !== false)
				$text = $this->parse_msg($text);
			else
				$text['first'] = $text['current'];
			//echo "elapsed time = ".((microtime()-$t)*1000)." ms";
			return $text['first'];
		}

		function bbcode($text, $new_window = 1, $enable_img = 1)
		{
			$this->new_window_link = $new_window;
			$this->enable_img = $enable_img;

			static $replace, $pattern, $code_pattern, $code_replace;

			if (!isset($replace) || !isset($pattern)) {
				include('parser_patterns.php');
			}

			$text = preg_replace($code_pattern, $code_replace, $text);

			if (strpos($text, 'quote') !== false)
			{
				$text = $this->sm_parse_start($text);
				$text = str_replace('[quote]', '<blockquote><div class="incqbox">', $text);
				$text = preg_replace('#\[quote=(&quot;|"|\'|)(.*)\\1\]#seU', '"<blockquote><div class=\"incqbox\"><h4>".str_replace(array(\'[\', \'\\"\'), array(\'&#91;\', \'"\'), \'$2\')." ".Agora::lang(\'wrote\').":</h4>"', $text);
				$text = preg_replace('#\[\/quote\]\s*#', '</div></blockquote>', $text);
			}
			
			if (strpos($text, 'spoiler') !== false)
			{
				$text = str_replace('[spoiler]', '<div class="slideContainer"><div class="toolbar">&nbsp;'.Agora::lang('Spoiler').'&nbsp;<a href="#" class="ShowHidden"><img src="'.Agora::getRoot().'img/agoraBBCode/warn_add.gif" border="0" alt="Show Spoiler"/></a> / <a href="#" class="HideHidden"><img src="'.Agora::getRoot().'img/agoraBBCode/warn_minus.gif" border="0" alt="Hide Spoiler" /></a></div><div class="SlideText">'.""."&nbsp;", $text);

				$text = preg_replace('#\[\/spoiler\]\s*#', "</div></div>", $text);
			}
			
			$text = preg_replace($pattern, $replace, $text);

			$space_pattern = array("\n", "\t", '  ', '  ');
			$space_replace = array('<br />', '&nbsp; &nbsp; ', '&nbsp; ', ' &nbsp;');
			$text = str_replace($space_pattern, $space_replace, $text);
			
			$text = ' '.$text;

			$text = preg_replace('#([\s\(\)])(https?|ftp|news){1}://([\w\-]+\.([\w\-]+\.)*[\w]+(:[0-9]+)?(/[^"\s\(\)<\[]*)?)#ie', '\'$1\'.$this->handle_url_tag(\'$2://$3\')', $text);
			$text = preg_replace('#([\s\(\)])(www|ftp)\.(([\w\-]+\.)*[\w]+(:[0-9]+)?(/[^"\s\(\)<\[]*)?)#ie', '\'$1\'.$this->handle_url_tag(\'$2.$3\', \'$2.$3\')', $text);


			return $text;
		}

		function smilies($text)
		{
			static $smiley_text, $smiley_img;

			if (!isset($smiley_text)) {
				$model = Model::getInstance('SmiliesModel');
				$smilies = $model->loadAll();

			    $smiley_text = array();
				$smiley_img = array();

				foreach ($smilies as $db_smilies)
				{
					$smiley_text_array = array($db_smilies['text']);
					$smiley_text = array_merge($smiley_text, $smiley_text_array);

					$smiley_img_array = array($db_smilies['image']);
					$smiley_img = array_merge($smiley_img, $smiley_img_array);
				}

			}

			$text = ' '.$text.' ';

			$num_smilies = count($smiley_text);
			for ($i = 0; $i < $num_smilies; ++$i)
				$text = preg_replace("#(?<=.\W|\W.|^\W)".preg_quote($smiley_text[$i], '#')."(?=.\W|\W.|\W$)#m", '$1<img src="'.Agora::getRoot().'/img/smilies/'.$smiley_img[$i].'"  alt="'.substr($smiley_img[$i], 0, strrpos($smiley_img[$i], '.')).'" />$2', $text);

			return substr($text, 1, -1);
		}

		function parse_msg($text)
		{
			//while ($text['current'] != '' && !look_ahead($text, '[/quote]') && !look_ahead($text, '[/code]') && !look_ahead($text, '[/spoiler]')){
			while ($text['current'] != '' && !look_ahead($text, '[/quote]') && !look_ahead($text, '[/spoiler]')) {
				if (look_ahead($text, '[quote]'))
					$text = parse_quote($text);
				else if (look_ahead($text, '[quote='))
					$text = parse_quote_auth($text);
				else if (look_ahead($text, '[spoiler]'))
					$text = parse_spoiler($text);
				else
					$text = invmatch($text, array('[quote]','[quote=','[/quote]','[spoiler]','[/spoiler]'));
			}
			return $text;
		}

		function parse_quote($text)
		{
			$text = match($text, '[quote]');
			$text = $this->parse_msg($text);
			$text = match($text, '[/quote]');
			return $text;
		}

		function parse_quote_auth($text){
			global $spoiler_level;
			// $spoiler_level cannot be larger than 1 anyways, since spoiler tags
			// can currently not be nested (just like code tags).
			if ($spoiler_level){
				$text['current'] = preg_replace('#^\[quote=(&quot;|"|\'|)(.*)\\1\]#seU',
								'"</font></p><blockquote><div class=\"incqbox\"><h4>".str_replace(array(\'[\', \'\\"\'), array(\'&#91;\', \'"\'), \'$2\')." ".Agora::lang(\'wrote\').":</h4><p><font style=\"color:black;background-color:black\">"',
								$text['current']);
				$end_substr = "<font style=\"color:black;background-color:black\">";
				if (strpos($text['current'], $end_substr) !== false){
					$len = strpos($text['current'], $end_substr) + strlen($end_substr);
					$text['first'] .= substr($text['current'], 0, $len);
					$text['current'] = substr_replace($text['current'], '', 0, $len);
				}
				else
					echo "<p><b>Syntax error!</b></p>";
			} else {
				$text = match($text, '[quote=');
			}

			$text = parse_msg($text);
			$text = match($text, '[/quote]');
			return $text;
		}
	}
?>