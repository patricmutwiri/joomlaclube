<?php
	defined( '_JEXEC' ) or die( 'Restricted access' );
	
	function com_uninstall()
	{
		echo JText::_('Uninstalled');
	}
?>
