CREATE TABLE IF NOT EXISTS #__agora_feeds (
	`url` varchar(255) NULL default '',
	`max` int(11) NOT NULL default 0,
	`closed` tinyint(1) NOT NULL default 0,
	`forum_id` int(11) NOT NULL default 0,
	`last_post` INT(10) NOT NULL default 0,
	`num_posts` INT(10) NOT NULL default 0,
	`id` INT(10) unsigned NULL auto_increment,
	PRIMARY KEY  (`id`)
) Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_adsense_config (
	`conf_name` VARCHAR(255) not null default '',
	`conf_value` TEXT,
	PRIMARY KEY (`conf_name`)
) TYPE = MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_bans (
	`id` int(10) unsigned NULL  auto_increment ,
	`username` varchar(200) NULL   ,
	`ip` varchar(255) NULL   ,
	`email` varchar(50) NULL   ,
	`message` varchar(255) NULL   ,
	`expire` int(10) unsigned NULL   ,
	PRIMARY KEY (`id`)
)Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_bans_auto(
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
`points` int(10) NOT NULL,
`message` varchar(255) DEFAULT NULL,
`expire` int(10) NOT NULL DEFAULT 0,
`image` varchar(255) DEFAULT NULL,
`message_txt` text default '',
PRIMARY KEY (`id`)
) Type=MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_categories (
	`id` int(10) unsigned NULL  auto_increment ,
	`cat_name` varchar(80) NOT NULL,
	`disp_position` int(10) NULL  DEFAULT '0' ,
	`enable` BOOLEAN NOT NULL DEFAULT 1,
	PRIMARY KEY (`id`)
)Type=MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_profile_fields (
	`id` int(10) unsigned NOT NULL auto_increment,
	`field_type` smallint(6) NOT NULL,
	`name` varchar(255) NOT NULL,
	`order` int(11) NOT NULL,
	`lang_entry` TEXT,
	PRIMARY KEY  (`id`)
)Type=MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_profile_field_entries (
	`e_id` int(6) NOT NULL auto_increment,
	`f_id` int(6) NOT NULL,
	`value` varchar(255) default NULL,
	`u_id` int(6) NOT NULL,
	PRIMARY KEY  (`e_id`)
)Type=MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_censoring (
	`id` int(10) unsigned NULL  auto_increment ,
	`search_for` varchar(60) NULL   ,
	`replace_with` varchar(60) NULL   ,
	PRIMARY KEY (`id`)
)Type=MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_config (
	`conf_name` varchar(255) NULL   ,
	`conf_value` text NULL   ,
	PRIMARY KEY (`conf_name`)
)Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_forums (
	`id` int(10) unsigned NULL  auto_increment ,
	`enable` BOOLEAN NOT NULL DEFAULT 1,
	`forum_name` varchar(80) NOT NULL,
	`forum_desc` text NULL   ,
	`forum_mdesc` TEXT,
	`forum_key` TEXT,
	`redirect_url` varchar(100) NULL   ,
	`moderators` text NULL   ,
	`num_topics` mediumint(8) unsigned NULL  DEFAULT '0' ,
	`num_posts` mediumint(8) unsigned NULL  DEFAULT '0' ,
	`last_post` int(10) unsigned NULL   ,
	`last_post_id` int(10) unsigned NULL   ,
	`last_poster` varchar(200) NULL   ,
	`sort_by` tinyint(1) NULL  DEFAULT '0' ,
	`disp_position` int(10) NULL  DEFAULT '0' ,
	`cat_id` int(10) unsigned NULL  DEFAULT '0' ,
	`parent_forum_id` int(10) unsigned NULL  DEFAULT '0' ,
	PRIMARY KEY (`id`),
	KEY(`enable`),
	KEY(`last_post`)
)Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_messages (
	`id` int(10) unsigned NULL  auto_increment ,
	`owner` int(10) NULL  DEFAULT '0' ,
	`subject` varchar(120) NULL  DEFAULT '0' ,
	`message` text NULL   ,
	`sender` varchar(120) NULL   ,
	`sender_id` int(10) NULL  DEFAULT '0' ,
	`posted` int(10) NULL  DEFAULT '0' ,
	`sender_ip` varchar(120) NULL   ,
	`smileys` tinyint(4) NULL  DEFAULT '1' ,
	`status` tinyint(4) NULL  DEFAULT '0' ,
	`showed` tinyint(4) NULL  DEFAULT '0' ,
	PRIMARY KEY (`id`)
)Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_polls (
	`id` int(11) NOT NULL  auto_increment ,
	`pollid` int(11) NOT NULL  DEFAULT '0' ,
	`options` longtext NOT NULL ,
	`voters` longtext NOT NULL ,
	`ptype` tinyint(4) NOT NULL  DEFAULT '0' ,
	`votes` longtext NOT NULL   ,
	`created` INT UNSIGNED NOT NULL,
	`edited` INT UNSIGNED NOT NULL DEFAULT 0,
	PRIMARY KEY (`id`)
)Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_posts (
	`id` int(10) unsigned NULL  auto_increment ,
	`poster` varchar(200) NULL   ,
	`poster_id` int(10) unsigned NULL  DEFAULT '1' ,
	`poster_ip` varchar(15) NULL   ,
	`poster_email` varchar(50) NULL   ,
	`message` text NULL   ,
	`hide_smilies` tinyint(1) NULL  DEFAULT '0' ,
	`posted` int(10) unsigned NULL  DEFAULT  '0' ,
	`edited` int(10) unsigned NULL   ,
	`edited_by` varchar(200) NULL   ,
	`topic_id` int(10) unsigned NULL  DEFAULT '0' ,
	`userimage` varchar(144) NOT NULL ,
	PRIMARY KEY (`id`) ,
	KEY `#__agora_posts_topic_id_idx` (`topic_id`) ,
	KEY `#__agora_posts_multi_idx` (`poster_id`,`topic_id`) ,
	FULLTEXT KEY `message_fulltext_search` (`message`)
)Type=MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_ranks (
	`id` int(10) unsigned NULL  auto_increment ,
	`rank` varchar(50) NULL   ,
	`min_posts` mediumint(8) unsigned NULL  DEFAULT '0' ,
	`image` varchar(50) DEFAULT '' ,
	`user_type` varchar(50) DEFAULT '' ,
	PRIMARY KEY (`id`)
)Type=MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_ratings (
	`rate` TINYINT(2) NULL ,
	`user_id` INT(10) UNSIGNED NULL   ,
	`topic_id` INT(10) UNSIGNED NULL
)Type=MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_reports (
	`id` int(10) unsigned NULL  auto_increment ,
	`post_id` int(10) unsigned NULL  DEFAULT '0' ,
	`topic_id` int(10) unsigned NULL  DEFAULT '0' ,
	`forum_id` int(10) unsigned NULL  DEFAULT '0' ,
	`reported_by` int(10) unsigned NULL  DEFAULT '0' ,
	`created` int(10) unsigned NULL  DEFAULT '0' ,
	`message` text NULL   ,
	`zapped` int(10) unsigned NULL   ,
	`zapped_by` int(10) unsigned NULL   ,
	PRIMARY KEY (`id`) ,
	KEY `#__agora_reports_zapped_idx` (`zapped`)
)Type=MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_reputation (
	`id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`user_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
	`from_user_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
	`time` INT(10) UNSIGNED NOT NULL DEFAULT 0,
	`post_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
	`reason` TEXT NOT NULL,
	`rep_plus` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
	`rep_minus` TINYINT(1) UNSIGNED NOT NULL  DEFAULT 0,
	`topics_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
	PRIMARY KEY (`id`)
	)TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_smilies (
	`id` INT( 10 ) NOT NULL AUTO_INCREMENT ,
	`image` VARCHAR(60) NOT NULL  DEFAULT '',
	`text` VARCHAR(60) NOT NULL  DEFAULT '',
	PRIMARY KEY (`Id`)
)Type=MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_subscriptions (
	`user_id` int(10) unsigned NULL  DEFAULT '0' ,
	`topic_id` int(10) unsigned NULL  DEFAULT '0' ,
	`forum_id` int(10) unsigned NULL  DEFAULT '0' ,
	`category_id` int(10) unsigned NULL  DEFAULT '0' ,
	PRIMARY KEY (`user_id`,`topic_id`,`forum_id`, `category_id`)
)Type=MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_topics (
	`id` int(10) unsigned NULL  auto_increment ,
	`poster` varchar(200) NULL   ,
	`subject` varchar(255) NULL   ,
	`descrip_t` VARCHAR(255),
	`posted` int(10) unsigned NULL  DEFAULT '0' ,
	`last_post` int(10) unsigned NULL  DEFAULT '0' ,
	`last_post_id` int(10) unsigned NULL  DEFAULT '0' ,
	`last_poster` varchar(200) NULL   ,
	`num_views` mediumint(8) unsigned NULL  DEFAULT '0' ,
	`num_replies` mediumint(8) unsigned NULL  DEFAULT '0' ,
	`closed` tinyint(1) NULL  DEFAULT '0' ,
	`sticky` tinyint(1) NULL  DEFAULT '0' ,
	`moved_to` int(10) unsigned NULL   ,
	`forum_id` int(10) unsigned NULL  DEFAULT '0' ,
	`announcements` TINYINT(1) NOT NULL DEFAULT '0',
	`question` varchar(255) NULL   ,
	`yes` varchar(30) NULL   ,
	`no` varchar(30) NULL   ,
	`icon_topic` BOOLEAN NOT NULL DEFAULT 0,
	PRIMARY KEY (`id`) ,
	KEY `#__agora_topics_forum_id_idx` (`forum_id`) ,
	KEY `#__agora_topics_moved_to_idx` (`moved_to`) ,
	FULLTEXT KEY `subject_fulltext_search` (`subject`)
)Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_users (
	`id` int(10) unsigned NULL  auto_increment ,
	`jos_id` int(10) NOT NULL,
	`group_id` int(10) unsigned NULL  DEFAULT '4' ,
	`username` varchar(200) NULL,
	`imgaward` VARCHAR( 255 ) NOT NULL,
	`email` varchar(50) NULL   ,
	`title` varchar(50) NULL   ,
	`url` varchar(100) NULL   ,
	`jabber` varchar(75) NULL   ,
	`icq` varchar(12) NULL   ,
	`msn` varchar(50) NULL   ,
	`aim` varchar(30) NULL   ,
	`yahoo` varchar(30) NULL   ,
	`skype` varchar(30) NULL   ,
	`xfire` varchar(30) NULL   ,
	`location` varchar(30) NULL   ,
	`use_avatar` BOOLEAN NULL  DEFAULT 0,
	`signature` text NULL   ,
	`disp_topics` tinyint(3) unsigned NULL   ,
	`disp_posts` tinyint(3) unsigned NULL   ,
	`notify_with_post` tinyint(1) NULL  DEFAULT '0' ,
	`show_smilies` tinyint(1) NULL  DEFAULT '1' ,
	`show_img` tinyint(1) NULL  DEFAULT '1' ,
	`show_img_sig` tinyint(1) NULL  DEFAULT '1' ,
	`show_avatars` tinyint(1) NULL  DEFAULT '1' ,
	`show_sig` tinyint(1) NULL  DEFAULT '1' ,
	`style` varchar(25) NULL  DEFAULT 'Olympus' ,
	`num_posts` int(10) unsigned NULL  DEFAULT '0' ,
	`last_post` int(10) unsigned NULL   ,
	`registered` int(10) unsigned NULL  DEFAULT '0' ,
	`last_visit` int(10) unsigned NULL  DEFAULT '0' ,
	`reverse_posts` BOOLEAN NOT NULL DEFAULT 0,
	`admin_note` varchar(30) NULL   ,
	`reputation_enable` BOOLEAN NOT NULL DEFAULT FALSE,
	`rep_minus` INT(11) UNSIGNED NOT NULL DEFAULT 0,
	`rep_plus` INT(11) UNSIGNED NOT NULL DEFAULT 0,
	`latitude` VARCHAR (100) NULL DEFAULT NULL,
	`longitude` VARCHAR (100) NULL DEFAULT NULL,
	`gender` int(1) NOT NULL default '0',
	`birthday` int(10) NULL default '0',
	`hide_age` BOOLEAN NOT NULL default FALSE,
	`interests` varchar(255) NOT NULL default '',
	`aboutme` text NOT NULL,
	`ignore_mode` TINYINT(1) NOT NULL DEFAULT '1',
	`ignored_users` VARCHAR(255) NULL,
	`auto_subscriptions` tinyint(1) NULL  DEFAULT '1',

	PRIMARY KEY (`id`) ,
	KEY `#__agora_users_registered_idx` (`registered`) ,
	KEY `#__agora_users_username_idx` (`username`(8))
)Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_read_posts
(
`id` int(10) unsigned NOT NULL auto_increment,
`read_time` int(10) unsigned,
`user_id` int(10) NOT NULL,
`topic_id` int(10) NOT NULL,
PRIMARY KEY(`id`),
UNIQUE (user_id, topic_id)
) Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_permissions
(
`id` int(10) unsigned NOT NULL auto_increment,
`read`				BOOL NOT NULL DEFAULT 1,
`bbcode`			BOOL NOT NULL DEFAULT 1,
`bbcode_img`		BOOL NOT NULL DEFAULT 1,
`read_rss`			BOOL NOT NULL DEFAULT 1,
`post_reply`		BOOL NOT NULL DEFAULT 1,
`post_poll`			BOOL NOT NULL DEFAULT 1,
`post_topic`		BOOL NOT NULL DEFAULT 1,
`edit_topic`		BOOL NOT NULL DEFAULT 1,
`edit_posts`		BOOL NOT NULL DEFAULT 1,
`delete_topics`		BOOL NOT NULL DEFAULT 1,
`delete_posts`		BOOL NOT NULL DEFAULT 1,
`make_sticky`		BOOL NOT NULL DEFAULT 1,
`close_topic`		BOOL NOT NULL DEFAULT 1,
`use_captcha`		BOOL NOT NULL DEFAULT 0,
PRIMARY KEY(`id`)
) Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_group
(
`id` int(10) unsigned NOT NULL auto_increment,
`name` varchar(255) NOT NULL,
`parent_id` int(10) unsigned NOT NULL DEFAULT 0,
`caps_message`		BOOL NOT NULL DEFAULT 1,
`caps_subject`		BOOL NOT NULL DEFAULT 1,
`sig_smilies`		BOOL NOT NULL DEFAULT 1,
`sig_bbcode`		BOOL NOT NULL DEFAULT 1,
`sig_bbcode_img`	BOOL NOT NULL DEFAULT 1,
`sig_caps`			BOOL NOT NULL DEFAULT 1,
`sig_length`		int(10) NOT NULL DEFAULT 400,
`sig_lines`			int(10) NOT NULL DEFAULT 4,
`search`			BOOL NOT NULL DEFAULT 1,
`search_users`		BOOL NOT NULL DEFAULT 1,
`pm`				BOOL NOT NULL DEFAULT 1,
`pm_limit`			int(10) NOT NULL DEFAULT 20,
`rep`				BOOL NOT NULL DEFAULT 1,
`rep_minus_min`		int(10) unsigned NOT NULL DEFAULT 10,
`rep_plus_min`		int(10) unsigned NOT NULL DEFAULT 10,
PRIMARY KEY(`id`)
) Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_roles
(
`id` int(10) unsigned NOT NULL auto_increment,
`name` varchar(255) NOT NULL,
PRIMARY KEY(`id`)
) Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_group_permissions
(
`id` int(10) unsigned NOT NULL auto_increment,
`group_id` int(10) unsigned NOT NULL,
`role_id` int(10) unsigned NOT NULL,
`access_id` int(10) unsigned NOT NULL,
PRIMARY KEY(`id`),
UNIQUE(`group_id`,`role_id`),
UNIQUE(`access_id`)
) Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_user_group
(
`id` int(10) unsigned NOT NULL auto_increment,
`user_id` int(10) unsigned NOT NULL,
`group_id` int(10) unsigned NOT NULL,
`role_id` int(10) unsigned NOT NULL,
PRIMARY KEY(`id`),
UNIQUE(`user_id`,`group_id`)
) Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_group_forum
(
`id` int(10) unsigned NOT NULL auto_increment,
`group_id` int(10) unsigned NOT NULL,
`forum_id` int(10) unsigned NOT NULL,
`role_id`  int(10) unsigned NOT NULL,
`access_id` int(10) unsigned NOT NULL,
PRIMARY KEY(`id`),
UNIQUE(`group_id`,`forum_id`,`role_id`)
) Type=MyISAM;

CREATE TABLE IF NOT EXISTS #__agora_warning (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
`points` int(10) NOT NULL,
`message` varchar(255) DEFAULT NULL,
`expire` int(10) NOT NULL DEFAULT 0,
`image` varchar(255) DEFAULT NULL,
`message_txt` text default '',
PRIMARY KEY (`id`)
) Type=MyISAM;


CREATE TABLE IF NOT EXISTS #__agora_user_warning (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
`user_id` int(10) NOT NULL,
`warning_id` int(10) NOT NULL,
`message` varchar(255) NOT NULL,
`posted` int(10) NOT NULL,
`expire` int(10) NOT NULL,
PRIMARY KEY (`id`)
) Type=MyISAM;