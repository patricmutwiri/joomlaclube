<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraAdminController
	{
		function loadModel()
		{
			$this->model = Model::getInstance('BanModel');
		}
		function _default()
		{
			$this->view->template = 'configuration/bans/list';

			$this->setPagination($this->model->loadAllCount());
			$bans = $this->model->loadAll('',$this->pagination->per_page,$this->pagination->page);

			$this->view->assignRef('bans',$bans);
		}

		function add_ip()
		{
			$this->view->template = 'configuration/bans/add_ip';
		}

		function add_user()
		{
			$this->view->template = 'configuration/bans/add_user';

		}

		function cancel()
		{
			$this->redirect();
		}

		function edit()
		{
			$cid = Agora::getPostVar('cid');
			$id = array_shift($cid);

			$ban = $this->model->load($id);
			$ban['expire'] = getdate($ban['expire'] - AGORA_TIME - intval(date('Z')));

			$this->view->assignRef('ban',$ban);
			$ban['ip'] = explode('.', $ban['ip']);
			$this->view->template = 'configuration/bans/edit_user';
		}

		function save()
		{
			$form = Agora::getPostVar('form');
			if ($form['ip']) {
				// Ban by IP
				array_map(intval, $form['ip']);
				$form['ip'] = implode('.', $form['ip']);
			}
            if ($form['username'])
			{
				$user_model = & Model::getInstance('UserModel');
				if (!$user_model->exists($form['username'],'username')) {
					Agora::showError('Username not found');
					$this->view->template = 'configuration/bans/add_user';
					return;
				}
			}
			if ($form['email'])
			{
				$user_model = & Model::getInstance('UserModel');
				if (!$user_model->exists($form['email'],'email')) {
					Agora::showError('Email not found');
					$this->view->template = 'configuration/bans/add_user';
					return;
				}
			    
			}

			$e = & $form['expire'];
			$expire = intval($e['days'])*3600 * 24 + intval($e['hours']) * 3600 + intval($e['minutes']) * 60;
			$form['expire'] = AGORA_TIME + $expire;

			if (isset($form['id'])) {
				$this->model->edit($form['id'],$form);
			} else {
				$this->model->add($form);
			}

			$this->redirect();
		}

		function remove()
		{
			$cid = Agora::getPostVar('cid');
			foreach ($cid as $id) {
				$this->model->delete($id);
			}
			$this->redirect();
		}
	}
?>
