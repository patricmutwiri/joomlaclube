<?php
	include('smilies.php');
?>
