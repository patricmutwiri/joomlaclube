<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraAdminController
	{
		function loadModel()
		{
			$this->model = Model::getInstance('AutobanModel');
		}
		function _default()
		{
			$this->view->template = 'configuration/autobans/autoban';
			$this->setPagination($this->model->loadAllCount());
			$bans = $this->model->loadAll('',$this->pagination->per_page,$this->pagination->page);
			foreach ($bans as $key=>$ban) {
				$bans[$key]['expire'] = getdate($ban['expire'] - intval(date('Z')));
			}
			$this->view->assignRef('warnings',$bans);
		}

		function add()
		{
			$this->view->template = 'configuration/autobans/add_autoban';

		}

		function edit()
		{
			$this->view->template = 'configuration/autobans/edit_autoban';
			$cid = Agora::getPostVar('cid');
			$id = array_shift($cid);
            
			$ban = $this->model->load($id);
			$ban['expire'] = getdate($ban['expire'] - intval(date('Z')));
			$this->view->assign('warning',$ban);
		}

		function save()
		{
			$form = Agora::getPostVar('form');

			$e = & $form['expire'];
			$expire = intval($e['days'])*3600 * 24 + intval($e['hours']) * 3600 + intval($e['minutes']) * 60;
			$form['expire'] = $expire;

			if (isset($form['id'])) {
				$this->model->edit($form['id'],$form);
			} else {
				$this->model->add($form);
			}

			$this->redirect();
		}

		function remove()
		{
			$cid = Agora::getPostVar('cid');
			foreach ($cid as $id) {
				$this->model->delete($id);
			}
			$this->redirect();
		}

	}
		if (Agora::getRequestVar('part','bans') === 'warnings') {
		ainclude('controller|configuration|bans|warnings');
	} else {
		ainclude('controller|configuration|bans|bans');
	}
?>
