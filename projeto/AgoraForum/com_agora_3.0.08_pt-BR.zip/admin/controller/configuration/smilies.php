<?php

	defined ('IN_AGORA') or die;

	class TaskController extends AgoraAdminController
	{
		function loadModel()
		{
			$this->model = & Model::getInstance('SmiliesModel');
		}

		function _default()
		{
			$this->view->template='configuration/smilies';

			$this->setPagination($this->model->loadAllCount());

			$smilies = $this->model->loadAll('',$this->pagination->per_page,$this->pagination->page);
			
			$this->view->assign('smilies',$smilies);
		}

		function remove()
		{
			$ids = Agora::getPostVar('cid',array());
			if (!is_array($ids)) {
				Agora::showError('Bad request');
				$this->redirect();
			}

			foreach($ids as $id) {
				$this->model->delete($id);
			}

			$this->redirect();
		}

		function add()
		{
			$this->view->template='configuration/add_smile';
      
      // MH - 20090928 - enumerate the list of images in the img dir
      $this->view->assign( "smileyPath", JURI::root()."components/com_agora/img/smilies/" );
      $this->view->assign( "fileList", $this->enumFiles() );
		}

		function cancel()
		{
			$this->redirect();
		}

		function save()
		{
			$s_id = Agora::getPostVar('id');
			$s_image = Agora::getPostVar('smiley_image','');
			$s_text = Agora::getPostVar('smiley_code','');
      $b_upload = false;
      
      // MH - 20090926 - smiley_image is now a radio field group.
      //      what we need to check for now is either smiley_image or
      //      smiley_upload, if both are null we need to error out.
			if (trim($s_text) == '') {                            // check for code
				Agora::showError('You cannot have blank smilies');
				$this->redirect();
			}

      $b_upload = $this->validateImage();

      // !!! - look for an Agora or Joomla function to access $_FILES array
      // check for a valid image file
      if( $s_image == "" && !$b_upload )
      {
        Agora::showError('Please select a smiley image or upload a valid image.');
				$this->redirect();
      }
      else
      {
        $b_upload;
      }

      // even if an image is selected the upload trumps the selected image
      if( $b_upload )
      {
        $s_image = $_FILES["smiley_upload"]["name"];
        if( !$this->uploadImage() )
        {
          Agora::showError( 'There was an error uploading your file, make sure it is below the 100Kb limit, and is in PNG format.' );
          $this->redirect();
        }
      }

			if ($s_id) {
				$this->model->edit($s_id, array (
						'text'=>$s_text,
						'image'=>$s_image
					));
				
			} else {
        $this->model->add($s_image,$s_text);
			}
			$this->redirect();
		}

		function edit()
		{
			$cid = Agora::getPostVar('cid');
			$id = array_shift($cid);
			$form = $this->model->load($id);
			$this->view->assign('form',$form);
      
      // MH - 20090928 - enumerate the list of images in the img dir
      $this->view->assign( "smileyPath", JURI::root()."components/com_agora/img/smilies/" );
      $this->view->assign( "fileList", $this->enumFiles() );

			$this->view->template = 'configuration/edit_smile';
		}

    //MH - 20090925 - new utility functions specific to this piece of the smilies component
    // generate a list of files
    function enumFiles()
    {
      jimport( 'joomla.filesystem.*' );
      return JFolder::files( JPATH_COMPONENT_SITE.DS."img".DS."smilies".DS,".png|.gif|.jpg|.jpeg" );
    }
    
    // validate the image data
    function validateImage()
    {
      $aUserFile = JRequest::getVar( 'smiley_upload', null, 'files', 'array' );
      // do we even have a specified file
      if( $aUserFile['size'] <= 0     || 
          $aUserFile['size'] > 100000 ||
          $aUserfile['error'] )
      {
        return false;
      }
      
      // we are going to only allow pngs, gifs, and jpegs
      if( $aUserFile['type'] != "image/gif" &&
          $aUserFile['type'] != "image/jpeg" &&
          $aUserFile['type'] != "image/png" && 
          $aUserFile['type'] != "image/x-png" )
      {
        return false;
      }
      
      return true;
    }

    // upload image for new smiley
    function uploadImage()
    {
      jimport( 'joomla.filesystem.*' );

      $aUserFile = JRequest::getVar( 'smiley_upload', null, 'files', 'array' );
      
      // Build the appropriate paths - not sure this is the best method
      $s_dest = JPATH_COMPONENT_SITE.DS."img".DS."smilies".DS.$aUserFile['name'];
      $s_src  = $aUserFile['tmp_name'];
      
      // Write the file $tmp_src in $tmp_dest folder
      if(move_uploaded_file($s_src, $s_dest)) 
      {
         return true;
      }
      else
      {
         return false;   
      }

      return true;
    }
	}

?>
