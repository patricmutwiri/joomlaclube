<?php
class TaskController extends AgoraAdminController
{
	function _default()
	{
		$this->view->assign('current_version',AGORA_VERSION);
		$this->view->template = 'index';
	}
}

?>
