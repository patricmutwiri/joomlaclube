<?php

	defined ('IN_AGORA') or die;

	class TaskController extends AgoraAdminController
	{

		function loadModel()
		{
			$this->model = & Model::getInstance('StylesModel');
		}

		function _default()
		{
			$this->view->template='maintenance/css_editor';
			$styles = $this->model->loadAll();

			$style = Agora::getVar('style',$styles[0]);

			$this->view->assign('styles',$styles);
			$this->view->assign('current_style',$style);

			$style = $this->model->getStyle($style);
			$this->view->assign('style',$style);
		}

		function save()
		{
			$content = Agora::getPostVar('form');

			$styles = $this->model->loadAll();
			$style = Agora::getVar('style',$styles[0]);

			if (!is_null($content) && !empty($content)) {
				if (!$this->model->saveStyle($style,$content)) {
					Agora::showError('Unable to save CSS files. Check permissions');
				}
			}
			$this->redirect('style');
		}
	}
?>
