<?php
  include('polls.php');
?>