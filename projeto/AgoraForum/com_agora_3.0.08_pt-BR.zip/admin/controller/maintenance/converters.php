<?php

	defined ('IN_AGORA') or die;

	class TaskController extends AgoraAdminController
	{
		function loadModel()
		{
			$this->model = Model::getInstance('ConvertersModel');
		}
			    
		function _default()
		{
			$this->view->template = 'maintenance/converters';
		}

		
		function kunena()
		{ 	
		    $this->model->start();
		    $this->model->export_users_kunena();
		    $this->model->export_forums_kunena();
		    $this->model->export_posts_kunena();
		    $this->model->end();
		    
			$this->view->template = 'maintenance/converters';
		}
		
		function ccboard()
		{ 	

		    $this->model->start();
		    $this->model->export_users_ccboard();
		    $this->model->export_forums_ccboard();
		    $this->model->export_posts_ccboard();
		    $this->model->end();
		    
			$this->view->template = 'maintenance/converters';
		}
		
		function sforum()
		{ 	

		    $this->model->start('sf');
		    $this->model->export_users_sforum();
		    $this->model->export_forums_sforum();
		    $this->model->export_posts_sforum();
		    $this->model->end();
		    
			$this->view->template = 'maintenance/converters';
		}
		
		function joobb()
		{ 	

		    $this->model->start();
		    $this->model->export_users_joobb();
		    $this->model->export_forums_joobb();
		    $this->model->export_posts_joobb();
//		    $this->model->end();
		    
			$this->view->template = 'maintenance/converters';
		}		
	}
?>