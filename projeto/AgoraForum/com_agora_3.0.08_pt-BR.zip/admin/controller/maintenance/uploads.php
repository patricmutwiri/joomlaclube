<?php
defined ('IN_AGORA') or die;

class TaskController extends AgoraAdminController
{
/*		function __construct()
		{
		}*/

	function loadModel()
	{
		$this->model = & Model::getInstance('UploadModel');
		$config_model = & Model::getInstance('ConfigModel');
		$this->agora_config = $config_model->load();
	}

	function sort()
	{
		$this->redirect('filter_order','filter_order_Dir', 'filename_filter');
	}

	function __sort_uploads($a, $b)
	{
/*		if ($b->username == $a->username) return 0;
		return ($a->username < $b->username) ? -1 : 1;*/
		$r = strcmp($a['name'],$b['name']);
		if ($this->sort_dir == 'asc') {
			$r = -$r;
		}
		return $r;
	}

	function _default()
	{
		$user_model = & Model::getInstance('UserModel');
		$users = $user_model->loadAll();
		$this->view->template = 'maintenance/uploads';

		$uploads = array();
		$allowed_extensions = $this->agora_config['o_uploadile_laws'];

		$filename_filter = Agora::getVar('filename_filter','');
		foreach ($users as $user) {
			$user_uploads = $this->model->loadUser($user['id'],$allowed_extensions);

			foreach ($user_uploads as $upload) {
				if (!preg_match('/.*'.preg_quote($filename_filter,'/').'.*/',$upload['name'])) continue;
				
				$uploads[] = array(
						'user_id' 	=> $user['id'],
						'user_name' => $user['username'],
						'upload_id' => $user['id'].'_'.$upload['id'],
						'size' 		=> $upload['size'],
						'mini' 		=> $upload['mini'],
						'path' 		=> $upload['path'],
						'name' 		=> $upload['name']
				);
			}
		}

		$this->sort_dir = Agora::getVar('filter_order_Dir','asc');
		$this->sort_field = Agora::getVar('filter_order','username');

		usort($uploads,array($this,'__sort_uploads'));

		$this->view->assign('filename_filter',$filename_filter);
		$this->view->assign('sort_dir',$this->sort_dir);
		$this->view->assignRef('uploads',$uploads);
	}

	function remove()
	{
		$cid = Agora::getPostVar('cid');
		$uploads = array();
		foreach ($cid as $id) {
			list($user_id,$upload_id) = explode('_',$id);
			$uploads[$user_id][] = $upload_id;
		}

		$allowed_extensions = $this->agora_config['o_uploadile_laws'];
		foreach ($uploads as $user_id=>$upload_list) {
			$this->model->deleteList($user_id,$upload_list, $allowed_extensions);
		}

		$this->redirect();
	}

}
?>
