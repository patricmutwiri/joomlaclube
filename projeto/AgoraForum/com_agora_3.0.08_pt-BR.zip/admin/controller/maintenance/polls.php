<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraAdminController
	{
		function loadModel()
		{
			$this->model = & Model::getInstance('PollModel');
		}
		function _default()
		{
			$count = $this->model->getCount();
			$pages = ceil(($count+1) / 20);
			$polls = $this->model->loadAll(20,Agora::getPage($pages));
			$this->view->assign('polls',$polls);
			$this->view->template = 'maintenance/polls';
		}

/*		function edit()
		{
			$id = Agora::getVar('id');
			$poll = $this->model->load($id);
			$poll['num_options'] = count($poll['options']);
			$this->view->assign('poll',$poll);

			switch (intval($poll['ptype'])) {
				case 1: $this->view->template = 'maintenance/polls/edit_regular'; break;
				case 2: $this->view->template = 'maintenance/polls/edit_multi'; break;
				case 3: $this->view->template = 'maintenance/polls/edit_multi_yesno'; break;
				default:
					Agora::showError(Agora::lang('Invalid poll type'));
					$this->redirect();
			}
		}*/

		function remove()
		{
			$cid = Agora::getPostVar('cid');
			foreach ($cid as $id) {
				$this->model->delete($id);
			}
			
			$this->redirect();
		}

		function reset()
		{
			$cid = Agora::getPostVar('cid');
			foreach ($cid as $id) {
				$this->model->resetVotes($id);
			}
			$this->redirect();
		}

/*		function saveRegular()
		{
			$id = Agora::getVar('id');
			$question = Agora::getPostVar('req_question');
			$options = Agora::getPostVar('poll_option');

			foreach ($options as $opt_id=>$option) {
				if (trim($option) === '') unset($options[$opt_id]);
			}

			$this->model->editRegular($id,$question, $options);
			$this->redirect();
		}

		function saveMulti()
		{
			$this->saveRegular();
		}

		function saveMultiYesNo()
		{
			$id = Agora::getVar('id');
			$question = Agora::getPostVar('req_question');
			$options = Agora::getPostVar('poll_option');
			$yes = Agora::getPostVar('poll_yes');
			$no = Agora::getPostVar('poll_no');

			foreach ($options as $opt_id=>$option) {
				if (trim($option) === '') unset($options[$opt_id]);
			}

			$this->model->editMultiYesNo($id,$question, $options, $yes, $no);

			$this->redirect();
		}*/
	}
?>