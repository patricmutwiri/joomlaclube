<?php

class AgoraDatabase extends AgoraCommonDatabase
{
	function __call($name,$args)
	{
		return call_user_func_array(array($this->_db,$name),$args);
	}

}

?>
