<?php
	defined('IN_AGORA') or die;

	class AgoraDispatcher
	{
		function AgoraDispatcher()
		{
			$this->__construct();
		}

		function __construct()
		{
			$this->_vars['task'] = 'index';
			$this->_vars['page'] = null;
			$this->_vars['action'] = null;
		}

		function & getInstance()
		{
			static $inst;

			if (!isset($inst)) {
				$inst = new AgoraDispatcher();
			}
			
			return $inst;
		}

		function getVar($var)
		{
			return isset($this->_vars[$var]) ? $this->_vars[$var] : null;
		}

		function setVar($var,$value)
		{
			$this->_vars[$var] = $value;
			if (!isset($_GET[$var])) {
				$_GET[$var] = $value;
			}
			if (!isset($_REQUEST[$var])) {
				$_REQUEST[$var] = $value;
			}
		}

		function loadController($fs_path,& $path)
		{
/*			if (count($path) === 0) {
				die('Bad request (code 1002)');
			}*/

			if (count($path) > 0) {
				$task = array_shift($path);
			} else {
				$task = 'index';
			}

			if (!is_string($task)) {
				$this->loadController($fs_path, $path);
				return;
			}

			$task = strtolower($task);

			if (is_file($fs_path.'_common.php')) {
				include($fs_path.'_common.php');
			}

			if (is_file($fs_path.$task.'.php')) {
				include($fs_path.$task.'.php');
				return;
			}

			if (is_dir($fs_path.$task)) {
				$this->loadController($fs_path.$task.DS,$path);
				return;
			}

			die('Bad request (code 1003)');
		}

		function route()
		{
			$path = array();

			$path[] = isset($_REQUEST['task']) ? $_REQUEST['task'] : $this->_vars['task'];
			$path[] = isset($_REQUEST['page']) ? $_REQUEST['page'] : $this->_vars['page'];
			$path[] = isset($_REQUEST['action']) ? $_REQUEST['action'] : $this->_vars['action'];


			foreach ($path as $item) {
				if (is_null($item) || empty($item)) {
					continue;
				}

				if (!preg_match('/^[\w]+[\w_\d]+$/',$item)) {
					die('Bad request (code 1001 - Go away)');
				}
			}

			$full_path = $path;

			$this->loadController(AGORA_CURRENT_PATH.'controller'.DS,$path);

			if (!class_exists('TaskController')) {
				die('Bad request (code 1004 - TaskController not found)');
			}

			$controller = new TaskController();

			while (count($path) > 0) {
				$method = array_shift($path);
				if (is_string($method)) break;
			}

			if (!isset($method) || !is_string($method)) {
				$method = 'index';
			}

			if (is_string($method) && method_exists($controller,$method)) {
				$controller->$method();
			} elseif (Agora::isPost() && method_exists($controller,'_save')) {
				$controller->_save();
			} elseif (method_exists($controller,'_default')) {
				$controller->_default();
			}

			if (method_exists($controller,'_execute')) {
				$controller->_execute($method);
			}

		}
	}
	
	function agoraBuildRoute( & $query )
	{
		static $items;

		$segments = array();

		if (!$items) {
			$component	= &JComponentHelper::getComponent('com_agora');
			$menu		= &JSite::getMenu();
			$items		= $menu->getItems('componentid', $component->id);
		}
	
		if (is_array($items)) {
			$query['Itemid'] = $items[0]->id;
		}

		if (isset($query['task'])) {
			$segments[] = $query['task'];
			unset($query['task']);
		} elseif (isset($query['action']) || isset($query['page'])) {
			$segments[] = 'index';
		}

		if (isset($query['page'])) {
			$segments[] = $query['page'];
			unset($query['page']);
		}

		if (isset($query['action'])) {
			$segments[] = $query['action'];
			unset($query['action']);
		}

/*		header('Content-type: text/plain');
		print_r ($query); print_r($segments);die;*/
		return $segments;
	}

	function agoraParseRoute( $segments ) 
	{
		$dispatcher = & AgoraDispatcher::getInstance();

		if (count($segments) > 0) {
			$dispatcher->setVar('task',$segments[0]);
		}

		// task/action
		if (count($segments) == 2) {
			if (isset($_REQUEST['page'])) {
				$dispatcher->setVar('action',$segments[1]);
			} else {
				$dispatcher->setVar('page',$segments[1]);
			}
//			$dispatcher->setVar('page',$segments[1]);
//			$vars['action'] = $segments[1];
		}

		// task/page/action
		if (count($segments) > 2) {
			$dispatcher->setVar('page',$segments[1]);
			$dispatcher->setVar('action',$segments[2]);
//			$vars['action'] = $segments[2];
		}

		return array();
	}
?>
