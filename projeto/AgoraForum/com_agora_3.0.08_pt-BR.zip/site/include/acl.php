<?php
/*	defined ('IN_AGORA') or die;

	class AgoraPermissions
	{
		function getInstance()
		{
			static $instance = NULL;

			if (!$instance) {
				define('AGORA_ROLE_ADMIN',3);
				define('AGORA_ROLE_MODERATOR',2);
				define('AGORA_ROLE_MEMBER',1);
				define('AGORA_ROLE_GUEST',0);
				
				$instance = new AgoraACL();
			}
			return $instance;
		}

	}*/

?>
