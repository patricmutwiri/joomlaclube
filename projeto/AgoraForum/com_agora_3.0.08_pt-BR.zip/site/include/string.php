<?php

    defined ('IN_AGORA') or die;

	class AString extends JString
	{
		function escape($str)
		{
			return htmlspecialchars($str,ENT_QUOTES,'UTF-8');
		}
	}
?>
