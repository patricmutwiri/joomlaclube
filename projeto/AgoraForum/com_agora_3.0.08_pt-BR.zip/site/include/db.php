<?php

class AgoraCommonDatabase
{
	function & getInstance($prefix)
	{
		static $inst;
		if (!isset($inst)) {
			$inst = new AgoraDatabase($prefix);
		}
		return $inst;
	}

	function __construct($prefix)
	{
		$this->_db = & JFactory::getDBO();
		$this->_vars = array();
		$this->_vars_perm = array();
		$this->_names = array();
		$this->_prefix = $this->_db->getPrefix().$prefix;
	}

/*	function __get($var)
	{
		return $this->_db->$var;
	}

	function __set($var, $value)
	{
		$this->_db->$var = $value;
	}*/

	function setQuery($sql,$offset = 0,$limit = 0,$jos_prefix = '#__')
	{
		$this->_vars['##__']=$this->_prefix;
		$this->_vars[$jos_prefix]=$this->_db->getPrefix();

		$sql = str_replace(array_keys($this->_names),array_values($this->_names),$sql);
		$sql = str_replace(array_keys($this->_vars),array_values($this->_vars),$sql);
		$sql = str_replace(array_keys($this->_vars_perm),array_values($this->_vars_perm),$sql);

		$this->_db->_sql = $sql;
		$this->_sql = $sql;
		$this->_db->_limit = (int) $limit;
		$this->_db->_offset = (int) $offset;

		$this->_vars = array();
		$this->_names = array();
	}

	function clear()
	{
		$this->_vars_perm = array();
	}

	function bind($var,$value,$type, $permanent = false)
	{
		if ($type != 'integer') {
			$value = $this->_db->Quote(strval($value));
		} else {
			$value = $this->_db->Quote(intval($value));
		}

		if ($permanent) {
			$this->_vars_perm[':'.$var] = $value;
		} else {
			$this->_vars[':'.$var] = $value;
		}
	}

	function bindList($var,$list,$type, $permanent = false)
	{
		if (!is_array($list)) {
			$list = array($list);
		}

		if ($type != 'integer') {
			$list = array_map('strval',$list);
			$list = array_map(array($this->_db,'Quote'),$list);
		} else {
			$list = array_map('intval',$list);
		}

		if (empty($list)) {
			$values = '\'\'';
		} else {
			$values = implode(',',$list);
		}

		if ($permanent) {
			$this->_vars_perm[':'.$var] = $values;
		} else {
			$this->_vars[':'.$var] = $values;
		}
	}
}

if (floatval(PHP_VERSION) >= 5.0) {
	ainclude('include|db.php5');
} else {
	ainclude('include|db.php4');
}
?>
