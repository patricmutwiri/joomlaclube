<?php
	defined ('IN_AGORA') or die;

/*	$code_pattern = '#\[code\](.*?)\[/code\]#s';
	$code_replace = '<div class="codebox"><div class="incqbox"><h4>'.Agora::lang('Code').':</h4><div class="scrollbox"><pre>$1</pre></div></div></div>';*/

	$pattern = array('#\[b\](.*?)\[/b\]#s',
					 '#\[i\](.*?)\[/i\]#s',
					 '#\[u\](.*?)\[/u\]#s',

					 '#\[url\]([^\[]*?)\[/url\]#e',
					 '#\[url=([^\[]*?)\](.*?)\[/url\]#e',
					 '#\[email\]([^\[]*?)\[/email\]#',
					 '#\[email=([^\[]*?)\](.*?)\[/email\]#',
					 '#\[color=([a-zA-Z]*|\#?[0-9a-fA-F]{6})](.*?)\[/color\]#s',
					 '#\[img\s*(width=\d+\w*)?\s*(height=\d+\w*)?\s*\]((ht|f)tps?://)([^\s<"]*?)\[/img\]#e',
				//++++++++++++++++++++++++++++++++++//
				
					 '#\[s\](.*?)\[/s\]#s',

					 '#\[center\](.*?)\[/center\]#s',
					 '#\[left\](.*?)\[/left\]#s',
					 '#\[right\](.*?)\[/right\]#s',
					 '#\[justify\](.*?)\[/justify\]#s',
					 '#\[indent\](.*?)\[/indent\]#s',

					 '#\[size=([0-9]*)](.*?)\[/size\]#s',
					 '#\[font=(.*?)\](.*?)\[/font\]#',
					 '#\[highlight\](.*?)\[/highlight\]#',

				//++++++++++++++++++++++++++++++++++//
				
						/* 	If you need some Tables - here are the BBCodes for that,
							but I haven't included them in the "agora_bbcode.php":
							A table could look like this

					 		[table]
							[caption] TableHeading[/caption]
							[tr][td]Testing1[/td][td]Testing2[/td][/tr]
							[tr][td]Testing3[/td][td]Testing4[/td][/tr]
							[/table]
						*/

					 '#\[table\](.*?)\[/table\]#s',
					 '#\[caption\](.*?)\[/caption\]#s',
					 '#\[th\](.*?)\[/th\]#s',
					 '#\[tr\](.*?)\[/tr\]#s',
					 '#\[td\](.*?)\[/td\]#s',
	
				//++++++++++++++++++++++++++++++++++//

					 '#\[pre\](.*?)\[/pre\]#s',
					 '#\[sup\](.*?)\[/sup\]#',
					 '#\[sub\](.*?)\[/sub\]#',


					 '#\[ol\](.*?)\[/ol\]#s',
					 '#\[ul\](.*?)\[/ul\]#s',
					 '#\[li\](.*?)\[/li\]#s',

					 '#\[hr\]#s',
				//++++++++++++++++++++++++++++++++++//

			//+++++++++++++ Video Portals +++++++++++++//

					 '#\[youtube\](.*?)\[/youtube\]#s',
					 '#\[googlevid\](.*?)\[/googlevid\]#s',
					 '#\[myvideo\](.*?)\[/myvideo\]#s',
 					 '#\[clipfish\](.*?)\[/clipfish\]#s',
 					 '#\[dailymotion\](.*?)\[/dailymotion\]#s',
 					 '#\[metacafe\](.*?)\[/metacafe\]#s',
 					 '#\[ifilm\](.*?)\[/ifilm\]#s',
					 '#\[sevenload\](.*?)\[/sevenload\]#s',
					 '#\[garagetv\](.*?)\[/garagetv\]#s',
					 '#\[revver\](.*?)\[/revver\]#s',
					 '#\[guba\](.*?)\[/guba\]#s',
					 '#\[myspace\](.*?)\[/myspace\]#s',
					 '#\[yahoo\](.*?)&amp;(.*?)\[/yahoo\]#s',
					 '#\[aniboom\](.*?)\[/aniboom\]#s',
					 '#\[veoh\](.*?)\[/veoh\]#s',
					 '#\[videojug\](.*?)\[/videojug\]#s',
					 '#\[vsocial\](.*?)\[/vsocial\]#s',
					 '#\[esnips\](.*?)\[/esnips\]#s',
					 '#\[brightcove\](.*?)\[/brightcove\]#s',

					 '#\[megavideo\](.*?)\[/megavideo\]#s',	// this one shows with "start-picture", but need the Video ID string from the "embed" Code
					 '#\[megavideo2\](.*?)\[/megavideo2\]#s',	// this one shows no "start-picture" in the player, but needs only the Video ID from the URL


					 '#\[stage6 width=([0-9,.]*) height=([0-9,.]*)\](.*?)\[/stage6\]#s',//******* set dimensions in BBCode ********//
					 '#\[stage6\](.*?)\[/stage6\]#s',

					 '#\[virb width=([0-9,.]*) height=([0-9,.]*)\](.*?)\[/virb\]#s',//******* set dimensions in BBCode ********//
					 '#\[virb\](.*?)\[/virb\]#s',


					 '#\[flv\](.*?)\[/flv\]#',

					 '#\[mp3\](.*?)\[/mp3\]#',

					 '#\[divx\](.*?)\[/divx\]#',
					 '#\[divx width=([0-9]*) height=([0-9]*)\](.*?)\[/divx\]#',

					 '#\[swf height=([0-9]*)\](.*?)\[/swf\]#',
					 '#\[swf width=([0-9]*) height=([0-9]*)\](.*?)\[/swf\]#',
					 '#\[swf\](.*?)\[/swf\]#',

					 '#\[quicktime\](.*?)\[/quicktime\]#',
					 '#\[quicktime width=([0-9]*) height=([0-9]*)\](.*?)\[/quicktime\]#',

					 '#\[wmp width=([0-9]*) height=([0-9]*)\](.*?)\[/wmp\]#',

				//++++++++++++++++++++++++++++++++++//

	);// end array - don't remove //

	$replace = array('<strong>$1</strong>',
					 '<em>$1</em>',
					 '<span class="bbu">$1</span>',

					 '$this->handle_url_tag(\'$1\')',
					 '$this->handle_url_tag(\'$1\', \'$2\')',
					 '<a href="mailto:$1">$1</a>',
					 '<a href="mailto:$1">$2</a>',
					 '<span style="color: $1">$2</span>',
					 //'$this->handle_img_tag(\'$1$3\')',
					 '$this->handle_img_tag(\'$3$5\',\'$1\',\'$2\')',

				//++++++++++++++++++++++++++++++++++//
				
					 '<span class="bbs">$1</span>',
					 '<p class="bbcenter">$1</p>',
					 '<p class="bbleft">$1</p>',
					 '<p class="bbright">$1</p>',
					 '<p class="bbjustify">$1</p>',
					 '<p class="bbindent">$1</p>',

					 '<span style="font-size: $1px">$2</span>',
					 '<span style="font-family: $1">$2</span>',
					 '<span class="bbhighlight">$1</span>',

				//++++++++++++++++++++++++++++++++++//
				
			/* 	If you need some Tables - here are the BBCodes for that, but I haven't included them in the "agora_bbcode.php":
				A table could look like this

			 	[table]
				[caption] TableHeading[/caption]
				[tr][td]Testing1[/td][td]Testing2[/td][/tr]
				[tr][td]Testing3[/td][td]Testing4[/td][/tr]
				[/table]
			*/

					 '<table class"bbtable">$1</table>',
					 '<caption>$1</caption>',
					 '<th class="bbth">$1</th>',
					 '<tr class="bbtr">$1</tr>',
					 '<td class="bbtd">$1</td>',

				//++++++++++++++++++++++++++++++++++//

					 '<pre>$1</pre>',
					 '<sup>$1</sup>',
					 '<sub>$1</sub>',


					 '<ol>$1</ol>',
					 '<ul>$1</ul>',
					 '<li>$1</li>',

					 '<hr/>',
				//++++++++++++++++++++++++++++++++++//

			//+++++++++++++ Video Portals +++++++++++++//

//****** embed YouTube Videos ***********************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.youtube.com/v/$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.youtube.com/v/$1" /><param name="quality" value="best" /><embed src="http://www.youtube.com/v/$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end YouTube Videos *************************************************

//****** embed Google Videos ************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://video.google.com/googleplayer.swf?docId=$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://video.google.com/googleplayer.swf?docId=$1" /><param name="quality" value="best" /><embed src="http://video.google.com/googleplayer.swf?docId=$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end Google Videos **************************************************

//****** embed MyVideo ******************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.myvideo.de/movie/$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.myvideo.de/movie/$1" /><param name="quality" value="best" /><embed src="http://www.myvideo.de/movie/$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end MyVideo ********************************************************

//****** embed ClipFish *****************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.clipfish.com/videoplayer.swf?as=0&videoid=$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.clipfish.com/videoplayer.swf?as=0&videoid=$1" /><param name="quality" value="best" /><embed src="http://www.clipfish.com/videoplayer.swf?as=0&videoid=$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end ClipFish *******************************************************

//****** embed Dailymotion Videos *******************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.dailymotion.com/swf/$1.swf" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.dailymotion.com/swf/$1.swf" /><param name="quality" value="best" /><embed src="http://www.dailymotion.com/swf/$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end Dailymotion Videos *********************************************

//****** embed Metacafe Videos **********************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.metacafe.com/fplayer/$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.metacafe.com/fplayer/$1" /><param name="quality" value="best" /><embed src="http://www.metacafe.com/fplayer/$1.swf" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end Metacafe Videos ************************************************

//****** embed iFilm Videos *************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.ifilm.com/efp?flvbaseclip=$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.ifilm.com/efp?flvbaseclip=$1" /><param name="quality" value="best" /><embed src="http://www.ifilm.com/efp?flvbaseclip=$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end iFilm Videos ***************************************************

//****** embed Sevenload Videos *********************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://page.sevenload.com/swf/player.swf?id=$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://page.sevenload.com/swf/player.swf?id=$1" /><param name="quality" value="best" /><embed src="http://page.sevenload.com/swf/player.swf?id=$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end Sevenload Videos ***********************************************

//****** embed GarageTV Videos **********************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.garagetv.be/v/$1/v.aspx" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.garagetv.be/v/$1/v.aspx" /><param name="quality" value="best" /><embed src="http://www.garagetv.be/v/$1/v.aspx" width="'.$bbvideo_width.'" height="350" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end GarageTV Videos ************************************************

//****** embed Revver Videos ************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://flash.revver.com/player/1.0/player.swf?mediaId=$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://flash.revver.com/player/1.0/player.swf?mediaId=$1" /><param name="quality" value="best" /><embed src="http://flash.revver.com/player/1.0/player.swf?mediaId=$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end Revver Videos **************************************************

//****** embed Guba Videos **************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.guba.com/f/root.swf?video_url=http://free.guba.com/uploaditem/$1/flash.flv" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.guba.com/f/root.swf?video_url=http://free.guba.com/uploaditem/$1/flash.flv" /><param name="quality" value="best" /><embed src="http://www.guba.com/f/root.swf?video_url=http://free.guba.com/uploaditem/$1/flash.flv" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end Guba Videos ****************************************************

//****** embed mySpace Videos ***********************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="392" align="top data="http://lads.myspace.com/videos/vplayer.swf?m=$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://lads.myspace.com/videos/vplayer.swf?m=$1" /><param name="quality" value="best" /><embed src="http://lads.myspace.com/videos/vplayer.swf?m=$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end mySpace Videos *************************************************

//****** embed Yahoo Videos **************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://us.i1.yimg.com/cosmos.bcst.yahoo.com/player/media/swf/FLVVideoSolo.swf?id=$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://us.i1.yimg.com/cosmos.bcst.yahoo.com/player/media/swf/FLVVideoSolo.swf?id=$1" /><param name="quality" value="best" /><embed src="http://us.i1.yimg.com/cosmos.bcst.yahoo.com/player/media/swf/FLVVideoSolo.swf?id=$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end Yahoo Videos ***************************************************

//****** embed Aniboom Videos ***********************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://api.aniboom.com/embedded.swf?videoar=$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://api.aniboom.com/embedded.swf?videoar=$1" /><param name="quality" value="best" /><embed src="http://api.aniboom.com/embedded.swf?videoar=$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end Aniboom Videos *************************************************

//****** embed Veoh Videos **************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.veoh.com/videodetails2.swf?permalinkId=$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.veoh.com/videodetails2.swf?permalinkId=$1" /><param name="quality" value="best" /><embed src="http://www.veoh.com/videodetails2.swf?permalinkId=$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end Veoh Videos ****************************************************

//****** embed VideoJug Videos **********************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.videojug.com/film/player?id=$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.videojug.com/film/player?id=$1" /><param name="quality" value="best" /><embed src="http://www.videojug.com/film/player?id=$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end VideoJug Videos ************************************************

//****** embed VSocial Videos ***********************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://static.vsocial.com/flash/ups.swf?d=$1&a=0" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://static.vsocial.com/flash/ups.swf?d=$1&a=0" /><param name="quality" value="best" /><embed src="http://static.vsocial.com/flash/ups.swf?d=$1&a=0" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end VSocial Videos *************************************************


//****** embed eSnips Videos ************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.esnips.com//3rd/flvplayer/esnips_flvplayer12.swf?xmlURL=http://www.esnips.com//flashxml/1/$1 \" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.esnips.com//3rd/flvplayer/esnips_flvplayer12.swf?xmlURL=http://www.esnips.com//flashxml/1/$1 \" /><param name="quality" value="best" /><param name="flashvars"  value= "autostart=false" /><embed src="http://www.esnips.com//3rd/flvplayer/esnips_flvplayer12.swf?xmlURL=http://www.esnips.com//flashxml/1/$1" quality="best" height="'.$bbvideo_height.'" width="'.$bbvideo_width.'" flashvars="autostart=false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"></embed></object></div>',
//****** end eSnips Videos **************************************************

//****** embed Brightcove Videos ********************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://admin.brightcove.com/destination/player/player.swf" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="always" /><param name="movie" value="http://admin.brightcove.com/destination/player/player.swf" /><param name="quality" value="best" /><param name="allowFullScreen" value="true" /><param name="flashvars"  value="allowFullScreen=true&servicesURL=http://www.brightcove.com&viewerSecureGatewayURL=https://www.brightcove.com&cdnURL=http://admin.brightcove.com&autoStart=false&initVideoId=$1" /><embed src="http://admin.brightcove.com/destination/player/player.swf?&initVideoId=$1" allowfullscreen="true" quality="best" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" flashvars="allowFullScreen=true&servicesURL=http://www.brightcove.com&viewerSecureGatewayURL=https://www.brightcove.com&cdnURL=http://admin.brightcove.com&autoStart=false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"></embed></object></div>',
//****** end Brightcove Videos **********************************************

//****** embed MegaVideo ****************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.megavideo.com/v/$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.megavideo.com/v/$1" /><param name="quality" value="best" /><embed src="http://www.megavideo.com/v/$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end MegaVideo ******************************************************

//****** embed MegaVideo ****************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.megavideo.com/ep_gn.swf?v=$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.megavideo.com/ep_gn.swf?v=$1" /><param name="quality" value="best" /><embed src="http://www.megavideo.com/ep_gn.swf?v=$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" align="top" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end MegaVideo ******************************************************

//****** embed Stage6 divX Videos with dimensions settings inside BBCode ****
'<div class="bbvideo"><object width="$1" height="$2" align="top" data="http://video.stage6.com/$3/.divx\" classid="clsid:67DABFBF-D0AB-41fa-9C46-CC0F21721616"  codebase="http://go.divx.com/plugin/DivXBrowserPlugin.cab"><param name="autoplay" value="false"><param name="src" value="http://video.stage6.com/$3/.divx\" /<param name="custommode" value="Stage6" /><param name="showpostplaybackad" value="false" /><embed src="http://video.stage6.com/$3/.divx" width="$1" height="$2" align="top" showpostplaybackad="false" custommode="Stage6" autoplay="false" type="video/divx" pluginspage="http://go.divx.com/plugin/download/"  /></embed></object>
<br/>No video? Get the DivX Web Player for <a style="text-decoration: underline;" href="http://download.divx.com/player/DivXWebPlayerInstaller.exe">Windows</a> or <a style="text-decoration: underline;" href="http://download.divx.com/player/DivXWebPlayer.dmg">Mac</a></div>',
//****** end Stage6 divX Videos *********************************************

//****** embed Stage6 divX Videos *******************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://video.stage6.com/$1/.divx\" classid="clsid:67DABFBF-D0AB-41fa-9C46-CC0F21721616"  codebase="http://go.divx.com/plugin/DivXBrowserPlugin.cab"><param name="autoplay" value="false"><param name="src" value="http://video.stage6.com/$1/.divx\" /<param name="custommode" value="Stage6" /><param name="showpostplaybackad" value="false" /><embed src="http://video.stage6.com/$1/.divx" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" showpostplaybackad="false" custommode="Stage6" autoplay="false" type="video/divx" pluginspage="http://go.divx.com/plugin/download/"  /></embed></object>
<br/>No video? Get the DivX Web Player for <a style="text-decoration: underline;" href="http://download.divx.com/player/DivXWebPlayerInstaller.exe">Windows</a> or <a style="text-decoration: underline;" href="http://download.divx.com/player/DivXWebPlayer.dmg">Mac</a></div>',
//****** end Stage6 divX Videos *********************************************

//****** embed Virb Videos with dimensions settings inside BBCode **********
'<div class="bbvideo"><object width="$1" height="$2" align="top" data="http://www.virb.com/external/video/$3" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.virb.com/external/video/$3" /><param name="quality" value="best" /><param name="salign" value="tl" /><param name="wmode" value="transparent" /><embed src="http://www.virb.com/external/video/$3" width="$1" height="$2" quality="best" salign="tl" align="top" wmode="transparent" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end Virb Videos ****************************************************

//****** embed Virb Videos **************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" data="http://www.virb.com/external/video/$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="http://www.virb.com/external/video/$1" /><param name="quality" value="best" /><param name="salign" value="tl" /><param name="wmode" value="transparent" /><embed src="http://www.virb.com/external/video/$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" quality="best" salign="tl" align="top" wmode="transparent" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></embed></object></div>',
//****** end Virb Videos ****************************************************

//****** embed FLV for JW - Players *****************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" data="mod_mediaplayer.swf" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0"><param name="movie" value="mod_mediaplayer.swf" /><param name="menu" value="false" /><param name="quality" value="best" /><param name="allowFullScreen" value="true" /><param name="flashvars" value="frontcolor=0xEEEEEE&backcolor=0x222222&lightcolor=0xFFFFFF&autostart=false&usefullscreen=true&file=$1" /><embed src="mod_mediaplayer.swf" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" menu="false" allowfullscreen="true" flashvars="frontcolor=0xEEEEEE&backcolor=0x222222&lightcolor=0xFFFFFF&autostart=false&usefullscreen=true&file=$1" type="application/x-shockwave-flash" pluginspage= "http://www.macromedia.com/go/getflashplayer"/></embed></object></div>',
//****** end FLV for JW - Players *******************************************

//****** embed Mp3 for JW - Players ******************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" data="mod_mediaplayer.swf" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0"><param name="movie" value="mod_mediaplayer.swf" /><param name="menu" value="false" /><param name="quality" value="best" /><param name="flashvars" value="flashvars="&height=20&width=320&frontcolor=0xEEEEEE&backcolor=0x444444&lightcolor=0xFFFFFF&showdownload=true&showicons=false&autostart=false&file=$1"" /><embed src="mod_mediaplayer.swf" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" menu="false" flashvars="&height=20&width=320&frontcolor=0xEEEEEE&backcolor=0x444444&lightcolor=0xFFFFFF&showdownload=true&showicons=false&autostart=false&file=$1" type="application/x-shockwave-flash" pluginspage= "http://www.macromedia.com/go/getflashplayer"/></embed></object></div>',
//****** end Mp3 for JW - Players *******************************************

//****** embed divX Videos **************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" classid="clsid:67DABFBF-D0AB-41fa-9C46-CC0F21721616" codebase="http://go.divx.com/plugin/DivXBrowserPlugin.cab"><param name="autoPlay" value="false" /><param name="src" value="$1" /><embed src="$1" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" autoPlay="false" type="video/divx" pluginspage="http://go.divx.com/plugin/download/"></embed></object>
<br/>No video? Get the DivX Web Player for <a style="text-decoration: underline;" href="http://download.divx.com/player/DivXWebPlayerInstaller.exe">Windows</a> or <a style="text-decoration: underline;" href="http://download.divx.com/player/DivXWebPlayer.dmg">Mac</a>	</div>',
//****** end divX Videos ****************************************************

//****** embed divX Videos **************************************************
'<div class="bbvideo"><object width="$1" height="$2" classid="clsid:67DABFBF-D0AB-41fa-9C46-CC0F21721616" codebase="http://go.divx.com/plugin/DivXBrowserPlugin.cab"><param name="autoPlay" value="false" /><param name="src" value="$3" /><embed src="$3" width="$1" height="$2" autoPlay="false" type="video/divx" pluginspage="http://go.divx.com/plugin/download/"></embed></object>
<br/>No video? Get the DivX Web Player for <a style="text-decoration: underline;" href="http://download.divx.com/player/DivXWebPlayerInstaller.exe">Windows</a> or <a style="text-decoration: underline;" href="http://download.divx.com/player/DivXWebPlayer.dmg">Mac</a>	</div>',
//****** end divX Videos ****************************************************

//****** embed SWF **********************************************************
'<div class="bbvideo"><object width="100%" height="$1" align="middle" data="$2" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" /><param name="scale" value="noscale" /><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="$2" /><param name="quality" value="best" /><param name=menu value="false"><embed align="middle" src="$2" quality="best" width="100%" height="$1" scale="noscale"  allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object></div>',
//******** end SWF **********************************************************
				
//****** embed SWF **********************************************************
'<div class="bbvideo"><object width="$1" height="$2" align="middle" data="$3" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" /><param name="scale" value="noscale" /><param name="allowScriptAccess" value="never" /><param name="movie" value="$3" /><param name="quality" value="best" /><param name=menu value="false"><embed align="middle" src="$3" quality="best" width="$1" height="$2" scale="noscale" allowScriptAccess="never" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object></div>',
//******** end SWF **********************************************************

//****** embed SWF **********************************************************
'<div class="bbvideo"><object align="top" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" data="$1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" /><param name="scale" value="noorder" /><param name="allowScriptAccess" value="never" /><param name="movie" value="$1" /><param name="quality" value="best" /><param name="bgcolor" value="#000000" /><param name="salign" value="tl" /><param name=menu value="false"><embed align="middle" src="$1" quality="best" bgcolor="#000000" width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" scale="noorder" salign="tl" align="top" allowScriptAccess="never" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object></div>',
//******** end SWF **********************************************************

//****** embed QuickTime ****************************************************
'<div class="bbvideo"><object width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" classid="clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B" codebase="http://www.apple.com/qtactivex/qtplugin.cab" ><param name="type" value="video/quicktime" /><param name="scale" value="aspect"/><param name="cache" value="true"/><param name="src" value="$1"/><param name="autoplay" value="false"/><param name="controller" value="true"/><param name="loop" value="false"/><param name="bgcolor" value="transparent" /><embed width="'.$bbvideo_width.'" height="'.$bbvideo_height.'" align="top" src="$1" type="video/quicktime" controller="true" autoplay="false" bgcolor="transparent" cache="true" scale="aspect" loop="false" pluginspage="http://www.apple.com/quicktime/download/"></embed></object></div>',
//****** end QuickTime *******************************************************

//****** embed QuickTime ****************************************************
'<div class="bbvideo"><object width="$1" height="$2" align="top" classid="clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B" codebase="http://www.apple.com/qtactivex/qtplugin.cab" ><param name="type" value="video/quicktime" /><param name="scale" value="aspect"/><param name="cache" value="true"/><param name="src" value="$3"/><param name="autoplay" value="false"/><param name="controller" value="true"/><param name="loop" value="false"/><param name="bgcolor" value="transparent" /><embed width="$1" height="$2" src="$3" align="top" type="video/quicktime" controller="true" autoplay="false" bgcolor="transparent" cache="true" scale="aspect" loop="false" pluginspage="http://www.apple.com/quicktime/download/"></embed></object></div>',
//****** end QuickTime *******************************************************

//****** embed Windows Media *************************************************
'<div class="bbvideo"><object width="$1" height="$2" classid="clsid:6BF52A52-394A-11D3-B153-00C04F79FAA6" standby="Loading Windows Media Player components..." type="application/x-oleobject"><param name="FileName" value="$3" /><param name="volume" value="-7000" /><param name="ShowControls" value="true" /><param name="ShowStatusBar" value="false" /><param name="ShowDisplay" value="false" /><param name="autostart" value="false" /><param name="autosize" value="true" /><param name="AnimationAtStart" value="false" /><embed width="$1" height="$2" src="$3" volume="-7000" AnimationAtStart="0" showcontrols="1" showstatusbar="0" showdisplay="0" autostart="0" autosize="1" type="application/x-mplayer2" pluginspage="http://www.microsoft.com/windows/windowsmedia/players.asp"></embed></object>
<br/>Using a Mac? Want to see this WMV with Quicktime? Get <a style="text-decoration: underline;" href="http://www.flip4mac.com/wmv_download.htm" onclick="window.open(this.href); return false;">flip4mac</a></div>',
//****** end Windows Media ****************************************************

				//++++++++++++++++++++++++++++++++++//

					 );// end array - don't remove //

?>