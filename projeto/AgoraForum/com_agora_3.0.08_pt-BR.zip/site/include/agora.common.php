<?php
	defined('IN_AGORA') or die;

	class AgoraCommon
	{
		function getIP()
		{
			if (isset($_SERVER['REMOTE_ADDR']))
				return $_SERVER['REMOTE_ADDR'];
			else
				return '0.0.0.0';
		}

		function getRefferer()
		{
			if (isset($_SERVER['HTTP_REFERER']))
				return $_SERVER['HTTP_REFERER'];
			else
				return Agora::makeURL();
		}

		function getTotalPages($total_items, $per_page)
		{
			$pages = ceil($total_items / $per_page);
			if ($pages < 1) $pages = 1;
			return $pages;
		}

		function getPage($page_count)
		{
			static $page = 0;

			if ($page === 0) {
				$page = intval(Agora::getVar('p',1));

				if ($page < 1) {
					$page = 1;
				} elseif ($page > $page_count && $page_count > 0) {
					$page = $page_count;
				}
			}

			return $page;
		}
	}

?>