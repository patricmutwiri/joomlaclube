<?php

defined('IN_AGORA') or die;

require_once('agora.common.php');

class Agora extends AgoraCommon
{
	function showMessage($msg, $type = 'message')
	{
		$mainframe = & JFactory::getApplication();
		$mainframe->enqueueMessage($msg, $type);
	}

	function showError($e)
	{
		Agora::showMessage(Agora::lang($e),'error');
/*		if (Agora::isPOST()) {
			Agora::redirect();
		}*/
	}

	function getRoot()
	{
		return JURI::base().'components/com_agora/';
	}

	function getSite()
	{
		return JURI::root().'components/com_agora/';
	}

	function escape($key)
	{
		return htmlspecialchars($key, ENT_QUOTES, 'UTF-8');
	}

	function getCurrentLanguage()
	{
		static $lang;
		if (!$lang) {
			$lang = & JFactory::getLanguage();
		}

		return $lang->getTag();
	}

	function lang($key)
	{
		static $jlang = null;

		if (is_null($jlang)) {
			$jlang = & JFactory::getLanguage();
		}

		if (is_array($key)) {
			// key from preg_replace_callback
			$key = $key[1];
		}

//		$result = addslashes($jlang->_(/*str_replace(' ','_',*/trim($key)/*)*/,false));
		$result = $jlang->_(trim($key));

		$args = func_get_args();
		if (count($args) > 1) {
			$args[0] = $result;
			$result = call_user_func_array('sprintf',$args);
		}

		if (defined('AGORA_HELP_TRANSLATE')) {
			echo $key.' '.'&nbsp;-&nbsp;';

			if ($key !== $result && '??'.$key.'??' !== $result) {
				echo 'TRANSLATED';
			} else {
				echo '<b>NOT FOUND</b>';
			}
			print "<br />\n";
		
		}

		return $result;
	}

	function linebreaks($str)
	{
		return str_replace("\r", "\n", str_replace("\r\n", "\n", $str));
	}

	function filterForm(& $form, $fields)
	{
		if (!is_array($fields)) return;
		$keys = array();
		foreach ($fields as $key => $value) {
			if (is_string($key)) {
				$form_key = $key;
				$form_value = $value;
			} else {
				$form_key = $value;
				$form_value = 0;
			}
			if (!isset($form[$form_key])) {
				$form[$form_key] = $form_value;
			}
			$keys[] = $form_key;
		}

		foreach ($form as $form_key=>$form_value) {
			if (!in_array($form_key,$keys)) {
				unset($form[$form_key]);
			}
		}
	}

	function redirect($url = NULL, $same_window = false)
	{
		if (!$url) {
			$uri = JURI::getInstance();
			$url = $uri->toString();
		}
//		if (headers_sent()) {
		@ob_end_clean();

		if (Agora::getRequestVar('type') == 'clean' && !$same_window) {
			//popup box
			echo '<script type="text/javascript">window.top.location.href="'.html_entity_decode($url).'"; window.parent.document.getElementById(\'sbox-window\').close();</script>\n';
		} elseif (Agora::isPost()) {
			header( 'HTTP/1.1 303 See other' );
			header( 'Location: ' . html_entity_decode($url), true);
			header( 'Allow: GET');
//			echo '<script type="text/javascript">document.location.href="'.html_entity_decode($url).'";</script>\n';
		} else {
			header( 'HTTP/1.1 303 See other' );
			header( 'Location: ' . html_entity_decode($url), true);
			header( 'Allow: GET');
		}
		// Persist messages if they exist

		$mainframe = & JFactory::getApplication();

		if (count($mainframe->_messageQueue))
		{
			$session =& JFactory::getSession();
			$session->set('application.queue', $mainframe->_messageQueue);
		}

/*		} else {
			@ob_end_clean(); // clear output buffer
			header( 'HTTP/1.1 303 See other' );
			header( 'Location: ' . $url, true);
			echo "\n\nRedirecting to $url";
		}*/
/*		$mainframe = & JFactory::getApplication();
		$mainframe->redirect($url);*/
		die;
	}

	function show404()
	{
		JError::raiseError( 404, JText::_('Page Not Found') );
	}

	function getVar($var,$def = NULL)
	{
/*		$disp_var = AgoraDispatcher::getInstance()->getVar($var);
		return is_null($disp_var) ? JRequest::getVar($var,$def,'GET') : $disp_var;*/
		return JRequest::getVar($var,$def,'GET');
	}

	function getRequestVar($var,$def = NULL)
	{
/*		$disp_var = AgoraDispatcher::getInstance()->getVar($var);
		return is_null($disp_var) ? JRequest::getVar($var,$def,'GET') : $disp_var;*/
		return JRequest::getVar($var,$def,'REQUEST');
	}

	function getPostVar($var,$def = NULL, $raw=false)
	{
		return JRequest::getVar($var,$def,'POST','none',$raw ? 2 : 0);
	}

	function getSessionVar($var,$def = NULL)
	{
		$sess = JFactory::getSession();
		return $sess->get($var,$def,'agora');
	}

	function setSessionVar($var,$value)
	{
		$sess = JFactory::getSession();
		$sess->set($var,$value,'agora');
	}

	function isFeed()
	{
		$format = JRequest::getWord('format');
		if ($format === 'feed') {
			return true;
		}
		return false;
	}

	function getFeedType()
	{
		$type = JRequest::getWord('type','rss');
		return $type;
	}

	function getSelf()
	{
		$uri = & JFactory::getURI();
		return $uri->toString();
	}

	function makeFeedURL($params)
	{
		$url = '/index.php?option=com_agora';
		foreach ($params as $name => $value) {
			$url .= "&$name=$value";
		}

		global $Itemid;

		if (isset($Itemid)) {
			$url .= '&Itemid='.$Itemid;
		}

		$uri = JURI::getInstance();
		return $uri->getPath().Agora::escape($url);
	}

	function makeURL($params, $html = true, $agroup = false)
	{
		static $isAdmin = null;

		if (is_null($isAdmin)) {
			$app = JFactory::getApplication();
			$isAdmin = $app->isAdmin();
		}
		
		$pos1 = strpos($_SERVER['PHP_SELF'], '/');
		$pos2 = strpos($_SERVER['PHP_SELF'], '/index');
		$prefics = substr($_SERVER['PHP_SELF'], $pos1, $pos2-$pos1);
		$prefics .= '/';

		if (isset($params['option'])) {
		    if ($agroup)
			$url = 'index2.php?option='.$params['option'];
			else
			$url = 'index.php?option='.$params['option'];

			if (!isset($params['Itemid'])) {
				$component	= &JComponentHelper::getComponent($params['option']);
				$menu		= &JSite::getMenu();
				$items		= $menu->getItems('componentid', $component->id);
				if (is_array($items) && count($items) > 0) {
					$url .= '&Itemid='.$items[0]->id;
				}
			}

			unset($params['option']);
		} else {
			static $agora_itemid;

			if (!isset($params['Itemid']) && !$isAdmin) {
				if (!isset($agora_itemid)) {
					$agora_itemid = Agora::getVar('Itemid');
					if (is_null($agora_itemid)) {
						$component	= &JComponentHelper::getComponent('com_agora');
						$menu		= &JSite::getMenu();
						$items		= $menu->getItems('componentid', $component->id);
						if (is_array($items) && count($items) > 0) {
							$agora_itemid = $items[0]->id;
						}
					}
				}
				if ($agora_itemid) {
					$params['Itemid'] = $agora_itemid;
				}
			}
            if ($agroup)
			$url = $prefics.'index2.php?option=com_agora';
			else
			$url = 'index.php?option=com_agora';
		}
		$hash = '';
		foreach ($params as $name => $value) {
			if ($name != '_') {
				$url .= '&'.$name.'='.$value;
			} else {
				$hash = '#'. $value;
			}
		}
		$uri    = & JURI::getInstance();

		if ($isAdmin) {
			$prefix = '';
		} else {
			$prefix = $uri->toString(array('scheme', 'host', 'port'));
		}

		return $prefix . Agora::routeURL($url, $html). $hash;
	}

	function routeURL($url,$html = true)
	{
    	$url = JRoute::_($url, false);
    	
		if ($html) {
			$url = htmlspecialchars($url);
		}
		return preg_replace('/[&\?]$/','',$url);
	}

	function isPOST()
	{
		if (JRequest::getMethod() === 'POST') {
			return true;
		}
		return false;
	}
}

?>