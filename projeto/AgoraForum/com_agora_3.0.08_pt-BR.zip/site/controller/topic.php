<?php
defined ('IN_AGORA') or die;

class TaskController extends AgoraController
{
    function __construct()
    {
        parent::__construct();
        
        $mode = Agora::getVar('mode');
        if ( strpos($_SERVER['PHP_SELF'],'index2.php')!=0 ) $mode='agroup';
        
        if ('agroup'==$mode)
        $this->loadDefaultView( null, 'view_agroup');
        else
        $this->loadDefaultView();
    }

    // extract parent forums and categories path from common forumList array and publish it to template
    function _buildPathWay($forum, $topic, $mode=false)
    {
        $forum_id = $forum['id'];
        $cat_id = $forum['cat_id'];
        $category = $this->forumList[$cat_id];

        $pathway = & $this->helper('pathway');

        while ($forum_id != 0) {
            $forum = $category['forums'][$forum_id];
            if ('agroup'==$mode)
            $pathway->push($forum['forum_name'],Agora::makeURL(array('task' => 'forum', 'id' => $forum['id']), true, true));
            else
            $pathway->push($forum['forum_name'],Agora::makeURL(array('task' => 'forum', 'id' => $forum['id'])));
            
            $forum_id = $forum['parent_forum_id'];
        };

        // prepend with category
        if ('agroup'==$mode)
        $pathway->push($category['cat_name'],Agora::makeURL(array('id' => $cat_id), true, true));
        else
        $pathway->push($category['cat_name'],Agora::makeURL(array('id' => $cat_id)));
        
        // append topic subject without link - user already has link in his browser
        $pathway->add($topic['subject'],'');
    }

    function _processPoll($topic)
    {
        $poll_model = & Model::getInstance('PollModel');
        $poll = $poll_model->load($topic['id'],'pollid');

        if ($poll) {

            if (is_array($poll['voters']) && in_array($this->agora_user['id'],$poll['voters'])) {
                $poll['voted'] = true;
            } else {
                $poll['voted'] = false;
            }
            if ($this->agora_user['is_guest']) {
                $poll['voted'] = true;
            }

            if ($poll['ptype'] == 1) {
                $poll['type'] = 'regular';
            } elseif ($poll['ptype'] == 2) {
                $poll['type'] = 'multi';
            } elseif ($poll['ptype'] == 3) {
                $poll['type'] = 'multi_yes_no';
            }

            if (!is_array($poll['votes'])) $poll['votes'] = array();
            if (!is_array($poll['options'])) $poll['options'] = array();

            $total = 0;

            foreach ($poll['votes'] as $votes) {
                if ($poll['ptype'] == '3') {
                    foreach ($votes as $option) {
                        $total += $option;
                    }
                } else {
                    $total += $votes;
                }
            }

            $poll['total_votes'] = $total;

/*			if ($poll['ptype'] == '3') {
                $total /= count($poll['options']);
            }*/

            if ($poll['voted']) {
                $option = null;
                foreach ($poll['options'] as $key=>$option) {
                    $poll['options'][$key] = array('name' => $option);

                    $vote = & $poll['votes'][$key];

                    if (isset($poll['votes'][$key]) && $total > 0) {
                        if ($poll['ptype'] != '3') {
                            $poll['options'][$key]['percent'] = floor($vote * 100 / $total);
                            $poll['options'][$key]['count'] = $vote;
                        } else {
                            if (!isset($vote['yes'])) $vote['yes'] = 0;
                            if (!isset($vote['no'])) $vote['no'] = 0;
                            $poll['options'][$key]['yes_percent'] = floor($vote['yes'] * 100 / $total);
                            $poll['options'][$key]['yes_count'] = $vote['yes'];
                            $poll['options'][$key]['no_percent'] = floor($vote['no'] * 100 / $total);
                            $poll['options'][$key]['no_count'] = $vote['no'];
                        }
                    } else {
                        if ($poll['ptype'] != '3') {
                            $poll['options'][$key]['percent'] = 0;
                            $poll['options'][$key]['count'] = 0;
                        } else {
                            $poll['options'][$key]['yes_percent'] = 0;
                            $poll['options'][$key]['yes_count'] = 0;
                            $poll['options'][$key]['no_percent'] = 0;
                            $poll['options'][$key]['no_count'] = 0;
                        }
                    }
                }
            }

            $this->view->assign('poll',$poll);
        }
    }

    // the same as for forum for now
    function _setHeadTags($forum)
    {
        $document = & JFactory::getDocument();
        $document->setTitle($forum['forum_name']);
        $document->setMetaData ('keywords', $forum['forum_key']);
        $document->setDescription($forum['forum_mdesc']);
    }

    function _default()
    {
        $topic_id = Agora::getVar('id');
        $mode = Agora::getVar('mode');                        
        if ( strpos($_SERVER['PHP_SELF'],'index2.php')!=0 ) $mode='agroup';
        
        $topic_model = & Model::getInstance('TopicModel');
        $topic = $topic_model->load($topic_id);

        $this->authenticate($topic['forum_id'],'read');

        $topic['subscribed'] = $topic_model->isSubscribed($topic_id, $this->agora_user['id']);

        if (!$topic) {
            Agora::show404();
            return;
        }
        $topic_model->addView($topic_id, $this->agora_user['id']);

        // load forum
        $forum_id = $topic['forum_id'];
        $forum_model = & Model::getInstance('ForumModel');
        $forum = $forum_model->load($forum_id);

        $catnav_helper = & $this->helper('catnav');
        $catnav_helper->fromCategory($forum['cat_id']);

        $this->_buildPathWay($forum, $topic, $mode);

        // get access parameters for forum
		$access_helper = & $this->helper('access');
		$access = $access_helper->getForumAccess($forum_id);

        if ($this->agora_user['is_guest']) {
            $banned = false;
        } else {
            $ban_model = & Model::getInstance('BanModel');
            $banned = $ban_model->isBanned($this->agora_user['username']);
        }

        if ($banned) {
            $access['post_topic'] = false;
            $access['post_poll'] = false;
            $access['post_reply'] = false;
            $access['can_moderate'] = false;
        }

        $this->view->assign('access',$access);

        // create pagination with respect to current page
        $per_page = intval($this->agora_user['disp_posts']) > 0 ? $this->agora_user['disp_posts'] : intval($this->agora_config['o_disp_posts_default']);
        $num_pages = ceil(($topic['num_replies'] + 1) / $per_page);
        $this->setPagination($num_pages);
        $page = Agora::getPage($num_pages);

        if ($topic['question']) {
            $this->_processPoll($topic);
        }

        // get posts and process then
        $posts = $topic_model->loadPosts($topic_id, $per_page, $page, intval($this->agora_user['reverse_posts']), $topic['num_replies']+1);

        $parser = & $this->helper('parser');

        $post_helper = & $this->helper('post');
        $posts = $post_helper->processPosts($posts, $parser);

        // Google adSense handling
        $as_model = & Model::getInstance('AdSenseModel');
        $as = $as_model->load();

        if ($as['google_adsense_enabled'] && strpos($as['google_exclude_forums'], ','.$topic['forum_id']) === FALSE ) {
            $this->view->smarty->assign('show_adsense',1);
        } else {
            $this->view->smarty->assign('show_adsense',0);
        }

        $this->_setHeadTags($forum);

        // post smilies are here
        $smilies_model = & Model::getInstance('SmiliesModel');
        $smilies = $smilies_model->loadAll();

        $this->view->assign('smilies',$smilies);
        $this->view->assign('topic',$topic);
        $this->view->assign('topic_id',$topic_id);
        $this->view->assign('forum',$forum);
        $this->view->assign('posts',$posts);
        $this->view->assign('page',$page);

        if ('agroup' == $mode)
        $this->view->template = 'topic_agroup';
        else
        $this->view->template = 'topic';
    }

    function subscribe()
    {
        $topic_id = Agora::getVar('id');
        $topic_model = & Model::getInstance('TopicModel');
        $topic = $topic_model->load($topic_id);
        if (!$topic) {
            Agora::show404();
            return;
        }
		$this->authenticate($topic['forum_id'], 'read');

        $subscription_model = & Model::getInstance('SubscriptionModel');
        $subscription_model->add(array('user_id'=>$this->agora_user['id'],'topic_id'=>$topic_id));

        Agora::showMessage(Agora::lang('You are now subscribed on topic ').AString::escape($topic['subject']));
        $this->redirect('id','!action','!page');
    }

    function unsubscribe()
    {
        $topic_id = Agora::getVar('id');
        $topic_model = & Model::getInstance('TopicModel');
        $topic = $topic_model->load($topic_id);
        if (!$topic) {
            Agora::show404();
            return;
        }
		$this->authenticate($topic['forum_id'], 'read');

        $subscription_model = & Model::getInstance('SubscriptionModel');
        $subscription_model->delete($this->agora_user['id'], $topic_id);

        Agora::showMessage(Agora::lang('You are now unsubscribed from topic ').AString::escape($topic['subject']));
        //$this->redirect('id');
        Agora::redirect($_SERVER['HTTP_REFERER']);
    }

    function sticky()
    {
        $topic_id = Agora::getVar('id');
		$this->authenticateTopic($topic_id, 'make_sticky');
        $topic_model = & Model::getInstance('TopicModel');
        $topic_model->edit($topic_id,array('sticky'=>1));

        Agora::showMessage(Agora::lang('Topic is sticky now'));
        $this->redirect('id','!action','!page');
    }

    function unsticky()
    {
        $topic_id = Agora::getVar('id');
		$this->authenticateTopic($topic_id, 'make_sticky');
        $topic_model = & Model::getInstance('TopicModel');
        $topic_model->edit($topic_id,array('sticky'=>0));
        Agora::showMessage(Agora::lang('Topic is not sticky now'));
        $this->redirect('id','!action','!page');
    }

    function close()
    {
        $topic_id = Agora::getVar('id');
		$this->authenticateTopic($topic_id, 'close_topic');
        $topic_model = & Model::getInstance('TopicModel');
        $topic_model->edit($topic_id,array('closed'=>1));
        Agora::showMessage(Agora::lang('Topic is closed now'));
        $this->redirect('id','!action','!page');
    }

    function open()
    {
        $topic_id = Agora::getVar('id');
		$this->authenticateTopic($topic_id, 'close_topic');
        $topic_model = & Model::getInstance('TopicModel');
        $topic_model->edit($topic_id,array('closed'=>0));
        Agora::showMessage(Agora::lang('Topic is open now'));
        $this->redirect('id','!action','!page');
    }

    function split()
    {
        if ( strpos($_SERVER['PHP_SELF'],'index2.php')!=0 ) $mode='agroup';
        else $mode='';
        
        $source_topic = Agora::getRequestVar('topic_id');
        $source_post = Agora::getRequestVar('post_id');
        $dest_forum = Agora::getRequestVar('id');
        if (!$dest_forum) {
            if ('agroup'==$mode)
            $this->view->assign('url', Agora::makeURL(array('task'=>'topic','action'=>'split','topic_id'=>$source_topic,'post_id'=>$source_post),true,true));
            else
            $this->view->assign('url', Agora::makeURL(array('task'=>'topic','action'=>'split','topic_id'=>$source_topic,'post_id'=>$source_post)));
            
            $this->view->template = 'post/select_forum';
            return;
        }

        $this->authenticate($dest_forum,'post_topic');

        $post_model = & Model::getInstance('PostModel');
        $post = $post_model->load($source_post);
        $post_model->delete($source_post);

        $forum_model = & Model::getInstance('ForumModel');

        $forum = $forum_model->load($dest_forum);
        $this->view->assign('forum',$forum);

        $icons_model = & Model::getInstance('TopicIconsModel');
        $this->view->assign('post_body',$post['message']);
        $this->view->assign('cur_forum_id',intval($dest_forum));
        $this->view->assign('topic_icons',$icons_model->loadAll());

        $this->view->template = 'post/topic';
    }

    function merge()
    {
        $source_topic = Agora::getRequestVar('source_id');
        $dest_id = Agora::getRequestVar('topic_id');
        $forum_id = Agora::getRequestVar('id');

        $this->authenticateTopic($source_topic,'close_topic');

        if (!$forum_id) {
            $this->view->assign('url', Agora::makeURL(array('task'=>'topic','action'=>'merge','source_id'=>$source_topic,'type'=>'clean')));
            $this->view->template = 'post/select_forum';
            return;
        }

        if (!$dest_id) {
            $forum_model = &Model::getInstance('ForumModel');
            $forum = $forum_model->load($forum_id);
            $topics = $forum_model->loadTopics($forum_id, null, null, $forum['sort_by'] == 1 ? 'posted' : 'last_post');
            foreach ($topics as $key=>$topic) {
                if ($topic['id'] == $source_topic) {
                    unset($topics[$key]);
                    break;
                }
            }
            $this->view->assign('topics',$topics);
            $this->view->assign('url', Agora::makeURL(array('task'=>'topic','action'=>'merge','source_id'=>$source_topic,'id'=>$forum_id,'type'=>'clean')));
            $this->view->template = 'post/select_topic';
            return;
        }

        $this->authenticate($forum_id,'post_topic');

        $topic_model = &Model::getInstance('TopicModel');
        $topic_model->merge($source_topic, $dest_id);
        Agora::showMessage(Agora::lang('Topic merged'));
        $this->redirect('page=topic','id='.intval($dest_id));
    }

    function move()
    {
        $source_topic = Agora::getRequestVar('source_id');
        $forum_id = Agora::getRequestVar('id');

        $this->authenticateTopic($source_topic,'close_topic');

        if (!$forum_id) {
            $this->view->assign('url', Agora::makeURL(array('task'=>'topic','action'=>'move','source_id'=>$source_topic,'type'=>'clean')));
            $this->view->template = 'post/select_forum';
            return;
        }

        $this->authenticate($forum_id,'post_topic');

        $topic_model = &Model::getInstance('TopicModel');
        $topic_model->move($source_topic,$forum_id);

        Agora::showMessage(Agora::lang('Topic moved'));
        $this->redirect('page=topic','id='.intval($source_topic));
    }
}

?>
