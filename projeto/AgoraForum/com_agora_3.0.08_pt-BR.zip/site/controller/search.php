<?php
defined ('IN_AGORA') or die;

class TaskController extends AgoraController
{

	function __construct()
	{
		parent::__construct();
		$this->loadDefaultView();
		$this->search_model = & Model::getInstance('SearchModel');
	}

	function search_results()
	{
		$params = array(
			'forum'		=> Agora::getVar('forum',-1),
			'keywords'	=> Agora::getVar('keywords',''),
			'author'	=> Agora::getVar('author',''),
			'sort_by'	=> intval(Agora::getVar('sort_by',5)),
			'show_as'	=> Agora::getVar('show_as','posts'),
			'sort_dir'	=> Agora::getVar('sort_dir','DESC'),
		);
		
		if ($params['sort_dir'] !== 'DESC' && $params['sort_dir'] !== 'ASC') {
			$params['sort_dir'] = 'DESC';
		}
		if ($params['show_as'] == 'posts') {
			$per_page = intval($this->agora_user['disp_posts']) > 0 ? $this->agora_user['disp_posts'] : intval($this->				agora_config['o_disp_posts_default']);
		}
		else
		{
			$per_page = intval($this->agora_user['disp_topics']) > 0 ? $this->agora_user['disp_topics'] : intval($this->				agora_config['o_disp_topics_default']);
		}
		$num_pages = ceil(($this->search_model->count_search($params))/ $per_page);
		$this->setPagination($num_pages);
		$page = Agora::getPage($num_pages);
		$s_res = $this->search_model->search($params,$per_page,$page);

		$forums_model = & Model::getInstance('ForumModel');
		$forums = $forums_model->loadNames();

		foreach ($s_res as $key => $value) {	
			if (isset($forums[$value['forum_id']])) {
				$s_res[$key]['forum_name'] = $forums[$value['forum_id']];
			} else {
				$s_res[$key]['forum_name'] = '';
			}
		}

		
		$this->view->assign('show_as',$params['show_as']);
		$this->view->assignRef('search_result',$s_res);
		$this->view->template = 'search_results';
	}

	function show_latest()
	{
		$per_page = intval($this->agora_user['disp_topics']) > 0 ? $this->agora_user['disp_topics'] : intval($this->				agora_config['o_disp_topics_default']);
		$count = $this->search_model->count_latest(24);
		print $count;
		$num_pages = ceil($count / $per_page);
		
//		$this->setPagination($num_pages);

		$page = Agora::getPage($num_pages);
		$s_res = $this->search_model->getLatest(24,$per_page,$page);

		$topic_helper = & $this->helper('topic');
		$s_res = $topic_helper->processRatings($s_res);
		$s_res = $topic_helper->processTopics($s_res);

		$forums_model = & Model::getInstance('ForumModel');
		$forums = $forums_model->loadNames();

		foreach ($s_res as $key => $value) {
			if (!$this->access_model->authenticate($this->agora_user['id'],$value['forum_id'],'read')) {
				unset($s_res[$key]);
				$count -= 1;
				continue;
			}

			if (isset($forums[$value['forum_id']])) {
				$s_res[$key]['forum_name'] = $forums[$value['forum_id']];
			} else {
				$s_res[$key]['forum_name'] = '';
			}
		}

		$num_pages = ceil($count / $per_page);

		$this->setPagination($num_pages);

		$this->view->assign('star_path',Agora::getRoot()."img/rate_stars/default_stars/");
		$this->view->assign('show_as','topics');
		$this->view->assignRef('search_result',$s_res);
		$this->view->template = 'search_results';
	}

	function show_unanswered()
	{
		$per_page = intval($this->agora_user['disp_topics']) > 0 ? $this->agora_user['disp_topics'] : intval($this->				agora_config['o_disp_topics_default']);
		$num_pages = ceil(($this->search_model->count_unanswered())/ $per_page);
		$this->setPagination($num_pages);
		$this->view->assign('star_path',Agora::getRoot()."img/rate_stars/default_stars/");
		$page = Agora::getPage($num_pages);
		$s_res = $this->search_model->getUnanswered($per_page,$page);

		$topic_helper = & $this->helper('topic');
		$s_res = $topic_helper->processRatings($s_res);
		$s_res = $topic_helper->processTopics($s_res);
		
		$forums_model = & Model::getInstance('ForumModel');
		$forums = $forums_model->loadNames();

		foreach ($s_res as $key => $value) {
			if (!$this->access_model->authenticate($this->agora_user['id'],$value['forum_id'],'read')) {
				unset($s_res[$key]);
				continue;
			}
			
			if (isset($forums[$value['forum_id']])) {
				$s_res[$key]['forum_name'] = $forums[$value['forum_id']];
			} else {
				$s_res[$key]['forum_name'] = '';
			}
		}


		$this->view->assign('show_as','topics');
		$this->view->assignRef('search_result',$s_res);
		$this->view->template = 'search_results';
	}

	function _default()
	{
		$this->view->template = 'search';
	}

}

?>
