<?php
    defined ('IN_AGORA') or die;

	class TaskController extends AgoraController {
		
		function __construct()
		{
			parent::__construct();
			$this->loadDefaultView();
		}

		function gmap()
		{
			$this->view->template = 'misc/gmap';
		}

		function rules()
		{
			$this->view->template = 'misc/rules';
		}

		function captcha()
		{
			ainclude('include|kcaptcha|kcaptcha.php');
			$captcha = new KCAPTCHA();
			Agora::setSessionVar('captcha',$captcha->getKeyString());
			Agora::setVar('type','raw');
		}

		function map()
		{
/*			$m_cat = new CategoryModel();
			$m_forum = new ForumModel();

			$categories = $m_cat->loadAll();
			foreach ($categories as $c_key => $cat) {
				$forums = $m_cat->loadForums($cat['id']);
				foreach ($forums as $f_key => $forum) {
					$topics = $m_forum->loadTopics($forum['id']);
					$forums[$f_key]['topics'] = $topics;
				}
				$categories[$c_key]['forums'] = $forums;
			}
			$this->view->smarty->assign('categories',$categories);*/
			$board_model = & Model::getInstance('BoardModel');
			$forums = $board_model->loadForumList();

			$forum_model = & Model::getInstance('ForumModel');
            foreach($forums as $cat => $cat_forums) {
            	foreach ($cat_forums['forums'] as $key=>$forum) {
	            	$forums[$cat][$key]['topics'] = $forum_model->loadTopics($forum['id']);
	            }
            }
			
			$this->view->smarty->assign('categories',$forums);
			$this->display("misc/map");
		}

		function markRead()
		{
			$topic_model = & Model::getInstance('TopicModel');
			$topic_model->markAllRead($this->agora_user['id'], $this->agora_config['o_timeout_visit'] * 86400);
	
	        if (isset($_SERVER['HTTP_REFERER'])) {
				Agora::redirect($_SERVER['HTTP_REFERER']);
	        } else {
	        	Agora::redirect(Agora::makeURL());
		    }
		}
	}
?>
