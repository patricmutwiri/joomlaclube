<?php
	defined ('IN_AGORA') or die;

	class AgoraPostController extends AgoraController
	{
		function __construct()
		{
			parent::__construct();
            if ( strpos($_SERVER['PHP_SELF'],'index2.php')!=0 ) $mode='agroup';
            else $mode='';
            
            if ('agroup'==$mode)
            $this->loadDefaultView( null, 'view_agroup');
            else
            $this->loadDefaultView();
						
			$this->id = Agora::getRequestVar('id',null);

			$smilies_model = & Model::getInstance('SmiliesModel');
			$smilies = $smilies_model->loadAll();

			$this->view->assignRef('smilies',$smilies);

			$this->topic_model = & Model::getInstance('TopicModel');
		}
	}
?>
