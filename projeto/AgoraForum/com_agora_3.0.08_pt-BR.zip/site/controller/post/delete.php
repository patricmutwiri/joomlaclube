<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraPostController
	{
		function _default()
		{
			$this->authenticatePost($this->id,'delete_posts');

			$post_model = & Model::getInstance('PostModel');
			$post = $post_model->load($this->id);

			$topic_model = & Model::getInstance('TopicModel');
			$forum_id = $topic_model->getForumId($post['topic_id']);

			$catnav_helper = & $this->helper('catnav');
			$catnav_helper->fromForum($forum_id);

			$this->view->assignRef('post',$post);

			$this->view->template = 'post/delete';
		}

		function _save()
		{
			$this->authenticatePost($this->id,'delete_posts');
			
			$post_model = & Model::getInstance('PostModel');
			$topic_id = $post_model->getTopicId($this->id);

			$post_model->delete($this->id);

			$topic_model = & Model::getInstance('TopicModel');
			
            if ( strpos($_SERVER['PHP_SELF'],'index2.php')!=0 ) $mode='agroup';
            else $mode='';            
            
            if ('agroup'==$mode)
			

			if ($topic_model->getPostCount($topic_id) == 0) {
				$forum_id = $topic_model->getForumId($topic_id);
				$topic_model->delete($topic_id);
                
				$url = array('task'	=>'forum', 'id'	=> $forum_id);				
				if ('agroup'==$mode)
				Agora::redirect(Agora::makeURL($url,true,true));
				else
				$this->redirect('task=forum','id='.$forum_id,'!page','!action');

			} else {
			    if ('agroup'==$mode)
				Agora::redirect(Agora::makeURL(
					array(
					'task'	=>'topic',
					'id'	=>$topic_id),true,true
				));			    
			    else
				Agora::redirect(Agora::makeURL(
					array(
					'task'	=>'topic',
					'id'	=>$topic_id)
				));
			}
			return;
		}
	}
?>
