<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraPostController
	{
		function _default()
		{
            $mode = Agora::getVar('mode');                        
            if ( strpos($_SERVER['PHP_SELF'],'index2.php')!=0 ) $mode='agroup';
		    
			$forum_model = & Model::getInstance('ForumModel');
			$this->authenticate($this->id,'post_topic');

			$forum = $forum_model->load($this->id);
			$this->view->assign('forum',$forum);

			$catnav_helper = & $this->helper('catnav');
			$catnav_helper->fromForum($this->id);

			$access_helper = & $this->helper('access');
			$access = $access_helper->getForumAccess($this->id);
			$this->view->assign('access',$access);

			$icons_model = & Model::getInstance('TopicIconsModel');
			$this->view->assign('post_body','');
			$this->view->assign('cur_forum_id',intval($this->id));
			$this->view->assign('topic_icons',$icons_model->loadAll());
			
            if ('agroup' == $mode)
            $this->view->template = 'post/topic_agroup';
            else
            $this->view->template = 'post/topic';
			
			
		}

		function save()
		{
            $mode = Agora::getVar('mode');                        
            if ( strpos($_SERVER['PHP_SELF'],'index2.php')!=0 ) $mode='agroup';
		    
			$this->authenticate($this->id,'post_topic');

			$forum_model = & Model::getInstance('ForumModel');
			$forum = $forum_model->load($this->id);

			if (!$this->agora_user['is_superadmin'] &&
				$this->access_model->authenticate($this->agora_user['id'],$forum['id'],'use_captcha')) {
				$captcha = Agora::getPostVar('captcha');
				$c_key = Agora::getSessionVar('captcha');

				if (trim($captcha) !== trim($c_key)) {
					Agora::showMessage(Agora::lang('Bad captcha'));
					Agora::redirect(Agora::getRefferer());
				}
			}

			$topic_model = & Model::getInstance('TopicModel');

			$subject = Agora::getPostVar('subject','No subject');
			$desc = Agora::getPostVar('desc','');

			$message = Agora::getPostVar('req_message','', true);
			
			$hide_smilies = Agora::getPostVar('hide_smilies',0);
			$topic_icon = intval(Agora::getPostVar('topic_icon',0));

			$topic_id = $topic_model->add($this->id, $subject,$desc, $topic_icon, $this->agora_user['username'],$this->agora_user['id'],$message, $hide_smilies);
			$api_AUP = JPATH_SITE.DS.'components'.DS.'com_alphauserpoints'.DS.'helper.php';
			
			if (file_exists($api_AUP))	{
				require_once ($api_AUP);
				AlphaUserPointsHelper::newpoints( 'plgaup_newtopic_agora', '', '', Agora::lang('AUP_TOPIC'));
			}

			$timeout = AGORA_TIME - intval($this->agora_config['o_timeout_visit']) * 86400;
			$topic_model->cleanupRead($timeout);
			
			$topic = $topic_model->load($topic_id);
			
			if ($subscribe = Agora::getPostVar('subscribe',0)) 
			{
				$subscription_model = & Model::getInstance('SubscriptionModel');
				$subscription_model->add(array('user_id'=>$this->agora_user['id'],'topic_id'=>$topic_id));
		
				Agora::showMessage(Agora::lang('You are now subscribed on topic ').AString::escape($topic['subject']));
			}


//			$topic_model->addPost($topic_id, $this->id, $message, $this->agora_user['id'], $this->agora_user['username'], $hide_smilies);

			$subscription_helper = & $this->helper('subscription');
			$subscription_helper->newPost($topic['last_post_id'],$this->id);
			
			if ('agroup'==$mode)
			Agora::redirect(Agora::makeURL(
				array(
					'task'	=>'topic',
					'id'	=>$topic_id),true,true
				));
			else
			Agora::redirect(Agora::makeURL(
				array(
					'task'	=>'topic',
					'id'	=>$topic_id)
				));
		}

		function preview()
		{
			$topic_icon = intval(Agora::getPostVar('topic_icon',0));
			$desc = Agora::getPostVar('desc','');
			$subject = Agora::getPostVar('subject','');

			$raw_message = Agora::getPostVar('req_message','', true);
			$message = $raw_message;
			$hide_smilies = Agora::getPostVar('hide_smilies',0);

			$parser = $this->helper('parser');

			$message = $parser->parseMessage($raw_message, $hide_smilies);

			$signature = '';
			if ($this->agora_user['show_sig']) {
				$signature = $parser->parseSignature($this->agora_user['signature']);
			}

			$post = array();
			$post = array();
			$post['user'] = $this->agora_user;
			$post['id'] = 0;

			$post['poster_id'] = $this->agora_user['id'];
			$post['poster'] = $this->agora_user['username'];
			$post['posted'] = time();

			$user_helper = &$this->helper('user');

			$post['user'] = $user_helper->prepareUserAvatar($post['user']);
			$post['user'] = $user_helper->prepareUserTitle($post['user']);

//			$post['id'] = 0;
/*			$post['poster_id'] = $this->agora_user['id'];
			$post['poster'] = $this->agora_user['username'];
			$post['posted'] = time();*/

			$post['message'] = $message;
			$post['user']['signature'] = $signature;

			$topic = array();
			$topic['status'] = 'ag_inew';
			// we don't know id, but we need something for topic_row.tpl
			$topic['id'] = -1;
			$topic['icon_topic'] = $topic_icon;
			$topic['subject'] = $subject;
			$topic['descrip_t'] = $desc;
			$topic['poster'] = $this->agora_user['username'];
			$topic['sticky'] = 0;
			$topic['new'] = 1;
			$topic['num_views'] = 0;
			$topic['num_replies'] = 0;
			$topic['last_post'] = AGORA_TIME;
			$topic['last_poster'] = $this->agora_user['username'];

			$this->view->assignRef('topic',$topic);

			$this->view->assignRef('post',$post);
			$this->view->assign('access',array());
			$this->view->assign('post_num','-');
			$this->view->assign('topic_id',-1);
			$this->view->assign('post_id',-1);

			$this->view->assign('topic_icon',$topic_icon);
			$this->view->assign('raw_message',$raw_message);
			$this->view->assign('hide_smilies',$hide_smilies);

/*			$this->view->assign('merge',$merge);
			$this->view->assign('subscribe',$subscribe);*/

			$this->view->template = 'post/preview_topic';

			$this->display();
			jexit(0);
		}

		function delete()
		{
			$this->authenticateTopic($this->id,'delete_topics');
			
			$this->view->assign('topic_id',$this->id);
			$this->view->template = 'post/delete_topic';
		}

		function select_forum()
		{
			$this->view->assign('url',Agora::makeURL(array('task'=>'post','page'=>'topic')));
			$this->view->assign('agora_itemid', Agora::getVar('Itemid',''));
			$this->view->template = 'post/select_forum';
		}
	}

?>
