<?php
defined ('IN_AGORA') or die;

ainclude('include|controller');

?>
