<?php
    defined ('IN_AGORA') or die;

	class TaskController extends AgoraController {
		
		function __construct()
		{
			parent::__construct();
			$this->loadDefaultView();

			$this->view->assign('star_path',Agora::getRoot()."img/rate_stars/default_stars/");
		}

		function _save()
		{
/*			if ($this->agora_user['is_guest']) {
				Agora::showError('Bad request');
				$this->redirect('task=index','!action');
			}*/

			$id = Agora::getVar('id');

			$topic_model = & Model::getInstance('TopicModel');
			$ratings = $topic_model->getRatings($id);

			foreach ($ratings as $rating) {
				if ($rating['user_id'] == $this->agora_user['id']) {
					Agora::showError('You already voted');
					$this->redirect('task=topic','id='.$id);
				}
			}

			$ratings = Agora::getPostVar('ratings');

			if (is_null($ratings)) {
				Agora::showError('Bad request');
				return;
			}

			$topic_model->addRating($id,$this->agora_user['id'],$ratings);
			$this->redirect('task=topic','id='.$id);
		}

		function view()
		{
			$id = Agora::getVar('id');
			$topic_model = & Model::getInstance('TopicModel');
			$ratings = $topic_model->getRatings($id);

			$forum_id = $topic_model->getForumId($id);
			
			$catnav_helper = & $this->helper('catnav');
			$catnav_helper->fromForum($forum_id);

			$this->authenticate($forum_id,'read');

			$rate = null;
			foreach ($ratings as $key=>$rate) {
				$rating = intval($rate['rate']);
				if ($rating >= 0.0 && $rating < 0.25)
					$star = 'Star_0';
				elseif ($rating >= 0.25 && $rating < 0.75)
					$star = 'Star_0_Half';
				elseif ($rating >= 0.75 && $rating < 1.25)
					$star = 'Star_1';
				elseif ($rating >= 1.25 && $rating < 1.75)
					$star = 'Star_1_Half';
				elseif ($rating >= 1.75 && $rating < 2.25)
					$star = 'Star_2';
				elseif ($rating >= 2.25 && $rating < 2.75)
					$star = 'Star_2_Half';
				elseif ($rating >= 2.75 && $rating < 3.25)
					$star = 'Star_3';
				elseif ($rating >= 3.25 && $rating < 3.75)
					$star = 'Star_3_Half';
				elseif ($rating >= 3.75 && $rating < 4.25)
					$star = 'Star_4';
				elseif ($rating >= 4.25 && $rating < 4.75)
					$star = 'Star_4_Half';
				else
					$star = 'Star_5';

				$ratings[$key]['rating_star'] = $star;
			}
			$this->view->smarty->assign('ratings',$ratings);
			$this->view->template='rate_results';
		}

		function _default()
		{
			$id = Agora::getVar('id',-1);
			$topic_model = & Model::getInstance('TopicModel');

			$topic = $topic_model->load($id);
			if (!$topic) {
				Agora::showError(Agora::lang('Bad request'));
				$this->redirect('task=index','!action');
			}

			$this->authenticate($topic['forum_id'],'read');
			
			$catnav_helper = & $this->helper('catnav');
			$catnav_helper->fromForum($topic['forum_id']);

			$this->view->template = 'rate';
		}
	}
?>