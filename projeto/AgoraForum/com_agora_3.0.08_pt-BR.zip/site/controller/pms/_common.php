<?php
	defined ('IN_AGORA') or die;

	class AgoraPMSController extends AgoraController
	{
		function __construct()
		{
			parent::__construct();
			if ($this->agora_user['is_guest']) {
				Agora::showError('You cannot use PM');
				Agora::redirect(Agora::getRefferer());
			}

			if ($this->agora_config['o_pms_uddeim'] == '1') {
				
				$action = Agora::getVar('action');
				$box = Agora::getVar('box');

				if ($action == 'compose') {
					$task = 'new';
				} elseif ($box == '0') {
					$task = 'inbox';
				} elseif ($box == '1') {
					$task = 'outbox';
				} else {
					$task = '';
				}

				$url = Agora::makeURL(array('option'=>'com_uddeim','task'=>$task));
				Agora::redirect($url);
			}
			$this->loadDefaultView();

      // MH - 20091025 - adding this to make sure PMs have access to smilies
      $smilies_model = & Model::getInstance('SmiliesModel');
      $smilies = $smilies_model->loadAll();

      $this->view->assignRef('smilies',$smilies);
		}
	}
?>
