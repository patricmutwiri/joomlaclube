<?php
	defined ('IN_AGORA') or die;

	ainclude ('controller|pms|list');
?>
