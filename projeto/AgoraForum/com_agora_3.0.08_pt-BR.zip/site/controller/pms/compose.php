<?php

defined ('IN_AGORA') or die;

class TaskController extends AgoraPMSController
{
    function _default()
    {

        $pathway = & $this->helper('pathway');
        $pathway->add(Agora::lang('PMS'),Agora::makeURL(array('task'=>'pms')));
        $pathway->add(Agora::lang('Compose'),'');

        $send_to = intval(Agora::getVar("send_to"));
        $this->view->assign('send_to','');
        if ($send_to) {
            $user_model = &Model::getInstance('UserModel');
            $user = $user_model->load($send_to);
            if ($user) {
                $this->view->assign('send_to',$user['username']);
            }
        }
        $this->view->template = 'pms/send';
    }
    function processBody($eprocess, $body, $userid, $username, $name, $useremail, $sitename, $siteurl, $title, $message){


        $eprocess->setData($body);

        $eprocess->setUserId($userid);

        $eprocess->setName($name);

        $eprocess->setUserName($username);

        $eprocess->setEmail($useremail);

        $eprocess->setSiteName($sitename);

        $eprocess->setSiteURL($siteurl);

        $eprocess->setItemId(JRequest::getVar('Itemid'));

        $eprocess->setTitle($title);

        $eprocess->setMessage($message);

        return $eprocess->Process();
        // <style type="text/css">
    }

    function notification($user_email, $subject, $message = '')
    {
        $config =& JFactory::getConfig();
        $mail =& JFactory::getMailer();
        $parser = & $this->helper('parser');
        $eprocess = & $this->helper('emailprocessor');

            /*$body  =  $this->agora_config['o_pm_messg'];
            $body .= " \n \n ". JText::_( 'Subject' ) ."- " . $subject;
            $body .= "\n ". JText::_( 'Visit' ) . " " . $config->getValue( 'config.sitename' );
            $body .= " " . JText::_( 'To read your messages' ) ." \n" ;
            $body .= " " . $config->getValue( 'config.live_site' );*/


        $username = Agora::getPostVar('req_username','');
        $message = Agora::getPostVar('req_message','',true);
        $hide_smilies = Agora::getPostVar('hide_smilies',0);
        $save_message = Agora::getPostVar('savemessage',0);

        $user_model = & Model::getInstance('UserModel');
        $user_id = $user_model->getUserId($username);
        $user_email = $user_model->getUserEmail($username);
        $user_fullname = $user_model->getUserFullName($username);


        $parser->enable_img = 'True';
        $message = $parser->bbcode($parser->links($parser->smilies($message)));


        $body = $this->processBody($eprocess, $this->agora_config['o_pm_messg'], $user_id, $username, $user_fullname, $user_email, $config->getValue( 'config.sitename' ), JURI::root(), $subject, $message);
        $emailSubject = $this->processBody($eprocess, $this->agora_config['o_pm_subject'], $user_id, $username, $user_fullname, $user_email, $config->getValue( 'config.sitename' ), JURI::root(), $subject, $message);
        $mail->addRecipient( $user_email );
        $mail->setSubject($emailSubject);
        $mail->setBody( $body );
        $mail->AltBody = $eprocess->getPlainData();
        $mail->IsHTML(true);

        if ($mail->Send()) { }

    }

    function editpms()
    {
        $this->view->assign('post_body',Agora::getPostVar('req_message','',true));
        $this->view->assign('post_subject',Agora::getPostVar('req_subject',''));
        $this->view->assign('edit_unsaved',1);
        $this->view->assign('send_to',Agora::getPostVar('req_username',''));

        if (Agora::getPostVar('PMSReply')) {

            $pathway = & $this->helper('pathway');
            $pathway->add(Agora::lang('PMS'),Agora::makeURL(array('task'=>'pms')));
            $pathway->add(Agora::lang('Reply'),'');

        }
        else
        {
            $pathway = & $this->helper('pathway');
            $pathway->add(Agora::lang('PMS'),Agora::makeURL(array('task'=>'pms')));
            $pathway->add(Agora::lang('Compose'),'');
        }

        $this->view->template = 'pms/send';
    }


    function _preview()
    {
        $raw_message = Agora::getPostVar('req_message','',true);
        $message = $raw_message;
        $hide_smilies = Agora::getPostVar('hide_smilies',0);
        $req_username = Agora::getPostVar('req_username','');
        $req_subject = Agora::getPostVar('req_subject','');

        $parser = & $this->helper('parser');

        $message = $parser->parseMessage($message,$hide_smilies);

        $post = array();
        $topic = array();

        $post['user'] = $this->agora_user;
        //Agora::prepareUser($post['user'],$this->agora_config['o_ranks']);
        $user_helper = & $this->helper('user');
        $post['user'] = $user_helper->prepareUserAvatar($post['user']);
        $post['user'] = $user_helper->prepareUserTitle($post['user']);

        $post['id'] = 0;
        $post['poster_id'] = $this->agora_user['id'];
        $post['poster'] = $this->agora_user['username'];
        $post['posted'] = time();
        $post['message'] = & $message;

        $topic['subject'] = $req_subject;

        if (Agora::getPostVar('PMSReply')) {
            $this->view->assignRef('PMSReply',Agora::getPostVar('PMSReply'));
        }

        $this->view->assignRef('post',$post);
        $this->view->assignRef('topic',$topic);

        $this->view->assign('access',array());

        $this->view->assign('raw_message',$raw_message);
        $this->view->assign('req_username',$req_username);
        $this->view->assign('req_subject',$req_subject);
        $this->view->assign('hide_smilies',$hide_smilies);

        $this->view->assign('pms_preview',true);

/*			$this->view->assign('merge',$merge);
            $this->view->assign('subscribe',$subscribe);*/

        $pathway = & $this->helper('pathway');
        $pathway->add(Agora::lang('PMS'),Agora::makeURL(array('task'=>'pms')));
        $pathway->add(Agora::lang('Preview'),'');

        $this->view->template = 'pms/preview';


    }

    function send()
    {
        if (Agora::getPostVar('preview')) {
            $this->_preview();
            return;
        }
        if (Agora::getPostVar('editpms')) {
            $this->editpms();
            return;
        }
        $subject = Agora::getPostVar('req_subject','');
        $username = Agora::getPostVar('req_username','');
        $message = Agora::getPostVar('req_message','',true);
        $hide_smilies = Agora::getPostVar('hide_smilies',0);
        $save_message = Agora::getPostVar('savemessage',0);

        $user_model = & Model::getInstance('UserModel');
        $user_id = $user_model->getUserId($username);
        $user_email = $user_model->getUserEmail($username);

        if (!$user_id) {
            Agora::showError('Invalid user');
            $this->redirect();
        }

        $pms_model = & Model::getInstance('PMSModel');

        $pms_model->sendMessage($this->agora_user['id'],$this->agora_user['username'],$user_id, $username, $subject, $message, $hide_smilies, $save_message);
        $this->notification($user_email, $subject, $message);
        $this->redirect('!page');
    }
}
?>
