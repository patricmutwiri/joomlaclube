<?php

	defined ('IN_AGORA') or die;

	class TaskController extends AgoraPMSController
	{
		function _default()
		{
			$box = Agora::getVar('box');

			if (is_null($box)) {
				$box = intval(Agora::getPostVar('box',0));
			}

			$this->view->assign('box',$box);

			$pms_model = & Model::getInstance('PMSModel');

			$per_page = $this->agora_config['o_pms_mess_per_page'];
			$pages = Agora::getTotalPages($pms_model->getTotal($this->agora_user['id'],$box), $per_page);
			$page = Agora::getPage($pages);

			$messages = $pms_model->loadMessages($this->agora_user['id'],$box, $per_page, $page);

/*			foreach ($messages as & $message) {
				if (!$message['showed']) {
					$message['icon_text'] = Agora::lang('Normal icon');
					$message['icon_type'] = 'icon';;
				} else {
					$message['icon_text'] = ' '.Agora::lang('New icon');
					$message['icon_type'] = 'inew';				}
			}*/


			$this->setPagination($pages);

			$pathway = & $this->helper('pathway');

			$pathway->add(Agora::lang('PMS'),Agora::makeURL(array('task'=>'pms')));

			if ($box == 0)
			{
				$pathway->add(Agora::lang('Inbox'),Agora::makeURL(array('task'=>'pms','box'=>'0')));
			} else {
				$pathway->add(Agora::lang('Sent'),Agora::makeURL(array('task'=>'pms','box'=>'1')));
			}

			$this->view->assign('messages',$messages);
			$this->view->template = 'pms/list';
		}

		function delete()
		{
			$ids = Agora::getPostVar('delete_messages',null);
			if (is_null($ids)) {
				$ids = Agora::getVar('delete_messages',array());
			}

			if (!is_array($ids)) {
				$ids = array($ids);
			}

			$pm_model = & Model::getInstance('PMSModel');

			foreach ($ids as $id) {
				$post = $pm_model->load($id);

				if ($post['sender_id'] != $this->agora_user['id'] && $post['owner'] != $this->agora_user['id']) {
					Agora::showError('Permission denied');
					$this->redirect('box');
				}
				$pm_model->delete($id);
			}
			$this->redirect('box');
		}
	}

?>
