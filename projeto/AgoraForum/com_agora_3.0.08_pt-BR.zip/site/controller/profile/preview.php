<?php
    defined ('IN_AGORA') or die;

    class TaskController extends AgoraProfileController
	{
		function _default()
		{
			//Agora::prepareUser($this->user, $this->agora_config['o_ranks']);
			$user_helper = & $this->helper('user');
			$this->user = $user_helper->prepareUserAvatar($this->user);
			$this->user = $user_helper->prepareUserTitle($this->user);
			$this->user = $user_helper->prepareUserUrl($this->user);

			$parser = & $this->helper('parser');
			$this->user['signature'] = $parser->parseSignature($this->user['signature']);
			$this->user['aboutme'] = $parser->parseSignature($this->user['aboutme']);

			$this->user['email'] = JHTML::_('email.cloak', $this->user['email']);

			if (!empty($this->user['birthday']))
			{
				$date_format = $this->agora_config['o_date_format'];
				if (!empty($this->user['hide_age'])) $date_format = trim(eregi_replace('[ \./-]?y+[ \./-]?', '', $date_format));
				$this->user['birthday'] = date($date_format, $this->user['birthday']);
			}
		}
	}
?>
