<?php
defined ('IN_AGORA') or die;

class AgoraProfileController extends AgoraController
{
    function __construct()
    {
        parent::__construct();

/*			if ($this->agora_user['is_guest']) {
                Agora::showError(Agora::lang('Permission denied'));
                Agora::redirect(array());
            }*/

        $this->loadView('ProfileView','profileview.php');

            /*if (method_exists($this,'loadModel')) {
                $this->loadModel();
            }*/
        $this->model = & Model::getInstance('UserModel');
        $this->user_id = Agora::getRequestVar('user_id');
        unset($this->user);
        if (is_null($this->user_id)) {
			// guest cannot open his own profile
			if ($this->agora_user['is_guest']) {
                Agora::showError(Agora::lang('Permission denied'));
                Agora::redirect(Agora::getRefferer());
            }
            $this->user_id = $this->agora_user['id'];
            $this->user = & $this->agora_user;
        } else {
            $this->user = $this->model->load($this->user_id);
			
			if (!$this->user) {
				Agora::showError(Agora::lang('User not found'));
				Agora::redirect(Agora::getRefferer());
			}
        }

        if ($this->agora_config['o_community_builder'] == '1') {
            $url = Agora::makeURL(array('option'=>'com_comprofiler','user'=>$this->user['jos_id']));
            Agora::redirect($url);
        }

        if ($this->agora_config['o_jomsocial'] == '1') {
            $url = Agora::makeURL(array('option'=>'com_community','view'=>'profile','userid'=>$this->user['jos_id']));
            Agora::redirect($url);
        }

        if ($this->agora_config['o_joomunity'] == '1') {
            $url = Agora::makeURL(array('option'=>'com_joomunity','cmd'=>'Profile.view.'.$this->user['jos_id']));
            Agora::redirect($url);
        }

        // Switch these next two lines for Admin Edits in Front end-
        // if ($this->user_id != $this->agora_user['id'] && !$this->agora_user['is_admin']) {
        if ($this->user_id != $this->agora_user['id']) {

            // a bit dirty. Need better routing here

            $page = Agora::getVar('page');
            //if ($page !== 'preview') {
            if ($this->toRedirect()){
                $this->redirect('page=preview');
            }
            //}

            $this->view->assign('preview_only',true);
        } else {
            $this->view->assign('preview_only',false);
		}

        $this->view->assignRef('user',$this->user);
    }
    function toRedirect(){
        $ret = false;
        $user_id = Agora::getRequestVar('user_id');
        $page = Agora::getRequestVar('page');
        $task = Agora::getRequestVar('task');
        if (!is_null($user_id) && is_null($page) && $task='profile'){
            $ret = true;
        }else{
            $ret = false;
        }

        return $ret;
    }
    function redirect()
    {
        $args = func_get_args();
        $args[] = 'user_id';
        call_user_func_array(array('AgoraController','redirect'),$args);
    }

    function _execute($method)
    {
        $action = Agora::getVar('action');
        $page = Agora::getVar('page');
        if ($action) {
            $this->display($action);
        } elseif ($page) {
            $this->display($page);
        } else {
            $this->display('personal');
        }
    }

}

?>
