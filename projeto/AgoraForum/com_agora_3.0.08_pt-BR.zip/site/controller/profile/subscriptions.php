<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraProfileController
	{
		
		function _default()
		{
			if ($this->agora_user['is_guest']) {
				Agora::showError(Agora::lang('Please login to view Subscriptions! '));
			}
			
			$sub_model 		= &Model::getInstance('SubscriptionModel');
			
			$topic_count 	= $sub_model->countSubscribedTopics($this->user['id']);
			$forum_count 	= $sub_model->countSubscribedForums($this->user['id']);
			$per_page		= intval($this->agora_config['o_disp_posts_default']);
			$num_pages 		= ceil( $topic_count / $per_page);
			$page 			= Agora::getPage($num_pages);
			$toipcs 		= $sub_model->getSubscribedTopics($this->user['id'], $per_page,$page );
			$forums 		= $sub_model->getSubscribedForums($this->user['id']);

			$this->setPagination($num_pages);
			
			$this->view->assign('topics',$toipcs);
			$this->view->assign('forums',$forums);
			$this->view->assign('num_pages',$num_pages);
			$this->view->assign('topic_count',$topic_count);
			$this->view->assign('forum_count',$forum_count);
			
		}
		
		function save()
		{
			$form = Agora::getPostVar('form',array());
			Agora::filterForm($form,array('auto_subscriptions'=>0));
			$this->model->edit($this->user_id,$form);
			$this->redirect();

		}
	}
?>
