<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraProfileController
	{
		function save()
		{
			$form = Agora::getPostVar('form',array());

			Agora::filterForm($form,
					array(
						'show_smilies',
						'show_sig',
						'show_avatars',
						'show_img',
						'show_img_sig',
						'reverse_posts',
						'disp_topics' => null,
						'disp_posts' => null,
						'reputation_enable',
					));

			if (empty($form['disp_topics'])) $form['disp_topics'] = null;
			if (empty($form['disp_posts'])) $form['disp_posts'] = null;

			$this->model->edit($this->user_id,$form);
			$this->redirect();
			return;
		}
	}
?>
