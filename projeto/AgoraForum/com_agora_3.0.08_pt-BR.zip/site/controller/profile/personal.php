<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraProfileController
	{
		function _default()
		{
			if (!empty($this->user['birthday'])) {
				$birthday = getdate($this->user['birthday']);


				$this->view->assign('birthday',array(
						'day'	=>	$birthday['mday'],
						'month'	=>	$birthday['mon'],
						'year'	=>	$birthday['year']
					));
			} else {
				$this->view->assign('birthday',array('day' => 0, 'month' => 0, 'year' => 0));
			}

			$ban_model = &Model::getInstance('BanModel');
			$this->user['banned'] = $ban_model->isBanned($this->user['username']);
			if ($this->user['banned']) {
				$ban = $ban_model->load($this->user['username'],'username');
				$this->view->assign('ban',$ban);
			}

			$warning_model = &Model::getInstance('WarningModel');
			$warnings = $warning_model->loadByUser($this->user['id']);

			$this->view->assign('warnings',$warnings);
		}

		function add_warning()
		{
			$warning_model = &Model::getInstance('WarningModel');
			$warnings = $warning_model->loadAll();
			$this->view->assign('warnings',$warnings);

			$this->view->template = 'add_warning';
		}

		function save_warning()
		{
			$form = Agora::getPostVar('form');

			$warnings_model = &Model::getInstance('WarningModel');
			$warnings_model->addToUser($this->user['id'], $form['warning_id'],$form['message']);
			$this->redirect();
		}

		function set_ban()
		{
			$this->view->template = 'set_ban';
		}

		function ban()
		{
			$ban_model = &Model::getInstance('BanModel');
			$form = Agora::getPostVar('form');

			$e = & $form['expire'];
			$expire = intval($e['days'])*3600 * 24 + intval($e['hours']) * 3600 + intval($e['minutes']) * 60;
			$expire = AGORA_TIME + $expire;

			$ban_model->banUser($this->user['username'],$form['message'],$expire);

			$this->redirect();
		}

		function unban()
		{
			$ban_model = &Model::getInstance('BanModel');
			$ban_model->unBanUser($this->user['username']);
			$this->redirect();
		}

		function save()
		{
			$form = Agora::getPostVar('form',array());
			if (checkdate(
				$form['birthday-month'],
				$form['birthday-day'],
				$form['birthday-year'])) {

				$form['birthday'] = mktime(0,0,0, $form['birthday-month'], $form['birthday-day'], $form['birthday-year']);
			} else {
				$form['birthday'] = 0;
			}
			unset($form['birthday-month']);
			unset($form['birthday-year']);
			unset($form['birthday-day']);
			if ($form['url']) {
				if(!stristr($form['url'],"http://")){
					$form['url'] = "http://" . $form['url'];
					JError::raiseNotice( 0, JText::_('Add http' ) );
				}
			}
			$this->model->edit($this->user_id,$form);
			$this->redirect();
		}
	}
?>
