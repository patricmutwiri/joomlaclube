<?php
    defined ('IN_AGORA') or die;

    class TaskController extends AgoraProfileController
	{

		function __construct()
		{
			parent::__construct();

			$this->category = Agora::getRequestVar('category','Modon Pack');

			$this->category = str_replace(array('..','\\','/'),'',$this->category);

			if (trim($this->category) == '') {
				$this->category = 'Modon Pack';
			}
		}

		function _default()
		{
			$categories = array();

			//$av_path = AGORA_PATH.DS.'img'.DS.'pre_avatars'.DS;
			$av_path = JPATH_BASE . DS . $this->agora_config['o_avatars_dir'] .DS;
			$dir = dir($av_path);
			while ($entry = $dir->read())
			{
				if (!is_dir($av_path.$entry)) continue;
//				if($entry === '.' || $entry === '..') continue;
				// don't include directories like .svn
				if (strpos($entry,'.') === 0) continue;

				$categories[] = $entry;
			}
			$dir->close();

			$this->view->assignRef('categories',$categories);

			$avatars=array();

			//$dir = dir(AGORA_PATH.DS.'img'.DS.'pre_avatars'.DS.$this->category.DS);
			$dir = dir(JPATH_BASE . DS . $this->agora_config['o_avatars_dir'] .DS. $this->category.DS);
			while ($entry = $dir->read())
			{
				$ext = strtoupper(substr($entry, -4));
				if ($ext == '.JPG' || $ext == '.GIF' || $ext == '.PNG') {
					$avatars[] = array(
						'name' => substr($entry,0,strlen($entry)-4),
						'file' => $entry
					);
				}

			}
			$avpath = JURI::root(). $this->agora_config['o_avatars_dir'] .'/';

			$this->view->assign('category',$this->category);
			$this->view->assignRef('avatars',$avatars);
			$this->view->assign('avpath',$avpath);
		}

		function change_category()
		{
			$this->redirect('category='.htmlentities($this->category));
		}

		function save()
		{
			$PIA = Agora::getPostVar('PIA');

			$ext = substr($PIA, -4);

			//$file = AGORA_PATH.DS.'img'.DS.'pre_avatars'.DS.$this->category.DS.$PIA;
			$file = JPATH_BASE . DS . $this->agora_config['o_avatars_dir'] .DS. $this->category.DS.$PIA;

			//$f_name = AGORA_PATH.DS.'img'.DS.'pre_avatars'.DS.$this->user_id;
			$f_name = JPATH_BASE . DS . $this->agora_config['o_avatars_dir'] .DS.$this->user_id;

			$new_file = $f_name.$ext;

			@unlink($f_name.'.gif');
			@unlink($f_name.'.jpg');
			@unlink($f_name.'.png');

			if (!copy($file, $new_file)) {
				Agora::showError(Agora::lang('Unable to copy avatar file'));
				$this->redirect();
			}

			chmod($new_file, 0644);

			$this->model->edit($this->user_id,array('use_avatar' => 1));
			$this->redirect('page=personality');
		}

		function delete()
		{
			//$f_name = AGORA_PATH.DS.'img'.DS.'pre_avatars'.DS.$this->user_id;
			$f_name = JPATH_BASE . DS . $this->agora_config['o_avatars_dir'] .DS.$this->user_id;

			@unlink($f_name.'.gif');
			@unlink($f_name.'.jpg');
			@unlink($f_name.'.png');

			$this->model->edit($this->user_id,array('use_avatar' => 0));

			$this->redirect('page=personality');
		}

		function upload()
		{
			$this->view->template = 'upload_avatar';
		}

		function save_upload()
		{
			if (!isset($_FILES['req_file'])) {
				Agora::showError(Agora::lang('Bad request'));
				$this->redirect('action');
			}

			$uploaded_file = $_FILES['req_file'];

			if (isset($uploaded_file['error']) && $uploaded_file['error'] != UPLOAD_ERR_OK) {
				Agora::showError(Agora::lang('Upload error'));
				$this->redirect('action');
			}

			if (!is_uploaded_file($uploaded_file['tmp_name'])) {
				Agora::showError(Agora::lang('Upload error'));
				$this->redirect('action');
			}

			$allowed_types = array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/x-png');
			
			if (!in_array($uploaded_file['type'], $allowed_types)) {
				Agora::showError(Agora::lang('Only images are allowed'));
				$this->redirect('action');
			}

			if ($uploaded_file['size'] > $this->agora_config['o_avatars_size']) {
				Agora::showError(Agora::lang('Avatar is too large. Maximum allowed').' '.$this->agora_config['o_avatars_size']);
				$this->redirect('action');
			}

			$ext = null;
			if ($uploaded_file['type'] == 'image/gif')
				$ext = '.gif';
			elseif ($uploaded_file['type'] == 'image/jpeg' || $uploaded_file['type'] == 'image/pjpeg')
				$ext = '.jpg';
			else
				$ext = '.png';

			//$src_file = AGORA_PATH.'img'.DS.'pre_avatars'.DS.$this->user_id.'.tmp';
			$src_file = JPATH_BASE . DS . $this->agora_config['o_avatars_dir'] .DS.$this->user_id.'.tmp';
			// Move the file to the avatar directory. We do this before checking the width/height to circumvent open_basedir restrictions.
			if (!@move_uploaded_file($uploaded_file['tmp_name'], $src_file)) {
				Agora::showError(Agora::lang('Cannot move uploaded file. Bad permissions'));
				$this->redirect('action');
			}

			list($width, $height, $type,) = getimagesize($src_file);
			if (empty($width) ||
				empty($height) ||
				$width > $this->agora_config['o_avatars_width'] ||
				$height > $this->agora_config['o_avatars_height'])
			{
				@unlink($src_file);
				Agora::showError(Agora::lang('Avatar is too large. Maximum allowed').' '.$this->agora_config['o_avatars_width'].'x'.$this->agora_config['o_avatars_height']);
				$this->redirect('action');
			}
			elseif ($type == 1 && $uploaded_file['type'] != 'image/gif')	// Prevent dodgy uploads
			{
				@unlink($src_file);
				Agora::showError(Agora::lang('Upload error (dodgy upload)'));
				$this->redirect('action');
			}

			//$dest_file = AGORA_PATH.DS.'img'.DS.'pre_avatars'.DS.$this->user_id;
			$dest_file = JPATH_BASE . DS . $this->agora_config['o_avatars_dir'] .DS.$this->user_id;

			@unlink($dest_file.'.gif');
			@unlink($dest_file.'.png');
			@unlink($dest_file.'.jpg');
			@rename($src_file, $dest_file.$ext);

			@chmod($dest_file.'.'.$ext, 0644);

			$this->model->edit($this->user_id,array('use_avatar' => 1));

			$this->redirect('page=personality');
		}
	}

?>
