<?php
	defined ('IN_AGORA') or die;
	
	class TaskController extends AgoraController
	{
		function _execute()
		{
			if (!isset($this->agora_config['o_rss_cron_builtin']) || !isset($this->agora_config['o_rss_cron_interval'])) {
				$config_model = & Model::getInstance('ConfigModel');
				$conf['o_rss_cron_builtin'] = 1;
				$conf['o_rss_cron_interval'] = 3600;
				$conf['o_rss_cron_last'] = time() - 3600;
				Model::getInstance('ConfigModel')->save($conf);
				Agora::redirect(Agora::makeURL());
				return;
			}
				
			if ($this->agora_config['o_rss_cron_builtin'] == '1') {
				Agora::redirect(Agora::makeURL());
				return;
			}
			
			echo "Agora cronjob. Fetching feed urls";
			$feed_model = & Model::getInstance('AggregatorModel');
			$feed_model->runJob();
			die;
		}
		
	}
?>
