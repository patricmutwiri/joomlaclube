<?php
defined ('IN_AGORA') or die;

ainclude("view|markerview");

class TaskController extends AgoraController
{

	function __construct()
	{
		$this->view = new MarkerView();
	}

	function _execute()
	{
		$user_model = & Model::getInstance('UserModel');
		$users = $user_model->loadAll();

		$config_model = & Model::getInstance('ConfigModel');
		$config = $config_model->load();

		foreach ($users as & $user) {
			//Agora::prepareUser($user,$config['o_ranks']);
			$this->user = $this->helper('user')->prepareUserAvatar($this->user);
			$this->user = $this->helper('user')->prepareUserTitle($this->user);
			
			$user['avatar_field'] = '';
		}

		$this->view->_users = & $users;
		$this->view->display();
	}
}

?>
