<?php
	defined ('IN_AGORA') or die;

	class TaskController extends AgoraController
	{
		function _default()
		{
			if (!$this->agora_config['o_rss_enabled']) {
				// empty feed
				$this->loadDefaultView();
				
				$this->view->assign('items',array());
				$this->view->assign('title',$this->agora_config['o_board_title']);
				$this->view->assign('link',Agora::makeFeedUrl(array()));
				$this->view->assign('description',$this->agora_config['o_board_desc']);
				return;
			}

			$tid = Agora::getVar('tid');
			$fid = Agora::getVar('fid');
			$cid = Agora::getVar('cid');
			$key = Agora::getVar('key');

			$user_model = &Model::getInstance('UserModel');
			if (!$key) {
				$this->agora_user = $user_model->loadGuest();
			} else {
				$this->agora_user = $user_model->loadByKey($key);
				if (!$this->agora_user) {
					$this->agora_user = $user_model->loadGuest();
				}
			}

			$this->loadDefaultView();
			$this->model = & Model::getInstance('FeedModel');

			if (! ($tid || $cid || $fid) ) {
				$this->_global();
				return;
			}

			if ($tid) {
				$this->authenticateTopic($tid,'read_rss');
				$this->_topic($tid);
				return;
			}

			if ($fid) {
				$this->authenticate($fid,'read_rss');
				$this->_forum($fid);
				return;
			}

			if ($cid) {
				$this->_category($cid);
				return;
			}
		}

		function & _processPosts(& $posts)
		{
			$items = array();

			foreach ($posts as $post) {
				$items[] = array (
						'title' => $post['topic_subject'],
						'date' => intval($post['posted']),
						'description' => $post['message'],
						'link' => Agora::makeFeedUrl(array('task'=>'topic','id'=>$post['topic_id'])).'#'.$post['id'],
					);
			}
			return $items;
		}

		function _global()
		{
			$posts = $this->model->getGlobalFeed();

			$access_model = & Model::getInstance('AccessModel');
			$allowed_forums = $access_model->getAllowedForums($this->agora_user['id'],'read_rss');

			foreach ($posts as $key=>$post) {
				if (!in_array($post['forum_id'],$allowed_forums)) {
					unset($posts[$key]);
				}
			}

			$this->view->assignRef('items',$this->_processPosts($posts));
			$this->view->assign('title',$this->agora_config['o_board_title']);
			$this->view->assign('link',Agora::makeFeedUrl(array()));
			$this->view->assign('description',$this->agora_config['o_board_desc']);
		}

		function _category($cat_id)
		{
			$posts = $this->model->getCategoryFeed($cat_id);

			$access_model = & Model::getInstance('AccessModel');
			$allowed_forums = $access_model->getAllowedForums($this->agora_user['id'],'read_rss');

			foreach ($posts as $key=>$post) {
				if (!in_array($post['forum_id'],$allowed_forums)) {
					unset($posts[$key]);
				}
			}

			$this->view->assignRef('items',$this->_processPosts($posts));
			$this->view->assign('title',$this->agora_config['o_board_title']);
			$this->view->assign('link',Agora::makeFeedUrl(array()));
			$this->view->assign('description',$this->agora_config['o_board_desc']);
		}


		function _forum($forum_id)
		{
			$posts = $this->model->getForumFeed($forum_id);

			$this->view->assignRef('items',$this->_processPosts($posts));
			$this->view->assign('title',$this->agora_config['o_board_title']);
			$this->view->assign('link',Agora::makeFeedUrl(array()));
			$this->view->assign('description',$this->agora_config['o_board_desc']);
		}

		function _topic($topic_id)
		{
			$posts = $this->model->getTopicFeed($topic_id);
			
			$this->view->assignRef('items',$this->_processPosts($posts));
			$this->view->assign('title',$this->agora_config['o_board_title']);
			$this->view->assign('link',Agora::makeFeedUrl(array()));
			$this->view->assign('description',$this->agora_config['o_board_desc']);
		}
	}
	
?>
