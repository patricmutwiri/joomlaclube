<?php
    defined ('IN_AGORA') or die;

	class TaskController extends AgoraPollsController
	{
		function _default()
		{
			$this->authenticate($this->id,'post_poll');

			$catnav_helper = & $this->helper('catnav');
			$catnav_helper->fromForum($this->id);
			
			$this->view->template = "poll/select";
		}

		function select_forum()
		{		    
		    $url = Agora::getSelf();
		    $mainframe =& JFactory::getApplication('site');
		    if ($mainframe->getCfg('sef'))
		    {
		        $url=substr($url, 0, strrpos($url, '/'));
		        $this->view->assign('self_url',$url);
		    }
		    // echo $url;exit;
			// filter allowed forums
			$forums = $this->forumList;

			if (!$this->agora_user['is_superadmin']) {
				foreach ($forums as $cat_id => $cat) {
					$this->access_model->filterForums($forums[$cat_id]['forums'],$this->agora_user['id'],'post_poll');
/*					foreach ($forums[$cat_id]['forums'] as $forum_id=>$forum) {
						$parent_id = $forum['parent_forum_id'];
						if ($parent_id == 0) continue;
						if (!isset($forums[$cat_id]['forums'][$parent_id])) {
							unset($forums[$cat_id]['forums'][$forum_id]);
						}
					}*/

					if (empty($forums[$cat_id]['forums'])) {
						unset($forums[$cat_id]);
					}
				}
			}

			$this->view->assign('allowed_forums',$forums);
			$this->view->template = "poll/select_forum";
		}
	}
?>
