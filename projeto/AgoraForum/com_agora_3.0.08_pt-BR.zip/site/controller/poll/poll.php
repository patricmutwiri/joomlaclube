<?php
    defined ('IN_AGORA') or die;

	class AgoraPollsController extends AgoraController {
		
		function __construct()
		{
			parent::__construct();
			$this->loadDefaultView();

			$this->id = Agora::getVar('id');

			if (!$this->id) {
				Agora::showError(Agora::lang('Bad request'));
				Agora::redirect(Agora::getRefferer());
			}
			$this->model = & Model::getInstance('PollModel');
		}

		function select()
		{
			$this->view->template = "poll/select";
//			$this->view->assign('cur_forum_id',intval($this->id));
		}

		function _execute()
		{
			$this->smilies = & Model::getInstance('SmiliesModel');
			$smilies = $this->smilies->loadAll();

			$this->view->assignRef('smilies',$smilies);

			$d = dir(AGORA_PATH.DS.'img'.DS.'icons');
			$topic_icons = array();
	        while (($entry = $d->read()) !== false)
        	{
    	        if (substr($entry, strlen($entry)-4) == '.gif')
	            {
            	    $topic_icons[] = substr($entry, 0, strlen($entry)-4);
        	    }
    	    }
	        $d->close();
			parent::_execute();
		}

	}

	$ptype = Agora::getVar('ptype');
	if (!$ptype) $ptype = Agora::getPostVar('ptype','regular');

	switch ($ptype) {
		case 'multi'		: ainclude ('controller|polls|multi'); break;
		case 'multi_yes_no'	: ainclude ('controller|polls|multi_yes_no'); break;
		case 'regular'		:
			ainclude ('controller|polls|regular'); break;

	}
?>