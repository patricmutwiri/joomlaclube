function gMapProfile(lng,lat,zoom,marker)
{
	var map = new GMap(document.getElementById("map"));
//	map.addControl(new GSmallMapControl());
	map.addControl(new GLargeMapControl());
	map.addControl(new GMapTypeControl());
	map.centerAndZoom(new GPoint(lng, lat), zoom);
	if (marker) {
		map.addOverlay(new GMarker(new GPoint(lng, lat)));
	}

	GEvent.addListener(map, 'click', function(overlay, point) {
		if (overlay) {
			map.removeOverlay(overlay);
			document.getElementById("lat").value='';
			document.getElementById("lng").value='';
		} else if (point) {
			map.clearOverlays();
	    	map.addOverlay(new GMarker(point));
			document.getElementById("lat").value=point.y;
		document.getElementById("lng").value=point.x;
		}
	});
}

function gMapProfilePreview(lng,lat,zoom)
{
	var map = new GMap(document.getElementById("map"));
	map.addControl(new GSmallMapControl());
	map.addControl(new GMapTypeControl());
	map.centerAndZoom(new GPoint(lng, lat), zoom);
	map.addOverlay(new GMarker(new GPoint(lng, lat)));
}
