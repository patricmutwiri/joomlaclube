<?php
	defined ('IN_AGORA') or die;

	class WarningModel extends Model
	{
		function __construct()
		{
			parent::__construct('warning');
		}
		
/*		function add($level, $message, $expire)
		{
			$q_level = intval($level);
			$q_message = $this->db->Quote($message);
			$q_expire = intval($expire);
			$this->setQuery("INSERT INTO ##__warning (points,message,expire) VALUES ($q_level, $q_message, $q_expire)");
			$this->db->query();
		}*/

/*		function copy($id)
		{
			$id = intval($id);
			$this->setQuery("SELECT * FROM ##__warning WHERE id='$id'");
			$old = $this->db->loadAssoc();

			$points = $this->db->Quote($old['points']);
			$message = $this->db->Quote($old['message']);
			$expire = $this->db->Quote($old['expire']);
			$image = $this->db->Quote($old['image']);

			$this->setQuery("INSERT INTO ##__warning (points, message, expire, image) VALUES ($points, $message, $expire, $image)");
			$this->db->query();
		}*/

		function loadByUser($user_id)
		{
			$this->db->bind('user_id',$user_id,'integer');
			$this->db->setQuery('SELECT *,u_warn.expire, u_warn.message, warn.message as default_message, points'.
							' FROM ##__user_warning AS u_warn'.
							' INNER JOIN ##__warning AS warn'.
							'  ON warn.id=u_warn.warning_id'.
							' WHERE user_id=:user_id');
			return $this->db->loadAssocList();
		}

		function addToUser($user_id, $warning_id, $message)
		{
			$this->setQuery('SELECT message, expire FROM ##__warning WHERE id='.intval($warning_id).' LIMIT 1');
			list($def_message,$expire) = $this->db->loadRow();
			$expire = time() + $expire;

			if (empty($message)) {
				$q_message = $this->db->Quote($def_message);
			} else {
				$q_message = $this->db->Quote($message);
			}
			
			$this->setQuery('INSERT INTO ##__user_warning'.
						' (user_id, warning_id, message, posted, expire)'.
						' VALUES ('.intval($user_id).','.intval($warning_id).','.$q_message.','.AGORA_TIME.','.$expire.')');
			$this->db->query();
		}

		function deleteFromUser($warning_id)
		{
			$this->setQuery('DELETE FROM ##__user_warning WHERE id='.intval($warning_id));
			$this->db->query();
		}
	}
?>