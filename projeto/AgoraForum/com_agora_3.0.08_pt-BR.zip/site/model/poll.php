<?php
	defined ('IN_AGORA') or die;

	class PollModel extends Model
	{
		function __construct()
		{
			parent::__construct('polls');
		}

		function getCount()
		{
			$this->setQuery('SELECT COUNT(*)'.
							' FROM ##__polls AS p'.
							' INNER JOIN ##__topics AS t ON p.pollid=t.id');
			return $this->db->loadResult();
		}

		function load($id)
		{
			$this->setQuery('SELECT'.
							' p.ptype, p.created, p.edited, p.options, p.voters, p.votes, '.
							' t.question, t.yes, t.no, t.id, t.subject'.
							' FROM ##__polls AS p'.
							' INNER JOIN ##__topics AS t ON p.pollid=t.id'.
							' WHERE pollid = '.intval($id));
			$poll = $this->db->loadAssoc();
			$poll['options'] = unserialize($poll['options']);
			$poll['voters'] = unserialize($poll['voters']);
			$poll['votes'] = unserialize($poll['votes']);

			if (!is_array($poll['voters'])) $poll['voters'] = array();
			if (!is_array($poll['votes'])) $poll['votes'] = array();
			
			return $poll;
		}

		function loadAll($per_page, $page)
		{
			$limit = $this->getLimit($per_page, $page);
			$this->setQuery('SELECT'.
							' p.ptype, p.created, p.edited,'.
							' t.question, t.yes, t.no, t.id, t.subject'.
							' FROM ##__polls AS p'.
							' INNER JOIN ##__topics AS t ON p.pollid=t.id'.
							' ORDER BY p.id DESC '.$limit);
			return $this->db->loadAssocList();
		}

		function add($topic_id, & $options, $ptype)
		{
			$q_topic_id = $this->db->Quote($topic_id);
			$q_options = $this->db->Quote(serialize($options));
			$q_ptype = $this->db->Quote($ptype);

			$this->setQuery('INSERT INTO ##__polls'.
				' (pollid, options, ptype, created)'.
				" VALUES ($q_topic_id, $q_options, $q_ptype, UNIX_TIMESTAMP(NOW()))"
				);
			$this->db->query();
		}

		function editRegular($topic_id, $question, & $options)
		{
			$q_topic_id = intval($topic_id);
			$q_options = $this->db->Quote(serialize($options));
			$q_question = $this->db->Quote($question);

			$this->setQuery("UPDATE ##__polls SET options = $q_options, edited = ".AGORA_TIME.
							" WHERE pollid = $q_topic_id");
			$this->db->query();

			$this->setQuery("UPDATE ##__topics SET question = $q_question".
							" WHERE id = $q_topic_id");
			$this->db->query();
		}

		function editMultiYesNo($topic_id, $question, & $options, $yes, $no)
		{
			$q_topic_id = intval($topic_id);
			$q_options = $this->db->Quote(serialize($options));
			$q_question = $this->db->Quote($question);

			$q_yes = $this->db->Quote($yes);
			$q_no = $this->db->Quote($no);

			$this->setQuery("UPDATE ##__polls SET options = $q_options, edited = ".AGORA_TIME.
							" WHERE pollid = $q_topic_id");
			$this->db->query();

			$this->setQuery("UPDATE ##__topics SET question = $q_question, yes = $q_yes, no = $q_no".
							" WHERE id = $q_topic_id");
			$this->db->query();
		}

		function delete($id)
		{
			$this->setQuery('DELETE FROM ##__polls WHERE pollid='.intval($id));
			$this->db->query();

			$this->setQuery('UPDATE ##__topics SET question=\'\', yes=\'\', no=\'\' WHERE id='.intval($id));
			$this->db->query();
		}

		function resetVotes($id)
		{
			$this->setQuery('UPDATE ##__polls SET voters=\'\', votes=\'\', edited='.AGORA_TIME.' WHERE pollid='.intval($id));
			$this->db->query();
		}

		function setVotes($poll_id, & $votes, & $voters)
		{
			$q_poll_id = $this->db->Quote($poll_id);
			$q_votes = $this->db->Quote(serialize($votes));
			$q_voters = $this->db->Quote(serialize($voters));
			$this->setQuery('UPDATE ##__polls'.
				" SET votes=$q_votes, voters=$q_voters WHERE pollid=$q_poll_id"
				);

			$this->db->query();
		}
	}
?>