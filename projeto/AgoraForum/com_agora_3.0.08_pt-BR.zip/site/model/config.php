<?php
	defined ('IN_AGORA') or die;

	class ConfigModel extends Model
	{
		function __construct()
		{
			parent::__construct("config");
		}

		function load()
		{
			$sql = "SELECT conf_name,conf_value FROM {$this->table}";
			$this->db->setQuery($sql);
			$list = $this->db->loadRowList();
			if (!$list) return false;
			$data = array();
			foreach ($list as $result) {
				$fname = $result[0];
				$fvalue = $result[1];
				$data[$fname] = $fvalue;
			}
			return $data;
		}
	
	    function save($data)
	    {
	    	foreach ($data as $key => $value) {
	    		$this->db->setQuery('UPDATE '.$this->table.' SET conf_value = '.$this->db->Quote($value).' WHERE conf_name = '.$this->db->Quote($key) );
	    		if (!$this->db->query()) {
	    			print $this->db->getErrorMsg();
	    			die;
	    		}
				if ($this->db->getAffectedRows() == 0) {
		    		$this->db->setQuery('SELECT 1 FROM '.$this->table.' WHERE conf_name = '.$this->db->Quote($key));
					if ($this->db->loadResult() !== '1') {
		    			$this->db->setQuery('INSERT INTO '.$this->table.' (conf_name, conf_value) VALUES('.$this->db->Quote($key).', '.$this->db->Quote($value).')');
						$this->db->query();
					}
				}
	    	}
	    }
	}
?>