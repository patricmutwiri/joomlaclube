<?php
	defined ('IN_AGORA') or die;

	class PMSModel extends Model
	{
		function __construct()
		{
			parent::__construct("messages");
		}

		function getTotal($user_id, $box)
		{
			$this->db->bind('user_id',$user_id,'integer');
			$this->db->bind('box',$box,'integer');

			$this->db->setQuery("SELECT COUNT(*) FROM {$this->table}".
						' WHERE owner = :user_id'.
						' AND status = :box');
		    return $this->db->loadResult();
		}
		
		function loadMessages($user_id, $box, $per_page, $page)
		{
			$this->db->bind('user_id',$user_id,'integer');
			$this->db->bind('box',$box,'integer');
			$limit = $this->getLimit($per_page, $page);
			
			$this->db->setQuery("SELECT * FROM {$this->table}".
						' WHERE owner = :user_id'.
						' AND status = :box'.
						" ORDER BY posted DESC $limit");
		    return $this->db->loadAssocList();
		}

		function sendMessage($sender_id,$sender_name,$user_id, $user_name, $subject, $message, $hide_smilies, $save_message)
		{
			$this->db->setQuery("INSERT INTO {$this->table}".
					" (owner, subject, message, sender, sender_id,".
					" sender_ip, smileys, showed, status, posted)".
					" VALUES (".
						$this->db->Quote($user_id).','.
						$this->db->Quote($subject).','.
						$this->db->Quote($message).','.
						$this->db->Quote($sender_name).','.
						$this->db->Quote($sender_id).','.
						$this->db->Quote(Agora::getIP()).','.
						$this->db->Quote($hide_smilies).','.
						" 0,".
						" 0,".
						" UNIX_TIMESTAMP(NOW())".
					" )");

			$this->db->query();

			if (!$save_message) return;

			$this->db->setQuery("INSERT INTO {$this->table}".
					" (owner, subject, message, sender, sender_id,".
					" sender_ip, smileys, showed, status, posted)".
					" VALUES (".
						$this->db->Quote($sender_id).','.
						$this->db->Quote($subject).','.
						$this->db->Quote($message).','.
						$this->db->Quote($user_name).','.
						$this->db->Quote($user_id).','.
						$this->db->Quote(Agora::getIP()).','.
						$this->db->Quote($hide_smilies).','.
						" 1,".
						" 1,".
						" UNIX_TIMESTAMP(NOW())".
					" )");
			$this->db->query();
		}

		function getUnreadCount($user_id)
		{
			$this->db->setQuery("SELECT COUNT(id)".
				" FROM {$this->table} WHERE showed=0 AND owner= ".$this->db->Quote($user_id));
		   	return $this->db->loadResult();
		}

		function markRead($id)
		{
			$this->db->setQuery("UPDATE {$this->table} SET showed = 1 WHERE id = ".$this->db->Quote($id));
			return $this->db->query();
		}
	}
?>