<?php
	defined ('IN_AGORA') or die;

	class FeedModel extends Model
	{
		function __construct()
		{
			parent::__construct();
			$this->limit = 'LIMIT 0,30';
		}

		function getGlobalFeed()
		{
			$this->setQuery('SELECT p.*,t.subject, f.id as forum_id, f.forum_name as topic_subject FROM ##__posts as p'.
							' INNER JOIN ##__topics AS t'.
							'  ON p.topic_id = t.id'.
							' INNER JOIN ##__forums AS f'.
							'  ON t.forum_id = f.id'.
							' ORDER BY p.posted DESC '.$this->limit);
			return $this->db->loadAssocList();
		}

		function getForumFeed($forum_id)
		{
			$this->setQuery('SELECT p.*,t.subject AS topic_subject FROM ##__posts as p'.
							' INNER JOIN ##__topics AS t'.
							'  ON p.topic_id = t.id'.
							' WHERE t.forum_id = '.intval($forum_id).
							' ORDER BY p.posted DESC '.$this->limit);
			return $this->db->loadAssocList();
		}

		function getTopicFeed($topic_id)
		{
			$this->setQuery('SELECT p.*,t.subject AS topic_subject FROM ##__posts as p'.
							' INNER JOIN ##__topics AS t'.
							'  ON p.topic_id = t.id'.
							'  WHERE topic_id = '.intval($topic_id).
							' ORDER BY p.posted DESC '.$this->limit);
			return $this->db->loadAssocList();
		}

		function getCategoryFeed($cat_id)
		{
			$this->setQuery('SELECT p.*, f.id as forum_id, t.subject AS topic_subject FROM ##__posts as p'.
							' INNER JOIN ##__topics AS t'.
							'  ON p.topic_id = t.id'.
							' INNER JOIN ##__forums AS f'.
							'  ON t.forum_id = f.id'.
							' WHERE f.cat_id = '.intval($cat_id).
							' ORDER BY p.posted DESC '.$this->limit);
			return $this->db->loadAssocList();
		}
	}
?>
