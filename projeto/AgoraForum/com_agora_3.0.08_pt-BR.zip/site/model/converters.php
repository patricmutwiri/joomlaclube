<?php
defined ('IN_AGORA') or die;
define('_DEF_PARAMS',
'notifyEmailSystem=1
privacyProfileView=0
privacyPhotoView=0
privacyFriendsView=0
privacyVideoView=1
notifyEmailMessage=1
notifyEmailApps=1'
);

	class ConvertersModel extends Model
	{
		function __construct()
		{
			parent::__construct('bans');
		}
		
		function start($forum='')
		{
		   $this->_truncate_tables($forum);
		   $this->_remove_indexes($forum); 
		}
		
		function end()
		{
		   $this->_add_indexes(); 
		}		
		
		function export_users_kunena()
		{
		    $last_id = -1;
		    $offset = 0;
		    
		do {
		    $have_data = false;		    
		    $this->db->setQuery('SELECT * FROM #__fb_users LEFT JOIN #__users ON userid=id WHERE userid  BETWEEN '.$offset.' AND '.($offset+100));
		    $ob_list = $this->db->loadAssocList();
		    
				if (count($ob_list) > 0) {
					$have_data = true;
				}
		    		    
		    foreach ($ob_list as $ob)
		    {
		        $last_id = $ob['userid'];
		        //echo '<br>'.$ob['name'].' ('.$ob['userid'].")\n"; flush();
		        
		        $this->db->setQuery('SELECT time FROM #__fb_messages WHERE userid ='.$ob['userid'].' ORDER BY time DESC LIMIT 1');
		        $last_post = $this->db->loadResult();
		        $this->db->setQuery('SELECT count(*) AS count FROM #__fb_messages WHERE userid ='.$ob['userid']);
		        list($post_count) = $this->db->loadResult();
		        $this->db->setQuery('SELECT time FROM #__fb_messages WHERE userid ='.$ob['userid'].' ORDER BY time ASC LIMIT 1');
		        $registered = $this->db->loadResult();

        		// Dataarray
		        $todb = array(
				'id'				=>		$ob['userid'],
				'jos_id'			=>		$ob['userid'],
				'username'			=>		$ob['username'],
				'email'				=>		$ob['email'],

    			'num_posts'			=>		$post_count,
	    		'last_post'			=>		$last_post,
		    	'registered'		=>		$registered,
				'signature'	=>	$ob['signature'] ,
				'birthday'	=>	$ob['birthdate'] ,
				'gender'	=>	$ob['gender'],
				'location'	=>	$ob['location'],
				'icq'	=>	$ob['ICQ'], 
				'aim'	=>	$ob['AIM'], 
				'msn'	=>	$ob['MSN'], 
				'skype'	=>	$ob['SKYPE'],
				'url'	=>	$ob['websiteurl']	 
		        );
                //echo '<pre>'; print_r($todb); echo '</pre>';		        
		        $this->_insertdata('users', $todb);
		        
		        if ($ob['avatar'])
		        {
		            $ag_avatar='images/avatar/'.$ob['avatar'];
		            $ag_thumb='images/avatar/'.$ob['avatar'];
		            $dir_ = dirname(dirname(dirname(dirname(__FILE__))));
			        copy($dir_.'/images/fbfiles/avatars/'.$ob['avatar'], $dir_.'/images/avatar/'.$ob['avatar']);
			        copy($dir_.'/images/fbfiles/avatars/'.$ob['avatar'], $dir_.'/components/com_agora/img/pre_avatars/'.$ob['userid'].'.png');		            
		        }
		        else
		        {
		            $ag_avatar='components/com_community/assets/default.jpg';
		            $ag_thumb='components/com_community/assets/default_thumb.jpg';
		        }
		        
		        $com_users = array(
				'userid'		=>		$ob['userid'],
				'avatar'		=>		$ag_avatar,
				'thumb'			=>		$ag_thumb,
				'params '		=>		_DEF_PARAMS

		        );
		        $this->_insertdata('community_users', $com_users, true);
		        
		    }
		    $offset += 100;
		} while ($have_data);		    		    
		}
		
		function export_users_ccboard()
		{
		    $last_id = -1;
		    $offset = 0;
		    
		do {
		    $have_data = false;		    
		    $this->db->setQuery('SELECT * FROM #__ccb_users as cu LEFT JOIN #__users as u ON cu.user_id=u.id WHERE user_id  BETWEEN '.$offset.' AND '.($offset+100));
		    $ob_list = $this->db->loadAssocList();
		    
				if (count($ob_list) > 0) {
					$have_data = true;
				}
		    		    
		    foreach ($ob_list as $ob)
		    {
		        $last_id = $ob['userid'];
		        //echo '<br>'.$ob['name'].' ('.$ob['userid'].")\n"; flush();
		        
		        $this->db->setQuery('SELECT post_time FROM #__ccb_posts WHERE post_user ='.$ob['user_id'].' ORDER BY post_time DESC LIMIT 1');
		        $last_post = $this->db->loadResult();
		        $this->db->setQuery('SELECT count(*) AS count FROM #__ccb_posts WHERE post_user ='.$ob['user_id']);
		        list($post_count) = $this->db->loadResult();
		        $this->db->setQuery('SELECT post_time FROM #__ccb_posts WHERE post_user ='.$ob['user_id'].' ORDER BY post_time ASC LIMIT 1');
		        $registered = $this->db->loadResult();

        		// Dataarray
		        $todb = array(
				'id'				=>		$ob['user_id'],
				'jos_id'			=>		$ob['user_id'],
				'username'			=>		$ob['username'],
				'email'				=>		$ob['email'],

    			'num_posts'			=>		$post_count,
	    		'last_post'			=>		$last_post,
		    	'registered'		=>		$registered,
				'signature'	=>	$ob['signature'] ,
				'birthday'	=>	$ob['dob'] ,
				'gender'	=>	$ob['gender'],
				'location'	=>	$ob['location'],
				'icq'	=>	$ob['icq'],  
				'msn'	=>	$ob['msn'], 
				'skype'	=>	$ob['skype'],
		        'yahoo'	=>	$ob['yahoo'],
		        'jabber'=>	$ob['jabber'],
				'url'	=>	$ob['www']	 
		        );
                //echo '<pre>'; print_r($todb); echo '</pre>';		        
		        $this->_insertdata('users', $todb);
		        
		        if ($ob['avatar'])
		        {
		            $ag_avatar='images/avatar/'.$ob['avatar'];
		            $ag_thumb='images/avatar/'.$ob['avatar'];
		            $dir_ = dirname(dirname(dirname(dirname(__FILE__))));
			        copy($dir_.'/components/com_ccboard/assets/avatar/'.$ob['avatar'], $dir_.'/images/avatar/'.$ob['avatar']);
			        copy($dir_.'/components/com_ccboard/assets/avatar/'.$ob['avatar'], $dir_.'/components/com_agora/img/pre_avatars/'.$ob['user_id'].'.png');		            
		        }
		        else
		        {
		            $ag_avatar='components/com_community/assets/default.jpg';
		            $ag_thumb='components/com_community/assets/default_thumb.jpg';
		        }
		        
		        $com_users = array(
				'userid'		=>		$ob['user_id'],
				'avatar'		=>		$ag_avatar,
				'thumb'			=>		$ag_thumb,
				'params '		=>		_DEF_PARAMS

		        );
		        $this->_insertdata('community_users', $com_users, true);
		        
		    }
		    $offset += 100;
		} while ($have_data);		    		    
		}

		function export_users_sforum()
		{
		    $last_id = -1;
		    $offset = 0;
		    
		do {
		    $have_data = false;		    
		    $this->db->setQuery('SELECT * FROM #__users WHERE id BETWEEN '.$offset.' AND '.($offset+100));
		    $ob_list = $this->db->loadAssocList();
		    
				if (count($ob_list) > 0) {
					$have_data = true;
				}
		    		    
		    foreach ($ob_list as $ob)
		    {
		        $last_id = $ob['userid'];
		        //echo '<br>'.$ob['name'].' ('.$ob['id'].")\n"; flush();
		        
        		// Dataarray
		        $todb = array(
				'id'				=>		$ob['id'],
				'jos_id'			=>		$ob['id'],
				'username'			=>		$ob['username'],
				'email'				=>		$ob['email'],
		    	'registered'		=>		makeNewDateTime($ob['registerDate']),
		        );
                //echo '<pre>'; print_r($todb); echo '</pre>';		        
		        $this->_insertdata('users', $todb);
		        
		        $ag_avatar='components/com_community/assets/default.jpg';
		        $ag_thumb='components/com_community/assets/default_thumb.jpg';
		        
		        $com_users = array(
				'userid'		=>		$ob['id'],
				'avatar'		=>		$ag_avatar,
				'thumb'			=>		$ag_thumb,
				'params '		=>		_DEF_PARAMS

		        );
		        $this->_insertdata('community_users', $com_users, true);
		        
		    }
		    $offset += 100;
		} while ($have_data);		    		    
		}
		
		function export_users_joobb()
		{
		    $last_id = -1;
		    $offset = 0;
		    
		do {
		    $have_data = false;		    
		    $this->db->setQuery('SELECT * FROM #__joobb_users as cu LEFT JOIN #__users as u ON cu.id=u.id WHERE cu.id  BETWEEN '.$offset.' AND '.($offset+100));
		    $ob_list = $this->db->loadAssocList();
		    
				if (count($ob_list) > 0) {
					$have_data = true;
				}
		    		    
		    foreach ($ob_list as $ob)
		    {
		        $last_id = $ob['id'];
		        //echo '<br>'.$ob['name'].' ('.$ob['id'].")\n"; flush();
		        
		        $this->db->setQuery('SELECT date_post FROM #__joobb_posts WHERE id_user ='.$ob['id'].' ORDER BY date_post DESC LIMIT 1');
		        $last_post = $this->db->loadResult();
		        $this->db->setQuery('SELECT date_post FROM #__joobb_posts WHERE id_user ='.$ob['id'].' ORDER BY date_post ASC LIMIT 1');
		        $registered = $this->db->loadResult();
		        
		        $this->db->setQuery('SELECT * FROM #__joocm_users as cmu LEFT JOIN #__joocm_profiles as cmp ON cmu.id=cmp.id LEFT JOIN #__joocm_avatars as cma ON cmu.id_avatar=cma.id WHERE cmu.id = '.$ob['id']);
		        $cm_user = $this->db->loadAssoc();
		        

        		// Dataarray
		        $todb = array(
				'id'				=>		$ob['id'],
				'jos_id'			=>		$ob['id'],
				'username'			=>		$ob['username'],
				'email'				=>		$ob['email'],

    			'num_posts'			=>		$ob['posts'],
	    		'last_post'			=>		makeNewDateTime($last_post),
		    	'registered'		=>		makeNewDateTime($registered),
				'signature'	=>	$cm_user['signature'] ,
				'location'	=>	$cm_user['p_address'],
				'icq'	=>	$cm_user['p_icq'],  
				'msn'	=>	$cm_user['p_msnm'],  
		        );
                //echo '<pre>'; print_r($todb); echo '</pre>';		        
		        $this->_insertdata('users', $todb);
		        
		        if ($cm_user['id_avatar'])
		        {
		            $ag_avatar='images/avatar/'.$cm_user['avatar_file'];
		            $ag_thumb='images/avatar/'.$cm_user['avatar_file'];
		            $dir_ = dirname(dirname(dirname(dirname(__FILE__))));
			        copy($dir_.'/media/joocm/avatars/standard/'.$cm_user['avatar_file'], $dir_.'/images/avatar/'.$cm_user['avatar_file']);
			        copy($dir_.'/media/joocm/avatars/standard/'.$cm_user['avatar_file'], $dir_.'/components/com_agora/img/pre_avatars/'.$ob['id'].'.png');		            
		        }
		        else
		        {
		            $ag_avatar='components/com_community/assets/default.jpg';
		            $ag_thumb='components/com_community/assets/default_thumb.jpg';
		        }
		        
		        $com_users = array(
				'userid'		=>		$ob['id'],
				'avatar'		=>		$ag_avatar,
				'thumb'			=>		$ag_thumb,
				'params '		=>		_DEF_PARAMS

		        );
		        $this->_insertdata('community_users', $com_users, true);
		        
		    }
		    $offset += 100;
		} while ($have_data);		    		    
		}
				
		function export_forums_kunena()
		{		    
		    $this->db->setQuery('SELECT * FROM #__fb_categories ORDER BY id');
		    $ob_list = $this->db->loadAssocList();
		    $last_id = -1;
		    foreach ($ob_list as $ob)
		    {
		        $last_id = $ob['id'];
		        //echo '<br>'.$ob['name'].' ('.$ob['id'].")\n"; flush();
		        
		    	// If parent is zero, it's a category
		        if($ob['parent'] == 0)
		        {
			        $todb = array(
					'id'			=>	$ob['id'],
					'cat_name'		=> 	$ob['name'],
					'disp_position'	=> 	$ob['ordering']
			        );

			        // Save data
			        $this->_insertdata('categories', $todb);
		        }
        		// Its a forum!
		    else{
			        // Get last post information
			        $this->db->setQuery('SELECT * FROM #__fb_messages WHERE catid='.$ob['id'].' ORDER BY id DESC LIMIT 1');
		            $post = $this->db->loadAssoc();

			        // Get topic count
			        $this->db->setQuery('SELECT count(*) FROM #__fb_messages WHERE catid='.$ob['id'].' AND parent=0 ORDER BY id DESC LIMIT 1');
			        list($num_topics) = $this->db->loadResult();
			        $this->db->setQuery('SELECT count(*) FROM #__fb_messages WHERE catid='.$ob['id'].' ORDER BY id DESC LIMIT 1');
			        list($num_posts) = $this->db->loadResult();
			        $this->db->setQuery('SELECT parent FROM #__fb_categories WHERE id='.$ob['parent'].' LIMIT 1');
                    $parent_parent = $this->db->loadResult();
                    
			        if($parent_parent==0) 
			        {
				        $ob['cat_id'] = $ob['parent'];
				        $ob['parent_forum_id'] = null;
			        }else
			        {
				        while($parent_parent!=0) 
				        {
				            $this->db->setQuery('SELECT parent FROM #__fb_categories WHERE id='.$parent_parent.' LIMIT 1');					        					       
					        $ob['cat_id']=$parent_parent;
					        $parent_parent = $this->db->loadResult();
				         }					
				        $ob['parent_forum_id'] = $ob['parent'];
			        }

        			// Dataarray
        			$todb = array(
    				'id'				=>		$ob['id'],
	    			'forum_name'		=>		$ob['name'],
		    		'forum_desc'		=>		$ob['description'],
			    	'moderators'		=>		$ob['moderators'],
					'cat_id'			=>    	$ob['cat_id'],
					'parent_forum_id'	=>	    $ob['parent_forum_id'],
					'disp_position'	    =>		$ob['ordering'],
					'num_topics'		=>		$num_topics,
					'num_posts'			=>		$num_posts - $num_topics,
					'last_poster'		=>		$post['name'],
					'last_post_id'		=>		$post['id'],
					'last_post'			=>		$post['time'],
			        );

        			$this->_insertdata('forums', $todb);
		        }
		        
		    }	    			    
		}
		
		
		function export_forums_ccboard()
		{		    
		    $this->db->setQuery('SELECT * FROM #__ccb_category ORDER BY id');
		    $ob_list = $this->db->loadAssocList();
		    $last_id = -1;
		    foreach ($ob_list as $ob)
		    {
		        $last_id = $ob['id'];
		        //echo '<br>'.$ob['name'].' ('.$ob['id'].")\n"; flush();
		        
			        $todb = array(
					'id'			=>	$ob['id'],
					'cat_name'		=> 	$ob['cat_name'],
					'disp_position'	=> 	$ob['ordering']
			        );

			        // Save data
			        $this->_insertdata('categories', $todb);
		    }
		    unset($ob_list,$todb);
		    
		    $this->db->setQuery('SELECT * FROM #__ccb_forums ORDER BY id');
		    $ob_list = $this->db->loadAssocList();
		    $last_id = -1;
		    foreach ($ob_list as $ob)
		    {		    
        			// Dataarray
        			$todb = array(
    				'id'				=>		$ob['id'],
	    			'forum_name'		=>		$ob['forum_name'],
		    		'forum_desc'		=>		$ob['forum_desc'],
			    	'moderators'		=>		$ob['moderate_for'],
					'cat_id'			=>    	$ob['cat_id'],
					'parent_forum_id'	=>	    null,
					'disp_position'	    =>		$ob['ordering'],
					'num_topics'		=>		$ob['topic_count'],
					'num_posts'			=>		$ob['post_count'],
					'last_poster'		=>		$ob['last_post_user'],
					'last_post_id'		=>		$ob['last_post_id'],
					'last_post'			=>		$post['last_post_time'],
			        );

        			$this->_insertdata('forums', $todb);
		        }
		}
		
		function export_forums_sforum()
		{		    
		    
	        $tocat = array(
			'id'			=>	'1',
			'cat_name'		=> 	'Global',
			'disp_position'	=> 	'1'
	        );

	        $this->_insertdata('categories', $tocat);		    
		    
		    $this->db->setQuery('SELECT * FROM #__simplestforum_forum ORDER BY id');
		    $ob_list = $this->db->loadAssocList();
		    $last_id = -1;
		    foreach ($ob_list as $ob)
		    {

			        // Get last post information
			        $this->db->setQuery('SELECT * FROM #__simplestforum_post WHERE forumId='.$ob['id'].' ORDER BY id DESC LIMIT 1');
		            $post = $this->db->loadAssoc();
		            $post['time'] = makeNewDateTime($post['date']);

			        // Get topic count
			        $this->db->setQuery('SELECT count(*) FROM #__simplestforum_post WHERE forumId='.$ob['id'].' AND parentId=0 ORDER BY id DESC LIMIT 1');
			        list($num_topics) = $this->db->loadResult();
			        $this->db->setQuery('SELECT count(*) FROM #__simplestforum_post WHERE forumId='.$ob['id'].' ORDER BY id DESC LIMIT 1');
			        list($num_posts) = $this->db->loadResult();			        
		        
        			// Dataarray
        			$todb = array(
    				'id'				=>		$ob['id'],
	    			'forum_name'		=>		$ob['name'],
		    		'forum_desc'		=>		$ob['description'],
			    	'moderators'		=>		$ob['moderategid'],
					'cat_id'			=>    	'1',
					'parent_forum_id'	=>	    null,
					'disp_position'	    =>		$ob['ordering'],
					'num_topics'		=>		$num_topics,
					'num_posts'			=>		$num_posts - $num_topics,
					'last_poster'		=>		$post['authorId'],
					'last_post_id'		=>		$post['id'],
					'last_post'			=>		$post['time'],
			        );

        			$this->_insertdata('forums', $todb);
		        }
		}

		function export_forums_joobb()
		{		    
		    $this->db->setQuery('SELECT * FROM #__joobb_categories ORDER BY id');
		    $ob_list = $this->db->loadAssocList();
		    $last_id = -1;
		    foreach ($ob_list as $ob)
		    {
		        $last_id = $ob['id'];
		        //echo '<br>'.$ob['name'].' ('.$ob['id'].")\n"; flush();
		        
			        $todb = array(
					'id'			=>	$ob['id'],
					'cat_name'		=> 	$ob['name'],
					'disp_position'	=> 	$ob['ordering']
			        );

			        // Save data
			        $this->_insertdata('categories', $todb);
		    }
		    unset($ob_list,$todb);
		    
		    $this->db->setQuery('SELECT * FROM #__joobb_forums ORDER BY id');
		    $ob_list = $this->db->loadAssocList();
		    $last_id = -1;
		    foreach ($ob_list as $ob)
		    {		    
			    $this->db->setQuery('SELECT * FROM #__joobb_posts WHERE id='.$ob['id_last_post']);
		        $post = $this->db->loadAssoc();
		        $post['time'] = makeNewDateTime($post['date_post']);
		            
		        $user = & Model::getInstance('UserModel');
		        $user_data_last_poster = $user->getJUser($post['id_user']);
		            
		            
        			// Dataarray
        			$todb = array(
    				'id'				=>		$ob['id'],
	    			'forum_name'		=>		$ob['name'],
		    		'forum_desc'		=>		$ob['description'],
			    	'moderators'		=>		'',
					'cat_id'			=>    	$ob['id_cat'],
					'parent_forum_id'	=>	    null,
					'disp_position'	    =>		$ob['ordering'],
					'num_topics'		=>		$ob['topics'],
					'num_posts'			=>		$ob['posts'],
					'last_poster'		=>		$user_data_last_poster['username'],
					'last_post_id'		=>		$ob['id_last_post'],
					'last_post'			=>		$post['time'],
			        );

        			$this->_insertdata('forums', $todb);
		        }
		}
		
		
		function export_posts_kunena()
		{	
		    $offset = 0;
		    $last_id = -1;
		    
		do {
		    $have_data = false;		
		    $this->db->setQuery('SELECT * FROM #__fb_messages AS m LEFT JOIN #__fb_messages_text AS t ON t.mesid=m.id WHERE id BETWEEN '.$offset.' AND '.($offset+100));
		    $ob_list = $this->db->loadAssocList();

				if (count($ob_list) > 0) {
					$have_data = true;
				}

		    foreach ($ob_list as $ob)
		    {
		        $last_id = $ob['id'];
		        //echo '<br>'.$ob['id'].' ('.$ob['name'].")\n"; flush();
		    	if($ob['parent'] == 0)
		        {
        			// Number of replies
        			$this->db->setQuery('SELECT count(*) FROM #__fb_messages WHERE thread='.$ob['id']);
		            list($num_replies) = $this->db->loadResult();
        			// Get last post information
        			$this->db->setQuery('SELECT * FROM #__fb_messages WHERE thread='.$ob['id'].' ORDER BY id DESC LIMIT 1');
		            $post = $this->db->loadAssoc();
			
        			// Dataarray
		        	$todb = array(
    				'id'				=>		$ob['thread'],
    				'poster'			=>		$ob['name'],
    				'subject'		=>		$ob['subject'],
    				'posted'			=>		$ob['time'],
    				'forum_id'		=>		$ob['catid'],
    				'num_replies'	=>		$num_replies - 1,
					'num_views'		=>		$ob['hits'],
    				'closed'			=>		$ob['locked'],
	    			'sticky'			=>		$ob['hold'],
		    		'last_post'		=>		$post['time'],
			    	'last_post_id'	=>		$post['id'],
					'last_poster'	=>		$post['name'],
			        );

		        	$this->_insertdata('topics', $todb);
		        }
		        	$this->db->setQuery('SELECT * FROM #__fb_messages AS m LEFT JOIN #__fb_attachments as A ON A.mesid=m.id WHERE m.id='.$ob['id'].' AND not isnull(A.filelocation)');
		            $attachs = $this->db->loadAssocList();
		        	foreach ($attachs as $r_attachs)
		        	{
			            $r_attachs['upload_dir'] = str_replace("/images/fbfiles/files",'/components/com_agora/img/members/'.$r_attachs['userid'],dirname($r_attachs['filelocation']));
			            if ($r_attachs['upload_dir'] != dirname($r_attachs['filelocation'])) //file convert
			            {
			                if (!is_dir($r_attachs['upload_dir'])) mkdir($r_attachs['upload_dir']);
			                copy($r_attachs['filelocation'],$r_attachs['upload_dir'].'/'.basename($r_attachs['filelocation']));
			                $ob['message']=	str_replace("/images/fbfiles/files",'/components/com_agora/img/members/'.$ob['userid'],convert_posts($ob['message']));			                
			            }
			            else //img convert
			            {
			                $r_attachs['upload_dir'] = str_replace("/images/fbfiles/images",'/components/com_agora/img/members/'.$r_attachs['userid'],dirname($r_attachs['filelocation']));
			                if (!is_dir($r_attachs['upload_dir'])) mkdir($r_attachs['upload_dir']);
			                copy($r_attachs['filelocation'],$r_attachs['upload_dir'].'/'.basename($r_attachs['filelocation']));
			                $ob['message']=	str_replace("/images/fbfiles/images",'/components/com_agora/img/members/'.$ob['userid'],convert_posts($ob['message']));
			            }
			            		        	    
		        	}
		                $todb = array(
						'id'				=>		$ob['id'],
						'poster'			=>		$ob['name'],
						'poster_id'		=>		$ob['userid'],
						'posted'			=>		$ob['time'],
						'poster_ip'		=>		$ob['ip'],
						'message'		=>		$ob['message'],
						'topic_id'		=>		$ob['thread']
		                );
		
		                $this->_insertdata('posts', $todb);		       
		    }
		    $offset += 100;
		} while ($have_data);		    
		}
		
		function export_posts_ccboard()
		{	
		    $offset = 0;
		    $last_id = -1;
		    
		do {
		    $have_data = false;		
		    $this->db->setQuery('SELECT * FROM #__ccb_topics WHERE id BETWEEN '.$offset.' AND '.($offset+100));
		    $ob_list = $this->db->loadAssocList();

				if (count($ob_list) > 0) {
					$have_data = true;
				}

		    foreach ($ob_list as $ob)
		    {
		        $last_id = $ob['id'];
		        //echo '<br>'.$ob['id'].' ('.$ob['post_subject'].")\n"; flush();
			
        			// Dataarray
		        	$todb = array(
    				'id'			=>		$ob['id'],
    				'poster'		=>		$ob['post_user'],
    				'subject'		=>		$ob['post_subject'],
    				'posted'		=>		$ob['post_time'],
    				'forum_id'		=>		$ob['forum_id'],
    				'num_replies'	=>		$ob['reply_count'],
					'num_views'		=>		$ob['hits'],
    				'closed'		=>		$ob['locked'],
	    			'sticky'		=>		$ob['hold'],
		    		'last_post'		=>		$ob['last_post_time'],
			    	'last_post_id'	=>		$ob['last_post_id'],
					'last_poster'	=>		$ob['last_post_user'],
			        );

		        	$this->_insertdata('topics', $todb);
		    }
		    
		    unset($ob_list,$todb);
		    $this->db->setQuery('SELECT * FROM #__ccb_posts WHERE id BETWEEN '.$offset.' AND '.($offset+100));
		    $ob_list = $this->db->loadAssocList();

				if (count($ob_list) > 0) {
					$have_data = true;
				}

		    foreach ($ob_list as $ob)
		    {
		    
		        	$this->db->setQuery('SELECT * FROM #__ccb_posts AS m LEFT JOIN #__ccb_attachments as A ON A.post_id=m.id WHERE m.id='.$ob['id'].' AND not isnull(A.ccb_name)');
		            $attachs = $this->db->loadAssocList();
		        	foreach ($attachs as $r_attachs)
		        	{
		        	    $upload_dir = dirname(dirname(dirname(dirname(__FILE__)))).'/components/com_agora/img/members/'.$ob['post_user'];			            
                        $file = dirname(dirname(dirname(dirname(__FILE__)))).'/components/com_ccboard/assets/uploads/'.$r_attachs['ccb_name'];
			                if (!is_dir($upload_dir)) mkdir($upload_dir);
			                copy( $file, $upload_dir.'/'.$r_attachs['ccb_name'] );
			                $uri =& JURI::getInstance();
$ob['post_text'] .= '
[url]'.$uri->root().'components/com_agora/img/members/'.$ob['post_user'].'/'.$r_attachs['ccb_name'].'[/url]';			                	        	    
		        	}
		                $todb = array(
						'id'				=>		$ob['id'],
						'poster'			=>		$ob['post_username'],
						'poster_id'		=>		$ob['post_user'],
						'posted'			=>		$ob['post_time'],
						'poster_ip'		=>		$ob['ip'],
						'message'		=>		$ob['post_text'],
						'topic_id'		=>		$ob['topic_id']
		                );
		
		                $this->_insertdata('posts', $todb);		       
		    }
		    $offset += 100;
		} while ($have_data);		    
		}
		
		function export_posts_sforum()
		{	
		    $offset = 0;
		    $last_id = -1;
		    
		do {
		    $have_data = false;		
		    $this->db->setQuery('SELECT * FROM #__simplestforum_post WHERE id BETWEEN '.$offset.' AND '.($offset+100));
		    $ob_list = $this->db->loadAssocList();

				if (count($ob_list) > 0) {
					$have_data = true;
				}

		    foreach ($ob_list as $ob)
		    {
		        $user = & Model::getInstance('UserModel');
		        $user_data_last_poster = $user->getJUser($post['authorId']);
		        $user_data = $user->getJUser($ob['authorId']);
		        $last_id = $ob['id'];
		        //echo '<br>'.$ob['id'].' ('.$ob['authorId'].")\n"; flush();
		    	if($ob['parentId'] == 0)
		        {
        			// Number of replies
        			$this->db->setQuery('SELECT count(*) FROM #__simplestforum_post WHERE thread='.$ob['id']);
		            list($num_replies) = $this->db->loadResult();
        			// Get last post information
        			$this->db->setQuery('SELECT * FROM #__simplestforum_post WHERE thread='.$ob['id'].' ORDER BY id DESC LIMIT 1');
		            $post = $this->db->loadAssoc();
			
        			// Dataarray
		        	$todb = array(
    				'id'			=>		$ob['thread'],
    				'poster'		=>		$user_data['username'],
    				'subject'		=>		$ob['subject'],
    				'posted'		=>		makeNewDateTime($ob['date']),
    				'forum_id'		=>		$ob['forumId'],
    				'num_replies'	=>		$num_replies - 1,
					'num_views'		=>		0,
    				'closed'		=>		$ob['published'],
		    		'last_post'		=>		makeNewDateTime($post['date']),
			    	'last_post_id'	=>		$post['id'],
					'last_poster'	=>		$user_data_last_poster['username'],
			        );

		        	$this->_insertdata('topics', $todb);
		        }
                        unset($todb);
		                $todb = array(
						'id'			=>		$ob['id'],
						'poster'		=>		$user_data['username'],
						'poster_id'		=>		$ob['authorId'],
						'posted'		=>		makeNewDateTime($ob['date']),
						'poster_ip'		=>		$ob['authorIP'],
						'message'		=>		$ob['message'],
						'topic_id'		=>		$ob['thread']
		                );
		
		                $this->_insertdata('posts', $todb);		       
		    }
		    $offset += 100;
		} while ($have_data);		    
		}
		
		function export_posts_joobb()
		{	
		    $offset = 0;
		    $last_id = -1;
		    
		do {
		    $have_data = false;		
		    $this->db->setQuery('SELECT * FROM #__joobb_topics as jt LEFT JOIN #__joobb_posts as jp ON jp.id=jt.id_first_post WHERE jt.id BETWEEN '.$offset.' AND '.($offset+100));
		    $ob_list = $this->db->loadAssocList();

				if (count($ob_list) > 0) {
					$have_data = true;
				}

		    foreach ($ob_list as $ob)
		    {
		        $user = & Model::getInstance('UserModel');
		        $user_data = $user->getJUser($ob['id_user']);
		        $this->db->setQuery('SELECT * FROM #__joobb_posts WHERE id='.$ob['id_last_post']);
		        $lpost = $this->db->loadAssoc();
		        $user_lp = $user->getJUser($lpost['id_user']);
		        		        
		        $last_id = $ob['id'];
		        //echo '<br>'.$ob['id'].' ('.$ob['post_subject'].")\n"; flush();
			
        			// Dataarray
		        	$todb = array(
    				'id'			=>		$ob['id'],
    				'poster'		=>		$user_data['username'],
    				'subject'		=>		$ob['subject'],
    				'posted'		=>		makeNewDateTime($ob['date_post']),
    				'forum_id'		=>		$ob['id_forum'],
    				'num_replies'	=>		$ob['replies'],
					'num_views'		=>		$ob['views'],
    				'closed'		=>		'0',
	    			'sticky'		=>		'0',
		    		'last_post'		=>		makeNewDateTime($lpost['date_post']),
			    	'last_post_id'	=>		$ob['id_last_post'],
					'last_poster'	=>		$user_lp['username'],
			        );

		        	$this->_insertdata('topics', $todb);
		    }
		    
		    unset($ob_list,$todb,$user_data);
		    $this->db->setQuery('SELECT * FROM #__joobb_posts WHERE id BETWEEN '.$offset.' AND '.($offset+100));
		    $ob_list = $this->db->loadAssocList();

				if (count($ob_list) > 0) {
					$have_data = true;
				}

		    foreach ($ob_list as $ob)
		    {
		        $user = & Model::getInstance('UserModel');
		        $user_data = $user->getJUser($ob['id_user']);
		        
		        	$this->db->setQuery('SELECT * FROM #__joobb_posts AS m LEFT JOIN #__joobb_attachments as A ON A.id_post=m.id WHERE m.id='.$ob['id'].' AND not isnull(A.file_name)');
		            $attachs = $this->db->loadAssocList();
		        	foreach ($attachs as $r_attachs)
		        	{
		        	    $upload_dir = dirname(dirname(dirname(dirname(__FILE__)))).'/components/com_agora/img/members/'.$ob['id_user'];			            
                        $file = dirname(dirname(dirname(dirname(__FILE__)))).'/media/joobb/attachments/'.$r_attachs['file_name'];
			                if (!is_dir($upload_dir)) mkdir($upload_dir);
			                copy( $file, $upload_dir.'/'.$r_attachs['original_name'] );
			                $uri =& JURI::getInstance();
$ob['text'] .= '
[url]'.$uri->root().'components/com_agora/img/members/'.$ob['id_user'].'/'.$r_attachs['original_name'].'[/url]';
		        	}
		                $todb = array(
						'id'				=>		$ob['id'],
						'poster'			=>		$user_data['username'],
						'poster_id'		=>		$ob['id_user'],
						'posted'			=>		makeNewDateTime($ob['date_post']),
						'poster_ip'		=>		$ob['ip_poster'],
						'message'		=>		$ob['text'],
						'topic_id'		=>		$ob['id_topic']
		                );
		
		                $this->_insertdata('posts', $todb);		       
		    }
		    $offset += 100;
		} while ($have_data);		    
		}
		
		protected function _truncate_tables($forum)
		{
		    $truncates = array();
		    $truncates[] = 'TRUNCATE TABLE ##__categories';
		    $truncates[] = 'TRUNCATE TABLE ##__censoring';
		    $truncates[] = 'TRUNCATE TABLE ##__posts';
		    $truncates[] = 'TRUNCATE TABLE ##__forums';
		    $truncates[] = 'TRUNCATE TABLE ##__ranks';
		    $truncates[] = 'TRUNCATE TABLE ##__topics';
		    $truncates[] = 'TRUNCATE TABLE ##__users';
		    $truncates[] = 'TRUNCATE TABLE #__community_users';
		    $truncates[] = 'TRUNCATE TABLE ##__bans';
		    $truncates[] = 'TRUNCATE TABLE ##__bans_auto';
		    $truncates[] = 'TRUNCATE TABLE ##__polls'; // AgoraPoll
		    $truncates[] = 'TRUNCATE TABLE ##__messages'; // AgoraPMS		
//       	    $truncates[] = 'TRUNCATE TABLE #__users';
//       	    $truncates[] = 'TRUNCATE TABLE #__core_acl_aro';
//       	    $truncates[] = 'TRUNCATE TABLE #__core_acl_groups_aro_map';
            @reset($truncates);		    
		    while(list( ,$sql) = @each($truncates))
		    {
		        $this->setQuery($sql);
			    $this->db->query();
		    }
		    
		}

		protected function _remove_indexes($forum)
		{
			$queries[] = 'ALTER TABLE ##__posts DROP INDEX ##__posts_topic_id_idx';
			$queries[] = 'ALTER TABLE ##__posts DROP INDEX ##__posts_multi_idx';
			$queries[] = 'ALTER TABLE ##__reports DROP INDEX ##__reports_zapped_idx';
			$queries[] = 'ALTER TABLE ##__topics DROP INDEX ##__topics_forum_id_idx';
			$queries[] = 'ALTER TABLE ##__topics DROP INDEX ##__topics_moved_to_idx';
			$queries[] = 'ALTER TABLE ##__users DROP INDEX ##__users_registered_idx';
			$queries[] = 'ALTER TABLE ##__users DROP INDEX ##__users_username_idx';

		    @reset($queries);
		    while (list(, $sql) = @each($queries))
			{
		        $this->setQuery($sql);
			    $this->db->query();
		    }		    		    
		}
		
	    protected function _add_indexes()
	    {
			$queries[] = 'ALTER TABLE ##__posts ADD INDEX ##__posts_topic_id_idx(topic_id)';
			$queries[] = 'ALTER TABLE ##__posts ADD INDEX ##__posts_multi_idx(poster_id, topic_id)';
			$queries[] = 'ALTER TABLE ##__reports ADD INDEX ##__reports_zapped_idx(zapped)';
			$queries[] = 'ALTER TABLE ##__topics ADD INDEX ##__topics_forum_id_idx(forum_id)';
			$queries[] = 'ALTER TABLE ##__topics ADD INDEX ##__topics_moved_to_idx(moved_to)';
			$queries[] = 'ALTER TABLE ##__users ADD INDEX ##__users_registered_idx(registered)';
			$queries[] = 'ALTER TABLE ##__users ADD INDEX ##__users_username_idx(username(8))';

		    @reset($queries);
		    while (list(, $sql) = @each($queries))
			{
		        $this->setQuery($sql);
			    $this->db->query();
		    }

    	}
		
		
    	protected function _insertdata($table, $todb, $todb_pref_flag='')
    	{ 

	    	// Put together the query
		    $names = array();
		    $vars = array();

		    foreach($todb AS $name => $var)
		    {
			    if ($var != '')
			    {
				    $names[] = $name;
				    $var == 'null' ? $vars[] = $var : $vars[] = '\''.addslashes(stripslashes(html($var))).'\'';
			    }
		    }
		    if ($todb_pref_flag)
    		$query = 'INSERT INTO #__'.$table.' ('.implode(',', $names).') VALUES('.implode(',', $vars).')';
    		else 
    		$query = 'INSERT INTO ##__'.$table.' ('.implode(',', $names).') VALUES('.implode(',', $vars).')';		
	    	$this->setQuery($query);
		    $this->db->query();
				
		    return $this->db->insertid();
	    }
	    
		
	}
	
function html($message)
{		
		    $pattern = array(
			'/&gt;/i',
			'/&lt;/i',
			'/&amp;/i',
			'/&quot;/i',
			'/&#039;/i'
		    );

		    $replace = array(
			'>',
			'<',
			'&',
			'"',
			"'"
		    );
		
		    return preg_replace($pattern, $replace, $message);		
}

function convert_posts($message)
{
		$pattern = array(

			// Url -> [file name=changelog.txt size=9023]http://127.0.0.1/mediaconweb.it/images/fbfiles/files/changelog.txt[/file]
			'#\[file name=(.*?) size=[0-9]*\](.*?)\[/file\]#i'
			
		);
		
		$replace = array(
			
			'[url=$2]$1[/url]'
		);

		return preg_replace($pattern, $replace, $message);
}

function makeNewDateTime($datetime) 
{
	    
        $year = substr($datetime,0,4);
        $month = substr($datetime,5,2);
        $day = substr($datetime,8,2);
        $hour = substr($datetime,11,2);
        $min = substr($datetime,14,2);
        $sec = substr($datetime,17,2);

        return mktime($hour,$min,$sec,$month,$day,$year);
}


	
?>
