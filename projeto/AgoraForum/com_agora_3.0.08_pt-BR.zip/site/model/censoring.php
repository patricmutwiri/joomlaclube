<?php
	defined ('IN_AGORA') or die;

	class CensoringModel extends Model
	{
		function __construct()
		{
			parent::__construct("censoring");
		}

	}
?>