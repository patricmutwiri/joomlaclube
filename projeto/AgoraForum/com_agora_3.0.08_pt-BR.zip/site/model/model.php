<?php
	defined ('IN_AGORA') or die;

	class Model
	{
		var $db;
		var $table;
		var $order;

		function Model($table = NULL)
		{
			$this->__construct($table);
		}

		function __construct($table = NULL)
		{
			ainclude('include|db');
			
//			$this->db = & JFactory::getDBO();

			$this->db = & AgoraDatabase::getInstance('agora_');

			$this->prefix = $this->db->getPrefix().'agora_';

			if ($table)
				$this->table = $this->db->nameQuote($this->prefix . $table);
			else
				$this->table = $this->prefix;

// 			$this->cache = array();
			$this->order = '';
			$this->_filter = '';
		}

		function setQuery($q)
		{
/*			$q = preg_replace(
					array('/##__(\S+)##(\s*)/','/##__(\S+)(\s*)/','/#__(\S+)(\s*)/'),
					array($this->prefix.'\1 AS \1\2',$this->prefix.'\1\2',$this->db->getPrefix().'\1\2'),
					$q);*/
			$q = str_replace(array('##__','#__'),array($this->prefix,$this->db->getPrefix()),$q);
			$this->db->setQuery($q);
		}
		
		function _table($table_name)
		{
			global $agora_table_cache;

			if (!isset($agora_table_cache[$table_name])) {
				$agora_table_cache[$table_name] = $this->db->nameQuote($this->prefix.$table_name);
			}

			return $agora_table_cache[$table_name];
		}

		function setOrder($order)
		{
			$this->order = $order;
		}
		
		function getLimit($per_page, $page)
		{
			if (is_null($per_page) || is_null($page)) return '';
			$page = intval($page) - 1;
			$per_page = intval($per_page);
			if ($per_page < 1) {
				$per_page = 5;
			}
			$start = $page * $per_page;
			return " LIMIT $start, $per_page ";
		}

		function & getInstance($class_name)
		{
			static $_models = array();

			if (!isset($_models[strtolower($class_name)])) {

				if (!class_exists($class_name)) {
			    	$file = strtolower(substr($class_name,0, -strlen('Model')));
			    	ainclude('model|'.$file);
			    }

				$_models[$class_name] = new $class_name();
			}

			return $_models[$class_name];
		}

		function setFilter($field,$value,$op='=')
		{
			if ($this->_filter) {
				$this->_filter .= 'AND ';
			} else {
				$this->_filter = 'WHERE ';
			}

			$this->_filter .= $this->db->nameQuote($field).' '.$op.' '.$this->db->Quote($value);
		}
		
		function load($value=NULL, $field = 'id')
		{
/*			if (isset($this->cache[$field]) &&
				isset($this->cache[$field][$value]) && 
				$value !== NULL)
				return $this->cache[$field][$value];*/

			$sql = "SELECT * FROM {$this->table}";
			if (!is_null($value)) {
				$sql .= ' WHERE '.$this->db->nameQuote($field) .'='. $this->db->Quote($value);
			}

			$sql .= " LIMIT 1";
			$this->db->setQuery($sql);
			$result = $this->db->loadAssoc();
			if (!$result) return false;
/*			$data = array();
			foreach ($result as $db_field => $db_val)
			{
				$data[$db_field] = $db_val;
			}*/
//			$this->cache[$field][$value] = $data;
			return $result;
		}

		function loadAllCount()
		{
			$this->db->setQuery('SELECT COUNT(*) FROM '.$this->table.' '.$this->_filter);
			return $this->db->loadResult();
		}

		function loadAll($key = '', $per_page = null, $page = null)
		{
			if (is_null($per_page) || is_null($page)) {
				$limit = '';
			} else {
				$limit = Model::getLimit($per_page, $page);
			}

			$this->db->setQuery('SELECT * FROM '.$this->table .' '.$this->_filter.' '. $this->order .' '. $limit);
			return $this->db->loadAssocList($key);
		}

	    function delete($value, $field = 'id')
	    {
	    	$this->db->setQuery('DELETE FROM '.$this->table.' WHERE'.
	    		$this->db->nameQuote($field) .'='. $this->db->Quote($value));

	    	$this->db->query();
	    }

	    function exists($value, $field = 'id')
	    {
	    	$this->db->setQuery('SELECT COUNT(*) FROM '.$this->table.' WHERE'.
	    		$this->db->nameQuote($field). '='. $this->db->Quote($value).' LIMIT 1');

	    	return $this->db->loadResult() > 0 ? true : false ;
	    }

	    function edit($key, $params, $key_field='id')
	    {
	    	$sql = "UPDATE {$this->table} SET ";

	    	$i = 0;
	    	$total = count($params);
	    	foreach ($params as $field => $value) {
	    		if (is_null($value)) {
	    			$sql .= $this->db->nameQuote($field). '= NULL';
	    		} else {
	    			$sql .= $this->db->nameQuote($field). '= '. $this->db->Quote($value);
	    		}

	    		$i++;
	    		if ($i != $total) {
	    			$sql .= ", ";
	    		}
	    	}
	    	$sql .= ' WHERE '.$this->db->nameQuote($key_field) .'='. $this->db->Quote($key);
			
	    	$this->db->setQuery($sql);

	    	$this->db->query();
	    }
		
		function add($data)
		{
	    	$sql = 'INSERT INTO '.$this->table.' ( ';

	    	$i = 0;
	    	$total = count($data);
	    	foreach ($data as $field => $value) {
    			$sql .= $this->db->nameQuote($field);

	    		$i++;
	    		if ($i != $total) {
	    			$sql .= ', ';
	    		}
	    	}
			
	    	$sql .= ') VALUES (';
	    	
			$i = 0;
			foreach ($data as $field => $value) {
    			$sql .= $this->db->Quote($value);

	    		$i++;
	    		if ($i != $total) {
	    			$sql .= ', ';
	    		}
	    	}
	    	$sql .= ')';
			
	    	$this->db->setQuery($sql);

	    	$this->db->query();
//	    	echo $sql;exit;
			return $this->db->insertid();
		}
	}
?>