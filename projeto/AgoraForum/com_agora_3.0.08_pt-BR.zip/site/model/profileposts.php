<?php
defined ('IN_AGORA') or die;

class ProfilePostsModel extends Model
{
    function __construct()
    {
        parent::__construct('profileposts');
    }


    function loadAll($key = '', $per_page = null, $page = null, $user_id, $allowed_forums=array())
    {


        if (is_null($per_page) || is_null($page)) {
            $limit = '';
        } else {
            $limit = Model::getLimit($per_page, $page);
        }
        if ($allowed_forums) {
            $fwhere = ' AND #__agora_topics.forum_id IN ('.implode(", ", $allowed_forums).')';
        } else {
            $fwhere = '';
        }

        $this->db->setQuery('SELECT #__agora_topics.id, #__agora_topics.poster, #__agora_topics.subject, #__agora_topics.descrip_t, #__agora_topics.posted, #__agora_topics.last_post, #__agora_topics.last_post_id, #__agora_topics.last_poster, #__agora_topics.num_views, #__agora_topics.num_replies, #__agora_topics.closed, #__agora_topics.sticky, #__agora_topics.moved_to, #__agora_topics.forum_id, #__agora_topics.question, #__agora_topics.yes, #__agora_topics.`no` , #__agora_topics.icon_topic, #__agora_forums.forum_name, #__agora_forums.forum_desc
FROM #__agora_topics
INNER JOIN #__agora_posts ON #__agora_topics.id = #__agora_posts.topic_id
INNER JOIN #__agora_forums ON #__agora_forums.id = #__agora_topics.forum_id WHERE #__agora_posts.poster_id='.$user_id.$fwhere .' GROUP BY topic_id '. $this->order .' '. $limit);




        return $this->db->loadAssocList($key);
    }


    function getTopicCount($user_id, $allowed_forums=array())
    {
        if ($allowed_forums) {
            $fwhere = ' AND #__agora_topics.forum_id IN ('.implode(", ", $allowed_forums).')';
        } else {
            $fwhere = '';
        }

        $this->db->setQuery('SELECT #__agora_topics.id FROM #__agora_topics INNER JOIN #__agora_posts ON #__agora_topics.id = #__agora_posts.topic_id WHERE #__agora_posts.poster_id='.$user_id.$fwhere.' GROUP BY topic_id');


        $posts = $this->db->loadAssocList();

        if (!is_null($posts)){
            return count($posts);
        }else{
            return 0;
        }
    }


}
?>

