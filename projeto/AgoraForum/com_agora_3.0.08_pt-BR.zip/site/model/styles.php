<?php
	defined ('IN_AGORA') or die;
	
	class StylesModel
	{
		function loadAll()
		{
        	$d = dir(AGORA_PATH.DS.'style');

        	$styles = array();

        	while (($entry = $d->read()) !== false)
	        {
    	    	$path = AGORA_PATH.DS.'style'.DS.$entry;

        		if (is_dir($path) && (
	        		file_exists($path.DS."$entry.css")) ||
    	    		file_exists($path.DS.'index.css'))
	        	{
    	    		$styles[] = $entry;
	        	}
    	    }
	        $d->close();

	        return $styles;
		}

		function getStyle($style_name)
		{
			$style = array();
			$style['index'] = file_get_contents(AGORA_PATH.DS.'style'.DS.$style_name.DS.'index.css');
			if ($style['index'] === FALSE) {
				$style['index'] = '';
			}

			$style['common'] = file_get_contents(AGORA_PATH.DS.'style'.DS.$style_name.DS.'common.css');
			if ($style['common'] === FALSE) {
				$style['common'] = '';
			}
			$style['profile'] = file_get_contents(AGORA_PATH.DS.'style'.DS.$style_name.DS.'profile.css');
			if ($style['profile'] === FALSE) {
				$style['profile'] = '';
			}

			return $style;
		}

		function saveStyle($style, $content)
		{
////			var_dump($content);die;
			$prefix = AGORA_PATH.DS.'style'.DS.$style.DS;
			if (isset($content['index'])) {
				if (file_put_contents($prefix.'index.css', $content['index']) === FALSE) return false;
			}
			if (isset($content['common'])) {
				if (file_put_contents($prefix.'common.css', $content['common']) === FALSE) return false;
			}
			if (isset($content['profile'])) {
				if (file_put_contents($prefix.'profile.css', $content['profile']) === FALSE) return false;
			}
			return true;
		}
	}

?>