<?php
	defined ('IN_AGORA') or die;

	class UddePMModel extends Model
	{
		function getUnreadCount($jos_id)
		{
			$this->db->setQuery('SELECT COUNT(*) FROM #__uddeim WHERE toid = '.intval($jos_id).' AND toread=0');
			return $this->db->loadResult();
		}
	}
?>
