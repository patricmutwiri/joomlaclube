<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	class TopicIconsModel
	{
		function loadAll()
		{
			$d = dir(AGORA_PATH.'img'.DS.'icons');
			$topic_icons = array();
	        while (($entry = $d->read()) !== false)
        	{
    	        if (substr($entry, strlen($entry)-4) == '.gif')
	            {
            	    $topic_icons[] = substr($entry, 0, strlen($entry)-4);
        	    }
    	    }
	        $d->close();
			return $topic_icons;
		}
	}


?>
