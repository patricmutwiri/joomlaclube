<?php
	defined ('IN_AGORA') or die;

	class BanModel extends Model
	{
		function __construct()
		{
			parent::__construct('bans');
		}
		
		function banUser($username, $message, $expire) 
		{
			$q_username = $this->db->Quote($username);
			$q_message = $this->db->Quote($message);
			$q_expire = intval($expire);
			
			$this->setQuery("DELETE FROM ##__bans WHERE username=$q_username");
			$this->db->query();
			
			$this->setQuery("INSERT INTO ##__bans (username,message,expire) VALUES ($q_username, $q_message, $q_expire)");
			$this->db->query();
		}
		
		function banIP($ip, $message, $expire)
		{
			$q_ip = $this->db->Quote($ip);
			$q_message = $this->db->Quote($message);
			$q_expire = intval($expire);
			$this->setQuery("INSERT INTO ##__bans (ip,message,expire) VALUES ($q_ip, $q_message, $q_expire)");
			$this->db->query();
		}

		function isBanned($username)
		{
			$this->setQuery('SELECT COUNT(*) FROM ##__bans WHERE username='.$this->db->Quote($username));
			return $this->db->loadResult() > 0 ? true : false;
		}

		function unBanUser($username)
		{
			$this->db->bind('username',$username,'string');
			$this->db->setQuery('DELETE FROM ##__bans WHERE username=:username');
			$this->db->query();
		}

	}
?>
