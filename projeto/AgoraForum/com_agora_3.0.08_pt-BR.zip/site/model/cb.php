<?php
	defined ('IN_AGORA') or die;

	class CbModel extends Model
	{
		function getCbAvatar($jos_id)
		{
			$this->db->setQuery('SELECT avatar FROM #__comprofiler WHERE user_id = '.intval($jos_id));
			return $this->db->loadResult();
		}
	}
?>
