<?php
	defined ('IN_AGORA') or die;

	class StatModel extends Model
	{
		function __construct()
		{
			parent::__construct();
		}

		function getStats()
		{
			$stats = array();
			
			$this->db->setQuery("SELECT COUNT(id) FROM {$this->prefix}users");
			$stats['total_users'] = $this->db->loadResult();
			
			$this->db->setQuery("SELECT agora.id, joomla.username FROM {$this->prefix}users as agora JOIN #__users as joomla ON agora.jos_id = joomla.id ORDER by joomla.registerDate DESC LIMIT 1");
			$last_user = $this->db->loadRow();
			$stats['last_user_id'] = $last_user[0];
			$stats['last_user_name'] = $last_user[1];

			$this->db->setQuery("SELECT SUM(num_topics), SUM(num_posts) FROM {$this->prefix}forums");
			$total = $this->db->loadRow();
			$stats['total_topics'] = $total[0];
			$stats['total_posts'] = $total[1];
			
			$this->db->setQuery("SELECT COUNT(*) FROM {$this->prefix}polls");
			$stats['total_polls'] = $this->db->loadResult();

			$this->db->setQuery("SELECT COUNT(*) FROM {$this->prefix}posts".
						" WHERE posted > ".(time()-7*24*3600));
			$stats['posts_week'] = $this->db->loadResult();

			$this->db->setQuery("SELECT COUNT(*) FROM {$this->prefix}posts".
						" WHERE posted > ".(time()-24*3600));

			$p_day = intval($this->db->loadResult());
			$stats['posts_day'] = $p_day;
			$stats['posts_hour'] = number_format($p_day / 24,1);

			return $stats;
		}

	}
?>