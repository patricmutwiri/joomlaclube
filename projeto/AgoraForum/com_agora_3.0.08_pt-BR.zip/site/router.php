<?php
	if (!defined('IN_AGORA')) define ('IN_AGORA',1);

	require_once('include/dispatcher.j15.php');
//	require_once('include/agora.common.php');
//	require_once('include/agora.j15.php');
?>
