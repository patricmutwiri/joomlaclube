<?php

class ATopicHelper
{
    var $db;
    function __construct()
    {
        ainclude('include|db');
        $this->db = & AgoraDatabase::getInstance('agora_');
        $this->prefix = $this->db->getPrefix().'agora_';
    }

    function & getInstance()
    {
        static $inst;
        if (!isset($inst)) {
            $inst = new ATopicHelper();
        }
        return $inst;

    }
    function processRatings($topics)
    {
        $topic_model = & Model::getInstance('TopicModel');

        foreach ($topics as $key=>$topic)
        {
            $rating = $topic_model->getRating($topic['id']);
            if ($rating >= 0.0 && $rating < 0.25)
            $star = 'Star_0';
            elseif ($rating >= 0.25 && $rating < 0.75)
            $star = 'Star_0_Half';
            elseif ($rating >= 0.75 && $rating < 1.25)
            $star = 'Star_1';
            elseif ($rating >= 1.25 && $rating < 1.75)
            $star = 'Star_1_Half';
            elseif ($rating >= 1.75 && $rating < 2.25)
            $star = 'Star_2';
            elseif ($rating >= 2.25 && $rating < 2.75)
            $star = 'Star_2_Half';
            elseif ($rating >= 2.75 && $rating < 3.25)
            $star = 'Star_3';
            elseif ($rating >= 3.25 && $rating < 3.75)
            $star = 'Star_3_Half';
            elseif ($rating >= 3.75 && $rating < 4.25)
            $star = 'Star_4';
            elseif ($rating >= 4.25 && $rating < 4.75)
            $star = 'Star_4_Half';
            else
            $star = 'Star_5';

            $topics[$key]['rating'] = $rating;
            $topics[$key]['rating_star'] = $star;

        }
        return $topics;
    }

    function processTopics($topics)
    {
        $topic_model = & Model::getInstance('TopicModel');

        foreach ($topics as $key=>$topic)
        {
            $topics[$key]['status'] = '';

            $timeout = AGORA_TIME - intval($this->agora_config['o_timeout_visit']) * 86400;
            if ($topic['last_post'] < $timeout) {
                // Was last post too long ago?
                $newp = false;
            } else {
                //Did user read this post?
                if ($topic_model->hasNewPosts($topic['id'], $this->agora_user['id'])) {
                    $newp = true;
                } else {
                    $newp = false;
                }
            }

            if ($newp) {
                $topics[$key]['new'] = true;
                $topics[$key]['status'] .= 'new';
            }

            if ($topic['sticky']) $topics[$key]['status'] .= 'sticky';
            if ($topic['closed']) $topics[$key]['status'] .= 'closed';
            if ($topic['num_replies'] >= 19) $topics[$key]['status'] .= 'hot';

			if (!$topics[$key]['status']) {
				$topics[$key]['status'] = 'icon';
			}

            $per_page = intval($this->agora_user['disp_posts']) > 0 ? $this->agora_user['disp_posts'] : intval($this->agora_config['o_disp_posts_default']);
            $topics[$key]['num_pages'] = ceil(($topic['num_replies'] + 1) / $per_page);

            $mess_text = $topic_model->getPostMessage($topic['last_post_id']);

            $mess_text = preg_replace('#\[quote(.*?)\[/quote\]#si', '', $mess_text);
            $mess_text = preg_replace('#\[QUOTE(.*?)\[/QUOTE\]#si', '', $mess_text);
            $mess_text = preg_replace('|[[\/\!]*?[^\[\]]*?]|si', '', $mess_text);
            $mess_text = strip_tags($mess_text);

            $length = strlen($mess_text);

            if ($length > 90)
            {
                $mess_text = AString::substr($mess_text, 0, 90).'...';
            }
            $topics[$key]['title'] = $mess_text;

            $forum_data = $this->_getForumNameDecAndID($topic['id']);

            $topics[$key]['descrip_t'] = $forum_data['topic_desc'];

            if (Agora::getVar('task', '') != 'forum'){
                $topics[$key]['forum_name'] = $forum_data['forum_name'];
                $topics[$key]['forum_id'] = $forum_data['forum_id'];
            }


        }
        return $topics;
    }

    function _getForumNameDecAndID($topicId)
    {
        $result = array();
        $this->db->setQuery('SELECT forum_id, descrip_t FROM ##__topics WHERE id = '.intval($topicId));
        $flds = $this->db->loadAssocList();

        $result['forum_id']=$flds[0]['forum_id'];
        $result['topic_desc']=$flds[0]['descrip_t'];

        if (!is_null($result['forum_id'])){
            $this->db->setQuery('SELECT forum_name FROM ##__forums WHERE id = '.$result['forum_id']);
            $flds = $this->db->loadAssocList();
            $result['forum_name']=$flds[0]['forum_name'];
        }else{
            $result['forum_name']='';
        }

        return $result;

    }
}


?>
