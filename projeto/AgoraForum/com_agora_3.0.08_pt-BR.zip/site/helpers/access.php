<?php

class AAccessHelper
{
	function getForumAccess($forum_id)
	{
		$access_model = & Model::getInstance('AccessModel');
		if (!$this->agora_user['is_superadmin']) {
			$access = $access_model->getForumAccess($forum_id,$this->agora_user['id']);
		} else {
			$access = array();
			foreach ($access_model->access as $name) {
				$access[$name] = 1;
			}
			$access['use_captcha'] = 0;
		}
		return $access;
	}
}

?>
