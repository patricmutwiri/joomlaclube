<?php
    defined ('IN_AGORA') or die;

	require_once('view.php');

	class AdminView extends View
	{
		var	$config;

		function __construct($template = NULL)
		{
			parent::__construct($template);
			$this->smarty->register_function('radio_option',array(&$this,'radioOption'));
			$this->smarty->register_function('text_option',array(&$this,'textOption'));
			$this->config = NULL;
			$this->clean_view = false;
		}

		function textOption($params, & $smarty)
		{
			if (!$this->config) {
				$this->config = & $smarty->get_template_vars('agora_config');
			}

			$caption = Agora::lang($params['caption']);

			if (isset($params['var'])) {
				$var = $params['var'];
			} elseif (isset($params['var1to1'])) {
				$var1 = $params['var1to1'];
			} else {
				$this->smarty->trigger_error("text_option must use 'var' or 'var1' option");
				return;
			}

			$desc = Agora::lang($params['desc']);
			$colspan = isset($params['colspan']) ? ' colspan='.$params['colspan'] : '';
			
			$opts = '';
			unset($params['desc']);
			unset($params['caption']);
			unset($params['var']);
			unset($params['var1to1']);
			unset($params['colspan']);

			foreach ($params as $opt_name => $opt_val) {
				$opts .= "$opt_name=\"$opt_val\" ";
			}

			if (isset($var) && !isset($this->config['o_'.$var])) {
				$this->smarty->trigger_error("Variable o_$var not found in agora_config");
			}

			if (isset($var1) && !isset($this->config[$var1])) {
				$this->smarty->trigger_error("Variable o_$var1 not found in agora_config");
			}
			
			$var = isset($var) ? 'o_'.$var : $var1;
			$value = $this->config[$var];
			
			return <<<EOT
				<tr><th scope="row" class="editlinktip hasTip" title="$caption::$desc">$caption</th>
					<td$colspan>
						<input type="text" name="form[$var]" value="$value" $opts/>
						<!--<span>$desc</span>-->
					</td>
			    </tr>
EOT;
		}

		function radioOption($params, & $smarty)
		{
			if (!$this->config) {
				$this->config = & $smarty->get_template_vars('agora_config');
			}

			$caption = Agora::lang($params['caption']);
			$var = 'o_'.$params['var'];
			$desc = Agora::lang($params['desc']);
			
			$colspan = isset($params['colspan']) ? ' colspan='.$params['colspan'] : '';

			if (!isset($this->config[$var])) {
				$this->smarty->trigger_error("Variable $var not found in agora_config");
			}

			if ($this->config[$var]) {
				$checked_1 = ' checked="checked"';
				$checked_0 = '';
			} else {
				$checked_1 = '';
				$checked_0 = ' checked="checked"';
			}
			$Yes = Agora::lang('Yes');
			$No = Agora::lang('No');

			return <<<EOT
				<tr>
					<th scope="row" class="editlinktip hasTip" title="$caption::$desc">$caption</th>
					<td$colspan>
						<input type="radio" name="form[$var]" value="1"$checked_1 />&nbsp;
							<strong>$Yes</strong>&nbsp;&nbsp;&nbsp;
						<input type="radio" name="form[$var]" value="0"$checked_0 />&nbsp;
							<strong>$No</strong>
						<!--<span>$desc</span>-->
					</td>
			    </tr>
EOT;
		}

		function prepareMenu()
		{
			$this->global_settings = array(
				Agora::lang('Admin main')		=> array('index',		'control.gif'),
				Agora::lang('Common Options')	=> array('options',		'options.gif'),
				Agora::lang('Smilies')			=> array('smilies',		'smilies.gif'),
//				'Maintenance'		            => array('maintance',	'maintenance.gif'),
//				'Polls'				            => array('polls',		'poll.gif'),
//				Agora::lang('Private Messages')	=> array('pms',			'pm.gif'),
//				Agora::lang('Reports')			=> array('reports',		'reports.gif'),
//				Agora::lang('Adsense')			=> array('adsense',		'google.gif'),
				Agora::lang('Maintenance')		=> array('maintenance',	'maintenance.gif'),
				Agora::lang('Aggregator')		=> array('aggregator',	'rss.gif'),
				Agora::lang('File Editor')		=> array('css_editor',	'editor.gif'),
//				Agora::lang('Joom-Backup DB')	=> array('backup',		'jbackup.gif'),
//				Agora::lang('Agora-Backup DB')	=> array('db_manage',	'abackup.gif'),
//				Agora::lang('Upload Plugin')		=> array('plugile',	'plugidile.gif'),
				Agora::lang('Upload Manager')	=> array('uploads',		'uploadile.gif'),
				Agora::lang('Polls Edit')		=> array('polls',	    'plugidile.gif'),

			);

			$this->forum_settings = array(
//				Agora::lang('Categories')		=> array('categories',	'categories.gif'),
				Agora::lang('Forum setup')		=> array('forums',		'forums.gif'),
				Agora::lang('Headers')			=> array('announce',		'headers.gif'),
				Agora::lang('Censoring')		=> array('censoring' , 'censor.gif'),
				Agora::lang('Prune')			=> array('prune' , 'prune.gif'),
				Agora::lang('Permissions')		=> array('permissions' , 'permissions.gif'),

				Agora::lang('Global Topics')	=> array('task' => 'admin_index' , 'img' => 'global.gif'),
				Agora::lang('Spam Scrubber')	=> array('task' => 'admin_index' , 'img' => 'spam.gif'),
			);

			$this->user_settings = array(
				Agora::lang('Users')			=> array('users' , 'user.gif'),
				Agora::lang('User groups')		=> array('groups' , 'groups.gif'),
				Agora::lang('Ranks')			=> array('ranks' , 'ranks.gif'),
				Agora::lang('Awards')			=> array('awards' , 'awards.gif'),
				Agora::lang('Bans')				=> array('bans' , 'bans.gif'),
				Agora::lang('Profile Fields')	=> array('task' => 'admin_index' , 'img' => 'prof_fields.gif'),
				Agora::lang('Reputation')		=> array('task' => 'admin_index' , 'img' => 'reput.gif'),
				Agora::lang('Syncronize')		=> array('task' => 'admin_index' , 'img' => 'author.gif'),
			);
		}

		function display($template = NULL)
		{
			if (Agora::getVar('type') === 'clean') {
				JRequest::setVar('tmpl', 'component'); //force the component template
				if ($this->template) {
					$template = $this->template;
				}
				$this->smarty->display('admin'.DS.$template.'.tpl');
				return;
			}

			$app = &JFactory::getApplication();
			$isBackend = $app->isAdmin();

			if (!$isBackend) {
				$this->smarty->display('header.tpl');

				$this->prepareMenu();

				$selected_page = 0;

				foreach ($this->forum_settings as $cap => $setting) {
					if (isset($setting[0]) && ($setting[0] === $template || $setting[0] === $this->template)) {
						$selected_page = 1;
						break;
					}
				}

				if ($selected_page === 0) {
					foreach ($this->user_settings as $cap => $setting) {
						if (isset($setting[0]) && ($setting[0] === $template || $setting[0] === $this->template)) {
							$selected_page = 2;
							break;
						}
					}
				}

				$this->smarty->assign('selected_page', $selected_page);
				
				$this->smarty->assign_by_ref('global_settings', $this->global_settings);
				$this->smarty->assign_by_ref('forum_settings', $this->forum_settings);
				$this->smarty->assign_by_ref('user_settings', $this->user_settings);
			}
//			$this->smarty->display('admin/header.tpl');
//			$this->smarty->caching = false;

			if ($this->template)
				$template = $this->template;

			$this->smarty->display('admin'.DS.$template.'.tpl');

//			$this->smarty->display('admin/footer.tpl');

			if (!$isBackend) {
				$this->smarty->display('footer.tpl');
			}
		}
	}
?>