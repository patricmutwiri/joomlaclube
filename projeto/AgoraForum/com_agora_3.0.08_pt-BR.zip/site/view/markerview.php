<?php
    defined ('IN_AGORA') or die;

	require_once ('view.php');

	class MarkerView extends View
	{
		var $_users;

		function __construct()
		{
			$_user = null;
		}

		function display()
		{
//			ob_end_clean();

			header('Content-type: text/xml');
			echo "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n";
			echo "<markers>\n";

			foreach ($this->_users as $user) {
				foreach ($user as $key=>$value) {
					$user[$key] = htmlspecialchars($value,ENT_QUOTES,'UTF-8');
				}

				echo "\t<marker".
					" id=\"{$user['id']}\"".
					" username=\"{$user['username']}\"".
					" title=\"{$user['title']}\"".
					" url=\"{$user['url']}\"".
					" location=\"{$user['location']}\"".
					" lat=\"{$user['latitude']}\"".
					" lng=\"{$user['longitude']}\"".
					" useavatar=\"{$user['use_avatar']}\"".
					" avatar=\"{$user['avatar_field']}\" /> \n";
			}

			echo '</markers>';
			die;
		}
	}
?>
