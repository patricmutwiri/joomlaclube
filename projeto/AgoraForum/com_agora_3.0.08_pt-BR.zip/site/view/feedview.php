<?php
    defined ('IN_AGORA') or die;

	class FeedView /*extends View*/
	{
		function FeedView()
		{
			$this->__construct();
		}

		function __construct($template = NULL)
		{
//			parent::__construct($template);
/*			$this->smarty->register_block('item',array(&$this,'item'));
			$this->smarty->register_block('title',array(&$this,'title'));
			$this->smarty->register_block('pubdate',array(&$this,'pubdate'));
			$this->smarty->register_block('description',array(&$this,'description'));*/
			$this->doc = & JFactory::getDocument();
		}

		function assign($name,$value)
		{
			if ($name !== 'items') {
				$this->doc->$name = $value;
			} else {
				$this->items = $value;
			}
		}

		function assignRef($name,& $value)
		{
			if ($name !== 'items') {
				$this->doc->$name = $value;
			} else {
				$this->items = $value;
			}
		}

/*		function item($params, $content, &$smarty, &$repeat)
		{
			if (!isset($content)) {
				if (isset($this->item)) {
					$smarty->trigger_error('You cannot use enclosed {item} functions');
				}
				$this->item = new JFeedItem();
				return;
			}

			$this->doc->addItem($this->item);
			unset($this->item);
		}

		function title($params, $content, &$smarty, &$repeat)
		{
			if (isset($content))
				$this->doc->setTitle($content);
		}

		function pubdate($params, $content, &$smarty, &$repeat)
		{
			if (isset($content))
				$this->item->date = $content;
		}

		function description($params, $content, &$smarty, &$repeat)
		{
			if (isset($content))
				$this->item->description = $content;
		}*/

		function display()
		{
			foreach ($this->items as $item) {
				$new_item = new JFeedItem();

				foreach ($item as $name=>$value) {
					$new_item->$name = $value;
				}

				$this->doc->addItem($new_item);
			}

//			$doc->
/*			$template = $this->template ? $this->template : $template;

			$this->smarty->display($template.'.feed.tpl');*/
			
		}
	}
?>
