/**
 * Ajex.FileManager
 * http://demphest.ru/ajex-filemanager
 *
 * @version
 * 1.0 (1 Oct 2009)
 * 
 * @copyright
 * Copyright (C) 2009 Demphest Gorphek
 *
 * @license
 * Dual licensed under the MIT and GPL licenses.
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
 * 
 * Ajex.FileManager is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This file is part of Ajex.FileManager.
 */

eval(function(p,a,c,k,e,d){while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+c+'\\b','g'),k[c])}}return p}('17 27={51:38(3){15(\'20\'==22(3))3={};2.6=3.6||38(){17 31=65.66(\'64\');40(17 9=-1;++9<31.36;){15(31[9].46(\'19\')&&-1!=(19=31[9].46(\'19\')).63(\'/61.62\')){21 19.34(0,19.67(\'/\'))}}42(\'60 44 "6" 32 27.51({6:"/6/53/27/"});\');21 68}();15(\'/\'==2.6.34(2.6.36-1)){2.6=2.6.34(0,2.6.36-1)}2.5=3.5||\'39\';2.7=3.7||\'73\';2.14=3.14||72;2.16=3.16||71;2.12=3.12||\'69\';2.11=3.11||\'70\';15(\'20\'!=22(3.8)&&45===3.8){2.8=45}18{2.8=74}15(\'39\'==2.5){15(\'20\'!=22(3.10)){3.10.13[\'58\']=2.14;3.10.13[\'56\']=2.16;3.10.13[\'54\']=2.6+\'/26.25?4=37&7=\'+2.7+\'&11=\'+2.11+\'&5=\'+2.5+\'&12=\'+2.12+\'&8=\'+2.8;3.10.13[\'59\']=2.6+\'/23/\'+2.7+\'/23.\'+2.7+\'?4=37&52=41\';17 4=[\'55\',\'57\'];40(17 9 32 4){3.10.13[\'29\'+4[9]+\'98\']=2.14;3.10.13[\'29\'+4[9]+\'94\']=2.16;3.10.13[\'29\'+4[9]+\'95\']=2.6+\'/26.25?4=\'+4[9].24()+\'&7=\'+2.7+\'&11=\'+2.11+\'&5=\'+2.5+\'&12=\'+2.12+\'&8=\'+2.8;3.10.13[\'29\'+4[9]+\'93\']=2.6+\'/23/\'+2.7+\'/23.\'+2.7+\'?52=41&4=\'+4[9].24()}}18{42(\'92 90 53 91 43 96 32 43 44 "10"\')}}18 15(\'50\'==2.5){}18{2.4=3.4||\'37\';2.28=2.6+\'/26.25?4=\'+2.4.24()+\'&7=\'+2.7+\'&11=\'+2.11+\'&12=\'+2.12+\'&8=\'+2.8;2.48=\'14=\'+2.14+\',16=\'+2.16+\'97=1,75=0,101=0,100=1,99=0,89=0,88=,80=\'}21},35:38(3,28,4,30){15(\'20\'!=22(3.5)){5=3.5}18{5=2.5}79(5){49\'39\':33;49\'50\':78.76.77.35({28:2.6+\'/26.25?4=\'+4.24()+\'&7=\'+2.7+\'&5=\'+2.5+\'&11=\'+2.11+\'&12=\'+2.12+\'&8=\'+2.8,14:2.14,16:2.16,81:\'82\',87:\'86\'},{47:30,85:3});33;83:17 30=47.35(2.28+\'&5=\'+5,\'27\',2.48);30.84();33}21}}',10,102,'||this|params|type|returnTo|path|connector|contextmenu|i|editor|lang|skin|config|width|if|height|var|else|src|undefined|return|typeof|ajax|toLowerCase|html|index|AjexFileManager|url|filebrowser|win|s|in|break|substring|open|length|file|function|ckeditor|for|QuickUpload|alert|the|variable|false|getAttribute|window|args|case|tinymce|init|mode|to|filebrowserBrowseUrl|Flash|filebrowserWindowHeight|Image|filebrowserWindowWidth|filebrowserUploadUrl|Undefined|ajex|js|indexOf|script|document|getElementsByTagName|lastIndexOf|null|dark|ru|660|1000|php|true|menubar|activeEditor|windowManager|tinyMCE|switch|screeny|inline|yes|default|focus|input|no|close_previous|screenx|top|need|pass|You|UploadUrl|WindowHeight|BrowseUrl|object|resizable|WindowWidth|left|location|scrollbars'.split('|')))
