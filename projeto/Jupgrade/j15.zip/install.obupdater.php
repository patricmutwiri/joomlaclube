<?php
/**
* @package		Joomla Updater
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.0.1
*/
	defined('_JEXEC') or die( 'Restricted access' );
//	$db = &JFactory::getDBO();	
/*	# 1. Get current component name		
	# 2. Create config table for component
	$query = "
		CREATE TABLE IF NOT EXISTS `#__$com_name"."_config`(
			 name 			varchar(255) NOT NULL,
			 value 			varchar(255) NOT NULL,
			 params 		text NOT NULL,
			 PRIMARY 		KEY  USING BTREE (name)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8;
	";
	$db->setQuery($query);
	$db->query();
	
	# 3. Insert into table #__config table
	$query 	= "
		INSERT INTO `#__$com_name"."_config` (name, value, params) VALUES
			('license', '134!@#$%^&gsdfg456 fgh dfghdfh', '');
	";
	$db->setQuery($query);
	$db->query();*/
	
	// 1 install plugin System - JUC	
	obInstallPlugin('System - Foobla JUC','objuc','system');
	function obInstallPlugin($name,$element,$folder){
		$db = &JFactory::getDBO();	
		$src	= JPATH_ADMINISTRATOR.DS.'components'.DS.'com_obupdater'.DS.'aio'.DS.'plugins'.DS.$folder;
		$dest	= JPATH_SITE.DS.'plugins'.DS.$folder.DS;
		JFolder::copy($src,$dest,'',true);	
		$query="INSERT IGNORE INTO `#__plugins`(`name`,`element`,`folder`,`published`)
				VALUES('$name','$element','$folder',1)";
		$db->setQuery($query);	
		if(!$db->query()){echo $db->getErrorMsg();}
	}	