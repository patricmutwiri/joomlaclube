<?php
/**
* @package		Joomla Updater Creator
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.0.1
*/
	
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');
class FooblaCoreModelJupgrade extends JModel
{
	private $_cversion = null;
	private $_lversion = null;
	private $_link_down = "";
	public $_url = "http://joomlacode.org/svn/joomla/development/releases/1.5/libraries/joomla/version.php";
	 
	public function getCVersion(){
		if(!$this->_cversion){
			$cjversion = new JVersion();
			$this->_cversion = $cjversion->getShortVersion();
		}
		return $this->_cversion;
	}
	
	public function getLVersion(){		
		if(!$this->_lversion){
			$this->_lversion = $this->getLastVersionFile();
		}
		return $this->_lversion;
	}
	
	private function getLastVersionFile(){
		global $option;
		$url 		= "http://joomlacode.org/svn/joomla/development/releases/1.5/libraries/joomla/version.php";
		$username	="anonymous";
		$password	= "";
		$context 	= stream_context_create(array(
		    'http' => array(
		        'header'  => "Authorization: Basic " . base64_encode("$username:$password")
		    )
		));
		$data = file_get_contents($url, false, $context);
		$wdata = str_replace("JVersion", "LastJVersion", $data);
		$lversionfile = JPATH_ADMINISTRATOR.DS."components".DS.$option.DS."helpers".DS."lastversion.php";
		file_put_contents( $lversionfile, $wdata );
		require $lversionfile;
		$ljversion = new LastJVersion();
		return $ljversion->getShortVersion();
		
	}
	
	public function getLink($cversion,$lversion,$url = "http://joomlacode.org/gf/project/joomla/frs") {
		$respon_obj = new stdClass();
		$respon_obj->cversion 		= $cversion;
		$respon_obj->lversion 		= $cversion;
		$respon_obj->url_download 	= '';
		$respon_obj->url_next 		= '';
		
//		$cversion = $this->getCVersion();
		#$cversion = "1.5.4";
		#lversion = $this->getLVersion();
		#$lversion = "1.5.15";
		
		$url = "http://joomlacode.org/gf/project/joomla/frs";
		$content = file_get_contents($url);
//		$cversion = "1.5.13";
//		$lversion = "1.5.15";
		#TODO: lay link download
		$matches = null;
		preg_match("/\/gf\/download\/frsrelease\/\d+\/\d+\/Joomla_".$cversion."_to_".$lversion."-Stable-Patch_Package.zip/",$content,$matches);
		if(count($matches)){
			$down_url = "http://joomlacode.org".$matches[0];
			$respon_obj->url_download = $down_url;
			return $respon_obj;
		}
		
		#TODO: lay link cua cac trang khac tu cac trang khac
		$matches_all = null;
		preg_match_all('/\/gf\/project\/joomla\/frs\/\?action=\&amp;_br_pkgrls_total=\d+\&amp;_br_pkgrls_page=\d+/',$content,$matches_all);
		$pages = array();
		if(count($matches_all[0])){
			for($i=0;$i<count($matches_all[0]);$i++){
				$pages[] = "http://joomlacode.org".$matches_all[0][$i];
			}
		}
		
		#TODO: lay trang hien tai
		$paginator = null;
		preg_match('/<div class="paginator">[\w\W]+<\/div>/',$content,$paginator);
		$tmp_str = substr($paginator[0],0,stripos($paginator[0],"</div>")+strlen("</div>"));
		
		$cpage = null;
		preg_match('/<strong>\d+<\/strong>/',$tmp_str,$cpage);
		$cpage = intval(trim(substr($cpage[0],strlen('<strong>'),0-strlen('</strong>'))));
		
		#TODO: lay link trang tiep theo = $cpage-1;
		$nextpage = 0;
		if($cpage>count($pages)){
			return $respon_obj;
		}else {
			$nextpage = $cpage-1;
		}
		
		$nexturl = $pages[$nextpage];
		$respon_obj->url_next = $nexturl;
		return $respon_obj;
	}
	
	public function getPack($url_download){
		jimport("joomla.installer.helper");
		$res = JInstallerHelper::downloadPackage($url_download);
		return $res;
	}
	
	public function extractPack($pack_path){
		global $option;
		jimport("joomla.installer.helper");
		jimport("joomla.filesystem.folder");
		jimport("joomla.filesystem.file");
		require_once JPATH_SITE.DS."libraries".DS."joomla".DS."filesystem".DS."archive".DS."zip.php";
//		require_once JPATH_ADMINISTRATOR.DS."components".DS.$option.DS.'helpers'.DS.'ziplib'.DIRECTORY_SEPARATOR.'zip.php';
		$config		= &JFactory::getConfig();
		$tmp_dest	= $config->getValue('config.tmp_path');
//		exit($tmp_dest.$pack_path);
//		$package	= JInstallerHelper::unpack($tmp_dest.$pack_path);
		$tmpdir = uniqid('install_');
		// Clean the paths to use for archive extraction
		$extractdir = JPath::clean(dirname($tmp_dest.$pack_path).DS.$tmpdir);
		JFolder::create($extractdir);
		
		$archivename = JPath::clean($tmp_dest.$pack_path);
		
		$zip = new JArchiveZip();
		if($zip->extract($tmp_dest.$pack_path,$extractdir)){
			return $extractdir;	
		} else {
			return $extractdir;
		}
	}
	
	public function upgradeJBase() {
		global $option;
		
		$cversion 	= &JRequest::getVar('cversion');
		$lversion 	= &JRequest::getVar('lversion');
		$url_down 	= &JRequest::getVar('url_down');
		$extractdir = $this->extractPack($url_down);
		JFolder::copy($extractdir,JPATH_SITE,'',true);
		return "OK";
	}
}
?>