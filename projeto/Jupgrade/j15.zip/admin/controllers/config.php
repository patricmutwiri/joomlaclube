<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.controller');

class FOOBLACOREControllerConfig extends JController
{
	function __construct()
	{
		parent::__construct();
	}
	
	function display()
	{
		$mName		= 'config';
		$document = JFactory::getDocument();
		$vType 		= $document->getType();
		$vName 		= JRequest::getVar('view', 'config');
		$vLayout	= JRequest::getVar('layout', 'default');
		
		$view = $this->getView($vName, $vType);
		$view->setLayout($vLayout);
			
		// Get/Create the view
		$view = &$this->getView( 'config', $vType);
		if ($model = &$this->getModel($mName)) {
			// Push the model into the view (as default)
			$view->setModel($model, true);
		}
		$view->display();
	}
	
	/**
	 *  function saveConfig
	 */
	function saveConfig()
	{
		global $mainframe, $option;
		$models = $this->getModel('config');
		$check_firsttime = $models->check_firsttime();
		if(!$check_firsttime){
			$info	= $models->getInfoConfig();
			$models->saveInfoConfig($info);
			$models->setCheck();
		}
		$models->saveLicense();
		$models->saveDataConfig();
		$models->saveConfig();
		
		$msg = JText::_('Updated success');
		$mainframe->redirect('index.php?option='.$option, $msg);
	}
} // end class
?>