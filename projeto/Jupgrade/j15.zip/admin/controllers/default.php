<?php
/**
* @package		Joomla Updater Creator
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.6
*/
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
jimport('joomla.application.component.controller');
require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'juinstaller.php');
class FooblaCoreController extends JController
{
	function __construct(){
		parent::__construct();
	}	
	function display(){
		$mvc	= 'cpanel';		
		//JRequest::setVar( 'hidemainmenu', 1 );
		$doc	= &JFactory::getDocument();
		$vType	= $doc->getType();
		$view	= &$this->getView( $mvc, $vType);
		$view->setLayout('default');
		if ($model = &$this->getModel($mvc)){$view->setModel($model, true);}
		$view->display();
	}
	function getphpinfo(){
		phpinfo();exit;
	}	
	function checkjver(){
		$JCVer	= JUCommon::getJCurVer();
		$JLVer	= JUCommon::getJLastVer();
		echo "Current version: <b>$JCVer</b>";
		$upgrUrl	= 'index.php?option=com_obupdater&controller=jupgrade';	
		if($JLVer==$JCVer){
			$notice = ' [ <span style="color:#009900;"><b>Latest Version</b></span> ]'; 
		}else {			
			$upgadeLink = '[ <a style="color:#ff6600;" href="'.$upgrUrl.'"><b><blink>Upgrade now</blink></b></a> ]';		 		
			$notice	= ' [ <span style="color:#ff0000;">Latest version: <b>'.$JLVer.'</b></span> ]'.$upgadeLink;
		}		
		exit($notice);		
	}
	function checkinv(){
		require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'jucenvironment.php';
		$jucenvi = new JUCEnvironment();
		//$envi_curl 	= $jucenvi->isCurlLoaded();
		$envi_json 	= $jucenvi->isJsonLoaded();
		$envi_zlib 	= $jucenvi->isZlibLoaded();
		//$envi_php 	= $jucenvi->phpVersion();
		$envi_dirs 	= $jucenvi->isWriteables();
		//$envi_cache	= JUCommon::checkCache();
		$envi_cron	= JUCommon::envErr();		
		$envi_cache = $envi_cron == 1?false:true;
		$envi_file_put	= ($envi_cron == 0 ||$envi_cron >2)?true:false;
		$envi_file_get	= ($envi_cron == 0 ||$envi_cron >3)?true:false;		
		?>
			<div><?= JText::_("All of the following php extensions must be loaded") ?></div>
			<ul>				
				<li class="<?= $envi_json->loaded?"yes":"no" ?>"><?= $envi_json->message ?></li>
				<li class="<?= $envi_zlib->loaded?"yes":"no" ?>"><?= $envi_zlib->message ?></li>				
			</ul>
			<?php if($envi_dirs){ ?>
			<div><?= JText::_("All of the following directory must be writeable") ?></div>
			<ul>
				<li class="<?= $envi_cache?"yes":"no" ?>">
					<? echo JPATH_ROOT.DS.'cache'.DS.'juc [ <b style="color:#'.($envi_cache?'009900;">':'ff0000;">Un').'Writable</b> ]'; ?>
					<ul>
						<li class="<?= $envi_file_put?"yes":"no" ?>">file_put_contents</li>
						<li class="<?= $envi_file_get?"yes":"no" ?>">file_get_contents</li>
					</ul>		
				</li>
				<?php 				
				for( $i=0; $i<count($envi_dirs); $i++ ){ ?>			
					<li class="<?= $envi_dirs[$i]->is_writable?"yes":"no" ?>"><?= $envi_dirs[$i]->dirpath ?></li>
				<?php 
				}?>
			</ul>
			<?php }
		exit();	
	}
	function getupdate(){
		global $option;
		$name	= JRequest::getVar('name','','cmd');
		$type	= JRequest::getVar('type','','cmd');	
		$ext	= JUCommon::checkExtVer($name,$type);
		if($ext->error!=''){exit($ext->error);}
		//echo '<pre>';print_r($ext);echo '</pre>';		
		$lid	= $ext->lid;
		$cuVer	= $ext->cuVer;		  	
		if($lid>0){
			$update = "index.php?option=$option&controller=browse&task=detail&cid[]=";
			exit('<i>'.$cuVer.' (old) </i> [ <a href="'.$update.$lid.'">Update</a> ] ');	
		}elseif ($lid == 0){
			$alt	= 'Latest version';
			$img	= 'Not supported';
			$img	= 'saccess';
			$cuVer	= '<b>'.$cuVer.'</b>';
		}else {
			$alt	= 'Not supported';
			$img	= 'disabled';
			$cuVer	= '<i>'.$cuVer.'</i>';
		}
		$path	= 'components/com_obupdater/assets/images/';
		$resHtml	= $cuVer.'&nbsp;&nbsp;&nbsp;&nbsp;<img width="16" height="16" border="0" title="'.$alt.'" alt="'.$alt.'" src="'.$path.$img.'.png"/>';
		exit($resHtml);
	}
	function getcats(){
		$sever	= JUInstaller::getServer();
		$dm		= JUCommon::getDomain();
		$url	= 'http://'.$sever.'/index.php?option=com_joomlaupdater_server&view=service&task=jucgetcats&dm='.$dm;
		@$json	= file_get_contents($url);
		if(!$json){exit('<i>None Categories</i><input type="hidden" value="0" id="catid" name="catid" />');}				
		$rows	= json_decode($json);
		if(isset($rows->error)){
			exit(JUCommon::getMsg($rows->message,'error'));
		}		
		$catid	= JRequest::getVar('catid',0,'int');
		$catlist='<select name="catid" id="catid"><option value="0">All Categories</option>'.$this->getOptionsCategories($rows,0,$catid).'</select>';
		exit($catlist);		
	}
	function getOptionsCategories($cats=array(),$level=0,$catid){
		$html ='';
		for($i=0; $i<count($cats); $i++){
			$cat = $cats[$i];
			$selected = ($catid==$cat->id)?'selected="selected"':'';
			$html.='<option value="'.$cat->id.'" '.$selected.'>'.str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;',$level).$cat->name.'</option>';
			if(count($cat->subcat)){
				$html.=$this->getOptionsCategories($cat->subcat,$level+1,$catid);
			}
		}
		return $html;
    }
    function getDesLimit($desc,$limit){
   		$desc	= trim($desc);
		$desc	= strip_tags($desc);
		$desArr	= explode(' ',$desc);
		if(count($desArr)>$limit){
			$desTxt = '';
			for ($j=0;$j<$limit;$j++){$desTxt .= ' '.$desArr[$j];}
			$desc = $desTxt.' ...';
		}
		return $desc;
    }
	function getStar($rate){
		$full = strlen($rate)==3 && substr($rate,-1)!= '0';
		$rate = intval(substr($rate,0,1));
		$html = '';
		$next = false;
		$href = JURI::base().'components/com_obupdater/assets/images/juvote/';
		for($i=1;$i<6;$i++){
			if($rate >= $i){
				$star = '10';
				if ($full && $rate ==$i) $next = true;	
			}else {
				$star = '00';
				if($next){
					$star = '05';
					$next = false;
				}
			}			
			$html .= '<img width="16" hspace="1" height="16" src="'.$href.'star_'.$star.'.png" alt="'.($star=='10'?'★':'').'"/>';
		}
		return "<span style=\"color:#ff6600;font-size:13px;\">$html</span>";
	}
	           
    function extsearch(){
    	$sever	= JUInstaller::getServer();
    	$dm		= JUCommon::getDomain();	
    	$url	= 'http://'.$sever.'/index.php?option=com_joomlaupdater_server&view=service&task=jucgetsearch&limit=10';
    	$key_search = JRequest::getVar('name','');
    	$url 	.= $key_search!=''?"&key_search=$key_search":'';    	
    	$ext_includes = JRequest::getVar('extincs','');
    	if($ext_includes !=''){
    		$exts = explode(',',$ext_includes);
    		for($i=0;$i<count($exts);$i++){$url.='&ext_includes[]='.$exts[$i];}
    	}    	
    	$catid	= JRequest::getVar('catid',0,'int');
    	$url	.= "&catid=$catid";    	
    	$ext_types	= JRequest::getVar('extp',0,'int');
    	if($ext_types > 0) $url .= '&ext_types[]='.($ext_types==1?'c':'n');
		$json	= @file_get_contents($url.'&dm='.$dm);
		if(!$json){
			echo JUCommon::getMsg(JText::_('CONNECT_ERROR'),'error');
			exit();			
		}
		$rows = json_decode($json);
		if(isset($rows->error)){
			exit(JUCommon::getMsg($rows->message,'error'));
		}
		$items = $rows->items;
		if($rows->total <1) exit('<div align="center" style="color:#ff6600;"><i><b>Your search does not return any result!</b> </i></div>');
		$server = 'http://obupdater.com/';
		$detail = 'index.php?option=com_obupdater&controller=browse&task=detail&cid[]=';
		for($i=0;$i<count($items);$i++){
			$row	= $items[$i];
			$rate	= $row->avgvote;
			$rate	= intval($rate)>0?$rate:0;
			$rate	= $this->getStar($rate);
			$vote	= $row->count_review;
			$vote	= intval($vote)>0?$vote:0;
			echo '<div class="ext-item">';
			echo '<img width="80" height="80" style="float:right;margin-right:10px;" alt="'.$row->lib_name.'" src="'.$server.$row->lib_image.'"/>';
			echo '<a href="'.$detail.$row->lib_id.'"><b>'.$row->lib_name.'</b></a>';
			echo '<span class="ext-img">'.JUCommon::getExtImg($row->lib_ext_type).'</span>';
			echo '<br/><b>Rating:</b> '.$rate.'&nbsp;&nbsp;&nbsp;&nbsp;<b>Votes:</b> '.$vote;			
			echo '<br/><b>Type:</b> '.($row->lib_commercial==1?'':'Non-').'Commercial';
			echo '<br/><b>Category:</b> '.$row->catid;						
			echo '<br/>'.$this->getDesLimit($row->description,30);
			echo '</div>';
		}
		$searchmore = ' [ <a href="index.php?option=com_obupdater&controller=browse&search='.$key_search.'">Search More</a>]';
		exit('<div align="center" style="background:#eeeeee;color:#33333;padding:5px;"><b>Results:</b> '.($rows->total>10?'10 / '.$rows->total.$searchmore:$rows->total).'</div>');	
	}
}