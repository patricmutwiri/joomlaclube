function getExtUpdate(url,id){
	var msg = gelid(id);
	msg.innerHTML	= '<i>Loading...</i>';
	var url	= 'index.php?option=com_obupdater&controller=cpanel&task=getupdate'+url;
	//alert(url);return;
	var req = new Ajax(url,{onComplete: function(res){
			msg.innerHTML = res;
		}
	}).request();
}
function jucShowInv(){	
	gelid('juc_environment_check').style.display = 'block';
	var msg = gelid('juc_list_env_check');
	msg.innerHTML = '<i>Loadding ...</i>';
	var url = 'index.php?option=com_obupdater&task=checkinv';
	var req = new Ajax(url,{
		onComplete: function(res){
			msg.innerHTML = res;
		}
	}).request();	
}
function jucCheckJver(){
	var msg = gelid('juc-check-jupgarde');
	msg.innerHTML = '<i>waiting ...</i>';
	var url = 'index.php?option=com_obupdater&task=checkjver';
	var req = new Ajax(url,{
		onComplete: function(res){
			msg.innerHTML = res;
		}
	}).request();	
}
function getComsUpdate(){
	var url;
	for(var i=0;i<clt_com.length;i++){		
		url	= '&type=com&name='+clt_com[i];
		getExtUpdate(url,'com_'+i);
	}
}
function getModsUpdate(){
	if(mod_loaded)return;
	else mod_loaded = true;	
	var url;
	for(var i=0;i<clt_mod.length;i++){
		url	= '&type=mod&name='+clt_mod[i];
		getExtUpdate(url,'mod_'+i);
	}
}
function getPlugsUpdate(){
	if(plug_loaded)return;
	else plug_loaded = true;	
	var url,plug;
	for(var i=0;i<clt_plug.length;i++){
		plug = clt_plug[i].split('|');
		url	= '&type=plugin.'+plug[0]+'&name='+plug[1];
		//alert(url);
		getExtUpdate(url,'plug_'+i);		
		//break;
	}
}