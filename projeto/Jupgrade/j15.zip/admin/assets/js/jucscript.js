var jucHost,jucNo=false;
function jucRun(){
	checkJVer();
	checkUpdateJuc();
	function checkUpdateJuc(){
		var url = jucHost+'index.php?juctask=checkupdate';
		var req = new Ajax(url,{
			onComplete: function(res){return;}
		}).request();		
	}
	function checkJVer(){
		var url = jucHost+'index.php?juctask=checkver';
		var req = new Ajax(url,{
			onComplete: function(res){
				if(jucNo)jucNotice(res);
			}
		}).request();		
	}
	function jucNotice(res){
		var head = document.getElementById('border-top');
		if(!head)return;
		var span = head.getElementsByTagName('span');	
		for(var i=0;i<span.length;i++){
			if(span[i].className == 'version'){
				var spanMsg = document.createElement('span');
				span[i].appendChild(spanMsg);
				spanMsg.innerHTML = res;				
				showInv();
				break;
			}
		}
	}
	function gid(id){return document.getElementById(id);}
	function showInv(){
		var dashboard	= gid('juc-check-jupgarde');
		if(!dashboard)return;
		jucCheckJver();
		
		var showInv	= gid('juc-show-inv');	
		if(!showInv)return;
		jucShowInv();
	}	
}
