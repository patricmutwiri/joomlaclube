window.onload=function (){	
	getComsUpdate();
	gelid('panelModule').onclick = function(){getModsUpdate();}
	gelid('panelPlugin').onclick = function(){getPlugsUpdate();}
	gelid('ju_bt_search').onclick= function(){juc_search();}	
	gelid('key_search').focus();
	getCategories();
}
function get_ext_includes(){	
	var f=document.ju_search,cb,extIncs = new Array;
	for(var i=0;i<6;i++){		
		cb=eval('f.ext_inc_'+i);			
		if(cb.checked) extIncs.push(cb.value);
	}	
	return extIncs.toString();
}
function get_ext_types(){
	var f=document.ju_search;	
	if(f.ext_tp_0.checked) return 0;
	if(f.ext_tp_1.checked) return 1;
	if(f.ext_tp_2.checked) return 2;
}
function juc_search(){	
	var name	= gelid('key_search').value;
	if(name==juksearch) name = '';
	var data	= '&name='+name;
	var incs	= get_ext_includes();	
	data	+= incs!=''?'&extincs='+incs:'';	
	var extp	= get_ext_types();
	data	+= '&extp='+extp;
	data	+='&catid='+gelid('catid').value;	
	var url	= 'index.php?option=com_obupdater&controller=cpanel&task=extsearch'+data;	
	var loading = gelid('ju-loading');	
	//gelid('ju_advance_search').style.display='none';
	loading.style.display = 'block'; 	
	var req = new Ajax(url,{onComplete: function(res){			
			var sres = gelid('ju-search-result'); 
			sres.style.display='block';			
			sres.innerHTML=res;
			loading.style.display = 'none';
		}
	}).request();	
}
function getCategories(){
	var url	= 'index.php?option=com_obupdater&controller=cpanel&task=getcats';	
	var req = new Ajax(url,{onComplete: function(cats){
			gelid('catlist').innerHTML = cats;
		}
	}).request();		
}
function toggleAdvanceSearch(){
	var adv_search = gelid('ju_advance_search');	
	if(adv_search.style.display=='none'){
		adv_search.style.display='block';
	}else{adv_search.style.display='none';}
}