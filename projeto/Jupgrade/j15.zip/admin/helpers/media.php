<?php
/**
* @package		jLord Core
* @subpackage	Media
* @author 		The Joomlord Team.
* @copyright	Copyright (C) 2008 The Joomlord Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		media.php 1.5.0.1	20080915.1058	Joomlord
* 20081120.1635	thongta	- modified copyright information
* 						- optimize some of source code
*/

/**
 * @package		Joomla
 * @subpackage	Media
 */
class MediaHelper
{
	
	function getVersion()
	{
		$xml = & JFactory::getXMLParser('Simple');
		if ($xml->loadFile(JPATH_COMPONENT_ADMINISTRATOR.DS.'elements'.DS.'version.xml'))
		{
			if (!$version = & $xml->document->version) {
				return false;
			}
			if (!$url = & $xml->document->url) {
				return false;
			}
			if (!$productcode = & $xml->document->productcode) {
				return false;
			}
		} else {
			return false;
		}
		
		return array('version' => $version[0]->data(), 'url' => $url[0]->data(), 'productcode'=> $productcode[0]->data() );
	}
} // end class