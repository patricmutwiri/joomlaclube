<?php 
/**
* @package		Joomla Updater Creator
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.6
*/
define('JUC_HELPER', realpath(dirname(__FILE__).'/../').DS );
class JUC_Plugin_system {
	function run(){
		$task	= JRequest::getVar('juctask','ajax');
		
		if($task!='ajax'){
			require_once JUC_HELPER.'common.php';
			$envErr = JUCommon::envErr();
			if($envErr > 0){
				$notice	= ' [ <b style="color:#ff9900;">JUC Notice: </b><a style="color:#ff0000;" href="index.php?option=com_obupdater"><b id="juc-show-inv">Environment not full!</b> ('.$envErr.')</a> ]';
				exit($notice);
			}
		}
		switch ($task){
			case 'checkver':JUC_ABC::checkVer();break;				
			case 'checkupdate':JUC_ABC::checkUpdate();break;
			case 'clearcache':JUC_ABC::clearCache();break;	
			case 'sendmail':JUC_ABC::noticeJupdate();break;		
			default:JUC_Plugin_system::runAjax();				
		}
	}
	function runAjax(){
		global $mainframe;
		$host	= JURI::root();
		$js	= "jucHost='$host';window.addEvent('domready',function(){jucRun();});";		
		if($mainframe->isAdmin() && @$_REQUEST['option']!='com_installer'){$js='jucNo=true;'.$js;}
		JHTML::_('behavior.mootools');
		$doc	= &JFactory::getDocument();
		$doc->addScript($host.'administrator'.DS.'components'.DS.'com_obupdater'.DS.'assets'.DS.'js'.DS.'jucscript.js');
		$doc->addScriptDeclaration($js, 'text/javascript');		
	}	
}
class JUC_ABC{
	function clearCache(){
		jimport('joomla.filesystem.file');
		$cachePath	= JPATH_ROOT.DS.'cache'.DS.'juc';		
		if (is_dir($cachePath)) {
			$msg = 'Clear '.(!JFolder::delete($cachePath)?'Fail':'Success'); 
		}else $msg = 'JUC cache don\'t exist ['.$cachePath.']';
		exit($msg);
	}
	function checkUpdate(){// exit('pause');
		$extN	= 'obupdater';
		$res = JUCommon::checkExtVer($extN,'com');		
		if(!$res->lid>0) exit('Using latest versions!');
		if($res->nextVer=='')exit('Don\'t exist Patch!');
		exit('Need update!');
/*
		require_once JUC_HELPER.'juinstaller.php';
		JRequest::setVar('lid',$res->lid);
		JRequest::setVar('ext_name',$extN);
		JRequest::setVar('ver',$res->nextVer); 
		JRequest::setVar('ex_type','com');
		JRequest::setVar('task','juupgrade');		
		$install = new JUInstaller;
		$res = $install->upgrade();
		exit('Check Update Done');			
*/	
	}
	function checkVer(){
		$JCVer	= JUCommon::getJCurVer();
		$JLVer	= JUCommon::getJLastVer();		
		$upgrUrl	= 'index.php?option=com_obupdater&controller=jupgrade';	
		if($JLVer==$JCVer){
			$notice = ' [ <a href="'.$upgrUrl.'" title="check version"><span style="color:#00ff00;"><b>Latest Version</b></span></a> ]'; 
		}else {
			JUC_ABC::noticeJupdate($JLVer);
			$upgadeLink = '[ <a style="color:#ffcc00;" href="'.$upgrUrl.'"><b><blink>Upgrade now</blink></b></a> ]';		 		
			$notice	= ' [ <span style="color:#ff0000;">Latest version: <b>'.$JLVer.'</b></span> ]'.$upgadeLink;			
		}		
		exit($notice);
	}
	function noticeJupdate($newVer){
		$path	= JPATH_ADMINISTRATOR.DS.'components'.DS.'com_obupdater'.DS.'config.xml';
		$obParams	= &JComponentHelper::getParams( 'com_obupdater',$path);
		$obParams	= $obParams->toObject();
		if(@$obParams->notice_jupdate!='1'){
			return ;
			//exit('No run I');
		}
		$cache	= JUC_CACHE.DS.'noticejupdate.html';	
		if(is_file($cache)){
			$info	= file_get_contents($cache);
			$info	= json_decode($info);
			if(isset($info->newver) && $info->newver == $newVer){
				return ;
			}
		}
		$toMail	= @$obParams->to_mail;
		preg_match('/^[^@]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$/', $toMail,$check);		 
		if(!$check){
			return ;
			//exit('No run II');
		}
		$toName	= explode('@',$toMail);
		$toName	= ucfirst($toName[0]);
				
		$mailFrom	= 'support@foobla.com';
		$fromName	= 'Foobla';
		$thisSite	= JURI::root();
		$urlUpdate	= $thisSite.'administrator/index.php?option=com_obupdater&controller=jupgrade';
		$subject	= "Verison $newVer of Joomla has been released";		
		$msg	= "Hi $toName, <br /><br /> Version <b>$newVer</b> of Joomla has been released. <br /><br />";
		$msg	.= "You should update for your joomla sites soon as possible!<br /><br />";
		$msg	.= "<b>Update now for <a href=\"$urlUpdate\">$thisSite</a></b>";
		
		$mailer = &JFactory::getMailer();
		$mailer->setSender(array($mailFrom, $fromName));
		$mailer->addRecipient($toMail);
		$mailer->setSubject($subject);
		$mailer->setBody($msg);
		$mailer->IsHTML(1);
		$send = $mailer->Send();
				
		//$sendmail = JUtility::sendMail($fromMail, $fromName, $toMail, $subject, $msg);
		//var_dump($sendmail);
		if($send){
			$info	= new stdClass();
			$info->newver	= $newVer;
			$info->time	= date('Y-m-d H:i:s');
			$info	= json_encode($info);
			file_put_contents($cache,$info);					
		}
		//echo "<br>from Mail:$fromMail<br>from Name: $fromName<br>To Mail: $toMail<br>subject: $subject<br>msg: $msg";
		//exit('<h1>Done</h1>');		
	}
}
