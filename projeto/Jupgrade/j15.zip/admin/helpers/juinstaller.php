<?php
/**
* @package		Joomla Updater
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		2009-12-05 10h00 AM
*/
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
jimport( 'joomla.installer.installer' );
jimport('joomla.filesystem.archive');
jimport('joomla.installer.helper');
jimport('joomla.filesystem.file');
class JUInstaller {
	function getErrPk($p_file){
		$res	= new stdClass();
		$res->lid	= @$this->_lid;
		if(substr($p_file,0,5)=='errpk'){
			$pkErrC = substr($p_file,6,-5);
			switch ($pkErrC){
				case 1:$res->msg	= 'Sorry, the extension not found';break;
				case 2:$res->msg	= 'Sorry, this install package errors. Please try again with other version or notice us about this problem.';break;
				case 3:$res->msg	= 'This service requires BROZEN Membership or higher [ <a href="http://obupdater.com/component/acctexp/?task=renewsubscription" target="_blank">Upgrade Your Membership Now</a> ]';break;
				case 4:$res->msg	= 'Not enough info';break;
				case 5:$res->msg	= 'Sorry, None pacth';break;
				case 6:$res->msg	= 'Sorry, Patch package is broken, please notice us about this problem';break;				
				default:
					if(substr($pkErrC,0,5) == 'inst:'){
						$res->msg	= $pkErrC;break;
					}else
						$res->msg	= "Package Error [ $pkErrC ]";
			}
			$res->state = $pkErrC == 3?'notice':'error';			
		}else {
			$res->msg	= '';
			$res->state	= 'message';
		}
		return $res;
	}
	function install(){
		$p_file = $this->getPKFromUrl();
		$res	= $this->getErrPk($p_file);
		if($res->msg !=''){return $res;}
		$tmp_dest	= $this->getTmpDest();	
		$package	= &JInstallerHelper::unpack($tmp_dest.DS.$p_file);
		$installer	= &JInstaller::getInstance();
		$res	= new stdClass();
		$res->lid	= $this->_lid;
		if($installer->install($package['dir'])){			
			$res->state = 'message';
			$res->msg	= 'Install '.$package['type'].' success';
		}else {
			$res->msg	= 'Install '.$package['type'].' fail';
			$res->state = 'error';
		}	
		JInstallerHelper::cleanupInstall($package['packagefile'], $package['extractdir']);		
		return $res;
	}
	function getTmpDest(){
		$config	= &JFactory::getConfig();
		$tmp_dest	= $config->getValue('config.tmp_path');
		return $tmp_dest;		
	}
	function jucRedirect($res){
		global $mainframe,$option;
		$mainframe->redirect('index.php?option='.$option.'&controller=browse&task=detail&cid[]='.$res->lid,$res->msg,$res->state);
	}
	function upgrade(){
		$p_file = $this->getPKFromUrl();
		$res	= $this->getErrPk($p_file);
		if($res->msg !=''){
			$res->redirect	= true;
			return $res;
		}else $res->redirect	= false;
		$tmp_dest	= $this->getTmpDest();
		$ugrPK	= JPath::clean($tmp_dest.DS.$p_file);
		$extDir	= $this->unpack($ugrPK);		
		//$extDir	= '/home/thongta/public_html/fullsite/joomlaupdater.com/tmp/upgrade_4b18cf028421b';
		$ugrXML	= JPath::clean($extDir.DS.'upgrade.xml');
		$xml	= &JFactory::getXMLParser('Simple');
		$xmlInvalid = false;		
		if ($xml->loadFile($ugrXML)){
			$root	= @$xml->document;
			$pCode	= @$root->getElementByPath('pcode');
			if($pCode){$pCode = $pCode->data();
			}else $xmlInvalid = true;
			$ver	= @$root->getElementByPath('version');
			if($ver){$ver = $ver->data();
			}else $xmlInvalid = true;
		}else $xmlInvalid = true;
		$urgInfo = '';
		if($xmlInvalid){
			$urgInfo .= '<br /><b>upgrade.xml invalid</b> ';
			echo $urgInfo; 
			return $res;
		}
		// create Folder backup.		
		$bakDir = $pCode.DS.$ver.DS.'bak_'.date('Y.m.d.H.i.s').DS.'files';
		//$bakDir = $pCode.DS.$ver.DS.'bak1259648681'.DS.'files';		
		//$bakDir = JPath::clean(JPATH_COMPONENT_ADMINISTRATOR.DS.'backup'.DS.$bakDir);		
		$bakDir	= JPath::clean(JPATH_ADMINISTRATOR.DS.'backups'.DS.'jubackup'.DS.$bakDir);		
		if(!JFolder::exists($bakDir)) JFolder::create($bakDir);
		//$fds	= $ugrFs->children();
		$ugrPathFiles	= JPath::clean($extDir.DS.'files');
		$ugrFiles	= JFolder::files($ugrPathFiles,'.',true,true);		
		$urgInfo .= '<br /><b>start Upgrade</b>';
		
		$rBakDir= dirname($bakDir);		 
		$bakXml	= JPath::clean($rBakDir.DS.'upgrade.xml');
		if(JFile::copy($ugrXML, $bakXml)){
			$urgInfo .= '<br />File: upgrade.xml <b>[Stored]</b>';
		} else return $res;
		$urgInfo .= '<br /><br /><b>Start Update Files: </b>';
		foreach($ugrFiles as $file){
			$urgInfo .= '<br />';
			$fname = str_replace($ugrPathFiles.DS,'', $file);
			$fDest = JPath::clean(JPATH_ROOT.DS.$fname);
			if(is_file($fDest)){
				$update = true;
				$bakFile = JPath::clean($bakDir.DS.$fname);
				$dirBak = dirname($bakFile);								
				if(!JFolder::exists($dirBak)){$this->createIndexHtml($dirBak);}
				if(JFile::copy($fDest,$bakFile)) {
					$urgInfo .= '<br />File: '.$fname.' <b>[Backup]</b>';
				}
			}else {
				$update = false;
				$dirDest = dirname($fDest);
				if(!JFolder::exists($dirDest)){
					$this->createIndexHtml($dirDest);
					$urgInfo .= '<br />Folder: '.$dirDest.' <b>[Created]</b>';
				}
			}
			$urgInfo .= '<br />';			
			if(JFile::copy($file, $fDest)) {
				$urgInfo .= 'File: '.$fname.' <b>['.($update?'Updated':'Created').']</b>';
			} else {
				$urgInfo .= 'Can\'t update file: '.$fname;
			}
		}
		$urgInfo .= '<br /><b>Update files DONE!</b><br />';
		if($this->zipFolder($rBakDir)){
			$urgInfo .= '<b>Backup File created: </b>';
			//$fbak = JPath::clean(dirname($rBakDir).DS.basename($rBakDir).'.zip');
			$fbak = str_replace(JPATH_BASE,JURI::base(),$rBakDir.'.zip');			
			$urgInfo .= '<br />Get backup file:<a href="'.$fbak.'"> '.basename($fbak).'</a><br />';
		}else echo 'Can\'t create Zip file backup';
		$urgInfo .= $this->exeSqlUgr($extDir);
		$urgInfo .= '<br /><b>Start Execute script upgrade:</b><br />';
		$urgInfo .= $this->exeScriptUgr($extDir);
		$urgInfo .= '<b>Upgarade Done</b>';		
		$rpUgr = JPath::clean(dirname($rBakDir).DS.basename($rBakDir).'.html');						
		JFile::write($rpUgr,$urgInfo);
		$this->clearFile($ugrPK);
		$this->clearFolder($extDir);
		$this->clearFolder($rBakDir);
		echo $urgInfo;
		return $res;
	}
	function exeSqlUgr($extDir){
		$incPath = JPath::clean($extDir.DS.'upgrade.sql');
		if(is_file($incPath)){
			$sqlUgr = JFile::read($incPath);
			$qrys	= explode(';',$sqlUgr);
			$db		= &JFactory::getDBO();
			$sqlUgr = '<br /><b>Start Update Database:</b>';
			foreach ($qrys as $qry){
				$qry = trim($qry);
				if($qry =='') continue;	
				$db->setQuery($qry);
				$sqlUgr .= '<br/>';
				if (!$db->query())$sqlUgr .= '<b>[Error]: </b>'.$db->_errorMsg;
				else $sqlUgr .= '<b>[Success]: </b>'.$qry;				
			}
			$sqlUgr .= '<br /><b>Update Datababe DONE!</b>';
		}else $sqlUgr = 'not exist upgrade.sql file.';
		return $sqlUgr.'<br /><br />';
	}
	function exeScriptUgr($extDir){
		$incPath = JPath::clean($extDir.DS.'upgrade.php');		
		if(is_file($incPath)){
			$scriptInfo = '';
			require_once($incPath);
			$scriptInfo .= '<br /><b>Execute script upgrade DONE</b>';		
		}else $scriptInfo = '<br />Not exist upgrade.php file.';
		return $scriptInfo.'<br /><br />';
	}
	function clearFile($path){
		if (is_file($path)) {
			JFile::delete($path);
		}
	}
	function clearFolder($path){
		if (is_dir($path)) {
			JFolder::delete($path);
		}
	}
	function zipFolder($dir = null){
		if (!$dir) return false;
		require_once JPATH_LIBRARIES.DS.'joomla'.DS.'filesystem'.DS.'archive'.DS.'zip.php';		
		$files = JFolder::files($dir,'.',true,true);
		$fileinfos	=	array();
		for ($i=0; $i<count($files); $i++){
			$fileinfos[$i]['data']	=	JFile::read($files[$i]);
			$fileinfos[$i]['name']	=	str_replace($dir.DS,'', $files[$i]);
		}
		$zipname= basename($dir).'.zip';		
		$zipdest= JPath::clean(dirname($dir).DS.$zipname);		
		$aZip	= new JArchiveZip();
		return $aZip->create($zipdest, $fileinfos);
	}
	function unpack($p_filename){
		$archivename = $p_filename;		
		$tmpdir = uniqid('upgrade_');
		$extractdir = JPath::clean(dirname($p_filename).DS.$tmpdir);
		$archivename = JPath::clean($archivename);
		$result = JArchive::extract( $archivename, $extractdir);
		if ( $result === false ) {
			return false;
		}
		return $extractdir; 
	}
	function createIndexHtml($dirDest){
		$idxFile = JPath::clean($dirDest.DS.'index.html');		
		JFile::write($idxFile,'<html><head></head><body>&nbsp;</body></html>');
	}
	function getPKFromUrl(){
		$lid	= JRequest::getInt('lid');
		$this->_lid = $lid;
		$extName= JRequest::getCmd('ext_name'); //
		$ver	= JRequest::getCmd('ver'); // 
		$exType	= JRequest::getCmd('ex_type'); //kieu extension com/mod/plug		
		$pkType = JRequest::getVar('task')=='juupgrade'?1:0;
		$server = $this->getServer();
		$dm		= JUCommon::getDomain();
		$url	= 'http://'.$server.'/index.php?option=com_joomlaupdater_server&view=service&task=getpk';
		//$url	= 'http://'.$server.'/index.php?option=com_joomlaupdater_server&view=service&task=getpk';
		$url 	.= "&lid=$lid&ext_name=$extName&ex_type=$exType&ver=$ver&pk_type=$pkType";
		//exit($url);
		$p_file	= JInstallerHelper::downloadPackage($url.'&dm='.$dm);
		return $p_file;
	}
	function getServer(){
		return JUCommon::getJusHost();
	}
	// >> Jun 24 2010
	function extUpdate($type, $code, $cuVer, $toVer){	
		$dm		= JUCommon::getDomain();
		$server = JUCommon::getJusHost();
		$url	= 'http://'.$server.'/index.php?option=com_joomlaupdater_server&view=service&task=getextpatch';
		$url	.= "&type=$type&code=$code&cuver=$cuVer&tover=$toVer&dm=$dm";
		$p_file	= JInstallerHelper::downloadPackage($url);
		$res	= $this->getErrPk($p_file);
		//$res->msg = 'inst:355';
		//echo "[ $res->msg ]";
		if($res->msg !=''){
			if(substr($res->msg,0,5) == 'inst:'){
				$lid	= substr($res->msg,5);
				$url = "index.php?option=com_obupdater&controller=browse&task=juinstall&ex_type=$type&lid=$lid&ver=$toVer";
				echo '<br /><br /><b style="color:#333333;">Detected the install package of new version has method is "upgrade":</b> [ <a href="'.$url.'"><b>UPGRADE now with Install package</b></a> ]';
				exit();
			}
			return $res->msg;
		}
		$tmp_dest	= $this->getTmpDest();
		$ugrPK	= JPath::clean($tmp_dest.DS.$p_file);
		$extDir	= $this->unpack($ugrPK);		
		//$extDir	='/home/thongta/public_html/dev/obupdater/tmp/upgrade_4c28799b13983';
		//echo "<br>[ extractdir: $extDir ]";				
		$pkUgr	= $this->getGxmlInfo($extDir);
		//echo '<pre>';print_r($pkUgr);echo '</pre>';
		$pkUgrInvalid	= $pkUgr->Invalid;		
		if(!$pkUgrInvalid && (($pkUgr->type != $type)
			||($pkUgr->code != $code)
			||($pkUgr->pVer != $cuVer)
			||($pkUgr->nVer != $toVer)))$pkUgrInvalid = true;	

		$log = '';	
		if($pkUgrInvalid){
			$log	.= '<br/><b>Patch info:</b> [ Type: '.$pkUgr->type.' ][ Code: '.$pkUgr->code.' ]';
			$log	.= '[ Pr Ver: '.$pkUgr->pVer.' ][ To Ver: '.$pkUgr->nVer.' ]';
			$log	.= '<br/><br/><b style="color:#ff3300;">Error: Invalid Patch package:</b> ';
			return $log;
		}
		$bakname	= date('Y.m.d_H.i').'_'.$cuVer.'_to_'.$toVer;
		$bakDir		= $type.'_'.$code; 
		$backup		= $this->extBackup($extDir,$bakname,$bakDir);
		
		$log = $backup->info;
		//echo '<br>Stop: '.$backup->error;
				
		if(!$backup->error){
			$log .=  $this->doUpdate($extDir);				
		}
		$log .= '<h4 style="color:#3366cc;">Done</h4>';
		@file_put_contents(JUC_BACKUP.$bakDir.DS.$bakname.'.html',$log);//FILE_APPEND
		JFolder::delete($extDir);
		return $log;
	}

	function extBackup($extDir,$bakname,$bakDir){
		$extDirFiles	= 	$extDir.DS.'files';
		$files = JFolder::files($extDirFiles,'.',true,true);
		$bakfiles = array();
		$updateList = '';
		$newList	= '';
		$lengExtDir	= strlen($extDirFiles);
		$lengRoot	= strlen(JPATH_SITE);
		$noUpgrade	= 0;
		for ($i = 0; $i < count($files); $i++) {
			$bfile = JPath::clean(JPATH_SITE.DS.substr($files[$i],$lengExtDir));
			$writable = '<img border="0" width="16" height="16" src="components/com_obupdater/assets/images/saccess.png" alt="Writable" title="Writable">';
			$msg	= '';	
			if(is_file($bfile)){
				$bakfiles[] = $bfile;				
				if(!is_writable($bfile)){
					//$setmod 	= chmod($bfile, 755);var_dump($setmod);
					//if(!$setmod){
						$noUpgrade++;
						$perm	= fileperms($bfile);
						$chmod	= substr(sprintf('%o',$perm), -4);						
						$writable	= '<img border="0" width="16" height="16" alt="Unwritable" src="images/publish_x.png">';
						$msg	= '<b style="color:#ff1100;">[ Unwritable ][ Perms: '.$chmod.' ]</b>'; 																	
					//}
				}
				$updateList .= "<li>".$writable.substr($bfile,$lengRoot)." $msg</li>\n";
			}else {
				if(!$this->checkWrite($bfile)){
					$noUpgrade++;
					$writable	= '<img border="0" width="16" height="16" alt="Unwritable" src="images/publish_x.png">';
					$msg	= '<b style="color:#ff1100;">[ Unwritable ]</b>';
				}
				$newList.= "<li>$writable ".substr($bfile,$lengRoot)." $msg</li>\n";
			}
		}

		$log	= "<br /><br /><b>Modified files list: </b><ol>$updateList</ol>\n";
		$log	.= "<b>New Files list: </b> ".($newList?"<ol>$newList</ol>":'[<i> None </i>]')."</ol>";
					
		if(!$noUpgrade){
			//echo '<br><br>check:'.$extDir.DS.'upgrade.php';
			//var_dump(is_file($extDir.DS.'upgrade.php'));			
			if(is_file($extDir.DS.'upgrade.php')){
				require_once $extDir.DS.'upgrade.php';
			}
			if(class_exists('JUextUpdate')){
				$path_zipbak= JUC_BACKUP.$bakDir.DS.'zipbak'.DS.$bakname;			
				$this->zipBakFile($bakfiles,$path_zipbak,$extDir);	
				$backupLink = substr($path_zipbak,($lengRoot+15));			
				//echo '<br />'.$path_zipbak.'<br />'.$backupLink;			
				$log	.= "<br /><br /><b>Backup:</b> <a href=\"$backupLink.zip\">$backupLink.zip</a> ";
			}else {
				$noUpgrade++;				
				$msg	= "Error:[ upgrade.php ]";
				$log	.= "<br /><br /><span style=\"border2px solid #ff1100;color:#ff1100;font-weight:bold;\">$msg</span>";
			}
		}else {
			$msg	= "Error: Unwritable, Please set writable for all, then start Upgrade again ![ $noUpgrade file(s) ]";
			$log	.= "<br /><br /><span style=\"border2px solid #ff1100;color:#ff1100;font-weight:bold;\">$msg</span>";
		}				
		$res	= new stdClass();
		$res->info	= $log;
		$res->error	= $noUpgrade;		
		return $res;		
	}
	function doUpdate($extDir,$type='update'){
		$dirFiles	= $extDir.DS.'files';
		if(JFolder::copy($dirFiles,JPATH_SITE,'',true)){			
			$replace	= '<b style="color:#0066cc;">successful !</b>';			
		}else{			
			$replace	= '<b style="color:#ff3300;">fail !</b>';
		}
		$log	= '<br /><br /><b>Replace the files:</b> '.$replace;		
		$log	.= '<p>'.($type=='update'?JUextUpdate::doUpdate():JUextUpdate::reStore()).'</p>';
		return $log;
	}
	function extRestore($ext){
		$log	= '';		
		$type	= substr($ext,0,3);
		
		if(in_array($type,array('com','mod'))){
			$code	= substr($ext,4);	
		}else {
			$log .= "<b>Error[1][ $ext ]</b>";
			return $log;
		}
		//echo "[ $type $code ]<br>";
		$cuVer	= JUCommon::getCuVer($code,$type);
		if(!$cuVer){
			$log .= "<b>Error[2][ cuVer: $cuVer ]</b>";
			return $log;
		}		
		//echo "<b>Restore: $ext cuVer: $cuVer</b>";		
		$pathBak = $this->getBakZipLatest($ext);
		$bakName	= basename($pathBak);
		$dest = JPATH_ROOT.DS.'tmp'.DS.$ext.'_bak_'.$bakName;
		if(!JFile::copy($pathBak, $dest)){
			$log .= "<b>Error[3][ Copy Fail ]</b>";
			return $log; 
		}
		$extDir = $this->unpack($dest);
		//echo "[ extDir: $extDir ]";		
		$pkUgr	= $this->getGxmlInfo($extDir);
		//echo '<pre>';print_r($pkUgr);echo '</pre>';
		$pkUgrInvalid	= $pkUgr->Invalid;		
		if(!$pkUgrInvalid && (($pkUgr->type != $type)
			||($pkUgr->code != $code)			
			||($pkUgr->nVer != $cuVer)))$pkUgrInvalid = true;	
		if($pkUgrInvalid){
			$log .= "<b>Error[4][ bak file Invalid ]</b>";
			return $log;						
		}
		$log .= "<b>Restore:</b> [ $ext ][ cuVer: $cuVer ][ backVer: $pkUgr->pVer ]<br />";
		if(is_file($extDir.DS.'upgrade.php')){
			require_once $extDir.DS.'upgrade.php';
			if(class_exists('JUextUpdate')){
				$log .= $this->doUpdate($extDir,'restore');			
			}else {
				$log .= "<b>Error[6][ JUextUpdate Class ]</b>";
				return $log;	
			}
		}else {
			$log .= "<b>Error[5][ upgrade.php ]</b>";
			return $log;			
		}		
		$this->clearFile($dest);
		$this->clearFolder($extDir);		
		return $log;
	}
	function zipBakFile($bakfiles,$path_zipbak,$extDir){ //return;
		$lengRoot	= strlen(JPATH_SITE); 
		JUCommon::createIndexHtml($path_zipbak.DS.'index.html');		
		JFile::copy($extDir.DS.'upgrade.xml',$path_zipbak.DS.'upgrade.xml');
		JFile::copy($extDir.DS.'upgrade.php',$path_zipbak.DS.'upgrade.php');
		for ($i=0;$i<count($bakfiles);$i++){
			$fbak	= $bakfiles[$i];
			$scr	= substr($fbak,$lengRoot);
			$dest	= JPath::clean($path_zipbak.DS.'files'.DS.$scr);		
			JUCommon::createIndexHtml($dest);
			JFile::copy($fbak,$dest);
		}
		$this->zipFolder($path_zipbak);
		$this->clearFolder($path_zipbak);
	}
	function getGxmlInfo($extDir){
		$pkUgr	= new stdClass();
		$pkUgr->Invalid	= false;		
		$ugrXML	= JPath::clean($extDir.DS.'upgrade.xml');				
		$xml	= &JFactory::getXMLParser('Simple');		
		if(!$xml->loadFile($ugrXML)){
			$pkUgr->Invalid	= true;
			return $pkUgr;
		}		
		$root	= @$xml->document;
		$utype	= @$root->getElementByPath('type');
		$ucode	= @$root->getElementByPath('code');
		$uNver	= @$root->getElementByPath('version');
		$uPver	= @$root->getElementByPath('preversion');
		
		$pkUgr->type	= @$utype->data();
		$pkUgr->code	= @$ucode->data();
		$pkUgr->pVer	= @$uPver->data();
		$pkUgr->nVer	= @$uNver->data();		
		return $pkUgr;						
	}
	function checkWrite($file){
		if(!JFile::write($file,'<?php echo "ju-write"; ?>'))return false;		
		return true;
	}
	function getBakZipLatest($ext){
		$path	= JUC_BACKUP.$ext.DS.'zipbak';
		if(!is_dir($path))return false;
		$files	= JFolder::files($path, '.zip', false, true);	
		if(count($files)<1) return false;		
		$max = count($files);
		$i=0;
		foreach($files as $file){$i++;if($max==$i)$f=$file;}	
		return $f;
	}
}