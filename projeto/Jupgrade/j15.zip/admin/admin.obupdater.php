<?php
/**
* @package		Joomla Updater
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.0.1
*/
	
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
define('JUC_BACKUP',JPATH_ADMINISTRATOR.DS.'backups'.DS.'jubackup'.DS);
require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'common.php');
require_once(JPATH_COMPONENT.DS.'controllers'.DS.'default.php');
if($controller = JRequest::getVar('controller')) {
	$path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
	if (file_exists($path)) {
		require_once($path);
	} else {
		$controller = '';
	}
}
#JRequest::setVar( 'hidemainmenu', 1 );
// create the controller
$fooblaController = 'FooblaCoreController'.ucfirst($controller);

$controller = new $fooblaController();

// perform the request task
$controller->execute(JRequest::getVar('task'));
// redirect if set by controller
$controller->redirect();
?>