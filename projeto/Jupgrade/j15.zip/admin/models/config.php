<?php
/**
* @package		jLord Core
* @author 		Thong Tran - The Joomlord Team.
* @copyright	Copyright (C) 2008 The Joomlord Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		config.php 1.5.0.1	20081119.1635	thongta
* 20081120.1635	thongta	- modified copyright information
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');
jimport('joomla.installer.helper');

class fooblaCoreModelConfig extends JModel
{
	function getInfoConfig()
	{
		global $option;

		$db = &JFactory::getDBO();
		$query = "
			SELECT `id`
			FROM `#__components`
			WHERE `link` = 'option=$option'
		";
		
		$db->setQuery($query);
		$id = $db->loadResult();
		$query = "
			SELECT *
			FROM `#__$option"."_config`
			WHERE `name` != 'check_firsttime'
		";
		$db->setQuery($query);
		$rows = $db->loadObjectList();
		
		$entities = array();
		foreach ($rows as $row)
			$entities[] = $row->name;
		
		$info 			= new stdClass();
		$info->entities	= $entities;
		$info->id		= $id;
		return $info;
	}
	
	/**
	 * Get Value from Name
	 *
	 * @param unknown_type $name
	 */
	function getConfigValue($name)
	{
		global $option;
		$db =& JFactory::getDBO();
		$query = "
			SELECT `value`
			FROM `#__$option"."_config`
			WHERE `name` = '$name'
		";
		$db->setQuery($query);
		$return = $db->loadResult();
		return $return;
	}
	
	/**
	 * Save Information Configuration
	 *
	 * @param unknown_type $info
	 * @return unknown
	 */
	function saveInfoConfig($info)
	{	
		global $mainframe, $option;
		$db 		= &JFactory::getDBO();
		$entities	= $info->entities;
		$id			= $info->id;
		// update jlord_core_config table
		foreach ($entities as $entity) {
			$cName 	= substr($entity, 5);
			if (($entity	=='show_cpanel')
			OR ($entity =='show_langs')
			OR ($entity =='show_tools')
			OR ($entity =='show_upgrade')
			OR ($entity =='show_addons')
			OR ($entity =='show_items')) {	
				// get id from jos_componets table
				$query = "
					SELECT `id` FROM `#__components` WHERE `admin_menu_link` ='option=$option&controller=$cName'
				";
				$db->setQuery($query);
				$entity_id 	= $db->loadResult();
				$query = "
					UPDATE `#__$option"."_config`
					SET `params` = 'option=$option&controller=$cName,$id,$entity_id'
					WHERE `name` = '$entity'
				";
				$db->setQuery($query);
				if(!$db->query()) return false;
			} else if ($entity == 'show_categories') {
				$query = "
					SELECT `id` FROM `#__components` WHERE `admin_menu_link` ='option=com_$cName&section=$option'
				";
				$db->setQuery($query);
				$entity_id 	= $db->loadResult();
				$query = "
					UPDATE `#__$option"."_config`
					SET `params` = 'option=com_$cName&section=$option,$id,$entity_id'
					WHERE `name` = '$entity'
				";
				$db->setQuery($query);
				if (!$db->query()) return false;
			}
		}
	}

	/**
	 * Check first time 
	 *
	 * @return boolean
	 */
	function check_firsttime()
	{
		$db 	= &JFactory::getDBO();
		$query 	= "
			SELECT `value`
			FROM `#__$option"."_config`
			WHERE `name` = 'check_firsttime'
		";
		$db->setQuery($query);
		$resval = $db->loadResult();
		if($resval)
		{
			return true;
		}
		return false;
	}
	
	function setCheck()
	{
		global $option;
		$db 	= &JFactory::getDBO();
		$query 	= "
			UPDATE `#__$option"."_config`
			SET		`value` = '1'
			WHERE  `name` 	= 'check_firsttime'
		";
		$db->setQuery($query);
		$db->query(); 
	}

	/**
	 * getDataConfig
	 *
	 */
	function saveDataConfig()
	{
		global $option;
		$db = &JFactory::getDBO();
		$entities = array();
		$entities['show_config'] 				= JRequest::getVar('show_config');
		$entities['show_cpanel']				= JRequest::getVar('show_cpanel');
		$entities['show_langs'] 				= JRequest::getVar('show_langs');
		$entities['show_tools'] 				= JRequest::getVar('show_tools');
		$entities['show_items'] 				= JRequest::getVar('show_items');
		$entities['show_upgrade'] 				= JRequest::getVar('show_upgrade');
		$entities['show_categories'] 			= JRequest::getVar('show_categories');
		$entities['show_addons'] 				= JRequest::getVar('show_addons');
		$entities['show_cpanel_info'] 			= JRequest::getVar('show_cpanel_info');
		$entities['show_cpanel_latestfaqs'] 	= JRequest::getVar('show_cpanel_latestfaqs');
		$entities['show_cpanel_addons'] 		= JRequest::getVar('show_cpanel_addons');
		$entities['show_cpanel_latestitems']	= JRequest::getVar('show_cpanel_latestitems');
		
		$tmps['show_config'] 					= 'show_config';
		$tmps['show_cpanel']					= 'show_cpanel';
		$tmps['show_langs'] 				  	= 'show_langs';
		$tmps['show_tools'] 					= 'show_tools';
		$tmps['show_items'] 					= 'show_items';
		$tmps['show_upgrade'] 					= 'show_upgrade';
		$tmps['show_categories'] 				= 'show_categories';
		$tmps['show_addons'] 					= 'show_addons';
		$tmps['show_cpanel_info'] 				= 'show_cpanel_info';
		$tmps['show_cpanel_latestfaqs'] 		= 'show_cpanel_latestfaqs';
		$tmps['show_cpanel_addons'] 			= 'show_cpanel_addons';
		$tmps['show_cpanel_latestitems']	 	= 'show_cpanel_latestitems';
		foreach ($tmps as $tmp) {
			$query = "
				UPDATE `#__$option"."_config`
				SET 	`value` = '".$entities[$tmp]."'
				WHERE 	`name` 	= '".$tmp."'
			";	
			$db->setQuery($query);
			$db->query();
		}
	}
	
	/**
	 * 
	 */
	function saveConfig()
	{	
		global $mainframe, $option;
		$db 	= &JFactory::getDBO();
		$query 	= "
			SELECT * FROM `#__$option"."_config`
			WHERE `name` != 'check_firsttime'
		";
		$db->setQuery($query);
		$resvals = $db->loadObjectList();
		foreach ($resvals as $resval) {	
			if (($resval->name =='show_cpanel')
			OR ($resval->name =='show_langs')
			OR ($resval->name =='show_tools')
			OR ($resval->name =='show_upgrade')
			OR ($resval->name =='show_addons')
			OR ($resval->name =='show_items')
			OR ($resval->name == 'show_categories')) {
				$param 	= $resval->params;
				$arr	= explode(',',$param);
				if ($resval->value) {

					$query = "
						UPDATE `#__components`
						SET `enabled` 			= 1,
						 	`admin_menu_link` 	= '".$arr[0]."'
						WHERE `id`				= '".$arr[2]."' 
					";
					$db->setQuery($query);
					$db->query();
				} else {
					$query = "
						UPDATE `#__components`
						SET `enabled` 			= 0,
						 	`admin_menu_link` 	= ''
						WHERE `id`				= '".$arr[2]."' 
					";
					$db->setQuery($query);
					$db->query();
				}
			}
		}
	}
	
	function saveLicense()
	{
		global $option;
		$license = JRequest::getVar('license');
		$db =& JFactory::getDBO();
		$query = "
			UPDATE `#__$option"."_config`
			SET `value` = '$license'
			WHERE `name` = 'license'
		";
		$db->setQuery($query);
		$db->query();
	}
} // end class
?>
