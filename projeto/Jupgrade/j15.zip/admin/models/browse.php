<?php
/**
* @package		Joomla Updater Creator
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.0.1
*/
	
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');
class FooblaCoreModelBrowse extends JModel
{
	function getShowData(){
		global $mainframe;
		$option = JRequest::getVar('option');
		$db 	= JFactory::getDBO();
		$task 	= JRequest::getVar('task');
		$filter_order		= $mainframe->getUserStateFromRequest( $option.'filter_order', 		'filter_order', 	'i.ordering',	'cmd' );
		$filter_order_Dir	= $mainframe->getUserStateFromRequest( $option.'filter_order_Dir',	'filter_order_Dir',	'',				'word' );
		$search 			= $mainframe->getUserStateFromRequest( $option.'search', 			'search', 			'',				'string' );
		$search 			= JString::strtolower( $search );
		$limit				= $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart			= $mainframe->getUserStateFromRequest($option.'.limitstart', 'limitstart', 0, 'int');
		$typeExt 		= $mainframe->getUserStateFromRequest( $option.'typeExt', 		'typeExt', 	''	,				'string' );
		$filter_commercial	= $mainframe->getUserStateFromRequest( $option.'filter_commercial',	'filter_commercial',	'',			'string' );

		$rows 	= $this->getShowDataClient();
		$total 	= (int) $rows->pageNav->total;
		jimport('joomla.html.pagination');
		$pageNav 	= new JPagination( $total, $limitstart, $limit );
		
		// select type
		$lists['type'] = $this->typeExt($typeExt);

		// select commercial
		$selected	= '';
		$selected_C = '';
		$selected_N = '';
		if ($filter_commercial == 'C'){
			$selected_C = 'selected="selected"';
		}else if ($filter_commercial == 'N'){
			$selected_N = 'selected="selected"';
		}else if ($filter_commercial == ''){
			$selected = 'selected="selected"';
		}
		$lists['commercial']= '<select id="filter_commercial" name="filter_commercial" class="inputbox" onchange="document.adminForm.submit( );">
				<option '.$selected.' value="">All</option>
				<option '.$selected_C.' value="C">Commercial</option>
				<option '.$selected_N.' value="N">Non-Commercial</option>
			</select>';
		// some other list
		$lists['search'] 	= $search;
		$lists['order_Dir']	= $filter_order_Dir;
		$lists['order']		= $filter_order;
		$rows 		= $this->getShowDataClient();
		$row_client = $rows->rows->rows;
		$res 				= new stdClass();
		$res->rows 			= $row_client;
		$res->lists 		= $lists;
		$res->pageNav 		= $pageNav; 
		return $res;
	}
	//get type of extension
	// com|mod|plugin|lang|esp|tool|patch
	function  typeExt($val) {
		$type[]	= JHTML::_('select.option', 'All', JText::_('- Select Type -'));
		$type[]	= JHTML::_('select.option', 'com', JText::_('Component'));
		$type[]	= JHTML::_('select.option', 'mod', JText::_('Module'));
		$type[]	= JHTML::_('select.option', 'plugin', JText::_('Plugin'));
		$type[]	= JHTML::_('select.option', 'lang', JText::_('Language'));
		$type[]	= JHTML::_('select.option', 'esp', JText::_('Ext. Specific Addon'));
		$type[]	= JHTML::_('select.option', 'tool', JText::_('Tool'));
		$type[]	= JHTML::_('select.option', 'patch', JText::_('Patch'));
		return 	JHTML::_('select.genericlist', $type, 'typeExt', 'class="inputbox" onchange="submitform();"', 'value', 'text', $val);
	}
	
	function getShowDataClient(){		
		global $mainframe,$option;
		$limit				= $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart			= $mainframe->getUserStateFromRequest($option.'.limitstart', 'limitstart', 0, 'int');
		$typeExt			= $mainframe->getUserStateFromRequest( $option.'typeExt', 		'typeExt', 	''	,				'string' );
		$filter_commercial	= $mainframe->getUserStateFromRequest( $option.'filter_commercial',	'filter_commercial',	'',			'string' );
		$filter_order		= $mainframe->getUserStateFromRequest( $option.'filter_order', 		'filter_order', 	'i.ordering',	'cmd' );
		$filter_order_Dir	= $mainframe->getUserStateFromRequest( $option.'filter_order_Dir',	'filter_order_Dir',	'',				'word' );
		$search 			= $mainframe->getUserStateFromRequest( $option.'search', 			'search', 			'',				'string' );
		$search 			= JString::strtolower( $search );
		
		$http 	 = 'http://'.$this->getServer().'/';				
		$url	 = $http.'index2.php?option=com_joomlaupdater_server&view=browse&task=getlib&limitstart='.$limitstart.'&limit='.$limit;
		$url	.= $typeExt? '&typeExt='.$typeExt: '';		
		$url	.= $filter_commercial? '&filter_commercial='.$filter_commercial: '';	
		$url	.= $filter_order? '&filter_order='.$filter_order: '';		
		$url	.= $filter_order_Dir? '&filter_order_Dir='.$filter_order_Dir: '';		
		$url	.= $search? '&search='.$search: '';
		
		$xmlstr	= @file_get_contents($url);		
		$res	= @simplexml_load_string($xmlstr);		
		return $res;
	}
	
	function getLibVersion () {
		$cid	= JRequest::getVar( 'cid', array(0), '', 'array' );
		JArrayHelper::toInteger($cid, array(0));
		
		$http 	 = 'http://'.$this->getServer().'/';
		$url	 = $http.'index2.php?option=com_joomlaupdater_server';
		$url	.= '&view=browse&task=getLibVer&lid='.$cid[0];
		//echo '<br>url: '.$url;		
		$xmlstr	= @file_get_contents($url);
		$res	= @simplexml_load_string($xmlstr);
		//echo '<pre>';print_r($res);echo '</pre>';
		return $res;
	}
	
	function getServer(){
		$sever = JUInstaller::getServer();
		return $sever;
	}
	
	public function getLibStatus($lib_obj,$lib_code){		
		$lib_type 	= $lib_obj->type;
		$lib_code 	= $lib_obj->ext_name;
		//echo '<pre>';print_r($lib_obj);echo '</pre>';
		$folder 	= $lib_obj->plg_group;
		$db 		= &JFactory::getDBO();
		#$query_from = '`#__components`';
		$query = "";
		switch ($lib_type) {
			case 'mod':
				#TODO: check module da cai dat hay chua bang cach kiem tra folde co ten = ten moduel cod ton tai hay khong
				$version = "";
				$mod_xmlpath = JPATH_ADMINISTRATOR.DS."modules".DS.'mod_'.$lib_code.DS.'mod_'.$lib_code.".xml";
				if(is_file($mod_xmlpath)){
					$version = $this->getVersionFromXMLInstallFile($mod_xmlpath);
				}else{
					$mod_xmlpath = JPATH_SITE.DS."modules".DS.'mod_'.$lib_code.DS.'mod_'.$lib_code.".xml";
					//echo '<br>'.$mod_xmlpath;					
					if(is_file($mod_xmlpath)){
						//echo '[ true ]';
						$version = $this->getVersionFromXMLInstallFile($mod_xmlpath);
					}
				}
				return array('ext_name'=>$lib_code,'version'=>$version);
				#TODO: kiem tra version da cai dat giong voi kiem tra version cua component;
			break;
			
			case 'plugin':
				#TODO: kiem tra plugin da cai dat hay chua bang cach search truong element trong bang lugin.
				$query = "
					select 
						`element`, 
						`folder` 
					from 
						`#__plugins` 
					where `element` = '$lib_code' and `folder`='$folder'
					limit 1;
				";
					//echo '<br>'.$query;
				$db->setQuery($query);
				$res = $db->loadObject();
				if(!$res){
					return false;
				}else{
					#TODO: kiem tra version hien tai bang cach docj file xml giong voi component
					$xml_path 	= JPATH_SITE.DS.'plugins'.DS.$folder.DS.$lib_code.'.xml';
					$version 	= $this->getVersionFromXMLInstallFile($xml_path);
					//print_r(array('ext_name'=>$lib_code,'version'=>$version));
					return array('ext_name'=>$lib_code,'version'=>$version);
				}
			break;
			
			case 'com':
				$query = "
					select
						`option` 
					from 
						`#__components` c
					where c.`option` = '$lib_code' or c.`option` = 'com_$lib_code' 
						limit 1;
				";
//				echo $query.__LINE__;
				$db->setQuery($query);
				$res = $db->loadObject();
//				print_r($res);
				if (!$res) {
					return false;
				}
				# get version installed
				$option			= $res->option;
				$version 		= "";
				$xmlinstall 	= "";
				
				jimport('joomla.filesystem.folder');
				$path = JPATH_ADMINISTRATOR.DS."components".DS.$option;
				$files = JFolder::files($path, '.xml', false, true);
				for($i = 0; $i < count($files);$i++ ){
					$version = $this->getVersionFromXMLInstallFile($files[$i]);
					if($version) break;
				}
//				echo $version;
				return array('ext_name'=>$option,'version'=>$version);
			break;
		}
		return false;
	}
	
	private function getVersionFromXMLInstallFile($path) {	
		global $option;
		$xml = & JFactory::getXMLParser('Simple');
		if (!$xml->loadFile($path)) {
			unset($xml);
			return '';
		}
		
		if ( !is_object($xml->document) || ($xml->document->name() != 'install' && $xml->document->name() != 'mosinstall')) {
			unset($xml);
			return false;
		}
		$element = & $xml->document->version[0];
		$version = $element ? $element->data() : '';
//		echo $version;
		return $version;		
	}
}
?>