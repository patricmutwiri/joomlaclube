<?php
/**
* @package		Joomla Updater Creator
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.6
*/
	
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.application.component.model');
class FooblaCoreModelJupgrade extends JModel
{
	private $_cversion = null;
	private $_lversion = null;
	private $_link_down = "";
	public $_url = "http://joomlacode.org/svn/joomla/development/releases/1.5/libraries/joomla/version.php";
	 
	public function getCVersion(){
		if(!$this->_cversion){
			$this->_cversion = JUCommon::getJCurVer();
		}
		return $this->_cversion;
	}
	public function getLVersion(){		
		if(!$this->_lversion){
			$this->_lversion = $this->getLastVersionFile();
		}
		return $this->_lversion;
	}
	
	private function getLastVersionFile(){
		global $option;
		$username	="anonymous";
		$password	= "";		
		//$url 		= "http://joomlacode.org/svn/joomla/development/releases/1.5/libraries/joomla/version.php";
		$url = "http://".$username.":".$password."@joomlacode.org/svn/joomla/development/releases/1.5/libraries/joomla/version.php";		
		$context 	= stream_context_create(array('http'=>array('header'=>"Authorization:Basic".base64_encode("$username:$password"))));
		$data = @file_get_contents($url, false, $context);
		if(!$data){echo 'ERROR: A';return false;}
		$wdata = str_replace("JVersion", "LastJVersion", $data);
		$lversionfile = JPATH_ADMINISTRATOR.DS."components".DS.$option.DS."helpers".DS."lastversion.php";
		file_put_contents( $lversionfile, $wdata );
		require_once $lversionfile;
		if(!class_exists('LastJVersion')){echo 'ERROR: B';return false;}
		$ljversion = new LastJVersion();
		return $ljversion->getShortVersion();
	}
	
	public function getLink($cversion,$lversion){
		global $option;
		include_once JPATH_ADMINISTRATOR.DS."components".DS.$option.DS."helpers".DS."joomlaupgrade.php";
		$jupgrade = new FooblaJoomlaUpgrade($cversion,$lversion);
//		exit("AAA");
		$links = $jupgrade->getLink();
		if($links){
			return $links[0];
		}
		return "";
	}
	
	public function getPack($url_download){
		jimport("joomla.installer.helper");
		$res = JInstallerHelper::downloadPackage($url_download);
		return $res;
	}
	
	public function extractPack($pack_path){
		global $option,$mainframe;
		jimport("joomla.installer.helper");
		jimport("joomla.filesystem.folder");
		jimport("joomla.filesystem.file");
		require_once JPATH_SITE.DS."libraries".DS."joomla".DS."filesystem".DS."archive".DS."zip.php";
		$tmp_dest = $mainframe->getCfg('tmp_path');
		$tmpdir = uniqid('jupgarde_');
		$extractdir = JPath::clean(dirname($tmp_dest.DS.$pack_path).DS.$tmpdir);
		if(!JFolder::create($extractdir)){
			return '';
		}
		$archivename = JPath::clean($tmp_dest.DS.$pack_path);
		
		$zip = new JArchiveZip();
		if($zip->extract($archivename,$extractdir)){
			return $extractdir;	
		} else {
			return $extractdir;
		}
	}
	public function upgradeJBase($extractdir) { //exit('DONE');
		$res = new stdClass();		
		if(JFolder::copy($extractdir,JPATH_SITE,'',true)){
			$res->error	= 0;
			$res->msg	= "Upgraded successful! Your Joomla is now up-to-date!";			
		}else{ 
			$res->error	= 1;
			$res->msg	= "Fail, Please set permission write on site";
		}
		JFolder::delete($extractdir);
		return $res;
	}	
	public function createBackUp($extractdir,$bakname) {
		$files = JFolder::files($extractdir,'.',true,true);
		$bakfiles = array();
		$updateList = '';
		$newList	= '';
		$lengExtDir	= strlen($extractdir);
		$lengRoot	= strlen(JPATH_SITE);
		$noUpgrade	= 0;
		for ($i = 0; $i < count($files); $i++) {
			$bfile = JPath::clean(JPATH_SITE.DS.substr($files[$i],$lengExtDir));
			$writable = '<img border="0" width="16" height="16" src="components/com_obupdater/assets/images/saccess.png" alt="Writable" title="Writable">';
			$msg	= '';	
			if(is_file($bfile)){
				$bakfiles[] = $bfile;				
				if(!is_writable($bfile)){
					//$setmod 	= chmod($bfile, 755);var_dump($setmod);
					//if(!$setmod){
						$noUpgrade++;
						$perm	= fileperms($bfile);
						$chmod	= substr(sprintf('%o',$perm), -4);						
						$writable	= '<img border="0" width="16" height="16" alt="Unwritable" src="images/publish_x.png">';
						$msg	= '<b style="color:#ff1100;">[ Unwritable ][ Perms: '.$chmod.' ]</b>'; 																	
					//}
				}				
				$updateList .= "<li>".$writable.substr($bfile,$lengRoot)." $msg</li>\n";
			}else {
				if(!$this->checkWrite($bfile)){
					$noUpgrade++;
					$writable	= '<img border="0" width="16" height="16" alt="Unwritable" src="images/publish_x.png">';
					$msg	= '<b style="color:#ff1100;">[ Unwritable ]</b>';
				}
				$newList.= "<li>$writable ".substr($bfile,$lengRoot)." $msg</li>\n";
			}
		}
		$log	= "<h3>Modified files list: </h3><ol>$updateList</ol>\n";
		$log	.= "<h3>New Files list: </h3>".($newList?"<ol>$newList</ol>":'[<i> None </i>]')."</ol>";			
		if(!$noUpgrade){
			$path_zipbak= JUC_BACKUP.'joomla_core'.DS.'zipbak'.DS.$bakname.'.zip';			
			JUCommon::createIndexHtml($path_zipbak);
			require_once JUC_HELPER.'ziplib'.DS.'zip.class.php';
			jimport("joomla.filesystem.archive.zip");
			$zip	= new Archive_Zip($path_zipbak);
			$backup_create	=  $zip->create( $bakfiles, array( 'add_path' => '', 'remove_path' => JPATH_SITE) );
			$backupLink	= substr($path_zipbak,($lengRoot+15));
			$log	.= "<br /><br /><b>Backup:</b> <a href=\"$backupLink\">$backupLink</a> ";						
		}else {
			JFolder::delete($extractdir);
			$msg	= "Error: Unwritable, Please set writable for all, then start Upgrade again ![ $noUpgrade file(s) ]";
			$log	.= "<br /><br /><span style=\"border2px solid #ff1100;color:#ff1100;font-weight:bold;\">$msg</span>";
		}
		@file_put_contents(JUC_BACKUP.'joomla_core'.DS.$bakname.'.html',$log);//FILE_APPEND		
		$finish = '<input type="hidden" name="jupgr-finish" id="jupgr-finish" value="'.($noUpgrade?'1':'0').'"/>';
		return $log.$finish;
	}
	function checkWrite($file){
		if(!JFile::write($file,'<?php echo "ju-write"; ?>'))return false;		
		return true;
	}
	function restore(){
		$baks	= $this->getBakList();
		if(!$baks) return false;
		$lastBak	= $baks[(count($baks)-1)];
		$info	= $this->getInfoKey($lastBak);
		if(!$info) return false;
		$JCVer	= JUCommon::getJCurVer();
		if($JCVer!=$info->newVer) return false;		
		$path_zipbak	= JUC_BACKUP.'joomla_core'.DS.'zipbak'.DS.$lastBak.'.zip';
		if(!is_file($path_zipbak))return false;
		$dest = JPATH_ROOT.DS.'tmp'.DS.$lastBak.'.zip';
		if(!JFile::copy($path_zipbak, $dest)){
			return false; 
		}
		$extractdir = $this->extractPack($lastBak.'.zip');
		$restore	= $this->upgradeJBase($extractdir);
		if($restore->error)return false;		
		JFile::delete($dest);
		return true;
	}	
	function getBakList($ext = 'joomla_core'){
		$path	= JUC_BACKUP.$ext;
		if(!is_dir($path))return false;
		$files	= JFolder::files($path, '.html', false, true);	
		if(count($files)<1) return false;
		$cut	= strlen($path);
		foreach ($files as $file) {
			$fs[]=substr($file,($cut+1),-5);
		}
		return $fs;
	}
	function getInfoKey($key){
		$res	= new stdClass();			
		$info	= explode('_',$key);
		if(count($info)!=5) return false;			
		$date	= explode('.',$info[0]);
		if(count($date)!=3) return false;				
		$time	= explode('.',$info[1]);
		if(count($time)!=2) return false;
		$res->date = "$date[0]-$date[1]-$date[2]";				
		$res->time = "$time[0]:$time[1]";
		$res->oldVer	= $info[2];
		$res->newVer	= $info[4];		
		return $res;
	}
	function getBackups(){
		$ext	= JRequest::getCmd('ext','joomla_core');		
		$fs	= $this->getBakList($ext);
		if(!$fs) return false;
		$extList	= JFolder::folders(JUC_BACKUP);
		//echo '<pre>';print_r($extList);echo '</pre>';
		$items	= array();
		$max	= count($fs)-1;		 
		for($i = $max; $i >=0 ;$i-- ){
			$info	= $this->getInfoKey($fs[$i]);
			if(!$info) continue;
			if($i == $max){
				$cuVerNew = $info->newVer;
			}
			$item	= new stdClass();
			$item->key	= $fs[$i];			
			$item->info	= "$info->date $info->time [ $info->oldVer to $info->newVer ]";
			$items[]	= $item;
		}
		$reStore	= '';
		if($max>-1){
			$key	= JRequest::getVar('f',$fs[$max]);
			if($key==$fs[$max]){
				if($ext=='joomla_core'){
					$JCVer	= JUCommon::getJCurVer();
					if($JCVer==$cuVerNew){
						$reStore = 'jupgrade';
					}
				}else {
					$reStore = "browse&ext=$ext";
				}
			}
			$bakInfo	= $this->getBakInfo($ext,$key);
		}else{
			$bakInfo = '';
			$key	= '';
		}		
		$res	= new stdClass();
		$res->ext	= $ext;
		$res->extlist	= $extList;
		$res->items	= $items;				
		$res->key	= $key;
		$res->info	= $bakInfo;
		$res->reStore	= $reStore;
		return $res;
	}
	function getBakInfo($ext='joomla_core',$key){
		if(!$key) return '';
		$file	= JUC_BACKUP.$ext.DS.$key.'.html';
		if(!is_file($file)) return '';
		$info	= file_get_contents($file);
		return $info;	
	}
}