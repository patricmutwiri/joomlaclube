<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');

class fooblaCoreModelCpanel extends JModel
{
	function getLatestItem(){
		$db 	= JFactory::getDBO();
		$query 	= "SELECT * FROM #__jlord_items ORDER BY created LIMIT 0,10";
		$db->setQuery($query);
		$rows 	= $db->loadObjectList();
		return $rows; 
	}
}
?>