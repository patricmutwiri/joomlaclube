<?php
/*------------------------------------------------------------------------
# Component com_joomlaupdater_server
# Version: 1.5.1
# Creation Date: 2010.01.22
# Copyright (C) 2010 foobla.com. All rights reserved
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Author: foobla.com
# Author Email: info@foobla.com
# Websites:  http://www.foobla.com
-------------------------------------------------------------------------*/
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.plugin.plugin');
class plgSystemObJuc extends JPlugin {
	function plgSystemObJuc(&$subject) {
		parent::__construct($subject);
	}	
	function onAfterRoute() {
		$pathCom	= JPATH_ADMINISTRATOR.DS.'components'.DS.'com_obupdater'.DS;
		$pathPlug	= $pathCom.'helpers'.DS.'plugins'.DS.'system.php';
		if(is_file($pathPlug)){
			require_once $pathPlug;
			JUC_Plugin_system::run();			
		}
	}
}
