<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.view');

class FooblaCoreViewBrowse extends JView
{
	function display($tpl = null) {
		global $option;
		JHTML::stylesheet( 'jlord_core.css', 'administrator'.DS.'components'.DS.$option.DS.'assets'.DS );		
		$model 	= $this->getModel("browse");
		$task	= JRequest::getVar('task');
		if ($task == 'detail') {
			JToolBarHelper::title(JText::_('Extension').' <small><small>[ Detailt ]</small></small>', 'template.png');
			$res	= $model->getLibVersion();
			JToolbarHelper::cancel();
		} elseif ($task == 'update') {
			JToolBarHelper::title(JText::_('Extension').' <small><small>[ Update ]</small></small>', 'template.png');			
			JToolbarHelper::cancel();			
		} else {
			JToolBarHelper::title(JText::_('Extension'), 'template.png');
			$res 	= $this->get('ShowData');
		}
		$this->assignRef('res',$res);
		JUCommon::getToolBarDefault();
		parent::display($tpl);
	}
} // end class
?>
