<?php
/**
* @package		jLord Core
* @author 		Thong Tran - The Joomlord Team.
* @copyright	Copyright (C) 2008 The Joomlord Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		form.php 1.5.0.1	20081119.1635	thongta
* 20081120.1635	thongta	- modified copyright information
*/

global $mainframe;
$controller = JRequest::getVar('controller');
$row		= $this->res;
//echo '<pre>';print_r($row);echo '</pre>';
$server		= 'http://'.JUInstaller::getServer().'/';  
$path_img	= JURI::base().'components'.DS.$option.DS.'assets'.DS.'images'.DS.'icons';
?>
<script>
function submitbutton(pressbutton){
	if(pressbutton=='cancel')pressbutton='goextension';
	if(goCtrl(pressbutton)) return false;	
}
</script>
<style>.ext-img img{margin-right:3px;}</style>
<form enctype="multipart/form-data" action="index.php?option=<?php echo $option;?>" method="POST" name="adminForm" id="adminForm">
		<table cellspacing="0" cellpadding="0" border="0" width="100%">
			<tr>
				<td valign="top" width="50%">
					<fieldset class="adminForm">
					<legend>Details</legend>
					<table class="admintable">
					<?php if (count($row)) {?>
						<tr>
							<td width="80" align="right" class="key">Product name:</td>
							<td>
								<?php echo $row->name;?>
							</td>
						</tr>
						<tr>
							<td width="80" align="right" class="key">Product code:</td>
							<td><?php echo $row->code;?></td>
						</tr>
						<tr>
							<td width="80" align="right" class="key">Type</td>
							<td nowrap="nowrap">
								<?php echo '<span class="ext-img">'.JUCommon::getExtImg($row->lib_type).'</span>';?>
							</td>		
						</tr>	
						<tr>
							<td width="80" align="right" class="key">Last version</td>
							<td><?php echo $row->last_version;?></td>
						</tr>
						<tr>
							<td width="80" align="right" class="key">Image:</td>
							<td><?php echo '<img src="'.$server.$row->lib_image.'" alt="'.$server.$row->lib_image.'"/>'; ?>
							</td>
						</tr>						
						<tr>
							<td width="80" align="right" class="key">Description:</td>
							<td><?php echo $row->description;?></td>
						</tr>						
						<?php }?>
					</table>
					</fieldset>	
				</td>
				<td valign="top">
					<fieldset class="adminForm">
					<legend>List versions</legend>
					<table class="adminlist">
						<thead>
							<tr>
								<th class="key" width="1%">#</th>
								<th class="key" width="25%">Install Package</th>								
								<th class="key" width="1%">version</th>
								<th class="key" width="1%">Commercial</th>								
								<th class="key" width="15%">Action</th>								
							</tr>
						</thead>
						<tbody>
							<?php 
						$k = 0;$i = 0;
						$vers = $row->versions->children();						
						if ($vers) {
							//echo '<pre>';print_r($vers);echo '</pre>';							
							$url = 'index.php?option=com_obupdater&controller=browse';
							foreach ($vers as $obj) {
								$actUrl		= $url.'&lid='.$row->id.'&ver='.$obj->version.'&ex_type='.$obj->type;
								$action		= '<a href="'.$actUrl.'&task=juinstall"><span style="padding:0px 5px;">Install</span></a>';
								$action 	.= $obj->patch_pk=='yes'?'/<a href="'.$actUrl.'&task=juupgrade"><span style="padding:0px 5px;">Upgrade</span></a>':'';
								$model 		= $this->getModel();
								$status 	= $model->getLibStatus($obj, $obj->ext_name);
								$maction = array('task'=>"juinstall",'title'=>"Install");
								if($status && $status['version']){
									$vcp = version_compare($obj->version,$status['version']);
									if($vcp==0){
										$vfolder = $obj->plg_group?"&folder=$obj->plg_group":"";
										$maction = array('task'=>"juuninstall&type=".$obj->type."&lib_code=".$obj->ext_name.$vfolder,'title'=>"UnInstall");
									}elseif($vcp=="1"){
										if($obj->patch_pk=='yes'){
											//$maction = array('task'=>"juupgrade",'title'=>"Upgrade");//
											$maction = array('task'=>"update",'title'=>"Update");//											
										}else {
											$maction = array('task'=>"",'title'=>"None Pacth");
										}
									} else {
										$maction = array('task'=>"",'title'=>"Old Version");
									}
								}
							?>
							<tr class="<?php echo "row$k";?>">
								<td align="right"><?php echo ++$i;?></td>
								<td><?php echo $obj->install_pk;?></td>
								<td align="center"><?php echo $obj->version;?></td>
								<td align="center"><?php echo ($obj->commercial == 1) ? "Yes" : "No";?></td>
								<td align="center">
								<?php if($maction['task']!=''){
									if($maction['task']=='update'){
										?><a href="<?=$url.'&task='.$maction['task'].'&type='.$obj->type.'&code='.$obj->ext_name.'&tover='.$obj->version ?>" title="<?= $maction['title'] ?>"><?= $maction['title'] ?></a><?php
									}else {
										?><a href="<?=$actUrl.'&task='.$maction['task'] ?>" title="<?= $maction['title'] ?>"><?= $maction['title'] ?></a><?php	
									}
								}else echo '<i>'.$maction['title'].'</i>';?>
								</td>
							</tr>
							<?php $k = 1 - $k;
							}
						}else { ?>
							<tr>
								<td colspan="5"><center><i>None Data</i></center></td>								
							</tr>
						<?php }?>
						</tbody>
					</table>
					</fieldset>	
				</td>
			</tr>
		</table>	
	<input type="hidden" name="controller" value="<?php echo $controller; ?>">	
	<input type="hidden" name="task" value="">
</form>