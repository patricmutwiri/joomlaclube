<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
$pane =& JPane::getInstance('Tabs');
echo $pane->startPane('JoomlaUpdaterClient');
{
	echo $pane->startPanel('Components', 'panelComponent');
		getComsInstalled();
	echo $pane->endPanel();
	
	echo $pane->startPanel('Modules', 'panelModule');		
		getModsInstalled();
	echo $pane->endPanel();
	
	echo $pane->startPanel('Plugins', 'panelPlugin');		
		getPlugsInstalled();	
	echo $pane->endPanel();
	
/*	echo $pane->startPanel('Languages', 'panelLanguages');	
		//getModInstalled();
		echo 'Languages';
	echo $pane->endPanel();
	
		echo $pane->startPanel('Templates', 'panelTemplate');
		//getModInstalled();
		echo 'Templates';
	echo $pane->endPanel();	*/		
}
echo $pane->endPane();	

function getPlugsInstalled(){
	$items	= JUCommon::getExtList();	
	echo '<table class="adminlist">';
	echo '<thead>
			<tr>
				<th class="title" width="1%">#</th>
				<th class="title" width="20%">Name</th>
				<th class="title" width="1%">Forder</th>
				<th class="title" width="1%">Group</th>
				<th class="title" width="1%">Version</th>		
			</tr>
		</thead>';
	$k= 0;
	$js = '';
	for($i=0;$i<count($items);$i++){
		$item	= $items[$i];
		$js	.= "clt_plug[$i]='".$item->folder.'|'.$item->element."';";
		$lnkConfig	= 'index.php?option=com_plugins&view=plugin&client=site&task=edit&cid[]=';		
		echo "<tr class=\"row$k\">
			<td align=\"right\">".($i+1)."</td>
			<td><a href=\"$lnkConfig$item->id\">$item->name</a></td>
			<td>$item->element</td>
			<td>$item->folder</td>	
			<td align=\"right\" nowrap=\"nowrap\"><span  id=\"plug_$i\">&nbsp;</span></td>
			</tr>";
		$k=1-$k;
	}	
	echo '</table>';
	echo "<script> //<![CDATA[\n var clt_plug = new Array(),plug_loaded = false;$js \n//]]></script>";
}
function getModsInstalled(){
	$mods	= JUCommon::getExtList('mod');	
	echo '<table class="adminlist">';
	echo '<thead>
			<tr>
				<th class="title" width="1%">#</th>
				<th class="title" width="20%">Name</th>
				<th class="title" width="10%">Module</th>
				<th class="title" width="1%">Client</th>
				<th class="title" width="1%">Version</th>								
			</tr>
		</thead>';
	$k	= 0;
	$js	= '';
	for($i=0;$i<count($mods);$i++){
		$mod = $mods[$i];
		$js		.= "clt_mod[$i]='".substr($mod->module,4)."';";
		$lnkConfig	= 'index.php?option=com_modules&client=0&task=edit&cid[]=';
		echo "<tr class=\"row$k\">
			<td align=\"right\">".($i+1)."</td>
			<td><a href=\"$lnkConfig$mod->id\">$mod->title</a></td>
			<td>$mod->module</td>
			<td align=\"right\">".($mod->client_id=='1'?'Admin':'Cient')."</td>				
			<td align=\"right\" nowrap=\"nowrap\"><span  id=\"mod_$i\">&nbsp;</span></td>
			</tr>";
		$k=1-$k;
	}
	echo '</table>';
	echo "<script> //<![CDATA[\n var clt_mod = new Array(),mod_loaded = false;$js \n//]]></script>";
}
function getComsInstalled(){
	$coms	= JUCommon::getExtList('com');
	echo '<table class="adminlist">
		<thead>
			<tr>
				<th class="title" width="1%">#</th>
				<th class="title" width="20%">Name</th>
				<th class="title" width="20%">Option</th>
				<th class="title" width="1%">Version</th>	
			</tr>
		</thead>';
	$k= 0;$js='';	
	for($i=0;$i<count($coms);$i++){
		$com	= $coms[$i];
		$js		.= "clt_com[$i]='".substr($com->option,4)."';";
		echo "<tr class=\"row$k\">
			<td align=\"right\">".($i+1)."</td>
			<td><a href=\"index.php?option=$com->option\">$com->name</a></td>
			<td>$com->option</td>			
			<td align=\"right\" nowrap=\"nowrap\"><span  id=\"com_$i\">&nbsp;</span></td>			
			</tr>";
		$k=1-$k;
	}
	echo '</table>';
	echo "<script> //<![CDATA[\n var clt_com = new Array();$js \n//]]></script>";
}