<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
?>
	Cronjob	info		
