<?php 
/**
* @package		Joomla Updater Creator
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.6
*/
// no direct access 
defined('_JEXEC') or die('Restricted Access');
?>
<script type="text/javascript">
	function jucGid(id){return document.getElementById(id);}
	function makeNewRes(msg){
		var divMsg = document.createElement("div");
		divMsg.style.padding = '5px';
		divMsg.innerHTML = msg;
		jucGid('main-upgrade').appendChild(divMsg);
		return divMsg; 				
	}
	var jucUpgr = 'index.php?option=com_obupdater&controller=jupgrade&tmpl=component&task=';	
	function checkJUpgr(){
		var url = jucUpgr+'checkjupgr';
		var req = new Ajax(url,{
			onComplete: function(res){
				jucGid('juc-upgr-msg').innerHTML = res;				
			}
		}).request();
	}	
	function getJPatchLink(){
		var actUgr = jucGid('juc-act');
		actUgr.innerHTML = ' <b style="color:#ff9900;">Upgarding ...</b> ';
		divMsg = makeNewRes('<b>Search Patch package:</b> [ <i>Searching ... </i>]');
		var url = jucUpgr+'getlink';
		var req = new Ajax(url,{
			onComplete: function(res){
				divMsg.innerHTML = res;
				if(jUpgrFinish()){
					actUgr.innerHTML = ' <b style="color:#ff3300;">Upgarde fail</b> ';
					return;
				}
				getPatchPackage();
			}
		}).request();
	}
	function getPatchPackage(){
		divMsg = makeNewRes('<b>Get Patch package:</b> [ <i>Downloading ... </i>]');
		var url = jucUpgr+'getpack';
		var req = new Ajax(url,{
			onComplete: function(res){
				divMsg.innerHTML = res;				
				dojbackup();
			}
		}).request();
	}
	function dojbackup(){		
		divMsg = makeNewRes('<b>Analysis and  Backup:</b> [ <i>doing ... </i> ]');
		var url = jucUpgr+'jbackup';
		var req = new Ajax(url,{
			onComplete: function(res){
				divMsg.innerHTML = res;
				if(jUpgrFinish()){
					jucGid('juc-act').innerHTML = ' <b style="color:#ff3300;">Upgarde fail</b> ';
					return;
				}				
				doUpgrade();
			}
		}).request();		

	}
	function jUpgrFinish(){
		var finish = jucGid('jupgr-finish');
		var res = finish.value=='0'?false:true;
		finish.parentNode.removeChild(finish);
		return res;
	}	
	function doUpgrade(){
		divMsg = makeNewRes('<b>Upgrade:</b> [ <i>Doing ... </i> ]');
		var url = jucUpgr+'doupgrade';
		var req = new Ajax(url,{
			onComplete: function(res){
				divMsg.innerHTML = res;
				checkJUpgr();
			}
		}).request();
	}
	window.addEvent('domready',function(){		
		checkJUpgr();		
	});
	function submitbutton(pressbutton){
		if(goCtrl(pressbutton)) return false;
		submitform( pressbutton );
		return;
	}
</script>
<div id="main-upgrade">
<div id="juc-upgr-msg"><i>Checking...</i></div>
</div>
<form id="adminForm" name="adminForm" method="POST" action="index.php?option=com_obupdater&controller=jupgrade">
	<input type="hidden" value="" name="task" />
</form>