<?php
/**
* @package		jLord Core
* @author 		Thong Tran - The Joomlord Team.
* @copyright	Copyright (C) 2008 The Joomlord Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		default.php 1.5.0.1	20081119.1635	thongta
* 20081120.1635	thongta	- modified copyright information
*/

// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');

JHTML::_('behavior.mootools');
?>
<script type="text/javascript">
<!--
	window.addEvent('domready', function()
      {
          $('hide_product').addEvent('click', function(e) 
          {
               document.getElementById('show_cpanel_latestfaqs0').checked = 'checked';
               document.getElementById('show_cpanel_info0').checked = 'checked';
               document.getElementById('show_config0').checked = 'checked';
               return;
          });
          
          $('show_product').addEvent('click', function(e) 
          { 
          	   document.getElementById('show_cpanel_latestfaqs1').checked = 'checked';
               document.getElementById('show_cpanel_info1').checked = 'checked';
               document.getElementById('show_config1').checked = 'checked';
               return;
          });
          
          $('show_all').addEvent('click', function(e) 
          { 
          	
          	   document.getElementById('show_config1').checked = 'checked';
          	   document.getElementById('show_cpanel1').checked = 'checked';
          	   document.getElementById('show_langs1').checked = 'checked';
          	   document.getElementById('show_items1').checked = 'checked';
          	   document.getElementById('show_tools1').checked = 'checked';
          	   document.getElementById('show_upgrade1').checked = 'checked';
          	   document.getElementById('show_categories1').checked = 'checked';
          	   document.getElementById('show_addons1').checked = 'checked';
          	   document.getElementById('show_cpanel_info1').checked = 'checked';
          	   document.getElementById('show_cpanel_latestfaqs1').checked = 'checked';
               document.getElementById('show_cpanel_latestitems1').checked = 'checked';
               document.getElementById('show_cpanel_addons1').checked = 'checked';
               return;
          });
          
          $('show_items0').addEvent('click', function(e) 
          {
               document.getElementById('show_cpanel_latestitems0').checked = 'checked';
               return;
          });
          
           $('show_addons0').addEvent('click', function(e) 
	      {
	           document.getElementById('show_cpanel_addons0').checked = 'checked';
	           return;
	      });
	      
	      $('show_cpanel_latestitems1').addEvent('click', function(e) 
          {
               document.getElementById('show_items1').checked = 'checked';
               return;
          });
          
          $('show_cpanel_addons1').addEvent('click', function(e) 
	      {
	           document.getElementById('show_addons1').checked = 'checked';
	           return;
	      });
      });
//-->
</script>
<form action="index.php?option=<?php echo $option; ?>" method="post" name="adminForm">

<?php
$pane =& JPane::getInstance('Tabs');
echo $pane->startPane('jLordCorePane');
{
	/* License */
	echo $pane->startPanel('License', 'panelLicense');
	?>
	<div class="adminform">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'License' ); ?></legend>
		<table class="admintable" width="100%">
			<tr>
				<td width="40%" class="key"><?php echo JText::_('Product License Key'); ?></td>
				<td width="60%">
					<input type="text" name="license" value="<?php echo $this->license; ?>" size="50" />
				</td>
			</tr>
		</table>
	</fieldset>
	</div>
	<div style="clear: both"></div>
	<?php
	echo $pane->endPanel();
}
echo $pane->endPane();
?>
<input type="hidden" name="controller" value="config"/>
<input type="hidden" name="task" value="saveConfig" />
</form>