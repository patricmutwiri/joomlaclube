<?php
/**
* @package		jLord Core
* @author 		Thong Tran - The Joomlord Team.
* @copyright	Copyright (C) 2008 The Joomlord Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		view.html.php 1.5.0.1	20081119.1635	thongta
* 20081120.1635	thongta	- modified copyright information
*/

// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.view');
jimport('joomla.html.pane');

class FOOBLACOREViewConfig extends JView
{
	function display($tpl = null)
	{
		global $option;
		JHTML::stylesheet( 'jlord_core.css', 'administrator'.DS.'components'.DS.$option.DS.'assets'.DS );
		JToolBarHelper::title( JText::_('Joomla Updater - Config'), 'icon-48-config.png' );
		JToolBarHelper::save('saveConfig');
		//JToolBarHelper::preferences('com_jlord_core', 500, 700, 'Settings', 'administrator'.DS.'components'.DS.$option.DS.'elements'.DS.'core.config.xml');
		//JToolBarHelper::help('about', true);
		$model = $this->getModel('config');
		$this->assign('license', $model->getConfigValue('license'));
		
		// display
		JUCommon::getToolBar();
		parent::display($tpl);
	}
} // end class
?>