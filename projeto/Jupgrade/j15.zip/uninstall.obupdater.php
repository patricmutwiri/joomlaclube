<?php
/**
* @package		Joomla Updater
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.0.1
*/
	
defined('_JEXEC') or die( 'Restricted access' );

	//$db = &JFactory::getDBO();
	# 1. Get current component name
	$com_name	= substr(strrchr(dirname(__FILE__), DS),1);
/*	$dir_path 		= dirname(__FILE__);
	$com_name 		= substr($dir_path,strrpos($dir_path,DS)+1);
	// 1. DROP TABLE jlord_phplist_config
	$query 	= "DROP TABLE IF EXISTS `#__$com_name"."_config`;";
	$db->setQuery($query);
	$db->query();*/
	
// 1. uninstall plugin System - JUC
	obUninstallPlugin('objuc','system');
	function obUninstallPlugin($element,$folder){
		$db = &JFactory::getDBO();
		$dest = JPATH_SITE.DS.'plugins'.DS.$folder.DS.$element;
		if (file_exists($dest.'.php')) {JFile::delete($dest.'.php');}
		if (file_exists($dest.'.xml')) {JFile::delete($dest.'.xml');}
		$query = "DELETE FROM `#__plugins` WHERE `element` = '$element' AND `folder`='$folder'";	
		$db->setQuery($query);
		if(!$db->query()){echo $db->getErrorMsg();}
	}
?>
<h3>Uninstall component <?php echo $com_name?> successfull</h3>