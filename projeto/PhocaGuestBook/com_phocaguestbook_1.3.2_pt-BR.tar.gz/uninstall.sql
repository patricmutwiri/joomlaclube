-- --------------------------------------------------------
--
-- Table structure for table `#__phocaguestbook_items`
DROP TABLE IF EXISTS `#__phocaguestbook_items`;
-- --------------------------------------------------------

-- --------------------------------------------------------
-- Table structure for table `#__phocaguestbook_books`
--
DROP TABLE IF EXISTS `#__phocaguestbook_books`;
-- --------------------------------------------------------