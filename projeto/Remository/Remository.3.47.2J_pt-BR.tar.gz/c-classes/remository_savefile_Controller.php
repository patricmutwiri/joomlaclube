<?php

/**************************************************************
* This file is part of Remository
* Copyright (c) 2006 Martin Brampton
* Issued as open source under GNU/GPL
* For support and other information, visit http://remository.com
* To contact Martin Brampton, write to martin@remository.com
*
* Remository started life as the psx-dude script by psx-dude@psx-dude.net
* It was enhanced by Matt Smith up to version 2.10
* Since then development has been primarily by Martin Brampton,
* with contributions from other people gratefully accepted
*/

class remository_savefile_Controller extends remositoryUserControllers {

	public function savefile ($func) {
		//Process the variables
		if (_SUBMIT_FILE_BUTTON != $_POST['submit']) remositoryInterface::getInstance()->redirect($this->repository->RemositoryBasicFunctionURL('select'));
		$oldid = remositoryRepository::getParam($_POST, 'oldid', 0);
		$container = new remositoryContainer(remositoryRepository::getParam($_POST, 'containerid', 0));
		if (0 == $container->id) remositoryInterface::getInstance()->redirect('index.php?option=com_remository');
		$this->remUser->allowUploadCheck($container);
		if ($this->remUser->hasAutoApprove($container)) {
		    $newfile = new remositoryFile();
		    if ($oldid) {
				$newfile->id = $oldid;
				$newfile->getValues($this->remUser);
				if (!$newfile->updatePermitted($this->remUser)) {
					$this->error_popup (_DOWN_NOT_AUTH);
					return;
				}
				$oldphysical = $newfile->obtainPhysical();
			}
		    $newfile->published = '1';
		}
		else {
			$newfile = new remositoryTempFile();
			if ($oldid) {
				$oldfile = new remositoryFile();
				$oldfile->id = $oldid;
				$oldfile->getValues($this->remUser);
				if (!$oldfile->updatePermitted($this->remUser)) {
					$this->error_popup (_DOWN_NOT_AUTH);
					return;
				}
				$newfile->setValues($oldfile);
				$newfile->isblob = $newfile->plaintext = $newfile->published = 0;
			}
		}
		$newfile->addPostData();
		$authors = remositoryFile::getPopularAuthors();
		$fileauthor = $newfile->fileauthor;
		$newfile->fileauthor = '';
		foreach ($authors as $author) if ($fileauthor == preg_replace('/[^a-zA-Z0-9]/', '-', $author)) {
			$newfile->fileauthor = $author;
			break;
		}
		if (!$newfile->fileauthor) $newfile->fileauthor = remositoryRepository::getParam($_POST, 'otherauthor');
		$newfile->validate(false);
		$newfile->memoContainer($container);
		if (!$newfile->submittedby OR !$this->remUser->isAdmin()) $newfile->submittedby = $this->remUser->id;
		if (eregi(_REMOSITORY_REGEXP_URL,$newfile->url) OR eregi(_REMOSITORY_REGEXP_IP,$newfile->url)) {
		  	if ($newfile->filetitle == '') $newfile->filetitle = $newfile->lastPart($newfile->url,'/');
		  	$newfile->metatype = 1;
			$newfile->saveFile();
			$upload = null;
			$logentry = new remositoryLogEntry(_LOG_UPLOAD, $this->remUser->id, $newfile->id, 0);
			$logentry->insertEntry();
		}
		else {
			$upload = new remositoryPhysicalFile();
			$upload->handleUpload();
			if ($oldid AND $upload->error_message == _ERR1) {
				// If true, must be auto-approve
				if (isset($oldphysical)) {
					if (!$oldphysical->moveTo($newfile->filepath.$newfile->realname, $newfile->id, $newfile->isblob, $newfile->plaintext, true)) $this->error_popup(_DOWN_MOVE_FILE_FAILED);
					$newfile->realwithid = 1;
				}
				$newfile->metatype = 2;
				$newfile->saveFile();
				$upload = null;
			}
			// In this case, a file should have been received - error condition
			elseif ($upload->error_message) {
				$upload = null;
				$this->noFileDiagnostics();
				return;
			}
			// This is the case of having a new file upload
			else {
				if ($newfile instanceof remositoryTempFile) $newfile->metatype = 1;
				if (isset($oldphysical)) $oldphysical->delete();
				if ($newfile->storePhysicalFile($upload) AND $newfile->published) {
					$logentry = new remositoryLogEntry(_LOG_UPLOAD, $this->remUser->id, $newfile->id, $newfile->filesize);
					$logentry->insertEntry();
				}
				$physical = $newfile->obtainPhysical();
				$this->savethumb($newfile, $physical);
			}
		}
		$classifications = remositoryRepository::getParam($_POST, 'classification', array());
		if (!empty($classifications)) $newfile->classifyFile($classifications);
		$this->repository->resetCounts(array());
		$thumbs = new remositoryThumbnails($newfile);
		if ($freecount = $thumbs->getFreeCount()) {
			for ($i = 1; $i <= $freecount; $i++) {
				if (!empty($_FILES['userfile'.(string)$i]['tmp_name'])) {
					$thumbnail = new remositoryPhysicalFile();
					$thumbnail->handleUpload((string) $i);
					$thumbs->addImage($thumbnail, $newfile->id);
				}
			}
		}

		//Send Admin notice
		if ($this->repository->Send_Sub_Mail) $this->repository->sendAdminMail($this->remUser->fullname.' ('.$this->remUser->name.')', $newfile->filetitle, $newfile->containerid, $newfile->published);
		require_once ($this->admin->v_classes_path.'remositoryAddFileDoneHTML.php');
		$uploadhandlers = remositoryInterface::getInstance()->triggerMambots('remositoryUploadSaved', array($newfile));
		if (array_sum($uploadhandlers)) return;
		$view = new remositoryAddFileDoneHTML($this);
		$view->addFileDoneHTML ($newfile);
	}

	private function savethumb ($file, $upload) {
		$graphics = array('png','gif','jpg');
		$repository = remositoryRepository::getInstance();
		if ($repository->Make_Auto_Thumbnail AND in_array($file->filetype, $graphics)) {
			$thumbnails = new remositoryThumbnails($file);
			if ($thumbnails->getFreeCount()) {
				$thumbnails->addImage($upload, $file->id, '', true);
			}
		}
	}
	
	private function noFileDiagnostics () {
		$heading = _DOWN_NO_FILE_RECEIVED;
		$error = isset($_FILES['userfile']['error']) ? $_FILES['userfile']['error'] : 'No error message';
		$filename = isset($_FILES['userfile']['name']) ? $_FILES['userfile']['name'] : 'No file name provided';
		$filesize = isset($_FILES['userfile']['size']) ? $_FILES['userfile']['size'] : 'No file size provided';
		$tempfile = isset($_FILES['userfile']['tmp_name']) ? $_FILES['userfile']['tmp_name'] : 'No file path provided';
		$isuploaded = isset($_FILES['userfile']['tmp_name']) ? is_uploaded_file($tempfile) : 'No file path provided';
		if ($this->remUser->isAdmin()) echo <<<DIAGNOSE_UPLOAD
		
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<th colspan="2" align="left">
					$heading
				</th>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td width="30%" align="right">
					<strong>Error message: </strong>
				</td>
				<td>
					$error
				</td>
			</tr>
			<tr>
				<td width="30%" align="right">
					<strong>Real file name: </strong>
				</td>
				<td>
					$filename
				</td>
			</tr>
			<tr>
				<td width="30%" align="right">
					<strong>File size (bytes): </strong>
				</td>
				<td>
					$filesize
				</td>
			</tr>
			<tr>
				<td width="30%" align="right">
					<strong>Temporary file path: </strong>
				</td>
				<td>
					$tempfile
				</td>
			</tr>
			<tr>
				<td width="30%" align="right">
					<strong>Is it an uploaded file?: </strong>
				</td>
				<td>
					$isuploaded
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td width="30%" align="right">
					<strong>PHP file_uploads: </strong>
				</td>
				<td>
					{$this->showPHP('file_uploads')}
				</td>
			</tr>
			<tr>
				<td width="30%" align="right">
					<strong>PHP upload_tmp_dir: </strong>
				</td>
				<td>
					{$this->showPHP('upload_tmp_dir')}
				</td>
			</tr>
			<tr>
				<td width="30%" align="right">
					<strong>PHP upload_max_filesize: </strong>
				</td>
				<td>
					{$this->showPHP('upload_max_filesize')}
				</td>
			</tr>
			<tr>
				<td width="30%" align="right">
					<strong>PHP post_max_size: </strong>
				</td>
				<td>
					{$this->showPHP('post_max_size')}
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td colspan="2" align="left">
					<p>Points to watch out for are: <ul>
					<li>There should be no error message (typically, zero will be displayed)</li>
					<li>The real file name should correspond with the name of the file you sent</li>
					<li>The file size should be the correct size for the file you sent</li>
					<li>Temporary file path should look like a genuine specification for a file on the host system.  Its
					precise character will vary across different systems.  It should be a valid path including the name of
					the temporary file. If it is not overriden by the PHP config (see below) the temporary path will be
					the system temporary directory with file name added. The file name is generated by the system.</li>
					<li>If PHP is permitting file uploads, the file_uploads setting will be non zero.</li>
					<li>There may be no temporary upload directory specified in the PHP config.
					In this case, the system temporary directory will be used.
					For a Unix style system, this defaults to /tmp but can be configured to be
					anything. If the file path is specified, you would expect it to form part of the temporary file
					path shown above, followed by the temporary name.  A temporary upload directory specified to PHP will
					override the system temporary directory.</li>
					<li>PHP will have a setting for the maximum permitted uploaded file size.</li>
					<li>PHP also has a setting for the maximmum POST size, and the file upload is a POST
					so the setting must be at least a little larger than the maximum permitted upload
					size, or it will be a constraint on uploads.</li>
					</ul><br/>
					Note that the PHP settings cannot be overriden by a program like Remository.  If they
					are too restrictive, you need to talk to your hosting provider, or consider altering
					your PHP configuration if it is under your own control.
					</p>
				</td>
			</tr>
		</table>
	
DIAGNOSE_UPLOAD;
		
		else echo <<<SIMPLE_ERROR
		
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<th colspan="2" align="left">
					$heading
				</th>
			</tr>
		</table>
		
SIMPLE_ERROR;

	}
	
	private function showPHP ($inivalue) {
		return ini_get($inivalue);
	}
}
