<?php
/**
 * Core Design Access Text plugin for Joomla! 1.5
 * @author		Daniel Rataj, <info@greatjoomla.com>
 * @package		Joomla
 * @subpackage	Content
 * @category   	Plugin
 * @version		1.0.2
 * @copyright	Copyright (C)  2007 - 2009 Core Design, http://www.greatjoomla.com
 *@license     http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Import library dependencies
jimport('joomla.plugin.plugin');
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');
// end

class plgContentCdAccessText extends JPlugin
{

	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param object $params  The object that holds the plugin parameters
	 * @since 1.5
	 */
	function plgContentCdAccessText(&$subject)
	{
		parent::__construct($subject);

		// load plugin parameters
		$this->plugin = &JPluginHelper::getPlugin('content', 'cdaccesstext');
		$this->params = new JParameter($this->plugin->params);
	}

	/**
	 * Call the prepare function
	 *
	 * Method is called by the view
	 *
	 * @param 	object		The article object.  Note $article->text is also available
	 * @param 	object		The article params
	 * @param 	int			The 'page' number
	 */
	function onPrepareContent(&$article, &$params, $limitstart=0)
	{

		// define the regular expression for the bot
		$regex = "#{accesstext(?:\s?(.*?)?)?}(.*?){/accesstext}#is";

		// Explication:
		// $match[1]	-> match to the next processing
		// $match[2]	-> html text for authorized user

		if (!preg_match($regex, $article->text)) {
			return;
		}

		$document = &JFactory::getDocument(); // set document for next usage
		$live_path = JURI::root(true) . '/';

		// attach CSS style
		$document->addStyleSheet($live_path . 'plugins/content/cdaccesstext/css/cdaccesstext.css', 'text/css');

		// replacement {accesstext...} {/accesstext}
		$article->text = preg_replace_callback($regex, array($this, 'replacer'), $article->text);
	}

	/**
	 * Replacer
	 */

	function replacer(&$match)
	{
		global $mainframe;

		$user = &JFactory::getUser();

		$user_name = $user->username;
		$user_id = (int)$user->id;
		$usertype = strtolower($user->usertype);

		// mode
		$set_mode = $this->params->get('set_mode', 'user');
		
		// disable for super administrator and administrator accounts 
		$disable = ( $this->params->get('disable', 'yes') == 'yes' ? true : false );
		$disable = $this->disableDefault($disable);

		if (isset($match[1]))
		{
			$set = $match[1];
		} else
		{
			return;
		}

		$get_html = ( isset($match[2]) ? trim($match[2]) : '' );
		$get_html = explode('||', $get_html);

		switch(sizeof($get_html)) {
			case 2:
				$get_noaccess = ( isset($get_html) ? $get_html[0] : '' ); // set no-access message
				$get_html = ( isset($get_html) ? $get_html[1] : '' ); // set "secret" message
				break;
			default:
				$get_noaccess = '';
				$get_html = ( isset($get_html) ? $get_html[0] : '' ); // set "secret" message
				break;
		}

		// set mode
		if (preg_match('#mode\s?=\s?"(user|level|facl)"#', $set, $get_mode))
		{

			$get_mode = ( isset($get_mode) ? $get_mode[1] : $set_mode );

		} else
		{
			$get_mode = $set_mode;
		}
		// end

		// load language
		JPlugin::loadLanguage('plg_content_cdaccesstext', JPATH_ADMINISTRATOR);

		// set $message to empty
		$message = '';

		switch ($get_mode)
		{
			case 'user':

				// set users
				if (preg_match('#user\s?=\s?"(.+?)"#', $set, $get_user))
				{
					$get_user = ( isset($get_user) ? $get_user[1] : '' );
				} else
				{
					JError::raiseNotice('', JText::_('ACCESSTEXT_NO_USER'));
					return;
				}
				// end

				$get_user_array = explode(':', $get_user);
				
				if ($user_name and in_array($user_name, $get_user_array) or $disable)
				{
					$message = $get_html;
					unset($get_html, $get_user_array);
				} else
				{
					$message = $get_noaccess;
					unset($get_noaccess);
				}

				break;

			case 'level':

				// set level
				if (preg_match('#level\s?=\s?"(.+?)"#', $set, $get_level))
				{
					$get_level = ( isset($get_level) ? strtolower($get_level[1]) : '' );
				} else
				{
					JError::raiseNotice('', JText::_('ACCESSTEXT_NO_LEVEL'));
					return;
				}
					
				$get_level_array = explode(':', $get_level);
				
				if ($usertype and in_array($usertype, $get_level_array) or $disable)
				{
					$message = $get_html;
					unset($get_html, $get_level_array);
				} else
				{
					$message = $get_noaccess;
					unset($get_noaccess);
				}

				break;
			case 'facl':

				if(!$this->faclInstalled()) {
					JError::raiseNotice('', JText::_('ACCESSTEXT_FACL_NOT_INSTALLED'));
					return;
				}
				
				if (!$this->faclPublished()) {
					JError::raiseNotice('', JText::_('ACCESSTEXT_FACL_NOT_PUBLISHED'));
					return;
				}

				// find group
				if (preg_match('#group\s?=\s?"(.+?)"#', $set, $get_group))
				{
					$get_group = ( isset($get_group) ? strtolower($get_group[1]) : '' );
				} else
				{
					JError::raiseNotice('', JText::_('ACCESSTEXT_NO_FACL_GROUP'));
					return;
				}
				
				$get_group_array = explode(':', $get_group);
				
				// retrieve session groupname based on File ACL plugin, array
				$facl_group_array = JFacl::groupName();
				
				$arr = array_intersect($facl_group_array, $get_group_array);

				if ($arr or $disable) {
					$message = $get_html;
					unset($get_html, $get_level_array);
				} else
				{
					$message = $get_noaccess;
					unset($get_noaccess);
				}

				break;
			default:
				return;
				break;
		}

		return $message;
	}

	/*
	 * Disable plugin for super administrator and administrator accounts
	 */
	function disableDefault($disable = true) {
		 
		$user = &JFactory::getUser();
		$usertype = strtolower($user->usertype);
		if ($usertype == 'super administrator' || $usertype == 'administrator') {
			if ($disable) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	/**
	 * Check if File ACL plugin is installed
	 */
	function faclInstalled() {

		$db = &JFactory::getDBO();

		$is_facl = 'SELECT `id` FROM `#__plugins` WHERE `element` LIKE \'cdfacl\' LIMIT 0, 1 ';
		$db->setQuery($is_facl);

		if (!$db->query()) {
			JError::raiseError(500, $db->stderr());
			return false;
		}

		$is_facl = (int)$db->loadResult();

		if ($is_facl and $is_facl > 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check if File ACL plugin is published
	 */
	function faclPublished() {
		jimport('joomla.plugin.helper');
		return JPluginHelper::isEnabled('system', 'cdfacl');
	}

}

?>
