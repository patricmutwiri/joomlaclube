<?php


// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

require_once ( dirname(__FILE__).DS.'ReadMoreExt'.DS.'autolinks.php' );


class plgContentReadMoreExt extends JPlugin
{

	function plgContentReadMoreExt( &$subject, $params )
	{
		parent::__construct( $subject, $params );
	}

	function onBeforeDisplayContent( &$article, &$params )
	{
		$option=JRequest :: getCmd('option');
		$onlyForComContent=$this->param('Only_For_Com_Content');
		if( $onlyForComContent&&($option!= 'com_content')){
			return ;
		}
		$view=JRequest :: getCmd('view');
		if($view=='article'){
			return ;
		}

		$ignore=$this->exclude('Exclude_Section_Ids',$article->sectionid);
		if($ignore){ return; }
		$ignore=$this->exclude('Exclude_Category_Ids',$article->catid);
		if($ignore){ return; }
		$ignore =$this->exclude('Exclude_Article_Ids',$article->id);
		if($ignore){ return; }
		$imgTitlePrefix=$this->param('ImgTitlePrefix');
		$imgAltPrefix=$this->param('ImgAltPrefix');
		$onlyFirstImage=$this->param('Only_For_First_Image');		
		$autolinks=new AutoLinks($imgTitlePrefix,$imgAltPrefix,$onlyFirstImage);		
		$article->text=$autolinks->handleImgLinks($article->text,$article->title,$article->readmore_link);


	}
	function param($name){
		static $plugin,$pluginParams;
		if (!isset( $plugin )){
			$plugin =& JPluginHelper::getPlugin('content', 'ReadMoreExt');
			$pluginParams = new JParameter( $plugin->params );
		}
		return $pluginParams->get($name);
	}
	function exclude($paramName,$value){
		$excludeIds=$this->param($paramName);
		$excludeIdsArray=explode(',',$excludeIds);
		if(empty($excludeIdsArray)){
			return 0;
		}
		if(!$value){
			return 0;
		}
		if(in_array($value,$excludeIdsArray,false)){
			return 1;
		}
		return 0;
	}

}
//end class

