<?php
/**
 * @version $Id: plgContentMultiAds.php 1.5
 * @copyright Joe Guo
 * @license GNU/GPLv2,
 * @author Joe Guo - http://www.ctoptravel.com
 */
defined( '_JEXEC' ) or  die('Restricted access');
jimport( 'joomla.event.plugin' );
jimport( 'joomla.environment.browser' );

class plgContentArticleSuggestions extends JPlugin{

    function plgContentArticleSuggestions( &$subject, $params ){
        parent::__construct( $subject, $params );
    }
    function onPrepareContent( &$article, &$params ){
        if((JRequest::getVar('view')) != 'article'){
            return true;
        }

		JPlugin::loadLanguage('plg_content_articlesuggestions', JPATH_ADMINISTRATOR);

        $db =& JFactory::getDBO();
        $user =& JFactory::getUser();
        $date =& JFactory::getDate();

        $authorCount=$this->param('author_count');
        $relatedCount=$this->param('related_count');
        $minChars=$this->param('min_chars');
        $showAuthorArticles=$this->param('show_author_articles');
        $showRelatedArticles=$this->param('show_related_articles');
        $showIntro=$this->param('show_intro');
        $charCount=$this->param('char_count');
        $showAvtar=$this->param('show_avtar');
        $showSection=$this->param('show_section');
        $showCategory=$this->param('show_category');
        $showHits=$this->param('show_hits');
        $excludes=$this->param('excludes');
        $incl_excl=intval($this->param('incl_excl'));
        $sec_cat_ids=trim($this->param('sec_cat_ids'));
        if(!$sec_cat_ids){
        	$sec_cat_ids = ',^,';
        }

				$relatedArticles=array();
				$authorArticles=array();
				$nullDate=$db->getNullDate();
				$now=$date->toMySQL();

        $where = '';
        if(preg_match('/^[0-9\^\,]*$/', $sec_cat_ids)){
            $sec_cats = explode("^",$sec_cat_ids);
            $sections = substr($sec_cats[0], 1, strlen($sec_cats[0])-2);
            $categories = substr($sec_cats[1], 1, strlen($sec_cats[1])-2);
            $where = '';
            if(strlen($sections) > 0){
                $where = ' AND a.sectionid ' . (($incl_excl == '0')?'NOT':'') . ' IN (' . $sections . ')';
            }
            if(strlen($categories) > 0){
                $where = ' AND a.catid ' . (($incl_excl == '0')?'NOT':'') . ' IN (' . $categories . ')';
            }
        }

				if($showAuthorArticles && $authorCount){
						$query = 'SELECT a.id, a.alias, a.title, a.sectionid, a.hits,'.
								(($showIntro)?'a.introtext,':'') .
								' s.title AS section, a.catid, cc.access AS cat_access, s.access AS sec_access, cc.published AS cat_state,'.
								' s.published AS sec_state, cc.title AS category, u.username AS author,' .
								' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(":", a.id, a.alias) ELSE a.id END as slug,'.
								' CASE WHEN CHAR_LENGTH(cc.title) THEN CONCAT_WS(":", cc.id, cc.title) ELSE cc.id END as catslug'.
								' FROM #__content AS a' .
								' LEFT JOIN #__categories AS cc ON cc.id = a.catid' .
								' LEFT JOIN #__sections AS s ON s.id = a.sectionid' .
								' LEFT JOIN #__users AS u ON u.id = a.created_by' .
								' WHERE a.id != '.(int) $article->id .
								' AND a.state = 1' . $where .
								' AND a.created_by=' . $article->created_by .
								' AND a.access <= ' .(int) $user->get('aid', 0) .
								' AND ( a.publish_up = '.$db->Quote($nullDate).' OR a.publish_up <= '.$db->Quote($now).' )' .
								' AND ( a.publish_down = '.$db->Quote($nullDate).' OR a.publish_down >= '.$db->Quote($now).' )';
						$db->setQuery($query ,0 , $authorCount);
						$temp = $db->loadObjectList();
						if (count($temp)){
							foreach ($temp as $row){
								if (($row->cat_state == 1 || $row->cat_state == '') &&
											($row->sec_state == 1 || $row->sec_state == '') &&
											($row->cat_access <= $user->get('aid', 0) || $row->cat_access == '') &&
											($row->sec_access <= $user->get('aid', 0) || $row->sec_access == '')){
									$row->href = JRoute::_(ContentHelperRoute::getArticleRoute($row->slug, $row->catslug, $row->sectionid));
									if($showIntro){
										$row->introtext = $this->getIntroArticle($row->introtext,$charCount,'');
									}
									$authorArticles[] = $row;
								}
							}
						}
						unset ($temp);
				}

				if($showRelatedArticles && $relatedCount && $article->title){
					$keys = explode(' ', $article->title);
					$count = "0";
					foreach ($keys as $key){
						$key = trim($key);
						if(!stristr($excludes, '^'.$key.'^')){
							if (strlen($key)>=$minChars) {
								if($count === "0"){
									$keywords = 'CONCAT("^", REPLACE(a.title," ","^"),"^") LIKE "%^' . $db->getEscaped($key) . '^%"';
								}else{
									$keywords .= ' OR CONCAT("^", REPLACE(a.title," ","^"),"^") LIKE "%^' . $db->getEscaped($key) . '^%"';
								}
								$count++;
							}
						}
					}
					if (count($keywords)){
						$query = 'SELECT a.id, a.alias, a.title, a.sectionid, a.hits,'.
								(($showIntro)?'a.introtext,':'').
								' s.title AS section, a.catid, cc.access AS cat_access, s.access AS sec_access, cc.published AS cat_state,'.
								' s.published AS sec_state, cc.title AS category, u.username AS author, a.created_by,' .
								' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(":", a.id, a.alias) ELSE a.id END as slug,'.
								' CASE WHEN CHAR_LENGTH(cc.title) THEN CONCAT_WS(":", cc.id, cc.title) ELSE cc.id END as catslug'.
								' FROM #__content AS a' .
								' LEFT JOIN #__categories AS cc ON cc.id = a.catid' .
								' LEFT JOIN #__sections AS s ON s.id = a.sectionid' .
								' LEFT JOIN #__users AS u ON u.id = a.created_by' .
								' WHERE a.id != '.(int) $article->id .
								' AND a.state = 1' . $where .
								' AND a.access <= ' .(int) $user->get('aid', 0) .
								' AND ( '.$keywords.' )' .
								' AND ( a.publish_up = '.$db->Quote($nullDate).' OR a.publish_up <= '.$db->Quote($now).' )' .
								' AND ( a.publish_down = '.$db->Quote($nullDate).' OR a.publish_down >= '.$db->Quote($now).' )';

						$db->setQuery($query ,0 , $relatedCount);
						$temp = $db->loadObjectList();
						if (count($temp)){
							foreach ($temp as $row){
								if (($row->cat_state == 1 || $row->cat_state == '') &&
											($row->sec_state == 1 || $row->sec_state == '') &&
											($row->cat_access <= $user->get('aid', 0) || $row->cat_access == '') &&
											($row->sec_access <= $user->get('aid', 0) || $row->sec_access == '')){
									$row->href = JRoute::_(ContentHelperRoute::getArticleRoute($row->slug, $row->catslug, $row->sectionid));
									if($showIntro){
										$row->introtext = $this->getIntroArticle($row->introtext,$charCount);
									}
									$relatedArticles[] = $row;
								}
							}
						}
						unset ($temp);
					}
				}
				$document	= & JFactory::getDocument();
				$document->addStyleSheet(JURI::base(true).'/plugins/content/asuggestions/assets/css/styles.css');
				$html = '';

				if($showAuthorArticles && $authorArticles){
					$html.='<div class="asTitle">' . JText::_('TITLE_AUTHOR_ARTICLES') . ':</div>';
					$i=0;
					$html.='<div class="as-wrapper">';
					foreach($authorArticles as $item){
						$html .= (($i)?'<div class="as-content-odd">':'<div class="as-content-even">');
							$html.='<a href="' . $item->href . '" title="' . $item->title .'">' . $item->title . '</a>';
							if($showHits){
								$html.='<small style="color: #8C0A00;"> (' . $item->hits .  ' ' . JText::_('Hits') . ')</small>';
							}
							if($showSection || $showCategory){
								$html.='<br/>';
							}
							if($showSection){
								$html.=$item->section;
							}
							if($showSection && $showCategory && $item->section && $item->category){
								$html.= ' &gt; ';
							}
							if($showCategory){
								$html.=$item->category;
							}
							if($showIntro){
								$html.='<br>' . $item->introtext;
							}
						$html.='</div>';
						$i=1-$i;
					}
					$html.='</div>';
				}

				/** Related Articles **/
				if($showRelatedArticles && $relatedArticles){
					$html.='<div class="asTitle">' . JText::_('TITLE_RELATED_ARTICLES') . ':</div>';
					$i=0;
					$html.='<div class="as-wrapper">';
					foreach($relatedArticles as $item){
						$html .= (($i)?'<div class="as-content-odd">':'<div class="as-content-even">');
								$html.='<a href="' . $item->href . '" title="' . $item->title .'">' . $item->title . '</a>';
								if($showHits){
									$html.='<small style="color: #8C0A00;"> (' . $item->hits .  ' ' . JText::_('Hits') . ')</small>';
								}
								if($showAvtar){
									$html.='<div class="as-avatar">';
										$html.=$this->getAvatar($item->created_by,'jomsocial');
									$html.='</div>';
								}
								if($showSection || $showCategory && ($item->section || $item->category)){
									$html.='<div>';
								}
								if($showSection){
									$html.=$item->section;
								}
								if($showSection && $showCategory && $item->section && $item->category){
									$html.= ' &gt; ';
								}
								if($showCategory){
									$html.=$item->category;
								}
								if($showSection || $showCategory && ($item->section || $item->category)){
									$html.='</div>';
								}
								if($showIntro){
									$html.='<div>' . $item->introtext.'</div>';
								}
							$html.='</div>';
						$html.='<div class="as-clear"></div>';
						$i=1-$i;
					}
					$html.='</div>';
				}
        $article->text .= $html;
    }

    function getIntroArticle( $text, $length=150, $tags='' ) {
        $text = preg_replace( "'<script[^>]*>.*?</script>'si", "", $text );
        $text = preg_replace( '/{.+?}/', '', $text);
        $text = preg_replace( "'<(br[^/>]*?/|hr[^/>]*?/|/(div|h[1-6]|li|p|td))>'si", ' ', $text );
        $text = strip_tags($text);
        if ( strlen($text) > $length ) {
            $text = substr( $text, 0, $length );
            $blankpos = strrpos( $text, ' ' );
            $text = substr( $text, 0, $blankpos );
            $text .= "...";
        }
        return html_entity_decode( $text );
    }

	function param($name){
		static $plugin,$pluginParams;
		if (!isset( $plugin )){
			$plugin =& JPluginHelper::getPlugin('content', 'articlesuggestions');
			$pluginParams = new JParameter( $plugin->params );
		}
		return $pluginParams->get($name);
	}

	function getAvatar( $userid, $useAvatarFrom, $height='48' )
	{
		global $mainframe;
		$db	   =& JFactory::getDBO();
    $avatar = '';

		switch ( $useAvatarFrom ){
			case 'jomsocial':
        $jspath = JPATH_BASE.DS.'components'.DS.'com_community';
        include_once($jspath.DS.'libraries'.DS.'core.php');

        // Get CUser object
        $jsuser =& CFactory::getUser($userid);
        $avatarLoc = $jsuser->getThumbAvatar();
        $link = CRoute::_('index.php? option=com_community&view=profile&userid='.$userid);
        $username = $jsuser->username;
        $avatar = "<a href=\"$link\"><img class=\"hasTip\"
                    style=\"border: 1px solid #cccccc; height: {$height}px;\"
                    src=\"$avatarLoc\" alt=\"$username\"  title=\"$username\" /></a>";
				break;
			case 'cb':
        $strSQL = "SELECT `avatar`, firstname FROM #__comprofiler WHERE `user_id`='{$userid}' AND `avatarapproved`='1'";
        $db->setQuery($strSQL);
        $result = $db->loadObject();
        $link = JRoute::_( 'index.php?option=com_comprofiler&amp;task=userProfile&amp;user=' . $userid);
        if($result && !empty($result->avatar)) {
            $avatarLoc = JURI::base(true)."/images/comprofiler/".$result->avatar;
        } else {
            $avatarLoc = JURI::base(true)."/components/com_comprofiler/plugin/templates/default/images/avatar/nophoto_n.png";
        }
        $avatar = "<a href=\"" . $link . "\"><img src=\"" . $avatarLoc . "\"" .
            "class=\"hasTip\" style=\"border: 1px solid #cccccc; height: {$height}px;\"" .
            "alt=\"" . $result->firstname . "\" title=\"" . $result->firstname . "\"/></a>";
				break;
			default:
				$avatar = '';
		}
		return $avatar;
	}
}
?>
