<?php
/**
 * Extension Install File
 * Does the stuff for the specific extensions
 *
 * @package    Modules Anywhere
 * @version    1.2.0
 * @since      File available since Release v1.0.0
 *
 * @author     Peter van Westen <peter@nonumber.nl>
 * @link       http://www.nonumber.nl/modulesanywhere
 * @copyright  Copyright (C) 2009 NoNumber! All Rights Reserved
 * @license    http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$name = 'Modules Anywhere';
$alias = 'modulesanywhere';
$ext = $name.' (system plugin)';

// SYSTEM PLUGIN
	$states[] = installExtension( $alias, 'System - '.$name, 'plugin', array( 'folder'=>'system' ), $queries );

// EDITOR BUTTON PLUGIN
	$states[] = installExtension( $alias, 'Editor Button - '.$name, 'plugin', array( 'folder'=>'editors-xtd' ) );