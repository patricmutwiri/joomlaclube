--
-- Database query file
-- For manual installation
--
-- @package    Modules Anywhere
-- @version    1.2.0
-- @since      File available since Release v1.0.0
--
-- @author     Peter van Westen <peter@nonumber.nl>
-- @link       http://www.nonumber.nl/modulesanywhere
-- @copyright  Copyright (C) 2009 NoNumber! All Rights Reserved
-- @license    http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
--

--
-- NOTE: The queries assume you are using 'jos_' as the prefix.
--       Please change that if you are using another prefix.
--

--
-- Insert the system plugin record
--
INSERT INTO `jos_plugins` (`id`, `name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES
(NULL, 'System - Modules Anywhere', 'modulesanywhere', 'system', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', '');

--
-- Insert the editor button plugin record
--
INSERT INTO `jos_plugins` (`id`, `name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES
(NULL, 'Editor Button - Modules Anywhere', 'modulesanywhere', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', '');