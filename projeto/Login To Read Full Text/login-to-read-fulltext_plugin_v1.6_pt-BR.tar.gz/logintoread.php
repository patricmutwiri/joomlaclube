<?php
// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Example Content Plugin
 *
 * @package		Joomla
 * @subpackage	Content
 * @since 		1.5
 */
class plgContentLoginToRead extends JPlugin
{
	var $mystr;
	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param object $params  The object that holds the plugin parameters
	 * @since 1.5
	 */
	function plgContentLoginToRead( &$subject, $params )
	{
		parent::__construct( $subject, $params );
		$this->mystr='';
	}

	/**
	 * Example prepare content method
	 *
	 * Method is called by the view
	 *
	 * @param 	object		The article object.  Note $article->text is also available
	 * @param 	object		The article params
	 * @param 	int			The 'page' number
	 */
	function onPrepareContent( &$article, &$params, $limitstart )
	{
		global $mainframe;
		global $my, $database;
		JPlugin::loadLanguage( 'plg_content_logintoread', JPATH_BASE."/administrator/" );
		$catid = trim($this->params->get("catid"));
		$secid = trim($this->params->get("secid"));
		$nocat = intval($this->params->get("nocat",1));
		$link_text = trim($this->params->get("link_url_text"));
		if(!$link_text) $link_text = JText::_("Please login first to read fulltext!");
		$link_tit = trim($this->params->get("link_url_title"));
		if(!$link_tit) $link_tit = JText::_("Please register or login first to read this!");
		$user = & JFactory::getUser();
		$isspider = getbot();
		if($isspider) $logined = true;
		else $logined = ($user->get('guest')) ? false : true;
		
		$link_url = trim($this->params->get("link_url"));
		if(!$link_url) $link_url = "index.php?option=com_user&task=register";

		$catarray=explode(',',$catid);
		$secarray=explode(',',$secid);
		$cursec=intval($article->sectionid);
		$curcat=intval($article->catid);
		$text = $article->introtext.$article->fulltext;

		if(!$cursec && $nocat){
			$text = str_replace('\\"','"',$text);
			$pattern = '#<hr\s+id=("|\')system-readmore("|\')\s*\/*>#i';
			$tagPos	= preg_match($pattern, $text);
			if ($tagPos == 0)	{
				$article->introtext	= $text;
			} else 	{
				list($article->introtext, $article->fulltext) = preg_split($pattern, $text, 2);
			}
		}
		if( strlen(trim($text))>strlen(trim($article->introtext)) ){
			if	(
			( $cursec>'0'&&(( ($secid=='')&&($catid==''||in_array($curcat,$catarray)) ) || (in_array($cursec,$secarray) && ($catid==''||in_array($curcat,$catarray)))
			)
			)||($cursec=='0'&&$nocat))
			{
				if((!$logined)&& (strlen($text)>strlen($article->introtext)))
				{
					$params->_registry['_default']['data']->show_readmore=0;
					$params->_registry['_default']['data']->show_pdf_icon=0;
					$params->_registry['_default']['data']->show_print_icon=0;
					$this->mystr = "<a href=\"$link_url\" title=\"$link_tit\">$link_text</a>";
					$article->fulltext = '';
					$article->text = str_replace( "__CRLF__", "\n", $article->introtext ).$this->mystr;
				}
			}
		}

	}

	/**
	 * Example after display title method
	 *
	 * Method is called by the view and the results are imploded and displayed in a placeholder
	 *
	 * @param 	object		The article object.  Note $article->text is also available
	 * @param 	object		The article params
	 * @param 	int			The 'page' number
	 * @return	string
	 */
	function onAfterDisplayTitle( &$article, &$params, $limitstart )
	{
		global $mainframe;

		return '';
	}

	/**
	 * Example before display content method
	 *
	 * Method is called by the view and the results are imploded and displayed in a placeholder
	 *
	 * @param 	object		The article object.  Note $article->text is also available
	 * @param 	object		The article params
	 * @param 	int			The 'page' number
	 * @return	string
	 */
	function onBeforeDisplayContent( &$article, &$params, $limitstart )
	{
		global $mainframe;

		return '';
	}

	/**
	 * Example after display content method
	 *
	 * Method is called by the view and the results are imploded and displayed in a placeholder
	 *
	 * @param 	object		The article object.  Note $article->text is also available
	 * @param 	object		The article params
	 * @param 	int			The 'page' number
	 * @return	string
	 */
	function onAfterDisplayContent( &$article, &$params, $limitstart )
	{
		global $mainframe;
		return '';
		//return $this->mystr;
	}
}
	function getbot(){
		$useragent = strtolower($_SERVER['HTTP_USER_AGENT']);
		$knowspider = "google|msnbot|slurp|baiduspider|sohu-search|sogou-test-spider|sogou web spider|lycos|robozilla|gigabot|yodaobot|sosospider|qihoobot@qihoo.net|libwww-perl|webalta|twiceler";
		$knowspider = explode("|",$knowspider);
		foreach($knowspider as $v){
			if (strpos($useragent, $v) !== false){
				return true;
			}
		}
//		echo $useragent;
		return false;
	}
