<?php
/**
* @version $Id:  mod_vivi_code.php, V1.0.0  2006-09-01 $
* @module Joomla
* @copyright (C) 2006 vivigrosseto.it
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

/* **************************************************** */
/* Vivi Code Module, version 1.0        */
/* **************************************************** */

/* Any problems, feature requests etc. write here:     */
/* http://www.vivigrosseto.it/   */
/* By Serra Antonio (tonio@vivigrosseto.it) 			   */

// no direct access
defined('_JEXEC') or die('Restricted access');

$module_code 			= $params->def( 'code', '' );
$module_height 			= $params->def( 'height', '' );
$module_width 			= $params->def( 'width', '' );
$moduleclass_sfx 			= $params->def( 'moduleclass_sfx', '' );
?>
<div align="right" style="
<?php if(!empty($module_height)) echo "height:".$module_height."px;";?>
<?php if(!empty($module_width)) echo "width:".$module_width."px;";?>
">
<?php
$or_string="<br />";
$permissed_tags="<script>";
//$module_code=strip_tags($module_code, $permissed_tags);
//$module_code=preg_replace($or_string, '', $module_code);
$module_code=str_replace($or_string, '', $module_code);
echo $module_code;
?>
</div>
