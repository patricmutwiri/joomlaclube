<?php
?><html><style> 

.google_translate img {
filter:alpha(opacity=100);
-moz-opacity: 1.0;
opacity: 1.0;
border:0;
}
.google_translate:hover img {
filter:alpha(opacity=30);
-moz-opacity: 0.30;
opacity: 0.30;
border:0;
}
.google_translatextra:hover img {
filter:alpha(opacity=0.30);
-moz-opacity: 0.30;
opacity: 0.30;
border:0;
}
</style> 

<div> 

<center><a class="google_translate" href="#" target="_blank" rel="nofollow" title="Ingl�s" onclick="window.open('http://translate.google.com/translate?u='+encodeURIComponent(location.href)+'&langpair=id%7Cen&hl=en'); return false;"><img alt="English" border="0" align="absbottom" title="Ingl&ecirc;s" height="32" src="http://lh6.ggpht.com/_pt7i0nbIOCY/SWwjycGEnLI/AAAAAAAAA1o/7p6S3-tipsA/English_thumb%5B3%5D.png?imgmax=800" style="cursor: pointer;margin-right:13px" width="24"/></a>
 
<a class="google_translate" href="#" target="_blank" rel="nofollow" title="Franceses" onclick="window.open('http://translate.google.com/translate?u='+encodeURIComponent(location.href)+'&langpair=en%7Cfr&hl=en'); return false;"><img alt="French" border="0" align="absbottom" title="Franc&ecirc;s" height="32" src="http://lh3.ggpht.com/_pt7i0nbIOCY/SWwj1AdOWZI/AAAAAAAAA1w/lWUkGNrOFYo/French_thumb%5B5%5D.png?imgmax=800" style="cursor: pointer;margin-right:13px" width="24"/></a> 
<a class="google_translate" href="#" target="_blank" rel="nofollow" title="Alem�o" onclick="window.open('http://translate.google.com/translate?u='+encodeURIComponent(location.href)+'&langpair=en%7Cde&hl=en'); return false;"><img alt="German" border="0" align="absbottom" title="Alem&atilde;o" height="32" src="http://lh5.ggpht.com/_pt7i0nbIOCY/SWwj4Ab0NaI/AAAAAAAAA14/3H56LPKtijA/German_thumb%5B1%5D.png?imgmax=800" style="cursor: pointer;margin-right:13px" width="24"/></a> 
<a class="google_translate" href="#" target="_blank" rel="nofollow" title="Espanhol" onclick="window.open('http://translate.google.com/translate?u='+encodeURIComponent(location.href)+'&langpair=en%7Ces&hl=en'); return false;"><img alt="Spain" border="0" align="absbottom" title="Espanhol" height="32" src="http://lh3.ggpht.com/_pt7i0nbIOCY/SWwj8KhadjI/AAAAAAAAA2A/GNyl8VBie3o/Spain_thumb%5B1%5D.png?imgmax=800" style="cursor: pointer;margin-right:13px" width="24"/></a> 
<a class="google_translate" href="#" target="_blank" rel="nofollow" title="Italiano" onclick="window.open('http://translate.google.com/translate?u='+encodeURIComponent(location.href)+'&langpair=en%7Cit&hl=en'); return false;"><img alt="Italian" border="0" align="absbottom" title="Italiano" height="32" src="http://lh3.ggpht.com/_pt7i0nbIOCY/SWwj-14HeyI/AAAAAAAAA2I/TN52dIqkO9Q/Italian_thumb%5B1%5D.png?imgmax=800" style="cursor: pointer;margin-right:13px" width="24"/></a> 
<a class="google_translate" href="#" target="_blank" rel="nofollow" title="Holand�s" onclick="window.open('http://translate.google.com/translate?u='+encodeURIComponent(location.href)+'&langpair=en%7Cnl&hl=en'); return false;"><img alt="Dutch" border="0" align="absbottom" title="Holand&ecirc;s" height="32" src="http://lh5.ggpht.com/_pt7i0nbIOCY/SWwkBmKewNI/AAAAAAAAA2Q/43NEAnyNo1I/Dutch_thumb%5B1%5D.png?imgmax=800" style="cursor: pointer;margin-right:13px" width="24"/></a>
<br/>
<a class="google_translate" href="#" target="_blank" rel="nofollow" title="Russo" onclick="window.open('http://translate.google.com/translate?u='+encodeURIComponent(location.href)+'&langpair=en%7Cru&hl=en'); return false;"><img alt="Russian" border="0" align="absbottom" title="Russo" height="32" src="http://lh4.ggpht.com/_pt7i0nbIOCY/SWwkESa-0pI/AAAAAAAAA2Y/i0X4cKgxq3g/Russian_thumb%5B1%5D.png?imgmax=800" style="cursor: pointer;margin-right:13px" width="24"/></a> 
<a class="google_translate" href="#" target="_blank" rel="nofollow" title="Portugu�s" onclick="window.open('http://translate.google.com/translate?u='+encodeURIComponent(location.href)+'&langpair=en%7Cpt&hl=en'); return false;"><img alt="Portuguese" border="0" align="absbottom" title="Portugu&ecirc;s" height="32" src="http://lh4.ggpht.com/_pt7i0nbIOCY/SWwkG0osjzI/AAAAAAAAA2g/_kM2A16R_Ho/Portuguese_thumb%5B1%5D.png?imgmax=800" style="cursor: pointer;margin-right:13px" width="24"/></a> 
<a class="google_translate" href="#" target="_blank" rel="nofollow" title="Japon�s" onclick="window.open('http://translate.google.com/translate?u='+encodeURIComponent(location.href)+'&langpair=en%7Cja&hl=en'); return false;"><img alt="Japanese" border="0" align="absbottom" title="Japon&ecirc;s" height="32" src="http://lh5.ggpht.com/_pt7i0nbIOCY/SWwkJ6RBJAI/AAAAAAAAA2o/lpsTh893J3k/Japanese_thumb%5B1%5D.png?imgmax=800" style="cursor: pointer;margin-right:13px" width="24"/></a> 
<a class="google_translate" href="#" target="_blank" rel="nofollow" title="Koreano" onclick="window.open('http://translate.google.com/translate?u='+encodeURIComponent(location.href)+'&langpair=en%7Cko&hl=en'); return false;"><img alt="Korean" border="0" align="absbottom" title="Koreano" height="32" src="http://lh4.ggpht.com/_pt7i0nbIOCY/SWwkMouNMKI/AAAAAAAAA2w/L5l6J-Hh8XA/Korean_thumb%5B1%5D.png?imgmax=800" style="cursor: pointer;margin-right:13px" width="24"/></a> 

<a class="google_translate" href="#" target="_blank" rel="nofollow" title="Arab�" onclick="window.open('http://translate.google.com/translate?u='+encodeURIComponent(location.href)+'&langpair=en%7Car&hl=en'); return false;"><img alt="Arabic" border="0" align="absbottom" title="Arab&eacute;" height="32" src="http://lh5.ggpht.com/_pt7i0nbIOCY/SWwkPdkvXBI/AAAAAAAAA24/A1LSG1lcuac/Arabic_thumb%5B1%5D.png?imgmax=800" style="cursor: pointer;margin-right:13px" width="24"/></a> 
<a class="google_translate" href="#" target="_blank" rel="nofollow" title="Chin�s" onclick="window.open('http://translate.google.com/translate?u='+encodeURIComponent(location.href)+'&langpair=en%7Czh-CN&hl=en'); return false;"><img alt="Chinese Simplified" border="0" align="absbottom" title="Chin&ecirc;s Simplificado" height="32" src="http://lh6.ggpht.com/_pt7i0nbIOCY/SWwkSgrv4ZI/AAAAAAAAA3A/jQqZ1l6avts/Chinese-Simplified_thumb%5B1%5D.png?imgmax=800" style="cursor: pointer;margin-right:13px" width="24"/></a> 

</div><div style=�font:10px;margin:10px 0px 3px 0px�>

</div></html>