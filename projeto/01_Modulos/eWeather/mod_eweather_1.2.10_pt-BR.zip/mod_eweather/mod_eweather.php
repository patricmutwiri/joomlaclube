<?php
/**
 * This file contains the classes for the eWeather module.
 *
 * This file is part of eWeather.
 *
 *   eWeather is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   eWeather is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with eWeather.  If not, see <a href="http://www.gnu.org/licenses/">
 *   http://www.gnu.org/licenses/</a>.
 *
 * <b>Modifications:</b><br/>
 * converted to Joomla! 1.5.x by Bob Lavey
 *
 * @version $Id: eweather.html.php 125 2009-04-17 00:38:34Z rjlavey $
 * @package eWeather
 * @subpackage eWeather
 * @copyright Copyright (C) 2000 - 2005 Miro International Pty Ltd,
 *            2006 Harald Baer<br/>
 *            2009 Bob Lavey<br/>
 * @license http://www.gnu.org/licenses/gpl.txt GNU/GPL
 * @toto General clean up, see if raw HTML can be converted
 *        to something easier to maintain.
 */

/* ensure this file is being called by Joomla! */
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

require_once(dirname(__FILE__).DS.'helper.php');
$items =& modEWeatherHelper::getItems($params);

if (file_exists(JPATH_ADMINISTRATOR.DS."components/com_eweather/WeatherConfiguration.xml"))
{
	//
	// load the com_eweather language file
	//
	$lang =& JFactory::getLanguage();
	$lang->load("com_eweather", JPATH_SITE);
	
	//
	// get the definition for the WeatherConfiguration class
	//  from the com_eweather component
	//
	include_once(JPATH_ADMINISTRATOR.DS."components/com_eweather/WeatherConfiguration.php");

	//
	// get the definitions for weather_global and ParseWeather()
	//  from the com_eweather component
	//
    include_once(JPATH_SITE.DS."components/com_eweather/eweather.html.php");
    include_once(JPATH_SITE.DS."components/com_eweather/eweather.main.php");
	
    $weatherClass = parseWeather(null);
  	if ($weatherClass->e_error != '')
  	{
     	HTML_weather::displayErrorMessage(JText::_('EWEATHER_ERROR_TITLE'), JText::_('EWEATHER_ERROR_DESCR'), $weatherClass->e_error);
  	}
    else
    {
    	showWeather($weatherClass, $items);
    }

}
else
{
	echo "Please install compontent com_eweather first!\n";
}

function showWeather(&$weather, $items)
{
    $url = JUri::base(true);
	$database = &JFactory::getDBO();
	$moduleClassSuffix = $items[ 'moduleclass_sfx' ];

	$cfg = & WeatherConfiguration::getInstance();
	$weatherIconStyle = $cfg->getIconStyle();
	
  	$database -> setQuery("SELECT * FROM #__menu WHERE `link` = 'index.php?option=com_eweather' AND `published` = '1'");
  	$mname = $database -> loadObjectList();
  	if (count($mname) > 0 )
  	{
     	$myItemID = $mname[0]->id;
  	}
  	else
  	{
     	$myItemID = "0";
  	}

	$eWeatherUrl = JROUTE::_("index.php?option=com_eweather&amp;Itemid=".$myItemID);
	$selectCityUrl = JROUTE::_("index.php?option=com_eweather&amp;Itemid=".$myItemID."&amp;task=profiles");
	
  	$content = "<!-- eWeather Module Version 1.2.10 -->\n";

  $content .="<table border=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse;\" align=\"center\" width=\"99%\">\n"
            ."  <tr>\n"
            ."    <td colspan=\"2\" align=\"center\" style=\"border-bottom: 1px solid #CCCCCC;\">\n"
            ."      <div align=\"center\"><strong>".$weather->loc_city."</strong></div>\n"
            ."    </td>\n"
            ."  </tr>\n"
            ."  <tr>\n"
            ."    <td>\n"
            ."      <div align=\"center\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/small/".$weather->cc_icon.".png\" alt=\"\" border=\"0\"></img></div>\n"
            ."    </td>\n"
            ."    <td valign=\"top\">\n"

            ."      <table border=\"0\" style=\"margin: 0px; padding: 0px;\" cellspacing=\"0\" cellpadding=\"0\" width=\"99%\" align=\"center\">\n"
            ."        <tr>\n"
            ."          <td style=\"margin: 0px; padding: 0px; text-align: left;\">\n"
            ."            <strong>".JText::_('EWEATHER_TEMP').":</strong>\n"
            ."          </td>\n"
            ."          <td style=\"margin: 0px; padding: 0px; text-align: right;\">\n";
  if (is_numeric($weather->cc_temp))
  {
  $content .="            ".$weather->cc_temp."&deg;".$weather->h_temp."\n";
  }
  else
  {
  $content .="            ".$weather->cc_temp."\n";
  }
  $content .="          </td>\n"
            ."        </tr>\n"
            ."        <tr>\n"
            ."          <td style=\"margin: 0px; padding: 0px; text-align: left;\">\n"
            ."            <strong>".JText::_('EWEATHER_WINDCHILL').":</strong>\n"
            ."          </td>\n"
            ."          <td style=\"margin: 0px; padding: 0px; text-align: right;\">\n";
  if (is_numeric($weather->cc_windchill))
  {
  $content .="            ".$weather->cc_windchill."&deg;".$weather->h_temp."\n";
  }
  else
  {
  $content .="            ".$weather->cc_windchill."\n";
  }
  $content .="          </td>\n"
            ."        </tr>\n"
            ."        <tr>\n"
            ."          <td style=\"margin: 0px; padding: 0px; text-align: left;\">\n"
            ."            <strong>".JText::_('EWEATHER_HUMIDITY').":</strong>\n"
            ."          </td>\n"
            ."          <td style=\"margin: 0px; padding: 0px; text-align: right;\">\n";
  if (is_numeric($weather->cc_humidity))
  {
  $content .="            ".$weather->cc_humidity."%\n";
  }
  else
  {
  $content .="            ".$weather->cc_humidity."\n";
  }
  $content .="          </td>\n"
            ."        </tr>\n"
            ."      </table>\n"

            ."    </td>\n"
            ."  </tr>\n"
            ."</table>\n"

            ."<table border=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse;\" align=\"center\" width=\"99%\">\n"
            ."  <tr>\n"
            ."    <td valign=\"top\">\n"

            ."      <table border=\"0\" style=\"margin: 0px; padding: 0px;\" cellspacing=\"0\" cellpadding=\"0\" width=\"99%\" align=\"center\">\n"
            ."        <tr>\n"
            ."          <td style=\"margin: 0px; padding: 0px; text-align: left;\">\n"
            ."            <strong>".JText::_('EWEATHER_FORECAST_WINDSPEED').":</strong>\n"
            ."          </td>\n"
            ."          <td style=\"margin: 0px; padding: 0px; text-align: right;\">\n";
  if (is_numeric($weather->cc_windspeed))
  {
  $content .="            ".$weather->cc_windspeed."&nbsp;".$weather->h_speed."\n";
  }
  else
  {
  $content .="            ".$weather->cc_windspeed."\n";
  }
  $content .="          </td>\n"
            ."        </tr>\n"
            ."        <tr>\n"
            ."          <td style=\"margin: 0px; padding: 0px; text-align: left;\">\n"
            ."            <strong>".JText::_('EWEATHER_FORECAST_DIRECTION').":</strong>\n"
            ."          </td>\n"
            ."          <td style=\"margin: 0px; padding: 0px; text-align: right;\">\n";
  if (is_numeric($weather->cc_winddirection))
  {
  $content .="            ".$weather->cc_winddirection."&deg;\n";
  }
  else
  {
  $content .="            ".$weather->cc_winddirection."\n";
  }
  $content .="          </td>\n"
            ."        </tr>\n"
            ."        <tr>\n"
            ."          <td style=\"margin: 0px; padding: 0px; text-align: left;\">\n"
            ."            <strong>".JText::_('EWEATHER_PRESSURE').":</strong>\n"
            ."          </td>\n"
            ."          <td style=\"margin: 0px; padding: 0px; text-align: right;\">\n";
  if (is_numeric($weather->cc_barpressure))
  {
  $content .="            ".$weather->cc_barpressure."&nbsp;".$weather->h_pressure."\n";
  }
  else
  {
  $content .="            ".$weather->cc_barpressure."\n";
  }
  $content .="          </td>\n"
            ."        </tr>\n"
            ."      </table>\n"

            ."    </td>\n"
            ."    <td>\n";

  if ($weather->cc_windtext != null)
  {
  $content .="      <div align=\"center\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/winddirs_small/wind_".$weather->cc_windtext.".gif\" alt=\"\" border=\"0\"></img></div>\n";
  }
  else
  {
  $content .="      <div align=\"center\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/winddirs_small/wind_nodir.gif\" alt=\"\" border=\"0\"></img></div>\n";
  }
  
  $content .="      <div align=\"center\"><strong>".$weather->cc_windtext."</strong></div>\n"
            ."    </td>\n"
            ."  </tr>\n"
            ."  <tr>\n"
            ."    <td colspan=\"2\" style=\"border-top: 1px solid #CCCCCC; text-align: center; padding-top: 8px; float: none;\" align=\"center\">\n"
            ."      <a class=\"button$moduleClassSuffix\" style=\"float: none;\" href=".$eWeatherUrl.">".JText::_('EWEATHER_MOD_BUTTON')."</a>\n"
            ."    </td>\n"
            ."  </tr>\n";
  if ($items[ 'showCitySelector' ] == '1')
  {
    $content .="  <tr>\n"
              ."    <td colspan=\"2\" style=\"border-bottom: 1px solid #CCCCCC; text-align: center; padding-top: 8px; float: none;\" align=\"center\">\n"
              ."      <a class=\"button$moduleClassSuffix\" style=\"float: none;\" href=".$selectCityUrl.">".JText::_('EWEATHER_SELECT_LOCATION')."</a>\n"
		  	  ."    </td>\n"
			  ." </tr>\n";
  }
            
  $content .="  <tr>\n"
            ."    <td colspan=\"2\">\n"
            ."      <table border=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse;\" align=\"center\" width=\"99%\">\n"
            ."        <tr>\n"
            ."          <td align=\"right\" style=\"font-size: 70%; padding-top: 15px;\">\n"
            ."            <div align=\"left\">".JText::_('EWEATHER_PROVIDER').":<br/><a href=\"http://www.weather.com\" target=\"blank\">\n"
            ."            <img src=\"".$url."/components/com_eweather/images/TWClogo_31px.png\" border=\"0\" alt=\"\"></img></a></div>\n"
            ."          </td>\n"
            ."          <td align=\"right\" style=\"font-size: 80%; padding-left: 5px; padding-top: 15px; text-align: right;\">\n"
            .HTML_weather::displayLinks($weather)
            ."          </td>\n"
            ."        </tr>\n"
            ."      </table>\n"
            ."    </td>\n"
            ."  </tr>\n"
            ."</table>\n";

  $content .= "<!-- end eWeather Module Version 1.2.10 -->\n";
            
  echo $content;
  
  return;
}

?>
