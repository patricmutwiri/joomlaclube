<?php
/**
 * This file contains the helpers for the eWeather Forecast module.
 *
 * This file is part of eWeather.
 *
 *   eWeather is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   eWeather is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with eWeather.  If not, see <a href="http://www.gnu.org/licenses/">
 *   http://www.gnu.org/licenses/</a>.
 *
 * <b>Modifications:</b><br/>
 * Initial revision by Bob Lavey
 *
 * @version $Id$
 * @package eWeather
 * @subpackage eWeather
 * @copyright Copyright (C) 2009 Bob Lavey
 * @license http://www.gnu.org/licenses/gpl.txt GNU/GPL
 */

/* ensure this file is being called by Joomla! */
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

/**
* eWeather Forecast Module Helper
*
* @static
*/
class modEWeatherForecastHelper
{
	/**
	* Gets an array of module parameters
	*
	* @param JParameter Module parameters
	* @return mixed Array of items, false on failure
	*/
	function &getItems(&$params)
	{
		static $items;
		if (!isset($items))
		{
			$items = array();
		}
		
		$items[ 'numberOfForecastDays' ] = $params->get( 'numberOfForecastDays' );
		$items[ 'forecastsPerRow' ] = $params->get( 'forecastsPerRow' );
		$items[ 'showCitySelector' ] = $params->get( 'showCitySelector' );
		$items[ 'moduleclass_sfx' ] = $params->get( 'moduleclass_sfx' );
		
		return $items;
	}
}

