<?php
/**
 * This file contains the classes for the eWeather Forecast module.
 *
 * This file is part of eWeather.
 *
 *   eWeather is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   eWeather is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with eWeather.  If not, see <a href="http://www.gnu.org/licenses/">
 *   http://www.gnu.org/licenses/</a>.
 *
 * <b>Modifications:</b><br/>
 * Initial revision by Bob Lavey
 *
 * @version $Id$
 * @package eWeather
 * @subpackage eWeatherForecast
 * @copyright Copyright (C) 2009 Bob Lavey
 * @license http://www.gnu.org/licenses/gpl.txt GNU/GPL
 * @toto General clean up, see if raw HTML can be converted
 *        to something easier to maintain.
 */

/* ensure this file is being called by Joomla! */
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

require_once(dirname(__FILE__).DS.'helper.php');
$items =& modEWeatherForecastHelper::getItems($params);

if (file_exists(JPATH_ADMINISTRATOR.DS."components/com_eweather/WeatherConfiguration.xml"))
{
	//
	// load the com_eweather language file
	//
	$lang =& JFactory::getLanguage();
	$lang->load("com_eweather", JPATH_SITE);
	
	//
	// get the definitions for weather_global and ParseWeather()
	//  from the com_eweather component
	//
    include_once(JPATH_SITE.DS."components/com_eweather/eweather.html.php");
    include_once(JPATH_SITE.DS."components/com_eweather/eweather.main.php");
	
    $weatherClass = parseWeather(null);
  	if ($weatherClass->e_error != '')
  	{
     	HTML_weather::displayErrorMessage(JText::_('EWEATHER_ERROR_TITLE'), JText::_('EWEATHER_ERROR_DESCR'), $weatherClass->e_error);
  	}
    else
    {
    	EWeatherForecastModule::showWeatherForecast($weatherClass, $items);
    }

}
else
{
	echo "Please install compontent com_eweather first!\n";
}

class EWeatherForecastModule
{
function showWeatherForecast(&$weather, $items)
{
    $url = JUri::base(true);
	$database = &JFactory::getDBO();
    $content = "";
	
  	$database -> setQuery("SELECT * FROM #__menu WHERE `link` = 'index.php?option=com_eweather' AND `published` = '1'");
  	$mname = $database -> loadObjectList();
  	if (count($mname) > 0 )
  	{
     	$myItemID = $mname[0]->id;
  	}
  	else
  	{
     	$myItemID = "0";
  	}

	$eWeatherUrl = JROUTE::_("index.php?option=com_eweather&amp;Itemid=".$myItemID);
	$selectCityUrl = JROUTE::_("index.php?option=com_eweather&amp;Itemid=".$myItemID."&amp;task=profiles");
	
  	echo "<!-- eWeather Forecast Module Version 1.3.4 -->\n";

  echo EWeatherForecastModule::getForecastHeaderMarkup($weather);
  echo HTML_weather::getForecastMarkup($weather, $items[ 'numberOfForecastDays' ], $items[ 'forecastsPerRow' ]);

  $content = "<table border=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse;\" align=\"center\" width=\"99%\">\n"
            ."  <tr>\n"
            ."    <td colspan=\"2\" style=\"border-top: 1px solid #CCCCCC; text-align: center; padding-top: 8px; float: none;\" align=\"center\">\n"
            ."      <a class=\"button\" style=\"float: none;\" href=".$eWeatherUrl.">".JText::_('EWEATHER_MOD_BUTTON')."</a>\n"
            ."    </td>\n"
            ."  </tr>\n";
            
  if ($items[ 'showCitySelector' ] == '1')
  {
    $content .="  <tr>\n"
              ."    <td colspan=\"2\" style=\"border-bottom: 1px solid #CCCCCC; text-align: center; padding-top: 8px; float: none;\" align=\"center\">\n"
              ."      <a class=\"button\" style=\"float: none;\" href=".$selectCityUrl.">".JText::_('EWEATHER_SELECT_LOCATION')."</a>\n"
		  	  ."    </td>\n"
			  ." </tr>\n";
  }
            
  $content .="  <tr>\n"
            ."    <td colspan=\"2\">\n"
            ."      <table border=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse;\" align=\"center\" width=\"99%\">\n"
            ."        <tr>\n"
            ."          <td align=\"right\" style=\"font-size: 70%; padding-top: 15px;\">\n"
            ."            <div align=\"left\">".JText::_('EWEATHER_PROVIDER').":<br/><a href=\"http://www.weather.com\" target=\"blank\">\n"
            ."            <img src=\"".$url."/components/com_eweather/images/TWClogo_31px.png\" alt=\"\" border=\"0\"></img></a></div>\n"
            ."          </td>\n"
            ."          <td align=\"right\" style=\"font-size: 80%; padding-left: 5px; padding-top: 15px; text-align: right;\">\n"
            .HTML_weather::displayLinks($weather)
            ."          </td>\n"
            ."        </tr>\n"
            ."      </table>\n"
            ."    </td>\n"
            ."  </tr>\n"
            ."</table>\n";

  $content .= "<!-- end eWeather Forecast Module Version 1.3.4 -->\n";

  echo $content;
  
  return;
}

  function getForecastHeaderMarkup(&$weather)
  {
  	$cfg = & WeatherConfiguration::getInstance();
    $date_format = $cfg->getDateFormatLong();
  	
    $content = "<table width=\"98%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\" align=\"center\" summary=\"\">\n"
              ."  <tr>"
              ."    <td valign=\"middle\">"
              ."      ".JText::_('EWEATHER_FORECAST')."&nbsp;".JText::_('EWEATHER_FORECAST_FOR')."&nbsp;".$weather->loc_city."\n"
              ."      <br/>\n"
              ."      ".JText::_('EWEATHER_LASTUPDATED')."&nbsp;".$weather->dayf_lastupdate."\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>\n"
              ."      <br/>\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."</table>\n";
    
    return $content;
  }

} // end class EWeatherForecastModule

?>
