<?php
/**
* @version		2.1
* @copyright	Copyright (C) 2007-2009 Stephen Brandon
* @license		GNU/GPL
*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

class JElementDonate extends JElement
{
	/**
	 * Element name
	 *
	 * @access	protected
	 * @var		string
	 */
	var	$_name = 'Donate';

	function fetchElement($name, $value, &$node, $control_name)
	{
		return '
		<a href="http://www.metamodpro.com/donate.php" target="_blank"><img src="https://www.paypal.com/en_GB/i/btn/btn_donate_SM.gif" border="0" alt="' . JText::_("Donate with PayPal").'" title="' . JText::_('Donate with PayPal - support further development of MetaMod!') . '" /></a>
			' . JText::_("Make a donation &mdash; support further development of MetaMod!");

	}
}