<?php
/**
 * @version		$Id: language.php 12874 2009-09-28 05:15:19Z eddieajau $
 * @copyright	Copyright (C) 2005 - 2009 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Languages list actions controller.
 *
 * @package		Joomla.Administrator
 * @subpackage	com_languages
 * @version		1.6
 */
class LanguagesControllerLanguage extends JControllerForm
{
	// Define protected variables and custom methods if necessary.
}