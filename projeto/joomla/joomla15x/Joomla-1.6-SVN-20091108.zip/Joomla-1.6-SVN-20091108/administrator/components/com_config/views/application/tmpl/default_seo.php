<?php
/**
 * @version		$Id: default_seo.php 13126 2009-10-10 17:33:51Z severdia $
 * @package		Joomla.Administrator
 * @subpackage	com_config
 * @copyright	Copyright (C) 2005 - 2009 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;
?>
<div class="width-100">
<fieldset class="adminform">
	<legend><?php echo JText::_('SEO Settings'); ?></legend>
			<?php
			foreach ($this->form->getFields('seo') as $field):
			?>
			<?php echo $field->label; ?>
			<?php echo $field->input; ?>
			<?php
			endforeach;
			?>

</fieldset>
</div>