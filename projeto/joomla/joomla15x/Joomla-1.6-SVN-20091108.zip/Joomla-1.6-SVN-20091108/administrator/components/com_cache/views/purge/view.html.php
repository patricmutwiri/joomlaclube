<?php
/**
 * @version		$Id: view.html.php 13332 2009-10-25 18:52:26Z severdia $
 * @package		Joomla.Administrator
 * @subpackage	Cache
 * @copyright	Copyright (C) 2005 - 2009 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

/**
 * HTML View class for the Cache component
 *
 * @static
 * @package		Joomla.Administrator
 * @subpackage	Cache
 * @since 1.6
 */
class CacheViewPurge extends JView
{
	public function display($tpl = null)
	{
		$this->_setToolbar();
		parent::display($tpl);
	}

	protected function _setToolbar()
	{
		JSubMenuHelper::addEntry(JText::_('COM_CACHE_BACK_CACHE_MANAGER'), 'index.php?option=com_cache', false);

		JToolBarHelper::title(JText::_('Cache Manager - Purge Cache Admin'), 'purge.png');
		JToolBarHelper::custom('purge', 'delete.png', 'delete_f2.png', 'Purge expired', false);
		JToolBarHelper::divider();
		if (JFactory::getUser()->authorise('core.admin', 'com_cache'))
		{
			JToolBarHelper::preferences('com_cache');
			JToolBarHelper::divider();
		}
		JToolBarHelper::help('screen.cache');
	}
}