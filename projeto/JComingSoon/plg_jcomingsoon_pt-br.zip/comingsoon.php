﻿<?php
/**
* @package		JComingSoon
* @version		1.1
* @copyright	Copyright (C) 2010 - 2011 Ronak Bhagdev
* @license		GPL 2.0 - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
$day = $params->get('date');
				  $month = $params->get('month');
				  $year = $params->get('year');
				  $hour = $params->get('hour');
				  $minute = $params->get('minute');
				  $second = $params->get('second');
*/

  // no direct access
  defined('_JEXEC') or die('Restricted access');
  jimport('joomla.plugin.plugin');
  $document = &JFactory::getDocument();
  
  class plgSystemComingsoon extends JPlugin
  {
      function onAfterRender()
      {
          $app = JFactory::getApplication();
          if (!$app->isAdmin()) {
              $token = JHTML::_('form.token');
              $plugin = JPluginHelper::getPlugin("system", "comingsoon");
              $params = new JParameter($plugin->params);
              
			  if($params->get('on_off') == 1)
			  {
				  $month = $params->get('month');
				  $year = $params->get('year');
				  $hour = $params->get('hour');
				  $minute = $params->get('minute');
				  $second = $params->get('second');
				  $email_from = $params->get('email_from');
				  $email_to = $params->get('email_to');
				  $copyright = $params->get('copyright');
				  $facebook = $params->get('facebook');
				  $twitter = $params->get('twitter');
				  $template = $params->get('template');
				  $logo_path = $params->get('logo_path');
				  $heading = $params->get('heading');
				  $description = $params->get('description');
				  $meta_title = $params->get('meta_title');
				  $meta_description = $params->get('meta_description');
				  $meta_key_words = $params->get('meta_key_words');
				  
				  
				  if(isset($_POST["subscribe"]))
				  {
					  // email paramerters
					  $subject = $params->get('subject');
					  $newemail = $_POST['email'];
					  $to = $email_to;
					  $from = $email_from;
					  
					  $mailer = JFactory::getMailer();
					  
					  $mailer->setSender($from);
					  
					  $mailer->addRecipient($to);
					  
					  $mailer->setSubject($subject);
					  $mailer->setBody("Subscribed for the updates: ".$newemail);
					  
					  $mailer->send();
				  }
				  
				  if ($template == 'green') {
					  $tem_id = 'id="wrapper_green"';
					  $bt_id = 'id="submit_green"';
					  $heading_text_id = 'id="under_construction_green"';
				  } elseif ($template == 'orange') {
					  $tem_id = 'id="wrapper_orange"';
					  $bt_id = 'id="submit_orange"';
					  $heading_text_id = 'id="under_construction_orange"';
				  } elseif ($template == 'red') {
					  $tem_id = 'id="wrapper_red"';
					  $bt_id = 'id="submit_red"';
					  $heading_text_id = 'id="under_construction_red"';
				  } else {
					  $tem_id = 'id="wrapper"';
					  $bt_id = 'id="submit"';
					  $heading_text_id = 'id="under_construction"';
				  }
				  
				  
				  $eventTime = mktime($hour, $minute, $second, $month, $day, $year);
				  $currentTime = time();
				  
				  $timeleft = $eventTime - $currentTime;
				  
				  //html head
				  $head = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"> 
	
		<html lang=\"en\">
		  <head>
		  <meta charset=utf-8 />
		<link href=\"" . $this->baseurl . "plugins/system/jcomingsoon/style.css\" rel=\"stylesheet\" type=\"text/css\" />
		<link href=\"" . $this->baseurl . "plugins/system/jcomingsoon/colorbox/colorbox.css\" rel=\"stylesheet\" type=\"text/css\" />
		<script type=\"text/javascript\" src=\"" . $this->baseurl . "plugins/system/jcomingsoon/jquery.js\" ></script>
		<script type=\"text/javascript\" src=\"" . $this->baseurl . "plugins/system/jcomingsoon/jquery.countdown.min.js\"></script>
		<script type=\"text/javascript\" src=\"" . $this->baseurl . "plugins/system/jcomingsoon/colorbox/jquery.colorbox.js\" ></script>
			
		<script type=\"text/javascript\">$(document).ready(function(){
	$(\".login_handle\").colorbox({width:\"40%\", inline:true, href:\"#login_panel\"});});
	  </script>
	  
	  <script type=\"text/javascript\">
$(function () {
	var austDay = new Date();
	austDay = new Date(austDay.getFullYear() + 1, 1 - 1, 26);
	$('#countdown').countdown({until: ".$timeleft."});
	$('#year').text(austDay.getFullYear());
});
</script>
		
		<meta name=\"description\" http-equiv=\"Content-Type\" content=\"" . $meta_description . "\" />
		<meta name=\"keywords\" http-equiv=\"Content-Type\" content=\"" . $meta_key_words . "\" />
		<title>" . $meta_title . "</title>
		</head>";
				  
				  
				  //html body
				  $body =  
				  "<body>
					
		<div " . $tem_id . ">
		
		<img id=\"logo\" src=\"" . $logo_path . "\"/>
		
		<div id=\"stripes\">
		
		<div " . $heading_text_id . ">
		EM CONSTRUÇÃO!
		</div>
		
		<div id=\"text\">" . $heading . "</div>
		
		<div id=\"info\">" . $description . "</div>
		
		<div id=\"time\">
		TEMPO ESTIMADO PARA LANÇAMENTO
		</div>
		
		<div id=\"countdown\"></div>
		
		
		
		
		<form action=\"".JURI::base( true )."\" method=\"post\" name=\"login\" id=\"form1\" >
		
		<input class=\"email\" name=\"email\" type=\"text\" value=\"Entre com seu email para novidades\" onfocus=\"if(this.value=='enter your email for updates'){this.value=''}\" onblur=\"if(this.value==''){this.value='enter your email for updates'}\" /> 
		<input " . $bt_id . " name=\"subscribe\" type=\"submit\" value=\"Enviar\" />
		
		</form>
		</div>
		
		<div id=\"footer\">" . $copyright . " | <a class='login_handle' href=\"#login_panel\">Login</a></div>
	
		<div id=\"icons\">
		<a href=\"" . $twitter . "\"><img src=\"" . $this->baseurl . "plugins/system/jcomingsoon/images/twitter.png\" width=\"22\" height=\"23\" /></a>
		<a href=\"" . $facebook . "\"><img src=\"" . $this->baseurl . "plugins/system/jcomingsoon/images/facebook.png\" width=\"22\" height=\"23\" /></a>
		</div>
		
		<div id=\"login_form\">
		<div id=\"login_panel\">
		
		<form action=\"".JURI::base( true )."\" method=\"post\" name=\"login\" id=\"form-login\" >
		
		<span class=\"label\">Usuário </span><input class=\"email\" name=\"username\" type=\"text\" /><br />
		<span class=\"label\">Senha </span><input id=\"passwd\" class=\"email\" name=\"passwd\" type=\"password\" /><br />
		<input id=\"form_submit\" name=\"login\" type=\"submit\" value=\"Login\" />
	
		<input type=\"hidden\" name=\"option\" value=\"com_user\" />
		  <input type=\"hidden\" name=\"task\" value=\"login\" />
		  <input type=\"hidden\" name=\"return\" value=\"".base64_encode(JURI::base( true ))."\" />
		" . $token . "
		</form>
		</div>
		</div>
		
		</div>
		
		</body></html>";
		
				  $user =& JFactory::getUser();
				  
				  if ($user->id) {
				  } else {
					  JResponse::setBody($head.$body);
				  }
				  
			  }
		  }
      }
  }
?>