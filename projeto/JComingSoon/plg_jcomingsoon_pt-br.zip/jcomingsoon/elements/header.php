<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

class JElementHeader extends JElement {

	function fetchElement($name, $value, &$node, $control_name){
		return '
		<div style="font-weight:bold;padding:5px;;color:#fff;background:#1352cc;">
			'.JText::_($value).'
		</div>
		';
	}

	function fetchTooltip($label, $description, &$node, $control_name, $name){
		return '&nbsp;';
	}

}
