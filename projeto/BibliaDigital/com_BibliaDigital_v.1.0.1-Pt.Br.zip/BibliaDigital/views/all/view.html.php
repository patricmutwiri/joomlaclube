<?php
/**
 * @version		$Id: view.html.php 10381 2009-01-12 11:55:53Z pasamio $
 * @package		Joomla
 * @author	        Ferax Informatica - http://www.ferax.inf.br.
 * @subpackage	Biblia Digital
 * @copyright	Copyright (C) 2009 Estudo Bíblico - http://www.estudobiblico.org. All rights reserved.
 * @license	GNU/GPL, see LICENSE.php

 * Biblia Digital is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

defined( '_JEXEC' ) or die ( 'Acesso Restrito' );

jimport('joomla.application.component.view');
class BibliaDigitalViewAll extends JView
{
    function display($tpl = null)
    {

        global $mainframe, $option;
        $model = &$this->getModel();
        $cid = JRequest::getVar( 'cid', array(0), '', 'array' );
        $session =& JFactory::getSession();


        $funcao = JRequest::getVar( 'funcao');
        switch ($funcao)
        {
            case 'gravar':

                $guardado= array();
                $solicitado = array();
                $joined = array();

                $guardado = $session->get( 'myvar', array() );

                if (($guardado != 'empty') && ($guardado != '') && ($guardado != Array()))
                {
                    $solicitado = $session->set( 'myvar', $cid );

                    $joined = array_merge($guardado, $cid);

                    $session->set( 'myvar', $joined);
                }else{
                    $solicitado = $session->set( 'myvar', $cid);
                }

            break;

            case 'ler':
                $guardado= array();

                $guardado = $session->get( 'myvar', 'empty' );
                if($guardado == 'empty')
                {
                    echo "<b>Não há items selecionados</b>";
                }
            break;

            case 'limpar':
                $filter_search = JRequest::setVar('filter_search', '');
                $livro = JRequest::setVar('livro', '');
                $livro_seq = JRequest::setVar('livro_seq', '');
                $capitulo = JRequest::setVar('capitulo', '');
                $versiculo = JRequest::setVar('versiculo', '');
                $tipo_de_pesquisa = JRequest::setVar('tipo_de_pesquisa', '');
                $funcao = JRequest::setVar( 'funcao', '');
            break;
        }

        $js = 'onchange="document.adminForm.submit();"';
        // prepare list array
        $lists = array();

        $filter_search = $mainframe->getUserStateFromRequest($option.'filter_search','filter_search');
        $tipo_de_pesquisa = $mainframe->getUserStateFromRequest($option.'tipo_de_pesquisa','tipo_de_pesquisa');
        $livro_seq = $mainframe->getUserStateFromRequest($option.'livroseq','livroseq');

        $capitulo = $mainframe->getUserStateFromRequest($option.'capitulo','capitulo');
        $versiculo = $mainframe->getUserStateFromRequest($option.'versiculo','versiculo');

        // set the table filter values

        $lists['capitulo'] = $capitulo;
        $lists['versiculo'] = $versiculo;
        $js = 'onchange="document.adminForm.submit();"';


        $lists['search'] = $filter_search;

        $lists['tipo_de_pesquisa'] = JHTML::_('select.booleanlist', 'tipo_de_pesquisa', 'class="inputbox"', $tipo_de_pesquisa);

        $lista = $model->getList();

        $palavras_pesquisadas = array();

        $palavras_pesquisadas = explode( ' ', $filter_search );

        //Tratamento das linhas
        for($i = 0; $i < count($lista); $i++)
        {
            $linha =& $lista[$i];

            if (trim($filter_search) != "")
            {
                $palavras = array();
                $palavras = explode(' ', $linha->palavra);

                for ($iword = 0; $iword < count($palavras);$iword++)
                {
                    $word = JRequest::getWord('word', $palavras[$iword], 'GET');


                    $plural_word = substr($word, 0 , -1);
                    $plural_iword = substr($palavras[$iword], 0 , -1);
                    $plural_iword2 = substr($palavras[$iword], 0 , -3);

                    if ( (in_array($word, $palavras_pesquisadas))
                                                        || (in_array(strtolower($word), $palavras_pesquisadas))
                                                        || (in_array(ucfirst($word), $palavras_pesquisadas))
                                                        || (in_array($palavras[$iword], $palavras_pesquisadas))
                                                        || (in_array(strtolower($palavras[$iword]), $palavras_pesquisadas))
                                                        || (in_array(ucfirst($palavras[$iword]), $palavras_pesquisadas))

                                                        || (in_array($plural_word, $palavras_pesquisadas))
                                                        || (in_array(strtolower($plural_word ), $palavras_pesquisadas))
                                                        || (in_array(ucfirst($plural_word ), $palavras_pesquisadas))
                                                        || (in_array($plural_iword, $palavras_pesquisadas))
                                                        || (in_array(strtolower($plural_iword ), $palavras_pesquisadas))
                                                        || (in_array(ucfirst($plural_iword ), $palavras_pesquisadas))
                                                        || (in_array($plural_iword2, $palavras_pesquisadas))
                                                        || (in_array(strtolower($plural_iword2 ), $palavras_pesquisadas))
                                                        || (in_array(ucfirst($plural_iword2 ), $palavras_pesquisadas))

                        )
                    {
                        $palavras[$iword] = '<b><span class=" highlight">' . $palavras[$iword] . '</span></b>';
                    }
                }
                $linha->palavra = implode($palavras, ' ');
            }


            $id = JHTML::_('grid.id', $i, $linha->id );

            $linha->link = JRoute::_('index.php?option=' . $option .
                                '&id=' . $linha->id . '&view=all&livro=' . $linha->livroseq . '&capitulo=' . $linha->capitulo . '&filter_search=' . "&versiculo=" . $linha->versiculo );

        }


	$db =& JFactory::getDBO();

        //Divisão Antigo/Novo
	$query = 'SELECT DISTINCT  livro_seq, livro_desc FROM #__biblia_livros WHERE published = 1';

        $livro = $mainframe->getUserStateFromRequest($option.'livro','livro');

	$db->setQuery($query);
	$options = $db->loadAssocList();
	$lists['livro'] = JHTML::_('select.genericlist', $options, 'livro', 'class="inputbox" size="1" style="font-size: 10px;" '.'', 'livro_seq','livro_desc',$livro);

        $pagination =& $this->get('Pagination');
 	$total =& $this->get('Total');
	$limit =& $this->get('Limit');

        $limitstart =& $this->get('Limitstart');

	// push data into the template
        $this->assignRef('lists', $lists);
	$this->assignRef('lista', $lista);
	$this->assignRef('total', $total);
	$this->assignRef('pagination', $pagination);
	$this->assignRef('total', $total);
	$this->assignRef('limit', $limit);
	$this->assignRef('limitstart', $limitstart);

        parent::display($tpl);
    }
}

?>