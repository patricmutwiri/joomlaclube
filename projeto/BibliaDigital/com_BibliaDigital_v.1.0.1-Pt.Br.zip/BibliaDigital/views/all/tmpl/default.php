<?php
/**
 * @version		$Id: default.php 10381 2009-01-12 11:55:53Z pasamio $
 * @package		Joomla
 * @author	        Ferax Informatica - http://www.ferax.inf.br.
 * @subpackage	Biblia Digital
 * @copyright	Copyright (C) 2009 Estudo Bíblico - http://www.estudobiblico.org. All rights reserved.
 * @license	GNU/GPL, see LICENSE.php

 * Biblia Digital is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */
 
defined( '_JEXEC' ) or die ( 'Acesso Restrito' );

$js =  "/includes/js/joomla.javascript.js";
$document =& JFactory::getDocument();
$document->addScript(JURI::base() . $js);
$css = JURI::base().'components/com_bibliadigital/css/style.css';
$document =& JFactory::getDocument();
$document->addStyleSheet($css);
$link_action = JRoute::_("index.php?option=com_bibliadigital&view=all");
$link_gravar = JRoute::_("index.php?option=com_bibliadigital&funcao=gravar&view=all");
$link_apagar = JRoute::_("index.php?option=com_bibliadigital&funcao=apagar&view=all");
$link_apagarselecao = JRoute::_("index.php?option=com_bibliadigital&funcao=apagarselecao&view=all");
$link_ler = JRoute::_("index.php?option=com_bibliadigital&funcao=ler&view=all");
$link_limpar = JRoute::_("index.php?option=com_bibliadigital&funcao=limpar&view=all");

?>

<table>
<tr>
<td>
<form name="adminForm" method="post" action="<?php echo $link_action; ?>">
<div id="biblia_facil">

<script language="javascript" type="text/javascript">
    function tableOrdering( order, dir, task )
    {
        var form = document.adminForm;
        form.filter_order.value   = order;
        form.filter_order_Dir.value   = dir;
        document.adminForm.submit( task );
    }

    function submeteForm(pTarget)
    {
        document.adminForm.action = pTarget;
        document.adminForm.submit();
    }
</script>

    <table>
    <tr>
    <td>
    <div id="biblia_facil_01">
        <div>
            <div id="testamento">
                <br>
                    </div>
            <div id="livro">
                 Livro:<br>
            <?php echo $this->lists['livro'];?>
            </div>
        
            <div id="capitulo">
                Cap.<br>
                <input type="text" class="capitulo" size="03" maxlength="2" name="capitulo" value="<?php echo $this->lists['capitulo'];?>">
            </div>
    
            <div id="versiculo">
                Vers.<br>
                <input type="text" class="versiculo" size="03" maxlength="2" name="versiculo" value="<?php echo $this->lists['versiculo'];?>">
            </div>
    
            <div id="button_buscar">
                <br>
                <button onclick="this.form.submit();"><?php echo
                        JText::_('Buscar'); ?></button>
            </div>
        </div>
    </div>
    </td>
    </tr>

    <div id="radio_button">
        <div id="search_radio_button">
    <tr>
            <td  class="radio_button">
                Frase Exata:<br>
            <?php     
                echo $this->lists['tipo_de_pesquisa'];
            ?>
            </td>
    </tr>

    <tr>
    <td>

    <div id="biblia_facil_02">
        <div id="search_versiculos">
            Palavra:<br>
            <input type="text" name="filter_search" id="search_versiculos" 
                value="<?php echo $this->lists['search'];?>" 
                class="pesquisa_versiculos" />

            <button onclick="this.form.submit();"><?php echo                     
                JText::_('Buscar'); ?></button>
<input type="button" value="Limpar" onClick="javascript: submeteForm('<?php echo $link_limpar;?>')" />
        </div>
    </div>

    </td>

    </tr>
    </table>

    <div id="biblia_facil_03">
        <div>

        <?php 
        $session =& JFactory::getSession();
        $guardado = $session->get( 'myvar', 'empty' );
        $funcao = JRequest::getVar('funcao', '');
        ?>
        <input type="button" value="Gravar" onClick="javascript: submeteForm('<?php echo $link_gravar;?>')" />
        <?php 
        $session =& JFactory::getSession();
        $guardado = $session->get( 'myvar', 'empty' );
        if (($guardado != 'empty') && ($guardado != '') && ($guardado != Array()))
        {
            $funcao = JRequest::getVar('funcao');
            if (($funcao == "ler") || ($funcao == "apagarselecao"))
            {
    
            ?>
            <input type=button value="Apagar Seleção" onClick="javascript: submeteForm('<?php echo $link_apagarselecao;?>');" />
        
            <?php 
            }
            ?>
            <input type="button" value="Apagar Tudo" onClick="javascript: submeteForm('<?php echo $link_apagar;?>');" />
    
            <?php 
            $funcao = JRequest::getVar('funcao');
            if (($funcao != "ler") && ($funcao != "apagarselecao"))
            {
            ?>
    
            <input type="button" value="Ler" onClick="javascript: submeteForm('<?php echo $link_ler;?>');" />
            <?php
            }
        }
        ?>
        </div>
    </div>

    <div>
            <table>
            <tr>
            <td colspan="5">

            <input type="checkbox" class="title" name="toggle"
                    value="" onclick="checkAll(<?php 
                $items = count( $this->lista  ); 
                $items += 1;
                echo $items?>);" />

            <b>Livro:</b>
            </td>
            </tr>


            <?php 
                $i = 0;
                foreach($this->lista as $l): 
            ?>
                <tr>
                    <td>
                    <?php
                    $id = JHTML::_('grid.id', ++$i, $l->id);
                    echo $id;
                    ?>
                    </td>
    

                    <td >
                    <span class="biblia_facil_link">

                    <a href="<?php echo $l->link; ?>">

                    <?php echo  $l->livro; ?>

                    </a>
                    </span>
                    </td>

                    <td >
                    <span class="biblia_facil_link">

                    <a href="<?php echo $l->link; ?>">

                    <?php echo  $l->capitulo . ":" .$l->versiculo; ?>

                    </a>
                    </span>
                    </td>
    
                    <td>
                    <span class="biblia_facil_palavra">
                    <?php echo $l->palavra; ?>
                    </span>
                    </td>
                </tr>
            <?php endforeach; ?>
                </table>
       </div>
    </div>

    <div id="biblia_facil_06">
        <div class="biblia_facil_reposta">
            <?php 
    
            if ($this->total < 1)
            {
                echo "Sua pesquisa não encontrou nenhum Versículo.";
            }
            elseif ($this->total == 1)
            {
                echo  "Encontrado <b>0" . $this->total . "</b> - Versículo";
            }
            elseif($this->total < 10)
            {
                echo  "Encontrados <b>0" . $this->total . "</b> - Versículos";
            }
            else
            {
                echo "Encontrados <b>" . $this->total . "</b> - Versículos";
            }
            ?>
        </div>
    </div>

    <div id="biblia_facil_07">
        <div class="biblia_facil_pagination">
            <?php 
            echo  $this->pagination->getListFooter(); 
            ?>
        </div>
    </div>

    <div id="biblia_facil_08">
        <div class="biblia_facil_footer">
            Created by <a href="http://www.estudobiblico.org/" target="_blank">Estudo Bíblico!</a><br>
            <a href="http://www.ferax.inf.br" target="_blank"></a><br>
            <a href="http://www.semearsaude.com.br" target="_blank"></a>
            <input type="hidden" name="limitstart" value="">
            <input type="hidden" name="limitstart_gravar" value="<?php echo $this->limitstart;?>">
            <input type="hidden" name="boxchecked" value="0">
            <input type="hidden" name="task" value="0">
        </div>
    </div>
</div>
</form>

</td>
</tr>
</table>