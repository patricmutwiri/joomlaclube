INSERT INTO `jos_biblia_versiculos` (`id`, `testamento`, `livroseq`, `livro`, `capitulo`, `versiculo`, `palavra`, `published`, `hits`) VALUES 
(NULL, 'N', 63, '2Jo', 1, 1, 'O PRESBÍTERO à senhora eleita, e a seus filhos, aos quais amo na verdade, e não somente eu, mas também todos os que têm conhecido a verdade,\r\n', 1, 0),
(NULL, 'N', 63, '2Jo', 1, 2, 'Por amor da verdade que está em nós, e para sempre estará conosco:\r\n', 1, 0),
(NULL, 'N', 63, '2Jo', 1, 3, 'Graça, misericórdia e paz, da parte de Deus Pai e da do Senhor Jesus Cristo, o Filho do Pai, seja convosco na verdade e amor.\r\n', 1, 0),
(NULL, 'N', 63, '2Jo', 1, 4, 'Muito me alegro por achar que alguns de teus filhos andam na verdade, assim como temos recebido o mandamento do Pai.\r\n', 1, 0),
(NULL, 'N', 63, '2Jo', 1, 5, 'E agora, senhora, rogo-te, não como se escrevesse um novo mandamento, mas aquele mesmo que desde o princípio tivemos: que nos amemos uns aos outros.\r\n', 1, 0),
(NULL, 'N', 63, '2Jo', 1, 6, 'E o amor é este: que andemos segundo os seus mandamentos. Este é o mandamento, como já desde o princípio ouvistes, que andeis nele.\r\n', 1, 0),
(NULL, 'N', 63, '2Jo', 1, 7, 'Porque já muitos enganadores entraram no mundo, os quais não confessam que Jesus Cristo veio em carne. Este tal é o enganador e o anticristo.\r\n', 1, 0),
(NULL, 'N', 63, '2Jo', 1, 8, 'Olhai por vós mesmos, para que não percamos o que temos ganho, antes recebamos o inteiro galardão.\r\n', 1, 0),
(NULL, 'N', 63, '2Jo', 1, 9, 'Todo aquele que prevarica, e não persevera na doutrina de Cristo, não tem a Deus. Quem persevera na doutrina de Cristo, esse tem tanto ao Pai como ao Filho.\r\n', 1, 0),
(NULL, 'N', 63, '2Jo', 1, 10, 'Se alguém vem ter convosco, e não traz esta doutrina, não o recebais em casa, nem tampouco o saudeis.\r\n', 1, 0),
(NULL, 'N', 63, '2Jo', 1, 11, 'Porque quem o saúda tem parte nas suas más obras.\r\n', 1, 0),
(NULL, 'N', 63, '2Jo', 1, 12, 'Tendo muito que escrever-vos, não quis fazê-lo com papel e tinta; mas espero ir ter convosco e falar face a face, para que o nosso gozo seja cumprido.\r\n', 1, 0),
(NULL, 'N', 63, '2Jo', 1, 13, 'Saúdam-te os filhos de tua irmã, a eleita. Amém.\r\n', 1, 0);
