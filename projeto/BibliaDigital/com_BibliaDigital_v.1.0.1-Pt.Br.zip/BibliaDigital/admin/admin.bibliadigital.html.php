<?php
/**
 * @version		$Id: admin.bibliadigital.html.php 10381 2009-01-12 11:55:53Z pasamio $
 * @package		Joomla
 * @author	        Ferax Informatica - http://www.ferax.inf.br.
 * @subpackage	Biblia Digital
 * @copyright	Copyright (C) 2009 Estudo Bíblico - http://www.estudobiblico.org. All rights reserved.
 * @license	GNU/GPL, see LICENSE.php

 * Biblia Digital is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

defined( '_JEXEC' ) or die ( 'Acesso Restrito' );
class HTML_versiculos
{
    function showBiblia_Digital( $option )
    {
        ?>
            <div class="header">Bíblia Digital</div>
    <div class="corpo" align="justify">
    <p>
    O componente <b>Bíblia Digital</b> para Joomla 1.5 é freeware sendo permitidas a cópia e a redistribuição livre e Gratuita deste software, desde que <b>não sejam retirados</b> os devidos créditos que se resumem ao link <a href="http://www.estudobiblico.org">Created by Estudo Bíblico!</a>
    </p>
    <p>
    Com o intuito de atender aqueles que desejam uma Bíblia Digital em seus Portais em Joomla 1.5, o <a href="http://www.estudobiblico.org">Portal Estudo Bíblico</a> disponibiliza aos seus associados o módulo para Joomla 1.5 a Bíblia Sagrada na versão Digital (Almeida Corrigida e fiel - ACF) com recursos de busca por palavra(s) em todos os livros da Bíblia ou em parâmetros pré-estabelecidos pelo usuário e gravação de versísulos em "cookies" para faciliar uma futura localização dos livros e versículos bíblicos.
    </p>
    <p>
    A Bíblia Digital contém o Antigo e o Novo Testamento na versão Almeida Corrigida Fiel (ACF). 
    </p>
    <p>
    Sentindo-se beneficiado ao utilizar este componente, por favor, ore por nosso ministério e, se possível, contribua conosco.  Caso não deseje deixar em seu portal os devidos créditos, entre em contato conosco acessando o <a href="http://www.estudobiblico.org">Portal Estudo Bíblico</a>.
    </p>
    
    <p>
    Tradução
    Almeida Corrigida Fiel - Todos os direitos reservados à Sociedade Bíblica Trinitariana (ACF).
    
    Este texto poderá ser reimpresso ou citado até 1.100 (mil e cem) versículos sem permissão da Sociedade Bíblica Trinitariana do Brasil (TBS), desde que não formem um livro completo da Bíblia, nem representem cinqüenta por cento da obra que os esteja mencionando. Referência aos direitos de publicação deve aparecer na página adequada da seguinte forma: Citações da Bíblia da Sociedade Bíblica Trinitariana do Brasil (ACF), © 1994 1995, 1996, 1997. Novo Testamento © 1979-1997.
    
    As citações da Bíblia SBTB nos meios informativos internos, tais como boletins de igreja, programas de reunião, cartazes, transparências e outros meios semelhantes, devem envolver apenas o uso das iniciais (ACF) ao final de cada citação, identificando o reconhecimento dos direitos de publicação.
    Acima daquele limite de 1.100 versículos, a autorização prévia deverá ser solicitada por escrito à Sociedade Bíblica Trinitariana do Brasil.
    </p>
    <p>
    Claudio Crispim
    </p>
    <div class="moduletable">
					<h3>Doações</h3>
            <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
            <input type="hidden" name="cmd" value="_donations">
            <input type="hidden" name="business" value="claudio.crispim@gmail.com">
            <input type="hidden" name="item_name" value="Faça uma doação ao Portal Estudo Bíblico">
            <input type="hidden" name="no_shipping" value="0">
            <input type="hidden" name="no_note" value="1">
            <input type="hidden" name="currency_code" value="USD">
            <input type="hidden" name="tax" value="0">
            <input type="hidden" name="bn" value="PP-DonationsBF">
            <input type="image" src="https://www.paypal.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
            <img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
            
            </form>		
    </div>

    <p>
    <br>Componente desenvolvido por <a href="http://www.ferax.inf.br">Ferax Informática</a> dentro dos padrões MVC Joomla!.
    </p>
    </div>

<?php

    }
}
?>