-- # @version		$Id: install.mysql.sql 10381 2009-01-12 11:55:53Z pasamio $
-- # @package		Joomla
-- # @author	        Ferax Informatica - http://www.ferax.inf.br.
-- # @subpackage	Biblia Digital
-- # @copyright	Copyright (C) 2009 Estudo Bíblico - http://www.estudobiblico.org. All rights reserved.
-- # @license	GNU/GPL, see LICENSE.php
-- 
-- # Biblia Digital is free software. This version may have been modified pursuant to the
-- # GNU General Public License, and as distributed it includes or is derivative
-- # of works licensed under the GNU General Public License or other free or open
-- # source software licenses. See COPYRIGHT.php for copyright notices and
-- # details.

CREATE TABLE IF NOT EXISTS `#__biblia_livros` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `livro` varchar(5) NOT NULL,
    `livro_desc` varchar(40) NOT NULL,
    `livro_seq` smallint(3) NOT NULL,
    `published` tinyint(1) NOT NULL default '1',
    PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `#__biblia_versiculos` (
  `id` int(5) NOT NULL auto_increment,
  `testamento` varchar(6) NOT NULL,
  `livroseq` smallint(3) NOT NULL default '0',
  `livro` varchar(40) NOT NULL,
  `capitulo` smallint(3) NOT NULL default '0',
  `versiculo` smallint(3) NOT NULL default '0',
  `palavra` text NOT NULL,
  `published` tinyint(1) NOT NULL default '1',
  `hits` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)


