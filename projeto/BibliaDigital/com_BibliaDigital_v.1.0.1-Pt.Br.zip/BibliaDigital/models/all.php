<?php
/**
 * @version		$Id: all.php 10381 2009-01-12 11:55:53Z pasamio $
 * @package		Joomla
 * @author	        Ferax Informatica - http://www.ferax.inf.br.
 * @subpackage	Biblia Digital
 * @copyright	Copyright (C) 2009 Estudo Bíblico - http://www.estudobiblico.org. All rights reserved.
 * @license	GNU/GPL, see LICENSE.php

 * Biblia Digital is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

defined( '_JEXEC' ) or die ( 'Acesso Restrito' );
jimport( 'joomla.application.component.model' );

class ModelBibliaDigitalAll extends JModel
{

    var $_id;
    var $_total = null;
    var $_pagination = null;
    var $_versiculos = null;
    var $_livro = null;

    function _buildQuery()
    {
        $funcao = JRequest::getVar( 'funcao');
        $session =& JFactory::getSession();
        $cid = JRequest::getVar( 'cid', array(0), '', 'array' );

        switch ($funcao)
        {

            case 'apagar':
                $guardado = $session->set( 'myvar', 'empty' );
            case 'apagarselecao':
                $solicitado = array();
                $sliced = array();

                $guardado = $session->get( 'myvar', 'empty' );
                if($guardado !== 'empty')
                {
                    $sliced = array_diff($guardado, $cid);
                    $guardado = $session->set( 'myvar', $sliced);
                }
            case 'ler':

                $guardado = $session->get( 'myvar', 'empty' );
                if (($guardado != 'empty') && ($guardado != '') && ($guardado != Array()))
                {

                    $cids = implode( ',', $guardado);
                    $query = "SELECT * FROM #__biblia_versiculos WHERE id IN ( $cids ) AND published = 1";

                    return $query;
                }else{

                    $query = 'SELECT * FROM #__biblia_versiculos ' .
                                        $this->_buildQueryWhere();
                    return $query;
                }
            break;

            default:
                global $mainframe, $option;
                $livro = $mainframe->getUserStateFromRequest($option.'livro','');
                if ($livro == "")
                {
                    $livro = rand(1,66);
                    $livro = $mainframe->setUserState($option.'livro', $livro);
                }

                $query = 'SELECT * FROM #__biblia_versiculos ' .
                                    $this->_buildQueryWhere();

            return $query;
            break;
        }
    }

    function _buildQueryWhere()
    {
        global $mainframe, $option;
        $query = ' WHERE published = 1';

        $livro = $mainframe->getUserStateFromRequest($option.'livro','livro');

        $filter_search = $mainframe->getUserStateFromRequest($option.'filter_search', '');
        $livro_seq = $mainframe->getUserStateFromRequest($option.'livroseq','');
        $capitulo = $mainframe->getUserStateFromRequest($option.'capitulo', '');
        $versiculo = $mainframe->getUserStateFromRequest($option.'versiculo', '');

        switch ($livro)
        {

        // Determina o Testamento
            case '':
            case '99':

            break;

            case '00':
                $query = $query . " AND testamento = 'O'";
            break;

            case '100':
                $query = $query . " AND testamento = 'N'";
            break;

        // Determina o Livro
            default:
                if (is_numeric($livro))
                {
                    $query = $query . ' AND livroseq = ' . "'" . $livro . "'";
                }
        }

        // Determina o Capitulo
        if ($capitulo != "")
        {
            if (is_numeric($capitulo))
            {
                $query = $query . ' AND capitulo = ' .  $capitulo;
            }else{
                echo "O valor para capítulo deve ser numérico.";
            }
        }

        if ($versiculo != "")
        {
            if (is_numeric($versiculo))
            {
                $query = $query . ' AND versiculo  >= ' .  $versiculo;
            }else{
                echo "O valor para versículo deve ser numérico.";
            }
        }

        // Determine search terms
        if ($filter_search)
        {
            $filter_search = JString::strtolower($filter_search);
            $db =& $this->_db;
            $filter_search = $db->getEscaped($filter_search);

            $tipo_de_pesquisa = $mainframe->getUserStateFromRequest($option.'tipo_de_pesquisa', '');

            if ($tipo_de_pesquisa == '1')
            {
                $filter_search = trim($filter_search);
                $query = $query . ' AND LOWER(palavra) LIKE "%'.$filter_search.'%"';
            }
            else
            {
                $words = explode( ' ', $filter_search );
                $queries = array();
                $search_andor  = JRequest::getVar('search_andor');
                if ($search_andor = "Cada_Palavra")
                {
                    $andor = ' OR ';
                }else{
                    $andor = ' AND ';
                }

                foreach ($words as $word) {
                $word  = $db->Quote( '%'.$db->getEscaped( $word, true ).'%', false );
                $queries[] = ' LOWER(palavra) LIKE '.$word;
                }
                $filter_search  = $db->Quote( '%'.$db->getEscaped( $filter_search, true ).'%', false );
                $query = $query . ' AND (LOWER(palavra) LIKE '.$filter_search ;
                $query = $query . $andor; 

                $query = $query . implode( "$andor" , $queries );
                $query = $query . ")";
            }

        }

        return $query;
    }


    function getList()
    {
        if(!$this->_versiculos)
        {
            $query = $this->_buildQuery();
            $limitstart = $this->getState('limitstart');
            $limit = $this->getState('limit');
    
            $this->_versiculos = $this->_getList($query, $limitstart, $limit);
        }
        return $this->_versiculos;
    }


    /**
    * 
    * Constructor
    * 
    */
    function __construct()
    {
        parent :: __construct();
        global $mainframe, $option;

        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'));

        if ($limit == 0) 
        {
            $limit = 20;
        }

        $limitstart = $mainframe->getUserStateFromRequest($option.'.limitstart', 'limitstart', 0);

        $funcao = JRequest::getVar('funcao');

        $limitstart = $mainframe->getUserStateFromRequest($option.'.limitstart', 'limitstart', 0);

        $limitstart = JRequest::getVar('limitstart',0);

        $limitstart_gravar = JRequest::getVar('limitstart_gravar','');
        if($funcao == 'gravar')
        {
            if($limitstart_gravar != "")
            {
                $limitstart = $limitstart_gravar;
            }
        }
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);

        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);

    }

    function getTotal()
    {
            // Load the content if it doesn't already exist
            if (empty($this->_total)) {
                $query = $this->_buildQuery();
                $this->_total = $this->_getListCount($query);	
            }
            return $this->_total;
    }

    
    function getLimit()
    {
            return $this->getState('limit');
    }

    function getLimitstart()
    {
            return $this->getState('limitstart');
    }
    
    function getPagination()
    {
            // Load the content if it doesn't already exist
            if (empty($this->_pagination)) {
                jimport('joomla.html.pagination');
                $option = JRequest::getVar('option');
                $total = $this->getTotal();
                $limitstart = $this->getState('limitstart');
                $limit = $this->getState('limit');
            
                $this->_pagination = new JPagination($total, $limitstart, $limit);
            }
            return $this->_pagination;
    }
}
?>