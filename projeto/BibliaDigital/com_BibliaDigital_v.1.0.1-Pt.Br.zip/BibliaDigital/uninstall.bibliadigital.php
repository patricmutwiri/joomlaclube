<?php
/**
 * @version		$Id: uninstall.bibliadigital.php 10381 2009-01-12 11:55:53Z pasamio $
 * @package		Joomla
 * @author	        Ferax Informatica - http://www.ferax.inf.br.
 * @subpackage	Biblia Digital
 * @copyright	Copyright (C) 2009 Estudo Bíblico - http://www.estudobiblico.org. All rights reserved.
 * @license	GNU/GPL, see LICENSE.php

 * Biblia Digital is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

defined( '_JEXEC' ) or die( 'Acesso Restrito' );
function com_uninstall()
{
    ?>
    <div class="header">Bíblia Digital</div>
    <p>
    O componente Bíblia Digital foi removido com sucesso.
    </p>
    <?php
}
?>