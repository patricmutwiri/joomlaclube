<?php
/** ensure this file is being included by a parent file */
defined('_JEXEC') or die('Restricted access');

$GLOBALS["users"]=array(
	array("admin","9628d0d187029e6337baa86780b2abb6",".","http://localhost",1,"",7,1),
); ?>
