<?php
/**
* @version $Id: install.joomlaxplorer.php 37 2007-06-22 07:58:06Z soeren $
* @package joomlaXplorer
* @copyright (C) 2005-2007 Soeren
* @license GNU / GPL
* @author soeren
* joomlaXplorer is Free Software
*/
###################################################################
/* Ninja Xplorer
* By Richie Mortimer
* http://www.ninjoomla.com 
* Copyright (C) 2008 Richie Mortimer www.ninjoomla.com - Code so sharp, it hurts.
* email: Richie@ninjaforge.com
* date: April 2008
* Release: 1.0
* License : http://www.gnu.org/copyleft/gpl.html GNU/GPL 
*
* Changelog
* v1.0
* Joomla! 1.5 Native
*       
* 
*/
###################################################################
//Ninja Xplorer
//Copyright (C) 2007 Richie Mortimer. Ninjoomla.com. All rights reserved.
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either version 2
//of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
###################################################################
defined('_JEXEC') or die('Restricted access');
function com_install(){
	/*global $database;

	$database->setQuery( "SELECT id FROM #__components WHERE admin_menu_link = 'option=com_ninjaxplorer'" );
	$id = $database->loadResult();

	//add new admin menu images
	$database->setQuery( "UPDATE #__components SET admin_menu_img = '../administrator/components/com_ninjaxplorer/images/ninja_x_icon.png', admin_menu_link = 'option=com_ninjaxplorer' WHERE id=$id");
	$database->query();*/
}
?>