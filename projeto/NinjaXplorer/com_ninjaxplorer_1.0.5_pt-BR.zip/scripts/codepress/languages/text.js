/*
 * CodePress regular expressions for Text syntax highlighting
 */

// plain text
Language.syntax = []
Language.snippets = []
Language.complete = []
Language.shortcuts = []
