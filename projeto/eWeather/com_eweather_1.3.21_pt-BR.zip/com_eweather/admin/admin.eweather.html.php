<?php
/**
 * This file contains the routines that display the administrator
 *  screens for the eWeather component.
 *
 * This file is part of eWeather.
 *
 *   eWeather is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   eWeather is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with eWeather.  If not, see <a href="http://www.gnu.org/licenses/">
 *   http://www.gnu.org/licenses/</a>.
 *
 * <b>Modifications:</b><br/>
 * aangepast door Mart Dirks<br/>
 * converted to Joomla! 1.5.x by Bob Lavey
 *
 * @version $Id: admin.eweather.html.php 276 2009-08-20 13:18:21Z rjlavey $
 * @package eWeather
 * @subpackage Admin eWeather
 * @copyright Copyright (c) 2000 - 2006 MamboBaer.de (Harald Baer),
 *            2009 Bob Lavey<br/>
 * @license http://www.gnu.org/licenses/gpl.txt GNU/GPL
 * @toto Break this into additional classes: AdminWeatherConfigurationForm,
 *        AdminWeatherInstalledLocationsForm, and AdminWeatherInfoForm.
 */


/* ensure this file is being called by Joomla! */
defined('_JEXEC') or die('Direct Access to this location is not allowed.');


/**
 * The AdminWeatherInstalledLocations class abstracts the currently-installed
 *  locations and allows the administrator to add and remove locations.
 *
 * @package eWeather
 * @subpackage Admin eWeather
 */
class HTML_eweather{

  function showInstLocations($option, &$lists){
    $url = JUri::base(true);

    $content = "<form action=\"index2.php?option=com_eweather\" method=\"post\" name=\"adminForm\">\n"
              ."  <table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n"
              ."    <tr>\n"
              ."      <td width=\"100%\" style=\"border-bottom: 1px solid #CCCCCC;\" width=\"100%\">\n"
              ."        <div class=\"LocationManagerHeader\">Install Location</div>\n"
              ."      </td>\n"
              ."    </tr>\n"
              ."  </table>\n"
              ."  <br />\n"
              ."  <table width=\"30%\">\n"
              ."    <tr><td>\n"
              ."      <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"adminlist\">\n"
              ."        <tr>\n"
              ."          <th colspan=\"2\" align=\"center\">".JText::_('EWEATHER_LOC_DATA')."</th>\n"
              ."        </tr>\n"
              ."        <tr>\n"
              ."          <td width=\"30%\">\n"
              ."            ".JText::_('EWEATHER_REGION')
              ."          </td>\n"
              ."          <td>\n"
              ."            :&nbsp;".$lists['regions']
              ."          </td>\n"
              ."        </tr>\n"
              ."        <tr>\n"
              ."          <td width=\"30%\">\n"
              ."            ".JText::_('EWEATHER_COUNTRY')
              ."          </td>\n"
              ."          <td>\n"
              ."            :&nbsp;".$lists['countries']
              ."          </td>\n"
              ."        </tr>\n"
              ."      </table>\n"
              ."    </td></tr>\n"
              ."  </table>\n"
              ."  <input type=\"hidden\" name=\"option\" value=\"$option\">\n"
              ."  <input type=\"hidden\" name=\"task\" value=\"instLocation\">\n"
              ."</form>\n";

    echo $content;
  }

  function showLocation($option, $list){
    $url = JUri::base(true);

    $content = "<form action=\"index2.php?option=com_eweather\" method=\"post\" name=\"adminForm\">\n"
              ."  <table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n"
              ."    <tr>\n"
              ."      <td width=\"100%\">\n"
              ."        <div class=\"LocationManagerHeader\">Install Location</div>\n"
              ."      </td>\n"
              ."    </tr>\n"
              ."  </table>\n"
              ."  <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"adminlist\">\n"
              ."    <tr>\n"
              ."      <th colspan=\"2\" align=\"left\">".JText::_('EWEATHER_REGION')."&nbsp;/&nbsp;".JText::_('EWEATHER_COUNTRY')."</th>\n"
              ."    </tr>\n"
              .$list
              ."    <tr>\n"
              ."      <th colspan=\"2\">&nbsp;</th>\n"
              ."    </tr>\n"
              ."  </table>\n"
              ."  <input type=\"hidden\" name=\"option\" value=\"$option\">\n"
              ."  <input type=\"hidden\" name=\"task\" value=\"\">\n"
              ."</form>\n";

    echo $content;
  }

  function showCountry($option, $list, $count, $country){
    $url = JUri::base(true);

    $content = "<form action=\"index2.php?option=com_eweather\" method=\"post\" name=\"adminForm\">\n"
              ."  <table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n"
              ."    <tr>\n"
              ."      <td width=\"100%\">\n"
              ."        <div class=\"LocationManagerCitiesListHeader\">Cities</font>\n"
              ."      </td>\n"
              ."    </tr>\n"
              ."  </table>\n"
              ."  <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"adminlist\">\n"
              ."    <tr>\n"
              ."      <th width=\"1%\"><input type=\"checkbox\" name=\"toggle\" value=\"\" onclick=\"checkAll(".$count.");\" /></th>\n"
              ."      <th align=\"left\">".$country."</th>\n"
              ."      <th align=\"left\">".JText::_('EWEATHER_CITY_CODE')."</th>\n"
              ."      <th align=\"left\">".JText::_('EWEATHER_COUNTRY')."</th>\n"
              ."      <th align=\"left\">".JText::_('EWEATHER_REGION')."</th>\n"
              ."    </tr>\n"
              .$list
              ."    <tr>\n"
              ."      <th colspan=\"5\">&nbsp;</th>\n"
              ."    </tr>\n"
              ."  </table>\n"
              ."  <input type=\"hidden\" name=\"option\" value=\"$option\">\n"
              ."  <input type=\"hidden\" name=\"task\" value=\"\">\n"
              ."  <input type=\"hidden\" name=\"boxchecked\" value=\"0\" />\n"
              ."</form>\n";

    echo $content;
  }

  }

?>