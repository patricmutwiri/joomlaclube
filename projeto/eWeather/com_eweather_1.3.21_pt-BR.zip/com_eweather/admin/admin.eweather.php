<?php
/**
 * This file contains helper routines for the administrator
 *  screens for the eWeather component.
 *
 * This file is part of eWeather.
 *
 *   eWeather is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   eWeather is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with eWeather.  If not, see <a href="http://www.gnu.org/licenses/">
 *   http://www.gnu.org/licenses/</a>.
 *
 * <b>Modifications:</b><br/>
 * aangepast door Mart Dirks<br/>
 * converted to Joomla! 1.5.x by Bob Lavey
 *
 * @version $Id: admin.eweather.php 310 2009-11-11 16:56:02Z rjlavey $
 * @package eWeather
 * @subpackage Admin eWeather
 * @copyright Copyright (c) 2000 - 2006 MamboBaer.de (Harald Baer),
 * 			  2007 Mart Dirks,<br/>
 *            2009 Bob Lavey<br/>
 * @license http://www.gnu.org/licenses/gpl.txt GNU/GPL
 * @toto Break this into additional classes: AdminWeatherConfigurationForm,
 *        AdminWeatherInstalledlocationForm, and AdminWeatherInfoForm.
 */

/* ensure this file is being called by Joomla! */
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

$url = JUri::base(true);
$app = &JFactory::getApplication();

require_once($app->getPath('admin_html'));
require_once(JPATH_ADMINISTRATOR.DS."components/com_eweather/AdminWeatherConfiguration.php");

// determine the action which helps to determine the final task
if (!empty($act)){
   $table = $act;
}
elseif (empty($table)){
   $table = "sessions";
}

$adminConfigForm = new AdminWeatherConfigurationForm();

switch ($task) {
    case "instLocation":
    	 //InstallAllLocations();
         instLocation($option);
         break;
    case "allLocations":
         showLocations($option);
         break;
    case "showConfig":
         $adminConfigForm->showConfig($option);
         break;
   case "saveConfiguration":
        $adminConfigForm->saveConfiguration($option);
        break;
    case "saveInstLocation":
        saveInstLocation($option);
        break;
    case "removeCity":
         removeCity($option);
         break;
    case "showCountry":
         showCountry($option);
         break;
    case "about":
         showInfo($option);
         break;

    default:
        showLocations($option);
        break;
}

function saveInstLocation($option) {
	$database = &JFactory::getDBO();
	$app = &JFactory::getApplication();
	$lang = &JFactory::getLanguage();

	$locationFileDir = JPATH_ADMINISTRATOR.DS."components/com_eweather/locationData/";
	$langTag = $lang->getTag();
	
	$conf_filter_region    = JRequest::getVar('filter_new_region', 'Africa', 'post');
	$conf_filter_countries = JRequest::getVar('filter_new_countries', '', 'post');

	$sql = "SELECT * FROM `#__eweather_prefs` WHERE `region` = '".$conf_filter_region."' AND `country` = '".$conf_filter_countries."'";
    $database->setQuery($sql);
    $new_country = $database->loadObject();

    $localizedLocationFileName = $new_country->loc_id.".".$langTag.".php";
	$defaultLocationFileName = $new_country->loc_id.".php";
    
    if (file_exists($locationFileDir.$localizedLocationFileName))
    {
        include_once($locationFileDir.$localizedLocationFileName);
        $foundLocationFile = true;
    }
    else if (file_exists($locationFileDir.$defaultLocationFileName))
    {
        include_once($locationFileDir.$defaultLocationFileName);
        $foundLocationFile = true;
    }
    else
    {
    	$foundLocationFile = false;
    }
    
    if ($foundLocationFile)
    {
        $cityCount = 0;
	    if (count($city_data) > 0)
	    {
            foreach ($city_data as $city)
            {
                $sql_select_city = "SELECT * FROM `#__eweather_locations` WHERE `city` = '".$city['name']."' AND `country` = '".$conf_filter_countries."' AND `region` = '".$conf_filter_region."' AND `loc_id` = '".$city['accid']."'\r\n";
				$database->setQuery($sql_select_city);
				$tempCity = NULL;
				$tempCity = $database->loadObject();
				if ($tempCity == NULL)
				{
					$sql_add = "INSERT INTO `#__eweather_locations` (`id`, `city`, `country`, `region`, `loc_id`) VALUES ('', '".$city['name']."', '".$conf_filter_countries."', '".$conf_filter_region."', '".$city['accid']."');\r\n";
					$database->setQuery($sql_add);
					$result = $database->query();
					$cityCount++;
				}
			}
			$cities = "cities";
			if (cityCount == 1)
			{
				$cities = "city";
			}
            $mosmsg = "Location File for ".$conf_filter_countries." installed.  $cityCount $cities added.";
	    }
		else
		{
            $mosmsg = "Location File for ".$conf_filter_countries." not installed: no cities found.";
		}
    }
    else
    {
        $mosmsg = "Could not find location file ".$localizedLocationFileName." or ".$defaultLocationFileName." for ".$conf_filter_countries."<br>";
    }

    $app->redirect("index2.php?option=$option&task=allLocations", $mosmsg);
}

function instLocation($option){
  $database = &JFactory::getDBO();
  $app = &JFactory::getApplication();

  $conf_filter_region    = JRequest::getVar('filter_new_region', 'Africa', 'post');
  $conf_filter_countries = JRequest::getVar('filter_new_countries', '', 'post');

  $tempregion  = array();
  $tempcountry = array();

  //
  // create regions list
  //
  $sql = "SELECT `region` FROM `#__eweather_prefs` GROUP BY `region` ORDER BY `region` ASC";
  $database-> setQuery($sql);
  $regions = $database -> loadObjectList();
  foreach($regions as $region){
    $tempregion[] = JHTML::_('select.option', $region->region , $region->region, 'value', 'text' );
  }
  $lists['regions'] = JHTML::_('select.genericlist', $tempregion, 'filter_new_region', 'class="inputbox" size="1" onchange="document.adminForm.submit( );"', 'value', 'text', $conf_filter_region);

  //
  // create countries list
  //
  $sql = "SELECT `country` FROM `#__eweather_prefs` WHERE `region` = '".$conf_filter_region."' GROUP BY `country` ORDER BY `country` ASC";
  $database-> setQuery($sql);
  $countries = $database -> loadObjectList();
  foreach($countries as $country){
    $tempcountry[] = JHTML::_('select.option', $country->country , $country->country, 'value', 'text' );
  }
  $lists['countries'] = JHTML::_('select.genericlist', $tempcountry, 'filter_new_countries', 'class="inputbox" size="1" onchange="document.adminForm.submit( );"', 'value', 'text', $conf_filter_countries);

  HTML_eweather::showInstLocations($option, $lists);
}

function removeCity($option){
  $app = &JFactory::getApplication();
  $database = &JFactory::getDBO();

  $cities = JRequest::getVar('city_list', '');
  if (is_array($cities)){
     foreach ($cities as $city){
             $database->setQuery("DELETE FROM `#__eweather_locations` WHERE `id` = '".$city."'");
             $database->query();
     }
  }
  $app->redirect("index2.php?option=$option", $mosmsg);
}

function showLocations($option){
  $database = &JFactory::getDBO();

  $sql = "SELECT `region`,`country`,COUNT(`city`) AS city_count FROM `#__eweather_locations` GROUP BY `country` ORDER BY `region`, `country` ASC";
  $database->setQuery($sql);
  $regions = $database->loadObjectList();
  $tmp_region = "";
  $list = "";
  foreach ($regions as $region){
          if ($tmp_region <> $region->region){
             $list.= "<tr>\n"
                    ."  <td style=\"font-weight: bold; background: url('components/com_eweather/assets/images/region_title.png');\">".$region->region."</td>\n"
                    ."  <td style=\"font-weight: bold; background: url('components/com_eweather/assets/images/region_title.png');\">&nbsp;</td>\n"
                    ."</tr>\n"
                    ."<tr>\n"
                    ."  <td style=\"text-indent: 20px;\"><a href=\"index2.php?option=com_eweather&task=showCountry&country=".$region->country."\">".$region->country."&nbsp;(".$region->city_count.")</a></td>\n"
                    ."  <td align=\"right\" width=\"5%\">".$region->city_count."</td>\n"
                    ."</tr>\n";
             $tmp_region = $region->region;
          }else{
             $list.= "<tr>\n"
                    ."  <td style=\"text-indent: 20px;\"><a href=\"index2.php?option=com_eweather&task=showCountry&country=".$region->country."\">".$region->country."&nbsp;(".$region->city_count.")</a></td>\n"
                    ."  <td align=\"right\" width=\"5%\">".$region->city_count."</td>\n"
                    ."</tr>\n";
          }
  }
  HTML_eweather::showLocation($option, $list);
}

function showCountry($option){
  $database = &JFactory::getDBO();

  $country = JRequest::getVar('country', '');
  $sql = "SELECT * FROM `#__eweather_locations` WHERE `country` = '".$country."' ORDER BY `city` ASC";
  $database->setQuery($sql);
  $cities = $database->loadObjectList();
  $i = 0;
  $list = "";
  
  foreach ($cities as $city){
          $list.= "<tr>\n"
                 ."  <td width=\"1%\"><input type=\"checkbox\" id=\"cb".$i++."\" name=\"city_list[]\" value=\"".$city->id."\" onclick=\"isChecked(this.checked);\" /></td>\n"
                 ."  <td style=\"white-space: nowrap;\">".$city->city."</td>\n"
                 ."  <td width=\"5%\" style=\"white-space: nowrap;\">".$city->loc_id."</td>\n"
                 ."  <td width=\"5%\" style=\"white-space: nowrap;\">".$city->country."</td>\n"
                 ."  <td width=\"5%\" style=\"white-space: nowrap;\">".$city->region."</td>\n"
                 ."</tr>\n";
  }
  HTML_eweather::showCountry($option, $list, $i, $country);
}

function showInfo($option)
{
  echo "<form action=\"index2.php?option=com_eweather&amp;task=about\" method=\"post\" name=\"adminForm\">\n";
  echo "  <table border=\"0\" class=\"adminform\">\n";
  echo "    <tr>\n";
  echo "      <td>\n";
  echo "        <div style=\"text-align:left;\" >\n";
  require_once(JPATH_SITE.DS."/components/$option/eweather.info.html");
  echo "        </div>\n";
  echo "      </td>\n";
  echo "    </tr>\n";
  echo "  </table>\n";
  //echo "  <input type=\"hidden\" name=\"myRegion\" value=\"".$params->get('myRegion')."\">\n";
//  echo "  <input type=\"hidden\" name=\"option\" value=\"$option\">\n";
//  echo "  <input type=\"hidden\" name=\"task\" value=\"\">\n";
  echo "</form>\n";
}

class AdminWeatherConfigurationForm
{
	function AdminWeatherConfigurationForm()
	{
		$this->_adminCfg = & AdminWeatherConfiguration::getInstance();
	}

	var $_adminCfg = null;
	var $region_ = null;
	var $country_ = null;
	var $city_ = null;

	function showConfig($option)
	{
		$lists = $this->displayLocations();
		$this->listConfiguration($option, $lists);
	}

	function displayLocations()
	{
		$database = &JFactory::getDBO();

		$this->region_  = JRequest::getVar('filter_region', '', 'post');
		$this->country_ = JRequest::getVar('filter_country', '', 'post');
		$this->city_    = JRequest::getVar('filter_city', '', 'post');

		if (($this->region_ == "") AND ($this->country_ == "") AND ($this->city_ == ""))
		{
			$sql = "SELECT * FROM `#__eweather_locations` WHERE `loc_id` = '".$this->_adminCfg->getDefaultLocation()."'";
			$database->setQuery($sql);
			$locInfo = $database -> loadObject();

			if (count($locInfo) <> 0)
			{
				$this->region_ = $locInfo->region;
				$this->country_ = $locInfo->country;
				$this->city_ = $locInfo->city;
			}
		}

		//
		// create a list of all regions
		//
		$sql = "SELECT * FROM `#__eweather_locations` GROUP BY `region` ORDER BY `region` ASC";
		$database->setQuery($sql);
		$regions = $database -> loadObjectList();

		if (count($regions) <> 0)
		{
			foreach ($regions as $region)
			{
				$tempregion[] = JHTML::_('select.option', $region->region, $region->region, 'value', 'text' );
			}
		}
		else
		{
			$tempregion[] = JHTML::_('select.option', "", "", 'value', 'text' );
		}
		$lists['regions'] = JHTML::_('select.genericlist', $tempregion, 'filter_region', 'class="inputbox" size="1" onchange="document.adminForm.submit( );"', 'value', 'text', $this->region_);

		//
		// create a list of all the countries in the selected region
		//  (default to the first region in the list)
		//
		if ($this->region_ == "")
		{
			if (($regions != null) && ($regions[0] != null))
			{
				$this->region_ = $regions[0]->region;
			}
		}
		$sql = "SELECT * FROM `#__eweather_locations` WHERE `region` = '".$this->region_."' GROUP BY `country` ORDER BY `country` ASC";
		$database->setQuery($sql);
		$countries = $database->loadObjectList();

		if (count($countries) <> 0)
		{
			foreach ($countries as $country)
			{
				$tempcountry[] = JHTML::_('select.option', $country->country, $country->country, 'value', 'text' );
			}
		}
		else
		{
			$tempcountry[] = JHTML::_('select.option', "", "", 'value', 'text' );
		}
		$lists['countries'] = JHTML::_('select.genericlist', $tempcountry, 'filter_country', 'class="inputbox" size="1" onchange="document.adminForm.submit( );"', 'value', 'text', $this->country_);

		//
		// default the current country to the first country in the country list
		//
		if ($this->country_ == "")
		{
			if (($countries != null) && ($countries[0] != null))
			{
				$this->country_ = $countries[0]->country;
			}
		}
		//
		// if the current country doesn't exist in the region,
		//  reset it to the first country in the country list
		//
		else
		{
			$sql = "SELECT * FROM `#__eweather_locations` WHERE `region` = '".$this->region_."' AND `country` = '".$this->country_."'";
			$database->setQuery($sql);
			$testcountries = $database->loadObjectList();
			if (count($testcountries) == 0)
			{
				$this->country_ = $countries[0]->country;
			}
		}

		//
		// create a list of cities in the current country
		//
		$sql = "SELECT * FROM `#__eweather_locations` WHERE `region` = '".$this->region_."' AND `country` = '".$this->country_."' ORDER BY `city` ASC";
		$database->setQuery($sql);
		$cities = $database->loadObjectList();

		if (count($cities) <> 0)
		{
			foreach ($cities as $city)
			{
				$tempcity[] = JHTML::_('select.option', $city->city, $city->city, 'value', 'text' );
			}
		}
		else
		{
			$tempcity[] = JHTML::_('select.option', "", "", 'value', 'text' );
		}
		$lists['cities'] = JHTML::_('select.genericlist', $tempcity, 'filter_city', 'class="inputbox" size="1" onchange="document.adminForm.submit( );"', 'value', 'text', $this->city_);

		//
		// default the current city to the first city in the city list
		//
		if ($this->city_ == "")
		{
			if (($cities != null) && ($cities[0] != null))
			{
				$this->city_ = $cities[0]->city;
			}
		}

		//
		// if the current city doesn't exist in the country,
		//  reset it to the first city in the city list
		//
		else
		{
			$sql = "SELECT * FROM `#__eweather_locations` WHERE `region` = '".$this->region_."' AND `country` = '".$this->country_."' AND `city` = '".$this->city_."'";
			$database->setQuery($sql);
			$testcities = $database->loadObjectList();
			if (count($testcities) == 0)
			{
				$this->city_ = $cities[0]->city;
			}
		}

		//
		// find the location ID for the current city
		//
		$sql = "SELECT * FROM `#__eweather_locations` WHERE `region` = '".$this->region_."' AND `country` = '".$this->country_."' AND `city` = '".$this->city_."'";
		$database->setQuery($sql);
		$defaultcities = $database->loadObjectList();

		if (count($defaultcities) <> 0)
		{
			$tempLocID = $defaultcities[0]->loc_id;
		}
		else
		{
			$tempLocID = "";
		}
	    $lists['locationID'] = $tempLocID;
	    
		return $lists;
	}

 	function listConfiguration($option, &$lists)
	{
		$url = JUri::base(true);
		
		//
		// read the configuration parameters from POST
		//
		$this->_adminCfg->readFromPost();
		
		//
		// reconcile any blank configuration parameters from POST
		//  with the component configuration's latest values
		//
		$this->_adminCfg->reconcile();
		
		//
		// the latest location ID can be found in the given lists
		//
		$this->_adminCfg->setDefaultLocation($lists['locationID']);
		
		//
		// create the list of image directories
		//
		$tempdir   = array();
		$templates = $this->GetDirectory(JPATH_SITE.DS.'/components/com_eweather/images/');
		foreach ($templates AS $template)
		{
			$tempdir[] = JHTML::_('select.option', $template , $template );
		}

		$content = "<table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n"
              ."  <tr>\n"
              ."    <td width=\"100%\">\n"
              ."      <div class=\"ConfigurationManagerHeader\">Configuration</div>\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."</table>\n"
              ."<form action=\"index2.php?option=com_eweather\" method=\"post\" name=\"adminForm\">\n"
              ."<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"adminlist\">\n"
              ."  <tr>\n"
              ."    <th align=\"left\">".JText::_('EWEATHER_PARAM_TITLE')."</th>\n"
              ."    <th align=\"left\">".JText::_('EWEATHER_VALUE_TITLE')."</th>\n"
              ."    <th align=\"left\">".JText::_('EWEATHER_DESCRIB_TITLE')."</th>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_PARTNER_ID').":</td>\n"
              ."    <td><input type=\"text\" name=\"partner_ID\" value=\"".$this->_adminCfg->getPartnerID()."\" maxlength=\"30\" size=\"31\"></td>\n"
              ."    <td>".JText::_('EWEATHER_PARTNER_ID_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_PARTNER_KEY').":</td>\n"
              ."    <td><input type=\"text\" name=\"partner_key\" value=\"".$this->_adminCfg->getPartnerKey()."\" maxlength=\"30\" size=\"31\"></td>\n"
              ."    <td>".JText::_('EWEATHER_PARTNER_KEY_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td valign=\"top\">".JText::_('EWEATHER_DEFAULT_LOCATION').":</td>\n"
              ."    <td>\n"
              ."      ".$lists['regions']."<br>\n"
              ."      ".$lists['countries']."<br>\n"
              ."      ".$lists['cities']."<br>\n"
              ."    </td>\n"
              ."    <td valign=\"top\">".JText::_('EWEATHER_DEFAULT_LOCATION_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_DEFAULT_LOC_CODE').":</td>\n"
              ."    <td><input type=\"text\" readonly name=\"default_location\" value=\"".$this->_adminCfg->getDefaultLocation()."\" maxlength=\"15\" size=\"16\"></td>\n"
              ."    <td>".JText::_('EWEATHER_DEFAULT_LOC_CODE_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_CACHE_TIME').":</td>\n"
              ."    <td><input type=\"text\" name=\"cache_time\" value=\"".$this->_adminCfg->getCacheTime()."\" maxlength=\"5\" size=\"6\"></td>\n"
              ."    <td>".JText::_('EWEATHER_CACHE_TIME_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_UNITS').":</td>\n"
              ."    <td>".JHTML::_('select.booleanlist', 'weather_units', 'class="inputbox"', $this->_adminCfg->getUnits(), JText::_('EWEATHER_UNITS_ENG'), JText::_('EWEATHER_UNITS_INT'))."</td>\n"
              ."    <td>".JText::_('EWEATHER_UNITS_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_SHOW_CURRENT_CONDITIONS').":</td>\n"
              ."    <td>".JHTML::_('select.booleanlist', 'show_current_conditions', 'class="inputbox"', $this->_adminCfg->getShowCurrentConditions())."</td>\n"
              ."    <td>".JText::_('EWEATHER_SHOW_CURRENT_CONDITIONS_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_SHOW_FORECAST').":</td>\n"
              ."    <td>".JHTML::_('select.booleanlist', 'show_forecast', 'class="inputbox"', $this->_adminCfg->getShowForecast())."</td>\n"
              ."    <td>".JText::_('EWEATHER_SHOW_FORECAST_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_ICONSET').":</td>\n"
              ."    <td>". JHTML::_('select.genericlist', $tempdir, 'icon_style', 'class="inputbox" size="1"', 'value', 'text', $this->_adminCfg->getIconStyle())."</td>\n"
              ."    <td>".JText::_('EWEATHER_ICONSET_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_FORECAST_DAYS').":</td>\n"
              ."    <td>".JHTML::_('select.integerlist','1', '5', '1', 'forecast_days', '',$this->_adminCfg->getForecastDays())."</td>\n"
              ."    <td>".JText::_('EWEATHER_FORECAST_DAYS_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_FORECAST_DAYS_PER_ROW').":</td>\n"
              ."    <td>".JHTML::_('select.integerlist','1', '5', '1', 'forecast_days_per_row', '',$this->_adminCfg->getForecastDaysPerRow())."</td>\n"
              ."    <td>".JText::_('EWEATHER_FORECAST_DAYS_PER_ROW_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_TIME_FORMAT').":</td>\n"
              ."    <td><input type=\"text\" name=\"time_format\" value=\"".$this->_adminCfg->getTimeFormat()."\" maxlength=\"20\" size=\"21\"></td>\n"
              ."    <td>".JText::_('EWEATHER_TIME_FORMAT_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_DATE_FORMAT_LONG').":</td>\n"
              ."    <td><input type=\"text\" name=\"date_format_long\" value=\"".$this->_adminCfg->getDateFormatLong()."\" maxlength=\"20\" size=\"21\"></td>\n"
              ."    <td>".JText::_('EWEATHER_DATE_FORMAT_LONG_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_DATE_FORMAT_SHORT').":</td>\n"
              ."    <td><input type=\"text\" name=\"date_format_short\" value=\"".$this->_adminCfg->getDateFormatShort()."\" maxlength=\"20\" size=\"21\"></td>\n"
              ."    <td>".JText::_('EWEATHER_DATE_FORMAT_SHORT_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_DATE_FORMAT_DETAIL').":</td>\n"
              ."    <td><input type=\"text\" name=\"date_format_detail\" value=\"".$this->_adminCfg->getDateFormatDetail()."\" maxlength=\"20\" size=\"21\"></td>\n"
              ."    <td>".JText::_('EWEATHER_DATE_FORMAT_DETAIL_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_USE_PROXY').":</td>\n"
              ."    <td>".JHTML::_('select.booleanlist', 'use_proxy', 'class="inputbox"', $this->_adminCfg->getUseProxy())."</td>\n"
              ."    <td>".JText::_('EWEATHER_USE_PROXY_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_PROXY_HOST').":</td>\n"
              ."    <td><input type=\"text\" name=\"proxy_host\" value=\"".$this->_adminCfg->getProxyHost()."\" maxlength=\"255\" size=\"31\"></td>\n"
              ."    <td>".JText::_('EWEATHER_PROXY_HOST_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_PROXY_PORT').":</td>\n"
              ."    <td><input type=\"text\" name=\"proxy_port\" value=\"".$this->_adminCfg->getProxyPort()."\" maxlength=\"5\" size=\"6\"></td>\n"
              ."    <td>".JText::_('EWEATHER_PROXY_PORT_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_USE_PROXY_AUTH').":</td>\n"
              ."    <td>".JHTML::_('select.booleanlist', 'use_proxy_auth', 'class="inputbox"', $this->_adminCfg->getUseProxyAuth())."</td>\n"
              ."    <td>".JText::_('EWEATHER_USE_PROXY_AUTH_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_PROXY_AUTH_USER').":</td>\n"
              ."    <td><input type=\"text\" name=\"proxy_auth_user\" value=\"".$this->_adminCfg->getProxyAuthUser()."\" maxlength=\"20\" size=\"21\"></td>\n"
              ."    <td>".JText::_('EWEATHER_PROXY_AUTH_USER_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_PROXY_AUTH_PWD').":</td>\n"
              ."    <td><input type=\"text\" name=\"proxy_auth_pwd\" value=\"".$this->_adminCfg->getProxyAuthPwd()."\" maxlength=\"20\" size=\"21\"></td>\n"
              ."    <td>".JText::_('EWEATHER_PROXY_AUTH_PWD_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_HEADER_POSITION').":</td>\n"
              ."    <td>".JHTML::_('select.booleanlist', 'header_position', 'class="inputbox"', $this->_adminCfg->getHeaderPosition(), 'below', 'above')."</td>\n"
              ."    <td>".JText::_('EWEATHER_HEADER_POSITION_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>".JText::_('EWEATHER_SHOW_FOOTER').":</td>\n"
              ."    <td>".JHTML::_('select.booleanlist', 'show_footer', 'class="inputbox"', $this->_adminCfg->getShowFooter())."</td>\n"
              ."    <td>".JText::_('EWEATHER_SHOW_FOOTER_D')."</td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <th colspan=\"4\">&nbsp;</th>\n"
              ."  </tr>\n"
              ."</table>\n"
              ."<input type=\"hidden\" name=\"option\" value=\"$option\">\n"
              ."<input type=\"hidden\" name=\"task\" value=\"showConfig\">\n"
              ."</form>\n";

		echo $content;
	}

	function saveConfiguration($option)
	{
		$app = &JFactory::getApplication();

		$this->_adminCfg->readFromPost();
		$this->_adminCfg->save();
		
		$mosmsg = "Config is saved !";
		$app->redirect("index2.php?option=$option&task=config", $mosmsg);
	}

	function GetDirectory($path)
	{
		$arr = array();
		if (!@is_dir( $path ))
		{
			return $arr;
		}

		$handle = opendir( $path );
		while ($file = readdir($handle))
		{
			$dir = JPath::clean( $path.'/'.$file );
			if (is_dir( $dir ))
			{
				if (($file <> ".") && ($file <> ".."))
				{
					$arr[] = trim( $file );
				}
			}
		}
		closedir($handle);
		asort($arr);
		return $arr;
	}

}

  function InstallAllLocations()
  {
    $database = &JFactory::getDBO();
  	$count = 0;
  	$locations = array();
  	
	$sql = "SELECT * FROM `#__eweather_prefs`";
    $database->setQuery($sql);
    $locations = $database->loadObjectList();
  	
	if (count($locations) > 0)
    {
  		foreach ($locations as $location)
  		{
  			$count += InstallCountry($location);
  		}
    }
    return $count;
  }
  
  function InstallCountry($location)
  {
    $database = &JFactory::getDBO();
  	$count = 0;
  	
	if (file_exists(JPATH_ADMINISTRATOR.DS."components/com_eweather/locationData/".$location->loc_id.".php"))
	{
        include_once(JPATH_ADMINISTRATOR.DS."components/com_eweather/locationData/".$location->loc_id.".php");
		$cityCount = 0;
		if (count($city_data) > 0)
		{
            foreach ($city_data as $city)
            {
            	$count += InstallCity($location, $city);
            }
		}
	 }
	 return $count;
  }
  
  function InstallCity($location, $city)
  {
    $database = &JFactory::getDBO();
  	$count = 0;
  	
  	$sql_select_city = "SELECT * FROM `#__eweather_locations` WHERE `city` = '".$city['name']."' AND `country` = '".$location->country."' AND `region` = '".$location->region."' AND `loc_id` = '".$city['accid']."'\r\n";
	$database->setQuery($sql_select_city);
	$tempCity = $database->loadObject();
	if ($tempCity == NULL)
	{
		$sql_add = "INSERT INTO `#__eweather_locations` (`id`, `city`, `country`, `region`, `loc_id`) VALUES ('', '".$city['name']."', '".$location->country."', '".$location->region."', '".$city['accid']."');\r\n";
		$database->setQuery($sql_add);
		$result = $database->query();
		++$count;
    }
    return $count;
  }

?>