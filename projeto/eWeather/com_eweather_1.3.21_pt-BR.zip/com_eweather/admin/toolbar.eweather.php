<?php
/**
 * This file contains the installation routines for the eWeather component.
 *
 * This file is part of eWeather.
 *
 *   eWeather is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   eWeather is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with eWeather.  If not, see <a href="http://www.gnu.org/licenses/">
 *   http://www.gnu.org/licenses/</a>.
 *
 * <b>Modifications:</b><br/>
 * aangepast door Mart Dirks<br/>
 * converted to Joomla! 1.5.x by Bob Lavey
 *
 * @version $Id: toolbar.eweather.php 119 2009-04-14 09:20:41Z rjlavey $
 * @package eWeather
 * @subpackage Admin eWeather
 * @copyright Copyright (c) 2000 - 2006 MamboBaer.de (Harald Baer),
 *            2009 Bob Lavey<br/>
 * @license http://www.gnu.org/licenses/gpl.txt GNU/GPL
 */

/* ensure this file is being called by Joomla! */
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

require_once(JApplicationHelper::getPath('toolbar_html'));
require_once(JApplicationHelper::getPath('toolbar_default'));

/**
 * Use the task parameter to execute the appropriate function.
 * @parameter task the task to be performed
 * @todo This should be part of the AdminWeatherToobar class.
 */
switch ($task) {

  case "location":
    TOOLBAR_eWeather::_LOCATION_MENU();
    break;
  case "instLocation":
    TOOLBAR_eWeather::_LOCATION_MENU();
    break;
  case "showConfig":
    TOOLBAR_eWeather::_CONFIG_MENU();
    break;
  case "showCountry":
    TOOLBAR_eWeather::_COUNTRY_MENU();
    break;
  case "about":
    TOOLBAR_eWeather::_ABOUT_MENU();
    break;

  default:
    TOOLBAR_eWeather::_DEFAULT();
    break;
}

?>