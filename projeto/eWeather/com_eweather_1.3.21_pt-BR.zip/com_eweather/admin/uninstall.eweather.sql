DROP TABLE IF EXISTS `#__eweather_cache`;
DROP TABLE IF EXISTS `#__eweather_locations`;
DROP TABLE IF EXISTS `#__eweather_profiles`;
DROP TABLE IF EXISTS `#__eweather_prefs`;
