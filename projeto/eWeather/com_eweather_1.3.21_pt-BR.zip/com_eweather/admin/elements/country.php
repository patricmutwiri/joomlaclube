<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

class JElementCountry extends JElement
{
	var $_name = 'Country';

	function fetchElement($name, $value, &$node, $control_name)
	{
		$db = &JFactory::getDBO();

		//dump($node->getElementByPath("/root"), '$node->getElementByPath("/root")');
		//dump($name, '$name');
		//dump($value, '$value');
		//dump($node, '$node');
		//dump($control_name, '$control_name');

		$table =& JTable::getInstance('component');
		$table->loadByOption( 'com_eweather' );
		//dump($table, '$table');

		$params = &JComponentHelper::getParams( 'com_eweather' );
		$regionID = $params->get( 'region', 1 );
			
		//
		// get the region name
		//
		$query = "SELECT region FROM #__eweather_prefs WHERE id = '".$regionID."'";
		$db->setQuery( $query );
		$region = $db->loadObject();

		//dump($params, '$params');
		//dump($regionID, '$regionID');
		//dump($query, '$query');
		//dump($region, '$region');
			
		//
		// get the list of countries for the selected region
		//
		$query = "SELECT id, country FROM #__eweather_prefs WHERE region = '".$region->region."' AND loc_id <> '' ORDER BY country ASC";
		$db->setQuery( $query );
		$countries = $db->loadObjectList( );

		//dump($query, '$query');
		//dump($countries, '$$countries');

		return JHTML::_('select.genericlist',  $countries, ''.$control_name.'['.$name.']', 'class="inputbox" onchange="document.adminForm.submit( );"', 'id', 'country', $value, $control_name.$name );

	}
}
