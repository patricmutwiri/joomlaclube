<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

class JElementRegion extends JElement
{
	var $_name = 'Region';
	var $region_ = "";
	var $country_ = "";

	function fetchElement($name, $value, &$node, $control_name)
	{
		$database = &JFactory::getDBO();
			
		//dump($value, '$value');

		$sql = "SELECT * FROM `#__eweather_locations` GROUP BY `region` ORDER BY `region` ASC";
		$database->setQuery($sql);
		$regions = $database -> loadObjectList();

		if (count($regions) <> 0)
		{
			foreach ($regions as $region)
			{
				$tempregion[] = JHTML::_('select.option', $region->region, $region->region, 'value', 'text' );
			}
		}
		else
		{
			$tempregion[] = JHTML::_('select.option', "foo", "bar", 'value', 'text' );
		}
			
		$foobar = JHTML::_('select.genericlist', $tempregion, $control_name.'_'.$name, 'class="inputbox" onchange="document.adminForm.submit( );"', 'value', 'text', $value);
			
		return $foobar;

	}

	function getCountryList($sel)
	{
		$object = new JObject();
		//dump($object, '$object');
	}

}
