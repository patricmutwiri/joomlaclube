<?php
/**
 * This file contains the definition for the AdminWeatherToolbar class.
 *
 * This file is part of eWeather.
 *
 *   eWeather is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   eWeather is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with eWeather.  If not, see <a href="http://www.gnu.org/licenses/">
 *   http://www.gnu.org/licenses/</a>.
 *
 * <b>Modifications:</b><br/>
 * aangepast door Mart Dirks<br/>
 * converted to Joomla! 1.5.x by Bob Lavey
 *
 * @version $Id: toolbar.eweather.html.php 310 2009-11-11 16:56:02Z rjlavey $
 * @package eWeather
 * @subpackage Admin eWeather
 * @copyright Copyright (c) 2000 - 2006 MamboBaer.de (Harald Baer),
 *            2009 Bob Lavey<br/>
 * @license http://www.gnu.org/licenses/gpl.txt GNU/GPL
 *
 */

/* ensure this file is being called by Joomla! */
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

/**
 * The AdminWeatherToolbar class describes the administrator toolbars
 *  for the eWeather component.
 *
 * @package eWeather
 * @subpackage Admin eWeather
 */
class TOOLBAR_eWeather{

  /**
   * Toolbar for the screen that shows the currently-installed locations;
   *  allow` the user to add a new location or cancel.
   */
  function _LOCATION_MENU() {
    JHTML::stylesheet( 'eweather.admin.css', 'administrator/components/com_eweather/assets/css/' );

    JToolBarHelper::title( JText::_( 'eWeather Location Manager' ), 'eweather_logo.png' );
	JToolBarHelper::save('saveInstLocation', 'Save Location');
	JToolBarHelper::cancel();
  }

  /**
   * Toolbar for the screen that shows the list of cities in a country;
   *  allow the user to delete the entire country or specific cities.
   */
  function _COUNTRY_MENU() {
    JHTML::stylesheet( 'eweather.admin.css', 'administrator/components/com_eweather/assets/css/' );

    JToolBarHelper::title( JText::_( 'eWeather Location Installation Manager' ), 'eweather_logo.png' );
    JToolbarHelper::deleteList('', 'removeCity');
    JToolbarHelper::cancel();
  }

  /**
   * Toolbar for the screen that shows the configuration;
   *  allow the user to save the configration or cancel.
   */
  function _CONFIG_MENU() {
    JHTML::stylesheet( 'eweather.admin.css', 'administrator/components/com_eweather/assets/css/' );

    JToolBarHelper::title( JText::_( 'eWeather Configuration Manager' ), 'eweather_logo.png' );
	JToolBarHelper::save('saveConfiguration');
	JToolBarHelper::cancel();
  }

  /**
   * Toolbar for the information screen;
   *  allow the user to return to the previous screen.
   */
  function _ABOUT_MENU() {
    JHTML::stylesheet( 'eweather.admin.css', 'administrator/components/com_eweather/assets/css/' );

    JToolBarHelper::title( JText::_( 'eWeather Information' ), 'eweather_logo.png' );
JToolBarHelper::preferences('com_eweather', '200');
    JToolbarHelper::cancel('', "Close");
  }

  /**
   * Toolbar for the screen that shows the list of installed locations;
   *  allow the user to install new locations.
   */
  function _DEFAULT() {
    JHTML::stylesheet( 'eweather.admin.css', 'administrator/components/com_eweather/assets/css/' );

    JToolBarHelper::title( JText::_( 'eWeather Location Manager' ), 'eweather_logo.png' );
    JToolbarHelper::addNew('instLocation', 'Install Location');
  }
}

?>