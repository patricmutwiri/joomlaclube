<?php
/**
 * This file contains the AdminWeatherConfiguration class, which
 *  abstracts the configuration parameters for the eWeather component.
 *
 * This file is part of eWeather.
 *
 *   eWeather is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   eWeather is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with eWeather.  If not, see <a href="http://www.gnu.org/licenses/">
 *   http://www.gnu.org/licenses/</a>.
 *
 * <b>Modifications:</b><br/>
 * aangepast door Mart Dirks<br/>
 * converted to Joomla! 1.5.x by Bob Lavey
 *
 * @version $Id$
 * @package eWeather
 * @subpackage Admin eWeather
 * @copyright Copyright (c) 2000 - 2006 MamboBaer.de (Harald Baer),
 * 			  2007 Mart Dirks,<br/>
 *            2009 Bob Lavey<br/>
 * @license http://www.gnu.org/licenses/gpl.txt GNU/GPL
 * @toto Break this into additional classes: AdminWeatherConfigurationForm,
 *        AdminWeatherInstalledlocationForm, and AdminWeatherInfoForm.
 */

/* ensure this file is being called by Joomla! */
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

require_once(JPATH_ADMINISTRATOR.DS."components/com_eweather/WeatherConfiguration.php");

/** @todo finish documentation */
class AdminWeatherConfiguration
{
	var $_cfg = null;

	var $_partnerID;
	var $_partnerKey;
	var $_defaultLocation;
	var $_cacheTime;
	var $_units;
	var $_forecastDays;
	var $_forecastDaysPerRow;
	var $_headerPosition;
	var $_showFooter;
	var $_iconStyle;
	var $_showCurrentConditions;
	var $_showForecast;
	var $_timeFormat;
	var $_dateFormatLong;
	var $_dateFormatShort;
	var $_dateFormatDetail;
	var $_useProxy;
	var $_proxyHost;
	var $_proxyPort;
	var $_useProxyAuth;
	var $_proxyAuthUser;
	var $_proxyAuthPwd;

	/** @todo finish documentation */
	function AdminWeatherConfiguration()
	{
		$this->_cfg = & WeatherConfiguration::getInstance();
		$this->reconcile();
	}

	function &getInstance()
	{
		static $_instance = null;
	
		if (null == $_instance)
		{
			$_instance = new AdminWeatherConfiguration();
		}
		
		return $_instance;
	}
	
	
	function getPartnerID() { return $this->_partnerID; }
	function getPartnerKey() { return $this->_partnerKey; }
	function getDefaultLocation() { return $this->_defaultLocation; }
	function setDefaultLocation($newValue)
	{
		$this->_defaultLocation = $newValue;
	}
	function getCacheTime()	{
		if ($this->_cacheTime < 1800)
		{
			return 1800;
		}
		else
		{
			return $this->_cacheTime;
		}
	}
	function getUnits()	{ return $this->_units; }
	function getForecastDays() { return $this->_forecastDays; }
	function getForecastDaysPerRow() { return $this->_forecastDaysPerRow; }
	function getHeaderPosition() { return $this->_headerPosition; }
	function getShowFooter() { return $this->_showFooter; }
	function getIconStyle() { return $this->_iconStyle; }
	function getShowCurrentConditions() { return $this->_showCurrentConditions; }
	function getShowForecast() { return $this->_showForecast; }
	function getTimeFormat() { return $this->_timeFormat; }
	function getDateFormatLong() { return $this->_dateFormatLong; }
	function getDateFormatShort() { return $this->_dateFormatShort; }
	function getDateFormatDetail() { return $this->_dateFormatDetail; }
	function getUseProxy() { return $this->_useProxy; }
	function getProxyHost() { return $this->_proxyHost; }
	function getProxyPort() { return $this->_proxyPort; }
	function getUseProxyAuth() { return $this->_useProxyAuth; }
	function getProxyAuthUser() { return $this->_proxyAuthUser; }
	function getProxyAuthPwd() { return $this->_proxyAuthPwd; }

	/** @todo finish documentation */
	function readFromPost()
	{
		$this->_partnerID             = JRequest::getVar( 'partner_ID', '', 'post' );
		$this->_partnerKey            = JRequest::getVar( 'partner_key', '', 'post' );
		$this->_defaultLocation       = JRequest::getVar( 'default_location', '', 'post');
		$this->_cacheTime             = JRequest::getVar( 'cache_time', '', 'post' );
		$this->_units                 = JRequest::getVar( 'weather_units', '', 'post');
		$this->_iconStyle             = JRequest::getVar( 'icon_style', '', 'post' );
		$this->_forecastDays          = JRequest::getVar( 'forecast_days', '', 'post' );
		$this->_forecastDaysPerRow    = JRequest::getVar( 'forecast_days_per_row', '', 'post' );
		$this->_headerPosition        = JRequest::getVar( 'header_position', '', 'post' );
		$this->_showFooter            = JRequest::getVar( 'show_footer', '', 'post' );
		$this->_showCurrentConditions = JRequest::getVar( 'show_current_conditions', '', 'post' );
		$this->_showForecast          = JRequest::getVar( 'show_forecast', '', 'post' );
		$this->_timeFormat            = JRequest::getVar( 'time_format', '', 'post' );
		$this->_dateFormatLong        = JRequest::getVar( 'date_format_long', '', 'post' );
		$this->_dateFormatShort       = JRequest::getVar( 'date_format_short', '', 'post' );
		$this->_dateFormatDetail      = JRequest::getVar( 'date_format_detail', '', 'post' );
		$this->_useProxy              = JRequest::getVar( 'use_proxy', '', 'post' );
		$this->_proxyHost             = JRequest::getVar( 'proxy_host', '', 'post' );
		$this->_proxyPort             = JRequest::getVar( 'proxy_port', '', 'post' );
		$this->_useProxyAuth          = JRequest::getVar( 'use_proxy_auth', '', 'post' );
		$this->_proxyAuthUser         = JRequest::getVar( 'proxy_auth_user', '', 'post' );
		$this->_proxyAuthPwd          = JRequest::getVar( 'proxy_auth_pwd', '', 'post' );		
	}
	
	/** @todo finish documentation */
	function reconcile()
	{
		if ($this->_partnerID == "")
		{
			$this->_partnerID = $this->_cfg->getPartnerID();
		}
		if ($this->_partnerKey == "")
		{
			$this->_partnerKey = $this->_cfg->getPartnerKey();
		}
		if ($this->_defaultLocation == "")
		{
			$this->_defaultLocation = $this->_cfg->getDefaultLocation();
		}
		if ($this->_cacheTime == "")
		{
			$this->_cacheTime = $this->_cfg->getCacheTime();
		}
		if ($this->_units == "")
		{
			$this->_units = $this->_cfg->getUnits();
		}
		if ($this->_iconStyle == "")
		{
			$this->_iconStyle = $this->_cfg->getIconStyle();
		}
		if ($this->_forecastDays == "")
		{
			$this->_forecastDays = $this->_cfg->getForecastDays();
		}
		if ($this->_forecastDaysPerRow == "")
		{
			$this->_forecastDaysPerRow = $this->_cfg->getForecastDaysPerRow();
		}
		if ($this->_headerPosition == "")
		{
			$this->_headerPosition = $this->_cfg->getHeaderPosition();
		}
		if ($this->_showFooter == "")
		{
			$this->_showFooter = $this->_cfg->getShowFooter();
		}
		if ($this->_showCurrentConditions == "")
		{
			$this->_showCurrentConditions = $this->_cfg->getShowCurrentConditions();
		}
		if ($this->_showForecast == "")
		{
			$this->_showForecast = $this->_cfg->getShowForecast();
		}
		if ($this->_timeFormat == "")
		{
			$this->_timeFormat = $this->_cfg->getTimeFormat();
		}
		if ($this->_dateFormatLong == "")
		{
			$this->_dateFormatLong = $this->_cfg->getDateFormatLong();
		}
		if ($this->_dateFormatShort == "")
		{
			$this->_dateFormatShort = $this->_cfg->getDateFormatShort();
		}
		if ($this->_dateFormatDetail == "")
		{
			$this->_dateFormatDetail = $this->_cfg->getDateFormatDetail();
		}
		if ($this->_useProxy == "")
		{
			$this->_useProxy = $this->_cfg->getUseProxy();
		}
		if ($this->_proxyHost == "")
		{
			$this->_proxyHost = $this->_cfg->getProxyHost();
		}
		if ($this->_proxyPort == "")
		{
			$this->_proxyPort = $this->_cfg->getProxyPort();
		}
		if ($this->_useProxyAuth == "")
		{
			$this->_useProxyAuth = $this->_cfg->getUseProxyAuth();
		}
		if ($this->_proxyAuthUser == "")
		{
			$this->_proxyAuthUser = $this->_cfg->getProxyAuthUser();
		}
		if ($this->_proxyAuthPwd == "")
		{
			$this->_proxyAuthPwd = $this->_cfg->getProxyAuthPwd();
		}
	}

	/** @todo finish documentation */
	function save()
	{
		$this->_cfg->setPartnerID($this->_partnerID);
		$this->_cfg->setPartnerKey($this->_partnerKey);
		$this->_cfg->setDefaultLocation($this->_defaultLocation);
		$this->_cfg->setCacheTime($this->_cacheTime);
		$this->_cfg->setUnits($this->_units);
		$this->_cfg->setForecastDays($this->_forecastDays);
		$this->_cfg->setForecastDaysPerRow($this->_forecastDaysPerRow);
		$this->_cfg->setHeaderPosition($this->_headerPosition);
		$this->_cfg->setShowFooter($this->_showFooter);
		$this->_cfg->setIconStyle($this->_iconStyle);
		$this->_cfg->setShowCurrentConditions($this->_showCurrentConditions);
		$this->_cfg->setShowForecast($this->_showForecast);
		$this->_cfg->setTimeFormat($this->_timeFormat);
		$this->_cfg->setDateFormatLong($this->_dateFormatLong);
		$this->_cfg->setDateFormatShort($this->_dateFormatShort);
		$this->_cfg->setDateFormatDetail($this->_dateFormatDetail);
		$this->_cfg->setUseProxy($this->_useProxy);
		$this->_cfg->setProxyHost($this->_proxyHost);
		$this->_cfg->setProxyPort($this->_proxyPort);
		$this->_cfg->setUseProxyAuth($this->_useProxyAuth);
		$this->_cfg->setProxyAuthUser($this->_proxyAuthUser);
		$this->_cfg->setProxyAuthPwd($this->_proxyAuthPwd);
		
		$this->_cfg->save();
	}
	
}
?>