<?php
/**
 * This file contains helper routines for the configuration
 *  parameters for the eWeather component.
 *
 * This file is part of eWeather.
 *
 *   eWeather is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   eWeather is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with eWeather.  If not, see <a href="http://www.gnu.org/licenses/">
 *   http://www.gnu.org/licenses/</a>.
 *
 * <b>Modifications:</b><br/>
 * Initial revision by Bob Lavey, 10/19/2009.
 *
 * @version $Id$
 * @package eWeather
 * @subpackage Admin eWeather
 * @copyright 2009 Bob Lavey
 * @license http://www.gnu.org/licenses/gpl.txt GNU/GPL
 */

/* ensure this file is being called by Joomla! */
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

require_once(JPATH_SITE.DS.'/libraries/joomla/database/table/component.php');

class WeatherConfiguration
{
	var $_paramData = null;
	var $_paramDefs = "";
	var $_component = null;
		
	function WeatherConfiguration()
	{
		$this->initialize();
	}

	function &getInstance()
	{
		static $_instance = null;
	
		if (null == $_instance)
		{
			$_instance = new WeatherConfiguration();
		}
		
		return $_instance;
	}
	
	function initialize()
	{
		//
		// initialize class attributes
		//
		$this->_paramData =& JComponentHelper::getParams('com_eweather');
		$this->_paramDefs = JPATH_ADMINISTRATOR."\components\com_eweather\WeatherConfiguration.xml";
		$this->_component =& JComponentHelper::getComponent('com_eweather');
		
		//
		// load the parameters and reconcile them with the component
		//
		$params = $this->getParams();
		$this->reconcileParamData($params);
		$this->save();
	}

	function getParams()
	{
		return new JParameter($this->_paramData->toString(), $this->_paramDefs);
	}
	
	function reconcileParamData($params)
	{
		$paramArray = $params->getParams();
		
		if ($paramArray != null)
		{
			foreach ($paramArray as $param)
			{
				$value = $this->_paramData->getValue($param[5], "bogusValue");
				if ("bogusValue" == $value)
				{
					if (isset($param[4]))
					{
						//
						// set and not null
						//
						$newParam = $param[5]."=".$param[4];
					}
					else
					{
						//
						// not set or null
						//
						$newParam = $param[5]."=";
					}
					
					$this->_paramData->loadINI($newParam);
					
				}  // end if ("bogusValue" == $value)

			} // end foreach ($paramArray as $param)
			
		} // end if (!paramArray != null)
	}
	
	function save()
	{
		//
		// save reconciled list back to the component
		//
		$database = &JFactory::getDBO();
		
		$sql = "SELECT * FROM `#__components` WHERE `name` = 'eWeather'";
		$database->setQuery($sql);
		$comRecord = $database->loadObject();
		if (NULL != $comRecord)
		{
			$comTable = new JTableComponent($database);
			$comTable->load($comRecord->id);
			$comTable->params = $this->_paramData->toString();
			$comTable->store();
		}
	}
	
	function getVersion() { return $this->getValue('version'); }
	function setVersion($newVal) { $this->setValue('version', $newVal); }

	function getPartnerID() { return $this->getValue('partnerId'); }
	function setPartnerID($newVal) { $this->setValue('partnerId', $newVal); }

	function getPartnerKey() { return $this->getValue('partnerKey'); }
	function setPartnerKey($newVal) { $this->setValue('partnerKey', $newVal); }

	function getDefaultLocation() { return $this->getValue('locationCode'); }
	function setDefaultLocation($newVal) { 	$this->setValue('locationCode', $newVal); }
	
	function getCacheTime() { return $this->getValue('cacheTime'); }
	function getCacheTimeForWeatherChannel()
	{
		$value = $this->getValue('cacheTime');
		if ($value < 1800)
		{
			$value = 1800;
		}
		return $value;
	}
	function setCacheTime($newVal) { $this->setValue('cacheTime', $newVal); }
	
	function getUnits() { return $this->getValue('units'); }
	function getUnitsForWeatherChannel()
	{
		$units = $this->getUnits();
		
		//
		// convert the units to a value The Weather Channel expects
		//
		if ($units == "0")
		{
			return "m";  // metric
		}
		else
		{
			return "s";  // standard
		}
	}
	function setUnits($newVal) { $this->setValue('units', $newVal); }
	
	function getShowCurrentConditions() { return $this->getValue('showCurrentConditions'); }
	function setShowCurrentConditions($newVal) { $this->setValue('showCurrentConditions', $newVal); }
	
	function getShowForecast() { return $this->getValue('showForecast'); }
	function setShowForecast($newVal) { $this->setValue('showForecast', $newVal); }
	
	function getIconStyle() { return $this->getValue('iconStyle'); }
	function setIconStyle($newVal) { $this->setValue('iconStyle', $newVal); }
	
	function getForecastDays() { return $this->getValue('forecastDays'); }
	function setForecastDays($newVal) { $this->setValue('forecastDays', $newVal); }
	
	function getForecastDaysPerRow() { return $this->getValue('forecastDaysPerRow'); }
	function setForecastDaysPerRow($newVal) { $this->setValue('forecastDaysPerRow', $newVal); }
	
	function getHeaderPosition() { return $this->getValue('headerPosition'); }
	function setHeaderPosition($newVal) { $this->setValue('headerPosition', $newVal); }
	
	function getShowFooter() { return $this->getValue('showFooter'); }
	function setShowFooter($newVal) { $this->setValue('showFooter', $newVal); }
	
	function getTimeFormat() { return $this->getValue('timeFormat'); }
	function setTimeFormat($newVal) { $this->setValue('timeFormat', $newVal); }
	
	function getDateFormatLong() { return $this->getValue('dateFormatLong'); }
	function setDateFormatLong($newVal) { $this->setValue('dateFormatLong', $newVal); }
	
	function getDateFormatShort() { return $this->getValue('dateFormatShort'); }
	function setDateFormatShort($newVal) { $this->setValue('dateFormatShort', $newVal); }
	
	function getDateFormatDetail() { return $this->getValue('dateFormatDetail'); }
	function setDateFormatDetail($newVal) { $this->setValue('dateFormatDetail', $newVal); }
	
	function getUseProxy() { return $this->getValue('useProxy'); }
	function setUseProxy($newVal) { $this->setValue('useProxy', $newVal); }
	
	function getProxyHost() { return $this->getValue('proxyHost'); }
	function setProxyHost($newVal) { $this->setValue('proxyHost', $newVal); }
	
	function getProxyPort() { return $this->getValue('proxyPort'); }
	function setProxyPort($newVal) { $this->setValue('proxyPort', $newVal); }
	
	function getUseProxyAuth() { return $this->getValue('useProxyAuth'); }
	function setUseProxyAuth($newVal) { $this->setValue('useProxyAuth', $newVal); }
	
	function getProxyAuthUser() { return $this->getValue('proxyAuthUser'); }
	function setProxyAuthUser($newVal) { $this->setValue('proxyAuthUser', $newVal); }
	
	function getProxyAuthPwd() { return $this->getValue('proxyAuthPwd'); }
	function setProxyAuthPwd($newVal) { $this->setValue('proxyAuthPwd', $newVal); }
	
	function getValue($name)
	{
		return $this->_paramData->getValue($name);
	}
	function setValue($name, $value)
	{
		 $this->_paramData->setValue($name, $value);
		 $this->save(); 
	}
}
