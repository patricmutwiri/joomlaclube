<?php

// City package for St. Helena 

$city_name = 'St. Helena';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'SHXX0001', 'name' => 'Ascension Island');

?>
