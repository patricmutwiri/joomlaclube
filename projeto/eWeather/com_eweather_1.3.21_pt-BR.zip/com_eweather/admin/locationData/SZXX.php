<?php

// City package for Switzerland 

$city_name = 'Switzerland';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'SZXX0001', 'name' => 'Aarau');
$city_data[] = array('accid' => 'SZXX0002', 'name' => 'Altdorf');
$city_data[] = array('accid' => 'SZXX0003', 'name' => 'Baden');
$city_data[] = array('accid' => 'SZXX0004', 'name' => 'Basel');
$city_data[] = array('accid' => 'SZXX0005', 'name' => 'Bellinzona');
$city_data[] = array('accid' => 'SZXX0006', 'name' => 'Bern');
$city_data[] = array('accid' => 'SZXX0007', 'name' => 'Biel');
$city_data[] = array('accid' => 'SZXX0008', 'name' => 'Carouge');
$city_data[] = array('accid' => 'SZXX0009', 'name' => 'Coppet');
$city_data[] = array('accid' => 'SZXX0010', 'name' => 'Delemont');
$city_data[] = array('accid' => 'SZXX0011', 'name' => 'Emmenbrucke');
$city_data[] = array('accid' => 'SZXX0012', 'name' => 'Fribourg');
$city_data[] = array('accid' => 'SZXX0013', 'name' => 'Geneva');
$city_data[] = array('accid' => 'SZXX0014', 'name' => 'Horgen');
$city_data[] = array('accid' => 'SZXX0015', 'name' => 'Koniz');
$city_data[] = array('accid' => 'SZXX0016', 'name' => 'Langnau');
$city_data[] = array('accid' => 'SZXX0017', 'name' => 'Lausanne');
$city_data[] = array('accid' => 'SZXX0018', 'name' => 'Liestal');
$city_data[] = array('accid' => 'SZXX0019', 'name' => 'Locarno');
$city_data[] = array('accid' => 'SZXX0020', 'name' => 'Lugano');
$city_data[] = array('accid' => 'SZXX0021', 'name' => 'Luzern');
$city_data[] = array('accid' => 'SZXX0022', 'name' => 'Montreux');
$city_data[] = array('accid' => 'SZXX0023', 'name' => 'Neuchatel');
$city_data[] = array('accid' => 'SZXX0024', 'name' => 'Olten');
$city_data[] = array('accid' => 'SZXX0025', 'name' => 'Rheinfelden');
$city_data[] = array('accid' => 'SZXX0026', 'name' => 'Sarnen');
$city_data[] = array('accid' => 'SZXX0027', 'name' => 'Solothurn');
$city_data[] = array('accid' => 'SZXX0028', 'name' => 'Stans');
$city_data[] = array('accid' => 'SZXX0029', 'name' => 'Uster');
$city_data[] = array('accid' => 'SZXX0030', 'name' => 'Winterthur');
$city_data[] = array('accid' => 'SZXX0031', 'name' => 'Zollikon');
$city_data[] = array('accid' => 'SZXX0032', 'name' => 'Zug');
$city_data[] = array('accid' => 'SZXX0033', 'name' => 'Zurich');
$city_data[] = array('accid' => 'SZXX0034', 'name' => 'Payerne');
$city_data[] = array('accid' => 'SZXX0035', 'name' => 'Sion');
$city_data[] = array('accid' => 'SZXX0036', 'name' => 'Guetsch');
$city_data[] = array('accid' => 'SZXX0037', 'name' => 'Locarno-Magadino');
$city_data[] = array('accid' => 'SZXX0038', 'name' => 'Chur/Vaduz');
$city_data[] = array('accid' => 'SZXX0039', 'name' => 'Gstaad');
$city_data[] = array('accid' => 'SZXX0040', 'name' => 'Engelberg');
$city_data[] = array('accid' => 'SZXX0041', 'name' => 'St. Moritz');
$city_data[] = array('accid' => 'SZXX0042', 'name' => 'Zermatt');
$city_data[] = array('accid' => 'SZXX0043', 'name' => 'Grindelwald');
$city_data[] = array('accid' => 'SZXX0044', 'name' => 'Interlaken');
$city_data[] = array('accid' => 'SZXX0045', 'name' => 'Flims');
$city_data[] = array('accid' => 'SZXX0046', 'name' => 'Laax');
$city_data[] = array('accid' => 'SZXX0047', 'name' => 'Falera');
$city_data[] = array('accid' => 'SZXX0048', 'name' => 'Verbier');

?>
