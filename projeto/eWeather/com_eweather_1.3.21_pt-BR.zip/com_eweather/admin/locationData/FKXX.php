<?php

// City package for Falkland Islands 

$city_name = 'Falkland Islands';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'FKXX0001', 'name' => 'Mount Pleasant Arpt');

?>
