<?php

// City package for Gabon 

$city_name = 'Gabon';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'GBXX0006', 'name' => 'Bitam');
$city_data[] = array('accid' => 'GBXX0001', 'name' => 'Franceville');
$city_data[] = array('accid' => 'GBXX0002', 'name' => 'Koulamoutou');
$city_data[] = array('accid' => 'GBXX0008', 'name' => 'Lambarene');
$city_data[] = array('accid' => 'GBXX0003', 'name' => 'Lastoursville');
$city_data[] = array('accid' => 'GBXX0004', 'name' => 'Libreville');
$city_data[] = array('accid' => 'GBXX0007', 'name' => 'Moanda');
$city_data[] = array('accid' => 'GBXX0005', 'name' => 'Port-Gentil');

?>
