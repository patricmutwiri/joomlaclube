<?php

// City package for Dominica 
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Dominica';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'DOXX0001', 'name' => 'Marigot');
$city_data[] = array('accid' => 'DOXX0002', 'name' => 'Roseau');

?>
