<?php

// City package for Thailand
// Last updated: 06/20/2009
// By:           Bob Lavey

$city_name = 'Thailand';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'THXX0001', 'name' => 'Ban Phai');
$city_data[] = array('accid' => 'THXX0002', 'name' => 'Bangkok');
$city_data[] = array('accid' => 'THXX0038', 'name' => 'Chaiyaphum');
$city_data[] = array('accid' => 'THXX0044', 'name' => 'Chanthaburi');
$city_data[] = array('accid' => 'THXX0003', 'name' => 'Chiang Mai');
$city_data[] = array('accid' => 'THXX0004', 'name' => 'Chon Buri');
$city_data[] = array('accid' => 'THXX0005', 'name' => 'Chum Phae');
$city_data[] = array('accid' => 'THXX0050', 'name' => 'Hat Yai');
$city_data[] = array('accid' => 'THXX0006', 'name' => 'Hua Hin');
$city_data[] = array('accid' => 'THXX0036', 'name' => 'Kam Paeng Phet');
$city_data[] = array('accid' => 'THXX0043', 'name' => 'Kanchanaburi');
$city_data[] = array('accid' => 'THXX0007', 'name' => 'Khok Kloi');
$city_data[] = array('accid' => 'THXX0008', 'name' => 'Khon Kaen');
$city_data[] = array('accid' => 'THXX0046', 'name' => 'Koh Samui');
$city_data[] = array('accid' => 'THXX0009', 'name' => 'Lampang');
$city_data[] = array('accid' => 'THXX0010', 'name' => 'Lamphun');
$city_data[] = array('accid' => 'THXX0033', 'name' => 'Loei');
$city_data[] = array('accid' => 'THXX0053', 'name' => 'Lopburi');
$city_data[] = array('accid' => 'THXX0027', 'name' => 'Mae Hong Son');
$city_data[] = array('accid' => 'THXX0011', 'name' => 'Mae Rim');
$city_data[] = array('accid' => 'THXX0029', 'name' => 'Mae Sariang');
$city_data[] = array('accid' => 'THXX0034', 'name' => 'Mae Sot');
$city_data[] = array('accid' => 'THXX0012', 'name' => 'Maha Sarakham');
$city_data[] = array('accid' => 'THXX0037', 'name' => 'Mukdahan');
$city_data[] = array('accid' => 'THXX0013', 'name' => 'Nakhon Pathom');
$city_data[] = array('accid' => 'THXX0014', 'name' => 'Nakhon Ratchasima');
$city_data[] = array('accid' => 'THXX0048', 'name' => 'Nakhon Si Thammarat');
$city_data[] = array('accid' => 'THXX0031', 'name' => 'Nan');
$city_data[] = array('accid' => 'THXX0051', 'name' => 'Narathiwat');
$city_data[] = array('accid' => 'THXX0032', 'name' => 'Nong Khai');
$city_data[] = array('accid' => 'THXX0015', 'name' => 'Pattaya');
$city_data[] = array('accid' => 'THXX0028', 'name' => 'Phayao');
$city_data[] = array('accid' => 'THXX0016', 'name' => 'Phetchaburi');
$city_data[] = array('accid' => 'THXX0035', 'name' => 'Phitsanulok');
$city_data[] = array('accid' => 'THXX0017', 'name' => 'Phra Nakhon Si Ayutthaya');
$city_data[] = array('accid' => 'THXX0018', 'name' => 'Phuket');
$city_data[] = array('accid' => 'THXX0042', 'name' => 'Prachin Buri');
$city_data[] = array('accid' => 'THXX0045', 'name' => 'Prachuap Khirikhan');
$city_data[] = array('accid' => 'THXX0019', 'name' => 'Roi Et');
$city_data[] = array('accid' => 'THXX0020', 'name' => 'Sakhon Nakhon');
$city_data[] = array('accid' => 'THXX0021', 'name' => 'Samut Prakan');
$city_data[] = array('accid' => 'THXX0022', 'name' => 'Samut Sakhon');
$city_data[] = array('accid' => 'THXX0023', 'name' => 'Saraphi');
$city_data[] = array('accid' => 'THXX0049', 'name' => 'Songkhla');
$city_data[] = array('accid' => 'THXX0041', 'name' => 'Suphan Buri');
$city_data[] = array('accid' => 'THXX0047', 'name' => 'Surat Thani');
$city_data[] = array('accid' => 'THXX0024', 'name' => 'Thai Muang');
$city_data[] = array('accid' => 'THXX0025', 'name' => 'Thalang');
$city_data[] = array('accid' => 'THXX0040', 'name' => 'Thong Pha Phum');
$city_data[] = array('accid' => 'THXX0039', 'name' => 'Ubon Ratchathani');
$city_data[] = array('accid' => 'THXX0026', 'name' => 'Udon Thani');

?>
