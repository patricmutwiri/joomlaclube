<?php

// City package for Taiwan
// Last updated: 06/20/2009
// By:           Bob Lavey

$city_name = 'Taiwan';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'TWXX0005', 'name' => 'Ch`i-shan');
$city_data[] = array('accid' => 'TWXX0001', 'name' => 'Chang-hua');
$city_data[] = array('accid' => 'TWXX0003', 'name' => 'Chi-lung');
$city_data[] = array('accid' => 'TWXX0002', 'name' => 'Chia-i');
$city_data[] = array('accid' => 'TWXX0004', 'name' => 'Chingmei');
$city_data[] = array('accid' => 'TWXX0006', 'name' => 'Chu-tung');
$city_data[] = array('accid' => 'TWXX0007', 'name' => 'Feng-yuan');
$city_data[] = array('accid' => 'TWXX0008', 'name' => 'Hengch`un');
$city_data[] = array('accid' => 'TWXX0017', 'name' => 'Hengchun');
$city_data[] = array('accid' => 'TWXX0009', 'name' => 'Hsin-chu');
$city_data[] = array('accid' => 'TWXX0010', 'name' => 'Hsin-tien');
$city_data[] = array('accid' => 'TWXX0011', 'name' => 'Hua-lien');
$city_data[] = array('accid' => 'TWXX0012', 'name' => 'Kangshan');
$city_data[] = array('accid' => 'TWXX0013', 'name' => 'Kao-hsiung');
$city_data[] = array('accid' => 'TWXX0014', 'name' => 'Miao-li');
$city_data[] = array('accid' => 'TWXX0015', 'name' => 'P`ing-tung');
$city_data[] = array('accid' => 'TWXX0016', 'name' => 'Su-ao');
$city_data[] = array('accid' => 'TWXX0019', 'name' => 'T`ai-chung');
$city_data[] = array('accid' => 'TWXX0020', 'name' => 'T`ai-nan');
$city_data[] = array('accid' => 'TWXX0022', 'name' => 'T`aipeihsien');
$city_data[] = array('accid' => 'TWXX0023', 'name' => 'T`aitung');
$city_data[] = array('accid' => 'TWXX0025', 'name' => 'T`ao-yuan');
$city_data[] = array('accid' => 'TWXX0017', 'name' => 'Ta-cho-shui');
$city_data[] = array('accid' => 'TWXX0018', 'name' => 'Ta-fan-lieh');
$city_data[] = array('accid' => 'TWXX0026', 'name' => 'Ta-wu');
$city_data[] = array('accid' => 'TWXX0028', 'name' => 'Taidong');
$city_data[] = array('accid' => 'TWXX0021', 'name' => 'Taipei');
$city_data[] = array('accid' => 'TWXX0024', 'name' => 'Tan-shui');

?>
