<?php

// City package for Czech Republic  
$city_name = 'Czech Republic';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'EZXX0001', 'name' => 'Beroun');
$city_data[] = array('accid' => 'EZXX0002', 'name' => 'Brno');
$city_data[] = array('accid' => 'EZXX0003', 'name' => 'Cesky Tesin');
$city_data[] = array('accid' => 'EZXX0004', 'name' => 'Frydek');
$city_data[] = array('accid' => 'EZXX0005', 'name' => 'Karvina');
$city_data[] = array('accid' => 'EZXX0006', 'name' => 'Kladno');
$city_data[] = array('accid' => 'EZXX0007', 'name' => 'Kolin');
$city_data[] = array('accid' => 'EZXX0008', 'name' => 'Opava');
$city_data[] = array('accid' => 'EZXX0009', 'name' => 'Ostrava');
$city_data[] = array('accid' => 'EZXX0010', 'name' => 'Pilsen');
$city_data[] = array('accid' => 'EZXX0011', 'name' => 'Pisek');
$city_data[] = array('accid' => 'EZXX0012', 'name' => 'Praha');
$city_data[] = array('accid' => 'EZXX0013', 'name' => 'Rosice');
$city_data[] = array('accid' => 'EZXX0014', 'name' => 'Slavkov u Brna');
$city_data[] = array('accid' => 'EZXX0015', 'name' => 'Tabor');
$city_data[] = array('accid' => 'EZXX0016', 'name' => 'Usti nad Labem');
$city_data[] = array('accid' => 'EZXX0017', 'name' => 'Cheb');
$city_data[] = array('accid' => 'EZXX0018', 'name' => 'Primda');
$city_data[] = array('accid' => 'EZXX0019', 'name' => 'Churanov');
$city_data[] = array('accid' => 'EZXX0020', 'name' => 'Milesovka');
$city_data[] = array('accid' => 'EZXX0021', 'name' => 'Kocelovice');
$city_data[] = array('accid' => 'EZXX0022', 'name' => 'Praha - Libus');
$city_data[] = array('accid' => 'EZXX0023', 'name' => 'Liberec');
$city_data[] = array('accid' => 'EZXX0024', 'name' => 'Kostelni Myslova');
$city_data[] = array('accid' => 'EZXX0025', 'name' => 'Pribyslav');
$city_data[] = array('accid' => 'EZXX0026', 'name' => 'Usti nad Orlici');
$city_data[] = array('accid' => 'EZXX0027', 'name' => 'Cervena');
$city_data[] = array('accid' => 'EZXX0028', 'name' => 'Holesov');
$city_data[] = array('accid' => 'EZXX0029', 'name' => 'Lysa Hora');
$city_data[] = array('accid' => 'EZXX0030', 'name' => 'Ceske Budejovice');

?>
