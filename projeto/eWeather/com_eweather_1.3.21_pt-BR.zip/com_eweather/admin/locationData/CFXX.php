<?php

// City package for Republic of The Congo 
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Republic of The Congo';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'CFXX0001', 'name' => 'Brazzaville');
$city_data[] = array('accid' => 'CFXX0004', 'name' => 'Impfondo');
$city_data[] = array('accid' => 'CFXX0002', 'name' => 'Madingo-Kayes');
$city_data[] = array('accid' => 'CFXX0003', 'name' => 'Pointe-Noire');

?>
