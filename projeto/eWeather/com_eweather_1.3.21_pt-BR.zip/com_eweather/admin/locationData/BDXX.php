<?php

// City package for Bermuda 

$city_name = 'Bermuda';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'BDXX0001', 'name' => 'Saint George');

?>
