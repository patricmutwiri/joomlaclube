<?php

// City package for Netherlands Antilles
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Netherlands Antilles';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'NTXX0001', 'name' => 'Curacao Island');
$city_data[] = array('accid' => 'NTXX0002', 'name' => 'Kralendijk');
$city_data[] = array('accid' => 'NTXX0021', 'name' => 'Saint Eustatius');

?>
