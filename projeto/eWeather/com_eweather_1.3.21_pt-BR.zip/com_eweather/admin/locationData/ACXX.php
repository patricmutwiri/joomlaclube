<?php

// City package for Antigua
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Antigua';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'WEXX0001', 'name' => 'Bethlehem');
$city_data[] = array('accid' => 'ACXX0001', 'name' => 'Codrington');
$city_data[] = array('accid' => 'ACXX0002', 'name' => 'Saint John`s');

?>
