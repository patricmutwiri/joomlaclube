<?php

// City package for Jamaica 
// Last updated: 07/05/2009
// By:           Bob Lavey

$city_name = 'Jamaica';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'JMXX0010', 'name' => 'Black River');
$city_data[] = array('accid' => 'JMXX0011', 'name' => 'Christiana');
$city_data[] = array('accid' => 'JMXX0001', 'name' => 'Falmouth');
$city_data[] = array('accid' => 'JMXX0002', 'name' => 'Kingston');
$city_data[] = array('accid' => 'JMXX0003', 'name' => 'Montego Bay');
$city_data[] = array('accid' => 'JMXX0004', 'name' => 'Morant Bay');
$city_data[] = array('accid' => 'JMXX0009', 'name' => 'Negril');
$city_data[] = array('accid' => 'JMXX0005', 'name' => 'Ocho Rios');
$city_data[] = array('accid' => 'JMXX0012', 'name' => 'Port Antonio');
$city_data[] = array('accid' => 'JMXX0006', 'name' => 'Port Royal');
$city_data[] = array('accid' => 'JMXX0007', 'name' => 'Reading');
$city_data[] = array('accid' => 'JMXX0008', 'name' => 'Spanish Town');

?>
