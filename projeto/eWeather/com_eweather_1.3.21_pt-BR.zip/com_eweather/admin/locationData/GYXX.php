<?php

// City package for Guyana 

$city_name = 'Guyana';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'GYXX0001', 'name' => 'Georgetown');
$city_data[] = array('accid' => 'GYXX0002', 'name' => 'New Amsterdam');
$city_data[] = array('accid' => 'GYXX0003', 'name' => 'Spring Garden');

?>
