<?php

// City package for Morocco 

$city_name = 'Morocco';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'MOXX0022', 'name' => 'Agadir Al Massira');
$city_data[] = array('accid' => 'MOXX0013', 'name' => 'Al Hoceima');
$city_data[] = array('accid' => 'MOXX0018', 'name' => 'Beni-Mellal');
$city_data[] = array('accid' => 'MOXX0001', 'name' => 'Casablanca');
$city_data[] = array('accid' => 'MOXX0002', 'name' => 'El Jadida');
$city_data[] = array('accid' => 'MOXX0020', 'name' => 'Errachidia');
$city_data[] = array('accid' => 'MOXX0025', 'name' => 'Es Semara');
$city_data[] = array('accid' => 'MOXX0021', 'name' => 'Essaouira');
$city_data[] = array('accid' => 'MOXX0003', 'name' => 'Fes');
$city_data[] = array('accid' => 'MOXX0017', 'name' => 'Kasba-Tadla');
$city_data[] = array('accid' => 'MOXX0012', 'name' => 'Larache');
$city_data[] = array('accid' => 'MOXX0004', 'name' => 'Marrakech');
$city_data[] = array('accid' => 'MOXX0005', 'name' => 'Meknes');
$city_data[] = array('accid' => 'MOXX0019', 'name' => 'Midelt');
$city_data[] = array('accid' => 'MOXX0006', 'name' => 'Mohammedia');
$city_data[] = array('accid' => 'MOXX0015', 'name' => 'Nouasseur');
$city_data[] = array('accid' => 'MOXX0023', 'name' => 'Ouarzazate');
$city_data[] = array('accid' => 'MOXX0014', 'name' => 'Oujda');
$city_data[] = array('accid' => 'MOXX0007', 'name' => 'Rabat');
$city_data[] = array('accid' => 'MOXX0016', 'name' => 'Safi');
$city_data[] = array('accid' => 'MOXX0011', 'name' => 'Sidi Ifni');
$city_data[] = array('accid' => 'MOXX0024', 'name' => 'Tan-tan');
$city_data[] = array('accid' => 'MOXX0008', 'name' => 'Tangier');
$city_data[] = array('accid' => 'MOXX0009', 'name' => 'Taza');
$city_data[] = array('accid' => 'MOXX0010', 'name' => 'Tetouan');

?>
