<?php

// City package for Zambia 

$city_name = 'Zambia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'ZAXX0001', 'name' => 'Chingolo');
$city_data[] = array('accid' => 'ZAXX0002', 'name' => 'Kabwe');
$city_data[] = array('accid' => 'ZAXX0003', 'name' => 'Livingstone');
$city_data[] = array('accid' => 'ZAXX0004', 'name' => 'Lusaka');
$city_data[] = array('accid' => 'ZAXX0005', 'name' => 'Ndola');

?>
