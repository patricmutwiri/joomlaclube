<?php

// City package for Namibia 

$city_name = 'Namibia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'WAXX0001', 'name' => 'Hentiesbaai');
$city_data[] = array('accid' => 'WAXX0006', 'name' => 'Keetmanshoop');
$city_data[] = array('accid' => 'WAXX0005', 'name' => 'Luderitz Diaz Point');
$city_data[] = array('accid' => 'WAXX0002', 'name' => 'Swakopmund');
$city_data[] = array('accid' => 'WAXX0003', 'name' => 'Walvis Bay');
$city_data[] = array('accid' => 'WAXX0004', 'name' => 'Windhoek');

?>
