<?php

// City package for Ukraine
//
// Last updated: 09/25/2009
// By:           Bob Lavey

$city_name = 'Ukraine';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'UPXX0001', 'name' => 'Bila Tserkva');
$city_data[] = array('accid' => 'UPXX0002', 'name' => 'Bilhorod-Dnistrovs`kyy');
$city_data[] = array('accid' => 'UPXX0003', 'name' => 'Boryspil');
$city_data[] = array('accid' => 'UPXX0004', 'name' => 'Boyarka');
$city_data[] = array('accid' => 'UPXX0005', 'name' => 'Busk');
$city_data[] = array('accid' => 'UPXX0006', 'name' => 'Cherkasy');
$city_data[] = array('accid' => 'UPXX0007', 'name' => 'Chernihiv');
$city_data[] = array('accid' => 'UPXX0045', 'name' => 'Chernivtsi');
$city_data[] = array('accid' => 'UPXX0053', 'name' => 'Chornomors`Ke');
$city_data[] = array('accid' => 'UPXX0008', 'name' => 'Chuhuyiv');
$city_data[] = array('accid' => 'UPXX0009', 'name' => 'Dniprodzerzhyns`k');
$city_data[] = array('accid' => 'UPXX0010', 'name' => 'Dnipropetrovs`k');
$city_data[] = array('accid' => 'UPXX0011', 'name' => 'Donets`k');
$city_data[] = array('accid' => 'UPXX0062', 'name' => 'Drogobych');
$city_data[] = array('accid' => 'UPXX0012', 'name' => 'Druzhba');
$city_data[] = array('accid' => 'UPXX0052', 'name' => 'Heniches`K');
$city_data[] = array('accid' => 'UPXX0013', 'name' => 'Horlivka');
$city_data[] = array('accid' => 'UPXX0040', 'name' => 'Ivano-Frankivs`K');
$city_data[] = array('accid' => 'UPXX0057', 'name' => 'Izium');
$city_data[] = array('accid' => 'UPXX0050', 'name' => 'Izmail');
$city_data[] = array('accid' => 'UPXX0055', 'name' => 'Kerch');
$city_data[] = array('accid' => 'UPXX0014', 'name' => 'Kharkov');
$city_data[] = array('accid' => 'UPXX0015', 'name' => 'Kherson');
$city_data[] = array('accid' => 'UPXX0037', 'name' => 'Khmel`Nyts`Kyi');
$city_data[] = array('accid' => 'UPXX0016', 'name' => 'Kiev');
$city_data[] = array('accid' => 'UPXX0047', 'name' => 'Kirovohrad');
$city_data[] = array('accid' => 'UPXX0030', 'name' => 'Konotop');
$city_data[] = array('accid' => 'UPXX0063', 'name' => 'Kovel');
$city_data[] = array('accid' => 'UPXX0049', 'name' => 'Kryvyi Rih');
$city_data[] = array('accid' => 'UPXX0017', 'name' => 'L`viv');
$city_data[] = array('accid' => 'UPXX0048', 'name' => 'Liubashivka');
$city_data[] = array('accid' => 'UPXX0035', 'name' => 'Lubny');
$city_data[] = array('accid' => 'UPXX0059', 'name' => 'Luhans`K');
$city_data[] = array('accid' => 'UPXX0018', 'name' => 'Makiyivka');
$city_data[] = array('accid' => 'UPXX0061', 'name' => 'Mariupol');
$city_data[] = array('accid' => 'UPXX0019', 'name' => 'Merefa');
$city_data[] = array('accid' => 'UPXX0046', 'name' => 'Mohyliv-Podil`s`Kyi');
$city_data[] = array('accid' => 'UPXX0020', 'name' => 'Mykolayiv');
$city_data[] = array('accid' => 'UPXX0038', 'name' => 'Myronivka');
$city_data[] = array('accid' => 'UPXX0029', 'name' => 'Nizhyn');
$city_data[] = array('accid' => 'UPXX0021', 'name' => 'Odessa');
$city_data[] = array('accid' => 'UPXX0039', 'name' => 'Poltava');
$city_data[] = array('accid' => 'UPXX0032', 'name' => 'Rivne');
$city_data[] = array('accid' => 'UPXX0026', 'name' => 'Sarny');
$city_data[] = array('accid' => 'UPXX0022', 'name' => 'Sevastopol`');
$city_data[] = array('accid' => 'UPXX0033', 'name' => 'Shepetivka');
$city_data[] = array('accid' => 'UPXX0023', 'name' => 'Shostka');
$city_data[] = array('accid' => 'UPXX0054', 'name' => 'Simferopol');
$city_data[] = array('accid' => 'UPXX0031', 'name' => 'Sumy');
$city_data[] = array('accid' => 'UPXX0043', 'name' => 'Svitlovods`K');
$city_data[] = array('accid' => 'UPXX0036', 'name' => 'Ternopil');
$city_data[] = array('accid' => 'UPXX0042', 'name' => 'Uman');
$city_data[] = array('accid' => 'UPXX0044', 'name' => 'Uzhhorod');
$city_data[] = array('accid' => 'UPXX0041', 'name' => 'Vinnytsia');
$city_data[] = array('accid' => 'UPXX0028', 'name' => 'Volodymyr-Volyns`Kyi');
$city_data[] = array('accid' => 'UPXX0056', 'name' => 'Yalta');
$city_data[] = array('accid' => 'UPXX0024', 'name' => 'Yevpatoriya');
$city_data[] = array('accid' => 'UPXX0060', 'name' => 'Zaporizhzhia');
$city_data[] = array('accid' => 'UPXX0025', 'name' => 'Zhytomyr');

?>