<?php

// City package for Guinea 

$city_name = 'Guinea';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'GVXX0001', 'name' => 'Boffa');
$city_data[] = array('accid' => 'GVXX0002', 'name' => 'Conakry');

?>
