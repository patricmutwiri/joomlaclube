<?php

// City package for Equatorial Guinea 

$city_name = 'Equatorial Guinea';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'EKXX0001', 'name' => 'Bata');
$city_data[] = array('accid' => 'EKXX0002', 'name' => 'Luba');
$city_data[] = array('accid' => 'EKXX0003', 'name' => 'Malabo');

?>
