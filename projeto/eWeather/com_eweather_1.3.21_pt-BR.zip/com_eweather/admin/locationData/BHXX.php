<?php

// City package for Belize 

$city_name = 'Belize';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'BHXX0001', 'name' => 'Belize City');
$city_data[] = array('accid' => 'BHXX0002', 'name' => 'Belmopan');
$city_data[] = array('accid' => 'BHXX0003', 'name' => 'Corozal');
$city_data[] = array('accid' => 'BHXX0004', 'name' => 'Dangriga');
$city_data[] = array('accid' => 'BHXX0005', 'name' => 'Turneffe Island');

?>
