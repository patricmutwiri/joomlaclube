<?php

// City package for Maldives 

$city_name = 'Maldives';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'MVXX0001', 'name' => 'Male');

?>
