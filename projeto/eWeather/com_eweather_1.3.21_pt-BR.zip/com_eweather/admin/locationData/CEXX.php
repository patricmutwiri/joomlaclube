<?php

// City package for Sri Lanka
// Last updated: 08/27/2009
// By:           Bob Lavey

$city_name = 'Sri Lanka';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'CEXX0001', 'name' => 'Colombo');
$city_data[] = array('accid' => 'CEXX0005', 'name' => 'Katunayake');
$city_data[] = array('accid' => 'CEXX0002', 'name' => 'Moratuwa');
$city_data[] = array('accid' => 'CEXX0003', 'name' => 'Negombo');
$city_data[] = array('accid' => 'CEXX0004', 'name' => 'Sri Jayavardhanapura');

?>