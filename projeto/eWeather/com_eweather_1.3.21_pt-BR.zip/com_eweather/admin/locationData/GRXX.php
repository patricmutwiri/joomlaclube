﻿<?php

// City package for Greece 
// Last updated: 07/18/2009
// By:           Bob Lavey

$city_name = 'Greece';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'GRXX0001', 'name' => 'Agrinion');
$city_data[] = array('accid' => 'GRXX0075', 'name' => 'Aigion');
$city_data[] = array('accid' => 'GRXX0003', 'name' => 'Alexandroupolis');
$city_data[] = array('accid' => 'GRXX0049', 'name' => 'Amorgos');
$city_data[] = array('accid' => 'GRXX0048', 'name' => 'Anafi');
$city_data[] = array('accid' => 'GRXX0027', 'name' => 'Andravida Airport');
$city_data[] = array('accid' => 'GRXX0050', 'name' => 'Andros');
$city_data[] = array('accid' => 'GRXX0069', 'name' => 'Araxos');
$city_data[] = array('accid' => 'GRXX0071', 'name' => 'Argos');
$city_data[] = array('accid' => 'GRXX0031', 'name' => 'Arta');
$city_data[] = array('accid' => 'GRXX0002', 'name' => 'Attika/Akharnai');
$city_data[] = array('accid' => 'GRXX0004', 'name' => 'Attika/Athens');
$city_data[] = array('accid' => 'GRXX0005', 'name' => 'Attika/Ilioupolis');
$city_data[] = array('accid' => 'GRXX0006', 'name' => 'Attika/Kalamakion');
$city_data[] = array('accid' => 'GRXX0007', 'name' => 'Attika/Kallithea');
$city_data[] = array('accid' => 'GRXX0012', 'name' => 'Attika/Nea Ionia');
$city_data[] = array('accid' => 'GRXX0014', 'name' => 'Attika/Peristerion');
$city_data[] = array('accid' => 'GRXX0025', 'name' => 'Chalkidiki/Zografos');
$city_data[] = array('accid' => 'GRXX0033', 'name' => 'Chios');
$city_data[] = array('accid' => 'GRXX0026', 'name' => 'Corfu Airport');
$city_data[] = array('accid' => 'GRXX0068', 'name' => 'Corfu');
$city_data[] = array('accid' => 'GRXX0051', 'name' => 'Folegandros');
$city_data[] = array('accid' => 'GRXX0072', 'name' => 'Galatas/Poros');
$city_data[] = array('accid' => 'GRXX0047', 'name' => 'Gavdos');
$city_data[] = array('accid' => 'GRXX0078', 'name' => 'Gythion');
$city_data[] = array('accid' => 'GRXX0030', 'name' => 'Heraklion Airport');
$city_data[] = array('accid' => 'GRXX0052', 'name' => 'Ios');
$city_data[] = array('accid' => 'GRXX0046', 'name' => 'Island of Crete');
$city_data[] = array('accid' => 'GRXX0036', 'name' => 'Kalamata');
$city_data[] = array('accid' => 'GRXX0063', 'name' => 'Kalymnos');
$city_data[] = array('accid' => 'GRXX0034', 'name' => 'Karditsa');
$city_data[] = array('accid' => 'GRXX0073', 'name' => 'Karpathos');
$city_data[] = array('accid' => 'GRXX0008', 'name' => 'Kavala');
$city_data[] = array('accid' => 'GRXX0053', 'name' => 'Kea');
$city_data[] = array('accid' => 'GRXX0035', 'name' => 'Kefallina');
$city_data[] = array('accid' => 'GRXX0009', 'name' => 'Khalkis');
$city_data[] = array('accid' => 'GRXX0032', 'name' => 'Khania/Souda');
$city_data[] = array('accid' => 'GRXX0055', 'name' => 'Kimolos');
$city_data[] = array('accid' => 'GRXX0054', 'name' => 'Kithnos');
$city_data[] = array('accid' => 'GRXX0010', 'name' => 'Korinthos');
$city_data[] = array('accid' => 'GRXX0038', 'name' => 'Kos');
$city_data[] = array('accid' => 'GRXX0037', 'name' => 'Kozani');
$city_data[] = array('accid' => 'GRXX0029', 'name' => 'Kythira');
$city_data[] = array('accid' => 'GRXX0011', 'name' => 'Larisa');
$city_data[] = array('accid' => 'GRXX0079', 'name' => 'Levadhia');
$city_data[] = array('accid' => 'GRXX0039', 'name' => 'Limnos');
$city_data[] = array('accid' => 'GRXX0028', 'name' => 'Methoni');
$city_data[] = array('accid' => 'GRXX0056', 'name' => 'Milos');
$city_data[] = array('accid' => 'GRXX0040', 'name' => 'Mitilini');
$city_data[] = array('accid' => 'GRXX0070', 'name' => 'Mitilini/Ayia Paraskevi');
$city_data[] = array('accid' => 'GRXX0045', 'name' => 'Mykonos');
$city_data[] = array('accid' => 'GRXX0076', 'name' => 'Navplion');
$city_data[] = array('accid' => 'GRXX0041', 'name' => 'Naxos');
$city_data[] = array('accid' => 'GRXX0064', 'name' => 'Nissiros');
$city_data[] = array('accid' => 'GRXX0057', 'name' => 'Paros');
$city_data[] = array('accid' => 'GRXX0065', 'name' => 'Patmos');
$city_data[] = array('accid' => 'GRXX0013', 'name' => 'Patrai');
$city_data[] = array('accid' => 'GRXX0015', 'name' => 'Piraeus');
$city_data[] = array('accid' => 'GRXX0074', 'name' => 'Polikhnitos');
$city_data[] = array('accid' => 'GRXX0016', 'name' => 'Preveza');
$city_data[] = array('accid' => 'GRXX0017', 'name' => 'Rhodes');
$city_data[] = array('accid' => 'GRXX0018', 'name' => 'Salamis');
$city_data[] = array('accid' => 'GRXX0019', 'name' => 'Salonica');
$city_data[] = array('accid' => 'GRXX0042', 'name' => 'Samos');
$city_data[] = array('accid' => 'GRXX0044', 'name' => 'Santorini');
$city_data[] = array('accid' => 'GRXX0058', 'name' => 'Serifos');
$city_data[] = array('accid' => 'GRXX0020', 'name' => 'Serrai');
$city_data[] = array('accid' => 'GRXX0059', 'name' => 'Sifnos');
$city_data[] = array('accid' => 'GRXX0060', 'name' => 'Sikinos');
$city_data[] = array('accid' => 'GRXX0066', 'name' => 'Simi');
$city_data[] = array('accid' => 'GRXX0061', 'name' => 'Siros');
$city_data[] = array('accid' => 'GRXX0021', 'name' => 'Skiathos');
$city_data[] = array('accid' => 'GRXX0022', 'name' => 'Skiros');
$city_data[] = array('accid' => 'GRXX0077', 'name' => 'Sparti');
$city_data[] = array('accid' => 'GRXX0081', 'name' => 'Spetsai');
$city_data[] = array('accid' => 'GRXX0067', 'name' => 'Tilos');
$city_data[] = array('accid' => 'GRXX0062', 'name' => 'Tinos');
$city_data[] = array('accid' => 'GRXX0043', 'name' => 'Tripolis');
$city_data[] = array('accid' => 'GRXX0023', 'name' => 'Volos');
$city_data[] = array('accid' => 'GRXX0080', 'name' => 'Xanthi');
$city_data[] = array('accid' => 'GRXX0024', 'name' => 'Zakinthos');

?>