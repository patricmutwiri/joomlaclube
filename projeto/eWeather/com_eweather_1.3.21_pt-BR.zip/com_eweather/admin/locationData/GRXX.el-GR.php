﻿<?php

// City package for Greece (in Greek language)
// Last updated: 09/04/2009
// By:           Nikos Kyrloglou (nikoky@gmail.com)

$city_name = 'Ελλάδα';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'GRXX0001', 'name' => 'Αγρίνιο');
$city_data[] = array('accid' => 'GRXX0075', 'name' => 'Αίγιο');
$city_data[] = array('accid' => 'GRXX0003', 'name' => 'Αλεξανδρούπολη');
$city_data[] = array('accid' => 'GRXX0049', 'name' => 'Αμοργός');
$city_data[] = array('accid' => 'GRXX0048', 'name' => 'Ανάφη');
$city_data[] = array('accid' => 'GRXX0027', 'name' => 'Ανδραβίδα/Αεροδρόμιο');
$city_data[] = array('accid' => 'GRXX0050', 'name' => 'Άνδρος');
$city_data[] = array('accid' => 'GRXX0069', 'name' => 'Άραξος');
$city_data[] = array('accid' => 'GRXX0071', 'name' => 'Άργος');
$city_data[] = array('accid' => 'GRXX0031', 'name' => 'Άρτα');
$city_data[] = array('accid' => 'GRXX0004', 'name' => 'Αττική/Αθήνα');
$city_data[] = array('accid' => 'GRXX0002', 'name' => 'Αττική/Αχαρνές');
$city_data[] = array('accid' => 'GRXX0005', 'name' => 'Αττική/Ηλιούπολη');
$city_data[] = array('accid' => 'GRXX0006', 'name' => 'Αττική/Καλαμάκι');
$city_data[] = array('accid' => 'GRXX0007', 'name' => 'Αττική/Καλλιθέα');
$city_data[] = array('accid' => 'GRXX0012', 'name' => 'Αττική/Νέα Ιωνία');
$city_data[] = array('accid' => 'GRXX0014', 'name' => 'Αττική/Περιστέρι');
$city_data[] = array('accid' => 'GRXX0023', 'name' => 'Βόλος');
$city_data[] = array('accid' => 'GRXX0072', 'name' => 'Γαλατάς/Πόρος');
$city_data[] = array('accid' => 'GRXX0047', 'name' => 'Γαύδος');
$city_data[] = array('accid' => 'GRXX0078', 'name' => 'Γύθειο');
$city_data[] = array('accid' => 'GRXX0024', 'name' => 'Ζάκυνθος');
$city_data[] = array('accid' => 'GRXX0030', 'name' => 'Ηράκλειο/Αεροδρόμιο');
$city_data[] = array('accid' => 'GRXX0019', 'name' => 'Θεσσαλονίκη');
$city_data[] = array('accid' => 'GRXX0052', 'name' => 'Ίος');
$city_data[] = array('accid' => 'GRXX0008', 'name' => 'Καβάλα');
$city_data[] = array('accid' => 'GRXX0036', 'name' => 'Καλαμάτα');
$city_data[] = array('accid' => 'GRXX0063', 'name' => 'Κάλυμνος');
$city_data[] = array('accid' => 'GRXX0034', 'name' => 'Καρδίτσα');
$city_data[] = array('accid' => 'GRXX0073', 'name' => 'Κάρπαθος');
$city_data[] = array('accid' => 'GRXX0053', 'name' => 'Κέα');
$city_data[] = array('accid' => 'GRXX0026', 'name' => 'Κέρκυρα/Αεροδρόμιο');
$city_data[] = array('accid' => 'GRXX0068', 'name' => 'Κέρκυρα');
$city_data[] = array('accid' => 'GRXX0035', 'name' => 'Κεφαλονιά');
$city_data[] = array('accid' => 'GRXX0055', 'name' => 'Κίμωλος');
$city_data[] = array('accid' => 'GRXX0037', 'name' => 'Κοζάνη');
$city_data[] = array('accid' => 'GRXX0010', 'name' => 'Κόρινθος');
$city_data[] = array('accid' => 'GRXX0046', 'name' => 'Κρήτη');
$city_data[] = array('accid' => 'GRXX0029', 'name' => 'Κύθηρα');
$city_data[] = array('accid' => 'GRXX0054', 'name' => 'Κύθνος');
$city_data[] = array('accid' => 'GRXX0038', 'name' => 'Κως');
$city_data[] = array('accid' => 'GRXX0011', 'name' => 'Λάρισα');
$city_data[] = array('accid' => 'GRXX0039', 'name' => 'Λήμνος');
$city_data[] = array('accid' => 'GRXX0079', 'name' => 'Λιβαδειά');
$city_data[] = array('accid' => 'GRXX0028', 'name' => 'Μεθώνη');
$city_data[] = array('accid' => 'GRXX0056', 'name' => 'Μήλος');
$city_data[] = array('accid' => 'GRXX0045', 'name' => 'Μύκονος');
$city_data[] = array('accid' => 'GRXX0070', 'name' => 'Μυτιλήνη/Αγία Παρασκευή');
$city_data[] = array('accid' => 'GRXX0040', 'name' => 'Μυτιλήνη');
$city_data[] = array('accid' => 'GRXX0041', 'name' => 'Νάξος');
$city_data[] = array('accid' => 'GRXX0076', 'name' => 'Ναύπλιο');
$city_data[] = array('accid' => 'GRXX0064', 'name' => 'Νίσυρος');
$city_data[] = array('accid' => 'GRXX0080', 'name' => 'Ξάνθη');
$city_data[] = array('accid' => 'GRXX0057', 'name' => 'Πάρος');
$city_data[] = array('accid' => 'GRXX0065', 'name' => 'Πάτμος');
$city_data[] = array('accid' => 'GRXX0013', 'name' => 'Πάτρα');
$city_data[] = array('accid' => 'GRXX0015', 'name' => 'Πειραιάς');
$city_data[] = array('accid' => 'GRXX0074', 'name' => 'Πολιχνίτος');
$city_data[] = array('accid' => 'GRXX0016', 'name' => 'Πρέβεζα');
$city_data[] = array('accid' => 'GRXX0017', 'name' => 'Ρόδος');
$city_data[] = array('accid' => 'GRXX0018', 'name' => 'Σαλαμίνα');
$city_data[] = array('accid' => 'GRXX0042', 'name' => 'Σάμος');
$city_data[] = array('accid' => 'GRXX0044', 'name' => 'Σαντορίνη');
$city_data[] = array('accid' => 'GRXX0058', 'name' => 'Σέριφος');
$city_data[] = array('accid' => 'GRXX0020', 'name' => 'Σέρρες');
$city_data[] = array('accid' => 'GRXX0060', 'name' => 'Σίκινος');
$city_data[] = array('accid' => 'GRXX0059', 'name' => 'Σίφνος');
$city_data[] = array('accid' => 'GRXX0021', 'name' => 'Σκιάθος');
$city_data[] = array('accid' => 'GRXX0022', 'name' => 'Σκύρος');
$city_data[] = array('accid' => 'GRXX0077', 'name' => 'Σπάρτη');
$city_data[] = array('accid' => 'GRXX0081', 'name' => 'Σπέτσες');
$city_data[] = array('accid' => 'GRXX0066', 'name' => 'Σύμη');
$city_data[] = array('accid' => 'GRXX0061', 'name' => 'Σύρος');
$city_data[] = array('accid' => 'GRXX0067', 'name' => 'Τήλος');
$city_data[] = array('accid' => 'GRXX0062', 'name' => 'Τήνος');
$city_data[] = array('accid' => 'GRXX0043', 'name' => 'Τρίπολη');
$city_data[] = array('accid' => 'GRXX0051', 'name' => 'Φολέγανδρος');
$city_data[] = array('accid' => 'GRXX0009', 'name' => 'Χαλκίδα');
$city_data[] = array('accid' => 'GRXX0025', 'name' => 'Χαλκιδική/Ζωγράφος');
$city_data[] = array('accid' => 'GRXX0032', 'name' => 'Χανιά/Σούδα');
$city_data[] = array('accid' => 'GRXX0033', 'name' => 'Χίος');

?>