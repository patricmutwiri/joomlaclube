<?php

// City package for Sierra Leone 

$city_name = 'Sierra Leone';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'SLXX0001', 'name' => 'Freetown');

?>
