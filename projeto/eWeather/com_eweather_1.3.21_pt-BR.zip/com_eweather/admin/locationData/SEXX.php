<?php

// City package for Seychelles 

$city_name = 'Seychelles';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'SEXX0001', 'name' => 'Seychelles International Airport');

?>
