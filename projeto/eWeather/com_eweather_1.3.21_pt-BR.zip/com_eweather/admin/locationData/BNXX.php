<?php

// City package for Benin 

$city_name = 'Benin';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'BNXX0001', 'name' => 'Cotonou');
$city_data[] = array('accid' => 'BNXX0002', 'name' => 'Porto-Novo');
$city_data[] = array('accid' => 'BNXX0003', 'name' => 'Save');

?>
