<?php

// City package for Trinidad and Tobago
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Trinidad and Tobago';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'TDXX0001', 'name' => 'Arima');
$city_data[] = array('accid' => 'TDXX0002', 'name' => 'Port-of-Spain');
$city_data[] = array('accid' => 'TDXX0003', 'name' => 'San Fernando');
$city_data[] = array('accid' => 'TDXX0006', 'name' => 'Scarborough');
$city_data[] = array('accid' => 'TDXX0005', 'name' => 'Tobago');
$city_data[] = array('accid' => 'TDXX0004', 'name' => 'Trinidad');

?>
