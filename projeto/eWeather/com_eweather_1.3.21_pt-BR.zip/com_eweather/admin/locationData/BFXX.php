<?php

// City package for Bahamas
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Bahamas';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'WEXX0001', 'name' => 'Bethlehem');
$city_data[] = array('accid' => 'BFXX0001', 'name' => 'Andros Town');
$city_data[] = array('accid' => 'BFXX0002', 'name' => 'Freeport');
$city_data[] = array('accid' => 'BFXX0006', 'name' => 'George Town');
$city_data[] = array('accid' => 'BFXX0003', 'name' => 'Governor`s Harbour');
$city_data[] = array('accid' => 'BFXX0004', 'name' => 'Matthew Town');
$city_data[] = array('accid' => 'BFXX0005', 'name' => 'Nassau');

?>
