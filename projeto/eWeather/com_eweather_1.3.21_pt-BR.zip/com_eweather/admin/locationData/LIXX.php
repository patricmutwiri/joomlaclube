<?php

// City package for Liberia 

$city_name = 'Liberia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'LIXX0002', 'name' => 'Monrovia');

?>
