<?php

// City package for Mongolia 
//
// Last updated: 10/06/2009
// By:           Bob Lavey

$city_name = 'Mongolia';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'MGXX0001', 'name' => 'Aldar');
$city_data[] = array('accid' => 'MGXX0023', 'name' => 'Altai');
$city_data[] = array('accid' => 'MGXX0028', 'name' => 'Arvaiheer');
$city_data[] = array('accid' => 'MGXX0020', 'name' => 'Baitag');
$city_data[] = array('accid' => 'MGXX0033', 'name' => 'Baruun-Urt');
$city_data[] = array('accid' => 'MGXX0017', 'name' => 'Baruunkharaa');
$city_data[] = array('accid' => 'MGXX0007', 'name' => 'Baruunturuun');
$city_data[] = array('accid' => 'MGXX0031', 'name' => 'Bayan-Ovoo');
$city_data[] = array('accid' => 'MGXX0022', 'name' => 'Bayanbulag');
$city_data[] = array('accid' => 'MGXX0039', 'name' => 'Bayandelger');
$city_data[] = array('accid' => 'MGXX0027', 'name' => 'Bayanhongor');
$city_data[] = array('accid' => 'MGXX0016', 'name' => 'Bulgan');
$city_data[] = array('accid' => 'MGXX0019', 'name' => 'Choibalsan');
$city_data[] = array('accid' => 'MGXX0030', 'name' => 'Choir');
$city_data[] = array('accid' => 'MGXX0041', 'name' => 'Dalanzadgad');
$city_data[] = array('accid' => 'MGXX0018', 'name' => 'Dashbalbar');
$city_data[] = array('accid' => 'MGXX0002', 'name' => 'Dzuunmod');
$city_data[] = array('accid' => 'MGXX0015', 'name' => 'Erdenemandal');
$city_data[] = array('accid' => 'MGXX0025', 'name' => 'Gaiuut');
$city_data[] = array('accid' => 'MGXX0005', 'name' => 'Hatgal');
$city_data[] = array('accid' => 'MGXX0010', 'name' => 'Hovd');
$city_data[] = array('accid' => 'MGXX0026', 'name' => 'Hujirt');
$city_data[] = array('accid' => 'MGXX0014', 'name' => 'Hutag');
$city_data[] = array('accid' => 'MGXX0034', 'name' => 'Khalkh-Gol');
$city_data[] = array('accid' => 'MGXX0029', 'name' => 'Maanti');
$city_data[] = array('accid' => 'MGXX0037', 'name' => 'Mandalgovi');
$city_data[] = array('accid' => 'MGXX0035', 'name' => 'Matad');
$city_data[] = array('accid' => 'MGXX0013', 'name' => 'Muren');
$city_data[] = array('accid' => 'MGXX0009', 'name' => 'Omno-Gobi');
$city_data[] = array('accid' => 'MGXX0004', 'name' => 'Rinchinlhumbe');
$city_data[] = array('accid' => 'MGXX0036', 'name' => 'Saikhan-Ovoo');
$city_data[] = array('accid' => 'MGXX0012', 'name' => 'Tarialan');
$city_data[] = array('accid' => 'MGXX0011', 'name' => 'Tosontsengel');
$city_data[] = array('accid' => 'MGXX0024', 'name' => 'Tsetserleg');
$city_data[] = array('accid' => 'MGXX0038', 'name' => 'Tsogt-Ovoo');
$city_data[] = array('accid' => 'MGXX0008', 'name' => 'Uigi');
$city_data[] = array('accid' => 'MGXX0006', 'name' => 'Ulaan-Gom');
$city_data[] = array('accid' => 'MGXX0003', 'name' => 'Ulan Bator');
$city_data[] = array('accid' => 'MGXX0021', 'name' => 'Uliastai');
$city_data[] = array('accid' => 'MGXX0032', 'name' => 'Underkhaan');
$city_data[] = array('accid' => 'MGXX0040', 'name' => 'Zamyn-Uud');

?>
