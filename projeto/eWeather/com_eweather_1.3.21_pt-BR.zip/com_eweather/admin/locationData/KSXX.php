<?php

// City package for South Korea 
//
// Last updated: 06/24/2009
// By:           Bob Lavey

$city_name = 'South Korea';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'KSXX0001', 'name' => 'Andong');
$city_data[] = array('accid' => 'KSXX0002', 'name' => 'Anyang');
$city_data[] = array('accid' => 'KSXX0003', 'name' => 'Ch`angwon');
$city_data[] = array('accid' => 'KSXX0006', 'name' => 'Ch`onan');
$city_data[] = array('accid' => 'KSXX0007', 'name' => 'Ch`ungju');
$city_data[] = array('accid' => 'KSXX0004', 'name' => 'Cheju');
$city_data[] = array('accid' => 'KSXX0053', 'name' => 'Cheju Upper/Radar');
$city_data[] = array('accid' => 'KSXX0005', 'name' => 'Chinhae');
$city_data[] = array('accid' => 'KSXX0055', 'name' => 'Chinju');
$city_data[] = array('accid' => 'KSXX0033', 'name' => 'Cholwon');
$city_data[] = array('accid' => 'KSXX0047', 'name' => 'Chonju');
$city_data[] = array('accid' => 'KSXX0035', 'name' => 'Chunchon');
$city_data[] = array('accid' => 'KSXX0051', 'name' => 'Chungmu');
$city_data[] = array('accid' => 'KSXX0044', 'name' => 'Chupungnyong');
$city_data[] = array('accid' => 'KSXX0008', 'name' => 'Haenam');
$city_data[] = array('accid' => 'KSXX0009', 'name' => 'Inch`on');
$city_data[] = array('accid' => 'KSXX0010', 'name' => 'Iri');
$city_data[] = array('accid' => 'KSXX0011', 'name' => 'Kangnung');
$city_data[] = array('accid' => 'KSXX0012', 'name' => 'Kimch`on');
$city_data[] = array('accid' => 'KSXX0046', 'name' => 'Kunsan');
$city_data[] = array('accid' => 'KSXX0014', 'name' => 'Kwangju');
$city_data[] = array('accid' => 'KSXX0048', 'name' => 'Masan');
$city_data[] = array('accid' => 'KSXX0016', 'name' => 'Miryang');
$city_data[] = array('accid' => 'KSXX0017', 'name' => 'Mokp`o');
$city_data[] = array('accid' => 'KSXX0018', 'name' => 'Osan');
$city_data[] = array('accid' => 'KSXX0019', 'name' => 'P`ohang');
$city_data[] = array('accid' => 'KSXX0045', 'name' => 'Pohang');
$city_data[] = array('accid' => 'KSXX0020', 'name' => 'Polgyo');
$city_data[] = array('accid' => 'KSXX0050', 'name' => 'Pusan');
$city_data[] = array('accid' => 'KSXX0037', 'name' => 'Seoul');
$city_data[] = array('accid' => 'KSXX0054', 'name' => 'Sogwipo');
$city_data[] = array('accid' => 'KSXX0023', 'name' => 'Sokch`o');
$city_data[] = array('accid' => 'KSXX0032', 'name' => 'Sokcho');
$city_data[] = array('accid' => 'KSXX0024', 'name' => 'Songnam');
$city_data[] = array('accid' => 'KSXX0042', 'name' => 'Sosan');
$city_data[] = array('accid' => 'KSXX0025', 'name' => 'Suwon');
$city_data[] = array('accid' => 'KSXX0026', 'name' => 'Taegu');
$city_data[] = array('accid' => 'KSXX0034', 'name' => 'Taegwallyong');
$city_data[] = array('accid' => 'KSXX0027', 'name' => 'Taejon');
$city_data[] = array('accid' => 'KSXX0036', 'name' => 'Tonghae Radar Site');
$city_data[] = array('accid' => 'KSXX0028', 'name' => 'Uisong');
$city_data[] = array('accid' => 'KSXX0043', 'name' => 'Ulchin');
$city_data[] = array('accid' => 'KSXX0039', 'name' => 'Ullungdo');
$city_data[] = array('accid' => 'KSXX0029', 'name' => 'Ulsan');
$city_data[] = array('accid' => 'KSXX0030', 'name' => 'Waegwan');
$city_data[] = array('accid' => 'KSXX0052', 'name' => 'Wando');
$city_data[] = array('accid' => 'KSXX0038', 'name' => 'Wonju');
$city_data[] = array('accid' => 'KSXX0056', 'name' => 'Yangyang');
$city_data[] = array('accid' => 'KSXX0041', 'name' => 'Yongwol');
$city_data[] = array('accid' => 'KSXX0031', 'name' => 'Yosu');

?>
