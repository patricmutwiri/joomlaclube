<?php

// City package for Aruba
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Aruba';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'WEXX0001', 'name' => 'Bethlehem');
$city_data[] = array('accid' => 'AAXX0001', 'name' => 'Oranjestad');
$city_data[] = array('accid' => 'AAXX0002', 'name' => 'Queen Beatrix Airport');

?>
