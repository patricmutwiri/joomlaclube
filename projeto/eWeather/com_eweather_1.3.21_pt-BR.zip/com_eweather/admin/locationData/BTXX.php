<?php

// City package for Bhutan 

$city_name = 'Bhutan';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'BTXX0001', 'name' => 'Paro');
$city_data[] = array('accid' => 'BTXX0002', 'name' => 'Thimphu');

?>
