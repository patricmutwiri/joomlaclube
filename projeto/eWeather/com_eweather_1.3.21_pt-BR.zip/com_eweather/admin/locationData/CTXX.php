<?php

// City package for Central African Republic 

$city_name = 'Central African Republic';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'CTXX0003', 'name' => 'Bangassou');
$city_data[] = array('accid' => 'CTXX0001', 'name' => 'Bangui');
$city_data[] = array('accid' => 'CTXX0002', 'name' => 'Bimbo');
$city_data[] = array('accid' => 'CTXX0004', 'name' => 'Bossangoa');

?>
