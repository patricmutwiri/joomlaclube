<?php

// City package for Brunei 

$city_name = 'Brunei';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'BXXX0001', 'name' => 'Brunei Airport');
$city_data[] = array('accid' => 'BXXX0002', 'name' => 'Kuala Belait');

?>
