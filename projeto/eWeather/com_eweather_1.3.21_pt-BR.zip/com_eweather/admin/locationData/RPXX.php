<?php

// City package for Philippines 
//
// Last updated: 06/25/2009
// By:           Bob Lavey

$city_name = 'Philippines';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'RPXX0058', 'name' => 'Alabat');
$city_data[] = array('accid' => 'RPXX0056', 'name' => 'Ambulong');
$city_data[] = array('accid' => 'RPXX0001', 'name' => 'Angeles');
$city_data[] = array('accid' => 'RPXX0042', 'name' => 'Aparri');
$city_data[] = array('accid' => 'RPXX0002', 'name' => 'Bacolod');
$city_data[] = array('accid' => 'RPXX0003', 'name' => 'Bacoor');
$city_data[] = array('accid' => 'RPXX0046', 'name' => 'Baguio');
$city_data[] = array('accid' => 'RPXX0049', 'name' => 'Baler Radar Site');
$city_data[] = array('accid' => 'RPXX0039', 'name' => 'Basco');
$city_data[] = array('accid' => 'RPXX0004', 'name' => 'Butuan');
$city_data[] = array('accid' => 'RPXX0048', 'name' => 'Cabanatuan');
$city_data[] = array('accid' => 'RPXX0005', 'name' => 'Cadiz');
$city_data[] = array('accid' => 'RPXX0055', 'name' => 'Calapan');
$city_data[] = array('accid' => 'RPXX0050', 'name' => 'Casiguran');
$city_data[] = array('accid' => 'RPXX0062', 'name' => 'Catanduanes Radar Site');
$city_data[] = array('accid' => 'RPXX0067', 'name' => 'Catarman');
$city_data[] = array('accid' => 'RPXX0006', 'name' => 'Cavite');
$city_data[] = array('accid' => 'RPXX0007', 'name' => 'Cebu City');
$city_data[] = array('accid' => 'RPXX0063', 'name' => 'Coron');
$city_data[] = array('accid' => 'RPXX0059', 'name' => 'Daet');
$city_data[] = array('accid' => 'RPXX0045', 'name' => 'Dagupan');
$city_data[] = array('accid' => 'RPXX0008', 'name' => 'Davao');
$city_data[] = array('accid' => 'RPXX0009', 'name' => 'Dipolog');
$city_data[] = array('accid' => 'RPXX0010', 'name' => 'General Santos');
$city_data[] = array('accid' => 'RPXX0011', 'name' => 'Hinigaran');
$city_data[] = array('accid' => 'RPXX0044', 'name' => 'Iba');
$city_data[] = array('accid' => 'RPXX0012', 'name' => 'Iloilo');
$city_data[] = array('accid' => 'RPXX0057', 'name' => 'Infanta');
$city_data[] = array('accid' => 'RPXX0013', 'name' => 'Isabela');
$city_data[] = array('accid' => 'RPXX0038', 'name' => 'Itbayat');
$city_data[] = array('accid' => 'RPXX0014', 'name' => 'Jolo');
$city_data[] = array('accid' => 'RPXX0041', 'name' => 'Laoag');
$city_data[] = array('accid' => 'RPXX0060', 'name' => 'Legaspi');
$city_data[] = array('accid' => 'RPXX0015', 'name' => 'Libagon');
$city_data[] = array('accid' => 'RPXX0016', 'name' => 'Malolos');
$city_data[] = array('accid' => 'RPXX0017', 'name' => 'Manila');
$city_data[] = array('accid' => 'RPXX0018', 'name' => 'Masbate');
$city_data[] = array('accid' => 'RPXX0019', 'name' => 'Meycauayan');
$city_data[] = array('accid' => 'RPXX0020', 'name' => 'Mobo');
$city_data[] = array('accid' => 'RPXX0047', 'name' => 'Munoz');
$city_data[] = array('accid' => 'RPXX0021', 'name' => 'Nutol');
$city_data[] = array('accid' => 'RPXX0022', 'name' => 'Olongapo');
$city_data[] = array('accid' => 'RPXX0023', 'name' => 'Olutanga');
$city_data[] = array('accid' => 'RPXX0024', 'name' => 'Orani');
$city_data[] = array('accid' => 'RPXX0025', 'name' => 'Pagadian');
$city_data[] = array('accid' => 'RPXX0070', 'name' => 'Pampanga');
$city_data[] = array('accid' => 'RPXX0026', 'name' => 'Pasig');
$city_data[] = array('accid' => 'RPXX0069', 'name' => 'Puerto Princesa');
$city_data[] = array('accid' => 'RPXX0027', 'name' => 'Quezon City');
$city_data[] = array('accid' => 'RPXX0065', 'name' => 'Romblon');
$city_data[] = array('accid' => 'RPXX0028', 'name' => 'Roxas');
$city_data[] = array('accid' => 'RPXX0029', 'name' => 'San Fernando');
$city_data[] = array('accid' => 'RPXX0064', 'name' => 'San Jose');
$city_data[] = array('accid' => 'RPXX0030', 'name' => 'San Pablo');
$city_data[] = array('accid' => 'RPXX0053', 'name' => 'Sangley Point');
$city_data[] = array('accid' => 'RPXX0031', 'name' => 'Santa Cruz');
$city_data[] = array('accid' => 'RPXX0032', 'name' => 'Sapao');
$city_data[] = array('accid' => 'RPXX0054', 'name' => 'Science Garden');
$city_data[] = array('accid' => 'RPXX0033', 'name' => 'Surigao');
$city_data[] = array('accid' => 'RPXX0068', 'name' => 'Tacloban');
$city_data[] = array('accid' => 'RPXX0034', 'name' => 'Tandag');
$city_data[] = array('accid' => 'RPXX0035', 'name' => 'Tarlac');
$city_data[] = array('accid' => 'RPXX0052', 'name' => 'Tayabas');
$city_data[] = array('accid' => 'RPXX0036', 'name' => 'Taytay');
$city_data[] = array('accid' => 'RPXX0043', 'name' => 'Tuguegarao');
$city_data[] = array('accid' => 'RPXX0040', 'name' => 'Vigan');
$city_data[] = array('accid' => 'RPXX0061', 'name' => 'Virac');
$city_data[] = array('accid' => 'RPXX0037', 'name' => 'Zamboanga');

?>
