<?php

// City package for Georgia 
//
// Last updated: 06/24/2009
// By:           Bob Lavey

$city_name = 'Georgia';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'GGXX0001', 'name' => 'Gori');
$city_data[] = array('accid' => 'GGXX0002', 'name' => 'K`ut`aisi');
$city_data[] = array('accid' => 'GGXX0003', 'name' => 'Rustavi');
$city_data[] = array('accid' => 'GGXX0004', 'name' => 'Tbilisi');

?>
