<?php

// City package for Lesotho 

$city_name = 'Lesotho';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'LTXX0001', 'name' => 'Maseru');
$city_data[] = array('accid' => 'LTXX0002', 'name' => 'Morija');
$city_data[] = array('accid' => 'LTXX0003', 'name' => 'Teyateyaneng');

?>
