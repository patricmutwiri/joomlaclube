<?php

// City package for Somalia 

$city_name = 'Somalia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'SOXX0003', 'name' => 'Hargeisa');
$city_data[] = array('accid' => 'SOXX0001', 'name' => 'Kismanyo');
$city_data[] = array('accid' => 'SOXX0002', 'name' => 'Mogadishu');

?>
