<?php

// City package for Chile 
//
// Last updated: 06/23/2009
// By:           Bob Lavey

$city_name = 'Chile';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'CIXX0001', 'name' => 'Antofagasta');
$city_data[] = array('accid' => 'CIXX0002', 'name' => 'Arica');
$city_data[] = array('accid' => 'CIXX0003', 'name' => 'Balmaceda');
$city_data[] = array('accid' => 'CIXX0004', 'name' => 'Baquedano');
$city_data[] = array('accid' => 'CIXX0033', 'name' => 'Calama');
$city_data[] = array('accid' => 'CIXX0005', 'name' => 'Caldera');
$city_data[] = array('accid' => 'CIXX0051', 'name' => 'Cerro Blanco');
$city_data[] = array('accid' => 'CIXX0046', 'name' => 'Cerro Canasta');
$city_data[] = array('accid' => 'CIXX0029', 'name' => 'Chaiten');
$city_data[] = array('accid' => 'CIXX0006', 'name' => 'Chillan');
$city_data[] = array('accid' => 'CIXX0049', 'name' => 'Colina');
$city_data[] = array('accid' => 'CIXX0007', 'name' => 'Concepcion');
$city_data[] = array('accid' => 'CIXX0030', 'name' => 'Copiapo');
$city_data[] = array('accid' => 'CIXX0008', 'name' => 'Coquimbo');
$city_data[] = array('accid' => 'CIXX0054', 'name' => 'Curacavi');
$city_data[] = array('accid' => 'CIXX0031', 'name' => 'Curico');
$city_data[] = array('accid' => 'CIXX0055', 'name' => 'Easter Island');
$city_data[] = array('accid' => 'CIXX0009', 'name' => 'Iquique');
$city_data[] = array('accid' => 'CIXX0035', 'name' => 'Isla Diego Ramirez');
$city_data[] = array('accid' => 'CIXX0034', 'name' => 'Islotes Evangelistas');
$city_data[] = array('accid' => 'CIXX0010', 'name' => 'La Serena');
$city_data[] = array('accid' => 'CIXX0042', 'name' => 'Los Cuartitos');
$city_data[] = array('accid' => 'CIXX0045', 'name' => 'Monturaque');
$city_data[] = array('accid' => 'CIXX0050', 'name' => 'Morro de La Bandera');
$city_data[] = array('accid' => 'CIXX0011', 'name' => 'Nunoa');
$city_data[] = array('accid' => 'CIXX0012', 'name' => 'Osorno');
$city_data[] = array('accid' => 'CIXX0013', 'name' => 'Ovalle');
$city_data[] = array('accid' => 'CIXX0032', 'name' => 'Palena');
$city_data[] = array('accid' => 'CIXX0044', 'name' => 'Portillo');
$city_data[] = array('accid' => 'CIXX0040', 'name' => 'Pucon');
$city_data[] = array('accid' => 'CIXX0014', 'name' => 'Puerto Aisen');
$city_data[] = array('accid' => 'CIXX0015', 'name' => 'Puerto Montt');
$city_data[] = array('accid' => 'CIXX0016', 'name' => 'Puerto Natales');
$city_data[] = array('accid' => 'CIXX0017', 'name' => 'Punta Arenas');
$city_data[] = array('accid' => 'CIXX0018', 'name' => 'Rancagua');
$city_data[] = array('accid' => 'CIXX0052', 'name' => 'Rocas de Santo Domingo');
$city_data[] = array('accid' => 'CIXX0047', 'name' => 'San Antonio');
$city_data[] = array('accid' => 'CIXX0019', 'name' => 'San Bernardo');
$city_data[] = array('accid' => 'CIXX0020', 'name' => 'Santiago');
$city_data[] = array('accid' => 'CIXX0053', 'name' => 'Talagante');
$city_data[] = array('accid' => 'CIXX0021', 'name' => 'Talca');
$city_data[] = array('accid' => 'CIXX0022', 'name' => 'Talcahuano');
$city_data[] = array('accid' => 'CIXX0023', 'name' => 'Temuco');
$city_data[] = array('accid' => 'CIXX0041', 'name' => 'Termas de Chillan');
$city_data[] = array('accid' => 'CIXX0024', 'name' => 'Toco');
$city_data[] = array('accid' => 'CIXX0025', 'name' => 'Valdivia');
$city_data[] = array('accid' => 'CIXX0026', 'name' => 'Valparaiso');
$city_data[] = array('accid' => 'CIXX0048', 'name' => 'Villa Alemana');
$city_data[] = array('accid' => 'CIXX0038', 'name' => 'Villarrica');
$city_data[] = array('accid' => 'CIXX0027', 'name' => 'Vina del Mar');
$city_data[] = array('accid' => 'CIXX0028', 'name' => 'Vitacura');

?>
