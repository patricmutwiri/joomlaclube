<?php

// City package for Nepal 

$city_name = 'Nepal';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'NPXX0001', 'name' => 'Bhaktapur');
$city_data[] = array('accid' => 'NPXX0002', 'name' => 'Kathmandu');
$city_data[] = array('accid' => 'NPXX0003', 'name' => 'Kathmandu Airport');

?>
