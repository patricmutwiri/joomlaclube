<?php

// City package for Cameroon 

$city_name = 'Cameroon';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'CMXX0001', 'name' => 'Bafoussam');
$city_data[] = array('accid' => 'BYXX0002', 'name' => 'Buea');
$city_data[] = array('accid' => 'BYXX0003', 'name' => 'Douala');
$city_data[] = array('accid' => 'BYXX0004', 'name' => 'Edea');
$city_data[] = array('accid' => 'BYXX0010', 'name' => 'Mamfe');
$city_data[] = array('accid' => 'BYXX0007', 'name' => 'Mbalmayo');
$city_data[] = array('accid' => 'BYXX0008', 'name' => 'Yaounde');

?>
