<?php

// City package for Mauritius 

$city_name = 'Mauritius';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'MPXX0001', 'name' => 'Agalega');
$city_data[] = array('accid' => 'MPXX0004', 'name' => 'Plaisance Mauritius');
$city_data[] = array('accid' => 'MPXX0003', 'name' => 'Rodrigues');
$city_data[] = array('accid' => 'MPXX0002', 'name' => 'Saint Brandon Saint Raphael');
$city_data[] = array('accid' => 'MPXX0005', 'name' => 'Vacoas Mauritius');

?>
