<?php

// City package for Sudan

$city_name = 'Sudan';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'SUXX0001', 'name' => 'El Obeid');
$city_data[] = array('accid' => 'SUXX0002', 'name' => 'Khartoum');
$city_data[] = array('accid' => 'SUXX0008', 'name' => 'Malakal');
$city_data[] = array('accid' => 'SUXX0007', 'name' => 'Nyala');
$city_data[] = array('accid' => 'SUXX0003', 'name' => 'Port Sudan');
$city_data[] = array('accid' => 'SUXX0004', 'name' => 'Umm Durman');
$city_data[] = array('accid' => 'SUXX0005', 'name' => 'Wad Madani');
$city_data[] = array('accid' => 'SUXX0006', 'name' => 'Wadi Halfa`');

?>