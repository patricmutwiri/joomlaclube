<?php

// City package for Lebanon 
// Last updated: 08/20/2009
// By:           Bob Lavey

$city_name = 'Lebanon';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'LEXX0001', 'name' => 'Ash Shuwayfat');
$city_data[] = array('accid' => 'LEXX0002', 'name' => 'Babda');
$city_data[] = array('accid' => 'LEXX0003', 'name' => 'Beirut');
$city_data[] = array('accid' => 'LEXX0004', 'name' => 'Furn ash Shubbak');
$city_data[] = array('accid' => 'LEXX0006', 'name' => 'Houche-Al-Oumara');
$city_data[] = array('accid' => 'LEXX0005', 'name' => 'Juniyah');
$city_data[] = array('accid' => 'LEXX0007', 'name' => 'Tripoli');

?>
