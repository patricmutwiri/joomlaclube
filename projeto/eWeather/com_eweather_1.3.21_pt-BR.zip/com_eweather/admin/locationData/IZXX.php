<?php

// City package for Iraq 
// Last updated: 07/18/2009
// By:           Bob Lavey

$city_name = 'Iraq';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'IZXX0001', 'name' => 'Al Azamiyah');
$city_data[] = array('accid' => 'IZXX0002', 'name' => 'Al Basrah');
$city_data[] = array('accid' => 'IZXX0003', 'name' => 'Al Hillah');
$city_data[] = array('accid' => 'IZXX0004', 'name' => 'Al Karkh');
$city_data[] = array('accid' => 'IZXX0005', 'name' => 'Al Kazimiyah');
$city_data[] = array('accid' => 'IZXX0006', 'name' => 'Al Kut');
$city_data[] = array('accid' => 'IZXX0007', 'name' => 'An Nasiriyah');
$city_data[] = array('accid' => 'IZXX0014', 'name' => 'Ar Rutbah');
$city_data[] = array('accid' => 'IZXX0008', 'name' => 'Baghdad');
$city_data[] = array('accid' => 'IZXX0009', 'name' => 'Baqubah');
$city_data[] = array('accid' => 'IZXX0010', 'name' => 'Mosul');
$city_data[] = array('accid' => 'IZXX0013', 'name' => 'Najaf');
$city_data[] = array('accid' => 'IZXX0011', 'name' => 'Nineveh');
$city_data[] = array('accid' => 'IZXX0012', 'name' => 'Tall Kayf');

?>
