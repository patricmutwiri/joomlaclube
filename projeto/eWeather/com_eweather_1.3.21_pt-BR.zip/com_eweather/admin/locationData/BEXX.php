<?php

// City package for Belgium 

$city_name = 'Belgium';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'BEXX0001', 'name' => 'Anderlecht');
$city_data[] = array('accid' => 'BEXX0002', 'name' => 'Ans');
$city_data[] = array('accid' => 'BEXX0003', 'name' => 'Antwerp');
$city_data[] = array('accid' => 'BEXX0004', 'name' => 'Aywaille');
$city_data[] = array('accid' => 'BEXX0005', 'name' => 'Brussels');
$city_data[] = array('accid' => 'BEXX0006', 'name' => 'Charleroi');
$city_data[] = array('accid' => 'BEXX0007', 'name' => 'Dendermonde');
$city_data[] = array('accid' => 'BEXX0008', 'name' => 'Gent');
$city_data[] = array('accid' => 'BEXX0009', 'name' => 'Halle');
$city_data[] = array('accid' => 'BEXX0010', 'name' => 'Herstal');
$city_data[] = array('accid' => 'BEXX0011', 'name' => 'Liege');
$city_data[] = array('accid' => 'BEXX0012', 'name' => 'Lokeren');
$city_data[] = array('accid' => 'BEXX0013', 'name' => 'Mechelen');
$city_data[] = array('accid' => 'BEXX0014', 'name' => 'Mons');
$city_data[] = array('accid' => 'BEXX0015', 'name' => 'Namur');
$city_data[] = array('accid' => 'BEXX0016', 'name' => 'Saint-Nicolas');
$city_data[] = array('accid' => 'BEXX0017', 'name' => 'Schaerbeek');
$city_data[] = array('accid' => 'BEXX0018', 'name' => 'Seraing');
$city_data[] = array('accid' => 'BEXX0019', 'name' => 'Sint-Niklaas');
$city_data[] = array('accid' => 'BEXX0020', 'name' => 'Vilvoorde');
$city_data[] = array('accid' => 'BEXX0021', 'name' => 'Koksijde');
$city_data[] = array('accid' => 'BEXX0022', 'name' => 'Oostende Airport');
$city_data[] = array('accid' => 'BEXX0023', 'name' => 'Munte');
$city_data[] = array('accid' => 'BEXX0024', 'name' => 'Uccle');
$city_data[] = array('accid' => 'BEXX0025', 'name' => 'Florennes');
$city_data[] = array('accid' => 'BEXX0026', 'name' => 'Beauvechain');
$city_data[] = array('accid' => 'BEXX0027', 'name' => 'St-Hubert');
$city_data[] = array('accid' => 'BEXX0028', 'name' => 'Kleine Brogel');
$city_data[] = array('accid' => 'BEXX0029', 'name' => 'Spa/La Sauveniere');
$city_data[] = array('accid' => 'BEXX0030', 'name' => 'Elsenborn');
$city_data[] = array('accid' => 'BEXX0031', 'name' => 'Spa');

?>
