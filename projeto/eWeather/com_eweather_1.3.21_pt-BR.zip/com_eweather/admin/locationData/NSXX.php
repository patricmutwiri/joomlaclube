<?php

// City package for Suriname 

$city_name = 'Suriname';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'NSXX0001', 'name' => 'New Nickerie');
$city_data[] = array('accid' => 'NSXX0002', 'name' => 'Paramaribo');
$city_data[] = array('accid' => 'NSXX0003', 'name' => 'Paranam');

?>
