<?php

// City package for Pakistan
// Last updated: 07/11/2009
// By:           Nadeem Iqbal [nadeem@softcorner.com]

$city_name = 'Pakistan';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array("accid" => "PKXX0001", "name" => "Chiniot");
$city_data[] = array("accid" => "PKXX0002", "name" => "Faisalabad");
$city_data[] = array("accid" => "PKXX0003", "name" => "Gujranwala");
$city_data[] = array("accid" => "PKXX0004", "name" => "Gujrat");
$city_data[] = array("accid" => "PKXX0005", "name" => "Hyderabad");
$city_data[] = array("accid" => "PKXX0006", "name" => "Islamabad");
$city_data[] = array("accid" => "PKXX0007", "name" => "Jhang Sadar");
$city_data[] = array("accid" => "PKXX0008", "name" => "Karachi");
$city_data[] = array("accid" => "PKXX0009", "name" => "Kasur");
$city_data[] = array("accid" => "PKXX0010", "name" => "Kohat");
$city_data[] = array("accid" => "PKXX0011", "name" => "Lahore");
$city_data[] = array("accid" => "PKXX0012", "name" => "Mardan");
$city_data[] = array("accid" => "PKXX0022", "name" => "Multan");
$city_data[] = array("accid" => "PKXX0024", "name" => "Nawabshah");
$city_data[] = array("accid" => "PKXX0013", "name" => "Okara");
$city_data[] = array("accid" => "PKXX0014", "name" => "Peshawar");
$city_data[] = array("accid" => "PKXX0021", "name" => "Quetta");
$city_data[] = array("accid" => "PKXX0015", "name" => "Rawalpindi");
$city_data[] = array("accid" => "PKXX0016", "name" => "Sahiwal");
$city_data[] = array("accid" => "PKXX0017", "name" => "Sargodha");
$city_data[] = array("accid" => "PKXX0018", "name" => "Shekhupura");
$city_data[] = array("accid" => "PKXX0019", "name" => "Sialkot");
$city_data[] = array("accid" => "PKXX0023", "name" => "Sukkur");
$city_data[] = array("accid" => "PKXX0020", "name" => "Thatta");

?>
