<?php

// City package for British Virgin Islands
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'British Virgin Islands';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'VIXX0001', 'name' => 'Road Town');
$city_data[] = array('accid' => 'VIXX0002', 'name' => 'Anegada');
$city_data[] = array('accid' => 'VIXX0003', 'name' => 'Cooper Island');
$city_data[] = array('accid' => 'VIXX0004', 'name' => 'Virgin Gorda');

?>
