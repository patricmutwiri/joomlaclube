<?php

// City package for Senegal 

$city_name = 'Senegal';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'SGXX0001', 'name' => 'Dakar');
$city_data[] = array('accid' => 'SGXX0002', 'name' => 'Kaolack');
$city_data[] = array('accid' => 'SGXX0003', 'name' => 'Mbour');
$city_data[] = array('accid' => 'SGXX0004', 'name' => 'Saint-Louis');
$city_data[] = array('accid' => 'SGXX0005', 'name' => 'Thies');
$city_data[] = array('accid' => 'SGXX0006', 'name' => 'Ziguinchor');

?>
