<?php

// City package for Romania
//
// Last updated: 06/06/2009
// By:           Bob Lavey

$city_name = 'Romania';
$city_version = '1.0.0';
$city_data = array();


$city_data[] = array('accid' => 'ROXX0024', 'name' => 'Arad');
$city_data[] = array('accid' => 'ROXX0023', 'name' => 'Bacau');
$city_data[] = array('accid' => 'ROXX0018', 'name' => 'Botosani');
$city_data[] = array('accid' => 'ROXX0001', 'name' => 'Braila');
$city_data[] = array('accid' => 'ROXX0002', 'name' => 'Brasov');
$city_data[] = array('accid' => 'ROXX0003', 'name' => 'Bucharest');
$city_data[] = array('accid' => 'ROXX0004', 'name' => 'Buzau');
$city_data[] = array('accid' => 'ROXX0042', 'name' => 'Calafat');
$city_data[] = array('accid' => 'ROXX0032', 'name' => 'Calarasi');
$city_data[] = array('accid' => 'ROXX0005', 'name' => 'Campina');
$city_data[] = array('accid' => 'ROXX0026', 'name' => 'Caransebes');
$city_data[] = array('accid' => 'ROXX0021', 'name' => 'Ceahlau Toaca');
$city_data[] = array('accid' => 'ROXX0022', 'name' => 'Cluj-Napoca');
$city_data[] = array('accid' => 'ROXX0034', 'name' => 'Constanta');
$city_data[] = array('accid' => 'ROXX0007', 'name' => 'Craiova');
$city_data[] = array('accid' => 'ROXX0031', 'name' => 'Drobeta Tr. Severin');
$city_data[] = array('accid' => 'ROXX0008', 'name' => 'Focsani');
$city_data[] = array('accid' => 'ROXX0009', 'name' => 'Galati');
$city_data[] = array('accid' => 'ROXX0035', 'name' => 'Gheorgheni');
$city_data[] = array('accid' => 'ROXX0010', 'name' => 'Giurgiu');
$city_data[] = array('accid' => 'ROXX0020', 'name' => 'Iasi');
$city_data[] = array('accid' => 'ROXX0019', 'name' => 'Oradea');
$city_data[] = array('accid' => 'ROXX0036', 'name' => 'Petrosani');
$city_data[] = array('accid' => 'ROXX0011', 'name' => 'Pitesti');
$city_data[] = array('accid' => 'ROXX0012', 'name' => 'Ploiesti');
$city_data[] = array('accid' => 'ROXX0037', 'name' => 'Prundu');
$city_data[] = array('accid' => 'ROXX0028', 'name' => 'Rimnicu Vilcea');
$city_data[] = array('accid' => 'ROXX0013', 'name' => 'Rosiori de Vede');
$city_data[] = array('accid' => 'ROXX0045', 'name' => 'Sase Martie');
$city_data[] = array('accid' => 'ROXX0038', 'name' => 'Satu Mare');
$city_data[] = array('accid' => 'ROXX0044', 'name' => 'Sebes');
$city_data[] = array('accid' => 'ROXX0014', 'name' => 'Sibiu');
$city_data[] = array('accid' => 'ROXX0017', 'name' => 'Sighetu Marmatiei');
$city_data[] = array('accid' => 'ROXX0015', 'name' => 'Slatina');
$city_data[] = array('accid' => 'ROXX0016', 'name' => 'Slobozia');
$city_data[] = array('accid' => 'ROXX0030', 'name' => 'Sulina');
$city_data[] = array('accid' => 'ROXX0039', 'name' => 'Talmaciu');
$city_data[] = array('accid' => 'ROXX0043', 'name' => 'Targu-Mures');
$city_data[] = array('accid' => 'ROXX0040', 'name' => 'Timisoara');
$city_data[] = array('accid' => 'ROXX0041', 'name' => 'Tirgoviste');
$city_data[] = array('accid' => 'ROXX0025', 'name' => 'Vf. Omu');

?>