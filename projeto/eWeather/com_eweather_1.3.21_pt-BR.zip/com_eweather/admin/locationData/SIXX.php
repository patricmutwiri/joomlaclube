<?php

// City package for Slovenia 
//
// Last updated: 06/24/2009
// By:           Bob Lavey

$city_name = 'Slovenia';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'SIXX0004', 'name' => 'Celje');
$city_data[] = array('accid' => 'SIXX0010', 'name' => 'Kocevje');
$city_data[] = array('accid' => 'SIXX0001', 'name' => 'Kranj');
$city_data[] = array('accid' => 'SIXX0008', 'name' => 'Krsko');
$city_data[] = array('accid' => 'SIXX0002', 'name' => 'Ljubljana');
$city_data[] = array('accid' => 'SIXX0005', 'name' => 'Murska Sobota');
$city_data[] = array('accid' => 'SIXX0009', 'name' => 'Novo Mesto');
$city_data[] = array('accid' => 'SIXX0007', 'name' => 'Postojna');
$city_data[] = array('accid' => 'SIXX0003', 'name' => 'Skofljica');
$city_data[] = array('accid' => 'SIXX0006', 'name' => 'Slovenska Bistrica');

?>
