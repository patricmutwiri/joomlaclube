<?php

// City package for U.S. Virgin Islands
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'U.S. Virgin Islands';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'USVI0001', 'name' => 'Christiansted');
$city_data[] = array('accid' => 'USVI0002', 'name' => 'Frederiksted');
$city_data[] = array('accid' => 'USVI0003', 'name' => 'Kingshill');
$city_data[] = array('accid' => 'USVI0004', 'name' => 'Saint Croix');
$city_data[] = array('accid' => 'USVI0005', 'name' => 'Saint John');
$city_data[] = array('accid' => 'USVI0006', 'name' => 'Saint Thomas');
$city_data[] = array('accid' => 'USVI0007', 'name' => 'Water Island');

?>
