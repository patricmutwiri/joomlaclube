<?php

// City package for Guinea-Bissau 

$city_name = 'Guinea-Bissau';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'PUXX0001', 'name' => 'Bissau');

?>
