<?php

// City package for Saudi Arabia

$city_name = 'المملكة العربية السعودية';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'SAXX0001', 'name' => 'أبيار علي');
$city_data[] = array('accid' => 'SAXX0002', 'name' => 'الدمام');
$city_data[] = array('accid' => 'SAXX0003', 'name' => 'الحريق');
$city_data[] = array('accid' => 'SAXX0004', 'name' => 'الحلوة');
$city_data[] = array('accid' => 'SAXX0005', 'name' => 'الجوف');
$city_data[] = array('accid' => 'SAXX0006', 'name' => 'الخبر');
$city_data[] = array('accid' => 'SAXX0007', 'name' => 'الليث');
$city_data[] = array('accid' => 'SAXX0008', 'name' => 'Al Qabiyah');
$city_data[] = array('accid' => 'SAXX0009', 'name' => 'السليمانية');
$city_data[] = array('accid' => 'SAXX0010', 'name' => 'بحرا');
$city_data[] = array('accid' => 'SAXX0011', 'name' => 'جدة/مطار الملك عبدالعزيز');
$city_data[] = array('accid' => 'SAXX0012', 'name' => 'جدة');
$city_data[] = array('accid' => 'SAXX0013', 'name' => 'مكة');
$city_data[] = array('accid' => 'SAXX0014', 'name' => 'المدينة المنور');
$city_data[] = array('accid' => 'SAXX0015', 'name' => 'القرعاء');
$city_data[] = array('accid' => 'SAXX0016', 'name' => 'رابغ');
$city_data[] = array('accid' => 'SAXX0017', 'name' => 'الرياض');
$city_data[] = array('accid' => 'SAXX0018', 'name' => 'الرياض/مطار الملك خالد');
$city_data[] = array('accid' => 'SAXX0019', 'name' => 'سكاكا');
$city_data[] = array('accid' => 'SAXX0021', 'name' => 'الظهران');
$city_data[] = array('accid' => 'SAXX0022', 'name' => 'طريف');
$city_data[] = array('accid' => 'SAXX0023', 'name' => 'عرعر');
$city_data[] = array('accid' => 'SAXX0024', 'name' => 'القريات');
$city_data[] = array('accid' => 'SAXX0025', 'name' => 'رفحاء');
$city_data[] = array('accid' => 'SAXX0026', 'name' => 'القيصومة');
$city_data[] = array('accid' => 'SAXX0027', 'name' => 'تبوك');
$city_data[] = array('accid' => 'SAXX0028', 'name' => 'حائل');
$city_data[] = array('accid' => 'SAXX0029', 'name' => 'الوجه');
$city_data[] = array('accid' => 'SAXX0030', 'name' => 'القصيم');
$city_data[] = array('accid' => 'SAXX0031', 'name' => 'الأحساء');
$city_data[] = array('accid' => 'SAXX0032', 'name' => 'ينبع');
$city_data[] = array('accid' => 'SAXX0033', 'name' => 'الطائف');
$city_data[] = array('accid' => 'SAXX0034', 'name' => 'وادي الدواسر');
$city_data[] = array('accid' => 'SAXX0035', 'name' => 'بيشة');
$city_data[] = array('accid' => 'SAXX0036', 'name' => 'أبها');
$city_data[] = array('accid' => 'SAXX0037', 'name' => 'خميس مشيط');
$city_data[] = array('accid' => 'SAXX0038', 'name' => 'نجران');
$city_data[] = array('accid' => 'SAXX0039', 'name' => 'شرورة');
$city_data[] = array('accid' => 'SAXX0040', 'name' => 'جازان');
$city_data[] = array('accid' => 'SAXX0041', 'name' => 'العقيق');
$city_data[] = array('accid' => 'SAXX0042', 'name' => 'الدوادمي');

?>