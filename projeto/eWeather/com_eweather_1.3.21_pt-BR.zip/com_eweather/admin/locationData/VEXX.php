<?php

// City package for Venezuela 
//
// Last updated: 06/24/2009
// By:           Bob Lavey

$city_name = 'Venezuela';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'VEXX0001', 'name' => 'Acarigua');
$city_data[] = array('accid' => 'VEXX0048', 'name' => 'Anaco');
$city_data[] = array('accid' => 'VEXX0046', 'name' => 'Antimano');
$city_data[] = array('accid' => 'VEXX0002', 'name' => 'Barcelona');
$city_data[] = array('accid' => 'VEXX0003', 'name' => 'Barinas');
$city_data[] = array('accid' => 'VEXX0004', 'name' => 'Barquisimeto');
$city_data[] = array('accid' => 'VEXX0049', 'name' => 'Barrio El Guafel');
$city_data[] = array('accid' => 'VEXX0041', 'name' => 'Baruta');
$city_data[] = array('accid' => 'VEXX0005', 'name' => 'Cabimas');
$city_data[] = array('accid' => 'VEXX0006', 'name' => 'Calabozo');
$city_data[] = array('accid' => 'VEXX0007', 'name' => 'Cantaura');
$city_data[] = array('accid' => 'VEXX0008', 'name' => 'Caracas');
$city_data[] = array('accid' => 'VEXX0040', 'name' => 'Carora');
$city_data[] = array('accid' => 'VEXX0042', 'name' => 'Charallave');
$city_data[] = array('accid' => 'VEXX0009', 'name' => 'Ciudad Bolivar');
$city_data[] = array('accid' => 'VEXX0010', 'name' => 'Ciudad Guayana');
$city_data[] = array('accid' => 'VEXX0047', 'name' => 'Colonia Tovar');
$city_data[] = array('accid' => 'VEXX0011', 'name' => 'Coro');
$city_data[] = array('accid' => 'VEXX0012', 'name' => 'Cumana');
$city_data[] = array('accid' => 'VEXX0013', 'name' => 'El Tigre');
$city_data[] = array('accid' => 'VEXX0051', 'name' => 'El Vigia');
$city_data[] = array('accid' => 'VEXX0044', 'name' => 'Generalisimo Francisco De Miranda AB');
$city_data[] = array('accid' => 'VEXX0014', 'name' => 'Guanare');
$city_data[] = array('accid' => 'VEXX0043', 'name' => 'Guarenas');
$city_data[] = array('accid' => 'VEXX0015', 'name' => 'Guasdualito');
$city_data[] = array('accid' => 'VEXX0016', 'name' => 'Isla de Margarita');
$city_data[] = array('accid' => 'VEXX0017', 'name' => 'Los Teques');
$city_data[] = array('accid' => 'VEXX0050', 'name' => 'Mantecal');
$city_data[] = array('accid' => 'VEXX0018', 'name' => 'Maracaibo');
$city_data[] = array('accid' => 'VEXX0019', 'name' => 'Maracay');
$city_data[] = array('accid' => 'VEXX0020', 'name' => 'Maturin');
$city_data[] = array('accid' => 'VEXX0021', 'name' => 'Mene Grande');
$city_data[] = array('accid' => 'VEXX0022', 'name' => 'Merida');
$city_data[] = array('accid' => 'VEXX0033', 'name' => 'Muelle Paraguana');
$city_data[] = array('accid' => 'VEXX0023', 'name' => 'Porlamar');
$city_data[] = array('accid' => 'VEXX0024', 'name' => 'Puerto Cabello');
$city_data[] = array('accid' => 'VEXX0025', 'name' => 'Puerto la Cruz');
$city_data[] = array('accid' => 'VEXX0035', 'name' => 'Puerto Ordaz');
$city_data[] = array('accid' => 'VEXX0037', 'name' => 'Punto Fijo');
$city_data[] = array('accid' => 'VEXX0026', 'name' => 'San Antonio del Tachira');
$city_data[] = array('accid' => 'VEXX0027', 'name' => 'San Cristobal');
$city_data[] = array('accid' => 'VEXX0028', 'name' => 'San Fernando');
$city_data[] = array('accid' => 'VEXX0034', 'name' => 'Santa Elena');
$city_data[] = array('accid' => 'VEXX0045', 'name' => 'Santa Teresa');
$city_data[] = array('accid' => 'VEXX0036', 'name' => 'Trujilo');
$city_data[] = array('accid' => 'VEXX0029', 'name' => 'Tumeremo');
$city_data[] = array('accid' => 'VEXX0030', 'name' => 'Upata');
$city_data[] = array('accid' => 'VEXX0031', 'name' => 'Valencia');
$city_data[] = array('accid' => 'VEXX0032', 'name' => 'Valera');

?>
