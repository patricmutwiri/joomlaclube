<?php

// City package for Bosnia
// Last updated: 30/08/2009
// By:           Adnan Kurtovi� www.supervijesti.com


$city_name = 'Bosnia';
$city_version = '1.0.0';
$city_data = array();


$city_data[] = array('accid' => 'BKXX0001', 'name' => 'Banja Luka');
$city_data[] = array('accid' => 'BKXX0007', 'name' => 'Brcko');
$city_data[] = array('accid' => 'BKXX0002', 'name' => 'Kotor Varos');
$city_data[] = array('accid' => 'BKXX0006', 'name' => 'Mostar');
$city_data[] = array('accid' => 'BKXX0003', 'name' => 'Sanski Most');
$city_data[] = array('accid' => 'BKXX0004', 'name' => 'Sarajevo');
$city_data[] = array('accid' => 'BKXX0005', 'name' => 'Zenica');

?>

