<?php

// City package for French Guiana 

$city_name = 'French Guiana';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'CAYX', 'name' => 'Cayenne');

?>
