<?php

// City package for Malawi 

$city_name = 'Malawi';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'MIXX0001', 'name' => 'Dowa');
$city_data[] = array('accid' => 'MIXX0002', 'name' => 'Lilongwe');

?>
