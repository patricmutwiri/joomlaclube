<?php

// City package for Costa Rica 
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Costa Rica';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'CSXX0001', 'name' => 'Alajuela');
$city_data[] = array('accid' => 'CSXX0002', 'name' => 'Canas');
$city_data[] = array('accid' => 'CSXX0003', 'name' => 'Cartago');
$city_data[] = array('accid' => 'CSXX0010', 'name' => 'Chacarita');
$city_data[] = array('accid' => 'CSXX0004', 'name' => 'Guapiles');
$city_data[] = array('accid' => 'CSXX0013', 'name' => 'Heredia');
$city_data[] = array('accid' => 'CSXX0005', 'name' => 'Liberia');
$city_data[] = array('accid' => 'CSXX0011', 'name' => 'Nicoya');
$city_data[] = array('accid' => 'CSXX0006', 'name' => 'Puerto Limon');
$city_data[] = array('accid' => 'CSXX0007', 'name' => 'Puntarenas');
$city_data[] = array('accid' => 'CSXX0008', 'name' => 'San Isidro del General');
$city_data[] = array('accid' => 'CSXX0009', 'name' => 'San Jose');
$city_data[] = array('accid' => 'CSXX0014', 'name' => 'Turrialba');

?>
