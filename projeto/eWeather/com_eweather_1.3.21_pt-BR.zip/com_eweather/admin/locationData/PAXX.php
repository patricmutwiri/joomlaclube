<?php

// City package for Paraguay 
//
// Last updated: 08/11/2009
// By:           Roberto Sens Hourcade

$city_name = 'Paraguay';
$city_version = '1.0.0';
$city_data = array();

$city_data[] = array('accid' => 'PAXX0001', 'name' => 'Asuncion');
$city_data[] = array('accid' => 'PAXX0002', 'name' => 'Caacupe');
$city_data[] = array('accid' => 'PAXX0003', 'name' => 'Ciudad del Este');
$city_data[] = array('accid' => 'PAXX0004', 'name' => 'Concepcion');
$city_data[] = array('accid' => 'PAXX0005', 'name' => 'Coronel Oviedo');
$city_data[] = array('accid' => 'PAXX0006', 'name' => 'Encarnacion');
$city_data[] = array('accid' => 'PAXX0012', 'name' => 'Fuerte Olimpo');
$city_data[] = array('accid' => 'PAXX0007', 'name' => 'Mariscal Estigarribia');
$city_data[] = array('accid' => 'PAXX0008', 'name' => 'Nueva Asuncion');
$city_data[] = array('accid' => 'PAXX0009', 'name' => 'Paraguari');
$city_data[] = array('accid' => 'PAXX0011', 'name' => 'Pilar');
$city_data[] = array('accid' => 'PAXX0013', 'name' => 'Punta Rieles');
$city_data[] = array('accid' => 'PAXX0014', 'name' => 'San Estanislao');
$city_data[] = array('accid' => 'PAXX0010', 'name' => 'San Juan Bautista');


?>
