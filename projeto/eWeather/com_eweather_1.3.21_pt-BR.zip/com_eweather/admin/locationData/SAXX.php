<?php

// City package for Saudi Arabia
// Last updated: 08/20/2009
// By:           Bob Lavey

$city_name = 'Saudi Arabia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'SAXX0036', 'name' => 'Abha');
$city_data[] = array('accid' => 'SAXX0001', 'name' => 'Abyar Ali');
$city_data[] = array('accid' => 'SAXX0002', 'name' => 'Ad Dammam');
$city_data[] = array('accid' => 'SAXX0042', 'name' => 'Ad Dawadimi');
$city_data[] = array('accid' => 'SAXX0031', 'name' => 'Al Ahsa');
$city_data[] = array('accid' => 'SAXX0041', 'name' => 'Al Aqiq');
$city_data[] = array('accid' => 'SAXX0003', 'name' => 'Al Hariq');
$city_data[] = array('accid' => 'SAXX0004', 'name' => 'Al Hulwah');
$city_data[] = array('accid' => 'SAXX0005', 'name' => 'Al Jawf');
$city_data[] = array('accid' => 'SAXX0006', 'name' => 'Al Khubar');
$city_data[] = array('accid' => 'SAXX0007', 'name' => 'Al Lith');
$city_data[] = array('accid' => 'SAXX0008', 'name' => 'Al Qabiyah');
$city_data[] = array('accid' => 'SAXX0026', 'name' => 'Al Qaysumah');
$city_data[] = array('accid' => 'SAXX0023', 'name' => 'Arar');
$city_data[] = array('accid' => 'SAXX0009', 'name' => 'As Sulaymaniyah');
$city_data[] = array('accid' => 'SAXX0010', 'name' => 'Bahrah');
$city_data[] = array('accid' => 'SAXX0035', 'name' => 'Bisha');
$city_data[] = array('accid' => 'SAXX0030', 'name' => 'Gassim');
$city_data[] = array('accid' => 'SAXX0040', 'name' => 'Gizan');
$city_data[] = array('accid' => 'SAXX0024', 'name' => 'Guriat');
$city_data[] = array('accid' => 'SAXX0028', 'name' => 'Hail');
$city_data[] = array('accid' => 'SAXX0011', 'name' => 'Jeddah/Abdul Aziz');
$city_data[] = array('accid' => 'SAXX0012', 'name' => 'Jiddah');
$city_data[] = array('accid' => 'SAXX0037', 'name' => 'Khamis Mushait');
$city_data[] = array('accid' => 'SAXX0013', 'name' => 'Mecca');
$city_data[] = array('accid' => 'SAXX0014', 'name' => 'Medina');
$city_data[] = array('accid' => 'SAXX0038', 'name' => 'Najran');
$city_data[] = array('accid' => 'SAXX0015', 'name' => 'Qara');
$city_data[] = array('accid' => 'SAXX0016', 'name' => 'Rabigh');
$city_data[] = array('accid' => 'SAXX0025', 'name' => 'Rafha');
$city_data[] = array('accid' => 'SAXX0017', 'name' => 'Riyadh');
$city_data[] = array('accid' => 'SAXX0018', 'name' => 'Riyadh/Khaled');
$city_data[] = array('accid' => 'SAXX0019', 'name' => 'Sakakah');
$city_data[] = array('accid' => 'SAXX0039', 'name' => 'Sharurah');
$city_data[] = array('accid' => 'SAXX0027', 'name' => 'Tabuk');
$city_data[] = array('accid' => 'SAXX0033', 'name' => 'Taif');
$city_data[] = array('accid' => 'SAXX0022', 'name' => 'Turaif');
$city_data[] = array('accid' => 'SAXX0034', 'name' => 'Wadi Al Dawasser Airport');
$city_data[] = array('accid' => 'SAXX0029', 'name' => 'Wejh');
$city_data[] = array('accid' => 'SAXX0032', 'name' => 'Yenbo');
$city_data[] = array('accid' => 'SAXX0021', 'name' => 'Zahran');

?>