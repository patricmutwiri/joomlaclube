<?php

// City package for West Bank
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'West Bank';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'WEXX0001', 'name' => 'Bethlehem');
$city_data[] = array('accid' => 'WEXX0002', 'name' => 'Hebron');
$city_data[] = array('accid' => 'WEXX0003', 'name' => 'Nabulus');
$city_data[] = array('accid' => 'WEXX0004', 'name' => 'Qalandiyah');
$city_data[] = array('accid' => 'WEXX0005', 'name' => 'Ramallah');

?>
