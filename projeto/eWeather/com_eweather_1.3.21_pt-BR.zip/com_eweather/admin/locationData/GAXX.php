<?php

// City package for The Gambia 

$city_name = 'The Gambia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'GAXX0001', 'name' => 'Banjul');

?>
