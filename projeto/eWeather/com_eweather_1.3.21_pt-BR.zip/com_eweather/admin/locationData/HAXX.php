<?php

// City package for Haiti 

$city_name = 'Haiti';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'HAXX0001', 'name' => 'Gonaives');
$city_data[] = array('accid' => 'HAXX0002', 'name' => 'Les Cayes');
$city_data[] = array('accid' => 'HAXX0003', 'name' => 'Petionville');
$city_data[] = array('accid' => 'HAXX0004', 'name' => 'Port au Prince');
$city_data[] = array('accid' => 'HAXX0005', 'name' => 'SaintMarc');

?>
