<?php

// City package for Djibouti 

$city_name = 'Djibouti';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'DJXX0001', 'name' => 'Djibouti');

?>
