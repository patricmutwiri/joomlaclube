<?php

// City package for Belarus
// Last updated: 08/04/2009
// By:           Bob Lavey

$city_name = 'Belarus';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'BOXX0020', 'name' => 'Baranovici');
$city_data[] = array('accid' => 'BOXX0022', 'name' => 'Bobruysr');
$city_data[] = array('accid' => 'BOXX0001', 'name' => 'Borisov');
$city_data[] = array('accid' => 'BOXX0023', 'name' => 'Brest');
$city_data[] = array('accid' => 'BOXX0002', 'name' => 'Dobrush');
$city_data[] = array('accid' => 'BOXX0003', 'name' => 'Dzerzhinsk');
$city_data[] = array('accid' => 'BOXX0004', 'name' => 'Gomel');
$city_data[] = array('accid' => 'BOXX0016', 'name' => 'Grodno');
$city_data[] = array('accid' => 'BOXX0027', 'name' => 'Kobrin');
$city_data[] = array('accid' => 'BOXX0019', 'name' => 'Kostjvkovici');
$city_data[] = array('accid' => 'BOXX0013', 'name' => 'Lepel');
$city_data[] = array('accid' => 'BOXX0017', 'name' => 'Lida');
$city_data[] = array('accid' => 'BOXX0012', 'name' => 'Lyntupy');
$city_data[] = array('accid' => 'BOXX0005', 'name' => 'Minsk');
$city_data[] = array('accid' => 'BOXX0018', 'name' => 'Mogilev');
$city_data[] = array('accid' => 'BOXX0026', 'name' => 'Mozyr');
$city_data[] = array('accid' => 'BOXX0006', 'name' => 'Mozyr');
$city_data[] = array('accid' => 'BOXX0015', 'name' => 'Orsa');
$city_data[] = array('accid' => 'BOXX0007', 'name' => 'Pinsk');
$city_data[] = array('accid' => 'BOXX0008', 'name' => 'Rakov');
$city_data[] = array('accid' => 'BOXX0009', 'name' => 'Rechitsa');
$city_data[] = array('accid' => 'BOXX0021', 'name' => 'Sluck');
$city_data[] = array('accid' => 'BOXX0011', 'name' => 'Verhnedvinsk');
$city_data[] = array('accid' => 'BOXX0010', 'name' => 'Vetka');
$city_data[] = array('accid' => 'BOXX0014', 'name' => 'Vitebsk');
$city_data[] = array('accid' => 'BOXX0025', 'name' => 'Zitkovici');

?>
