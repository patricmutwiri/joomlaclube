<?php

// City package for Barbados
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Barbados';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'BBXX0001', 'name' => 'Bridgetown');


?>
