<?php

// City package for Macedonia 
//
// Last updated: 07/06/2009
// By:           Bob Lavey

$city_name = 'Macedonia';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'MKXX0008', 'name' => 'Berovo');
$city_data[] = array('accid' => 'MKXX0005', 'name' => 'Bitola');
$city_data[] = array('accid' => 'MKXX0010', 'name' => 'Demir Kapija');
$city_data[] = array('accid' => 'MKXX0011', 'name' => 'Gevgelija');
$city_data[] = array('accid' => 'MKXX0012', 'name' => 'Gostivar');
$city_data[] = array('accid' => 'MKXX0003', 'name' => 'Kriva Palanka');
$city_data[] = array('accid' => 'MKXX0009', 'name' => 'Lazaropole');
$city_data[] = array('accid' => 'MKXX0004', 'name' => 'Ohrid');
$city_data[] = array('accid' => 'MKXX0006', 'name' => 'Prilep');
$city_data[] = array('accid' => 'MKXX0001', 'name' => 'Skopje');
$city_data[] = array('accid' => 'MKXX0007', 'name' => 'Stip');
$city_data[] = array('accid' => 'MKXX0013', 'name' => 'Tetovo');
$city_data[] = array('accid' => 'MKXX0002', 'name' => 'Veles');

?>
