<?php

// City package for Madagascar 

$city_name = 'Madagascar';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'MAXX0001', 'name' => 'Andevoranto');
$city_data[] = array('accid' => 'MAXX0002', 'name' => 'Antananarivo');
$city_data[] = array('accid' => 'MAXX0004', 'name' => 'Mahavelona');
$city_data[] = array('accid' => 'MAXX0006', 'name' => 'Toamasina');

?>
