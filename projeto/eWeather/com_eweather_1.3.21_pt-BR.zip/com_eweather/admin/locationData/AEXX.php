<?php

// City package for Dubai

$city_name = 'Dubai';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'AEXX0001', 'name' => 'Abu Dhabi');
$city_data[] = array('accid' => 'AEXX0002', 'name' => 'AJMAN');
$city_data[] = array('accid' => 'AEXX0003', 'name' => 'Sharjah');
$city_data[] = array('accid' => 'AEXX0004', 'name' => 'Dubai');
$city_data[] = array('accid' => 'AEXX0005', 'name' => 'Sharjah International');
$city_data[] = array('accid' => 'AEXX0006', 'name' => 'Umm al Qaywayn');
$city_data[] = array('accid' => 'AEXX0007', 'name' => 'Ras al Khaimah');

?>