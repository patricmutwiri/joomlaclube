<?php

// City package for Fiji 
// Last updated: 11/11/2009
// By:           Bob Lavey

$city_name = 'Fiji';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'FJXX0007', 'name' => 'Matuku');
$city_data[] = array('accid' => 'FJXX0001', 'name' => 'Nadi');
$city_data[] = array('accid' => 'FJXX0002', 'name' => 'Nambouwalu');
$city_data[] = array('accid' => 'FJXX0005', 'name' => 'Nausori');
$city_data[] = array('accid' => 'FJXX0008', 'name' => 'Ono-I-Lau');
$city_data[] = array('accid' => 'FJXX0009', 'name' => 'Suva');
$city_data[] = array('accid' => 'FJXX0010', 'name' => 'Vanua Mbalavu');
$city_data[] = array('accid' => 'FJXX0004', 'name' => 'Viwa Island');
$city_data[] = array('accid' => 'FJXX0006', 'name' => 'Vunisea');
$city_data[] = array('accid' => 'FJXX0003', 'name' => 'Yasawa-I-Rara');
	
?>
