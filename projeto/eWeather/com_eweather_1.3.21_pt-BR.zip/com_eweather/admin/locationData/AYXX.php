<?php

// City package for Antarctica 
//
// Last updated: 06/24/2009
// By:           Bob Lavey

$city_name = 'Antarctica';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'AYXX0007', 'name' => 'Base Arturo Prat');
$city_data[] = array('accid' => 'AYXX0009', 'name' => 'Base Bernardo O`Higgins');
$city_data[] = array('accid' => 'AYXX0001', 'name' => 'Base Esperanza');
$city_data[] = array('accid' => 'AYXX0003', 'name' => 'Base Jubany');
$city_data[] = array('accid' => 'AYXX0005', 'name' => 'Base Marambio Centro Met. Antartico');
$city_data[] = array('accid' => 'AYXX0002', 'name' => 'Base Orcadas');
$city_data[] = array('accid' => 'AYXX0006', 'name' => 'Centro Met. Antartico');
$city_data[] = array('accid' => 'AYXX0004', 'name' => 'Dinamet-Uruguay');
$city_data[] = array('accid' => 'AYXX0008', 'name' => 'Great Wall');


?>
