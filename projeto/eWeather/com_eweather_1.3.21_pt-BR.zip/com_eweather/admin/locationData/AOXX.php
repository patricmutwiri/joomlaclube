<?php

// City package for Angola 

$city_name = 'Angola';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'AOXX0002', 'name' => 'Cabinda');
$city_data[] = array('accid' => 'AOXX0003', 'name' => 'Cacuaco');
$city_data[] = array('accid' => 'AOXX0005', 'name' => 'Caxito');
$city_data[] = array('accid' => 'AOXX0008', 'name' => 'Luanda');

?>
