<?php

// City package for Uzbekistan 
//
// Last updated: 06/24/2009
// By:           Bob Lavey

$city_name = 'Uzbekistan';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'UZXX0006', 'name' => 'Ak-Bajtal');
$city_data[] = array('accid' => 'UZXX0001', 'name' => 'Almalyk');
$city_data[] = array('accid' => 'UZXX0018', 'name' => 'Buhara');
$city_data[] = array('accid' => 'UZXX0010', 'name' => 'Buzaubaj');
$city_data[] = array('accid' => 'UZXX0007', 'name' => 'Chimbaj');
$city_data[] = array('accid' => 'UZXX0014', 'name' => 'Dzizak');
$city_data[] = array('accid' => 'UZXX0017', 'name' => 'Fergana');
$city_data[] = array('accid' => 'UZXX0019', 'name' => 'Karshi');
$city_data[] = array('accid' => 'UZXX0002', 'name' => 'Kattakurgan');
$city_data[] = array('accid' => 'UZXX0005', 'name' => 'Kungrad');
$city_data[] = array('accid' => 'UZXX0016', 'name' => 'Namangan');
$city_data[] = array('accid' => 'UZXX0008', 'name' => 'Nukus');
$city_data[] = array('accid' => 'UZXX0013', 'name' => 'Nurata');
$city_data[] = array('accid' => 'UZXX0012', 'name' => 'Pskem');
$city_data[] = array('accid' => 'UZXX0003', 'name' => 'Samarkand');
$city_data[] = array('accid' => 'UZXX0015', 'name' => 'Syr-Dar`Ja');
$city_data[] = array('accid' => 'UZXX0011', 'name' => 'Tamdy');
$city_data[] = array('accid' => 'UZXX0004', 'name' => 'Tashkent');
$city_data[] = array('accid' => 'UZXX0020', 'name' => 'Termez');
$city_data[] = array('accid' => 'UZXX0009', 'name' => 'Urgench');

?>
