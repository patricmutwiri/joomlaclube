<?php

// City package for Uruguay 
//
// Last updated: 06/24/2009
// By:           Bob Lavey

$city_name = 'Uruguay';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'UYXX0010', 'name' => 'Artigas');
$city_data[] = array('accid' => 'UYXX0001', 'name' => 'Chapicuy');
$city_data[] = array('accid' => 'UYXX0011', 'name' => 'Colonia');
$city_data[] = array('accid' => 'UYXX0002', 'name' => 'Durazno');
$city_data[] = array('accid' => 'UYXX0003', 'name' => 'Las Piedras');
$city_data[] = array('accid' => 'UYXX0004', 'name' => 'Maldonado');
$city_data[] = array('accid' => 'UYXX0005', 'name' => 'Melo');
$city_data[] = array('accid' => 'UYXX0018', 'name' => 'Mercedes');
$city_data[] = array('accid' => 'UYXX0006', 'name' => 'Montevideo');
$city_data[] = array('accid' => 'UYXX0014', 'name' => 'Paso De Los Toros');
$city_data[] = array('accid' => 'UYXX0017', 'name' => 'Paysandu');
$city_data[] = array('accid' => 'UYXX0007', 'name' => 'Punta del Este');
$city_data[] = array('accid' => 'UYXX0013', 'name' => 'Rivera');
$city_data[] = array('accid' => 'UYXX0008', 'name' => 'Salto');
$city_data[] = array('accid' => 'UYXX0012', 'name' => 'Tacuarembo');
$city_data[] = array('accid' => 'UYXX0009', 'name' => 'Treinta y Tres');

?>
