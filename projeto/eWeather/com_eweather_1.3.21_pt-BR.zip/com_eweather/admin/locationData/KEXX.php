<?php

// City package for Kenya 

$city_name = 'Kenya';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'KEXX0001', 'name' => 'Athi River');
$city_data[] = array('accid' => 'KEXX0016', 'name' => 'Garissa');
$city_data[] = array('accid' => 'KEXX0002', 'name' => 'Kakamega');
$city_data[] = array('accid' => 'KEXX0003', 'name' => 'Kericho');
$city_data[] = array('accid' => 'KEXX0004', 'name' => 'Kisii');
$city_data[] = array('accid' => 'KEXX0005', 'name' => 'Kisumu');
$city_data[] = array('accid' => 'KEXX0014', 'name' => 'Kitale');
$city_data[] = array('accid' => 'KEXX0006', 'name' => 'Konza');
$city_data[] = array('accid' => 'KEXX0012', 'name' => 'Lodwar');
$city_data[] = array('accid' => 'KEXX0017', 'name' => 'Makindu');
$city_data[] = array('accid' => 'KEXX0007', 'name' => 'Malindi');
$city_data[] = array('accid' => 'KEXX0013', 'name' => 'Marsabit');
$city_data[] = array('accid' => 'KEXX0015', 'name' => 'Meru');
$city_data[] = array('accid' => 'KEXX0008', 'name' => 'Mombasa');
$city_data[] = array('accid' => 'KEXX0009', 'name' => 'Nairobi');
$city_data[] = array('accid' => 'KEXX0010', 'name' => 'Nakuru');
$city_data[] = array('accid' => 'KEXX0011', 'name' => 'Thika');
$city_data[] = array('accid' => 'KEXX0018', 'name' => 'Voi');
$city_data[] = array('accid' => 'KEXX0019', 'name' => 'Wajir');

?>
