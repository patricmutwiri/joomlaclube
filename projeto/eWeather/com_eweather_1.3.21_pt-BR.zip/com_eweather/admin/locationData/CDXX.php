<?php

// City package for Chad 

$city_name = 'Chad';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'CDXX0002', 'name' => 'Faya');
$city_data[] = array('accid' => 'CDXX0003', 'name' => 'Ndjamena');

?>
