<?php

// City package for Iran 
// Last updated: 09/23/2009
// By:           Bob Lavey

$city_name = 'Iran';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'IRXX0001', 'name' => 'Abadan');
$city_data[] = array('accid' => 'IRXX0032', 'name' => 'Ahwaz');
$city_data[] = array('accid' => 'IRXX0030', 'name' => 'Arak');
$city_data[] = array('accid' => 'IRXX0002', 'name' => 'Azar Shahr');
$city_data[] = array('accid' => 'IRXX0026', 'name' => 'Babulsar');
$city_data[] = array('accid' => 'IRXX0043', 'name' => 'Bandar-E Anzali');
$city_data[] = array('accid' => 'IRXX0040', 'name' => 'Bandar-E Mahshahr');
$city_data[] = array('accid' => 'IRXX0033', 'name' => 'Bandarabbass');
$city_data[] = array('accid' => 'IRXX0031', 'name' => 'Birjand');
$city_data[] = array('accid' => 'IRXX0042', 'name' => 'Bojnurd');
$city_data[] = array('accid' => 'IRXX0037', 'name' => 'Dow Gonbadan');
$city_data[] = array('accid' => 'IRXX0003', 'name' => 'Esfahan');
$city_data[] = array('accid' => 'IRXX0004', 'name' => 'Eslamshahr');
$city_data[] = array('accid' => 'IRXX0036', 'name' => 'Fasa');
$city_data[] = array('accid' => 'IRXX0044', 'name' => 'Gorgan');
$city_data[] = array('accid' => 'IRXX0035', 'name' => 'Heleylah');
$city_data[] = array('accid' => 'IRXX0005', 'name' => 'Kanavis');
$city_data[] = array('accid' => 'IRXX0006', 'name' => 'Karaj');
$city_data[] = array('accid' => 'IRXX0034', 'name' => 'Kerman');
$city_data[] = array('accid' => 'IRXX0029', 'name' => 'Kermanshah');
$city_data[] = array('accid' => 'IRXX0022', 'name' => 'Khoy');
$city_data[] = array('accid' => 'IRXX0007', 'name' => 'Marv Dasht');
$city_data[] = array('accid' => 'IRXX0045', 'name' => 'Masheh');
$city_data[] = array('accid' => 'IRXX0008', 'name' => 'Mashhad');
$city_data[] = array('accid' => 'IRXX0038', 'name' => 'Masjed Soleyman');
$city_data[] = array('accid' => 'IRXX0009', 'name' => 'Mehriz');
$city_data[] = array('accid' => 'IRXX0010', 'name' => 'Najafabad');
$city_data[] = array('accid' => 'IRXX0039', 'name' => 'Omidiyeh');
$city_data[] = array('accid' => 'IRXX0023', 'name' => 'Orumieh');
$city_data[] = array('accid' => 'IRXX0011', 'name' => 'Osku');
$city_data[] = array('accid' => 'IRXX0012', 'name' => 'Persepolis');
$city_data[] = array('accid' => 'IRXX0013', 'name' => 'Qomsheh');
$city_data[] = array('accid' => 'IRXX0025', 'name' => 'Ramsar');
$city_data[] = array('accid' => 'IRXX0014', 'name' => 'Rey');
$city_data[] = array('accid' => 'IRXX0027', 'name' => 'Sabzevar');
$city_data[] = array('accid' => 'IRXX0015', 'name' => 'Shiraz');
$city_data[] = array('accid' => 'IRXX0016', 'name' => 'Tabriz');
$city_data[] = array('accid' => 'IRXX0017', 'name' => 'Taft');
$city_data[] = array('accid' => 'IRXX0018', 'name' => 'Tehran');
$city_data[] = array('accid' => 'IRXX0028', 'name' => 'Torbat-Heydarieh');
$city_data[] = array('accid' => 'IRXX0019', 'name' => 'Yazd');
$city_data[] = array('accid' => 'IRXX0020', 'name' => 'Zahedan');
$city_data[] = array('accid' => 'IRXX0024', 'name' => 'Zanjan');
$city_data[] = array('accid' => 'IRXX0021', 'name' => 'Zargan');

?>
