<?php

// City package for Burkina Faso 

$city_name = 'Burkina Faso';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'UVXX0001', 'name' => 'Ouagadougou');

?>
