<?php

// City package for Reunion Islands 

$city_name = 'Reunion Islands';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'REXX0002', 'name' => 'Saint-Denis/Gillot');
$city_data[] = array('accid' => 'REXX0001', 'name' => 'Serge/Frolow Ile Tromelin');

?>
