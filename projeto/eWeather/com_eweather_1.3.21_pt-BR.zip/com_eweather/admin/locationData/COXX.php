<?php

// City package for Colombia 
// Last updated: 06/22/2009
// By:           Bob Lavey

$city_name = 'Colombia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'COXX0039', 'name' => 'Apartado');
$city_data[] = array('accid' => 'COXX0035', 'name' => 'Arauca');
$city_data[] = array('accid' => 'COXX0001', 'name' => 'Armenia');
$city_data[] = array('accid' => 'COXX0006', 'name' => 'Barranca-bermeja');
$city_data[] = array('accid' => 'COXX0002', 'name' => 'Barranquilla');
$city_data[] = array('accid' => 'COXX0003', 'name' => 'Bello');
$city_data[] = array('accid' => 'COXX0004', 'name' => 'Bogota');
$city_data[] = array('accid' => 'COXX0005', 'name' => 'Bucaramanga');
$city_data[] = array('accid' => 'COXX0007', 'name' => 'Buenaventura');
$city_data[] = array('accid' => 'COXX0008', 'name' => 'Cali');
$city_data[] = array('accid' => 'COXX0009', 'name' => 'Cartagena');
$city_data[] = array('accid' => 'COXX0010', 'name' => 'Cartago');
$city_data[] = array('accid' => 'COXX0049', 'name' => 'Corinto');
$city_data[] = array('accid' => 'COXX0011', 'name' => 'Cucuta');
$city_data[] = array('accid' => 'COXX0012', 'name' => 'Envigado');
$city_data[] = array('accid' => 'COXX0013', 'name' => 'Floridablanca');
$city_data[] = array('accid' => 'COXX0040', 'name' => 'Gaviotas');
$city_data[] = array('accid' => 'COXX0014', 'name' => 'Girardot');
$city_data[] = array('accid' => 'COXX0015', 'name' => 'Ibague');
$city_data[] = array('accid' => 'COXX0016', 'name' => 'Ipiales');
$city_data[] = array('accid' => 'COXX0017', 'name' => 'Itagui');
$city_data[] = array('accid' => 'COXX0050', 'name' => 'La Estrella');
$city_data[] = array('accid' => 'COXX0018', 'name' => 'Leticia');
$city_data[] = array('accid' => 'COXX0019', 'name' => 'Manizales');
$city_data[] = array('accid' => 'COXX0020', 'name' => 'Medellin');
$city_data[] = array('accid' => 'COXX0036', 'name' => 'Mitu');
$city_data[] = array('accid' => 'COXX0021', 'name' => 'Monteria');
$city_data[] = array('accid' => 'COXX0037', 'name' => 'Neiva');
$city_data[] = array('accid' => 'COXX0022', 'name' => 'Palmira');
$city_data[] = array('accid' => 'COXX0023', 'name' => 'Pasto');
$city_data[] = array('accid' => 'COXX0024', 'name' => 'Pereira');
$city_data[] = array('accid' => 'COXX0047', 'name' => 'Pijao');
$city_data[] = array('accid' => 'COXX0025', 'name' => 'Popayan');
$city_data[] = array('accid' => 'COXX0041', 'name' => 'Puerto Asis');
$city_data[] = array('accid' => 'COXX0046', 'name' => 'Quibdo');
$city_data[] = array('accid' => 'COXX0044', 'name' => 'Riohacha');
$city_data[] = array('accid' => 'COXX0043', 'name' => 'Rionegro/J. M. Cordova');
$city_data[] = array('accid' => 'COXX0026', 'name' => 'Sabanalarga');
$city_data[] = array('accid' => 'COXX0048', 'name' => 'Salento');
$city_data[] = array('accid' => 'COXX0027', 'name' => 'San Andres');
$city_data[] = array('accid' => 'COXX0028', 'name' => 'Santa Marta');
$city_data[] = array('accid' => 'COXX0029', 'name' => 'Sincelejo');
$city_data[] = array('accid' => 'COXX0030', 'name' => 'Sogamoso');
$city_data[] = array('accid' => 'COXX0051', 'name' => 'Solano');
$city_data[] = array('accid' => 'COXX0031', 'name' => 'Soledad');
$city_data[] = array('accid' => 'COXX0031', 'name' => 'Tumaco');
$city_data[] = array('accid' => 'COXX0031', 'name' => 'Tunja');
$city_data[] = array('accid' => 'COXX0031', 'name' => 'Valledupar');
$city_data[] = array('accid' => 'COXX0031', 'name' => 'Villavicencio');

?>
