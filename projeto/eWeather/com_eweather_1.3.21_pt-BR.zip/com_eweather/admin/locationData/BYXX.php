<?php

// City package for Burundi 

$city_name = 'Burundi';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'BYXX0001', 'name' => 'Bujumbura');

?>
