<?php

// City package for Tanzania 

$city_name = 'Tanzania';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'TZXX0001', 'name' => 'Dar es Salaam');
$city_data[] = array('accid' => 'TZXX0002', 'name' => 'Dodoma');
$city_data[] = array('accid' => 'TZXX0003', 'name' => 'Kigoma');
$city_data[] = array('accid' => 'TZXX0004', 'name' => 'Mtwara');
$city_data[] = array('accid' => 'TZXX0007', 'name' => 'Mwanza');
$city_data[] = array('accid' => 'TZXX0005', 'name' => 'Tanga');
$city_data[] = array('accid' => 'TZXX0006', 'name' => 'Zanzibar');

?>
