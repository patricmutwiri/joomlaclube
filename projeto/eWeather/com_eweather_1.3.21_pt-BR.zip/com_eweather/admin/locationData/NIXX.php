<?php

// City package for Nigeria 

$city_name = 'Nigeria';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'NIXX0001', 'name' => 'Aba');
$city_data[] = array('accid' => 'NIXX0002', 'name' => 'Abeokuta');
$city_data[] = array('accid' => 'NIXX0022', 'name' => 'Abuja');
$city_data[] = array('accid' => 'NIXX0003', 'name' => 'Birnin Kebbi');
$city_data[] = array('accid' => 'NIXX0004', 'name' => 'Calabar');
$city_data[] = array('accid' => 'NIXX0005', 'name' => 'Dange');
$city_data[] = array('accid' => 'NIXX0006', 'name' => 'Enugu');
$city_data[] = array('accid' => 'NIXX0007', 'name' => 'Gwarzo');
$city_data[] = array('accid' => 'NIXX0008', 'name' => 'Ibadan');
$city_data[] = array('accid' => 'NIXX0009', 'name' => 'Iwo');
$city_data[] = array('accid' => 'NIXX0010', 'name' => 'Kano');
$city_data[] = array('accid' => 'NIXX0011', 'name' => 'Kware');
$city_data[] = array('accid' => 'NIXX0012', 'name' => 'Lagos');
$city_data[] = array('accid' => 'NIXX0013', 'name' => 'Maiduguri');
$city_data[] = array('accid' => 'NIXX0014', 'name' => 'Mushin');
$city_data[] = array('accid' => 'NIXX0015', 'name' => 'Onitsha');
$city_data[] = array('accid' => 'NIXX0016', 'name' => 'Oyo');
$city_data[] = array('accid' => 'NIXX0017', 'name' => 'Port Harcourt');
$city_data[] = array('accid' => 'NIXX0018', 'name' => 'Sokoto');
$city_data[] = array('accid' => 'NIXX0019', 'name' => 'Zaria');

?>
