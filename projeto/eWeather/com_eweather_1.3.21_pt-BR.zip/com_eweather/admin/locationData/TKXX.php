<?php

// City package for Turks and Caicos Islands
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Turks and Caicos Islands';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'TKXX0001', 'name' => 'Grand Turk');

?>
