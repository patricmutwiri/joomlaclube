<?php

// City package for El Salvador 

$city_name = 'El Salvador';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'ESXX0006', 'name' => 'Acajutla');
$city_data[] = array('accid' => 'ESXX0007', 'name' => 'San Miguel');
$city_data[] = array('accid' => 'ESXX0002', 'name' => 'San Vincente');
$city_data[] = array('accid' => 'ESXX0001', 'name' => 'San Salvador');
$city_data[] = array('accid' => 'ESXX0003', 'name' => 'Santa Ana');
$city_data[] = array('accid' => 'ESXX0004', 'name' => 'Sonsonate');
$city_data[] = array('accid' => 'ESXX0005', 'name' => 'Usulutan');

?>
