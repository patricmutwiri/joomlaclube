<?php

// City package for Bahrain 
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Bahrain';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'BAXX0001', 'name' => 'Al Manama');
$city_data[] = array('accid' => 'BAXX0002', 'name' => 'Al Muharraq');

?>
