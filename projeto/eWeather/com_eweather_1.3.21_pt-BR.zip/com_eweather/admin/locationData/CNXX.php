<?php

// City package for Comoros 

$city_name = 'Comoros';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'CNXX0001', 'name' => 'Dzaoudzi');
$city_data[] = array('accid' => 'CNXX0002', 'name' => 'Dzaoudzi/FPamanzi');
$city_data[] = array('accid' => 'CNXX0003', 'name' => 'Moroni/FHahaya');

?>
