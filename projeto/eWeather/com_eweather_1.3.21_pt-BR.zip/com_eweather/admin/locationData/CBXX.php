<?php

// City package for Cambodia
// Last updated: 08/24/2009
// By:           Bob Lavey

$city_name = 'Cambodia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'CBXX0001', 'name' => 'Phnom Penh');

?>