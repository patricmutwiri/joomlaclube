<?php

// City package for Jordan 
//
// Last updated: 06/24/2009
// By:           Bob Lavey

$city_name = 'Jordan';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'JOXX0001', 'name' => 'Al Aqabah');
$city_data[] = array('accid' => 'JOXX0002', 'name' => 'Amman');
$city_data[] = array('accid' => 'JOXX0003', 'name' => 'Az Zarqa`');
$city_data[] = array('accid' => 'JOXX0004', 'name' => 'Madaba');
$city_data[] = array('accid' => 'JOXX0007', 'name' => 'Queen Alia Airport');
$city_data[] = array('accid' => 'JOXX0008', 'name' => 'Safi');
$city_data[] = array('accid' => 'JOXX0005', 'name' => 'Sahab');
$city_data[] = array('accid' => 'JOXX0006', 'name' => 'Zuwayza');

?>
