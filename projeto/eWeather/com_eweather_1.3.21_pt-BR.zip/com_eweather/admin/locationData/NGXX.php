<?php

// City package for Niger 

$city_name = 'Niger';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'NGXX0001', 'name' => 'Agadez');
$city_data[] = array('accid' => 'NGXX0002', 'name' => 'Assaouas');
$city_data[] = array('accid' => 'NGXX0010', 'name' => 'Bilma');
$city_data[] = array('accid' => 'NGXX0011', 'name' => 'Diffa');
$city_data[] = array('accid' => 'NGXX0008', 'name' => 'Magaria');
$city_data[] = array('accid' => 'NGXX0009', 'name' => 'Maine-Soroa');
$city_data[] = array('accid' => 'NGXX0006', 'name' => 'Maradi');
$city_data[] = array('accid' => 'NGXX0003', 'name' => 'Niamey');
$city_data[] = array('accid' => 'NGXX0005', 'name' => 'Tahoua');
$city_data[] = array('accid' => 'NGXX0004', 'name' => 'Tillabery');
$city_data[] = array('accid' => 'NGXX0007', 'name' => 'Zinder');

?>
