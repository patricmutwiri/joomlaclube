<?php

// City package for Slovakia  
//
// Last updated: 11/11/2009
// By:           Bob Lavey

$city_name = 'Slovakia';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'LOXX0013', 'name' => 'Banska Stiavnica');
$city_data[] = array('accid' => 'LOXX0017', 'name' => 'Bardejov');
$city_data[] = array('accid' => 'LOXX0001', 'name' => 'Bratislava');
$city_data[] = array('accid' => 'LOXX0028', 'name' => 'Brezno');
$city_data[] = array('accid' => 'LOXX0019', 'name' => 'Cadca');
$city_data[] = array('accid' => 'LOXX0012', 'name' => 'Handlova');
$city_data[] = array('accid' => 'LOXX0025', 'name' => 'Humenne');
$city_data[] = array('accid' => 'LOXX0002', 'name' => 'Ivánka Pri Dunaji');
$city_data[] = array('accid' => 'LOXX0003', 'name' => 'Košice');
$city_data[] = array('accid' => 'LOXX0022', 'name' => 'Levice');
$city_data[] = array('accid' => 'LOXX0024', 'name' => 'Lucenec');
$city_data[] = array('accid' => 'LOXX0010', 'name' => 'Martin');
$city_data[] = array('accid' => 'LOXX0021', 'name' => 'Nitra');
$city_data[] = array('accid' => 'LOXX0004', 'name' => 'Nové Zámky');
$city_data[] = array('accid' => 'LOXX0008', 'name' => 'Pieštany');
$city_data[] = array('accid' => 'LOXX0005', 'name' => 'Poprad');
$city_data[] = array('accid' => 'LOXX0011', 'name' => 'Prievidza');
$city_data[] = array('accid' => 'LOXX0015', 'name' => 'Rimavska Sobota');
$city_data[] = array('accid' => 'LOXX0014', 'name' => 'Roznava');
$city_data[] = array('accid' => 'LOXX0006', 'name' => 'Senec');
$city_data[] = array('accid' => 'LOXX0020', 'name' => 'Senica');
$city_data[] = array('accid' => 'LOXX0009', 'name' => 'Sliač');
$city_data[] = array('accid' => 'LOXX0018', 'name' => 'Snina');
$city_data[] = array('accid' => 'LOXX0016', 'name' => 'Stropkov');
$city_data[] = array('accid' => 'LOXX0023', 'name' => 'Topolcany');
$city_data[] = array('accid' => 'LOXX0027', 'name' => 'Trencin');
$city_data[] = array('accid' => 'LOXX0007', 'name' => 'Trnava');
$city_data[] = array('accid' => 'LOXX0026', 'name' => 'Zilina');

?>
