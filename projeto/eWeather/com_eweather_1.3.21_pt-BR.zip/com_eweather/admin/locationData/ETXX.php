<?php

// City package for Ethiopia 

$city_name = 'Ethiopia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'ETXX0001', 'name' => 'Addis Ababa');
$city_data[] = array('accid' => 'ETXX0003', 'name' => 'Gode');
$city_data[] = array('accid' => 'ETXX0004', 'name' => 'Gondar');
$city_data[] = array('accid' => 'ETXX0005', 'name' => 'Gore');
$city_data[] = array('accid' => 'ETXX0006', 'name' => 'Jiggiga');
$city_data[] = array('accid' => 'ETXX0002', 'name' => 'Jimma');
$city_data[] = array('accid' => 'ETXX0007', 'name' => 'Neghelli');

?>
