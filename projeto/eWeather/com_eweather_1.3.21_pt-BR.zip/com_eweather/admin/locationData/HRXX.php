<?php

// City package for Croatia 
// Last updated: 07/04/2009
// By:           Bob Lavey

$city_name = 'Croatia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'HRXX0017', 'name' => 'Baskc');
$city_data[] = array('accid' => 'HRXX0016', 'name' => 'Biograd');
$city_data[] = array('accid' => 'HRXX0019', 'name' => 'Cres');
$city_data[] = array('accid' => 'HRXX0001', 'name' => 'Dubrovnik');
$city_data[] = array('accid' => 'HRXX0012', 'name' => 'Gornji Humac');
$city_data[] = array('accid' => 'HRXX0002', 'name' => 'Karlovac');
$city_data[] = array('accid' => 'HRXX0020', 'name' => 'Korcula');
$city_data[] = array('accid' => 'HRXX0023', 'name' => 'Labin');
$city_data[] = array('accid' => 'HRXX0022', 'name' => 'Mali Losinj');
$city_data[] = array('accid' => 'HRXX0021', 'name' => 'Mali Ston');
$city_data[] = array('accid' => 'HRXX0015', 'name' => 'Marina');
$city_data[] = array('accid' => 'HRXX0003', 'name' => 'Osijek');
$city_data[] = array('accid' => 'HRXX0014', 'name' => 'Pag');
$city_data[] = array('accid' => 'HRXX0007', 'name' => 'Pula');
$city_data[] = array('accid' => 'HRXX0006', 'name' => 'Rijeka');
$city_data[] = array('accid' => 'HRXX0018', 'name' => 'Rovinj');
$city_data[] = array('accid' => 'HRXX0011', 'name' => 'Sibenik');
$city_data[] = array('accid' => 'HRXX0013', 'name' => 'Slavonski Brod');
$city_data[] = array('accid' => 'HRXX0004', 'name' => 'Split');
$city_data[] = array('accid' => 'HRXX0010', 'name' => 'Zadar');
$city_data[] = array('accid' => 'HRXX0005', 'name' => 'Zagreb');

?>
