<?php

// City package for Serbia
// Last updated: 08/04/2009
// By:           Bob Lavey

$city_name = 'Serbia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'SRXX0005', 'name' => 'Belgrade');
$city_data[] = array('accid' => 'SRXX0032', 'name' => 'Cacak');
$city_data[] = array('accid' => 'SRXX0019', 'name' => 'Crni Vrh');
$city_data[] = array('accid' => 'SRXX0026', 'name' => 'Cuprija');
$city_data[] = array('accid' => 'SRXX0029', 'name' => 'Dimitrovgrad');
$city_data[] = array('accid' => 'SRXX0013', 'name' => 'Kikinda');
$city_data[] = array('accid' => 'SRXX0004', 'name' => 'Knjazevac');
$city_data[] = array('accid' => 'SRXX0024', 'name' => 'Kopaonik');
$city_data[] = array('accid' => 'SRXX0023', 'name' => 'Kraljevo');
$city_data[] = array('accid' => 'SRXX0025', 'name' => 'Krusevac');
$city_data[] = array('accid' => 'SRXX0028', 'name' => 'Leskovac');
$city_data[] = array('accid' => 'SRXX0015', 'name' => 'Loznica');
$city_data[] = array('accid' => 'SRXX0020', 'name' => 'Negotin');
$city_data[] = array('accid' => 'SRXX0027', 'name' => 'Nis');
$city_data[] = array('accid' => 'SRXX0001', 'name' => 'Novi Pazar');
$city_data[] = array('accid' => 'SRXX0006', 'name' => 'Novi Sad');
$city_data[] = array('accid' => 'SRXX0011', 'name' => 'Novi Sad Rimski Sancevi');
$city_data[] = array('accid' => 'SRXX0031', 'name' => 'Palic');
$city_data[] = array('accid' => 'SRXX0003', 'name' => 'Pancevo');
$city_data[] = array('accid' => 'SRXX0002', 'name' => 'Ratari');
$city_data[] = array('accid' => 'SRXX0008', 'name' => 'Ruma');
$city_data[] = array('accid' => 'SRXX0022', 'name' => 'Sjenica');
$city_data[] = array('accid' => 'SRXX0009', 'name' => 'Smederevo');
$city_data[] = array('accid' => 'SRXX0016', 'name' => 'Sremska Mitrovica');
$city_data[] = array('accid' => 'SRXX0017', 'name' => 'Valjevo');
$city_data[] = array('accid' => 'SRXX0018', 'name' => 'Veliko Gradiste');
$city_data[] = array('accid' => 'SRXX0030', 'name' => 'Vranje');
$city_data[] = array('accid' => 'SRXX0014', 'name' => 'Vrsac');
$city_data[] = array('accid' => 'SRXX0021', 'name' => 'Zlatibor');
$city_data[] = array('accid' => 'SRXX0012', 'name' => 'Zrenjanin');

?>
