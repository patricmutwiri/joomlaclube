<?php

// City package for Eritrea 

$city_name = 'Eritrea';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'ERXX0001', 'name' => 'Asmara');
$city_data[] = array('accid' => 'ERXX0002', 'name' => 'Keren');

?>
