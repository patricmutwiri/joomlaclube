<?php

// City package for Grenada

$city_name = 'Grenada';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'GJXX0002', 'name' => 'Point Salines Airport');
$city_data[] = array('accid' => 'GJXX0001', 'name' => 'St. George`s');

?>