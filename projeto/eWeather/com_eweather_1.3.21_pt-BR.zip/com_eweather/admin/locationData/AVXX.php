<?php

// City package for Anguilla 

$city_name = 'Anguilla';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'AVXX0001', 'name' => 'Crocus Hill');

?>
