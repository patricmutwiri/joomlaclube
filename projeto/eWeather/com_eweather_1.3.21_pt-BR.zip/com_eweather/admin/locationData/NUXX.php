<?php

// City package for Nicaragua 

$city_name = 'Nicaragua';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'NUXX0001', 'name' => 'Bluefields');
$city_data[] = array('accid' => 'NUXX0002', 'name' => 'Chinandega');
$city_data[] = array('accid' => 'NUXX0003', 'name' => 'Granada');
$city_data[] = array('accid' => 'NUXX0007', 'name' => 'Jinotega');
$city_data[] = array('accid' => 'NUXX0004', 'name' => 'Managua');
$city_data[] = array('accid' => 'NUXX0008', 'name' => 'Puerto Cabezas');
$city_data[] = array('accid' => 'NUXX0005', 'name' => 'Rivas');
$city_data[] = array('accid' => 'NUXX0006', 'name' => 'Tipitapa');

?>
