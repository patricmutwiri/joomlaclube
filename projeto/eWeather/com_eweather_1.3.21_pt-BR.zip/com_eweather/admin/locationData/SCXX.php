<?php

// City package for St. Kitts and Nevis
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'St. Kitts and Nevis';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'SCXX0001', 'name' => 'Basseterre');

?>
