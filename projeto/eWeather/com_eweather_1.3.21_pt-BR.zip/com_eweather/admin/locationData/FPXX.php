<?php

// City package for French Polynesia 

$city_name = 'French Polynesia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'FPXX0001', 'name' => 'Tahiti/Papeete');
$city_data[] = array('accid' => 'FPXX0002', 'name' => 'Atuona');
$city_data[] = array('accid' => 'FPXX0003', 'name' => 'Hao');
$city_data[] = array('accid' => 'FPXX0004', 'name' => 'Hereheretue');
$city_data[] = array('accid' => 'FPXX0005', 'name' => 'Rapa');

?>
