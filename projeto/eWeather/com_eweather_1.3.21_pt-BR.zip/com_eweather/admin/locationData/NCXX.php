<?php

// City package for New Caledonia
//
// Last updated: 07/18/2009
// By:           Bob Lavey

$city_name = 'New Caledonia';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'NCXX0002', 'name' => 'Ile Loop Chesterfield');
$city_data[] = array('accid' => 'NCXX0001', 'name' => 'Ile Surprise');
$city_data[] = array('accid' => 'NCXX0003', 'name' => 'Koumac Nlle-Caledonie');
$city_data[] = array('accid' => 'NCXX0005', 'name' => 'La Tontouta Nlle-Caledonie');
$city_data[] = array('accid' => 'NCXX0006', 'name' => 'Noumea Nlle-Caledonie');
$city_data[] = array('accid' => 'NCXX0004', 'name' => 'Ouloup Ile Ouvea');

?>
