<?php

// City package for Martinique 

$city_name = 'Martinique';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'MBXX0001', 'name' => 'Fort-de-France');
$city_data[] = array('accid' => 'MBXX0002', 'name' => 'Le Marin');
$city_data[] = array('accid' => 'MBXX0003', 'name' => 'Saint-Joseph');
$city_data[] = array('accid' => 'MBXX0004', 'name' => 'Saint-Pierre');

?>
