<?php

// City package for Mauritania 

$city_name = 'Mauritania';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'MRXX0005', 'name' => 'Atar');
$city_data[] = array('accid' => 'MRXX0001', 'name' => 'Beila');
$city_data[] = array('accid' => 'MRXX0002', 'name' => 'Cansado');
$city_data[] = array('accid' => 'MRXX0003', 'name' => 'Nouadhibou');
$city_data[] = array('accid' => 'MRXX0004', 'name' => 'Nouakchott');

?>
