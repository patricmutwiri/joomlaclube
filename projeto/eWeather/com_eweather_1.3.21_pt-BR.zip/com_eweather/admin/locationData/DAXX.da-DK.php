<?php

// City package for Danmark

$city_name = 'Danmark';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'DAXX0001', 'name' => 'Åbenrå');
$city_data[] = array('accid' => 'DAXX0002', 'name' => 'Ålborg');
$city_data[] = array('accid' => 'DAXX0003', 'name' => 'Århus');
$city_data[] = array('accid' => 'DAXX0004', 'name' => 'Augustenborg');
$city_data[] = array('accid' => 'DAXX0005', 'name' => 'Billund');
$city_data[] = array('accid' => 'DAXX0006', 'name' => 'Birkerød');
$city_data[] = array('accid' => 'DAXX0007', 'name' => 'Bramming');
$city_data[] = array('accid' => 'DAXX0008', 'name' => 'Brande');
$city_data[] = array('accid' => 'DAXX0009', 'name' => 'København');
$city_data[] = array('accid' => 'DAXX0010', 'name' => 'Esbjerg');
$city_data[] = array('accid' => 'DAXX0011', 'name' => 'Filskov');
$city_data[] = array('accid' => 'DAXX0012', 'name' => 'Frederikshavn');
$city_data[] = array('accid' => 'DAXX0013', 'name' => 'Frøstrup');
$city_data[] = array('accid' => 'DAXX0014', 'name' => 'Grimstrup');
$city_data[] = array('accid' => 'DAXX0015', 'name' => 'Hasle');
$city_data[] = array('accid' => 'DAXX0016', 'name' => 'Helsingør');
$city_data[] = array('accid' => 'DAXX0017', 'name' => 'Herning');
$city_data[] = array('accid' => 'DAXX0018', 'name' => 'Hillerød');
$city_data[] = array('accid' => 'DAXX0019', 'name' => 'Holstebro');
$city_data[] = array('accid' => 'DAXX0020', 'name' => 'Hørsholm');
$city_data[] = array('accid' => 'DAXX0021', 'name' => 'Karup');
$city_data[] = array('accid' => 'DAXX0022', 'name' => 'Køge');
$city_data[] = array('accid' => 'DAXX0023', 'name' => 'Norup');
$city_data[] = array('accid' => 'DAXX0024', 'name' => 'Odense');
$city_data[] = array('accid' => 'DAXX0025', 'name' => 'Østerild');
$city_data[] = array('accid' => 'DAXX0026', 'name' => 'Randers');
$city_data[] = array('accid' => 'DAXX0027', 'name' => 'Ribe');
$city_data[] = array('accid' => 'DAXX0028', 'name' => 'Rønne');
$city_data[] = array('accid' => 'DAXX0029', 'name' => 'Roskilde');
$city_data[] = array('accid' => 'DAXX0030', 'name' => 'Sandvig');
$city_data[] = array('accid' => 'DAXX0031', 'name' => 'Sjørring');
$city_data[] = array('accid' => 'DAXX0032', 'name' => 'Skrydstrup');
$city_data[] = array('accid' => 'DAXX0033', 'name' => 'Sønderborg');
$city_data[] = array('accid' => 'DAXX0034', 'name' => 'Spang');
$city_data[] = array('accid' => 'DAXX0035', 'name' => 'Tåstrup');
$city_data[] = array('accid' => 'DAXX0036', 'name' => 'Thisted');
$city_data[] = array('accid' => 'DAXX0037', 'name' => 'Torning');
$city_data[] = array('accid' => 'DAXX0038', 'name' => 'Varde');
$city_data[] = array('accid' => 'DAXX0039', 'name' => 'Vesløs');
$city_data[] = array('accid' => 'DAXX0040', 'name' => 'Viborg');
$city_data[] = array('accid' => 'DAXX0041', 'name' => 'Thorshavn');
$city_data[] = array('accid' => 'DAXX0042', 'name' => 'Hammer Odde');

?> 
