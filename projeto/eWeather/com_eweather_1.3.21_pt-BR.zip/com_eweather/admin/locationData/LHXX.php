<?php

// City package for Lithuania 
// Last updated: 07/14/2009
// By:           Bob Lavey

$city_name = 'Lithuania';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'LHXX0001', 'name' => 'Alytus');
$city_data[] = array('accid' => 'LHXX0002', 'name' => 'Kaunas');
$city_data[] = array('accid' => 'LHXX0008', 'name' => 'Klaipeda');
$city_data[] = array('accid' => 'LHXX0003', 'name' => 'Lentvaris');
$city_data[] = array('accid' => 'LHXX0004', 'name' => 'Nemencine');
$city_data[] = array('accid' => 'LHXX0006', 'name' => 'Palanga');
$city_data[] = array('accid' => 'LHXX0007', 'name' => 'Panevezys');
$city_data[] = array('accid' => 'LHXX0009', 'name' => 'Siauliai');
$city_data[] = array('accid' => 'LHXX0005', 'name' => 'Vilnius');

?>
