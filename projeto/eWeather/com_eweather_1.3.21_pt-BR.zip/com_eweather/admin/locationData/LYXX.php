<?php

// City package for Libya 

$city_name = 'Libya';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'LYXX0011', 'name' => 'Benghazi/Benina');
$city_data[] = array('accid' => 'LYXX0002', 'name' => 'Dirj');
$city_data[] = array('accid' => 'LYXX0003', 'name' => 'Ghadamis');
$city_data[] = array('accid' => 'LYXX0004', 'name' => 'Ghat');
$city_data[] = array('accid' => 'LYXX0012', 'name' => 'Hon');
$city_data[] = array('accid' => 'LYXX0013', 'name' => 'Kufra');
$city_data[] = array('accid' => 'LYXX0005', 'name' => 'Misratah');
$city_data[] = array('accid' => 'LYXX0006', 'name' => 'Murzuq');
$city_data[] = array('accid' => 'LYXX0008', 'name' => 'Taraghin');
$city_data[] = array('accid' => 'LYXX0009', 'name' => 'Tripoli');

?>
