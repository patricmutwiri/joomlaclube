<?php

// City package for Dominican Republic 
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Dominican Republic';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'DRXX0021', 'name' => 'Azua');
$city_data[] = array('accid' => 'DRXX0025', 'name' => 'Bani');
$city_data[] = array('accid' => 'DRXX0001', 'name' => 'Barahona');
$city_data[] = array('accid' => 'DRXX0023', 'name' => 'Bavaro');
$city_data[] = array('accid' => 'DRXX0002', 'name' => 'Bonao');
$city_data[] = array('accid' => 'DRXX0013', 'name' => 'Cabarete');
$city_data[] = array('accid' => 'DRXX0017', 'name' => 'Cotui');
$city_data[] = array('accid' => 'DRXX0020', 'name' => 'El Seibo');
$city_data[] = array('accid' => 'DRXX0024', 'name' => 'Higuey');
$city_data[] = array('accid' => 'DRXX0027', 'name' => 'Isla Saona');
$city_data[] = array('accid' => 'DRXX0003', 'name' => 'La Romana');
$city_data[] = array('accid' => 'DRXX0004', 'name' => 'La Vega');
$city_data[] = array('accid' => 'DRXX0010', 'name' => 'Luperon');
$city_data[] = array('accid' => 'DRXX0028', 'name' => 'Mao');
$city_data[] = array('accid' => 'DRXX0012', 'name' => 'Monte Cristi');
$city_data[] = array('accid' => 'DRXX0018', 'name' => 'Monte Plata');
$city_data[] = array('accid' => 'DRXX0014', 'name' => 'Nagua');
$city_data[] = array('accid' => 'DRXX0005', 'name' => 'Puerto Plata');
$city_data[] = array('accid' => 'DRXX0022', 'name' => 'Punta Cana');
$city_data[] = array('accid' => 'DRXX0015', 'name' => 'Rio San Juan');
$city_data[] = array('accid' => 'DRXX0006', 'name' => 'Samana');
$city_data[] = array('accid' => 'DRXX0026', 'name' => 'San Cristobal');
$city_data[] = array('accid' => 'DRXX0016', 'name' => 'San Francisco De Macoris');
$city_data[] = array('accid' => 'DRXX0007', 'name' => 'San Pedro de Macoris');
$city_data[] = array('accid' => 'DRXX0008', 'name' => 'Santiago');
$city_data[] = array('accid' => 'DRXX0009', 'name' => 'Santo Domingo');
$city_data[] = array('accid' => 'DRXX0019', 'name' => 'Savana De La Mar');
$city_data[] = array('accid' => 'DRXX0011', 'name' => 'Sosua');

?>
