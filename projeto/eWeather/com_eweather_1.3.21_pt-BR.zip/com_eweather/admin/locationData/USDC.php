<?php

// City package for USA: District of Columbia 

$city_name = 'USA: District of Columbia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'USDC0001', 'name' => 'Washington');

?>
