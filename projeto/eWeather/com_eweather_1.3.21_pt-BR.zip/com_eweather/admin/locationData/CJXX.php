<?php

// City package for Cayman Islands
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Cayman Islands';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'CJXX0001', 'name' => 'George Town');

?>
