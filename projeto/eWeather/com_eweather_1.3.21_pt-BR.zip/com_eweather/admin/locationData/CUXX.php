<?php

// City package for Cuba 
// Last updated: 07/04/2009
// By:           Bob Lavey

$city_name = 'Cuba';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'CUXX0021', 'name' => 'Baracoa');
$city_data[] = array('accid' => 'CUXX0001', 'name' => 'Bayamo');
$city_data[] = array('accid' => 'CUXX0002', 'name' => 'Camaguey');
$city_data[] = array('accid' => 'CUXX0017', 'name' => 'Cienfuegus');
$city_data[] = array('accid' => 'CUXX0016', 'name' => 'Guantanamo Bay NAS');
$city_data[] = array('accid' => 'CUXX0003', 'name' => 'Havana');
$city_data[] = array('accid' => 'CUXX0011', 'name' => 'Holguin');
$city_data[] = array('accid' => 'CUXX0004', 'name' => 'Las Tunas');
$city_data[] = array('accid' => 'CUXX0005', 'name' => 'Manzanillo');
$city_data[] = array('accid' => 'CUXX0006', 'name' => 'Matanzas');
$city_data[] = array('accid' => 'CUXX0012', 'name' => 'Moa');
$city_data[] = array('accid' => 'CUXX0007', 'name' => 'Pinar del Rio');
$city_data[] = array('accid' => 'CUXX0014', 'name' => 'Playa Giron');
$city_data[] = array('accid' => 'CUXX0008', 'name' => 'Sancti Spiritus');
$city_data[] = array('accid' => 'CUXX0009', 'name' => 'Santa Clara');
$city_data[] = array('accid' => 'CUXX0010', 'name' => 'Santiago de Cuba');
$city_data[] = array('accid' => 'CUXX0013', 'name' => 'Trinidad');
$city_data[] = array('accid' => 'CUXX0020', 'name' => 'Varadero');

?>
