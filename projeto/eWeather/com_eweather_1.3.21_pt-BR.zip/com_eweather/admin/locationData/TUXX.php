<?php

// City package for Turkey 
//
// Last updated: 06/23/2009
// By:           Bob Lavey

$city_name = 'Turkey';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'TUXX0061', 'name' => 'Adana');
$city_data[] = array('accid' => 'TUXX0001', 'name' => 'Adana/Incirlik');
$city_data[] = array('accid' => 'TUXX0046', 'name' => 'Afyon');
$city_data[] = array('accid' => 'TUXX0044', 'name' => 'Akhisar');
$city_data[] = array('accid' => 'TUXX0080', 'name' => 'Alanya');
$city_data[] = array('accid' => 'TUXX0066', 'name' => 'Anamur');
$city_data[] = array('accid' => 'TUXX0002', 'name' => 'Ankara');
$city_data[] = array('accid' => 'TUXX0003', 'name' => 'Ankara/Etimesgut');
$city_data[] = array('accid' => 'TUXX0004', 'name' => 'Antalya');
$city_data[] = array('accid' => 'TUXX0073', 'name' => 'Armutova');
$city_data[] = array('accid' => 'TUXX0005', 'name' => 'Askale');
$city_data[] = array('accid' => 'TUXX0051', 'name' => 'Aydin');
$city_data[] = array('accid' => 'TUXX0071', 'name' => 'Ayvacik');
$city_data[] = array('accid' => 'TUXX0006', 'name' => 'Bafra');
$city_data[] = array('accid' => 'TUXX0041', 'name' => 'Balikesir');
$city_data[] = array('accid' => 'TUXX0038', 'name' => 'Bandirma');
$city_data[] = array('accid' => 'TUXX0074', 'name' => 'Bergama');
$city_data[] = array('accid' => 'TUXX0007', 'name' => 'Bismil');
$city_data[] = array('accid' => 'TUXX0056', 'name' => 'Bodrum');
$city_data[] = array('accid' => 'TUXX0032', 'name' => 'Bolu');
$city_data[] = array('accid' => 'TUXX0078', 'name' => 'Bucak');
$city_data[] = array('accid' => 'TUXX0072', 'name' => 'Burhaniye');
$city_data[] = array('accid' => 'TUXX0039', 'name' => 'Bursa');
$city_data[] = array('accid' => 'TUXX0037', 'name' => 'Canakkale');
$city_data[] = array('accid' => 'TUXX0067', 'name' => 'Cerkezmusellim');
$city_data[] = array('accid' => 'TUXX0008', 'name' => 'Ceyhan');
$city_data[] = array('accid' => 'TUXX0076', 'name' => 'Civril');
$city_data[] = array('accid' => 'TUXX0033', 'name' => 'Corum');
$city_data[] = array('accid' => 'TUXX0009', 'name' => 'Cubuk');
$city_data[] = array('accid' => 'TUXX0060', 'name' => 'Dalaman');
$city_data[] = array('accid' => 'TUXX0010', 'name' => 'Diyarbakir');
$city_data[] = array('accid' => 'TUXX0030', 'name' => 'Edirne');
$city_data[] = array('accid' => 'TUXX0049', 'name' => 'Elazig');
$city_data[] = array('accid' => 'TUXX0011', 'name' => 'Elmadag');
$city_data[] = array('accid' => 'TUXX0012', 'name' => 'Ergani');
$city_data[] = array('accid' => 'TUXX0035', 'name' => 'Erzincan');
$city_data[] = array('accid' => 'TUXX0013', 'name' => 'Erzurum');
$city_data[] = array('accid' => 'TUXX0040', 'name' => 'Eskisehir');
$city_data[] = array('accid' => 'TUXX0070', 'name' => 'Ezine');
$city_data[] = array('accid' => 'TUXX0081', 'name' => 'Fethiye');
$city_data[] = array('accid' => 'TUXX0077', 'name' => 'Finike');
$city_data[] = array('accid' => 'TUXX0055', 'name' => 'Gaziantep');
$city_data[] = array('accid' => 'TUXX0079', 'name' => 'Inegol');
$city_data[] = array('accid' => 'TUXX0059', 'name' => 'Iskenderun');
$city_data[] = array('accid' => 'TUXX0052', 'name' => 'Isparta');
$city_data[] = array('accid' => 'TUXX0014', 'name' => 'Istanbul');
$city_data[] = array('accid' => 'TUXX0015', 'name' => 'Izmir');
$city_data[] = array('accid' => 'TUXX0016', 'name' => 'Izmir/Cumaovasi');
$city_data[] = array('accid' => 'TUXX0017', 'name' => 'Izmit');
$city_data[] = array('accid' => 'TUXX0036', 'name' => 'Kars');
$city_data[] = array('accid' => 'TUXX0018', 'name' => 'Kartal');
$city_data[] = array('accid' => 'TUXX0047', 'name' => 'Kayseri/Erkilet');
$city_data[] = array('accid' => 'TUXX0019', 'name' => 'Kirikkale');
$city_data[] = array('accid' => 'TUXX0042', 'name' => 'Kirsehir');
$city_data[] = array('accid' => 'TUXX0053', 'name' => 'Konya');
$city_data[] = array('accid' => 'TUXX0054', 'name' => 'Konya/Eregli');
$city_data[] = array('accid' => 'TUXX0068', 'name' => 'Kusadasi');
$city_data[] = array('accid' => 'TUXX0069', 'name' => 'Lapseki');
$city_data[] = array('accid' => 'TUXX0048', 'name' => 'Malatya/Erhac');
$city_data[] = array('accid' => 'TUXX0020', 'name' => 'Manavgat');
$city_data[] = array('accid' => 'TUXX0064', 'name' => 'Merzifon');
$city_data[] = array('accid' => 'TUXX0075', 'name' => 'Milas');
$city_data[] = array('accid' => 'TUXX0057', 'name' => 'Mugla');
$city_data[] = array('accid' => 'TUXX0062', 'name' => 'Mus');
$city_data[] = array('accid' => 'TUXX0065', 'name' => 'Nevsehir');
$city_data[] = array('accid' => 'TUXX0063', 'name' => 'Pamukkale');
$city_data[] = array('accid' => 'TUXX0021', 'name' => 'Pasinler');
$city_data[] = array('accid' => 'TUXX0022', 'name' => 'Sakarya');
$city_data[] = array('accid' => 'TUXX0023', 'name' => 'Samsun');
$city_data[] = array('accid' => 'TUXX0024', 'name' => 'Sariyer');
$city_data[] = array('accid' => 'TUXX0050', 'name' => 'Siirt');
$city_data[] = array('accid' => 'TUXX0058', 'name' => 'Silifke');
$city_data[] = array('accid' => 'TUXX0034', 'name' => 'Sivas');
$city_data[] = array('accid' => 'TUXX0025', 'name' => 'Tarsus');
$city_data[] = array('accid' => 'TUXX0031', 'name' => 'Tekirdag');
$city_data[] = array('accid' => 'TUXX0026', 'name' => 'Torbali');
$city_data[] = array('accid' => 'TUXX0029', 'name' => 'Trabzon');
$city_data[] = array('accid' => 'TUXX0082', 'name' => 'Tutuzlupinar');
$city_data[] = array('accid' => 'TUXX0027', 'name' => 'Urla');
$city_data[] = array('accid' => 'TUXX0045', 'name' => 'Usak');
$city_data[] = array('accid' => 'TUXX0043', 'name' => 'Van');
$city_data[] = array('accid' => 'TUXX0028', 'name' => 'Zonguldak');

?>
