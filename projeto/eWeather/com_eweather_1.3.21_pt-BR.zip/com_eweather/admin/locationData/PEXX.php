<?php

// City package for Peru 
//
// Last updated: 06/24/2009
// By:           Bob Lavey

$city_name = 'Peru';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'PEXX0025', 'name' => 'Andahuaylas');
$city_data[] = array('accid' => 'PEXX0026', 'name' => 'Anta');
$city_data[] = array('accid' => 'PEXX0001', 'name' => 'Arequipa');
$city_data[] = array('accid' => 'PEXX0036', 'name' => 'Atalaya');
$city_data[] = array('accid' => 'PEXX0037', 'name' => 'Barranca');
$city_data[] = array('accid' => 'PEXX0002', 'name' => 'Cajamarca');
$city_data[] = array('accid' => 'PEXX0003', 'name' => 'Callao');
$city_data[] = array('accid' => 'PEXX0004', 'name' => 'Camana');
$city_data[] = array('accid' => 'PEXX0027', 'name' => 'Chachapoyas');
$city_data[] = array('accid' => 'PEXX0038', 'name' => 'Chancay');
$city_data[] = array('accid' => 'PEXX0005', 'name' => 'Chiclayo');
$city_data[] = array('accid' => 'PEXX0006', 'name' => 'Chimbote');
$city_data[] = array('accid' => 'PEXX0007', 'name' => 'Chincha Alta');
$city_data[] = array('accid' => 'PEXX0008', 'name' => 'Cusco');
$city_data[] = array('accid' => 'PEXX0039', 'name' => 'Huacho');
$city_data[] = array('accid' => 'PEXX0046', 'name' => 'Huancavelica');
$city_data[] = array('accid' => 'PEXX0044', 'name' => 'Huancayo');
$city_data[] = array('accid' => 'PEXX0035', 'name' => 'Huanuco');
$city_data[] = array('accid' => 'PEXX0040', 'name' => 'Huaral');
$city_data[] = array('accid' => 'PEXX0009', 'name' => 'Ica');
$city_data[] = array('accid' => 'PEXX0048', 'name' => 'Ilo');
$city_data[] = array('accid' => 'PEXX0010', 'name' => 'Iquitos');
$city_data[] = array('accid' => 'PEXX0043', 'name' => 'Jauja');
$city_data[] = array('accid' => 'PEXX0028', 'name' => 'Juanjui');
$city_data[] = array('accid' => 'PEXX0049', 'name' => 'Juliaca');
$city_data[] = array('accid' => 'PEXX0045', 'name' => 'La Oroya');
$city_data[] = array('accid' => 'PEXX0011', 'name' => 'Lima');
$city_data[] = array('accid' => 'PEXX0012', 'name' => 'Lobitos');
$city_data[] = array('accid' => 'PEXX0041', 'name' => 'Lurin');
$city_data[] = array('accid' => 'PEXX0013', 'name' => 'Matucana');
$city_data[] = array('accid' => 'PEXX0014', 'name' => 'Moquegua');
$city_data[] = array('accid' => 'PEXX0015', 'name' => 'Nazca');
$city_data[] = array('accid' => 'PEXX0016', 'name' => 'Pimentel');
$city_data[] = array('accid' => 'PEXX0017', 'name' => 'Pisco');
$city_data[] = array('accid' => 'PEXX0018', 'name' => 'Piura');
$city_data[] = array('accid' => 'PEXX0019', 'name' => 'Pucallpa');
$city_data[] = array('accid' => 'PEXX0042', 'name' => 'Puente Piedra');
$city_data[] = array('accid' => 'PEXX0029', 'name' => 'Puerto Maldonado');
$city_data[] = array('accid' => 'PEXX0020', 'name' => 'Puno');
$city_data[] = array('accid' => 'PEXX0030', 'name' => 'Rioja');
$city_data[] = array('accid' => 'PEXX0047', 'name' => 'San Juan');
$city_data[] = array('accid' => 'PEXX0021', 'name' => 'Tacna');
$city_data[] = array('accid' => 'PEXX0031', 'name' => 'Talara');
$city_data[] = array('accid' => 'PEXX0032', 'name' => 'Tarapoto');
$city_data[] = array('accid' => 'PEXX0033', 'name' => 'Tingo Maria');
$city_data[] = array('accid' => 'PEXX0022', 'name' => 'Trujillo');
$city_data[] = array('accid' => 'PEXX0023', 'name' => 'Tumbes');
$city_data[] = array('accid' => 'PEXX0024', 'name' => 'Vitarte');
$city_data[] = array('accid' => 'PEXX0034', 'name' => 'Yurimaguas');

?>
