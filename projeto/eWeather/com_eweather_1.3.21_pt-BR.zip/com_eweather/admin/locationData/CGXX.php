<?php

// City package for Democratic Republic of The Congo 
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'Democratic Republic of The Congo';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'CGXX0001', 'name' => 'Baya');
$city_data[] = array('accid' => 'CGXX0002', 'name' => 'Boma');
$city_data[] = array('accid' => 'CGXX0003', 'name' => 'Kahemba');
$city_data[] = array('accid' => 'CGXX0017', 'name' => 'Kananga');
$city_data[] = array('accid' => 'CGXX0005', 'name' => 'Kinshasa');
$city_data[] = array('accid' => 'CGXX0006', 'name' => 'Kipushi');
$city_data[] = array('accid' => 'CGXX0007', 'name' => 'Kisangani');
$city_data[] = array('accid' => 'CGXX0008', 'name' => 'Likasi');
$city_data[] = array('accid' => 'CGXX0009', 'name' => 'Lubumbashi');
$city_data[] = array('accid' => 'CGXX0010', 'name' => 'Matadi');
$city_data[] = array('accid' => 'CGXX0011', 'name' => 'Mbandaka');
$city_data[] = array('accid' => 'CGXX0014', 'name' => 'Uvira');
$city_data[] = array('accid' => 'CGXX0015', 'name' => 'Zongo');

?>
