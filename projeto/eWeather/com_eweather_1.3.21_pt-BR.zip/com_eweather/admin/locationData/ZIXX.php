<?php

// City package for Zimbabwe 

$city_name = 'Zimbabwe';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'ZIXX0011', 'name' => 'Buffalo Range');
$city_data[] = array('accid' => 'ZIXX0001', 'name' => 'Bulawayo');
$city_data[] = array('accid' => 'ZIXX0002', 'name' => 'Chegutu');
$city_data[] = array('accid' => 'ZIXX0003', 'name' => 'Chitungwiza');
$city_data[] = array('accid' => 'ZIXX004', 'name' => 'Harare');
$city_data[] = array('accid' => 'ZIXX0008', 'name' => 'Hwange National Park');
$city_data[] = array('accid' => 'ZIXX0005', 'name' => 'Karoi');
$city_data[] = array('accid' => 'ZIXX0010', 'name' => 'Masvingo');
$city_data[] = array('accid' => 'ZIXX0006', 'name' => 'Mount Darwin');
$city_data[] = array('accid' => 'ZIXX0009', 'name' => 'Rusape');
$city_data[] = array('accid' => 'ZIXX0007', 'name' => 'Victoria Falls');

?>
