<?php

// City package for Uganda 

$city_name = 'Uganda';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'UGXX0001', 'name' => 'Entebbe');
$city_data[] = array('accid' => 'UGXX0002', 'name' => 'Kampala');

?>
