<?php

// City package for Mozambique 

$city_name = 'Mozambique';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'MZXX0001', 'name' => 'Beira');
$city_data[] = array('accid' => 'MZXX0002', 'name' => 'Lumbo');
$city_data[] = array('accid' => 'MZXX0003', 'name' => 'Maputo');
$city_data[] = array('accid' => 'MZXX0004', 'name' => 'Mocambique');
$city_data[] = array('accid' => 'MZXX0005', 'name' => 'Mogincual');
$city_data[] = array('accid' => 'MZXX0007', 'name' => 'Quelimane');
$city_data[] = array('accid' => 'MZXX0006', 'name' => 'Xai-Xai');

?>
