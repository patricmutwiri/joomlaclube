<?php

// City package for St. Lucia 
// Last updated: 07/08/2009
// By:           Bob Lavey

$city_name = 'St. Lucia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'STXX0001', 'name' => 'Castries');
$city_data[] = array('accid' => 'STXX0002', 'name' => 'Dennery');
$city_data[] = array('accid' => 'STXX0003', 'name' => 'Micoud');
$city_data[] = array('accid' => 'STXX0004', 'name' => 'Vieux Fort');

?>
