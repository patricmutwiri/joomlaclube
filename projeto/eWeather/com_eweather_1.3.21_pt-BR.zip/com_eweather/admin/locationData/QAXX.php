<?php

// City package for Qatar 

$city_name = 'Qatar';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'QAXX0001', 'name' => 'Al Wakrah');
$city_data[] = array('accid' => 'QAXX002', 'name' => 'Ar Rayyan');
$city_data[] = array('accid' => 'QAXX0003', 'name' => 'Doha');

?>
