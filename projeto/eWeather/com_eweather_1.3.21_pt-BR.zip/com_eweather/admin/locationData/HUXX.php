<?php

// City package for Hungary 
// Last updated: 07/18/2009
// By:           Bob Lavey

$city_name = 'Hungary';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'HUXX0027', 'name' => 'Abaujszanto');
$city_data[] = array('accid' => 'HUXX0037', 'name' => 'Balatonboglar');
$city_data[] = array('accid' => 'HUXX0001', 'name' => 'Berettyoujfalu');
$city_data[] = array('accid' => 'HUXX0002', 'name' => 'Budapest');
$city_data[] = array('accid' => 'HUXX0016', 'name' => 'Budapest/Lorinc');
$city_data[] = array('accid' => 'HUXX0003', 'name' => 'Cegled');
$city_data[] = array('accid' => 'HUXX0036', 'name' => 'Csorna');
$city_data[] = array('accid' => 'HUXX0004', 'name' => 'Debrecen');
$city_data[] = array('accid' => 'HUXX0005', 'name' => 'Dunaujvaros');
$city_data[] = array('accid' => 'HUXX0042', 'name' => 'Eger');
$city_data[] = array('accid' => 'HUXX0029', 'name' => 'Egyek');
$city_data[] = array('accid' => 'HUXX0006', 'name' => 'Erd');
$city_data[] = array('accid' => 'HUXX0007', 'name' => 'Gyor');
$city_data[] = array('accid' => 'HUXX0040', 'name' => 'Kecel');
$city_data[] = array('accid' => 'HUXX0008', 'name' => 'Kecskemet');
$city_data[] = array('accid' => 'HUXX0035', 'name' => 'Keszthely');
$city_data[] = array('accid' => 'HUXX0023', 'name' => 'Kunszentmarton');
$city_data[] = array('accid' => 'HUXX0025', 'name' => 'Mako');
$city_data[] = array('accid' => 'HUXX0041', 'name' => 'Mezocsat');
$city_data[] = array('accid' => 'HUXX0015', 'name' => 'Miskolc');
$city_data[] = array('accid' => 'HUXX0017', 'name' => 'Nagykanizsa');
$city_data[] = array('accid' => 'HUXX0031', 'name' => 'Nagyleta');
$city_data[] = array('accid' => 'HUXX0009', 'name' => 'Nyiregyhaza');
$city_data[] = array('accid' => 'HUXX0033', 'name' => 'Ofeherto');
$city_data[] = array('accid' => 'HUXX0026', 'name' => 'Oroshaza');
$city_data[] = array('accid' => 'HUXX0018', 'name' => 'Pecs/Pogany');
$city_data[] = array('accid' => 'HUXX0028', 'name' => 'Polgar');
$city_data[] = array('accid' => 'HUXX0021', 'name' => 'Poroszlo');
$city_data[] = array('accid' => 'HUXX0010', 'name' => 'Puspokladany');
$city_data[] = array('accid' => 'HUXX0024', 'name' => 'Sarbogard');
$city_data[] = array('accid' => 'HUXX0038', 'name' => 'Siofok');
$city_data[] = array('accid' => 'HUXX0020', 'name' => 'Szecseny');
$city_data[] = array('accid' => 'HUXX0019', 'name' => 'Szeged');
$city_data[] = array('accid' => 'HUXX0011', 'name' => 'Szekesfehervar');
$city_data[] = array('accid' => 'HUXX0034', 'name' => 'Szolnok');
$city_data[] = array('accid' => 'HUXX0039', 'name' => 'Tapolca');
$city_data[] = array('accid' => 'HUXX0012', 'name' => 'Tatabanya');
$city_data[] = array('accid' => 'HUXX0030', 'name' => 'Tiszafured');
$city_data[] = array('accid' => 'HUXX0022', 'name' => 'Tiszanana');
$city_data[] = array('accid' => 'HUXX0032', 'name' => 'Tiszavasvari');
$city_data[] = array('accid' => 'HUXX0043', 'name' => 'Tompa');
$city_data[] = array('accid' => 'HUXX0013', 'name' => 'Ujfeherto');
$city_data[] = array('accid' => 'HUXX0014', 'name' => 'Vac');

?>
