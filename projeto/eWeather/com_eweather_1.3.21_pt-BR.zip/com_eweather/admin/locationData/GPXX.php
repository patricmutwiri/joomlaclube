<?php

// City package for Guadeloupe 

$city_name = 'Guadeloupe';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'GPXX0006', 'name' => 'Basse Terre');
$city_data[] = array('accid' => 'GPXX0001', 'name' => 'Les Abymes');
$city_data[] = array('accid' => 'GPXX0002', 'name' => 'Petit-Bourg');
$city_data[] = array('accid' => 'GPXX0003', 'name' => 'Pointe-�-Pitre');
$city_data[] = array('accid' => 'GPXX0004', 'name' => 'Port-Louis');
$city_data[] = array('accid' => 'GPXX0005', 'name' => 'Saint Martin Island');

?>
