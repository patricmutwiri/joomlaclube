<?php

// City package for Israel

$city_name = 'Israel';
$city_version = '1.0.0';
$city_data = array();


$city_data[] = array('accid' => 'ITXX0001', 'name' => 'Alcamo');
$city_data[] = array('accid' => 'ISXX0001', 'name' => 'Acre');
$city_data[] = array('accid' => 'ISXX0029', 'name' => 'Ariel');
$city_data[] = array('accid' => 'ISXX0002', 'name' => 'Bat Yam');
$city_data[] = array('accid' => 'ISXX0030', 'name' => 'Beersheba');
$city_data[] = array('accid' => 'ISXX0003', 'name' => 'Beit Lahm');
$city_data[] = array('accid' => 'ISXX0004', 'name' => 'Bene Beraq');
$city_data[] = array('accid' => 'ISXX0005', 'name' => 'Elat');
$city_data[] = array('accid' => 'ISXX0006', 'name' => 'Hadera');
$city_data[] = array('accid' => 'ISXX0007', 'name' => 'Haifa');
$city_data[] = array('accid' => 'ISXX0008', 'name' => 'Herzliyya');
$city_data[] = array('accid' => 'ISXX0009', 'name' => 'Holon');
$city_data[] = array('accid' => 'ISXX0010', 'name' => 'Jerusalem');
$city_data[] = array('accid' => 'ISXX0031', 'name' => 'Kiryat Shmone');
$city_data[] = array('accid' => 'ISXX0011', 'name' => 'Lod/Ben Gurion Airport');
$city_data[] = array('accid' => 'ISXX0012', 'name' => 'Nahariyya');
$city_data[] = array('accid' => 'ISXX0013', 'name' => 'Nazareth');
$city_data[] = array('accid' => 'ISXX0014', 'name' => 'Nesher');
$city_data[] = array('accid' => 'ISXX0015', 'name' => 'Netanya');
$city_data[] = array('accid' => 'ISXX0016', 'name' => 'Ovda');
$city_data[] = array('accid' => 'ISXX0017', 'name' => 'Petah Tiqwa');
$city_data[] = array('accid' => 'ISXX0018', 'name' => 'Qiryat Ata');
$city_data[] = array('accid' => 'ISXX0019', 'name' => 'Qiryat Bialik');
$city_data[] = array('accid' => 'ISXX0020', 'name' => 'Qiryat Motzkin');
$city_data[] = array('accid' => 'ISXX0021', 'name' => 'Qiryat Yam');
$city_data[] = array('accid' => 'ISXX0022', 'name' => 'Ramat Gan');
$city_data[] = array('accid' => 'ISXX0023', 'name' => 'Ramla');
$city_data[] = array('accid' => 'ISXX0024', 'name' => 'Rehovot');
$city_data[] = array('accid' => 'ISXX0025', 'name' => 'Rishon LeZiyyon');
$city_data[] = array('accid' => 'ISXX0026', 'name' => 'Tel Aviv-Yafo');
$city_data[] = array('accid' => 'ISXX0032', 'name' => 'Tiberius');
$city_data[] = array('accid' => 'ISXX0027', 'name' => 'Yotvata');
$city_data[] = array('accid' => 'ISXX0028', 'name' => 'Zova');

?>