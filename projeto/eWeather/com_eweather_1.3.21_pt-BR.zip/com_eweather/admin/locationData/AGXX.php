<?php

// City package for Algeria 

$city_name = 'Algeria';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'AGXX0034', 'name' => 'Adrar');
$city_data[] = array('accid' => 'AGXX0001', 'name' => 'Algiers');
$city_data[] = array('accid' => 'AGXX0002', 'name' => 'Amsel');
$city_data[] = array('accid' => 'AGXX0012', 'name' => 'Annaba');
$city_data[] = array('accid' => 'AGXX0017', 'name' => 'Batna');
$city_data[] = array('accid' => 'AGXX0028', 'name' => 'Bechar');
$city_data[] = array('accid' => 'AGXX0003', 'name' => 'Bejaia');
$city_data[] = array('accid' => 'AGXX0038', 'name' => 'Beni Abbes');
$city_data[] = array('accid' => 'AGXX0022', 'name' => 'Biskra');
$city_data[] = array('accid' => 'AGXX0015', 'name' => 'Bordj Bou Arreridj');
$city_data[] = array('accid' => 'AGXX0021', 'name' => 'Bou-Saada');
$city_data[] = array('accid' => 'AGXX0014', 'name' => 'Chlef');
$city_data[] = array('accid' => 'AGXX0013', 'name' => 'Constantine');
$city_data[] = array('accid' => 'AGXX0037', 'name' => 'Djanet');
$city_data[] = array('accid' => 'AGXX0031', 'name' => 'El Golea');
$city_data[] = array('accid' => 'AGXX0026', 'name' => 'El Oued');
$city_data[] = array('accid' => 'AGXX0027', 'name' => 'Ghardaia');
$city_data[] = array('accid' => 'AGXX0030', 'name' => 'Hassi-Messaoud');
$city_data[] = array('accid' => 'AGXX0036', 'name' => 'Illizi');
$city_data[] = array('accid' => 'AGXX0033', 'name' => 'In Amenas');
$city_data[] = array('accid' => 'AGXX0035', 'name' => 'In Salah');
$city_data[] = array('accid' => 'AGXX0040', 'name' => 'Jijel Achouat');
$city_data[] = array('accid' => 'AGXX0019', 'name' => 'Mascara Metmore');
$city_data[] = array('accid' => 'AGXX0024', 'name' => 'Mecheria');
$city_data[] = array('accid' => 'AGXX0005', 'name' => 'Mostanagem');
$city_data[] = array('accid' => 'AGXX0006', 'name' => 'Oran');
$city_data[] = array('accid' => 'AGXX0029', 'name' => 'Ouargla');
$city_data[] = array('accid' => 'AGXX0016', 'name' => 'Selif');
$city_data[] = array('accid' => 'AGXX0011', 'name' => 'Skikda');
$city_data[] = array('accid' => 'AGXX0007', 'name' => 'Tahifet');
$city_data[] = array('accid' => 'AGXX0008', 'name' => 'Tamanrasset');
$city_data[] = array('accid' => 'AGXX0018', 'name' => 'Tebessa');
$city_data[] = array('accid' => 'AGXX0009', 'name' => 'Tenes');
$city_data[] = array('accid' => 'AGXX0039', 'name' => 'Tessalit');
$city_data[] = array('accid' => 'AGXX0020', 'name' => 'Tiaret');
$city_data[] = array('accid' => 'AGXX0032', 'name' => 'Timimoun');
$city_data[] = array('accid' => 'AGXX0010', 'name' => 'Tindouf');
$city_data[] = array('accid' => 'AGXX0023', 'name' => 'Tlemcen Zenata');
$city_data[] = array('accid' => 'AGXX0025', 'name' => 'Touggourt');

?>
