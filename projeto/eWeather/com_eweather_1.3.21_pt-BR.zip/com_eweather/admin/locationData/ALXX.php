<?php

// City package for Albania 
//
// Last updated: 08/31/2009
// By:           Bob Lavey

$city_name = 'Albania';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'ALXX0001', 'name' => 'Shkoder');
$city_data[] = array('accid' => 'ALXX0002', 'name' => 'Tirane');

?>
