<?php

// City package for Tunisia 

$city_name = 'Tunisia';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'TSXX0001', 'name' => 'Bizerte');
$city_data[] = array('accid' => 'TSXX0002', 'name' => 'Chebba');
$city_data[] = array('accid' => 'TSXX0018', 'name' => 'Djerba Mellita');
$city_data[] = array('accid' => 'TSXX0003', 'name' => 'Gabes');
$city_data[] = array('accid' => 'TSXX0016', 'name' => 'Gafsa');
$city_data[] = array('accid' => 'TSXX0004', 'name' => 'Houmet Essouk');
$city_data[] = array('accid' => 'TSXX0013', 'name' => 'Kairouan');
$city_data[] = array('accid' => 'TSXX0012', 'name' => 'Kelibia');
$city_data[] = array('accid' => 'TSXX0005', 'name' => 'La Marsa');
$city_data[] = array('accid' => 'TSXX0006', 'name' => 'Mahres');
$city_data[] = array('accid' => 'TSXX0007', 'name' => 'Menzel Bourguiba');
$city_data[] = array('accid' => 'TSXX0015', 'name' => 'Monastir-Skanes');
$city_data[] = array('accid' => 'TSXX0019', 'name' => 'Remada');
$city_data[] = array('accid' => 'TSXX0008', 'name' => 'Sfax');
$city_data[] = array('accid' => 'TSXX0009', 'name' => 'Sousse');
$city_data[] = array('accid' => 'TSXX0011', 'name' => 'Tabarka');
$city_data[] = array('accid' => 'TSXX0014', 'name' => 'Thala');
$city_data[] = array('accid' => 'TSXX0017', 'name' => 'Tozeur');
$city_data[] = array('accid' => 'TSXX0010', 'name' => 'Tunis');

?>
