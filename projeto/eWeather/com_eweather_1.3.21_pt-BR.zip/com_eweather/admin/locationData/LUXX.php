<?php

// City package for Luxembourg

$city_name = 'Luxembourg';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'LUXX0001', 'name' => 'Dudelange');
$city_data[] = array('accid' => 'LUXX0002', 'name' => 'Esch-sur-Alzette');
$city_data[] = array('accid' => 'LUXX0003', 'name' => 'Luxembourg');
$city_data[] = array('accid' => 'LUXX0004', 'name' => 'Mersch');

?>