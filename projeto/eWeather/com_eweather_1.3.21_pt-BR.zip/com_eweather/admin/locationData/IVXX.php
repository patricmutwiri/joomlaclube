<?php

// City package for Ivory Coast 

$city_name = 'Ivory Coast';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'IVXX0001', 'name' => 'Abidjan');
$city_data[] = array('accid' => 'IVXX0002', 'name' => 'Dabou');
$city_data[] = array('accid' => 'IVXX0004', 'name' => 'Gagnoa');
$city_data[] = array('accid' => 'IVXX0003', 'name' => 'Grand-Bassam');

?>
