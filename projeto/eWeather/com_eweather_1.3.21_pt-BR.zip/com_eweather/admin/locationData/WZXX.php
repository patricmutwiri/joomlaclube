<?php

// City package for Swaziland 

$city_name = 'Swaziland';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'WZXX0001', 'name' => 'Mbabane');

?>
