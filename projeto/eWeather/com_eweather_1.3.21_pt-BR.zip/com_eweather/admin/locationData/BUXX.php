<?php

// City package for Bulgaria 
//
// Last updated: 06/24/2009
// By:           Bob Lavey

$city_name = 'Bulgaria';
$city_version = '1.0.2';
$city_data = array();

$city_data[] = array('accid' => 'BUXX0023', 'name' => 'Blagoevgrad');
$city_data[] = array('accid' => 'BUXX0014', 'name' => 'Botev Vrah Top/Sommet');
$city_data[] = array('accid' => 'BUXX0001', 'name' => 'Burgas');
$city_data[] = array('accid' => 'BUXX0021', 'name' => 'Gotse Delchev');
$city_data[] = array('accid' => 'BUXX0019', 'name' => 'Kavarna');
$city_data[] = array('accid' => 'BUXX0016', 'name' => 'Kurdjali');
$city_data[] = array('accid' => 'BUXX0010', 'name' => 'Lovetch');
$city_data[] = array('accid' => 'BUXX0013', 'name' => 'Mussala Top/Sommet');
$city_data[] = array('accid' => 'BUXX0022', 'name' => 'Pazardzhik');
$city_data[] = array('accid' => 'BUXX0002', 'name' => 'Pernik');
$city_data[] = array('accid' => 'BUXX0003', 'name' => 'Pleven');
$city_data[] = array('accid' => 'BUXX0004', 'name' => 'Plovdiv');
$city_data[] = array('accid' => 'BUXX0012', 'name' => 'Razgrad');
$city_data[] = array('accid' => 'BUXX0011', 'name' => 'Rousse');
$city_data[] = array('accid' => 'BUXX0015', 'name' => 'Sandanski');
$city_data[] = array('accid' => 'BUXX0018', 'name' => 'Shabla');
$city_data[] = array('accid' => 'BUXX0017', 'name' => 'Sliven');
$city_data[] = array('accid' => 'BUXX0005', 'name' => 'Sofia');
$city_data[] = array('accid' => 'BUXX0006', 'name' => 'Stara Zagora');
$city_data[] = array('accid' => 'BUXX0020', 'name' => 'Tolbukhin');
$city_data[] = array('accid' => 'BUXX0024', 'name' => 'Turnovo');
$city_data[] = array('accid' => 'BUXX0007', 'name' => 'Varna');
$city_data[] = array('accid' => 'BUXX0009', 'name' => 'Vidin');
$city_data[] = array('accid' => 'BUXX0008', 'name' => 'Vraca');

?>
