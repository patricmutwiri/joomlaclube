<?php

// City package for Vietnam
// Last updated: 10/06/2009
// By:           Bob Lavey

$city_name = 'Vietnam';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'VMXX0001', 'name' => 'An Nhon');
$city_data[] = array('accid' => 'VMXX0002', 'name' => 'Bac Giang');
$city_data[] = array('accid' => 'VMXX0024', 'name' => 'Bach Long Vi');
$city_data[] = array('accid' => 'VMXX0003', 'name' => 'Bien Hoa');
$city_data[] = array('accid' => 'VMXX0031', 'name' => 'Ca Mau');
$city_data[] = array('accid' => 'VMXX0004', 'name' => 'Can Tho');
$city_data[] = array('accid' => 'VMXX0020', 'name' => 'Cao Bang');
$city_data[] = array('accid' => 'VMXX0033', 'name' => 'Con Son');
$city_data[] = array('accid' => 'VMXX0028', 'name' => 'Da Nang');
$city_data[] = array('accid' => 'VMXX0027', 'name' => 'Dong Hoi');
$city_data[] = array('accid' => 'VMXX0005', 'name' => 'Haiphong');
$city_data[] = array('accid' => 'VMXX0006', 'name' => 'Hanoi');
$city_data[] = array('accid' => 'VMXX0007', 'name' => 'Ho Chi Minh City');
$city_data[] = array('accid' => 'VMXX0008', 'name' => 'Hoa Binh');
$city_data[] = array('accid' => 'VMXX0009', 'name' => 'Hue');
$city_data[] = array('accid' => 'VMXX0023', 'name' => 'Lang Son');
$city_data[] = array('accid' => 'VMXX0019', 'name' => 'Lao Cai');
$city_data[] = array('accid' => 'VMXX0010', 'name' => 'My Tho');
$city_data[] = array('accid' => 'VMXX0011', 'name' => 'Nam Dinh');
$city_data[] = array('accid' => 'VMXX0029', 'name' => 'Nha Trang');
$city_data[] = array('accid' => 'VMXX0012', 'name' => 'Phan Thiet');
$city_data[] = array('accid' => 'VMXX0022', 'name' => 'Phu Lien');
$city_data[] = array('accid' => 'VMXX0032', 'name' => 'Phu Quoc');
$city_data[] = array('accid' => 'VMXX0013', 'name' => 'Quy Nhon');
$city_data[] = array('accid' => 'VMXX0014', 'name' => 'Song Cau');
$city_data[] = array('accid' => 'VMXX0030', 'name' => 'Song Tu Tay South West Cay');
$city_data[] = array('accid' => 'VMXX0015', 'name' => 'Thai Nguyen');
$city_data[] = array('accid' => 'VMXX0025', 'name' => 'Thanh Hoa');
$city_data[] = array('accid' => 'VMXX0034', 'name' => 'Truong Sa');
$city_data[] = array('accid' => 'VMXX0016', 'name' => 'Tuy Hoa');
$city_data[] = array('accid' => 'VMXX0017', 'name' => 'Viet Tri');
$city_data[] = array('accid' => 'VMXX0026', 'name' => 'Vinh');
$city_data[] = array('accid' => 'VMXX0018', 'name' => 'Vung Tau');

?>
