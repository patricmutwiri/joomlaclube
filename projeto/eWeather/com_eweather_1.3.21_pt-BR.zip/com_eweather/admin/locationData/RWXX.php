<?php

// City package for Rwanda 

$city_name = 'Rwanda';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'RWXX0001', 'name' => 'Kigali');

?>
