<?php

// City package for Mali 

$city_name = 'Mali';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'MLXX0001', 'name' => 'Bamako');
$city_data[] = array('accid' => 'MLXX0003', 'name' => 'Gao');
$city_data[] = array('accid' => 'MLXX0004', 'name' => 'Kayes');
$city_data[] = array('accid' => 'MLXX0005', 'name' => 'Mopti');
$city_data[] = array('accid' => 'MLXX0006', 'name' => 'Segou');
$city_data[] = array('accid' => 'MLXX0002', 'name' => 'Timbuktu');

?>
