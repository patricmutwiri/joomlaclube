<?php

// City package for Botswana 

$city_name = 'Botswana';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'BCXX0004', 'name' => 'Francistown');
$city_data[] = array('accid' => 'BCXX0005', 'name' => 'Gaberone/Kharma');
$city_data[] = array('accid' => 'BCXX0001', 'name' => 'Gaborone');
$city_data[] = array('accid' => 'BCXX0006', 'name' => 'Ghanzi');
$city_data[] = array('accid' => 'BCXX0007', 'name' => 'Jwaneng');
$city_data[] = array('accid' => 'BCXX0008', 'name' => 'Kazane');
$city_data[] = array('accid' => 'BCXX0009', 'name' => 'Letlhakane');
$city_data[] = array('accid' => 'BCXX0010', 'name' => 'Mahalapye');
$city_data[] = array('accid' => 'BCXX0011', 'name' => 'Maun');
$city_data[] = array('accid' => 'BCXX0012', 'name' => 'Pandamanga');
$city_data[] = array('accid' => 'BCXX0013', 'name' => 'Selebi Phikwe');
$city_data[] = array('accid' => 'BCXX0016', 'name' => 'Shakawe');
$city_data[] = array('accid' => 'BCXX0017', 'name' => 'Suapan');
$city_data[] = array('accid' => 'BCXX0014', 'name' => 'Tsabong');
$city_data[] = array('accid' => 'BCXX0015', 'name' => 'Tshane');

?>
