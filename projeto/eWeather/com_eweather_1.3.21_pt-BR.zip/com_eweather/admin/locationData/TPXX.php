<?php

// City package for Sao Tome and Principe 

$city_name = 'Sao Tome and Principe';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'TPXX0001', 'name' => 'Sao Tome');

?>
