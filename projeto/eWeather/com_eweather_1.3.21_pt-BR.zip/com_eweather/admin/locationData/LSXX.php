<?php

// City package for Lichtenstein...
$city_name = 'Lichtenstein';
$city_version = '1.0.2';
$city_data = array();


$city_data[] = array('accid' => 'LSXX0001', 'name' => 'Schaan');
$city_data[] = array('accid' => 'LSXX0002', 'name' => 'Vaduz');
$city_data[] = array('accid' => 'LSXX0003', 'name' => 'Schrunz');

?>