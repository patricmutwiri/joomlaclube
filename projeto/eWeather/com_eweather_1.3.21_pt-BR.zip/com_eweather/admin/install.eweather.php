<?php
/**
 * This file contains the installation routines for the eWeather component.
 *
 * This file is part of eWeather.
 *
 *   eWeather is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   eWeather is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with eWeather.  If not, see <a href="http://www.gnu.org/licenses/">
 *   http://www.gnu.org/licenses/</a>.
 *
 * <b>Modifications:</b><br/>
 * aangepast door Mart Dirks<br/>
 * converted to Joomla! 1.5.x by Bob Lavey
 *
 * @version $Id: install.eweather.php 267 2009-07-30 15:24:19Z rjlavey $
 * @package eWeather
 * @subpackage Admin eWeather
 * @copyright Copyright (c) 2000 - 2006 MamboBaer.de (Harald Baer),
 *            2009 Bob Lavey<br/>
 * @license http://www.gnu.org/licenses/gpl.txt GNU/GPL
 *
 */

/* ensure this file is being called by Joomla! */
defined('_JEXEC') or die ('Direct Access to this location is not allowed.');

  /**
   * nothing to do...
   */
  function com_install(){

  }

?>
<table width="100%" border="0">
   <tr>
     <td width="10%" valign="top">
        <img src="../media/com_eweather/images/eWeather_logo.png" alt="" />
     </td>
     <td width="90%">
        <p>
           <strong>eWeather</strong> Component <em>for Joomla! 1.5.x CMS </em> <br />
           &copy; 2006 door Mambobaer en &copy; 2007 door Mart Dirks en &copy; 2009 by Bob Lavey <br/>
           All rights reserved.
           <br />
           <br />
           eWeather Component has been released under
           <a href="index2.php?option=com_admisc&amp;task=license">GNU/GPL</a>.<br/>
           <strong>Note:</strong>&nbsp;This package has only been tested under Joomla! 1.5.x
        </p>
     </td>
   </tr>
   <tr>
     <td valign="top">
        <strong>Installation</strong><br /><br />
     </td>
     <td>&nbsp;
     </td>
   </tr>
   <tr>
      <td valign="top">
         <strong>Information:</strong><br /><br />
      </td>
      <td>
         <p>
<strong>NO WARRANTY</strong><br />
  <p>
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <a href="http://www.gnu.org/licenses/">http://www.gnu.org/licenses/</a>.
        </p>
      </td>
   </tr>
   <tr>
      <td>&nbsp;
      </td>
      <td>
         <p>
            Thank you for using eWeather Component!
         </p>
         <p>
            <em>MamboBaer.de, www.martdirks.nl, and Bob Lavey</em>
         </p>
      </td>
   </tr>
</table>
