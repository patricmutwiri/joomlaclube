DROP TABLE IF EXISTS `#__eweather_cache`;
CREATE TABLE IF NOT EXISTS `#__eweather_cache` (
  `id` mediumint(9) NOT NULL auto_increment,
  `lastupdate` int(11) default NULL,
  `locid` varchar(15) NOT NULL default '',
  `dataType` varchar(9) NOT NULL default '',
  `units` varchar(1) NOT NULL default 's',
  `feed` text NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM PACK_KEYS=0 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;

DROP TABLE IF EXISTS `#__eweather_locations`;
CREATE TABLE IF NOT EXISTS `#__eweather_locations` (
  `id` int(4) NOT NULL auto_increment,
  `city` varchar(50) default NULL,
  `country` varchar(50) NOT NULL default '0',
  `region` varchar(50) NOT NULL default '0',
  `loc_id` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM PACK_KEYS=0 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;

DROP TABLE IF EXISTS `#__eweather_profiles`;
CREATE TABLE IF NOT EXISTS `#__eweather_profiles` (
  `id` int(11) NOT NULL auto_increment,
  `uid` varchar(10) NOT NULL default '',
  `locid` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;

DROP TABLE IF EXISTS `#__eweather_prefs`;
CREATE TABLE IF NOT EXISTS `#__eweather_prefs` (
  `id` int(11) NOT NULL auto_increment,
  `region` varchar(100) NOT NULL default '',
  `country` varchar(100) NOT NULL default '',
  `loc_id` varchar(5) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;

INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Algeria', 'AGXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Angola', 'AOXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Benin', 'BNXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Botswana', 'BCXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Burkina Faso', 'UVXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Burundi', 'BYXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Cameroon', 'CMXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Canary Islands', 'SPXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Cape Verde', 'CVXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Central African Republic', 'CTXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Chad', 'CDXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Comoros', 'CNXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Democratic Rep. of Congo', 'CGXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Djibouti', 'DJXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Egypt', 'EGXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Equatorial Guinea', 'EKXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Eritrea', 'ERXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Ethiopia', 'ETXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Gabon', 'GBXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Ghana', 'GHXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Guinea', 'GVXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Guinea-Bissau', 'PUXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Ivory Coast', 'IVXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Kenya', 'KEXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Lesotho', 'LTXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Liberia', 'LIXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Libya', 'LYXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Madagascar', 'MAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Malawi', 'MIXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Mali', 'MLXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Morocco', 'MOXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Mauritania', 'MRXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Mauritius', 'MPXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Mozambique', 'MZXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Namibia', 'WAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Niger', 'NGXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Nigeria', 'NIXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Republic of The Congo', 'CFXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Reunion Islands', 'REXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Rwanda', 'RWXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Sao Tome and Principe', 'TPXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Senegal', 'SGXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Seychelles', 'SEXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Sierra Leone', 'SLXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Somalia', 'SOXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'South Africa', 'SFXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'St. Helena', 'SHXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Sudan', 'SUXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Swaziland', 'WZXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Tanzania', 'TZXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'The Gambia', 'GAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Togo', 'TOXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Tunisia', 'TSXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Uganda', 'UGXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Western Sahara', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Zaire', 'CGXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Zambia', 'ZAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Africa', 'Zimbabwe', 'ZIXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Antarctica', 'Antarctica', 'AYXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Afghanistan', 'AFXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Armenia', 'AMXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Azerbaijan', 'AJXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Bangladesh', 'BGXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Bhutan', 'BTXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Brunei', 'BXXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Burma', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Cambodia', 'CBXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'China', 'CHXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Georgia', 'GGXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'India', 'INXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Indian Ocean Islands', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Indonesia', 'IDXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Japan', 'JAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Kazakhstan', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Kyrgyzstan', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Laos', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Macao', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Malaysia', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Maldives', 'MVXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Mongolia', 'MGXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Myanmar', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Nepal', 'NPXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'North Korea', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Pakistan', 'PKXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Philippines', 'RPXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Russia', 'RSXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Singapore', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'South Korea', 'KSXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Sri Lanka', 'CEXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Taiwan', 'TWXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Tajikistan', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Thailand', 'THXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Turkmenistan', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Uzbekistan', 'UZXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Asia', 'Vietnam', 'VMXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Australia/New Zealand', 'Australia', 'ASXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Australia/New Zealand', 'New Zealand', 'NZXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Anguilla', 'AVXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Antigua', 'ACXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Aruba', 'AAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Bahamas', 'BFXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Barbados', 'BBXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Caymen Islands', 'CJXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Cuba', 'CUXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Dominica', 'DOXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Dominican Republic', 'DRXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Grenada', 'GJXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Guadaloupe', 'GPXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Haiti', 'HAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Jamaica', 'JMXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Martinique', 'MBXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Montserrat', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Netherlands Antilles', 'NTXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Puerto Rico', 'USPR');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'St. Kitts and Nevis', 'SCXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'St. Lucia', 'STXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'St. Vincent and Grenadines', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Trinidad and Tobago', 'TDXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'Turks and Caicos Islands', 'TKXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'British Virgin Islands', 'VIXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Caribbean', 'U.S. Virgin Islands', 'USVI');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Central America', 'Belize', 'BHXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Central America', 'Costa Rica', 'CSXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Central America', 'El Salvador', 'ESXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Central America', 'Guatemala', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Central America', 'Honduras', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Central America', 'Nicaragua', 'NUXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Central America', 'Panama', 'PMXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Albania', 'ALXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Belarus', 'BOXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Bosnia', 'BKXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Bulgaria', 'BUXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Croatia', 'HRXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Czech Republic', 'EZXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Estonia', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Finland', 'FIXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Greece', 'GRXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Hungary', 'HUXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Latvia', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Lithuania', 'LHXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Macedonia', 'MKXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Moldova', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Poland', 'PLXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Romania', 'ROXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Serbia', 'SRXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Slovakia', 'LOXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Slovenia', 'SIXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'East Europe', 'Ukraine', 'UPXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Bahrain', 'BAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Cyprus', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Iran', 'IRXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Iraq', 'IZXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Israel', 'ISXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Jordan', 'JOXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Kuwait', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Lebanon', 'LEXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Oman', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Qatar', 'QAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Saudi Arabia', 'SAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Syria', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Turkey', 'TUXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'United Arab Emirates', 'AEXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'West Bank', 'WEXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Middle East', 'Yemen', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'North America', 'Canada', 'CAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'North America', 'Mexico', 'MXXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'North Atlantic Islands', 'Bermuda', 'BDXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Cook Islands', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Fiji', 'FJXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'French Polynesia', 'FPXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Guam', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Kiribati', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Marshall Islands', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Micronesia', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Nauru', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'New Caledonia', 'NCXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Palau', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Papua New Guinea', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Solomon Islands', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Tonga', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Tuvalu', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Vanuatu', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'Pacific Islands', 'Western Samoa', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Argentina', 'ARXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Bolivia', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Brazil', 'BRXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Chile', 'CIXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Colombia', 'COXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Ecuador', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Falkland Islands', 'FKXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'French Guiana', 'CAYX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Guyana', 'GYXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Paraguay', 'PAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Peru', 'PEXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Suriname', 'NSXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Uruguay', 'UYXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'South America', 'Venezuela', 'VEXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Alabama', 'USAL');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Alaska', 'USAK');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Arizona', 'USAZ');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Arkansas', 'USAR');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA California', 'USCA');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Colorado', 'USCO');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Connecticut', 'USCT');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA DC', 'USDC');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Delaware', 'USDE');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Florida', 'USFL');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Georgia', 'USGA');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Hawaii', 'USHI');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Idaho', 'USID');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Illinois', 'USIL');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Indiana', 'USIN');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Iowa', 'USIA');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Kansas', 'USKS');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Kentucky', 'USKY');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Louisiana', 'USLA');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Maine', 'USME');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Maryland', 'USMD');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Massachusetts', 'USMA');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Michigan', 'USMI');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Minnesota', 'USMN');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Mississippi', 'USMS');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Missouri', 'USMO');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Montana', 'USMT');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Nebraska', 'USNE');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Nevada', 'USNV');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA New Hampshire', 'USNH');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA New Jersey', 'USNJ');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA New Mexico', 'USNM');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA New York', 'USNY');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA North Carolina', 'USNC');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA North Dakota', 'USND');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Ohio', 'USOH');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Oklahoma', 'USOK');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Oregon', 'USOR');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Pennsylvania', 'USPA');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Rhodeisland', 'USRI');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA South Carolina', 'USSC');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA South Dakota', 'USSD');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Tennessee', 'USTN');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Texas', 'USTX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Utah', 'USUT');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Vermont', 'USVT');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Virginia', 'USVA');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Washington', 'USWA');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA West Virginia', 'USWV');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Wisconsin', 'USWI');
INSERT INTO `#__eweather_prefs` VALUES ('', 'United States', 'USA Wyoming', 'USWY');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Andorra', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Austria', 'AUXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Azores', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Belgium', 'BEXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Denmark', 'DAXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'France', 'FRXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Germany', 'GMXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Greenland', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Iceland', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Ireland', 'EIXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Italy', 'ITXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Liechtenstein', 'LSXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Luxembourg', 'LUXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Madeira Islands', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Malta', 'MTXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Monaco', '');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Netherlands', 'NLXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Norway', 'NOXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Portugal', 'POXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Spain', 'SPXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Sweden', 'SWXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Switzerland', 'SZXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'United Kingdom', 'UKXX');
INSERT INTO `#__eweather_prefs` VALUES ('', 'West Europe', 'Vatican City', '');

