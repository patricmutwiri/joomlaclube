<?php
/**
 * This file contains the classes front-end of the eWeather component.
 *
 * This file is part of eWeather.
 *
 *   eWeather is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   eWeather is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with eWeather.  If not, see <a href="http://www.gnu.org/licenses/">
 *   http://www.gnu.org/licenses/</a>.
 *
 * <b>Modifications:</b><br/>
 * aangepast door Mart Dirks<br/>
 * converted to Joomla! 1.5.x by Bob Lavey
 *
 * @version $Id: eweather.html.php 310 2009-11-11 16:56:02Z rjlavey $
 * @package eWeather
 * @subpackage eWeather
 * @copyright Copyright (c) 2000 - 2006 MamboBaer.de (Harald Baer),
 *            2009 Bob Lavey<br/>
 * @license http://www.gnu.org/licenses/gpl.txt GNU/GPL
 * @toto General clean up, see if raw HTML can be converted
 *        to something easier to maintain.
 */

/* ensure this file is being called by Joomla! */
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );


class PartnerLink
{
	var $url = null;
	var $text = null;
}

class weather_day {
  var $day_num = null;
  var $day_weekday = null;
  var $day_date = null;
  var $day_temp_max = null;
  var $day_temp_min = null;
  var $day_sunrise = null;
  var $day_sunset = null;
  // Day Part
  var $day_d_icon = null;
  var $day_d_text = null;
  var $day_d_windspeed = null;
  var $day_d_windgust = null;
  var $day_d_winddirection = null;
  var $day_d_windtext = null;
  var $day_d_precipitation = null;
  var $day_d_windtextd = null;
  var $day_d_humidity = null;
  // Night Part
  var $day_n_icon = null;
  var $day_n_text = null;
  var $day_n_windspeed = null;
  var $day_n_windgust = null;
  var $day_n_winddirection = null;
  var $day_n_windtext = null;
  var $day_n_precipitation = null;
  var $day_n_windtextd = null;
  var $day_n_humidity = null;
}

class weather_global {
  // Header Tag Informations
  var $h_temp = null;
  var $h_distance = null;
  var $h_speed = null;
  var $h_precipitation = null;
  var $h_pressure = null;

  var $e_error = null;
  var $n_channels = null;

  // Location Tag Information
  var $loc_city = null;
  var $loc_code = null;
  var $loc_localtime = null;
  var $loc_longitude = null;
  var $loc_latitude = null;
  var $loc_sunrise = null;
  var $loc_sunset = null;
  var $loc_timezone = null;

  // Current Conditions Tag Information
  var $cc_lastupdate = null;
  var $cc_observatory = null;
  var $cc_temp = null;
  var $cc_windchill = null;
  var $cc_text = null;
  var $cc_icon = null;
  var $cc_windspeed = null;
  var $cc_winddirection = null;
  var $cc_windtext = null;
  var $cc_windgust = null;
  var $cc_barpressure = null;
  var $cc_bartext = null;
  var $cc_humidity = null;
  var $cc_uvindex = null;
  var $cc_uvtext = null;
  var $cc_moonicon = null;
  var $cc_moontext = null;
  var $cc_visibility = null;
  var $cc_dewp =null;

  // Forecast Tag Information
  var $dayf_lastupdate = null;
  var $dayf_forecasts = array();

  // Partner Link Information
  var $partnerLinks = array();
}

class HTML_weather {

	var $pageClassSuffix_ = null;
	
	function HTML_weather()
	{
		global $mainframe;
		
		//
		// get the Page Class Suffix
		//
		$params =& $mainframe->getPageParameters();
		$this->setPageClassSuffix($params->get('pageclass_sfx'));
	}
	function setPageClassSuffix($pageClassSuffix)
	{
		$this->pageClassSuffix_ = $pageClassSuffix;
	}
	function getPageClassSuffix()
	{
		return $this->pageClassSuffix_;
	}


  function displayHeader(){
    $url = JUri::base(true);
	$database = &JFactory::getDBO();
	global $Itemid;

	//
	// get the name of the menu associated with $Itemid
	//  (that's the eWeather menu)
	//
	$sql = "SELECT * FROM `#__menu` WHERE `id` = '".$Itemid."'";
    $database->setQuery($sql);
    $menu = $database->loadObject();
    if ($menu != null)
    {
    	$params = new JParameter($menu->params);

    	if (($params != null) && ($params->get('show_page_title') <> 0))
    	{
     		echo "<h1 class=\"componentheading".$this->getPageClassSuffix()."\">".$menu->name."</h1>\n";
    	}
    }

  }

  function displayCitySelector()
  {
  	global $Itemid;
  	$selectLocationUrl = JROUTE::_("index.php?option=com_eweather&amp;Itemid=".$Itemid."&amp;task=profiles");
  	
    $content = "<br />"
            ."  <table width=\"98%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n"
            ."    <tr>\n";
    $content.= "    <td valign=\"bottom\" align=\"left\" style=\"border-bottom: 1px solid #cccccc; margin-top: 2px; padding-top: 5px; padding-bottom: 5px; text-align: left;\">\n"
            ."        <div align=\"left\"><a class=\"button".$this->getPageClassSuffix()."\" href=\"".$selectLocationUrl."\">".JText::_('EWEATHER_SELECT_LOCATION')."</a></div>\n"
            ."      </td>\n"
            ."    </tr>\n"
            ."  </table>\n";

    echo $content;
  }
  
  function displayWeather(&$weather, $weatherIconStyle){
    $url = JUri::base(true);

    $cont_xx  =" <table width=\"98%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\" align=\"center\">\n"
              ."  <tr><td>&nbsp;</td></tr>\n"
              ." <tr>\n"
              ."    <td class=\"sectiontableheader".$this->getPageClassSuffix()."\" valign=\"middle\">"
              ."      ".JText::_('EWEATHER_ACTUAL')."&nbsp;-&nbsp;".$weather->loc_city."\n"
              ."      <br/>\n"
              ."      ".JText::_('EWEATHER_LASTUPDATED')."&nbsp;-&nbsp;".$weather->cc_lastupdate."\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>&nbsp;</td>\n"
              ."  </tr>\n"

/*
 * CSS-based current conditions stuff
 * still work in progress
 *
	$cont_xx  ="    <div class=\"cc_header\">"
              ."      ".JText::_('EWEATHER_ACTUAL')."&nbsp;-&nbsp;".$weather->loc_city."\n"
              ."      <br/>\n"
              ."      ".JText::_('EWEATHER_LASTUPDATED')."&nbsp;-&nbsp;".$weather->cc_lastupdate."\n"
              ."    </div>\n"

			  ."    <div class=\"cc_block_wrapper\" style=\"float:left;\">\n"
			  ."    <div class=\"cc_block\">\n"
			  ."      <div class=\"cc_block_header\">\n"
              ."        ".$weather->loc_city."\n"
			  ."      </div>\n"
			  ."      <div class=\"cc_upper\">\n"
              ."        <div class=\"cc_image\">\n"
			  ."          <img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/large/".$weather->cc_icon.".png\" alt=\"\" border=\"0\" />\n"
              ."          <div>".$weather->cc_text."</div>\n"
			  ."        </div>\n"
			  ."        <p>".$weather->cc_temp."&deg;".$weather->h_temp."</p>\n"
			  ."      </div>\n"
			  ."      <div class=\"cc_lower\" >\n"
			  ."        <dl class=\"cc_details\" >\n"
			  ."          <div class=\"cc_details_odd\">\n"
              ."            <dt>".JText::_('EWEATHER_WINDCHILL').": </dt>\n"
              ."            <dd>".$weather->cc_windchill."&deg;".$weather->h_temp."</dd>\n"
			  ."          </div>\n"
			  ."          <div class=\"cc_details_even\">\n"
              ."            <dt>".JText::_('EWEATHER_SUNRISE').": </dt>\n"
              ."            <dd>".$weather->loc_sunrise."</dd>\n"
			  ."          </div>\n"
			  ."          <div class=\"cc_details_odd\">\n"
              ."            <dt>".JText::_('EWEATHER_SUNSET').": </dt>\n"
              ."            <dd>".$weather->loc_sunset."</dd>\n"
			  ."          </div>\n"
			  ."        </dl>\n"
              ."        <div class=\"cc_moon_block\">\n"
			  ."          <img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/moon/".$weather->cc_moonicon.".gif\" alt=\"\" border=\"0\"/>\n"
              ."          <p>".$weather->cc_moontext."</p>\n"
			  ."        </div>\n"
			  ."      </div>\n"
			  ."      <div class=\"clear\"></div>\n"
			  ."    </div>\n"
			  ."  </div>\n"


			  ."    <div class=\"cc_block_wrapper\" style=\"float:left;\">\n"
			  ."    <div class=\"cc_block\">\n"
			  ."      <div class=\"cc_block_header\">\n"
              ."        ".$weather->loc_city."\n"
			  ."      </div>\n"
			  ."      <div class=\"cc_upper\">\n"
              ."        <div class=\"cc_image\">\n"
			  ."          <img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/large/".$weather->cc_icon.".png\" alt=\"\" border=\"0\" />\n"
              ."          <div>".$weather->cc_text."</div>\n"
			  ."        </div>\n"
			  ."        <p>".$weather->cc_temp."&deg;".$weather->h_temp."</p>\n"
			  ."      </div>\n"
			  ."      <div class=\"cc_lower\" >\n"
			  ."        <dl class=\"cc_details\" >\n"
			  ."          <div class=\"cc_details_odd\">\n"
              ."            <dt>".JText::_('EWEATHER_WINDCHILL').": </dt>\n"
              ."            <dd>".$weather->cc_windchill."&deg;".$weather->h_temp."</dd>\n"
			  ."          </div>\n"
			  ."          <div class=\"cc_details_even\">\n"
              ."            <dt>".JText::_('EWEATHER_SUNRISE').": </dt>\n"
              ."            <dd>".$weather->loc_sunrise."</dd>\n"
			  ."          </div>\n"
			  ."          <div class=\"cc_details_odd\">\n"
              ."            <dt>".JText::_('EWEATHER_SUNSET').": </dt>\n"
              ."            <dd>".$weather->loc_sunset."</dd>\n"
			  ."          </div>\n"
			  ."        </dl>\n"
              ."        <div class=\"cc_moon_block\">\n"
			  ."          <img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/moon/".$weather->cc_moonicon.".gif\" alt=\"\" border=\"0\"/>\n"
              ."          <p>".$weather->cc_moontext."</p>\n"
			  ."        </div>\n"
			  ."      </div>\n"
			  ."      <div class=\"clear\"></div>\n"
			  ."    </div>\n"
			  ."    </div>\n"

			  ."    <div class=\"cc_block_wrapper\" style=\"float:left;\">\n"
			  ."    <div class=\"cc_block\">\n"
			  ."      <div class=\"cc_block_header\">\n"
              ."        ".$weather->loc_city."\n"
			  ."      </div>\n"
			  ."      <div class=\"cc_upper\">\n"
              ."        <div class=\"cc_image\">\n"
			  ."          <img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/large/".$weather->cc_icon.".png\" alt=\"\" border=\"0\" />\n"
              ."          <div>".$weather->cc_text."</div>\n"
			  ."        </div>\n"
			  ."        <p>\n"
			  ."          ".$weather->cc_temp."&deg;".$weather->h_temp."\n"
			  ."        </p>\n"
			  ."      </div>\n"
			  ."      <div class=\"cc_lower\" >\n"
			  ."        <dl class=\"cc_details\" >\n"
			  ."          <div class=\"cc_details_odd\">\n"
              ."            <dt>".JText::_('EWEATHER_WINDCHILL').": </dt>\n"
              ."            <dd>".$weather->cc_windchill."&deg;".$weather->h_temp."</dd>\n"
			  ."          </div>\n"
			  ."          <div class=\"cc_details_even\">\n"
              ."            <dt>".JText::_('EWEATHER_SUNRISE').": </dt>\n"
              ."            <dd>".$weather->loc_sunrise."</dd>\n"
			  ."          </div>\n"
			  ."          <div class=\"cc_details_odd\">\n"
              ."            <dt>".JText::_('EWEATHER_SUNSET').": </dt>\n"
              ."            <dd>".$weather->loc_sunset."</dd>\n"
			  ."          </div>\n"
			  ."        </dl>\n"
              ."        <div class=\"cc_moon_block\">\n"
			  ."          <img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/moon/".$weather->cc_moonicon.".gif\" alt=\"\" border=\"0\"/>\n"
              ."          <p>".$weather->cc_moontext."</p>\n"
			  ."        </div>\n"
			  ."      </div>\n"
			  ."      <div class=\"clear\"></div>\n"
			  ."    </div>\n"
			  ."    </div>\n"
*/
              ."  <tr>\n"
              ."    <td>\n"
              ."      <table border=\"0\" width=\"99%\" align=\"center\" cellpadding=\"2\" cellspacing=\"0\">\n"
                        //
                        // headings for Current Condition columns
                        //
              ."        <tr>\n"
              ."          <td class=\"CurrentConditionsBlockHeader".$this->getPageClassSuffix()."\" width=\"33%\">".$weather->loc_city."</td>\n"
              ."          <td>&nbsp;</td>\n"
              ."          <td class=\"CurrentConditionsBlockHeader".$this->getPageClassSuffix()."\" width=\"33%\">".JText::_('EWEATHER_WIND')."</td>\n"
              ."          <td>&nbsp;</td>\n"
              ."          <td class=\"CurrentConditionsBlockHeader".$this->getPageClassSuffix()."\" width=\"33%\">".JText::_('EWEATHER_LOC_DATA')."</td>\n"
              ."        </tr>\n"
              ."        <tr>\n"
              ."          <td valign=\"top\" style=\"border: 1px solid #CCCCCC;\">\n"

              ."            <table border=\"0\" width=\"100%\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\n"
              ."              <tr>\n"
              ."                <td>\n"
              ."                  <div align=\"center\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/large/".$weather->cc_icon.".png\" alt=\"\" border=\"0\" /></div>\n"
              ."                  <div class=\"CurrentConditionsText".$this->getPageClassSuffix()."\">".$weather->cc_text."</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"CurrentConditionsTemperature".$this->getPageClassSuffix()."\">".$weather->cc_temp."&deg;".$weather->h_temp."</div><br />\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."            </table>\n"
              ."            <table border=\"0\" width=\"96%\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\n"
              ."              <tr>\n"
              ."                <td>\n"
              ."                  <table border=\"0\" width=\"100%\" cellspacing=\"0\" summary=\"\">\n"
              ."                    <tr class=\"CurrentConditionsDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                      <td>\n"
              ."                        <div class=\"CurrentConditionsDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_WINDCHILL').":</div>\n"
              ."                      </td>\n"
              ."                      <td>\n"
              ."                        <div class=\"CurrentConditionsDetailValue".$this->getPageClassSuffix()."\">".$weather->cc_windchill."&deg;".$weather->h_temp."</div>\n"
              ."                      </td>\n"
              ."                    </tr>\n"
              ."                    <tr class=\"CurrentConditionsDetail_2".$this->getPageClassSuffix()."\">\n"
              ."                      <td>\n"
              ."                        <div class=\"CurrentConditionsDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_SUNRISE').":</div>\n"
              ."                      </td>\n"
              ."                      <td>\n"
              ."                        <div class=\"CurrentConditionsDetailValue".$this->getPageClassSuffix()."\">".$weather->loc_sunrise."</div>\n"
              ."                      </td>\n"
              ."                    </tr>\n"
              ."                    <tr class=\"CurrentConditionsDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                      <td>\n"
              ."                        <div class=\"CurrentConditionsDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_SUNSET').":</div>\n"
              ."                      </td>\n"
              ."                      <td>\n"
              ."                        <div class=\"CurrentConditionsDetailValue".$this->getPageClassSuffix()."\">".$weather->loc_sunset."</div>\n"
              ."                      </td>\n"
              ."                    </tr>\n"
              ."                  </table>\n"
              ."                </td>\n"
              ."                <td align=\"center\">\n";
  if ($weather->cc_moonicon != null)
  {             
    $cont_xx .="                    <img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/moon/".$weather->cc_moonicon.".gif\" border=\"0\" alt=\"\" />";
  }
    $cont_xx .="                    <br />"
              .                     $weather->cc_moontext
              ."                </td>\n"
              ."              </tr>\n"
              ."            </table>\n"
              ."          </td>\n"

              ."          <td>&nbsp;</td>\n"

              ."          <td valign=\"top\" style=\"border: 1px solid #CCCCCC\">\n"

              ."            <table border=\"0\" width=\"100%\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\n"
              ."              <tr>\n"
              ."                <td>\n"
              ."                  <div align=\"center\">\n";

  if (($weather->cc_windtext != null) && ($weather->cc_windtext != "N/A"))
  {
    $cont_xx .="<img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/winddirs/wind_".$weather->cc_windtext.".gif\" alt=\"\" border=\"0\" />";
  }
  else
  {
    $cont_xx .="<img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/winddirs/wind_nodir.gif\" alt=\"\" border=\"0\" />";
  }
  
    $cont_xx .="</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"CurrentConditionsWindBlockText".$this->getPageClassSuffix()."\">".$weather->cc_windtext."</div><br />\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."            </table><br />\n"
              ."            <table border=\"0\" width=\"100%\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\n"
              ."              <tr>\n"
              ."                <td valign=\"middle\">\n"

              ."                  <table border=\"0\" width=\"80%\" cellspacing=\"0\" align=\"center\">\n"
              ."                    <tr class=\"CurrentConditionsWindDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                      <td>\n"
              ."                        <div class=\"CurrentConditionsWindDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_WINDSPEED').":</div>\n"
              ."                      </td>\n"
              ."                      <td>\n"
              ."                        <div class=\"CurrentConditionsWindDetailValue".$this->getPageClassSuffix()."\">".$weather->cc_windspeed."&nbsp;".$weather->h_speed."</div>\n"
              ."                      </td>\n"
              ."                    </tr>\n"
              ."                    <tr class=\"CurrentConditionsWindDetail_2".$this->getPageClassSuffix()."\">\n"
              ."                      <td>\n"
              ."                        <div class=\"CurrentConditionsWindDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_WINDDIR').":</div>\n"
              ."                      </td>\n"
              ."                      <td>\n"
              ."                        <div class=\"CurrentConditionsWindDetailValue".$this->getPageClassSuffix()."\">".$weather->cc_winddirection."&deg;</div>\n"
              ."                      </td>\n"
              ."                    </tr>\n"
              ."                    <tr class=\"CurrentConditionsWindDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                      <td>\n"
              ."                        <div class=\"CurrentConditionsWindDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_WINDGUST').":</div>\n"
              ."                      </td>\n"
              ."                      <td>\n"
              ."                        <div class=\"CurrentConditionsWindDetailValue".$this->getPageClassSuffix()."\">".$weather->cc_windgust."&nbsp;".$weather->h_speed."</div>\n"
              ."                      </td>\n"
              ."                    </tr>\n"
              ."                  </table>\n"

              ."                </td>\n"
              ."              </tr>\n"
              ."            </table>\n"


              ."          </td>\n"

              ."          <td>&nbsp;</td>\n"

              ."          <td valign=\"top\" style=\"border: 1px solid #CCCCCC;\">\n"

              ."            <br />\n"
              ."            <table border=\"0\" width=\"98%\" cellspacing=\"0\" align=\"center\" summary=\"\">\n"
              ."              <tr class=\"CurrentConditionsLocationDataDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"CurrentConditionsLocationDataDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_OBST').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"CurrentConditionsLocationDataDetailValue".$this->getPageClassSuffix()."\">".$weather->cc_observatory."</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"CurrentConditionsLocationDataDetail_2".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"CurrentConditionsLocationDataDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_LAT').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                <div class=\"CurrentConditionsLocationDataDetailValue".$this->getPageClassSuffix()."\">".$weather->loc_latitude."</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"CurrentConditionsLocationDataDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"CurrentConditionsLocationDataDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_LON').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                <div class=\"CurrentConditionsLocationDataDetailValue".$this->getPageClassSuffix()."\">".$weather->loc_longitude."</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"CurrentConditionsLocationDataDetail_2".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"CurrentConditionsLocationDataDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_DEWP').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                <div class=\"CurrentConditionsLocationDataDetailValue".$this->getPageClassSuffix()."\">".$weather->cc_dewp."&deg;".$weather->h_temp."</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"CurrentConditionsLocationDataDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"CurrentConditionsLocationDataDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_VISIBILITY').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                <div class=\"CurrentConditionsLocationDataDetailValue".$this->getPageClassSuffix()."\">".$weather->cc_visibility."&nbsp;".$weather->h_distance."</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"CurrentConditionsLocationDataDetail_2".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"CurrentConditionsLocationDataDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_HUMIDITY').":</div>\n"
              ."                </td>\n"
              ."                <td>\n";
  if (is_numeric($weather->cc_humidity))
  {
    $cont_xx .="                <div class=\"CurrentConditionsLocationDataDetailValue".$this->getPageClassSuffix()."\">".$weather->cc_humidity."%</div>\n";
  }
  else
  {
    $cont_xx .="                <div class=\"CurrentConditionsLocationDataDetailValue".$this->getPageClassSuffix()."\">".$weather->cc_humidity."</div>\n";
  }
    $cont_xx .="                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"CurrentConditionsLocationDataDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"CurrentConditionsLocationDataDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_PRESSURE').":</div>\n"
              ."                </td>\n"
              ."                <td>\n";
  if (is_numeric($weather->cc_barpressure))
  {
    $cont_xx .="                  <div class=\"CurrentConditionsLocationDataDetailValue".$this->getPageClassSuffix()."\">".$weather->cc_barpressure."&nbsp;".$weather->h_pressure."&nbsp;(".$weather->cc_bartext.")</div>\n";
  }
  else
  {
    $cont_xx .="                  <div class=\"CurrentConditionsLocationDataDetailValue".$this->getPageClassSuffix()."\">".$weather->cc_barpressure."</div>\n";
  }
    $cont_xx .="                </td>\n"
              ."              </tr>\n"
              ."            </table>\n"
              ."            <br />\n"
              ."            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"174\" align=\"center\" summary=\"\">\n"
              ."            <tbody>\n"
              ."              <tr>\n"
              ."                <td colspan=\"4\" style=\"height: 2px;\"></td>\n"
              ."              </tr>\n"
              ."              <tr>\n"
              ."                <td class=\"CurrentConditionsUvIndexHeader\" colspan=\"4\" valign=\"top\">\n"
              ."                  &nbsp;".JText::_('EWEATHER_UV_INDEX')."&nbsp;(".$weather->cc_uvindex.")\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr>\n"
              ."                <td rowspan=\"3\" style=\"height: 3px; width: 4px;\"></td>\n"
              ."              </tr>\n"
              ."              <tr>\n"
              ."                <td colspan=\"4\" height=\"4\">\n"
              ."                  <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"height: 2; \" summary=\"\">\n"
              ."                  <tbody>\n"
              ."                    <tr>\n";

              for ($y = 0; $y < 11; $y++) {
                 if($weather->cc_uvindex != $y){
                    $cont_xx.= "          <td width=\"15\"></td>\n";
                 } else {
                    $cont_xx.= "          <td width=\"15\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/arrow.gif\" height=\"6\" width=\"6\" alt=\"\" /></td>\n";
                 }
              }


    $cont_xx.= "        </tr>\n"
              ."        </tbody>\n"
              ."      </table>\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td colspan=\"4\" height=\"4\">\n"
              ."      <img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/uvkey.gif\" height=\"10\" width=\"166\" alt=\"\" />\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td colspan=\"4\" style=\"height: 1px;\"></td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td rowspan=\"3\" style=\"width: 4px;\"></td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td width=\"42\"><font face=\"Verdana,sans-serif\" size=\"-2\">".JText::_('EWEATHER_UV_LOW')."</font></td>\n"
              ."    <td width=\"42\"><font face=\"Verdana,sans-serif\" size=\"-2\">".JText::_('EWEATHER_UV_MED')."</font></td>\n"
              ."    <td width=\"42\"><font face=\"Verdana,sans-serif\" size=\"-2\">".JText::_('EWEATHER_UV_HIGH')."</font></td>\n"
              ."    <td width=\"42\"><font face=\"Verdana,sans-serif\" size=\"-2\">".JText::_('EWEATHER_UV_SHIGH')."</font></td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td width=\"42\"><font face=\"Verdana,sans-serif\" size=\"-2\">0</font></td>\n"
              ."    <td width=\"42\"><font face=\"Verdana,sans-serif\" size=\"-2\">&nbsp;</font></td>\n"
              ."    <td width=\"42\"><font face=\"Verdana,sans-serif\" size=\"-2\">&nbsp;</font></td>\n"
              ."    <td width=\"42\" align=\"right\" style=\"text-align: right;\"><font face=\"Verdana,sans-serif\" size=\"-2\">+10</font></td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td colspan=\"4\" style=\"height: 6px;\"></td>\n"
              ."  </tr>\n"
              ."  </tbody>\n"
              ."</table>\n"

              ."          </td>\n"

              ."        </tr>\n"
              ."      </table>\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."</table><br /><br />\n";

    echo $cont_xx;
  }

  function displayLinks(&$weather){
/*
 * CSS-based current conditions stuff
 * still work in progress
 *
    $numLinks = count($weather->partnerLinks);
    $content = "<ul id=\"provider-links\">\n";
    
    for ($x = 0; $x < $numLinks; $x++)
    {
		$link = str_replace('&','&amp;',$weather->partnerLinks[$x]->url);
		$text = str_replace('&','&amp;',$weather->partnerLinks[$x]->text);
 		$content .= "  <li>\n"
		          . "    <a href=\"".$link."\" title=\"".$text."\" >"
    	          . "      ".$text."\n"
				  . "    </a>\n"
				  . "  </li>\n";
    }

    $content.="</li>\n";
*/

    $numLinks = count($weather->partnerLinks);
    $content = "<div align=\"left\">\n";
    
    for ($x = 0; $x < $numLinks; $x++)
    {
 		 $content.="<a target=\"_blank\" href=\"".str_replace('&','&amp;',$weather->partnerLinks[$x]->url)
    	         ."\" title=\"".str_replace('&','&amp;',$weather->partnerLinks[$x]->text)."\" >"
    	         .str_replace('&','&amp;',$weather->partnerLinks[$x]->text)."</a><br/>\n";
    }

    $content.="</div>\n";
    
    return $content;
  }
  
  function displayForecast(&$weather)
  {
 	$cfg = & WeatherConfiguration::getInstance();
  	
  	echo $this->getForecastHeaderMarkup($weather);
  	echo $this->getForecastMarkup($weather, $cfg->getForecastDays(), $cfg->getForecastDaysPerRow());
  }
  
  function getForecastHeaderMarkup(&$weather)
  {
    $content = "<a name=\"eWeatherForecast\"></a>\n"
              ."<table width=\"98%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\" align=\"center\" summary=\"\">\n"
              ."  <tr>"
              ."    <td class=\"sectiontableheader".$this->getPageClassSuffix()."\" valign=\"middle\">"
              ."      ".JText::_('EWEATHER_FORECAST')."&nbsp;-&nbsp;".$weather->loc_city."\n"
              ."      <br/>\n"
              ."      ".JText::_('EWEATHER_LASTUPDATED')."&nbsp;-&nbsp;".$weather->dayf_lastupdate."\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>\n"
              ."      <br />\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."</table>\n";
    
    return $content;
  }
  
  function getForecastMarkup(&$weather, $forecastDays, $forecastDaysPerRow)
  {
    global $Itemid;
    
  	$url = JUri::base(true);
  	$cfg = & WeatherConfiguration::getInstance();
    $weatherIconStyle = $cfg->getIconStyle();
    $date_format = $cfg->getDateFormatShort();
    
    $content = "";

    $content.= "<table>\n"
              ."  <tr>\n";
    
    for ($x = 0; $x < $forecastDays; $x++) {
    $v = JHTML::_('date', strtotime($weather->dayf_forecasts[$x]->day_date), $date_format, 0);
    $detailedForecastUrl = JROUTE::_("index.php?option=com_eweather&amp;Itemid=".$Itemid."&amp;task=viewWeather&amp;weatherLocation=".$weather->loc_code."&amp;detailedForecast=".$x."#eWeatherForecastDetail");
        
    $content.= "    <td>\n"
              ."      <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" summary=\"\">\n"
              ."        <tr>\n"
              //  background=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/subhead.png\"
              ."          <td style=\" border-left: 1px solid #CCCCCC; border-right: 1px solid #CCCCCC; background: url(".$url."/components/com_eweather/images/".$weatherIconStyle."/subhead.png) repeat-x;\" height=\"19\" colspan=\"2\">\n"
              //  valign=\"absmiddle\"
              ."            <div style=\"font-weight: bold; text-align: center; color: #000000; border: 0px; vertical-align: bottom;\">\n"
              ."              <a href=\"".$detailedForecastUrl."\" title=\"".JText::_('EWEATHER_FORECAST_FTITLE')."\">\n"
              ."                <img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/plus.gif\" align=\"left\" border=\"0\" alt=\"\" />\n"
              ."              </a>\n"
              ."              ".$v
              ."            </div>\n"
              ."          </td>\n"
              ."        </tr>\n"
              ."        <tr>\n"
              ."          <td style=\"border-left: 1px solid #CCCCCC; border-right: 1px solid #CCCCCC;\">\n"
              ."            <div style=\"font-weight: bold; text-align: center;\">".JText::_('EWEATHER_FORECAST_DAY')."</div>\n"
              ."          </td>\n"
              ."          <td style=\"border-right: 1px solid #CCCCCC;\">\n"
              ."            <div style=\"font-weight: bold; text-align: center;\">".JText::_('EWEATHER_FORECAST_NIGHT')."</div>\n"
              ."          </td>\n"
              ."        </tr>\n"
              ."        <tr>\n"
              ."          <td style=\"border-left: 1px solid #CCCCCC; border-right: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC;\">\n"
              ."            <div align=\"center\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/small/".$weather->dayf_forecasts[$x]->day_d_icon.".png\" border=\"0\" alt=\"\" /><br /></div>\n"
              ."          </td>\n"
              ."          <td style=\"border-right: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC;\">\n"
              ."            <div align=\"center\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/small/".$weather->dayf_forecasts[$x]->day_n_icon.".png\" border=\"0\" alt=\"\" /><br /></div>\n"
              ."          </td>\n"
              ."        </tr>\n"
              ."        <tr>\n"
              ."          <td style=\"border-left: 1px solid #CCCCCC; border-right: 1px solid #CCCCCC;\" colspan=\"2\">\n"
              ."            <div style=\"font-weight: bold; text-align: center; color: #000000; background: #EFEFEF;\">".JText::_('EWEATHER_FORECAST_TEMP')."</div>\n"
              ."          </td>\n"
              ."        </tr>\n"
              ."        <tr>\n"
              ."          <td style=\"border-left: 1px solid #CCCCCC; border-right: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC;\">\n"
              ."            <div align=\"center\">".JText::_('EWEATHER_FORECAST_TEMP_MAX').": ".$weather->dayf_forecasts[$x]->day_temp_max."&deg;".$weather->h_temp."<br /></div>\n"
              ."          </td>\n"
              ."          <td style=\"border-right: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC;\">\n"
              ."            <div align=\"center\">".JText::_('EWEATHER_FORECAST_TEMP_MIN').": ".$weather->dayf_forecasts[$x]->day_temp_min."&deg;".$weather->h_temp."<br /></div>\n"
              ."          </td>\n"
              ."        </tr>\n"
              ."        <tr>\n"
              ."          <td style=\"border-left: 1px solid #CCCCCC; border-right: 1px solid #CCCCCC;\" colspan=\"2\">\n"
              ."            <div style=\"font-weight: bold; text-align: center; color: #000000; background: #EFEFEF;\">".JText::_('EWEATHER_FORECAST_RAIN')."</div>\n"
              ."          </td>\n"
              ."        </tr>\n"
              ."        <tr>\n"
              ."          <td style=\"border-left: 1px solid #CCCCCC; border-right: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC;\">\n"
              ."            <div align=\"center\">".$weather->dayf_forecasts[$x]->day_d_precipitation."%<br /></div>\n"
              ."          </td>\n"
              ."          <td style=\"border-right: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC;\">\n"
              ."            <div align=\"center\">".$weather->dayf_forecasts[$x]->day_n_precipitation."%<br /></div>\n"
              ."          </td>\n"
              ."        </tr>\n"
              ."        <tr>\n"
              ."          <td style=\"border-left: 1px solid #CCCCCC; border-right: 1px solid #CCCCCC;\" colspan=\"2\">\n"
              ."            <div style=\"font-weight: bold; text-align: center; color: #000000; background: #EFEFEF;\">".JText::_('EWEATHER_FORECAST_WIND')."</div>\n"
              ."           </td>\n"
              ."         </tr>\n"
              ."         <tr>\n"
              ."           <td style=\"border-left: 1px solid #CCCCCC; border-right: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC;\">\n"
              ."             <div align=\"center\">".$weather->dayf_forecasts[$x]->day_d_windtext."&nbsp;".$weather->dayf_forecasts[$x]->day_d_windspeed."<br /></div>\n"
              ."           </td>\n"
              ."           <td style=\"border-right: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC;\">\n"
              ."             <div align=\"center\">".$weather->dayf_forecasts[$x]->day_n_windtext."&nbsp;".$weather->dayf_forecasts[$x]->day_n_windspeed."<br /></div>\n"
              ."           </td>\n"
              ."         </tr>\n"
              ."       </table>\n"
              ."     </td>\n";
              
    if (($x % $forecastDaysPerRow) == ($forecastDaysPerRow - 1))
    {
    $content.= "   </tr>\n"
              ."   <tr>\n"
              ."     <td colspan=\"15\" height=\"10\"></td>\n"
              ."   </tr>\n";
	  //
	  // if there are more forecasts, open a new row
	  //
      if ($x != $forecastDays-1) { $content.= "   <tr>\n"; }
    }
    elseif ($x != $forecastDays-1)
    {
    $content.= "     <td width=\"15\"></td>\n";
    }
    }

	//
	// if there is still a forecast row open, close it
	// there will be a forecast row open in the case that
	//  the number of forecasts per row is not an even
	//  multiple of the number of forecasts
	//
    if (($forecastDays % $forecastDaysPerRow) != 0)
	{
    $content.= " </tr>\n";
	}
    $content.= "</table>\n";
              
    return $content;
  }

  function displayDetailForecast(&$weather, $weatherCity, $weatherCode, $weatherIconStyle, $lastUpdate, $metric_v, $metric_t, $date_format){
    $url = JUri::base(true);
	global $Itemid;

	$v = JHTML::_('date', strtotime($weather->day_date), $date_format, 0);
    $forecastUrl = JROUTE::_("index.php?option=com_eweather&amp;Itemid=".$Itemid."&amp;task=viewWeather&amp;weatherLocation=$weatherCode#eWeatherForecast");
	
	$content = "<a name=\"eWeatherForecastDetail\"></a>\n"
              ."<table width=\"98%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\" align=\"center\" summary=\"\">\n"
              ."  <tr>"
              ."    <td class=\"sectiontableheader".$this->getPageClassSuffix()."\" valign=\"middle\">"
              ."      ".JText::_('EWEATHER_FORECAST')."&nbsp;".JText::_('EWEATHER_FORECAST_FOR')."&nbsp;".$weatherCity."\n"
              ."      <br/>\n"
              ."      ".JText::_('EWEATHER_LASTUPDATED')."&nbsp;".$lastUpdate."\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td>\n"
              ."      <br />\n"
              ."      <table width=\"70%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" summary=\"\">\n"
              ."        <tr>\n"
              ."          <td class=\"ForecastBlockHeader".$this->getPageClassSuffix()."\">\n"
              ."            <div style=\"font-weight: bold; text-align: center; color: #000000; border: 0px; vertical-align: bottom;\" valign=\"absmiddle\">\n"
              ."              <a href=\"".$forecastUrl."\" title=\"".JText::_('EWEATHER_FORECAST_BACK')."\">\n"
              ."              <img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/minus.gif\" align=\"left\" border=\"0\" alt=\"\" />\n"
              ."              </a>\n"
              ."            </div>\n"
              ."            <b>".JText::_('EWEATHER_FORECAST')."&nbsp;".JText::_('EWEATHER_FORECAST_FOR')."&nbsp;".$v."</b>\n"
              ."          </td>\n"
              ."        </tr>\n"
              ."        <tr>\n"
              ."          <td style=\"border-left: 1px solid #CCCCCC; border-right: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC;\">\n"
              ."            <br />\n"
              ."            <table width=\"98%\" align=\"center\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\" summary=\"\">\n"
              ."              <tr>\n"
              ."                <td colspan=\"2\" align=\"center\" style=\"padding-bottom: 5px; border-bottom: 1px solid #CCCCCC;\">\n"

              ."            <table border=\"0\" width=\"290\" cellspacing=\"0\" align=\"center\" cellpadding=\"2\" cellspacing=\"5\" summary=\"\">\n"
              ."              <tr class=\"ForecastDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"ForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_FORECAST_TEMP_D_MAX').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"ForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_temp_max."&deg;".$metric_t."</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"ForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_SUNRISE').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"ForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_sunrise."</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"ForecastDetail_2".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"ForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_FORECAST_TEMP_D_MIN').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"ForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_temp_min."&deg;".$metric_t."</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"ForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_SUNSET').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"ForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_sunset."</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."            </table>\n"


              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr>\n"
              ."                <td align=\"center\">\n"
              ."                  <div align=\"center\"><b>".JText::_('EWEATHER_FORECAST_D_DAY')."</b></div>\n"
              ."                </td>\n"
              ."                <td align=\"center\">\n"
              ."                  <div align=\"center\"><b>".JText::_('EWEATHER_FORECAST_D_NIGHT')."</b></div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr>\n"
              ."                <td width=\"50%\" valign=\"top\">\n"

              ."                  <table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\" summary=\"\">\n"
              ."                    <tr>\n"
              ."                      <td width=\"50%\" height=\"140\">\n"
              ."                        <div align=\"center\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/large/".$weather->day_d_icon.".png\" border=\"0\" alt=\"\" /><br /></div>\n"
              ."                      </td>\n"
              ."                      <td width=\"50%\" height=\"140\" valign=\"middle\">\n"
              ."                        <div class=\"DaytimeForecastText".$this->getPageClassSuffix()."\">".$weather->day_d_text."<br /><br /></div>\n"

              ."            <table border=\"0\" width=\"100%\" cellspacing=\"0\" summary=\"\">\n"
              ."              <tr class=\"DaytimeForecastDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"DaytimeForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_FORECAST_D_RAIN').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"DaytimeForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_d_precipitation."%</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"DaytimeForecastDetail_2".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"DaytimeForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_HUMIDITY').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"DaytimeForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_d_humidity."%</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."            </table>\n"


              ."                      </td>\n"
              ."                    </tr>\n"
              ."                    <tr>\n"
              ."                      <td width=\"50%\" height=\"140\" valign=\"middle\">\n"
              ."                        <div class=\"DaytimeForecastWindText".$this->getPageClassSuffix()."\">".$weather->day_d_windtext."<br /><br /></div>\n"



              ."            <table border=\"0\" width=\"100%\" cellspacing=\"0\" summary=\"\">\n"
              ."              <tr class=\"DaytimeForecastDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"DaytimeForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_WINDSPEED').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"DaytimeForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_d_windspeed."&nbsp;".$metric_v."</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"DaytimeForecastDetail_2".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"DaytimeForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_WINDDIR').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"DaytimeForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_d_winddirection."&deg;</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"DaytimeForecastDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"DaytimeForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_WINDGUST').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"DaytimeForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_d_windgust."&nbsp;".$metric_v."</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."            </table>\n"

              ."                      </td>\n"
              ."                      <td width=\"50%\" height=\"140\">\n";
   if (($weather->day_d_windtext != null) && ($weather->day_d_windtext != "N/A"))
   {
     $content .="                        <div align=\"center\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/winddirs/wind_".$weather->day_d_windtext.".gif\" border=\"0\" alt=\"\" /><br /></div>\n";
   }
   else
   {
     $content .="                        <div align=\"center\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/winddirs/wind_nodir.gif\" border=\"0\" alt=\"\" /><br /></div>\n";
   }
     $content .="                      </td>\n"
              ."                    </tr>\n"
              ."                  </table>\n"
              ."                </td>\n"
              ."                <td width=\"50%\" valign=\"top\" style=\"border-left: 1px solid #CCCCCC; margin-left: 3px;\">\n"
              ."                  <table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\" summary=\"\">\n"
              ."                    <tr>\n"
              ."                      <td width=\"50%\" height=\"140\">\n"
              ."                        <div align=\"center\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/large/".$weather->day_n_icon.".png\" border=\"0\" alt=\"\" /><br /></div>\n"
              ."                      </td>\n"
              ."                      <td width=\"50%\" height=\"140\" valign=\"middle\">\n"
              ."                        <div class=\"EveningForecastText".$this->getPageClassSuffix()."\">".$weather->day_n_text."<br /><br /></div>\n"


              ."            <table border=\"0\" width=\"100%\" cellspacing=\"0\" summary=\"\">\n"
              ."              <tr class=\"EveningForecastDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"EveningForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_FORECAST_D_RAIN').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"EveningForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_n_precipitation."%</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"EveningForecastDetail_2".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"EveningForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_HUMIDITY').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"EveningForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_n_humidity."%</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."            </table>\n"



              ."                      </td>\n"
              ."                    </tr>\n"
              ."                    <tr>\n"
              ."                      <td width=\"50%\" height=\"140\">\n"
              ."                        <div class=\"EveningForecastWindText".$this->getPageClassSuffix()."\">".$weather->day_n_windtext."<br /><br /></div>\n"

              ."            <table border=\"0\" width=\"100%\" cellspacing=\"0\" summary=\"\">\n"
              ."              <tr class=\"EveningForecastDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"EveningForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_WINDSPEED').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"EveningForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_n_windspeed."&nbsp;".$metric_v."</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"EveningForecastDetail_2".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"EveningForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_WINDDIR').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"EveningForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_n_winddirection."&deg;</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."              <tr class=\"EveningForecastDetail_1".$this->getPageClassSuffix()."\">\n"
              ."                <td>\n"
              ."                  <div class=\"EveningForecastDetailHeader".$this->getPageClassSuffix()."\">".JText::_('EWEATHER_WINDGUST').":</div>\n"
              ."                </td>\n"
              ."                <td>\n"
              ."                  <div class=\"EveningForecastDetailValue".$this->getPageClassSuffix()."\">".$weather->day_n_windgust."&nbsp;".$metric_v."</div>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."            </table>\n"

              ."                      </td>\n"
              ."                      <td width=\"50%\" height=\"140\">\n";
   if (($weather->day_n_windtext != null) && ($weather->day_n_windtext != "N/A"))
   {
     $content .="                        <div align=\"center\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/winddirs/wind_".$weather->day_n_windtext.".gif\" border=\"0\" alt=\"\" /><br /></div>\n";
   }
   else
   {
     $content .="                        <div align=\"center\"><img src=\"".$url."/components/com_eweather/images/".$weatherIconStyle."/winddirs/wind_nodir.gif\" border=\"0\" alt=\"\" /><br /></div>\n";
   }
     $content .="                      </td>\n"
              ."                    </tr>\n"
              ."                  </table>\n"
              ."                </td>\n"
              ."              </tr>\n"
              ."            </table>\n"
              ."            <br />\n"
              ."          </td>\n"
              ."        </tr>\n"
              ."      </table>\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."</table>\n"
              ."<br/><br/>\n";
    echo $content;

  }

  function displayLocationForm(&$lists, $option){
    $url = JUri::base(true);
    $database = &JFactory::getDBO();
	global $my, $Itemid;

	//
	// get the name of the menu associated with $Itemid
	//  (that's the eWeather menu)
	//
	$sql = "SELECT * FROM `#__menu` WHERE `id` = '".$Itemid."'";
    $database->setQuery($sql);
    $menu = $database->loadObject();
    $params = new JParameter($menu->params);
    
    if ($params->get('show_page_title') <> 0)
    {
        echo "<div class=\"componentheading".$this->getPageClassSuffix()."\">".$menu->name."&nbsp;-&nbsp;".JText::_('EWEATHER_SELECT_LOCATION')."</div>\n";
    }

//    if($my->id == 0){
//      $content.= "Sie haben keine Berechtigung!!\n";
//    } else {
      $content = "<form action=\"index.php?option=com_eweather&amp;Itemid=".$Itemid."&amp;task=profiles\" method=\"post\" name=\"locationForm\">\n"
                ."<table width=\"50%\" border=\"0\" cellspacing=\"1\" cellpadding=\"5\" align=\"center\" summary=\"\">\n"
                ."  <tr>\n"
                ."    <td width=\"30%\" style=\"border-bottom: 1px solid #CCCCCC\">\n"
                ."      ".JText::_('EWEATHER_REGION').":\n"
                ."    </td>\n"
                ."    <td style=\"border-bottom: 1px solid #CCCCCC\">\n"
                ."      ".$lists['regions']."\n"
                ."    </td>\n"
                ."  </tr>\n"

                ."  <tr>\n"
                ."    <td width=\"30%\" style=\"border-bottom: 1px solid #CCCCCC\">\n"
                ."      ".JText::_('EWEATHER_COUNTRY').":\n"
                ."    </td>\n"
                ."    <td style=\"border-bottom: 1px solid #CCCCCC\">\n"
                ."      ".$lists['countries']."\n"
                ."    </td>\n"
                ."  </tr>\n"

                ."  <tr>\n"
                ."    <td width=\"30%\" style=\"border-bottom: 1px solid #CCCCCC\">\n"
                ."      ".JText::_('EWEATHER_CITY').":\n"
                ."    </td>\n"
                ."    <td style=\"border-bottom: 1px solid #CCCCCC\">\n"
                ."      ".$lists['cities']."\n"
                ."    </td>\n"
                ."  </tr>\n"
                ."  <tr align\"center\">\n"
                ."    <td colspan=\"1\" align=\"center\">\n"
                ."      <input type=\"SUBMIT\" name=\"save_button\" value=\"".JText::_('EWEATHER_SAVE_BUTTON')."\" class=\"button".$this->getPageClassSuffix()."\" align=\"center\">\n"
                ."    </td>\n"
                ."    <td colspan=\"1\" align=\"center\">\n"
                ."      <input type=\"SUBMIT\" name=\"cancel_button\" value=\"".JText::_('EWEATHER_CANCEL_BUTTON')."\" class=\"button".$this->getPageClassSuffix()."\" align=\"center\">\n"
                ."    </td>\n"
                ."  </tr>\n"
                ."</table>\n"
                ."<input type=\"hidden\" name=\"option\" value=\"".$option."\">\n"
                ."<input type=\"hidden\" name=\"task\" value=\"profiles\">\n"
                ."<input type=\"hidden\" name=\"act\" value=\"\">\n"
                ."</form>\n";
//    }
    echo $content;
  }

  function displayErrorMessage($error_title, $error_descr, $error_msg){
    $url = JUri::base(true);

    $content = "<table width=\"50%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" summary=\"\">\n"
              ."  <tr>\n"
              ."    <td style=\"border-left: 1px solid #000070; border-right: 1px solid #000070;\" align=\"center\" background=\"".$url."/components/com_eweather/images/tbl_error.png\" height=\"22\">\n"
              ."      <div align=\"center\" style=\"color: #FFFFFF; font-weight: bold;\">.::&nbsp;".$error_title."&nbsp;::.</div>\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."  <tr>\n"
              ."    <td style=\"border-left: 1px solid #000070; border-right: 1px solid #000070; border-bottom: 1px solid #000070;\">\n"
              ."      <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"5\" cellpadding=\"5\" summary=\"\">\n"
              ."        <tr>\n"
              ."          <td>\n"
              ."            <div style=\"font-weight: bold;\">".$error_descr.":</div><br />\n"
              ."            <div style=\"text-indent: 0px;\">".$error_msg."</div><br />\n"
              ."          </td>\n"
              ."        </tr>\n"
              ."      </table>\n"
              ."    </td>\n"
              ."  </tr>\n"
              ."</table>\n";

    echo $content;
  }

  function showProvider(&$weather){
/*
 * CSS-based current conditions stuff
 * still work in progress
 *
    $url = JUri::base(true);
	$cont_xx = "";
	
    $cont_xx .="  <div class=\"provider-wrapper\">\n"
              ."    <div class=\"provider\">\n"
              ."      <div>\n"
              ."        <a href=\"http://www.weather.com\" target=\"blank\">\n"
              ."          <img src=\"".$url."/components/com_eweather/images/TWClogo_61px.png\" border=\"0\" alt=\"www.weather.com\" />\n"
			  ."        </a>\n"
              ."      </div>\n"
              .       $this->displayLinks($weather)
              ."    </div>\n"
              ."  </div>\n";
*/

    $url = JUri::base(true);

    $cont_xx = "  <table width=\"98%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n"
              ."    <tr>\n"
              ."      <td align=\"left\" style=\"border-top: 1px solid #cccccc; margin-top: 2px; padding-top: 5px; padding-bottom: 5px; text-align: right;\">\n"
              ."        <div style=\"text-align:left;\"><font class=\"small\"><a href=\"http://www.weather.com\" target=\"blank\">\n"
              ."        <img src=\"".$url."/components/com_eweather/images/TWClogo_61px.png\" border=\"0\" alt=\"www.weather.com\" /></a>\n"
              ."        </font></div>\n"
              ."      </td>\n"
              ."      <td align=\"left\" style=\"border-top: 1px solid #cccccc; margin-top: 2px; padding-top: 5px; padding-bottom: 5px; text-align: right;\">\n"
              .$this->displayLinks($weather)
              ."      </td>\n"
              ."    </tr>\n"
              ."  </table>\n"
              ."  <hr size=\"1\" width=\"98%\"/>\n";
    
    echo $cont_xx;
    
    $this->displayCitySelector();
  }

  function showFooter()
  {
  	$cfg = & WeatherConfiguration::getInstance();
  	
	echo "<p align=\"center\">\n";
	echo "  <font class=\"small\">\n";
    echo "  <a href=\"http://www.robertjlavey.com\" target=\"blank\">eWeather ".$cfg->getVersion()."</a>&nbsp;-\n";
    echo "  &nbsp;&copy; 2006 <a href=\"http://www.mambobaer.de\" target=\"blank\">MamboBaer</a>\n";
    echo "  &nbsp;&copy; 2007 <a href=\"http://www.martdirks.nl\" target=\"blank\">Mart Dirks</a>\n";
    echo "  &nbsp;&copy; 2009 <a href=\"http://www.robertjlavey.com\" target=\"blank\">Bob Lavey</a>\n";
    echo "  </font>\n";
	echo "</p>\n";

  }

}
?>
