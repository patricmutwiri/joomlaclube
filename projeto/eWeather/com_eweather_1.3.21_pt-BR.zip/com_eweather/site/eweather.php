<?php
/**
 * This file contains the routines that display the administrator
 *  screens for the eWeather component.
 *
 * This file is part of eWeather.
 *
 *   eWeather is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   eWeather is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with eWeather.  If not, see <a href="http://www.gnu.org/licenses/">
 *   http://www.gnu.org/licenses/</a>.
 *
 * <b>Modifications:</b><br/>
 * aangepast door Mart Dirks<br/>
 * converted to Joomla! 1.5.x by Bob Lavey
 *
 * @version $Id: eweather.php 315 2009-11-11 20:30:41Z rjlavey $
 * @package eWeather
 * @subpackage eWeather
 * @copyright Copyright (c) 2000 - 2006 MamboBaer.de (Harald Baer),
 *            2009 Bob Lavey<br/>
 * @license http://www.gnu.org/licenses/gpl.txt GNU/GPL
 * @toto General clean up, convert to classes.
 */

/* ensure this file is being called by Joomla! */
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

// load the html drawing class
require_once( JApplicationHelper::getPath('front_html'));

//
// the component's configuration parameters
//
require_once(JPATH_ADMINISTRATOR.DS."components/com_eweather/WeatherConfiguration.php");
$cfg = & WeatherConfiguration::getInstance();

//
// include the appropriate style sheets
//
$css = JURI::base().'components/com_eweather/css/eweather.css';
$css_images = JURI::base().'components/com_eweather/css/eweather.images.'.$cfg->getIconStyle().'.css';
$document =& JFactory::getDocument();
$document->addStyleSheet($css);
$document->addStyleSheet($css_images);


global $Itemid;

switch($task) {
    case "profiles":
		displayLocations($Itemid);
         break;
	
    case "viewWeather":
    default:
	    $weatherLocation = JRequest::getCmd('weatherLocation');
    	viewWeather($weatherLocation);
         break;
}

function displayLocations($myItemid){
  $app = &JFactory::getApplication();
  $database = &JFactory::getDBO();
  global $option;

  $conf_filter_region    = JRequest::getVar( 'filter_region', '', 'post' );
  $conf_filter_countries = JRequest::getVar( 'filter_countries', '', 'post' );
  $conf_filter_cities    = JRequest::getVar( 'filter_cities', '', 'post' );
  $save                  = JRequest::getVar( 'save_button', '', 'post' );
  $cancel                = JRequest::getVar( 'cancel_button', '', 'post' );

  //
  // if cancel button pressed, then return to the main site
  // without saving
  //
  if ($cancel <> "") {
     $app->redirect("index.php?option=$option&Itemid=".$myItemid,"");
     return;
  }

  $user =& JFactory::getUser();
  $userId = $user->get('id');
  
  //
  // if save button pressed, then save and return to the main site
  //
  if ($save <> "") {
      $sql = "SELECT * FROM `#__eweather_locations` WHERE `region` = '".$conf_filter_region."' AND `country` = '".$conf_filter_countries."' AND `city` = '".$conf_filter_cities."'";
      $database->setQuery($sql);
      $myCity = $database -> loadObject();
      if ($userId <> 0)
      {
      	if (count($myCity) <> 0){
          $database->setQuery("SELECT * FROM #__eweather_profiles WHERE `uid` = '".$userId."'");
          $myID = $database->loadObject();
          if (count($myID) <> 0){
             $database->setQuery("UPDATE `#__eweather_profiles` SET `locid` = '".$myCity->loc_id."' WHERE `id` =".$myID->id);
             $result = $database->query();
             $mosmsg = JText::_('EWEATHER_PROFILE_UPDATE');
          } else {
             $database->setQuery("INSERT INTO `#__eweather_profiles` ( `id` , `uid` , `locid` ) VALUES ('', '".$userId."', '".$myCity->loc_id."');");
             $result = $database->query();
             $mosmsg = JText::_('EWEATHER_PROFILE_SAVED');
          }
      	} else {
          $mosmsg = JText::_('EWEATHER_PROFILE_ERROR');
      	}
      }
      else
      {
      	$mosmsg = JText::_('EWEATHER_CITY_SAVED')."<br/>\n";
      	setcookie("defaultWeatherLocation", $myCity->loc_id, time()+60*60*24*30, '/');
      }
      $app->redirect("index.php?option=$option&Itemid=".$myItemid, $mosmsg);
      return;
  }
  
  //
  // check for user profile with default location
  //
  if (($userId <> 0) AND ($conf_filter_region == "") AND ($conf_filter_countries == "") AND ($conf_filter_cities == ""))
  {
     if (($conf_filter_region == "") AND ($conf_filter_countries == "") AND ($conf_filter_cities == "")){
        $sql = "SELECT * FROM `#__eweather_profiles` WHERE `uid` = '".$userId."'";
        $database->setQuery($sql);
        $userProfiles = $database->loadObject();
        if (count($userProfiles) <> 0) {
           $sql = "SELECT * FROM `#__eweather_locations` WHERE `loc_id` = '".$userProfiles->locid."'";
           $database->setQuery($sql);
           $locInfo = $database->loadObject();
           if (count($locInfo) <> 0) {
              $conf_filter_region    = $locInfo->region;
              $conf_filter_countries = $locInfo->country;
              $conf_filter_cities    = $locInfo->city;
           }
        }
     }
  }

  //
  // otherwise, check for a cookie with default location
  //
  if (isset($_COOKIE["defaultWeatherLocation"]) AND ($conf_filter_region == "") AND ($conf_filter_countries == "") AND ($conf_filter_cities == ""))
  {
  	 $sql = "SELECT * FROM `#__eweather_locations` WHERE `loc_id` = '".$_COOKIE["defaultWeatherLocation"]."'";
     $database->setQuery($sql);
     $locInfo = $database->loadObject();
     if (count($locInfo) <> 0) {
        $conf_filter_region    = $locInfo->region;
        $conf_filter_countries = $locInfo->country;
        $conf_filter_cities    = $locInfo->city;
     }
  }
  
  //
  // finally, use the default from the site configuration
  //
  if (($conf_filter_region == "") AND ($conf_filter_countries == "") AND ($conf_filter_cities == ""))
  {
	$cfg = & WeatherConfiguration::getInstance();

	$sql = "SELECT * FROM `#__eweather_locations` WHERE `loc_id` = '".$cfg->getDefaultLocation()."'";
    $database->setQuery($sql);
    $locInfo = $database->loadObject();
    if (count($locInfo) <> 0)
    {
		$conf_filter_region    = $locInfo->region;
        $conf_filter_countries = $locInfo->country;
        $conf_filter_cities    = $locInfo->city;
     }
  }

  //
  // create a list of all regions
  //
  $sql = "SELECT * FROM `#__eweather_locations` GROUP BY `region` ORDER BY `region` ASC";
  $database->setQuery($sql);
  $regions = $database -> loadObjectList();

  if (count($regions) <> 0)
  {
	foreach ($regions as $region)
	{
		$tempregion[] = JHTML::_('select.option', $region->region , $region->region, 'value', 'text' );
	}
  }
  else
  {
	$tempregion[]="";
  }
  $lists['regions'] = JHTML::_('select.genericlist', $tempregion, 'filter_region', 'class="inputbox" size="1" onchange="document.locationForm.submit( );"', 'value', 'text', $conf_filter_region);

  //
  // create a list of all the countries in the selected region
  //  (default to the first region in the list)
  //
  if ($conf_filter_region == "")
  {
	$conf_filter_region = $regions[0]->region;
  }
  $sql = "SELECT * FROM `#__eweather_locations` WHERE `region` = '".$conf_filter_region."' GROUP BY `country` ORDER BY `country` ASC";
  $database->setQuery($sql);
  $countries = $database->loadObjectList();

  if (count($countries) <> 0)
  {
	foreach ($countries as $country)
	{
		$tempcountry[] = JHTML::_('select.option', $country->country , $country->country, 'value', 'text' );
	}
  }
  else
  {
	$tempcountry[]="";
  }
  $lists['countries'] = JHTML::_('select.genericlist', $tempcountry, 'filter_countries', 'class="inputbox" size="1" onchange="document.locationForm.submit( );"', 'value', 'text', $conf_filter_countries);

  //
  // default the current country to the first country in the country list
  //
  if ($conf_filter_countries == "")
  {
	$conf_filter_countries = $countries[0]->country;
  }
  //
  // if the current country doesn't exist in the region,
  //  reset it to the first country in the country list
  //
  else
  {
  	$sql = "SELECT * FROM `#__eweather_locations` WHERE `region` = '".$conf_filter_region."' AND `country` = '".$conf_filter_countries."'";
	$database->setQuery($sql);
	$testcountries = $database->loadObjectList();
	if (count($testcountries) == 0)
	{
		$conf_filter_countries = $countries[0]->country;
	}
  }

  //
  // create a list of cities in the current country
  //
  $sql = "SELECT * FROM `#__eweather_locations` WHERE `region` = '".$conf_filter_region."' AND `country` = '".$conf_filter_countries."' ORDER BY `city` ASC";
  $database->setQuery($sql);
  $cities = $database->loadObjectList();

  if (count($cities) <> 0)
  {
	foreach ($cities as $city)
	{
		$tempcity[] = JHTML::_('select.option', $city->city , $city->city, 'value', 'text' );
	}
  }
  else
  {
	$tempcity[]="";
  }
  $lists['cities'] = JHTML::_('select.genericlist', $tempcity, 'filter_cities', 'class="inputbox" size="1" onchange="document.locationForm.submit( );"', 'value', 'text', $conf_filter_cities);

  //
  // default the current city to the first city in the city list
  //
  if ($conf_filter_cities == "")
  {
  	$conf_filter_cities = $cities[0]->city;
  }

  //
  // if the current city doesn't exist in the country,
  //  reset it to the first city in the city list
  //
  else
  {
	$sql = "SELECT * FROM `#__eweather_locations` WHERE `region` = '".$conf_filter_region."' AND `country` = '".$conf_filter_countries."' AND `city` = '".$conf_filter_cities."'";
	$database->setQuery($sql);
	$testcities = $database->loadObjectList();
	if (count($testcities) == 0)
	{
		$conf_filter_cities = $cities[0]->city;
	}
  }

  //
  // find the location ID for the current city
  //
  $sql = "SELECT * FROM `#__eweather_locations` WHERE `region` = '".$conf_filter_region."' AND `country` = '".$conf_filter_countries."' AND `city` = '".$conf_filter_cities."'";
  $database->setQuery($sql);
  $defaultcities = $database->loadObjectList();
  if (count($defaultcities) <> 0)
  {
  	$tempLocID = $defaultcities[0]->loc_id;
  }
  else
  {
  	$tempLocID = "";
  }
  $lists['locationID'] = $tempLocID;
  
  $weatherHtml = new HTML_weather();
  $weatherHtml->displayLocationForm($lists, $option);
}

function viewWeather($weatherLocation)
{
  $database = &JFactory::getDBO();
  global $Itemid;

  $weatherHtml = new HTML_weather();
  $cfg = & WeatherConfiguration::getInstance();
  
  if ($cfg->getPartnerID() == "") {
     $weatherHtml->displayHeader();
     $weatherHtml->displayErrorMessage(JText::_('EWEATHER_ERROR_TITLE'), JText::_('EWEATHER_ERROR_DESCR'), JText::_('EWEATHER_ERROR_NOPARTNERID'));
     return;
  }

  if ($cfg->getPartnerKey() == "") {
     $weatherHtml->displayHeader();
     $weatherHtml->displayErrorMessage(JText::_('EWEATHER_ERROR_TITLE'), JText::_('EWEATHER_ERROR_DESCR'), JText::_('EWEATHER_ERROR_NOPASSWORD'));
     return;
  }

  include_once(JPATH_COMPONENT.DS."eweather.main.php");

  $weatherClass = parseWeather($weatherLocation);

  	if ($weatherClass->e_error != '')
  	{
     	$weatherHtml->displayErrorMessage(JText::_('EWEATHER_ERROR_TITLE'), JText::_('EWEATHER_ERROR_DESCR'), $weatherClass->e_error);
  	}
  	else
  	{
     	$weatherHtml->displayHeader();
    	if ($cfg->getHeaderPosition() == "0")
    	{
     		$weatherHtml->showProvider($weatherClass);
    	}

	   	if ($cfg->getShowCurrentConditions() == "1")
	   	{
    		$weatherHtml->displayWeather($weatherClass, $cfg->getIconStyle());
	   	}

     	if (isset($_REQUEST["detailedForecast"]))
     	{
         	$detailedForecast = JRequest::getVar( 'detailedForecast' , '' );
         	$weatherHtml->displayDetailForecast($weatherClass->dayf_forecasts[$detailedForecast], $weatherClass->loc_city, $weatherClass->loc_code, $cfg->getIconStyle(), $weatherClass->dayf_lastupdate, $weatherClass->h_speed, $weatherClass->h_temp, $cfg->getDateFormatDetail());
       	}
	   	elseif ($cfg->getShowForecast() == "1")
	   	{
         	$weatherHtml->displayForecast($weatherClass, $cfg->GetForecastDays(), $cfg->getForecastDaysPerRow());
        }
        
    	if ($cfg->getHeaderPosition() == "1")
    	{
     		$weatherHtml->showProvider($weatherClass);
    	}
        if ($cfg->getShowFooter() == "1")
    	{
    		$weatherHtml->showFooter();
    	}
    }
}

?>
