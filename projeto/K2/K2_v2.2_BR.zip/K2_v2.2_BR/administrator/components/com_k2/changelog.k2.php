<?php
/**
 * @version		$Id: changelog.k2.php 318 2010-01-15 02:18:54Z joomlaworks $
 * @package		K2
 * @author    JoomlaWorks http://www.joomlaworks.gr
 * @copyright	Copyright (c) 2006 - 2010 JoomlaWorks Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

?>

1. Copyright and disclaimer
---------------------------
This application is opensource software released under the GPL. Please see source code for more.


2. Changelog
------------
This is a non-exhaustive (but still near complete) changelog for K2, including beta and release candidate versions. Our thanks to all those people who've contributed bug reports and code fixes.

-------------------- 2.2 Stable Release [XX-January-2010] ------------------
Pending update...
