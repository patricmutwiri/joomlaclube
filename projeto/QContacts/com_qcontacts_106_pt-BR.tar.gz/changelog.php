<?php
/*
1.0.0 26 April 2008 
- QContacts released!

1.0.1 1 May 2008
- Added file install.nonutf8.sql for installation on non utf8 databases

1.0.2 30 May 2008
- fix: address icon sometimes shown on contact page when no address fields 
were set to visible.
- fix: Use Global setting not working on some configuration parameters for 
contacts imported from com_contact.
- fix: page title not shown on contact page even when Show Page Title was 
set to Yes in Category Layout menu.
- fix: drop down list not shown on contact page even when Drop Down was
set to Show on Standard Contact Layout menu.

1.0.3 28 July 2008
- new: added many new configuration parameters to control captcha 
appearance: code lenght, image width and height, foreground and background 
color, font, vertical and arc lines on/off.
- new: more field types allowed for custom fields: checkbox, radio buttons,
 drop down list.
- new: added a Field Order parameter to control the position of custom and 
standard fields on the form.
- new: an asterisk (or another symbol) can optionally be displayed near 
required fields. In addition required fields style can be controlled with 
css (label.required selector).
- new: all contact fields (name, position, e-mail, phone, mobile, fax, 
street, city, state, postcode, country) can be displayed in Category Layout 
lists. Each column width and order can be set via configuration parameters.
- new: Contacts per Page parameter added to Contact Category Layout menu to 
control the maximum number of records per page on the list.

1.0.4 25 October 2008

- fix: corrected XHTML validation error in adminForm action url on category 
layout pages.
- fix: corrected wrong numbering of class sectiontableentry (odd/even rows) 
in Contact Category Layout.
- new: Name, E-mail and Message fields are no longer mandatorily required and 
can be set as optional or hidden exactly as custom fields.
- new: added a global configuration parameter to send form results from admin 
e-mail set in Global configuration > Server > Mail settings in place of e-mail 
submitted with the form.
- new: added a global configuration parameter to set a custom path for the 
folder containing contacts images.
- new: added a global configuration parameter to include an additional field 
with submitter IP address in e-mail containing form results.
- new: A Default Ordering parameter is available when creating a Contact 
Category Layout menu item to set the default ordering field for the list of 
contacts.

1.0.5 22 December 2008

- fix: Column width settings in Contact Category Layout not working when 
Table Headings parameter set to Hide.
- fix: alternate background colors for contact lists rows should now work.
- fix: wrong page title even when set in Parameters(System) of a Contact 
Category Layout or Standard Contact Layout menu item.
- fix: category title always appended to page title even if a custom page 
title was set in menu parameters.
- fix: column sorting not preserved when changing page in contact lists. 
- new: Contact category, Skype and Yahoo messenger ID can now be displayed 
in contact lists columns (Contact Category Layout) not only in contact 
details page (Standard Contact Layout).
- new: added a new parameter to Contact Category Layout menu item 
parameters to make each column sortable.
- new: changed how sorting of contact lists works: a click on a column 
heading no longer automatically reverses the sort order. A click on the 
sort icon switches between ascending and descending sort order.

1.0.6 3 July 2009

- fix: images folder moved to frontend.
- fix: once required field marker in Global configuration is saved as empty 
(= no marker) doesn't revert back to asterisk.
- new: added Standard Contact Section Layout menu item
- new: added After Form Submission parameter to global and contact 
configuration. 
* */
?>