====================================================================================================
WHAT ARE PREMIUM PLUGINS?
====================================================================================================

There are two plugins exclusively available for donators which have donated 
at least 10 EUR or 20 US$.

Public Frontend plugin (uddeIM 1.6+)

    Enables Public Frontend functionality in uddeIM. With enabling the Public Frontend
    unregistered users can send registered users PMs.

RSS Feed plugin (uddeIM 1.6+)

    This plugin publishes your inbox using a RSS feed. So you can display PMs in
    your favourite RSS reader or on your personalized iGoogle page.

Message Control Center (uddeIM 1.7+)

    When enabled users can report annoying messages to the admin. The admin can check
    these messages in the backend and take appropriate actions.

All plugins can be downloaded from my support web site: 
    http://www.slabihoud.de/software/

When you are interested in these plugins, please make a donation using the donate 
buttons in uddeIM or on my support site. Ensure that your email address is submitted 
by PayPal, so I can send you your personal username/password. With these user 
credentials you are able to download the files from my webpage.

I decided to make some feature "premium" since there are currently 100.000 downloads
but only a dozens of donators (incl. translators). So these plugins are a 
"Thank you" for their donations and help. The donations help to pay the webtraffic
even when they do only cover less then 10% of the costs currently. 

====================================================================================================
How to install uddeIM plugins
====================================================================================================

Extract the downloaded archive and copy the files

    /components/com_uddeim/rss.php
    /components/com_uddeim/pfrontend.php
    /administrator/components/com_uddeim/admin.spamcontrol.php

into

    /components/com_uddeim/
    /administrator/components/com_uddeim/

	
When you enter uddeIM backend you should see

    - a new tab "Public" and
    - under tab "System" the option "Enable RSS".
    - a new toolbar icon "Report Control"


====================================================================================================
How to install iGoogle gadget
====================================================================================================

Although you can use any RSS reader to display uddeIM message feeds (RSS 0.91) it is
very useful to display feeds on the iGoogle startpage.

You can use for this purpose any iGoogle RSS gadget or the enclosed one which is
installed with uddeIM. A link to install the gadget in iGoogle can be found in the user
preferences. Nevertheless the user has to setup the feed in order to receive his PMs.


Since the iGoogle API caches JSON data for about one hour this might be inacceptable 
for message feeds, so I implemented the gadget using plain XML for the data 
transfer which reduces the cache time to 30 seconds. Please give feedback if this 
works for you.


IMPORTANT:
-------------------------------------------------------------------------------------
PLEASE REFER TO THE FAQ HOW TO CONFIGURE THE GADGET FOR YOUR USERS!
DO NOT USE THE GADGET WITHOUT CONFIGURING IT FOR YOUR SITE!
