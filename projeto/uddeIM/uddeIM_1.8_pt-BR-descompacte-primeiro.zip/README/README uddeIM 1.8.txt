====================================================================================================
HOW TO INSTALL / UPDATE - read below for update instructions
====================================================================================================
Joomla 1.5 users please read "ADDITIONAL JOOMLA 1.5 NOTES" before installing uddeIM.
====================================================================================================

CONTENT

 * HOW TO UPGRADE TO UDDEIM 1.8 FROM UDDEIM 1.5 - 1.7
   - How to upgrade
   - Optional steps

 * HOW TO UPGRADE TO UDDEIM 1.8 FROM UDDEIM 1.4 OR EARLIER

 * FIRST INSTALL OF UDDEIM
   - Installation
   - Optional steps

 * ADDITIONAL JOOMLA 1.5 NOTES
 * NOTES FOR DONATORS
 * APPENDIX A - Folder structure


====================================================================================================
HOW TO UPGRADE TO UDDEIM 1.8 FROM UDDEIM 1.5 - 1.7
====================================================================================================

How to upgrade:
---------------

 1. a) Backup your uddeIM template (if you do not use uddeIM's default templates)

    b) Backup your database (at least all tables prefixed "uddeim", when using phpMyAdmin you can 
       copy the tables given the copy a new name, e.g. jos_uddeim_backup).


 2. Backup your configuration using the internal backup function and/or backup the config file:

        /administrator/components/com_uddeim/config.class.php

    I recommend to uninstall the previous version of uddeIM and then upgrade to the new version
    using the component installer, so you might need this file to restore your settings.

    When you are an experienced user you can also overwrite the existing files with the new
    files from the archive. Please check Appendix A for the correct folder structure
    (please check if there are new files which have to be uploaded).
	

 3. After upgrading uddeIM, update your database tables (go to phpMyAdmin and enter following 
    SQL statements in the SQL box, this will create the missing fields).

    You will find a small tutorial in the FAQ (chapter 1.3.x "How can I upgrade uddeIM�s tables?").


    When you upgrade 1.7 to 1.8:
    ============================
        Nothing to do


    When you upgrade 1.6 to 1.8:
    ============================

        CREATE TABLE IF NOT EXISTS `jos_uddeim_spam` (
           `id` int(10) unsigned NOT NULL auto_increment,
           `mid` int(11) NOT NULL default '0',
           `datum` int(11) default NULL,
           `reported` int(11) default NULL,
           `fromid` int(1) NOT NULL default '0',
           `toid` int(1) NOT NULL default '0',
           `message` TEXT NOT NULL,
           PRIMARY KEY  (`id`),
           KEY `mid` (`mid`),
           KEY `fromid` (`fromid`),
           KEY `toid` (`toid`)
        ) ENGINE=MyISAM;
        ALTER TABLE `jos_uddeim_emn` ADD `locked` INT( 1 ) DEFAULT '0' NOT NULL ;

 
    When you upgrade 1.5 to 1.8:
    ============================

        CREATE TABLE IF NOT EXISTS `jos_uddeim_spam` (
           `id` int(10) unsigned NOT NULL auto_increment,
           `mid` int(11) NOT NULL default '0',
           `datum` int(11) default NULL,
           `reported` int(11) default NULL,
           `fromid` int(1) NOT NULL default '0',
           `toid` int(1) NOT NULL default '0',
           `message` TEXT NOT NULL,
           PRIMARY KEY  (`id`),
           KEY `mid` (`mid`),
           KEY `fromid` (`fromid`),
           KEY `toid` (`toid`)
        ) ENGINE=MyISAM;
        ALTER TABLE `jos_uddeim_emn` ADD `locked` INT( 1 ) DEFAULT '0' NOT NULL ;
        ALTER TABLE `jos_uddeim_userlists` ADD `global` INT( 1 ) NOT NULL DEFAULT '0';
        ALTER TABLE `jos_uddeim_userlists` ADD INDEX ( `global` ) ;


 4. Restore your uddeIM template (from step 1, when you do not use uddeIM's default templates).

    ATTENTION:

    There might be new icons (depending on the version of uddeIM you are updating from):
        \components\com_uddeim\templates\default\images\envelope.gif
        \components\com_uddeim\templates\default\images\envelope_deleted.gif
        \components\com_uddeim\templates\default\images\staron.gif
        \components\com_uddeim\templates\default\images\staroff.gif
        \components\com_uddeim\templates\default\images\icon_spam.gif
        \components\com_uddeim\templates\images\rss_logo.png
    When updating manually don't forget to upload these files!


 5. Restore your configuration. When you have used the internal backup feature its just one click,
    otherwiese restore config.class.php from step 2. After doing that it is important that you 
    review the new added settings and save the new configuration!


 6. Check Community Builder settings (it is not required to use CB with uddeIM but it is
    highly recommended for a community platform). There are uddeIM settings for the 
    "cblogin" module and "mypms" plugin of the Community Builder. When possible choose
    "uddeIM 1.8" otherwise the next lower version e.g. "uddeIM 1.3". It is recommended 
    to install the uddeIM specific modules (see the important note below).

 7. Check the menu link to uddeIM. Usually you have to update the link (Joomla 1.5) or you
    have to re-create the link (Joomla 1.0) so the Itemid to uddeIM is valid.


    IMPORTANT:
    
    a) plug_pms_uddeim

       A plugin for the Community Builder that allows to send a "Quick message" from a 
       user's profile. Install this with the plugin installer in CB. You have also to publish
       and configure a tab in CB. "plug_pms_uddeim" is the uddeIM-only version of 
       "plug_pms_mypmspro" (delivered with CB) and supports several additional features 
       of uddeIM.

       Note: Unpublish "plug_pms_mypmspro" (delivered with CB) when you use this plugin!

    b) plug_pms_uddeim_inbox

       A plugin for the Community Builder that shows the content of the inbox in a profile 
       tab. Install this with the plugin installer in CB and you have also to publish and 
       configure a tab in CB.


    c) mod_uddeim

       A message notifier module. Install this module with the module installer. The module 
       provides popup notifications introduced with uddeIM 0.8.

       When you do not want to have any output, switch of the module title and select 
       "No output" in the module configuration (so it will only do the notifications for you).

    d) mod_uddeim_mailbox

       A mailbox module for uddeIM. Install this module with the module installer. The module 
       shows some statistics and links to the inbox, outbox, trashcan, archive, settings and 
       compose form.

       Note: Use this module on small sites only. It creates some cpu load on your database
             server because of some additional queries performed on each page view.


 Optional: When you want to use message obfuscating check the "key" which can be set in uddeIM
           administration. Default is "uddeIMcryptkey" but it can be changed to whatever you 
           like. This "key" is used to obfuscate all new messages.
           You cannot change this value later. You have to set it before the first new message 
           has been written and obfuscating of messages is enabled in the preferences.



====================================================================================================
HOW TO UPGRADE TO UDDEIM 1.8 FROM UDDEIM 1.4 OR EARLIER
====================================================================================================

Upgrades from uddeIM 1.4 and below are not longer supported.
Please upgrade to uddeIM 1.7 first before upgrading to uddeIM 1.8.



====================================================================================================
FIRST INSTALL OF UDDEIM
====================================================================================================

Installation:
-------------

 1. Use the Joomla installer to install this component.


 2. Check the configuration in the backend before starting to use uddeIM.
    Configuration setting printed in red are not available since a component is not
    installed on your system (e.g. Community Builder).
	

 3. Check Community Builder settings (it is not required to use CB with uddeIM but it is
    highly recommended for a community platform). There are uddeIM settings for the 
    "cblogin" module and "mypms" plugin of the Community Builder. When possible choose
    "uddeIM 1.8" otherwise the next lower version e.g. "uddeIM 1.3". It is recommended 
    to install the uddeIM specific modules (see the important note below).


 4. Create a menu link to uddeIM. This is important because uddeIM requires a unique Itemid.
    When you want to use the public front end feature set public access for the menu link 
	otherwise set registered access.


    IMPORTANT:
    
    a) plug_pms_uddeim

       A plugin for the Community Builder that allows to send a "Quick message" from a 
       user's profile. Install this with the plugin installer in CB. You have also to publish
       and configure a tab in CB. "plug_pms_uddeim" is the uddeIM-only version of 
       "plug_pms_mypmspro" (delivered with CB) and supports several additional features 
       of uddeIM.

       Note: Unpublish "plug_pms_mypmspro" (delivered with CB) when you use this plugin!

    b) plug_pms_uddeim_inbox

       A plugin for the Community Builder that shows the content of the inbox in a profile 
       tab. Install this with the plugin installer in CB and you have also to publish and 
       configure a tab in CB.

    c) mod_uddeim

       A message notifier module. Install this module with the module installer. The module 
       provides popup notifications introduced with uddeIM 0.8.

       When you do not want to have any output, switch of the module title and select 
       "No output" in the module configuration (so it will only do the notifications for you).

    d) mod_uddeim_mailbox

       A mailbox module for uddeIM. Install this module with the module installer. The module 
       shows some statistics and links to the inbox, outbox, trashcan, archive, settings and 
       compose form.

       Note: Use this module on small sites only. It creates some cpu load on your database
             server because of some additional queries performed on each page view.


 Optional: When you want to use message obfuscating check the "key" which can be set in uddeIM
           administration. Default is "uddeIMcryptkey" but it can be changed to whatever you 
           like. This "key" is used to obfuscate all new messages.
           You cannot change this value later. You have to set it before the first new message 
           has been written and obfuscating of messages is enabled in the preferences.



====================================================================================================
ADDITIONAL JOOMLA 1.5 NOTES
====================================================================================================

 1. uddeIM is compatible to Joomla 1.5 in native and legacy mode (i.e. it does not matter if the
    "System - Legacy" plugin in enabled or not).

 2. First alternative (without ftp mode enabled):
    When your .php files are running under different owner rights (e.g. "wwwrun" and "userid")
    make sure that you do not have ftp mode enabled in global configuration when you install 
    uddeIM. uddeIM creates a new configuration file during installation. With ftp mode 
    enabled the existing file will be owned by "userid" and the new created file is owned by 
    "wwwrun". So you will get an error message that the configuration file could not be written.
	
    Second alternative (with ftp mode enabled):
    When you install uddeIM with ftp mode enabled you may get an warning that the configuration
    file config.class.php is not writeable. Ignore this warning and after the installation has
    finished use your ftp client to chmod this file, so it is writeable for your web server
    (when you are unsure about the correct access right, try 0777 for a first start).



====================================================================================================
NOTES FOR DONATORS
====================================================================================================

When upgrading uddeIM you have to reinstall the premium plugins. If you forget how to do that, 
check the FAQ or the README provided with the premium plugin package. 

You don't have to install the premium plugins again:
- if you install a "hotfix" for uddeIM
- you are an experienced user and overwrite the existing files with the new files from the archive 
  when upgrading (like 1.7 to 1.8).



====================================================================================================
APPENDIX A - Folder structure
====================================================================================================

In /components/com_uddeim/

	uddeim.php
	inbox.php
	outbox.php
	archive.php
	trashcan.php
	userlists.php
	includes.php
	includes.db.php
	blocking.php
	bbparser.php
	crypt.class.php
	getpiclink.php
	cb_extra.php
	json.php
	index.html
	pfrontend.php (optional)
	rss.php (optional)
        uddeim_igoogle.xml
	captcha.php
	captcha15.php
	uddeimlib10.php
	uddeimlib15.php
	uddeim.xml
	monofont.ttf
	js/*
	templates/*


In /administrator/components/com_uddeim/

	admin.uddeim.php
	admin.shared.php
	admin.includes.php
	admin.usersettings.php
	admin.uddeimlib10.php
	admin.uddeimlib15.php
	admin.spamcontrol.php (optional)
	toolbar.uddeim.php
	install.uddeim.php
	uninstall.uddeim.php
	config.class.php
	uddeim.xml (Joomla 1.0)
	uddeim.j15.xml (Joomla 1.5)
	index.html
	language/*
	language.utf8/*




