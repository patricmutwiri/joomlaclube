<?php
/**
* @version $Id: custom.functions.php 4987 2009-04-03 11:05:29Z Radek Suski $
* @package: Sigsiu Online Business Index 2
* ===================================================
* @author
* Name: Sigrid & Radek Suski, Sigsiu.NET
* Email: sobi@sigsiu.net
* Url: http://www.sigsiu.net
* ===================================================
* @copyright Copyright (C) 2006 - 2009 Sigsiu.NET (http://www.sigsiu.net). All rights reserved.
* @license see http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL.
* You can use, redistribute this file and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation.
*/
/*
 *  no direct access
 */
defined( '_SOBI2_' ) || defined( '_VALID_MOS' )  || ( trigger_error("Restricted access", E_USER_ERROR) && exit() );
?>