<?php
/**
 * @ version	$Id: AlphaToolbar.php 2009-05-05  v1.0.7$
 * @ package	AlphaToolbar
 * @ Copyright (C) 2008 by Bernard Gilly. All rights reserved.
 * @ license	GNU/GPL
 * @ Website    http://www.alphaplug.com
 * @
 * @ infos      Code for social-bookmark is a part of original module mod_social_bookmark for Joomla 1.0.x
 * @ Copyright (C) 2006-2008 by Alexander Hadj Hassine - All rights reserved
 * @ Website    http://www.social-bookmark-script.de/
 */

// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

class plgContentalphatoolbar extends JPlugin {

	function plgContentalphatoolbar( &$subject, $params )
	{
		parent::__construct( $subject, $params );
	}

	function onPrepareContent( &$article, &$params, $limitstart )
	{
		global $mainframe;		

		$document	= & JFactory::getDocument();
		$lang       = $document->getLanguage();
		$lang   	= substr($lang, 0, 2);
		$view		= JRequest::getCmd('view');
		$print		= JRequest::getVar('print');
		
		if ( $view != 'article' ) return;
	
		// Load language
		JPlugin::loadLanguage( 'plg_alphatoolbar', JPATH_ADMINISTRATOR );
		
		// Get plugin info
		$plugin =& JPluginHelper::getPlugin('content', 'alphatoolbar');
		$pluginParams = new JParameter( $plugin->params );
		
		if  ( !$pluginParams->get( 'atb_show_on_printpage',  0 ) && $print )  return;
		
		$excludeSectionID    = $pluginParams->get( 'excludeSectionID',  '' );		
		$excludeCategoryID   = $pluginParams->get( 'excludeCategoryID', '' );
		$excludeID           = $pluginParams->get( 'excludeID',         '' );		
		$listexcludeSection  = @explode ( ",",  $excludeSectionID );	
		$listexcludeCategory = @explode ( ",", $excludeCategoryID );	
		$listexclude 		 = @explode ( ",",         $excludeID );		
		
		$atb_show_icons_resize_text = $pluginParams->def( 'atb_show_icons_resize_text', 1 );
		$atb_show_icon_hits			= $pluginParams->def( 'atb_show_icon_hits',         1 );
		$atb_show_go_top_link 		= $pluginParams->def( 'atb_show_go_top_link',       1 );
		$atb_include_pdf      		= $pluginParams->def( 'atb_include_pdf',            1 );
		$atb_include_print    		= $pluginParams->def( 'atb_include_print',          1 );
		$atb_include_mail     		= $pluginParams->def( 'atb_include_mail',           1 );
		$atb_include_tags     		= $pluginParams->def( 'atb_include_tags',           1 );
		$atb_include_vozMe     		= $pluginParams->def( 'atb_include_vozMe',          1 );
		$atb_position     			= $pluginParams->def( 'atb_position',               1 );
		
		if ( $params->get( 'intro_only' ) || in_array ( $article->id, $listexclude ) || in_array ( $article->sectionid, $listexcludeSection ) || in_array ( $article->catid, $listexcludeCategory ) ) return;
		
		/* prepare content toc */
		$contenttoc  = "";		
		if ( isset($article->toc) ) {			
			$article->toc = str_replace('class="toclink"','class="sublevel-toolbar-article-horizontal"',$article->toc);			
			if ( preg_match('#<th>(.*)</th>#Uis', $article->toc, $m) ) {
				$contenttoc = "<li><a href=\"#\" class=\"mainlevel-toolbar-article-horizontal\"><span class=\"expanded\"><img src=\"plugins/content/alphatoolbar/images/icon-indexpage.gif\" alt=\"\" border=\"0\" />" . $m[1] . "</span></a>";
			}
			if ( preg_match_all('#<a href=(.*)</a>#Uis', $article->toc, $m) ) {						
				$contenttoc .= "<ul id=\"menulist_1-toolbar-article-horizontal\">\n";
				for ($i=0, $n=count($m[0]); $i < $n; $i++) {			
					$contenttoc .= "<li>" . $m[0][$i] . "</li>";					
				}
				$contenttoc .= "</ul>\n</li>\n";
			}			
			$article->toc = "";
		}
		
		// Add style sheet
		$document->addStyleSheet(JURI::base(true).'/plugins/content/alphatoolbar/css/toolbararticlemenu.css');		
		$document->addStyleSheet(JURI::base(true).'/plugins/content/alphatoolbar/css/small.css', 'text/css', 'screen', array( 'title' => 'small text' ));
		$document->addStyleSheet(JURI::base(true).'/plugins/content/alphatoolbar/css/medium.css', 'text/css', 'screen', array( 'title' => 'medium text' ));
		$document->addStyleSheet(JURI::base(true).'/plugins/content/alphatoolbar/css/large.css', 'text/css', 'screen', array( 'title' => 'large text' ));
		
		// Add Javascript
		$document->addScript(JURI::base(true).'/plugins/content/alphatoolbar/js/menu.js');
		$document->addScript(JURI::base(true).'/plugins/content/alphatoolbar/js/switcher.js');	
		
		$document->addScriptDeclaration("window.addEvent('domready', function(){ var JTooltips = new Tips($$('.hasTip'), { maxTitleChars: 50, fixed: false}); });");
		
		$hear = "";
		if( $atb_include_vozMe ) {
			$hear = "<li><script type=\"text/javascript\" src=\"http://vozme.com/get_text.js\"></script><a href=\"javascript:void(0);\" onclick=\"get_id('toolbar-articlebody','".$lang."','fm');\" class=\"mainlevel-toolbar-article-horizontal\" rel=\"nofollow\"><img src=\"plugins/content/alphatoolbar/images/icon-hear.gif\" alt=\"\" border=\"0\" />" . JTEXT::_('ATB_HEAR_THIS_TEXT') . "</a></li>";
		}
		
		$pdf = "";
		if( $params->get('show_pdf_icon') && $atb_include_pdf ) {
			$url  = "index.php?view=article";
			$url .=  @$article->catslug ? "&amp;catid=".$article->catslug : "";
			$url .= "&amp;id=" . $article->slug . "&amp;format=pdf&amp;option=com_content";		
			$status = 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no';		
			$linkpdf = JRoute::_($url);		
			$pdf = "<li><a href=\"" . $linkpdf . "\" onclick=\"window.open(this.href,'win2','".$status."'); return false;\" class=\"mainlevel-toolbar-article-horizontal\" rel=\"nofollow\" ><img src=\"plugins/content/alphatoolbar/images/icon-pdf.gif\" alt=\"\" border=\"0\" />" . JTEXT::_('ATB_EXPORTPDF') . "</a></li>";
			$params->set('show_pdf_icon', 0);
		}
		
		$print = "";
		if( $params->get('show_print_icon') && $atb_include_print ) {
			$url  = "index.php?view=article";
			$url .=  @$article->catslug ? "&amp;catid=".$article->catslug : "";
			$url .= "&amp;id=" . $article->slug . "&tmpl=component&print=1&option=com_content";		
			$status = 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no';		
			$linkprint = JRoute::_($url);		
			$print = "<li><a href=\"" . $linkprint . "\" onclick=\"window.open(this.href,'win2','".$status."'); return false;\" class=\"mainlevel-toolbar-article-horizontal\" rel=\"nofollow\" ><img src=\"plugins/content/alphatoolbar/images/icon-print.gif\" alt=\"\" border=\"0\" />" . JTEXT::_('ATB_PRINT') . "</a></li>";
			$params->set('show_print_icon', 0);
		}
		
		$email = "";		
		if( $params->get('show_email_icon') && $atb_include_mail ) {
			$uri     =& JURI::getInstance();
			$base  = $uri->toString( array('scheme', 'host', 'port'));
			$link    = $base.JRoute::_( "index.php?view=article&id=" . $article->slug, false );
			$url	= 'index.php?option=com_mailto&tmpl=component&link=' . base64_encode( $link );		
			$status = 'width=400,height=300,menubar=yes,resizable=yes';		
			$linkemail = JRoute::_($url);		
			$email = "<li><a href=\"" . $linkemail . "\" onclick=\"window.open(this.href,'win2','".$status."'); return false;\" class=\"mainlevel-toolbar-article-horizontal\" rel=\"nofollow\" ><img src=\"plugins/content/alphatoolbar/images/icon-email.gif\" alt=\"\" border=\"0\" />" . JTEXT::_('ATB_EMAIL') . "</a></li>";
			$params->set('show_email_icon', 0);
		}
		
		$tags = "";			
		if( $atb_include_tags && $article->metakey ) {		
			$keywords = array();
			$keywords = explode( "," , trim($article->metakey) );	
			$tags .= "<li><a href=\"#\" class=\"mainlevel-toolbar-article-horizontal\"><span class=\"expanded\"><img src=\"plugins/content/alphatoolbar/images/icon-tags.gif\" alt=\"\" border=\"0\" />" . JTEXT::_('ATB_TAGS') . "</span></a>";
			$tags .= "<ul id=\"menulist_2-toolbar-article-horizontal\">";
			for ($a=0, $b=count($keywords); $a < $b; $a++) {
				$metakey = trim($keywords[$a]);				
				$tags .= "<li><a href=\"" . JRoute::_("index.php?option=com_search&searchword=$metakey&submit=Search&searchphrase=any&ordering=newest") . "\" class=\"sublevel-toolbar-article-horizontal\">" . $metakey . "</a></li>";
			}
			$tags .="</ul>\n</li>\n";
		}
		
		// Build SocialBookmark list
		$social_links = $this->buildSocialBookmarkList( $pluginParams );
		
		// Prepare Icons Set for resize text
		if ( $atb_show_icons_resize_text && $atb_show_icon_hits) {			
			$seticonsresizetext = "<table border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"5\">
			  <tr><td><span class=\"editlinktip hasTip\" title=\"" .  JTEXT::_('Hits')  . "::" . $article->hits . "\"><img src=\"plugins/content/alphatoolbar/images/icon-chart.gif\" alt=\"Hits\" border=\"0\" /></span></td><td>
			<a href=\"#\" onkeypress=\"setActiveStyleSheet('small text', 1); return false;\" onclick=\"setActiveStyleSheet('small text', 1); return false;\"><img src=\"plugins/content/alphatoolbar/images/icon-small.gif\" alt=\"smaller text tool icon\" border=\"0\" /></a></td><td><a href=\"#\" onkeypress=\"setActiveStyleSheet('medium text', 1);return false;\" onclick=\"setActiveStyleSheet('medium text', 1);return false;\"><img src=\"plugins/content/alphatoolbar/images/icon-medium.gif\" alt=\"medium text tool icon\" border=\"0\" /></a></td><td><a href=\"#\" onkeypress=\"setActiveStyleSheet('large text', 1);return false;\" onclick=\"setActiveStyleSheet('large text', 1);return false;\"><img src=\"plugins/content/alphatoolbar/images/icon-large.gif\" alt=\"larger text tool icon\" border=\"0\" /></a>
				</td>
			  </tr>
			  </table>"
			  ;
		} elseif ( $atb_show_icons_resize_text && !$atb_show_icon_hits ) {		
			$seticonsresizetext = "<table border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"5\">
			  <tr><td>
			<a href=\"#\" onkeypress=\"setActiveStyleSheet('small text', 1); return false;\" onclick=\"setActiveStyleSheet('small text', 1); return false;\"><img src=\"plugins/content/alphatoolbar/images/icon-small.gif\" alt=\"smaller text tool icon\" border=\"0\" /></a></td><td><a href=\"#\" onkeypress=\"setActiveStyleSheet('medium text', 1);return false;\" onclick=\"setActiveStyleSheet('medium text', 1);return false;\"><img src=\"plugins/content/alphatoolbar/images/icon-medium.gif\" alt=\"medium text tool icon\" border=\"0\" /></a></td><td><a href=\"#\" onkeypress=\"setActiveStyleSheet('large text', 1);return false;\" onclick=\"setActiveStyleSheet('large text', 1);return false;\"><img src=\"plugins/content/alphatoolbar/images/icon-large.gif\" alt=\"larger text tool icon\" border=\"0\" /></a>
				</td>
			  </tr>
			  </table>"
			  ;
		} elseif ( $atb_show_icon_hits && !$atb_show_icons_resize_text) {		
			$seticonsresizetext = "<table border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"5\">
			  <tr><td><span class=\"editlinktip hasTip\" title=\"" .  JTEXT::_('Hits')  . "::" . $article->hits . "\"><img src=\"plugins/content/alphatoolbar/images/icon-chart.gif\" alt=\"Hits\" border=\"0\" /></span>
			  </td></tr>
			  </table>"
			  ;		
		} else $seticonsresizetext = "";

		// prepare html
		$html  = "";
		
		if ( $atb_position=='0' ) {
			$html .= "<div id=\"toolbar-articlebody\">\n";		
			$html .= $article->text;
			$html .= "</div>\n";
		}
		
		// toolbar html
		$html .= "<div id=\"toolbar-article\">\n";	
		$html .= "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
			  <tr><td width=\"95%\">
				<div class=\"menu-toolbar-article-horizontal\">
				<ul id=\"menulist_root-toolbar-article-horizontal\" class=\"mainlevel-toolbar-article-horizontal\" >					
					<li><a href=\"#\" class=\"mainlevel-toolbar-article-horizontal\"><span class=\"expanded\"><img src=\"plugins/content/alphatoolbar/images/icon-sharethis.gif\" alt=\"\" border=\"0\" />" . JTEXT::_('ATB_SHARETHIS') . "</span></a>
						<ul id=\"menulist_1-toolbar-article-horizontal\">" 
						. $social_links .
						"</ul>
					</li>\n" . $hear . $pdf . $print . $email .	$tags . $contenttoc . 
				"</ul>
				</div>
				</td>
			  <td width=\"5%\">\n"
			  . $seticonsresizetext .			  
			  "</td>\n
			   </tr>
			  </table>\n";				
		$html .= "</div>\n";
		// end div toolbar-article
		
		if ( $atb_position=='1' ) {
			$html .= "<div id=\"toolbar-articlebody\">\n";		
			$html .= $article->text;
			$html .= "</div>\n";
		}
		if ( $atb_show_go_top_link ) $html .= "<div class=\"backtotop\"><a href=\"#top-toolbar-article\" class=\"expandedtop\">" . JTEXT::_('ATB_TOPARTICLE') . "</a></div>\n";		
				
		$article->text = $html;
	}	
	
	function onBeforeDisplayContent( &$article, &$params, $limitstart )
	{
		global $mainframe;
		
		$view		= JRequest::getCmd('view');		
		$print		= JRequest::getVar('print');
		
		if ( $view != 'article' || $print ) return;
		
		// Get plugin info
		$plugin =& JPluginHelper::getPlugin('content', 'alphatoolbar');
		$pluginParams = new JParameter( $plugin->params );
		
		if ( !$pluginParams->get( 'atb_show_on_printpage',  0 ) && $print )  return;
		
		$atb_show_go_top_link = $pluginParams->def( 'atb_show_go_top_link', 1 );
		
		if ( $atb_show_go_top_link ) echo "<a name=\"top-toolbar-article\"></a>\n";
	}	

	function buildSocialBookmarkList ( $pluginParams )
	{
		global $mainframe;
	
		$description    = $mainframe->getCfg('MetaDesc');		
		$tags 			= str_replace('\n','', $mainframe->getCfg('MetaKeys') );
		$tags 			= trim($tags);
		$tags_space		= str_replace(',', ' ', $tags);
		$tags_semi 		= str_replace(',', ';', $tags);
		$tags_space 	= str_replace('  ', ' ', $tags_space);	
		
		$social_links   = "";		
		$imgImg         = JURI::base(true). "/plugins/content/alphatoolbar/images/";	
		$imgdir         = JURI::base(true). "/plugins/content/alphatoolbar/images/social/";
		

		if ( $pluginParams->get('twitter', 1) ) {
				$twitter1		   = $pluginParams->def('twitter1', '.com');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.twitter$twitter1\" onclick=\"window.open('http://www.twitter.com/home?status='+encodeURIComponent(document.title)+':+'+encodeURIComponent(location.href)+'','','resizable,location,menubar,toolbar,scrollbars,status');return false;\"><img src=\"" . $imgdir . "twitter_trans.gif\" alt=\"\" name=\"twitter\" border=\"0\" id=\"twitter\"/> Twitter</a></li>";
		}
		
		if ( $pluginParams->get('myspace', 1) ) {
				$myspace1		   = $pluginParams->def('myspace1', '.com');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.myspace$myspace1\" onclick=\"window.open('http://www.myspace.com/index.cfm?fuseaction=postto&amp;t='+encodeURIComponent(document.title)+'&amp;u='+ encodeURIComponent(location.href));return false;\"><img src=\"" . $imgdir . "myspace_trans.gif\" alt=\"\" name=\"myspace\" border=\"0\" id=\"myspace\"/> Myspace</a></li>";
		}
		
		if ( $pluginParams->get('wong', 1) ) {
				$wongl		   = $pluginParams->def('wongl', '.com');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.mister-wong$wongl\" onclick=\"window.open('http://www.mister-wong$wongl/index.php?action=addurl&amp;bm_url='+encodeURIComponent(location.href)+'&amp;bm_notice=" . $description . "&amp;bm_description='+encodeURIComponent(document.title)+'&amp;bm_tags=" . $tags_space . "');return false;\"><img src=\"" . $imgdir . "wong_trans.gif\" alt=\"\" name=\"wong\" border=\"0\" id=\"wong\"/> Mister Wong</a></li>";
		}
		
		if ( $pluginParams->get('webnews', 0) ) {
				$webnewsl 	   = $pluginParams->def('webnewsl', '.de');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.webnews$webnewsl\" onclick=\"window.open('http://www.webnews$webnewsl/einstellen?url='+encodeURIComponent(document.location)+'&amp;title='+encodeURIComponent(document.title)+'&amp;desc=" . $description . "');return false;\" ><img src=\"" . $imgdir . "webnews_trans.gif\" alt=\"\" name=\"Webnews\" border=\"0\" id=\"Webnews\" /> Webnews</a></li>";
		}
		
		if ( $pluginParams->get('iciode', 0) ) {
				$iciodel	   = $pluginParams->def('iciodel', '.de');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.icio$iciodel\" onclick=\"window.open('http://www.icio$iciodel/add.php?url='+encodeURIComponent(location.href));return false;\"><img src=\"" . $imgdir . "icio_trans.gif\" alt=\"\"  name=\"Icio\" border=\"0\" id=\"Icio\" /> Icio</a></li>";
		}
		
		if ( $pluginParams->get('oneview', 0) ) {
				$oneviewl 	   = $pluginParams->def('oneviewl', '.de');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.oneview$oneviewl\" onclick=\"window.open('http://www.oneview$oneviewl/quickadd/neu/addBookmark.jsf?URL='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title));return false;\" ><img src=\"" . $imgdir . "oneview_trans.gif\" alt=\"\" name=\"Oneview\" border=\"0\" id=\"Oneview\"/> Oneview</a></li>";
		}
		
		if ( $pluginParams->get('yigg', 0) ) {
				$yiggl 			= $pluginParams->def('yiggl', '.de');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://yigg$yiggl\" onclick=\"window.open('http://yigg$yiggl/neu?exturl='+encodeURIComponent(location.href));return false\"><img src=\"" . $imgdir . "yigg_trans.gif\" alt=\"\" name=\"Yigg\" border=\"0\" id=\"Yigg\"/> Yigg</a></li>";
		}		

		if ( $pluginParams->get('newsider', 0) ) {
				$newsiderl 	   = $pluginParams->def('newsiderl', '.de');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.newsider$newsiderl\" onclick=\"window.open('http://www.newsider$newsiderl/submit.php?url='+(document.location.href));return false;\"><img src=\"" . $imgdir . "newsider_trans.gif\" alt=\"\" name=\"Newsider\" border=\"0\" id=\"Newsider\" /> Newsider</a></li>";
		}	

		if ( $pluginParams->get('seekxl', 0) ) {
				$seekxll 	   = $pluginParams->def('seekxll', '.de');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://social-bookmarking.seekxl$seekxll\" onclick=\"window.open('http://social-bookmarking.seekxl$seekxll/?add_url='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title));return false;\" ><img src=\"" . $imgdir . "seekxl_trans.gif\" alt=\"\" name=\"Seekxl\" border=\"0\" id=\"Seekxl\" /> Seekxl</a></li>";
		}
	
		if ( $pluginParams->get('newskick', 0) ) {
				$newskickl 	   = $pluginParams->def('newskickl', '.de');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.newskick$newskickl\" onclick=\"window.open('http://www.newskick$newskickl/submit.php?url='+(document.location.href));return false;\"><img src=\"" . $imgdir . "newskick_trans.gif\" alt=\"\" name=\"Newskick\" border=\"0\" id=\"Newskick\" /> Newskick</a></li>";
		}		
		
		if ( $pluginParams->get('favit', 0) ) {
				$favitl		   = $pluginParams->def('favitl', '.de');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.favit$favitl\" onclick=\"window.open('http://www.favit$favitl/submit.php?url='+(document.location.href));return false;\" ><img src=\"" . $imgdir . "favit_trans.gif\" alt=\"\" name=\"Favit\" border=\"0\" id=\"Favit\" /> FAV!T</a></li>";
		}

		if ( $pluginParams->get('kledy', 0) ) {
				$kledyl		   = $pluginParams->def('kledyl', '.de');			
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.kledy$kledyl\" onclick=\"window.open('http://www.kledy$kledyl/submit.php?url='+(document.location.href));return false;\"><img src=\"" . $imgdir . "kledy_trans.gif\" alt=\"\" name=\"Kledy\" border=\"0\" id=\"Kledy\"/> Kledy</a></li>";
		}		

		if ( $pluginParams->get('sbdk', 0) ) {
				$sbdkl 		   = $pluginParams->def('sbdkl', '.dk');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.social-bookmarking$sbdkl\" onclick=\"window.open('http://www.social-bookmarking$sbdkl/bookmarks/?action=add&amp;title='+encodeURIComponent(document.title)+'&amp;address='+(document.location.href));return false;\"><img src=\"" . $imgdir . "sbdk_trans.gif\" alt=\"\" name=\"SocialBookmarkPortal\" border=\"0\" id=\"SocialBookmarkPortal\" /> Social Bookmarking</a></li>";
		}

		if ( $pluginParams->get('boni', 0) ) {
				$bonil		   = $pluginParams->def('bonil', '.de');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.bonitrust$bonil\" onclick=\"window.open('http://www.bonitrust$bonil/account/bookmark/?bookmark_url='+unescape(location.href));return false;\"><img src=\"" . $imgdir . "boni_trans.gif\" alt=\"\" name=\"BoniTrust\" border=\"0\" id=\"BoniTrust\" /> BoniTrust</a></li>";
		}

		if ( $pluginParams->get('power', 0) ) {
				$powerl			= $pluginParams->def('powerl', '.com');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.power-oldie$powerl\" onclick=\"window.open('http://www.power-oldie$powerl\"><img src=\"" . $imgdir . "power_trans.gif\" alt=\"\" name=\"PowerOldie\" border=\"0\" id=\"PowerOldie\" /> Power-Oldie</a></li>";
		}		

		if ( $pluginParams->get('bookmarkscc', 1) ) {
				$bookmarksccl	= $pluginParams->def('bookmarksccl', '.cc');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.bookmarks$bookmarksccl\" onclick=\"window.open('http://www.bookmarks$bookmarksccl/bookmarken.php?action=neu&amp;url='+(document.location.href)+'&amp;title='+(document.title));return false;\"><img src=\"" . $imgdir . "bookmarkscc_trans.gif\" alt=\"\" name=\"Bookmarkscc\" border=\"0\" id=\"Bookmarkscc\" /> Bookmarks.cc</a></li>";
		}

		if ( $pluginParams->get('favoriten', 0) ) {
				$favoritenl		= $pluginParams->def('favoritenl', '.de');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.favoriten$favoritenl\" onclick=\"window.open('http://www.favoriten$favoritenl/url-hinzufuegen.html?bm_url='+encodeURIComponent(location.href)+'&amp;bm_title='+encodeURIComponent(document.title));return false;\"><img src=\"" . $imgdir . "favoriten_trans.gif\" alt=\"\" name=\"Favoriten\" border=\"0\" id=\"Favoriten\" /> Favoriten</a></li>";
		}				

		if ( $pluginParams->get('linksilo', 0) ) {
				$linksilol 	   = $pluginParams->def('linksilol', '.de');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.linksilo$linksilol\" onclick=\"window.open('http://www.linksilo$linksilol/index.php?area=bookmarks&amp;func=bookmark_new&amp;addurl='+encodeURIComponent(location.href)+'&amp;addtitle='+encodeURIComponent(document.title));return false;\"><img src=\"" . $imgdir . "linksilo_trans.gif\" alt=\"\" name=\"Linksilo\" border=\"0\" id=\"Linksilo\" /> Linksilo</a></li>";
		}

		if ( $pluginParams->get('readster', 0) ) {
				$readsterl 		= $pluginParams->def('readsterl', '.de');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.readster$readsterl\" onclick=\"window.open('http://www.readster$readsterl/submit/?url='+encodeURIComponent(document.location)+'&amp;title='+encodeURIComponent(document.title));return false;\"><img src=\"" . $imgdir . "readster_trans.gif\" alt=\"\" name=\"Readster\" border=\"0\" id=\"Readster\" /> Readster</a></li>";
		}

		if ( $pluginParams->get('linkarena', 0) ) {
				$linkarenal		= $pluginParams->def('linkarenal', '.com');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.linkarena$linkarenal\" onclick=\"window.open('http://linkarena$linkarenal/bookmarks/addlink/?url='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title)+'&amp;desc=" . $description . "&amp;tags=" . $tags_space . "');return false;\"><img src=\"". $imgdir . "linkarena_trans.gif\" alt=\"\"  name=\"Linkarena\" border=\"0\" id=\"Linkarena\" /> Linkarena</a></li>";
		}

		if ( $pluginParams->get('digg', 1) ) {
				$diggl 		   = $pluginParams->def('diggl', '.com');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://digg$diggl\" onclick=\"window.open('http://digg$diggl/submit?phase=2&amp;url='+encodeURIComponent(location.href)+'&amp;bodytext=" . $description . "&amp;tags=" . $tags_space . "&amp;title='+encodeURIComponent(document.title));return false;\"><img src=\"". $imgdir . "digg_trans.gif\" alt=\"\" name=\"Digg\" border=\"0\" id=\"Digg\" /> Digg</a></li>";
		}

		if ( $pluginParams->get('icio', 1) ) {
				$iciol 		   = $pluginParams->def('iciol', '.us');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://del.icio$iciol\" onclick=\"window.open('http://del.icio$iciol/post?v=2&amp;url='+encodeURIComponent(location.href)+'&amp;notes=" . $description . "&amp;tags=" . $tags_space . "&amp;title='+encodeURIComponent(document.title));return false;\"><img src=\"". $imgdir . "del_trans.gif\" alt=\"\" name=\"Delicious\" border=\"0\" id=\"Delicious\" /> Del.icio.us</a></li>";
		}

		if ( $pluginParams->get('reddit', 0) ) {
				$redditl       = $pluginParams->def('redditl', '.com');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://reddit$redditl\" onclick=\"window.open('http://reddit$redditl/submit?url='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title));return false;\"><img src=\"". $imgdir . "reddit_trans.gif\" alt=\"\" name=\"Reddit\" border=\"0\" id=\"Reddit\" /> Reddit</a></li>";
		}

		if ( $pluginParams->get('jumptags', 0) ) {
				$jumptagsl 		= $pluginParams->def('jumptagsl', '.com');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.jumptags$jumptagsl\" onclick=\"window.open('http://www.jumptags$jumptagsl/add/?url='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title));return false;\"><img src=\"" . $imgdir . "jumptags_trans.gif\" alt=\"\"  name=\"Jumptags\" border=\"0\" id=\"Jumptags\" /> Jumptags</a></li>";
		}

		if ( $pluginParams->get('upchuckr', 0)) {
				$upchuckrl 	   = $pluginParams->def('upchuckrl', '.com');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.upchuckr$upchuckrl\" onclick=\"window.open('http://www.upchuckr$upchuckrl/bookmarks.php/?action=add&amp;address='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title));return false;\"><img src=\"" . $imgdir . "upchuckr_trans.gif\" alt=\"\" name=\"Upchuckr\" border=\"0\" id=\"Upchuckr\" /> Upchuckr</a></li>";
		}

		if ( $pluginParams->get('simpy', 0)) {
				$simpyl			= $pluginParams->def('simpyl', '.com');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.simpy$simpyl\" onclick=\"window.open('http://www.simpy$simpyl/simpy/LinkAdd.do?title='+encodeURIComponent(document.title)+'&amp;tags=$tags&amp;note=" . $description . "&amp;href='+encodeURIComponent(location.href));return false;\"><img src=\"" . $imgdir . "simpy_trans.gif\" alt=\"\" name=\"Simpy\" border=\"0\" id=\"Simpy\" /> Simpy</a></li>";
		}
		
		if ( $pluginParams->get('stumbleupon', 0)) {
				$stumbleuponl 	= $pluginParams->def('stumbleuponl', '.com');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.stumbleupon$stumbleuponl\" onclick=\"window.open('http://www.stumbleupon$stumbleuponl/submit?url='+encodeURIComponent(location.href)+'&amp;newcomment=" . $description . "&amp;title='+encodeURIComponent(document.title));return false;\"><img src=\"" . $imgdir . "stumbleupon_trans.gif\" alt=\"\" name=\"StumbleUpon\" border=\"0\" id=\"StumbleUpon\" /> StumbleUpon</a></li>";
		}

		if ( $pluginParams->get('slashdot', 1)) {
				$slashdotl 		= $pluginParams->def('slashdotl', '.org');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://slashdot$slashdotl\" onclick=\"window.open('http://slashdot$slashdotl/bookmark.pl?url='+encodeURIComponent(location.href)+'&amp;tags=" . $tags_space . "&amp;title='+encodeURIComponent(document.title));return false;\"><img src=\"" . $imgdir . "slashdot_trans.gif\" alt=\"\" name=\"Slashdot\" border=\"0\" id=\"Slashdot\" /> Slashdot</a></li>";
		}

		if ( $pluginParams->get('netscape', 1)) {
				$netscapel 		= $pluginParams->def('netscapel', '.com');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.netscape$netscapel\" onclick=\"window.open('http://www.netscape$netscapel/submit/?U='+encodeURIComponent(location.href)+'&amp;storyText=" . $description . "&amp;storyTags=$tags&amp;T='+encodeURIComponent(document.title));return false;\"><img src=\"" . $imgdir . "netscape_trans.gif\" alt=\"\" name=\"Netscape\" border=\"0\" id=\"Netscape\" /> Netscape</a></li>";
		}

		if ( $pluginParams->get('furl', 1)) {
				$furll 			= $pluginParams->def('furll', '.net');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.furl$furll\" onclick=\"window.open('http://www.furl$furll/storeIt.jsp?u='+encodeURIComponent(location.href)+'&amp;keywords=$tags&amp;t='+encodeURIComponent(document.title));return false;\"><img src=\"" . $imgdir . "furl_trans.gif\" alt=\"\" name=\"Furl\" border=\"0\" id=\"Furl\" /> Furl</a></li>";
		}

		if ( $pluginParams->get('yahoo', 1)) {
				$yahool			= $pluginParams->def('yahool', '.com');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.yahoo$yahool\" onclick=\"window.open('http://myweb2.search.yahoo$yahool/myresults/bookmarklet?t='+encodeURIComponent(document.title)+'&amp;d=" . $description . "&amp;tag=" . $tags . "&amp;u='+encodeURIComponent(location.href));return false;\"><img src=\"" . $imgdir . "yahoo_trans.gif\" alt=\"\" name=\"Yahoo\" border=\"0\" id=\"Yahoo\" /> Yahoo</a></li>";
		}

		if ( $pluginParams->get('blogmarks', 0)) {
				$blogmarksl 	= $pluginParams->def('blogmarksl', '.net');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://blogmarks$blogmarksl\" onclick=\"window.open('http://blogmarks$blogmarksl/my/new.php?mini=1&amp;simple=1&amp;url='+encodeURIComponent(location.href)+'&amp;content=" . $description . "&amp;public-tags=" . $tags . "&amp;title='+encodeURIComponent(document.title));return false;\"><img src=\"" . $imgdir . "blogmarks_trans.gif\" alt=\"\" name=\"Blogmarks\" border=\"0\" id=\"Blogmarks\" /> Blogmarks</a></li>";
		}

		if ( $pluginParams->get('diigo', 0)) {
				$diigol 		= $pluginParams->def('diigol', '.com');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.diigo$diigol\" onclick=\"window.open('http://www.diigo$diigol/post?url='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title)+'&amp;tag=" . $tags . "&amp;comments=" . $description . "'); return false;\"><img src=\"" . $imgdir . "diigo_trans.gif\" alt=\"\" name=\"Diigo\" border=\"0\" id=\"Diigo\" /> Diigo</a></li>";
		}

		if ( $pluginParams->get('technorati', 1)) {
				$technoratil 	= $pluginParams->def('technoratil', '.com');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.technorati$technoratil\" onclick=\"window.open('http://technorati$technoratil/faves?add='+encodeURIComponent(location.href)+'&amp;tag=" . $tags_space . "');return false;\"><img src=\"" . $imgdir . "technorati_trans.gif\" alt=\"\" name=\"Technorati\" border=\"0\" id=\"Technorati\" /> Technorati</a></li>";
		}

		if ( $pluginParams->get('newsvine', 0)) {
				$newsvinel 		= $pluginParams->def('newsvinel', '.com');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.newsvine$newsvinel\" onclick=\"window.open('http://www.newsvine$newsvinel/_wine/save?popoff=1&amp;u='+encodeURIComponent(location.href)+'&amp;tags=" .$tags . "&amp;blurb='+encodeURIComponent(document.title));return false;\"><img src=\"" . $imgdir . "newsvine_trans.gif\" alt=\"\" name=\"Newsvine\" border=\"0\" id=\"Newsvine\" /> Newsvine</a></li>";
		}

		if ( $pluginParams->get('blinkbits', 0)) {
				$blinkbitsl		= $pluginParams->def('blinkbitsl', '.com');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.blinkbits$blinkbitsl\" onclick=\"window.open('http://www.blinkbits$blinkbitsl/bookmarklets/save.php?v=1&amp;title='+encodeURIComponent(document.title)+'&amp;source_url='+encodeURIComponent(location.href)+'&amp;source_image_url=&amp;rss_feed_url=&amp;rss_feed_url=&amp;rss2member=&amp;body=" . $description . "');return false;\"><img src=\"" . $imgdir . "blinkbits_trans.gif\" alt=\"\" name=\"Blinkbits\" border=\"0\" id=\"Blinkbits\" /> Blinkbits</a></li>";
		}

		if ( $pluginParams->get('magnolia', 0)) {
				$magnolial 		= $pluginParams->def('magnolial', '.com');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://ma.gnolia$magnolial\" onclick=\"window.open('http://ma.gnolia$magnolial/bookmarklet/add?url='+encodeURIComponent(location.href)+'&amp;title='+encodeURIComponent(document.title)+'&amp;description=" . $description . "&amp;tags=$tags');return false;\"><img src=\"" . $imgdir . "ma.gnolia_trans.gif\" alt=\"\" name=\"MaGnolia\" border=\"0\" id=\"MaGnolia\"/> Ma.Gnolia</a></li>";
		}

		if ( $pluginParams->get('smarking', 0)) {
				$smarkingl 		= $pluginParams->def('smarkingl', '.com');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://smarking$smarkingl\" onclick=\"window.open('http://smarking$smarkingl/editbookmark/?url='+ location.href +'&amp;description=" . $description . "&amp;tags=$tags');return false;\"><img src=\"" . $imgdir . "smarking_trans.gif\" alt=\"\" name=\"Smarking\" border=\"0\" id=\"Smarking\" /> Smarking</a></li>";
		}

		if ( $pluginParams->get('netvouz', 0)) {
				$netvouzl 		= $pluginParams->def('netvouzl', '.com');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.netvouz$netvouzl\" onclick=\"window.open('http://www.netvouz$netvouzl/action/submitBookmark?url='+encodeURIComponent(location.href)+'&amp;description=" . $description . "&amp;tags=$tags&amp;title='+encodeURIComponent(document.title)+'&amp;popup=yes');return false;\"><img src=\"" . $imgdir . "netvouz_trans.gif\" alt=\"\" name=\"Netvouz\" border=\"0\" id=\"Netvouz\" /> Netvouz</a></li>";
		}		

		if ( $pluginParams->get('folkd', 0)) {
				$folkdl			= $pluginParams->def('folkdl', '.com');		
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.folkd$folkdl\" onclick=\"window.open('http://www.folkd$folkdl/page/submit.html?step2_sent=1&amp;url='+encodeURIComponent(location.href)+'&amp;check=page&amp;add_title='+encodeURIComponent(document.title)+'&amp;add_description=" . $description . "&amp;add_tags_show=&amp;add_tags=" . $tags_semi . "&amp;add_state=public');return false;\"><img src=\"" . $imgdir . "folkd_trans.gif\" alt=\"\" name=\"Folkd\" border=\"0\" id=\"Folkd\" /> Folkd</a></li>";
		}

		if ( $pluginParams->get('spurl', 0)) {
				$spurll 		= $pluginParams->def('spurll', '.net');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.spurl$spurll\" onclick=\"window.open('http://www.spurl$spurll/spurl.php?v=3&amp;tags=$tags&amp;title='+encodeURIComponent(document.title)+'&amp;url='+encodeURIComponent(document.location.href));return false;\"><img src=\"" . $imgdir . "spurl_trans.gif\" alt=\"\" name=\"Spurl\" border=\"0\" id=\"Spurl\" /> Spurl</a></li>";
		}

		if ( $pluginParams->get('google', 1)) {
				$googlel 		= $pluginParams->def('googlel', '.com');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.google$googlel\" onclick=\"window.open('http://www.google$googlel/bookmarks/mark?op=add&amp;hl=de&amp;bkmk='+encodeURIComponent(location.href)+'&amp;annotation=" . $description . "&amp;labels=$tags&amp;title='+encodeURIComponent(document.title));return false;\" ><img src=\"" . $imgdir . "google_trans.gif\" alt=\"\" name=\"Google\" border=\"0\" id=\"Google\" /> Googlize this</a></li>";
		}

		if ( $pluginParams->get('blinklist', 0) ) {
				$blinklistl 	= $pluginParams->def('blinklistl', '.com');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.blinklist$blinklistl\" onclick=\"window.open('http://www.blinklist$blinklistl/index.php?Action=Blink/addblink.php&amp;Description=" . $description . "&amp;Tag=$tags&amp;Url='+encodeURIComponent(location.href)+'&amp;Title='+encodeURIComponent(document.title));return false;\"><img src=\"" . $imgdir . "blinklist_trans.gif\" alt=\"\" name=\"Blinklist\" border=\"0\" id=\"Blinklist\" /> Blinklist</a></li>";
		}

		if ( $pluginParams->get('facebook', 0) ) {
				$facebookl 		= $pluginParams->def('facebookl', '.com');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.facebook$facebookl\" onclick=\"window.open('http://www.facebook$facebookl/sharer.php?u='+encodeURIComponent(location.href));return false;\"><img src=\"" . $imgdir . "facebook_trans.gif\" alt=\"\" name=\"Facebook\" border=\"0\" id=\"Facebook\" /> Facebook</a></li>";
		}

		if ( $pluginParams->get('wikio', 0) ) {
				$wikiol 		= $pluginParams->def('wikiol', '.com');
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.wikio$wikiol\" onclick=\"window.open('http://www.wikio$wikiol/vote?url='+encodeURIComponent(location.href));return false;\"><img src=\"" . $imgdir . "wikio_trans.gif\" alt=\"\" name=\"Wikio\" border=\"0\" id=\"Wikio\" /> Wikio</a></li>";
		}

		if ( $pluginParams->get('meneame', 0) ) {
				$meneame1 		= $pluginParams->def('meneame1', '.net');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://meneame$meneame1\" onclick=\"window.open('http://meneame$meneame1/submit.php?url='+encodeURIComponent(location.href));return false;\"><img src=\"" . $imgdir . "meneame_trans.gif\" alt=\"\" name=\"Meneame\" border=\"0\" id=\"Wikio\" /> Meneame</a></li>";
		}
		
		if ( $pluginParams->get('diggita', 1) ) {
				$diggital 		= $pluginParams->def('diggital', '.it');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.diggita$diggital\" onclick=\"window.open('http://www.diggita$diggital/submit.php?title='+(document.title)+'&url='+(document.location.href));return false;\"><img src=\"" . $imgdir . "diggita.png\" alt=\"\" name=\"Diggita\" border=\"0\" id=\"Diggita\" /> Diggita</a></li>";
		}
		
		if ( $pluginParams->get('kipapa', 0) ) {
				$kipapa1 	   = $pluginParams->def('kipapa1', '.it');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://kipapa$kipapal\" onclick=\"window.open('http://kipapa$kipapal/add.php?title='+(document.title)+'&url='+(document.location.href));return false;\"><img src=\"" . $imgdir . "kipapa.jpg\" alt=\"\" name=\"Kipapa\" border=\"0\" id=\"Kipapa\" /> Kipapa.cc</a></li>";
		}
		
		if ( $pluginParams->get('notizieflash', 0) ) {
				$notizieflashl = $pluginParams->def('notizieflashl', '.com');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://notizieflash$notizieflashl\" onclick=\"window.open('http://notizieflash$notizieflashl/submit.php?title='+(document.title)+'&url='+(document.location.href));return false;\"><img src=\"" . $imgdir . "notizieflash.png\" alt=\"\" name=\"Notizieflash\" border=\"0\" id=\"Notizieflash\" /> Notizieflash</a></li>";
		}
		
		if ( $pluginParams->get('oknotizie', 0) ) {
				$oknotiziel    = $pluginParams->def('oknotiziel', '.com');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://oknotizie$oknotiziel\" onclick=\"window.open('http://oknotizie$oknotiziel/post?url='+(document.location.href)+'&title='+(document.title));return false;\"><img src=\"" . $imgdir . "oknotizie.gif\" alt=\"\" name=\"OKnotizie\" border=\"0\" id=\"OKnotizie\" /> OKnotizie</a></li>";
		}
		
		if ( $pluginParams->get('segnalo', 0) ) {
				$segnalol    = $pluginParams->def('segnalol', '.com');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://segnalo$segnalol\" onclick=\"window.open('http://segnalo$segnalol/post.html.php?url='+(document.location.href)+'&title='+(document.title));return false;\"><img src=\"" . $imgdir . "segnalo.png\" alt=\"\" name=\"Segnalo\" border=\"0\" id=\"Segnalo\" /> Segnalo</a></li>";
		}
		
		if ( $pluginParams->get('ziczac', 0) ) {
				$ziczacl    = $pluginParams->def('ziczacl', '.it');	
				$social_links .= "<li><a rel=\"nofollow\" class=\"sublevel-toolbar-article-horizontal\" href=\"http://ziczac$ziczacl\" onclick=\"window.open('http://ziczac$ziczacl/a/segnala/?gurl='+(document.location.href)+'&gtit='+(document.title));return false\"><img src=\"" . $imgdir . "ziczac.gif\" alt=\"\" name=\"Ziczac\" border=\"0\" id=\"Ziczac\"/> Ziczac</a></li>";
		}
		
		$social_links .= "<li><a class=\"sublevel-toolbar-article-horizontal\" href=\"http://www.alphaplug.com\"><img src=\"" . $imgImg . "ap.gif\" alt=\"\" name=\"AlphaPlug\" border=\"0\" id=\"AlphaPlug\"/></a></li>";
	
		return $social_links;
	}	
}
?>