<?php
/**
* @package RokBridge
* @version 1.0
* @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* Joomla! is free software and parts of it may contain or be derived from the
* GNU General Public License or other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

/** ensure this file is being included by a parent file */
defined( '_JEXEC' ) or die( 'Restricted access' );

$document 	=& JFactory::getDocument();
$document->addStyleSheet('components/com_rokbridge/assets/rokbridge.css');


function displayRokBridgeConfig(&$params, &$bits) {
    
    $patch_installed =$bits->patch_intalled;
    $patch_note = $bits->patch_note;
    
    $joomla_authplg_installed = $bits->joomla_authplg_installed;
    $joomla_userplg_installed = $bits->joomla_userplg_installed;
    
    $current_bridge_path    = $bits->current_bridge_path;
    $bridge_install_enable  = $bits->bridge_install_enable;
    $bridge_note            = $bits->bridge_note;
    
    $phpbb3plg_installed    = (bool) $bits->phpbb3plg_installed;
    $phpbb3plg_note         = $bits->phpbb3plg_note;
    $phpbb3_installed       = (bool) $bits->phpbb3_installed;
    $bridge_installed       = (bool) $bits->bridge_installed;
    
    
    $patch_class            = $patch_installed ? "installed":"notinstalled";
    $userplg_class          = $joomla_userplg_installed ? "installed":"notinstalled";
    $authplg_class          = $joomla_authplg_installed ? "installed":"notinstalled";
    $phpbb3plg_class        = $phpbb3plg_installed ? "installed":"notinstalled";
    $phpbb3_class           = $phpbb3_installed ? "installed":"notinstalled";
    $bridge_class           = $bridge_installed ? "installed":"notinstalled";
    
    if ($joomla_userplg_installed) {
        $userplg_status = JText::_('INSTALLED_ENABLED');
        $userplg_note = "";
    } else {
        $userplg_status = JText::_('INSTALLED_NOT_ENABLED');
        $userplg_note = JText::_('INSTALLED_NOT_ENABLED_NOTE');        
    }

    if ($joomla_authplg_installed) {
        $authplg_status = JText::_('INSTALLED_ENABLED');
        $authplg_note = "";
    } else {
        $authplg_status = JText::_('INSTALLED_NOT_ENABLED');
        $authplg_note = JText::_('INSTALLED_NOT_ENABLED_NOTE');        
    } 
    
    if (!$patch_installed) { 
        $patch_status = JText::_('NOT_INSTALLED');
    } else {
        $patch_status = JText::_('INSTALLED');
    }
    
    
    if (!$phpbb3_installed) { 
        $phpbb3_note = JText::_('PHPBB3_INSTALL_NOT_FOUND');
        $phpbb3_status = JText::_('NOT_INSTALLED');
    } else {
        $phpbb3_note = "";
        $phpbb3_status = JText::_('INSTALLED');
    }
    
    if (!$phpbb3plg_installed) {
        $phpbb3plg_status = JText::_('NOT_INSTALLED');
    } else {
        $phpbb3plg_status = JText::_('INSTALLED');;
    }
    
    if (!$bridge_installed) {
        $bridge_status = JText::_('NOT_INSTALLED');
    } else {
        $bridge_status = JText::_('INSTALLED');;
    }

?> 

<h1><?php echo JText::_('ROKBRIDGE_CONFIGURATION'); ?></h1>

<table>
    <tr valign="top">
        <td width="50%">
<form action="index.php" method="post" name="adminForm" autocomplete="off">
    <?php echo $params->render('params'); ?>
    <input type="hidden" name="option" value="com_rokbridge" />
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="current_bridge_path" value="<?php echo $current_bridge_path; ?>" />
</form>
        </td>
        <td width="50%">
            <div class="note">
                <?php echo JText::_('INSTRUCTIONS'); ?>
            </div>
        </td>
    </tr>
</table>

<br />

<h1><?php echo JText::_('ROKBRIDGE_STATUS'); ?></h1>

<table class="adminlist">
	<thead>
		<tr>
			<th class="title" width="20%"><?php echo JText::_('ELEMENT'); ?></th>
			<th width="15%"><?php echo JText::_('STATUS'); ?></th>
			<th width="15%"><?php echo JText::_('ACTION'); ?></th>
			<th width="50%"><?php echo JText::_('NOTE'); ?></th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="4">&nbsp;</td>
		</tr>
	</tfoot>
	<tbody>
	   <tr class="<?php echo $userplg_class; ?>"> 
	        <td><?php echo JText::_('JOOMLA_USERPLG'); ?></td>
	        <td class="status"><?php echo $userplg_status ?></td>
	        <td>&nbsp;</td>
	        <td><?php echo $userplg_note; ?></td>
	   </tr>
	   <tr class="<?php echo $authplg_class; ?>"> 
   	        <td><?php echo JText::_('JOOMLA_AUTHPLG'); ?></td>
   	        <td class="status"><?php echo $authplg_status; ?></td>
   	        <td>&nbsp;</td>
   	        <td><?php echo $authplg_note; ?></td>
   	   </tr>
   	   <tr class="<?php echo $bridge_class; ?>"> 
  	        <td><?php echo JText::_('PHPBB3_BRIDGE'); ?></td>
  	        <td class="status"><?php echo $bridge_status; ?></td>
  	        <td class="centeralign">
  	            <?php if ($bridge_install_enable) :?>
  	                <?php if (!$bridge_installed) : ?>
  	                <a href="index.php?option=com_rokbridge&amp;task=movebridge"><?php echo JText::_('INSTALL'); ?></a>
  	                <?php else: ?>
  	                <a href="index.php?option=com_rokbridge&amp;task=removebridge"><?php echo JText::_('REMOVE'); ?></a>    
  	                <?php endif; ?>
  	            <?php endif; ?>
  	        </td>
  	        <td><?php echo $bridge_note; ?></td>
  	   </tr>   	   
   	   <tr class="<?php echo $phpbb3_class; ?>"> 
 	        <td><?php echo JText::_('PHPBB3_FORUM');?></td>
 	        <td class="status"><?php echo $phpbb3_status; ?></td>
 	        <td></td>
 	        <td><?php echo $phpbb3_note; ?></td>
 	   </tr>
   	   <tr class="<?php echo $phpbb3plg_class; ?>"> 
  	        <td><?php echo JText::_('PHPBB3_AUTHPLG');?></td>
  	        <td class="status"><?php echo $phpbb3plg_status; ?></td>
  	        <td class="centeralign">
      	        <?php if ($phpbb3_installed and $bridge_installed) : ?>
          	        <?php if (!$phpbb3plg_installed) : ?>
          	        <a href="index.php?option=com_rokbridge&amp;task=installphpbb3plg"><?php echo JText::_('INSTALL'); ?></a>
          	        <?php else: ?>
          	        <a href="index.php?option=com_rokbridge&amp;task=removephpbb3plg"><?php echo JText::_('REMOVE'); ?></a>    
          	        <?php endif; ?>
          	    <?php else: 
          	        $phpbb3plg_note = JText::_('BRIDGE_INSTALLED_FIRST');
          	     endif; ?>
  	        </td>
  	        <td><?php echo $phpbb3plg_note; ?></td>
  	   </tr>
  	   <tr class="<?php echo $patch_class; ?>"> 
     	        <td><?php echo JText::_('PHPBB3_PATCH');?></td>
     	        <td class="status"><?php echo $patch_status; ?></td>
     	        <td class="centeralign">
         	        <?php if ($phpbb3_installed) : ?>
             	        <?php if (!$patch_installed) : ?>
             	        <a href="index.php?option=com_rokbridge&amp;task=applypatch"><?php echo JText::_('INSTALL'); ?></a>
             	        <?php else: ?>
             	        <a href="index.php?option=com_rokbridge&amp;task=removepatch"><?php echo JText::_('REMOVE'); ?></a>    
             	        <?php endif; ?>
         	        <?php endif; ?>
     	        </td>
     	        <td><?php echo $patch_note; ?></td>
     	   </tr>
	   
    </tbody>
</table>

<?php } ?>
