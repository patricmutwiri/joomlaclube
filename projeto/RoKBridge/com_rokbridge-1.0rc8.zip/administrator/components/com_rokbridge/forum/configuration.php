<?php 
class JConfigForum 
{
    var $phpbb_path = 'distribution';
    var $sef = '0';
    var $sef_rewrite = '0';
    var $remember_login = false;
}
?>
