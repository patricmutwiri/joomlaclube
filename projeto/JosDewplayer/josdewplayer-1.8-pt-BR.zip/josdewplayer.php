<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
/**
*# Josdewplayer based on mosdewplayer, Joomla 1.5 native plugin
*# License http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL, see LICENSE.php
*# By infograf768, and help by Sam Moffatt for the local parameters implementation
*# Version 1.6, may now load mp3 from other locations than Joomla folder
*# Version 1.7, may now play multiple mp3 using dewplayer-multi.swf (thanks Russel for the idea)
**/

$mainframe->registerEvent( 'onPrepareContent', 'plgContentJDewplayer' );

function plgContentJDewplayer( &$row, &$params, $page=0 )
{
$db =& JFactory::getDBO();
	// simple performance check to determine whether bot should process further
	if ( JString::strpos( $row->text, 'play' ) === false ) {
		return true;
	}
// Get plugin info
	$plugin =& JPluginHelper::getPlugin('content', 'josdewplayer');

	// define the regular expression for the plugin
	$regex = "#{play}(.*?){/play}#s";

$pluginParams = new JParameter( $plugin->params );

	// check whether plugin has been unpublished
	if ( !$pluginParams->get( 'enabled', 1 ) ) {
	$row->text = preg_replace( $regex, '', $row->text );
return true;
}

	// perform the replacement
	$row->text = preg_replace_callback( $regex, 'josdewplayer_replacer', $row->text );

	return true;
}

function josdewplayer_replacer ( &$matches) {
$LiveSite = JURI::base();
$plugin =& JPluginHelper::getPlugin('content', 'josdewplayer');
$pluginParams = new JParameter( $plugin->params );
$thisParams = explode("|",$matches[1]);

// look for and replace general parameters by local ones if present (Thanks Sam ;) )

for($i = 1; $i < count($thisParams); $i++)
{
	if(!strcmp($thisParams[$i], '[AUTOPLAY]')) {
		$autoplay = $pluginParams->set('autoplay',1);
	} else if(!strcmp($thisParams[$i], '[AUTOREPLAY]')) {
		$autoreplay = $pluginParams->set('autoreplay', 1);
	} else if(strstr($thisParams[$i], '[BGCOLOR]')) {
		$parts = explode('[',$thisParams[$i]);
		$pluginParams->set('bgcolor',$parts[0]);
	}
}

// Get params values
$autoplay = $pluginParams->get('autoplay', 0);
$bgcolor = $pluginParams->get('bgcolor', '');
$autoreplay = $pluginParams->get('autoreplay', 0);
if(empty($bgcolor)) $bgcolor='#fff';

if($bgcolor=="transparent"){
$wmode='transparent';
$background='';
}
else {
$wmode='opaque';
$background= 'bgcolor="'.$bgcolor.'"';}

//Multiplayer - Based on an idea by Russel Winter

$playList = explode('*', $thisParams[0]);
for($i = 0; $i < count($playList); $i++)
{
  if ($i >0) {

   if (strpos( $playList[$i], 'http' ) !==false) {
   $path .= '|'. $playList[$i];
   } else {
   $path .='|'.$LiveSite.$playList[$i];
   }
   $player = 'dewplayer-multi.swf?mp3=';
   $width= '240';

  } else {
   $path = $playList[$i];
   if (strpos( $path, 'http' ) !==false) {
   $path =$path;
   } else {
   $path =$LiveSite.$path;
   }
   $player = 'dewplayer.swf?son=';
   $width= '200';
   }
}

$text = '<object type="application/x-shockwave-flash" data="'. $LiveSite .'plugins/content/'.$player. $path .'&amp;autoplay='.$autoplay.'&amp;autoreplay='.$autoreplay.'&amp;showtime=1" width="'.$width.'" height="20" '.$background.'>  <param name="wmode" value="'.$wmode.'" /><param name="movie" value="'. $LiveSite .'plugins/content/'.$player. $path .'&amp;autoplay='.$autoplay.'&amp;autoreplay='.$autoreplay.'&amp;showtime=1" /></object>
';
return $text;
}
?>