<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Controller Class
class AcesefControllerPurge extends AcesefController {
	
	// Main constructer
	function __construct() {
        parent::__construct();
    }
	
	// Purge function
    function purge() {
        $do = JRequest::getVar('do', '0');
        if($do == '0') {
            JRequest::setVar('view', 'purge');
            JRequest::setVar('layout', 'default');
        } else {
            $model =& $this->getModel('purge');
            if($model->purge()){
                $this->setRedirect('index.php?option=com_acesef', JText::_('ACESEF_PURGE_PURGED'));
            } else {
                $this->setRedirect('index.php?option=com_acesef', JText::_('ACESEF_PURGE_NOT_PURGED'));
			}
        }
        parent::display();
    }
}
?>