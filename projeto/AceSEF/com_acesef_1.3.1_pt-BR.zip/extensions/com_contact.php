<?php
/*
* @package		AceSEF
* @subpackage	Contact
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_contact extends AceSEFTools {

	var $title_cat;
	var $title_item;
	var $desc_cat;
	
	function getCategoryTitle($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();

        $database->setQuery("SELECT title, alias, description$joomfish FROM #__categories WHERE id =".$id);
        $rows = $database->loadRow();

		$name = (($this->params->get('categoryid_inc', '1') != '1') ? $id.'-' : '');
		if(AceSEFTools::urlPart($this->params->get('category_part', 'global')) == 'title'){
			$name .= $rows[0];
		} else {
			$name .= $rows[1];
		}
		
		$this->desc_cat = $rows[2];
		$this->title_cat = $name;
			
		return $name;
    }

    function getContactTitle($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();

        $database->setQuery("SELECT name, alias, catid$joomfish FROM #__contact_details WHERE id =".$id);
        $rows = $database->loadRow();

		$name = (($this->params->get('contactid_inc', '1') != '1') ? $id.'-' : '');
		if(AceSEFTools::urlPart($this->params->get('contact_part', 'global')) == 'title'){
			$name .= $rows[0];
		} else {
			$name .= $rows[1];
		}
		
		if($this->params->get('category_inc', '1') != '2') {
			$this->title_item = array($rows[0]);
			return array($name);
		} else {
			$this->title_item = array($this->getCategoryTitle($rows[2]), $rows[0]);
			return array($this->getCategoryTitle($rows[2]), $name);
		}
    }
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();
		
		if(isset($view)) {
            switch($view) {
				case 'category':
                    if(isset($catid)){
                        $title[] = $this->getCategoryTitle($catid);
					}
                    break;
                case 'contact':
					if(isset($id)){
						$title = array_merge($title, $this->getContactTitle($id));
					}
                    break;
            }
        }

		return $title;
	}
	
	function metaTags(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		
		$separator			= $this->params->get('separator', '-');
		$desc_length		= $this->params->get('desc_length', '250');
		$keywords_word		= $this->params->get('keywords_word', '3');
		$keywords_count		= $this->params->get('keywords_count', '15');
		$blacklist			= $this->params->get('blacklist', '');
		
		$acesef_title = $acesef_desc = $acesef_key = "";
		
		if (isset($view)){
			switch ($view){
				case 'category': 
					if(isset($catid)){
						$acesef_title	= $this->title_cat;
						$acesef_desc	= AceSEFTools::clipDesc($this->desc_cat, $desc_length);
						if(!empty($acesef_desc)){
							$acesef_key = AceSEFTools::generateKeywords($acesef_desc, $blacklist, $keywords_count, $keywords_word);
						}
					}
					break;
				case 'contact': 
					if(isset($id)){
						$acesef_title	= implode(" ".$separator." ", array_reverse($this->title_item));
					}
					break;
			}
		}
		
		$meta = AceSEFTools::setMetaData($acesef_title, $acesef_desc, $acesef_key);

		return $meta;
	}
}
?>