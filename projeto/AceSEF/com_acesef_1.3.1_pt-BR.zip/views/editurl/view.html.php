<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Imports
jimport('joomla.application.component.view');
include_once(JPATH_ROOT.DS.'libraries'.DS.'joomla'.DS.'html'.DS.'html'.DS.'select.php');
require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');

// View Class
class AcesefViewEditurl extends JView {

	// Edit URL
	function edit ($tpl = null) {
	
		// Get data from model
		$row = & $this->get('Data');
		
		// Get configuration class
		$this->acesef_config = new acesef_configuration();
		
		// Import CSS
		$document =& JFactory::getDocument();
		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set toolbar
		JToolBarHelper::title(JText::_('ACESEF_URL_EDIT_TITLE').' '.$row->url_sef, 'acesef');
		JToolBarHelper::custom('save', 'save1.png', 'save1.png', JTEXT::_('Save'), false);
		JToolBarHelper::custom('apply', 'approve.png', 'approve.png', JTEXT::_('Apply'), false);
		JToolBarHelper::custom('cancel', 'cancel1.png', 'cancel1.png', JTEXT::_('Cancel'), false);
		JToolBarHelper::divider();
		JToolBarHelper::custom('savemoved', 'save1.png', 'save1.png', JTEXT::_('ACESEF_URL_EDIT_SAVEMOVED'), false);
		
		// Options array
		$select = array();
		$select[] = JHTMLSelect::Option('0', JTEXT::_('No'));
		$select[] = JHTMLSelect::Option('1', JTEXT::_('Yes'));
		
		// Published list
   	   	$lists['published'] = JHTMLSelect::genericlist($select, 'published', 'class="inputbox" size="1 "','value', 'text', $row->published);
		
		// Locked list
   	   	$lists['locked'] = JHTMLSelect::genericlist($select, 'locked', 'class="inputbox" size="1 "','value', 'text', $row->locked);
		
		// Get alias
		$row->moved_alias = "";
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT url_old FROM #__acesef_urls_moved WHERE url_new = '".$row->url_sef."' ORDER BY url_old");
		$urls = $db->loadObjectList();
		if(!is_null($urls)){
			foreach($urls as $url){
				$row->moved_alias .= $url->url_old."\n";
			}
		}
		
		// Indexed
		if($row->sm_indexed == ''){
			$row->sm_indexed = $this->acesef_config->sm_indexed;
		}
   	   	$lists['indexed'] = JHTMLSelect::genericlist($select, 'sm_indexed', 'class="inputbox" size="1 "','value', 'text', $row->sm_indexed);
		
		// Date
		if($row->sm_date == '0000-00-00' || $row->sm_date == ''){
			$row->sm_date = date('Y-m-d');
		}
		
		// Frequency
		$f_list = array();
		$f_list[] = JHTMLSelect::Option('always', JTEXT::_('ACESEF_SITEMAP_SELECT_ALWAYS'));
		$f_list[] = JHTMLSelect::Option('hourly', JTEXT::_('ACESEF_SITEMAP_SELECT_HOURLY'));
		$f_list[] = JHTMLSelect::Option('daily', JTEXT::_('ACESEF_SITEMAP_SELECT_DAILY'));
		$f_list[] = JHTMLSelect::Option('weekly', JTEXT::_('ACESEF_SITEMAP_SELECT_WEEKLY'));
		$f_list[] = JHTMLSelect::Option('monthly', JTEXT::_('ACESEF_SITEMAP_SELECT_MONTHLY'));
		$f_list[] = JHTMLSelect::Option('yearly', JTEXT::_('ACESEF_SITEMAP_SELECT_YEARLY'));
		$f_list[] = JHTMLSelect::Option('never', JTEXT::_('ACESEF_SITEMAP_SELECT_NEVER'));
		if($row->sm_freq == ''){
			$row->sm_freq = $this->acesef_config->sm_freq;
		}
   	   	$lists['frequency'] = JHTMLSelect::genericlist($f_list, 'sm_freq', 'class="inputbox" size="1 "','value', 'text', $row->sm_freq);
		
		// Priority
		$p_list = array();
		$p_list[] = JHTMLSelect::Option('0.0', '0.0');
		$p_list[] = JHTMLSelect::Option('0.1', '0.1');
		$p_list[] = JHTMLSelect::Option('0.2', '0.2');
		$p_list[] = JHTMLSelect::Option('0.3', '0.3');
		$p_list[] = JHTMLSelect::Option('0.4', '0.4');
		$p_list[] = JHTMLSelect::Option('0.5', '0.5');
		$p_list[] = JHTMLSelect::Option('0.6', '0.6');
		$p_list[] = JHTMLSelect::Option('0.7', '0.7');
		$p_list[] = JHTMLSelect::Option('0.8', '0.8');
		$p_list[] = JHTMLSelect::Option('0.9', '0.9');
		$p_list[] = JHTMLSelect::Option('1.0', '1.0');
		if($row->sm_priority == ''){
			$row->sm_priority = $this->acesef_config->sm_priority;
		}
   	   	$lists['priority'] = JHTMLSelect::genericlist($p_list, 'sm_priority', 'class="inputbox" size="1 "','value', 'text', $row->sm_priority);
		
		// Assign values
		$this->assignRef('row', $row);
		$this->assignRef('lists', $lists);

		parent::display($tpl);
	}
}
?>