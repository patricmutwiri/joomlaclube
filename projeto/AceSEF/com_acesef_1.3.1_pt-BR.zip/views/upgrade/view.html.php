<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
// Import View
jimport('joomla.application.component.view');

// Upgrade View Class
class AceSEFViewUpgrade extends JView {

	function __construct($config = null) {
		parent::__construct($config);
	}

	function display($tpl = null) {
		$document =& JFactory::getDocument();
		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		JToolBarHelper::title(JText::_('ACESEF_UPGRADE_TITLE'), 'acesef');
		
		JToolBarHelper::back('Back', 'index.php?option=com_acesef');

		parent::display($tpl);
	}

	function showMessage() {
	    JToolBarHelper::title(JText::_('ACESEF_UPGRADE_TITLE'));
	    
	    JToolBarHelper::back('Continue', 'index.php?option=com_acesef');
	    
	    $this->setLayout('message');
	    parent::display();
	}
}
