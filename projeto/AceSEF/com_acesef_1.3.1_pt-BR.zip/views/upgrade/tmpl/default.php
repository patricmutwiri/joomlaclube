<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/
 
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
?>
<script language="javascript" type="text/javascript">
<!--
	function submitupgrade(pressbutton) {
		var form = document.upgradeForm;

		form.task.value = 'upgrade';
		form.submit();
	}
//-->
</script>
<form enctype="multipart/form-data" action="index.php" method="post" name="upgradeForm">
	<fieldset class="adminform">
	<legend><?php echo JText::_('ACESEF_UPGRADE_TITLE'); ?></legend>
	
		<table class="adminform">
			<tr>
				<th colspan="2"><?php echo JText::_('ACESEF_UPGRADE_PACKAGE'); ?></th>
			</tr>
			<tr>
				<td width="120">
					<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
				</td>
				<td>
					<input class="input_box" id="install_package" name="install_package" type="file" size="57" />
					<input class="button" type="submit" value="<?php echo JText::_('ACESEF_UPGRADE_UPLOAD_INSTALL'); ?>" onclick="submitupgrade()" />
				</td>
			</tr>
		</table>

		<input type="hidden" name="option" value="com_acesef" />
		<input type="hidden" name="task" value="view" />
		<input type="hidden" name="controller" value="upgrade" />
	</fieldset>
</form>