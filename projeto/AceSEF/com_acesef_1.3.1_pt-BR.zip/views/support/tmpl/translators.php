<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');
?>
<form action="index.php" method="post" name="adminForm">
	<div id="editcell">
	<table class="adminform">
		<tr>
			<td align="left" width="50px">
				<b>Code</b>
			</td>
			<td align="left" width="100px">
				<b>Language</b>
			</td>
			<td align="left">
				<b>Translator</b>
			</td>
		</tr>
		<tr>
			<td align="left">
				da-DK
			</td>
			<td align="left">
				Danish
			</td>
			<td align="left">
				<a href="http://www.joomace.net" target="_blank">JoomAce LLC</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				de-De
			</td>
			<td align="left">
				German
			</td>
			<td align="left">
				<a href="http://www.joomla-aktuell.de" target="_blank">Markus Rouenhoff</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				el-GR
			</td>
			<td align="left">
				Greek
			</td>
			<td align="left">
				Marios Polycarpou
			</td>
		</tr>
		<tr>
			<td align="left">
				en-GB
			</td>
			<td align="left">
				English
			</td>
			<td align="left">
				<a href="http://www.joomace.net" target="_blank">JoomAce LLC</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				es-ES
			</td>
			<td align="left">
				Spanish
			</td>
			<td align="left">
				<a href="http://www.joomace.net" target="_blank">JoomAce LLC</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				fr-FR
			</td>
			<td align="left">
				French
			</td>
			<td align="left">
				<a href="http://www.joomace.net" target="_blank">JoomAce LLC</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				hr-HR
			</td>
			<td align="left">
				Croatian
			</td>
			<td align="left">
				<a href="http://www.net-nekretnine.com" target="_blank">Gordan</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				hu-HU
			</td>
			<td align="left">
				Hungarian
			</td>
			<td align="left">
				PePe
			</td>
		</tr>
		<tr>
			<td align="left">
				it-IT
			</td>
			<td align="left">
				Italian
			</td>
			<td align="left">
				Enrico
			</td>
		</tr>
		<tr>
			<td align="left">
				pl-PL
			</td>
			<td align="left">
				Polish
			</td>
			<td align="left">
				<a href="http://www.joomace.net" target="_blank">JoomAce LLC</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				pt-BR
			</td>
			<td align="left">
				Brazilian
			</td>
			<td align="left">
				<a href="http://www.pevermelho.com" target="_blank">Elvis Vinicius</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				pt-PT
			</td>
			<td align="left">
				Portuguese
			</td>
			<td align="left">
				<a href="http://www.joomace.net" target="_blank">JoomAce LLC</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				ru-RU
			</td>
			<td align="left">
				Russian
			</td>
			<td align="left">
				<a href="http://www.joomace.net" target="_blank">JoomAce LLC</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				sl-SI
			</td>
			<td align="left">
				Slovenian
			</td>
			<td align="left">
				<a href="http://www.joomace.net" target="_blank">JoomAce LLC</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				sr-RS
			</td>
			<td align="left">
				Serbian
			</td>
			<td align="left">
				<a href="http://www.joomace.net" target="_blank">JoomAce LLC</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				tr-TR
			</td>
			<td align="left">
				Turkish
			</td>
			<td align="left">
				<a href="http://www.koraykupe.com.tr" target="_blank">Koray Kupe</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				zh-CN
			</td>
			<td align="left">
				Chinese-China
			</td>
			<td align="left">
				<a href="http://www.joomlagate.com" target="_blank">baijianpeng</a>
			</td>
		</tr>
		<tr>
			<td align="left">
				zh-TW
			</td>
			<td align="left">
				Chinese-Taiwan
			</td>
			<td align="left">
				<a href="http://www.joomlagate.com" target="_blank">baijianpeng</a>
			</td>
		</tr>
	</table>
	</div>

	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="task" value="support" />
	<input type="hidden" name="controller" value="support" />
</form>