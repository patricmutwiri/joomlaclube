<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');
?>

<style type="text/css">
h2 { color: #A1B754; }
h1, h3, h4 { color: #666666; }
div.docs,div.docs p,div.docs ul li,div.docs ol li {
	text-align: left;
	font-weight: lighter;
	font-family: Tahoma, Arial, Verdana;
}
span.link { cursor: pointer; }
div.docs p { padding-left: 3em; font-weight: lighter; }
div.docs li p { padding-left: 0em; }
div.docs .small {
	color: #666666; font-size: 90%;
}
span.bold {
	font-weight: bold;
}
</style>

<form action="index.php" method="post" name="adminForm">
	<div class="docs">
		<h1><a name="top"></a>AceSEF Changelog</h1>
		<h3>Legend</h3>
		<ul>
			<li># -> Bug Fix</li>
			<li>+ -> Addition</li>
			<li>^ -> Change</li>
			<li>-- -> Removed</li>
		</ul>
		<h3>1.3.1 &nbsp;&nbsp;&nbsp;<span class="small">26 January 2010</span></h3>
		<ul>
			<li>+ : Ping sitemap to Yahoo!, Bing and Services</li>
			<li>+ : Duplicated URLs filter</li>
			<li>+ : Meta Title configuration</li>
			<li>+ : Language filter in Metamanager and Sitemap</li>
			<li>^ : Keywords and Description filter optimized</li>
			<li>^ : Metadata management through Meta Manager for ALL components</li>
			<li>^ : Option to disable Source Tracker, not supported by PHP in CGI mode</li>
			<li># : Joom!Fish: Homepage title, desc and keywords are not translated</li>
			<li># : Not installing extensions</li>
			<li># : Rewriting index2.php URLs</li>
			<li>-- : Joom!Fish: Cookies and lang. determination options</li>
		</ul>
		<h3>1.3.0 &nbsp;&nbsp;&nbsp;<span class="small">11 January 2010</span></h3>
		<ul>
			<li>+ : Sitemap (XML) for ALL components (Pro version)</li>
			<li>+ : Croatian language translation</li>
			<li>+ : Export/Import options for metadata</li>
			<li>+ : Language determination and cookies options for Joom!Fish</li>
			<li>+ : URL source tracking for issue debugging</li>
			<li>^ : Option to rewrite metadata only if empty</li>
			<li>^ : Multiple Moved (Alias) URLs field</li>
			<li>^ : Google site verification metatag updated</li>
			<li>^ : Import / Migrate functions improved</li>
			<li>^ : Major code cleanup & optimization</li>
			<li># : Canonical link not working on homepage</li>
			<li># : Joom!Fish language selector module</li>
			<li># : No language code in some URLs</li>
			<li># : Not loading Joom!Fish translated menus</li>
			<li># : Not editing Moved URLs</li>
			<li># : Not recording 404 URLs</li>
			<li># : Records ordering in backend not working</li>
		</ul>
		<h3>1.2.5 &nbsp;&nbsp;&nbsp;<span class="small">21 December 2009</span></h3>
		<ul>
			<li>+ : Option to disable version checker</li>
			<li>+ : Greek language translation</li>
			<li>+ : Option to record 404 errors in database or not</li>
			<li>^ : Exact variables in non-SEF vars like view=article</li>
			<li>^ : Adding nonSefVars from extension code part</li>
			<li># : Deleting Prefix and Skip Title options in extension upgrades</li>
			<li># : Not filtering black list of meta tags</li>
			<li># : Some minor bugs</li>
		</ul>
		<h3>1.2.4 &nbsp;&nbsp;&nbsp;<span class="small">13 December 2009</span></h3>
		<ul>
			<li>+ : Automatic upgrade of AceSEF using Download-ID</li>
			<li>+ : Alexa meta tag field</li>
			<li>^ : Better AceSEF & extensions version checker</li>
			<li># : Missing / after domain</li>
			<li># : No more not installed components in Extensions list</li>
			<li># : Some minor bugs</li>
		</ul>
		<h3>1.2.3 &nbsp;&nbsp;&nbsp;<span class="small">04 December 2009</span></h3>
		<ul>
			<li>+ : Translators page</li>
			<li>+ : Save & Moved button in Edit URL page</li>
			<li>+ : Be tolerant to trailing slash option</li>
			<li>^ : Disable base href option</li>
			<li>^ : Minor GUI improvements in Configuration page</li>
			<li>^ : Redirection of not found (404) URLs to homepage option</li>
			<li># : Can't save Configuration</li>
			<li># : Record Duplicated not working</li>
			<li># : Router problem with new extension installation</li>
			<li># : User activation link</li>
			<li># : Minor bug with JoomFish redirection</li>
			<li># : Minor bug with extensions installation and upgrade</li>
		</ul>
		<h3>1.2.2 &nbsp;&nbsp;&nbsp;<span class="small">20 November 2009</span></h3>
		<ul>
			<li>+ : disable-SEF variables field</li>
			<li># : Deleting parameters while extension upgrade</li>
			<li># : Multiple records for same 404 URLs</li>
			<li># : Not saving SEF URL if the same 404 URL has been created</li>
			<li># : Pagination issues with some components</li>
			<li># : Warnings in extensions page</li>
			<li># : Some minor bugs</li>
		</ul>
		<h3>1.2.1 &nbsp;&nbsp;&nbsp;<span class="small">13 November 2009</span></h3>
		<ul>
			<li>+ : Option to save duplicated SEF URLs or not</li>
			<li>+ : Upgrading extensions automaticly</li>
			<li>+ : Language filter in URL Repository</li>
			<li>^ : Extensions and Routers pages united</li>
			<li>^ : Meta desc and Meta kewords fields increased</li>
			<li># : Internal Links effecting ALL site, changed to only content</li>
			<li># : Missing component name in URL with some components</li>
			<li># : Exporting/Importing AceSEF URLs</li>
			<li># : Double // slash issue</li>
			<li># : 404 error page because of special chars in meta tags</li>
			<li># : www Redirect not working properly</li>
			<li># : Some minor bugs</li>
		</ul>
		<h3>1.2.0 &nbsp;&nbsp;&nbsp;<span class="small">07 November 2009</span></h3>
		<ul>
			<li>+ : Slovenian language</li>
			<li>+ : Installation of AceSEF extensions from Joomla! Installer page</li>
			<li>+ : Moved 301 URLs</li>
			<li>+ : Meta Manager for changing meta tags in batch mode for ALL components</li>
			<li>+ : non-SEF variables in SEF URLs</li>
			<li>+ : Redirect non-www to www</li>
			<li>+ : Base href value for relative images URLs</li>
			<li>+ : Force SSL option</li>
			<li>+ : Warnings regarding AceSEF requirements</li>
			<li>+ : Multi-tier menu alias or prefix</li>
			<li>+ : Enabled/Disable automatic meta title, description and keywrods from Configuration</li>
			<li>+ : Google, Live.com and Yahoo site verification</li>
			<li>+ : Abstract, Revisit and 3 custom meta tag fields</li>
			<li>+ : New SEO features such as h1 headings, nofollow for better SEO</li>
			<li>+ : Internal Links feature for better SEO</li>
			<li>^ : URL rewrite performance improved up to 20% (less queries)</li>
			<li>^ : URL statistics enchased</li>
			<li># : Not loading Ajax requests (like yooSearch module)</li>
			<li># : Cannot modify header information error</li>
			<li># : Wrong home page loaded with JoomFish</li>
			<li># : Not importing sh404SEF URLs and Meta data</li>
			<li># : Some minor bugs</li>
			<li>-- : Bypass POST Redirects</li>
		</ul>
		<h3>1.1.3 &nbsp;&nbsp;&nbsp;<span class="small">20 October 2009</span></h3>
		<ul>
			<li>+ : Hungarian and Danish languages</li>
			<li>+ : Backup of URLs, Routers and Extensions tables after uninstallation</li>
			<li>+ : Support of UTF-8 characters in SEF URLs</li>
			<li>+ : Select the generation of description/keywords from articles meta desc</li>
			<li>+ : Search version and author in extensions page</li>
			<li>+ : Used filter in URL Repository</li>
			<li>+ : Remove session id option</li>
			<li># : UTF-8 meta keywords generation</li>
			<li># : Prevent deletion of locked URLs after extension installation</li>
			<li># : Blocked URLs redirecting to home page</li>
			<li># : Sorting records in URL Repository</li>
			<li># : Pagination issues in backend (URL Repository and Extensions pages)</li>
			<li># : Some minor bugs</li>
		</ul>
		<h3>1.1.2 &nbsp;&nbsp;&nbsp;<span class="small">14 October 2009</span></h3>
		<ul>
			<li>^ : Pagination improvement for VirtueMart component</li>
			<li>^ : Cleaning meta description</li>
			<li># : Redirecting "return" post issue, set properly as Bypass POST</li>
			<li># : URL is set as Used after being edited</li>
			<li># : Multiple records for same 404 URLs</li>
			<li># : Not exporting selected URLs</li>
			<li># : Breadcrumbs module</li>
			<li># : Removing copyright while upgrading from Free to Paid verisons</li>
			<li># : Compatibility of Poll extension with AceSEF 1.1</li>
			<li># : Remove trailing slash option in Configuration</li>
		</ul>
		<h3>1.1.1 &nbsp;&nbsp;&nbsp;<span class="small">10 October 2009</span></h3>
		<ul>
			<li>+ : Insert active menu ItemID option</li>
			<li>+ : Append menu ItemID to SEF URL option</li>
			<li>+ : Set QUERY_STRING option</li>
			<li>^ : Routing components</li>
			<li># : Some components not showing in Routers page</li>
			<li># : Minimum keyword word length</li>
			<li># : Some minor bugs</li>
			<li>-- : Parameters in URL option</li>
		</ul>
		<h3>1.1.0 &nbsp;&nbsp;&nbsp;<span class="small">07 October 2009</span></h3>
		<ul>
			<li>+ : Import sh404SEF meta data</li>
			<li>+ : French, Portuguese and Brazilian languages</li>
			<li>^ : AceSEF URL rewrite structure changed to URI</li>
			<li>^ : URL rewrite performance improved up to 20% (minimum queries)</li>
			<li>^ : All buttons' icons has been renewed</li>
			<li>^ : URL Repository page is reorganized</li>
			<li>^ : Better AceSEF version checker</li>
			<li># : Pagination for articles with multi pages</li>
			<li># : Pagination in Category Table view</li>
			<li># : Deleted Locked URLs deleted after Delete Filtered</li>
			<li># : Export Filtered didnt work if any filter is applied</li>
			<li># : Error while importing AceSEF URLs because of apostrophe in meta desc</li>
			<li># : Some minor bugs</li>
			<li>-- : Extension (un)publish option</li>
			<li>-- : Used option in URL Edit page</li>
		</ul>
		<h3>1.0.6 &nbsp;&nbsp;&nbsp;<span class="small">27 September 2009</span></h3>
		<ul>
			<li>+ : Automatic extensions version checker</li>
			<li># : Deleted Locked URLs deleted after Save & Purge in Extensions</li>
			<li># : Searching in URL Repository</li>
			<li># : Generator meta tag not changing</li>
			<li># : Some minor bugs</li>
		</ul>
		<h3>1.0.5 &nbsp;&nbsp;&nbsp;<span class="small">26 September 2009</span></h3>
		<ul>
			<li>+ : 8 new Control Panel languages</li>
			<li>+ : Used button on Repository toolbar for bulk changes</li>
			<li>+ : Filter by ItemID and Real URL in URL Repository page</li>
			<li>+ : Sort by Real URL, Used, Locked and Blocked in Repository page</li>
			<li># : Empty SEF URLs</li>
			<li># : Multiple copies of routers</li>
			<li># : Language file problem during upgrading</li>
			<li># : Version checker not working on live sites</li>
			<li># : Page title missing in some cases</li>
			<li># : Characters replacement issue</li>
			<li># : Some minor bugs</li>
		</ul>
		<h3>1.0.4 &nbsp;&nbsp;&nbsp;<span class="small">15 September 2009</span></h3>
		<ul>
			<li>+ : Automatic version checker</li>
			<li>+ : New buttons in extensions, routers and URL repository pages</li>
			<li># : Components not listed in Routers page wont be routed</li>
			<li># : Delete locked URLs deleted after Save/Apply & Purge in Configuration</li>
			<li># : Error while importing/exporting AceSEF URLs</li>
			<li># : Pagination optimization, specially for VirtueMart</li>
		</ul>
		<h3>1.0.3 &nbsp;&nbsp;&nbsp;<span class="small">10 September 2009</span></h3>
		<ul>
			<li>+ : Custom Generator tag option</li>
			<li>+ : Remove trailing slash option</li>
			<li># : 404 error with JCE editor</li>
			<li># : non-SEF URLs for some AJAX URLs (like captcha)</li>
			<li># : Google News numbering</li>
			<li># : 500 error page in Configuration with Debug System on</li>
			<li># : Some minor bugs and missing language strings</li>
		</ul>
		<h3>1.0.2 &nbsp;&nbsp;&nbsp;<span class="small">04 September 2009</span></h3>
		<ul>
			<li># : Components' names in Routers page</li>
			<li># : 404 error for Content (Articles) component</li>
			<li># : Some missing language strings</li>
		</ul>
		<h3>1.0.1 &nbsp;&nbsp;&nbsp;<span class="small">01 September 2009</span></h3>
		<ul>
			<li># : Double home page URL</li>
			<li># : URL duplicated with AceSEF basic rewriting</li>
			<li># : Some minor bugs</li>
			<li>^ : Improved automatic meta tags management</li>
			<li>^ : Improved extensions parameters</li>
		</ul>	
		<h3>1.0.0 &nbsp;&nbsp;&nbsp;<span class="small">29 August 2009</span></h3>
		<ul>
			<li>First Release</li>
		</ul>	
	</div>

	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="support" />
	<input type="hidden" name="task" value="changelog" />
</form>