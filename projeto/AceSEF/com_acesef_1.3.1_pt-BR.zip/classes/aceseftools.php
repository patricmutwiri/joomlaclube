<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.filesystem.file');
require_once(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_extensions.php');

class AceSEFTools {
	
	var $params;
	var $acesef_config = null;
	
	function AceSEFTools() {		
		// Read the configuration file
		require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
		$this->acesef_config = new acesef_configuration();
		
		$class = get_class($this);
        if (substr($class, 0, 7) == 'AceSEF_') {
			$component = substr($class, 7);
			$this->params = AceSEFTools::getExtParams($component);
		}
	}
	
	// Make changes on URI before building route
	function beforeBuildRoute(&$uri) {
        return;
    }
	
	// Build Route
	function buildRoute(&$uri) {
        $vars = $uri->getQuery(true);
        extract($vars);
		
		$title = array();
        return;
    }
	
	// Make changes on URI after the route is built
	function afterBuildRoute(&$uri) {
        return;
    }
	
	// Meta Tags
	function metaTags(&$uri) {
        $vars = $uri->getQuery(true);
        extract($vars);
		
		$meta = array();
        return;
    }
	
	// Get non-SEF variables
	function nonSefVars(&$uri) {
        return;
    }
	
	// Clear texts from unwanted chars
	function cleanText($text) {
		$text = str_replace('&amp;', '&', $text);
		$text = preg_replace(array('/&quot;/', '/&nbsp;/', '/&lt;/', '/&gt;/', '/&copy;/', '/&amp;/', '/&euro;/', '/&hellip;/'), '', $text);
		$text = preg_replace("'<script[^>]*>.*?</script>'si", '', $text);
		$text = preg_replace('/<a\s+.*?href="([^"]+)"[^>]*>([^<]+)<\/a>/is', '\2 (\1)', $text);
		$text = preg_replace('/<!--.+?-->/', '', $text);
		$text = preg_replace('/{.+?}/', '', $text);
		$text = preg_replace('(\{.*?\})', '', $text);
		$text = preg_replace('/\s\s+/', ' ', $text);
		$text = preg_replace('/\n\n+/s', '', $text);
		$text = strip_tags($text);
		$text = htmlspecialchars($text);
        $text = trim($text);
		$text = str_replace("  ", " ",$text);
		$text = str_replace(array('\r\n', '\r', '\n', '\t', '\n\n', '"', '<', '>', ';', ':', '\'', '#', '`', '�', '�', '�'), '', $text);
		$text = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $text);
		
        return $text;
    }
	
	// Clip text to use as meta description
	function clipDesc($text, $limit) {
		// First, cleanup text
		$text = AceSEFTools::cleanText($text);
		
		// Clip text
        if(strlen($text) > $limit) {
            $text = substr($text, 0, $limit);
            $pos = strrpos($text, ' ');
            if ($pos !== false) {
                $text = substr($text, 0, $pos - 1);
            }
            $text = trim($text);
        }
		
		return $text;
	}
	
	// Generate for metatags
	function generateKeywords($text, $blacklist, $count, $minLength) {
		// Remove any email addresses
		$regex = '/(([_A-Za-z0-9-]+)(\\.[_A-Za-z0-9-]+)*@([A-Za-z0-9-]+)(\\.[A-Za-z0-9-]+)*)/iex';
		$text = preg_replace($regex, '', $text);
		
		// Some unwanted replaces
        $text = preg_replace('/<[^>]*>/', ' ', $text);	
		$text = preg_replace('/[\.;:|\'|\"|\`|\,|\(|\)|\-]/', ' ', $text);
		
		// Lowercase the strings		
		$text = JString::strtolower($text);
        
		// Sort words from up to down
		$keysArray = explode(" ", $text);
		$keysArray = array_count_values($keysArray);
		
		// Check if blacklist is null
		if(is_null($blacklist)) {
		    $blacklist = "a, able, about, above, abroad, according, accordingly, across, actually, adj, after, afterwards, again, against, ago, ahead, ain't, all, allow, allows, almost, alone, along, alongside, already, also, although, always, am, amid, amidst, among, amongst, an, and, another, any, anybody, anyhow, anyone, anything, anyway, anyways, anywhere, apart, appear, appreciate, appropriate, are, aren't, around, as, a's, aside, ask, asking, associated, at, available, away, awfully, b, back, backward, backwards, be, became, because, become, becomes, becoming, been, before, beforehand, begin, behind, being, believe, below, beside, besides, best, better, between, beyond, both, brief, but, by, c, came, can, cannot, cant, can't, caption, cause, causes, certain, certainly, changes, clearly, c'mon, co, co., com, come, comes, concerning, consequently, consider, considering, contain, containing, contains, corresponding, could, couldn't, course, c's, currently, d, dare, daren't, definitely, described, despite, did, didn't, different, directly, do, does, doesn't, doing, done, don't, down, downwards, during, e, each, edu, eg, eight, eighty, either, else, elsewhere, end, ending, enough, entirely, especially, et, etc, even, ever, evermore, every, everybody, everyone, everything, everywhere, ex, exactly, example, except, f, fairly, far, farther, few, fewer, fifth, first, five, followed, following, follows, for, forever, former, formerly, forth, forward, found, four, from, further, furthermore, g, get, gets, getting, given, gives, go, goes, going, gone, got, gotten, greetings, h, had, hadn't, half, happens, hardly, has, hasn't, have, haven't, having, he, he'd, he'll, hello, help, , hence, her, here, hereafter, hereby, herein, here's, hereupon, hers, herself, he's, hi, him, himself, his, hither, hopefully, how, howbeit, however, hundred, i, i'd, ie, if, ignored, i'll, i'm, immediate, in, inasmuch, inc, inc., indeed, indicate, indicated, indicates, inner, inside, insofar, instead, into, inward, is, isn't, it, it'd, it'll, its, it's, itself, i've, j, just, k, keep, keeps, kept, know, known, knows, l, last, lately, later, latter, latterly, least, less, lest, let, let's, like, liked, likely, likewise, little, look, looking, looks, low, lower, ltd, m, made, mainly, make, makes, many, may, maybe, mayn't, me, mean, meantime, meanwhile, merely, might, mightn't, mine, minus, miss, more, moreover, most, mostly, mr, mrs, much, must, mustn't, my, myself, n, name, namely, nd, near, nearly, necessary, need, needn't, needs, neither, never, neverf, neverless, nevertheless, new, next, nine, ninety, no, nobody, non, none, nonetheless, noone, no-one, nor, normally, not, nothing, notwithstanding, novel, now, nowhere, o, obviously, of, off, often, oh, ok, okay, old, on, once, one, ones, one's, only, onto, opposite, or, other, others, otherwise, ought, oughtn't, our, ours, ourselves, out, outside, over, overall, own, p, particular, particularly, past, per, perhaps, placed, please, plus, possible, presumably, probably, provided, provides, q, que, quite, qv, r, rather, rd, re, really, reasonably, recent, recently, regarding, regardless, regards, relatively, respectively, right, round, s, said, same, saw, say, saying, says, second, secondly, , see, seeing, seem, seemed, seeming, seems, seen, self, selves, sensible, sent, serious, seriously, seven, several, shall, shan't, she, she'd, she'll, she's, should, shouldn't, since, six, so, some, somebody, someday, somehow, someone, something, sometime, sometimes, somewhat, somewhere, soon, sorry, specified, specify, specifying, still, sub, such, sup, sure, t, take, taken, taking, tell, tends, th, than, thank, thanks, thanx, that, that'll, thats, that's, that've, the, their, theirs, them, themselves, then, thence, there, thereafter, thereby, there'd, therefore, therein, there'll, there're, theres, there's, thereupon, there've, these, they, they'd, they'll, they're, they've, thing, things, think, third, thirty, this, thorough, thoroughly, those, though, three, through, throughout, thru, thus, till, to, together, too, took, toward, towards, tried, tries, truly, try, trying, t's, twice, two, u, un, under, underneath, undoing, unfortunately, unless, unlike, unlikely, until, unto, up, upon, upwards, us, use, used, useful, uses, using, usually, v, value, various, versus, very, via, viz, vs, w, want, wants, was, wasn't, way, we, we'd, welcome, well, we'll, went, were, we're, weren't, we've, what, whatever, what'll, what's, what've, when, whence, whenever, where, whereafter, whereas, whereby, wherein, where's, whereupon, wherever, whether, which, whichever, while, whilst, whither, who, who'd, whoever, whole, who'll, whom, whomever, who's, whose, why, will, willing, wish, with, within, without, wonder, won't, would, wouldn't, x, y, yes, yet, you, you'd, you'll, your, you're, yours, yourself, yourselves, you've, z, zero";
		}
		
		$blackArray = explode(",", $blacklist);
		
	    foreach($blackArray as $blackWord){
		    if(isset($keysArray[trim($blackWord)])){
				unset($keysArray[trim($blackWord)]);
			}
		}
		
		arsort($keysArray);
		
		$i = 1;
		$keywords = "";
		foreach($keysArray as $word => $instances){
			if($i > $count){
				break;
			}
			if(strlen(trim($word)) >= $minLength ) {
				$keywords .= $word . ", ";
				$i++;
			}
		}
		
		$keywords = rtrim($keywords, ", ");
		return $keywords;
    }
	
	// Define title or alias
	function urlPart($param) {
        if(($param == 'title') || ($param == 'global' && $this->acesef_config->title_alias == 'title')) {
            return 'title';
        }
        return 'alias';
    }
	
	// Define numeral duplicated
	function numeralDuplicated($param) {
        if(($param == 'yes') || ($param == 'global' && $this->acesef_config->numeral_duplicated == '1')) {
            return true;
        }
        return false;
    }
	
	// Define record duplicated
	function recordDuplicated($param) {
        if(($param == 'yes') || ($param == 'global' && $this->acesef_config->record_duplicated == '1')) {
            return true;
        }
        return false;
    }
	
	// Define meta title generation
	function autoTitle($param) {
        if(($param == 'no') || ($param == 'global' && $this->acesef_config->meta_title == '0')) {
            return false;
        }
        return true;
    }
	
	// Define meta desc generation
	function autoDesc($param) {
        if(($param == 'no') || ($param == 'global' && ($this->acesef_config->meta_desc == '2' || $this->acesef_config->meta_desc == '3'))) {
            return false;
        }
        return true;
    }
	
	// Define meta title generation
	function autoKey($param) {
        if(($param == 'no') || ($param == 'global' && ($this->acesef_config->meta_key == '2' || $this->acesef_config->meta_key == '3'))) {
            return false;
        }
        return true;
    }
	
	function setMetaData($acesef_title, $acesef_desc, $acesef_key) {
		global $mainframe;
		$meta 	= array();
		$config	= & JFactory::getConfig();
		
		$meta_title			= AceSEFTools::autoTitle($this->params->get('meta_title', 'global'));
		$meta_desc			= AceSEFTools::autoDesc($this->params->get('meta_desc', 'global'));
		$meta_key			= AceSEFTools::autoKey($this->params->get('meta_key', 'global'));
		$separator			= $this->params->get('separator', '-');
		$sitename			= $config->getValue('sitename');
		$custom_sitename	= $this->params->get('custom_sitename', '');
		$use_sitename		= $this->params->get('use_sitename', '2');
		$title_prefix		= $this->params->get('title_prefix', '');
		$title_suffix		= $this->params->get('title_suffix', '');
		
		$title = $desc = $key = "";
		
		// Prepare meta title
		if(!empty($acesef_title)){			
			if(!empty($custom_sitename)){
				$sitename = $custom_sitename;
			}
			
			if($use_sitename == 1){
				$acesef_title = $sitename." ".$separator." ".$acesef_title;
			} elseif ($use_sitename == 2){
				$acesef_title = $acesef_title." ".$separator." ".$sitename;
			}
			
			if(!empty($title_prefix)){
				$acesef_title = $title_prefix." ".$separator." ".$acesef_title;
			}
			
			if(!empty($title_suffix)){
				$acesef_title = $acesef_title." ".$separator." ".$title_suffix;
			}
		}
		
		// Set extension metadata
		$mainframe->set('acesef.meta.autodesc', $acesef_desc);
		$mainframe->set('acesef.meta.autokey', $acesef_key);
		
		// Meta title
		if($meta_title){
			$title = $acesef_title;
		}
		
		// Meta description
		if($meta_desc){
			$desc = $acesef_desc;
		}
		
		// Meta keywords
		if($meta_key){
			$key = $acesef_key;
		}
		
		// Set metadata
		$meta['metatitle']	= $title;
		$meta['metadesc']	= $desc;
		$meta['metakey']	= $key;
		
		return $meta;
	}
	
	// Meta title
	function pluginMetaTitle($url_id, $org_title, $db_title){
		// Modify original title
		$modified_title = $org_title;
		if(!empty($modified_title)){
			// Get original title values
			$config				= &JFactory::getConfig();
			$separator			= $this->acesef_config->meta_t_seperator;
			$sitename			= $config->getValue('sitename');
			$custom_sitename	= $this->acesef_config->meta_t_sitename;
			$use_sitename		= $this->acesef_config->meta_t_usesitename;
			$title_prefix		= $this->acesef_config->meta_t_prefix;
			$title_suffix		= $this->acesef_config->meta_t_suffix;
		
			if(!empty($custom_sitename)){
				$sitename = $custom_sitename;
			}
			
			if($use_sitename == 1){
				$modified_title = $sitename." ".$separator." ".$modified_title;
			} elseif ($use_sitename == 2){
				$modified_title = $modified_title." ".$separator." ".$sitename;
			}
			
			if(!empty($title_prefix)){
				$modified_title = $title_prefix." ".$separator." ".$modified_title;
			}
			
			if(!empty($title_suffix)){
				$modified_title = $modified_title." ".$separator." ".$title_suffix;
			}
		}
		
		if(empty($db_title)){
			AceSEFTools::pluginStoreMeta($url_id, 'metatitle', $modified_title);
			return $modified_title;
		} else {
			return $db_title;
		}
	}
	
	// Meta Description
	function pluginMetaDesc($url_id, $org_desc, $db_desc, $auto_desc){		
		// Let's play
		if($this->acesef_config->meta_desc == '1' || $this->acesef_config->meta_desc == '3'){
			// Get global description
			$config	= & JFactory::getConfig();
			$global_desc = $config->getValue('MetaDesc');
			
			// Clean out original description if they're global description
			if($org_desc == $global_desc){
				$org_desc = '';
			}
			
			$desc1 = $desc2 = '';
			if($this->acesef_config->meta_desc == '1'){
				$desc1 = $auto_desc;
				$desc2 = $org_desc;
			} else {
				$desc1 = $org_desc;
				$desc2 = $auto_desc;
			}
			if(empty($db_desc)){
				if(empty($desc1)){
					AceSEFTools::pluginStoreMeta($url_id, 'metadesc', $desc2);
					return $desc2;
				} else {
					AceSEFTools::pluginStoreMeta($url_id, 'metadesc', $desc1);
					return $desc1;
				}
			} else {
				return $db_desc;
			}
		} else {
			if(empty($db_desc)){
				AceSEFTools::pluginStoreMeta($url_id, 'metadesc', $org_desc);
				return $org_desc;
			} else {
				return $db_desc;
			}
		}
	}
	
	// Meta Keywords
	function pluginMetaKey($url_id, $org_key, $db_key, $auto_key){
		// Let's play
		if($this->acesef_config->meta_key == '1' || $this->acesef_config->meta_key == '3'){
			// Get global keywords
			$config	= & JFactory::getConfig();
			$global_key = $config->getValue('MetaKeys');
			
			// Clean out original keywords if they're global keywords
			if($org_key == $global_key){
				$org_key = '';
			}
			
			$key1 = $key2 = '';
			if($this->acesef_config->meta_key == '1'){
				$key1 = $auto_key;
				$key2 = $org_key;
			} else {
				$key1 = $org_key;
				$key2 = $auto_key;
			}
			if(empty($db_key)){
				if(empty($key1)){
					AceSEFTools::pluginStoreMeta($url_id, 'metakey', $key2);
					return $key2;
				} else {
					AceSEFTools::pluginStoreMeta($url_id, 'metakey', $key1);
					return $key1;
				}
			} else {
				return $db_key;
			}
		} else {
			if(empty($db_key)){
				AceSEFTools::pluginStoreMeta($url_id, 'metakey', $org_key);
				return $org_key;
			} else {
				return $db_key;
			}
		}
	}
	
	// Store metadata
	function pluginStoreMeta($id, $tag, $value){
		if(!empty($id)){
			$db =& JFactory::getDBO();
			$db->setQuery("UPDATE #__acesef_urls SET ".$tag." = '".AceSEFTools::cleanText($value)."' WHERE id=".$id);
			$db->query();
		}
	}
	
	// Remove : part from a single string variable
	function fixVar($var) {
        if(!is_null($var)) {
            $pos = strpos($var, ':');
            if($pos !== false){
                $var = substr($var, 0, $pos);
			}
        }
		return $var;
    }
	
	// Remove : part from a single URI variable
	function fixUriVar(&$uri, $var) {
        $value = $uri->getVar($var);
        if(!is_null($value)) {
            $pos = strpos($value, ':');
            if($pos !== false) {
                $value = substr($value, 0, $pos);
                $uri->setVar($var, $value);
            }
        }
    }
	
	// Get menu params for components that doesnt include id's in URL but in menu params
	function getMenuParams($option, $Itemid = null) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
		$db =& JFactory::getDBO();
		if(!empty($Itemid)){
            $query = "SELECT `params`$joomfish FROM `#__menu` WHERE `id` = '$Itemid' AND `published` > 0";
        } else {
            $query = "SELECT `params`$joomfish FROM `#__menu` WHERE `link` = 'index.php?option=$option' AND `published` > 0";
		}
		
        $db->setQuery($query);
        $row = $db->loadObject();
		
		if(!empty($row)){
			$menu->params = new JParameter($row->params);
        } elseif (!isset($Itemid)) {
			// Try to extend the search for any link to component
			$db->setQuery("SELECT `params`$joomfish FROM `#__menu` WHERE `link` LIKE 'index.php?option=$option%' AND `published` > 0");
			$row = $db->loadObject();
			$menu->params = new JParameter($row->params);
        }

		return $menu;
    }
	
	// Get Menu title
	function getMenuTitle($option, $id = null) {
        $db =& JFactory::getDBO();
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
		// Title or Alias
		$part = 'name';
		if($this->acesef_config->menu_url_part == 'alias'){
			$part = 'alias';
		}
		
		// Grab the result
		if(!empty($id)){
            $sql = "SELECT `$part` AS `name`$joomfish FROM `#__menu` WHERE `id` = '$id' AND `published` > 0";
        } else {
            $sql = "SELECT `$part` AS `name`$joomfish FROM `#__menu` WHERE `link` = 'index.php?option=$option' AND `published` > 0";
		}
		
        $db->setQuery($sql);
        $row = $db->loadObject();
		
		if (!empty($row) && !empty($row->name)) {
			$title = $row->name;
        } else {
            $title = str_replace('com_', '', $option);
            if (!isset($id)) {
                // Try to extend the search for any link to component
                $sql = "SELECT `$part` AS `name`$joomfish FROM `#__menu` WHERE `link` LIKE 'index.php?option=$option%' AND `published` > 0";
                $db->setQuery($sql);
                $row = $db->loadObject();
                if (!empty($row) && !empty($row->name)){
					$title = $row->name;
				}
            }
        }
        
        return $title;
    }
	
	// Get Extension Parameters
	function &getExtParams($option) {
        $db =& JFactory::getDBO();

        static $exts, $params;

        if(!isset($exts)) {
            $query = "SELECT extension, params FROM #__acesef_extensions";
            $db->setQuery($query);
            $exts = $db->loadObjectList('extension');
        }

        if(!isset($params)) {
            $params = array();
        }
		
        if(!isset($params[$option])) {
            $data = '';
            if(isset($exts[$option])) {
                $data = $exts[$option]->params;
            }
            $params[$option] = new JParameter($data);
			
            // Set the extension's parameters renderer
            $pxml =& AcesefTools::getExtParamsXML($option);
            if(is_a($pxml, 'JSimpleXMLElement')) {
                $params[$option]->setXML($pxml);
            }
        }

        return $params[$option];
    }
    
    // Get Parameters
	function &getExtParamsXML($option) {
        static $xmls;

        if(!isset($xmls)) {
            $xmls = array();
        }

        if(!isset($xmls[$option])) {
            $xmls[$option] = null;

            $xml =& AcesefTools::getExtXML($option);

            if($xml) {
                $document =& $xml->document;
                if(isset($document->params[0]->param)){
                    $xmls[$option] =& $document->params[0];
				}
            }
        }

        return $xmls[$option];
    }

    // Get the extensions XML object
	function &getExtXML($extension) {
        static $xmls;

        if(!isset($xmls)) {
            $xmls = array();
        }

        if(!isset($xmls[$extension])) {
            $xmls[$extension] = null;

            $xmlFile = JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.$extension.'.xml';
            if(JFile::exists($xmlFile)) {
                $xmls[$extension] = JFactory::getXMLParser('Simple');
                if(!$xmls[$extension]->loadFile($xmlFile)) {
                    $xmls[$extension] = null;
                }
            }
        }
		
        return $xmls[$extension];
    }
}
?>