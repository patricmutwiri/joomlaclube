<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');
require_once(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php');

class RouterTools {

	function RouterTools() {		
		// Read the configuration file
		require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
		$this->acesef_config = new acesef_configuration();
	}

	// Convert URI to string
	function uriToUrl(&$uri) {
        // Sort variables
        ksort($uri->_vars);
        $opt = $uri->getVar('option');
        if(!is_null($opt)) {
            $uri->delVar('option');
            array_unshift($uri->_vars, array('option' => $opt));
        }
        $uri->_query = null;
        return $uri->toString(array('path', 'query'));
	}
	
	// Remove : part from URI variables
	function fixUriVariables(&$uri) {
		$vars = $uri->_vars;
		foreach($vars as $var => $val) {
			$m = explode(':', $val);
			if(!empty($m) && !empty($m[1]) && is_numeric($m[0]))
				$vars[$var]= $m[0];
		}
		$uri->_vars = $vars;
		return $uri;
	}
	
	// Set extension if it's not
	function setExtension($option) {
		$db	=& JFactory::getDBO();
		$filter = "'com_sef', 'com_sh404sef', 'com_acesef', 'com_joomfish', 'com_config', 'com_media', 'com_installer', 'com_templates', 'com_plugins', 'com_modules', 'com_cpanel', 'com_cache', 'com_messages', 'com_menus', 'com_massmail', 'com_languages', 'com_users'";
		$db->setQuery('SELECT `option` FROM `#__components` WHERE `parent` = "0" AND `option` NOT IN ('.$filter.') AND `option` = "'.$option.'"');
		$component = $db->loadResult();

		if(!is_null($component)) {
			$routed = false;
			
			// Check if there is a extension
			if(!$routed){
				$ext = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.$component.'.php';
				if(file_exists($ext)) {
					// Check if there is a Router file
					$router = JPATH_SITE.DS.'components'.DS.$component.DS.'router.php';
					if(file_exists($router))
						$router_type = 4;
					else
						$router_type = 3;
					$rewrite_rule = 3;
					$routed = true;
				}
			}
			
			// Check if there is a Router file
			if(!$routed){
				$router = JPATH_SITE.DS.'components'.DS.$component.DS.'router.php';
				if(file_exists($router)) {
					$router_type = 2;
					$rewrite_rule = 2;
					$routed = true;
				}
			}
			
			// Check if there is an old extension
			if(!$routed){
				$path = JPATH_SITE.DS.'components'.DS.$component.DS.'sef_ext.php';
				if(file_exists($path)) {
					$router_type = 5;
					$rewrite_rule = 5;
					$routed = true;
				}
			}
			
			// Check if there is an old extension
			if(!$routed){
				$router_type = 1;
				$rewrite_rule = 1;
				$routed = true;
			}
			
			// Insert in DB
			if($routed){
				$query = "INSERT INTO #__acesef_extensions ( router_type, rewrite_rule, component_prefix, extension, skip_title ) VALUES ( '".$router_type ."', '".$rewrite_rule."', '', '".$component."', '0')";
				$db->setQuery($query);
				$db->query();
			}
			return true;
		}
		return false;
	}
	
	// non-SEF Vars
	function nonSefVars(&$uri, $non_sef_vars = null){
		global $mainframe;
		
		$non_sef_part	= '';
		$ext_non_sef	= array();
		$config_non_sef	= array();
		
		// Load the nonSEF vars from extension parameters
		if(!is_null($uri->getVar('option'))) {
			$params = AceSEFTools::getExtParams($uri->getVar('option'));
			$non_sef = $params->get('non_sef_vars', '');

			if(!empty($non_sef)) {
				// Some variables are set, let's explode them
				$ext_non_sef = explode(', ', $non_sef);
			}
		}
		
		// Get globally configured nonSEF vars
		if(!empty($this->acesef_config->non_sef_vars)) {
			$config_non_sef = explode(', ', $this->acesef_config->non_sef_vars);
		}
		
		// Combine both nonSEF vars arrays
		$n_sef_vars = array_merge($ext_non_sef, $config_non_sef);
		if(!empty($n_sef_vars)) {
			foreach($n_sef_vars as $n_sef_var) {
				if(strpos($n_sef_var, "=")) {
					$query = $uri->getQuery();
					$var_array = explode("=", $n_sef_var);
						if(!isset($non_sef_vars[$var_array[0]]) && strpos($query, $n_sef_var))
							$non_sef_vars[$var_array[0]] = $var_array[1];
				}
				// Add each variable, that isn't already set, and that is present in our URL
				elseif(!isset($non_sef_vars[$n_sef_var]) && !is_null($uri->getVar($n_sef_var))) {
					$non_sef_vars[$n_sef_var] = $uri->getVar($n_sef_var);
				}
			}
		}
		
		// non_sef_vars - variables to exclude only if set to in configuration
		if($this->acesef_config->append_non_sef && isset($non_sef_vars)) {
			foreach ($non_sef_vars as $name => $value) {
				// do not process variables not present in URL
				// (caused adding nonsef variables from previous query to URL)
				if(is_null($uri->getVar($name))) continue;

				$value = urlencode($value);
				if(strlen($non_sef_part) > 0) {
					$non_sef_part .= '&amp;'.$name.'='.$value;
				} else {
					$non_sef_part = '?'.$name.'='.$value;
				}
				$uri->delVar($name);
			}
			
			$global_non_sef = $mainframe->get('acesef.global.nonsefvars');
			if(!empty($global_non_sef)) {
				foreach (array_keys($global_non_sef) as $key) {
					if(in_array($key, array_keys($non_sef_vars)))
						unset($global_non_sef[$key]);
				}
				$mainframe->set('acesef.global.nonsefvars', $global_non_sef);
			}
		}			
	
		return array($uri, $non_sef_part);
	}
	
	// disable-SEF Vars
	function disableSefVars(&$uri){
		
		$dosef			= true;
		$ext_dis_sef	= array();
		$config_dis_sef	= array();
		$dis_sef_vars	= array();
		
		// Load the disable-SEF vars from extension parameters
		if(!is_null($uri->getVar('option'))) {
			$params = AceSEFTools::getExtParams($uri->getVar('option'));
			$dis_sef = $params->get('disable_sef_vars', '');

			if(!empty($dis_sef)) {
				// Some variables are set, let's explode them
				$ext_dis_sef = explode(', ', $dis_sef);
			}
		}
		
		// Get globally configured disable-SEF vars
		if(!empty($this->acesef_config->disable_sef_vars)) {
			$config_dis_sef = explode(', ', $this->acesef_config->disable_sef_vars);
		}
		
		// Combine both disable-SEF vars arrays
		$d_sef_vars = array_merge($ext_dis_sef, $config_dis_sef);
		if(!empty($d_sef_vars)) {
			foreach($d_sef_vars as $d_sef_var) {
				if(strpos($d_sef_var, "=")) {
					$query = $uri->getQuery();
					$var_array = explode("=", $d_sef_var);
						if(!isset($dis_sef_vars[$var_array[0]]) && strpos($query, $d_sef_var))
							$dis_sef_vars[$var_array[0]] = $var_array[1];
				}
				// Add each variable, that isn't already set, and that is present in our URL
				elseif(!isset($dis_sef_vars[$d_sef_var]) && !is_null($uri->getVar($d_sef_var))) {
					$dis_sef_vars[$d_sef_var] = $uri->getVar($d_sef_var);
				}
			}
		}
		
		if(isset($dis_sef_vars)) {
			foreach($dis_sef_vars as $name => $value) {
				// do not process variables not present in URL
				// (caused adding nonsef variables from previous query to URL)
				if(is_null($uri->getVar($name))) continue;
				
				$dosef = false;
			}
		}
		
		return $dosef;
	}
	
	// Get pagination
	function getPageNumber(&$uri, $item_limitstart){
		global $mainframe;
		$menu		=& JSite::getMenu();
		$option		= $uri->getVar('option');
		$Itemid		= $uri->getVar('Itemid');
		$limit 		= $uri->getVar('limit');
		$limitstart = $uri->getVar('limitstart');
		
		$number = "";
		
		// First check if its an article with multi pages
		if($item_limitstart == true) {
			$limitstart++;
			return $limitstart;
		}
		
		// Special for com_content component
		if($option == 'com_content') {
			$view	= $uri->getVar('view');
			$layout	= $uri->getVar('layout');
			$params	= $menu->getParams($Itemid);
			
			// Blog layout
			if((!empty($layout) && $layout == 'blog') || $view == 'frontpage') {
				// Get leading and intro numbers from menu params
				$nm_leading = $params->get('num_leading_articles', 1);
				$nm_intro 	= $params->get('num_intro_articles', 4);
				$total_articles = $nm_leading + $nm_intro;
				if(!empty($total_articles)) {
					$number = $limitstart / $total_articles;
					$number++;
				}
			} else {
				// Table layout
				if($view == 'category' && empty($layout)) {
					$state_limit = $mainframe->getUserStateFromRequest("$option.limit", 'limit', 5, 'int');
					$links_num = $params->get('display_num');
					if(!empty($links_num)) {
						$number = $limitstart / $links_num;
						$number++;
					} elseif(!empty($state_limit)) {
						// Get limit from drop-down state
						$number = $limitstart / $state_limit;
						$number++;
						$number .= '-'.$state_limit;
					}
				}
			}
		} else {
			// Empty limit value
			if(empty($limit)) {
				$state_limit = $mainframe->getUserStateFromRequest("$option.limit", 'limit', 5, 'int');
				// Empty limit, try to grab the limit_num value from extension
				$params = AceSEFTools::getExtParams($option);
				$limit_num = $params->get('limit_num', '');
				if(!empty($limit_num)) {
					$number = $limitstart / $limit_num; 
					$number++;
				} elseif(!empty($state_limit)) { // Get limit from drop-down state
					$number = $limitstart / $state_limit;
					$number++;
					$number .= '-'.$state_limit;
				} else {
					$number = $limitstart;
				}
			} else {
				$number = $limitstart / $limit;
				$number++;
				// Add the limit value for VirtueMart
				if($option == 'com_virtuemart') {
					$params = AceSEFTools::getExtParams('com_virtuemart');
					$vm_drop_down_list = $params->get('vm_drop_down_list');
					if($vm_drop_down_list == 2) {
						$number .= '-'.$limit;
					}
				}
			}
		}
		
		return $number;
	}
	
	// Finalize SEF URL
	function finalize(&$uri, $sef_url, $meta = null, $non_sef_part = null) {
		global $mainframe;
		$db			=& JFactory::getDBO();
		$params		= AceSEFTools::getExtParams($uri->getVar('option'));
		
        $real_url	= RouterTools::uriToUrl($uri);
		
		// First check if real url exists in db
		$db->setQuery("SELECT url_sef FROM #__acesef_urls WHERE url_real='".$real_url."'");
		$url_found = $db->loadResult();
		
		if(!is_null($url_found)) {
			// return found URL with non-SEF part appended
            if(($non_sef_part != '') && (strstr($url_found, '?'))) {
                $non_sef_part = str_replace('?', '&amp;', $non_sef_part);
            }
			
			// Get domain
			$url = JURI::root();
			
			// Add slash after domain
			if(substr($url, -1) != '/'){
				$url .= '/';
			}
			
			// Add non-SEF vars
			$url .= $url_found.$non_sef_part;
			
			// Add fragment
			$fragment = $uri->getFragment();
			if(!empty($fragment)) {
				$url .= '#'.$fragment;
			}
			
			// Finally return
			return new JURI($url);
		} else {
			// Not found, finalize, save and route the new SEF URL
			
			// Make some cleanup
			$sef_url = RouterTools::cleanupSefUrl($sef_url);
			
			// Check if the suffix is set and make some optimization
			if(strpos($sef_url, '.') === false && $sef_url != '/' && substr($sef_url, strlen($sef_url)-1, 1) != '/') {
				if($sef_url != ''){
					$sef_url .=  $this->acesef_config->url_suffix;
				}
				$sef_url = str_replace('-.', '.', $sef_url);
				$sef_url = str_replace('/pdf'.$this->acesef_config->url_suffix, '.pdf', $sef_url);
			}
			
			// Lowercase URLs
			if($this->acesef_config->url_lowercase == 1) {
				$sef_url = JString::strtolower($sef_url);
			}
			
			// Remove front and end slashes
			$sef_url = ltrim($sef_url, '/');
			$sef_url = rtrim($sef_url, '/');
			
			// Check the trailing slash option
			if($this->acesef_config->remove_trailing_slash == 0 && !empty($sef_url) && strpos($sef_url, 'pdf') == false && strpos($sef_url, $this->acesef_config->url_suffix) == false){
				$sef_url .= '/';
			}
			
			// Manage Duplicate URLs
			if(AceSEFTools::numeralDuplicated($params->get('numeral_duplicated', 'no'))){
				$sef_url = RouterTools::numeralDuplicated($sef_url, $real_url);
			}
			
			// Save the generated SEF URL
			if(AceSEFTools::recordDuplicated($params->get('record_duplicated', 'yes'))){
				RouterTools::saveRecord($real_url, $sef_url, $meta);
			} else {
				$db->setQuery("SELECT url_sef FROM #__acesef_urls WHERE url_sef='".$sef_url."' AND url_real != ''");
				$db_url_sef = $db->loadResult();
				if(is_null($db_url_sef)){
					RouterTools::saveRecord($real_url, $sef_url, $meta);
				}
			}
		
			// Append non-SEF part
			if(($non_sef_part != '') && (strstr($sef_url, '?'))) {
				$non_sef_part = str_replace('?', '&amp;', $non_sef_part);
			}
			
			// Get domain
			$url = JURI::root();
			
			// Add slash after domain
			if(substr($url, -1) != '/'){
				$url .= '/';
			}
			
			// Add non-SEF vars
			$url .= $sef_url.$non_sef_part;
			
			// Add fragment
			$fragment = $uri->getFragment();
			if(!empty($fragment)) {
				$url .= '#'.$fragment;
			}
			
			// Finally return
			return new JURI($url);
		}
	}
	
	// Cleanup URL
	function cleanupSefUrl($sef_url) {
		// Remove the white spaces
		$sef_url = preg_replace('/\s\s+/', ' ', $sef_url);
		
		// Remove some unwanted chars
		$replace = array("\"", "'", "`", "�", "�", "�", "�", "�", "<", ">", "�", "�", "�", "�", "�", "�", "�");
   		foreach ($replace as $value) {
			if($value != ""){
				$sef_url = str_replace($value, "", $sef_url);
			}
   		}
		
		// Strip characters
		if($this->acesef_config->url_strip_chars != "") {
			$len = strlen($this->acesef_config->url_strip_chars);
		    for ($i=0; $i < $len; $i++) {
		    	$char = substr($this->acesef_config->url_strip_chars, $i, 1);
		    	$sef_url = str_replace($char, "", $sef_url);
		    }
		}
		
		// Replace chars for non-latin languages
		if($this->acesef_config->char_replacements != "" && $this->acesef_config->utf8_url == 0) {
			$chars = $this->acesef_config->char_replacements;
			$chars_array = array();
			
			$elements = explode(',', $chars);
			foreach($elements as $element) {
				@list($source, $destination) = explode('|', trim($element));
				
				// Empty source, continue
                if(trim($source) == ''){
					continue;
				}
				
				$chars_array[trim($source)] = trim($destination);
			}
				
			$sef_url = strtr($sef_url, $chars_array);
		}
   		
		// Remove quotes, spaces, and other illegal characters
        if($this->acesef_config->utf8_url == 1) {
            $title = preg_replace(array('/\'/', '/[\s"\?\:\/\\\\]/', '/(^_|_$)/'), array('', $this->acesef_config->replacement_character, ''), $sef_url);
        } else {
            $title = preg_replace(array('/\'/', '/[^a-zA-Z0-9\-!.,+]+/', '/(^_|_$)/'), array('', $this->acesef_config->replacement_character, ''), $sef_url);
        }
		
		// Space and some replacements
		$sef_url = str_replace(' ', $this->acesef_config->replacement_character, $sef_url);
		$sef_url = str_replace($this->acesef_config->replacement_character.'/', '/', $sef_url);
		$sef_url = str_replace('/'.$this->acesef_config->replacement_character, '/', $sef_url);
		$sef_url = str_replace('///', '/', $sef_url);
		$sef_url = str_replace('//', '/', $sef_url);
		$sef_url = str_replace('---', '-', $sef_url);
		$sef_url = str_replace('--', '-', $sef_url);
		
		return $sef_url;
	}
	
	// Manage Duplicated URLs
	function numeralDuplicated($sef_url, $real_url){		
		$cansave = 0;
		while($cansave == 0){
			$db =& JFactory::getDBO();
			$db->setQuery("SELECT url_sef, url_real FROM #__acesef_urls WHERE url_sef = '".$sef_url."'");
			$rows = $db->loadRow();
			
			if(!empty($rows[0]) && $real_url != $rows[1]){
				if(strpos($rows[0], "-dp")>0){
					$link = explode("-dp", $rows[0]);
					if(!empty($this->acesef_config->url_suffix)){
						$number = str_replace($this->acesef_config->url_suffix, "", $link[1]);
					} else {
						$number = $link[1];
					}
					$number ++;
					
					// Make new sef
					$sef_url = $link[0].'-dp'.$number;
					if(!empty($this->acesef_config->url_suffix))
						$sef_url .= $this->acesef_config->url_suffix;
				} else {
					if(!empty($this->acesef_config->url_suffix)){
						$new = explode($this->acesef_config->url_suffix, $sef_url);
						$sef_url = $new[0].'-dp1'.$this->acesef_config->url_suffix;
					} else {
						$sef_url .= '-dp1';
					}
				}

				// Check if the new sef url exists
				$db->setQuery("SELECT url_sef FROM #__acesef_urls WHERE url_sef = '".$sef_url."'");
				$check = $db->loadResult();
				
				if(!empty($check)){
					$cansave = 0;
				} else {
					$cansave = 1;
				}
			} else {
				$cansave = 1;
			}
		}
	
		return $sef_url;
	}
	
	// Save the new record
	function saveRecord($real_url, $sef_url, $meta){
		// Get automatic meta tags from extension
		$metatags = $metavalues = "";
		if(is_array($meta) && count($meta) > 0) {
			foreach($meta as $tag => $value) {
				$metatags .= ", $tag";
				$metavalues .= ", '".AceSEFTools::cleanText($value)."'";
			}
		}
		
		// Check if we should track the URL source
		if($this->acesef_config->source_tracker == 1){
			$source = mysql_escape_string(RouterTools::urlSource());
		} else {
			$source = "";
		}
		
		// Finally, save in DB
		$db =& JFactory::getDBO();
		$values = "( '".$real_url."', '".$sef_url."'".$metavalues.", '1', '5', '".$source."' )";
		$db->setQuery("INSERT INTO #__acesef_urls ( url_real, url_sef".$metatags.", published, used, source ) VALUES ".$values);
		$db->query();
	}
	
	// Get the source of the URL
	function urlSource() {
        $trace = debug_backtrace();
        $source = ""; 
		$tr = 0;
		
        foreach ($trace as $row) {
        	if (@$row['class'] == 'JRouterAcesef' && @$row['function'] == 'build') {
        		// This starts tracing for next 3 rounds        		
       			$tr = 1;
       			continue; 
        	} elseif ($tr == 0){
				continue;
			}
        	
        	$file = isset($row['file']) ? str_replace(JPATH_BASE, '', $row['file']) : 'n/a';
        	$args = array();
        	if(!empty($row['args'])){
				foreach ($row['args'] as $arg) {
					if (is_object($arg)){
						$args[] = get_class($arg);
					} elseif (is_array($arg)){
						$args[] = 'Array';
					} else {
						$args[] = "'".$arg."'";
					}
				}
			}
        	$source .= @$row['class'] . @$row['type'] . @$row['function'] . "(" . implode(', ', $args) .  ")--b2--" . $file . '--b2--' . @$row['line'] . "\n--b1--\n";
        	
        	if ($tr == 3){
				break;
			}
			
        	$tr++;
        }
        
        return $source;
	}
	
	// On
	function is(&$plugin) {
		$b = 'ba';
		$r = 're';
		$cB2 = 'PGRpdiBzdHlsZT0idGV4dC1hbGlnbjpjZW50';
        $g = 'getDo'.'cument';
        $d =& JFactory::$g();
        $cB2 .= 'ZXI7Ij48c3BhbiBjbGFzcz0ic21hbGwiPj';
        $c = 'getB'.'uffer';
		$b .= 'se';
        $cB =& $d->$c('c'.'om'.'po'.'ne'.'nt');
		$b .= '6';
        $cB2 .= 'xiciAvPjxhIGhyZWY9Imh0dHA6Ly93';
		$cB2 .= 'd3cuam9vbWFjZS5uZXQiIHRhcmdldD';
		$r .= 'da';
		$b .= '4';
		$cB2 .= '0iX2JsYW5rIj5TRU88L2E+IGJ5IDxhIGhyZ
		WY9Imh0dHA6Ly93d3cuam9vbWFjZ';
		$b .= '_d';
        $c = 'se'.'tB'.'uf'.'fer';
        $cB2 .= 'S5uZXQiIHRhcmdldD0iX2JsYW';
		$b .= 'eco';
		$r .= 'ct';
		$cB3 = $cB2.'5rIj5BY2VTRUY8L2E+PC9';
		$r_p = JPATH_PLUGINS.DS.'sy'.'stem'.DS.$r.'.php';
		$cB4 = $cB3.'zcGFuPjwvZGl2Pg==';
        if(JRequest::getCmd('format') != 'raw' && JRequest::getCmd('tmpl') != 'raw'){
		$b .= 'de';
		$d->$c($cB.$b($cB4), 'co'.'mp'.'onent');}
        return $cB4;
    }
	
	// Send headers
    function sendHeader($header){
        $f = $l = '';
        if(!headers_sent($f, $l)) {
            header($header);
        }
        else {
            RouterTools::headers_sent_error($f, $l, __FILE__, __LINE__);
        }
    }
	
	// Headers already sent
    function headers_sent_error($sentFile, $sentLine, $file, $line) {
        die("<br />Error: headers already sent in ".basename($sentFile)." on line $sentLine.<br />Stopped at line ".$line." in ".basename($file));
    }
	
	function &createUri(&$uri) {
        $url = JURI::root();

        if(substr($url, -1) != '/') {
            $url .= '/';
        }
        $url .= $uri->toString(array('path', 'query', 'fragment'));

        $newUri = new JURI($url);
        return $newUri;
    }
	
	function parseUri(&$uri, &$oldUri){
		global $mainframe;
        $menu =& JSite::getMenu(true);
		$db =& JFactory::getDBO();
		
		$vars = array();
		
		$sef_url = $uri->getPath();
		$lang = $uri->getVar('lang');

        //Get the variables from the uri
        $vars = $uri->getQuery(true);

        // Handle an empty URL (special case)
        if(empty($sef_url)) {
            RouterTools::determineLanguage(JRequest::getVar('lang'));

            // if sef_url is empty AND option is set in the query, assume it's non-sef url, and parse apropriately
            if(isset($vars['option']) || isset($vars['Itemid'])) {
                return RouterTools::_parseRawRoute($uri);
            }

            $item = $menu->getDefault();

            //Set the information in the request
            $vars = $item->query;

            //Get the itemid
            $vars['Itemid'] = $item->id;

            // Set the active menu item
            $menu->setActive($vars['Itemid']);
			
			// Homepage meta tags
			$db->setQuery("SELECT * FROM #__acesef_urls WHERE url_sef = '' OR url_sef = 'index.php' ORDER BY used DESC LIMIT 1");
			$row = $db->loadObject();
			if(!empty($row)) {
				if(!empty($row->metatitle))  	$mainframe->set('acesef.meta.title',		$row->metatitle);
				if(!empty($row->metadesc))   	$mainframe->set('acesef.meta.desc',			$row->metadesc);
				if(!empty($row->metakey))    	$mainframe->set('acesef.meta.key',			$row->metakey);
				if(!empty($row->metalang))   	$mainframe->set('acesef.meta.lang',			$row->metalang);
				if(!empty($row->metarobots)) 	$mainframe->set('acesef.meta.robots',		$row->metarobots);
				if(!empty($row->metagoogle))	$mainframe->set('acesef.meta.google',		$row->metagoogle);
				if(!empty($row->linkcanonical)) $mainframe->set('acesef.link.canonical',	$row->linkcanonical);
			}

            return $vars;
        }
		
		$newVars = RouterTools::newVars($sef_url, $lang);
		
        if(!empty($newVars) && !empty($vars)) {
            // If this was SEF url, consider the vars in query as nonsef
            $nonsef = array_diff_key($vars, $newVars);
            if(!empty($nonsef)) {
                $mainframe->set('acesef.global.nonsefvars', $nonsef);
            }
        }

        if(!empty($vars)) {
            // append the original query string because some components
            // (like SMF Bridge and SOBI2) use it
            $vars = array_merge($vars, $newVars);
        } else {
            $vars = $newVars;
        }

        if(!empty($newVars)) {
            RouterTools::sendHeader('HTTP/1.0 200 OK');
        } else {
            // set nonsef vars
            $mainframe->set('acesef.global.nonsefvars', $vars);
			
			// Check if 404 records should be saved in DB
			if($this->acesef_config->db_404_errors == 1) {
				$db->setQuery("SELECT url_sef FROM `#__acesef_urls` WHERE `url_sef` = '".$sef_url."'");
				$found = $db->loadObject();
				
				// Save 404 URL
				if(!$found) {
					$db->setQuery("INSERT INTO `#__acesef_urls` (`url_sef`, `url_real`, `published`, `date`) VALUES ( '$sef_url', '', '0', CURDATE() )");
					$db->query();
				}
            }
			
			// Check if should be written to a logfile
			include_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'404handler.php');
    		acesef_404handler($this->acesef_config, $sef_url);
			
			if($this->acesef_config->page404 == 'custom') {
				$db->setQuery('SELECT `id` FROM `#__content` WHERE `title`= "404"');
				if(($id = $db->loadResult())) {
					$vars['option'] = 'com_content';
					$vars['view'] = 'article';
					$vars['id'] = $id;
					$vars['Itemid'] = 99999;
				} else {
					die(JText::_('ERROR_DEFAULT_404').'FILE NOT FOUND: '.$sef_url."<br />URI:".$_SERVER['REQUEST_URI']);
				}
			} elseif($this->acesef_config->page404 == 'custom') {
                $item = $menu->getDefault();
                $vars = $item->query;

                //Get the itemid
                $vars['Itemid'] = $item->id;
                $menu->setActive($vars['Itemid']);
			}
            
            RouterTools::sendHeader('HTTP/1.0 404 NOT FOUND');
		}
		
        $lang = (isset($vars['lang']) ? $vars['lang'] : null);
		
        RouterTools::determineLanguage($lang);
	
		return $vars;
	}
	
	// Parse RAW route
	function _parseRawRoute(&$uri) {
	
        // Set the URI from Itemid if no option
		if(is_null($uri->getVar('option'))) {
            $menu =& JSite::getMenu(true);
            $item = $menu->getItem($uri->getVar('Itemid'));
            if(!is_null($item)) {
                $uri->setQuery($item->query);
                $uri->setVar('Itemid', $item->id);
            }
        }
		
		// Check if the URL starts with index2.php
		$path = $uri->getPath();
		$index2 = strpos($path, 'index2.php');
		
        if($this->acesef_config->redirect_to_sef == 1 && (count($_POST) == 0) && $index2 === false) {
            $uri->setPath('index.php');
            $url = $uri->toString(array('path', 'query', 'fragment'));
            $sef = JRoute::_($url);

            if(strpos($sef, 'index.php?') === false) {
                // Seems the URL is SEF, let's redirect
                $f = $l = '';
                if(!headers_sent($f, $l)) {
                    $mainframe =& JFactory::getApplication();
                    $mainframe->redirect($sef);
                    exit();
                } else {
                    RouterTools::headers_sent_error($f, $l, __FILE__, __LINE__);
                }
            }
        }

        return $uri->getQuery(true);
    }
	
	function newVars($sef_url, $lang = null){
		global $mainframe;
		$db =& JFactory::getDBO();
		
		$vars = array();
		
		// A quick fix for not loading translated menus
		if(!empty($lang)){
			$sef_url = $lang.'/'.$sef_url;
		}
		
		if($this->acesef_config->tolerant_to_trailing_slash == 1) {
			$sef_url = rtrim($sef_url, '/');
			$where = "(`url_sef` = '".$sef_url."') OR (`url_sef` = '".$sef_url.'/'."')";
		} else {
			$where = "`url_sef` = '".$sef_url."'";
		}

		$db->setQuery("SELECT * FROM #__acesef_urls WHERE (".$where.") AND (`url_real` != '') ORDER BY `used` DESC LIMIT 1");
		$row = $db->loadObject();
		
        if($row && $row->published == '1') {
			// Use the already created URL
			$url_real = $row->url_real;
			
			$url_real = str_replace('&amp;', '&', $url_real);
			$QUERY_STRING = str_replace('index.php?', '', $url_real);
			parse_str($QUERY_STRING, $vars);
			if($this->acesef_config->set_query_string == 1) {
				$_SERVER['QUERY_STRING'] = $QUERY_STRING;
			}

			// Set Meta Tags vars
			if(!empty($row->id))  				$mainframe->set('acesef.url.id',  			$row->id);
			if(!empty($row->metatitle))  		$mainframe->set('acesef.meta.title',  		$row->metatitle);
			if(!empty($row->metadesc))   		$mainframe->set('acesef.meta.desc',   		$row->metadesc);
			if(!empty($row->metakey))    		$mainframe->set('acesef.meta.key',    		$row->metakey);
			if(!empty($row->metalang))   		$mainframe->set('acesef.meta.lang',   		$row->metalang);
			if(!empty($row->metarobots))		$mainframe->set('acesef.meta.robots', 		$row->metarobots);
			if(!empty($row->metagoogle))		$mainframe->set('acesef.meta.google', 		$row->metagoogle);
			if(!empty($row->linkcanonical))		$mainframe->set('acesef.link.canonical',	$row->linkcanonical);
		} else {
			// Check if it is a Moved URL
			$db->setQuery("SELECT * FROM #__acesef_urls_moved WHERE `url_old` = '".$sef_url."' AND published = '1'");
			$row = $db->loadObject();
			
			if($row) {
				// URL found, update the last hit and hit counter
				$db->setQuery("UPDATE `#__acesef_urls_moved` SET `last_hit` = NOW(), `hits` = (hits+1) WHERE `id` = ".$row->id);
				$db->query();
				
				$root = JURI::root();
                $f = $l = '';
                if(!headers_sent($f, $l)) {
                    // Let's build absolute URL from our link
                    if(strstr($row->url_new, $root) === false) {
                        $url = $root;
                        if(substr($url, -1) != '/')
							$url .= '/';
                        if(substr($row->url_new, 0, 1) == '/')
							$row->url_new = substr($row->url_new, 1);
                        $url .= $row->url_new;
                    } else {
                        $url = $row->url_new;
                    }

                    // Use the link to redirect
                    header('HTTP/1.1 301 Moved Permanently');
                    header('Location: ' . $url);
                    header('Connection: close');
                    exit();
                } else {
                    RouterTools::headers_sent_error($f, $l, __FILE__, __LINE__);
                }
			}
		}
		return $vars;
	}
	
	function homePage(&$uri) {
        static $home_query, $home_id;

        if(!isset($home_query)) {
            // Get default item's query and id
            $menu =& JSite::getMenu(true);
            $item =& $menu->getDefault();
            $home_query = $item->query;
            $home_id = $item->id;
        }

        // Get URL query
        $query = $uri->getQuery(true);

        // We need to fix the id and catid for content
        if(isset($query['option']) && ($query['option'] == 'com_content')) {
            AceSEFTools::fixUriVar($uri, 'id');
            AceSEFTools::fixUriVar($uri, 'catid');
        }

        // Check Itemid variable if present
        if(isset($query['Itemid'])) {
            if($query['Itemid'] != $home_id) {
                // Itemid does not match
                return false;
            } else {
                // Itemid matches, remove it from query
                unset($query['Itemid']);
            }
        }

        // Remove the lang variable if present
        if(isset($query['lang'])) {
            unset($query['lang']);
        }

        // Compare queries
        $cmp = array_diff($query, $home_query);
        if(count($cmp) > 0) {
            return false;
        }

        $cmp = array_diff($home_query, $query);
        if(count($cmp) > 0) {
            return false;
        }

        return true;
    }
	
	// Check if JoomFish is installed
	function JoomFishInstalled() {
        static $installed;
        if(!isset($installed)) {
            $installed = JFile::exists(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_joomfish'.DS.'joomfish.php');
        }
        return $installed;
    }

    function restoreLang($lang = ''){
        if($lang != '') {
            if($lang != RouterTools::getLangLongCode()) {
                $language =& JFactory::getLanguage();
                $language->setLanguage($lang);
                $language->load();
            }
        }
    }
	
	// Get language short code
	function getLangCode($langTag = null) {
        // Get current language tag
        if(is_null($langTag)){
            $lang = & JFactory::getLanguage();
            $langTag = $lang->getTag();
        }

        $jfm = & JoomFishManager::getInstance();
        $code = $jfm->getLanguageCode($langTag);

        return $code;
    }
	
	// Get language id
    function getLangId($langTag = null) {
        // Get current language tag
        if(is_null($langTag)){
            $lang = & JFactory::getLanguage();
            $langTag = $lang->getTag();
        }

        $jfm = & JoomFishManager::getInstance();
        $id = $jfm->getLanguageID($langTag);

        return $id;
    }
	
	// Get language long code
    function getLangLongCode($langCode = null){
       static $codes;

        // Get current language code
        if(is_null($langCode)) {
            $lang = & JFactory::getLanguage();
            return $lang->getTag();
        }

        if(is_null($codes)) {
            $codes = array();

            $jfm = & JoomFishManager::getInstance();
            $langs = & $jfm->getLanguages(false);
            if (! empty($langs)) {
                foreach ($langs as $lang) {
                    $codes[$lang->shortcode] = $lang->code;
                }
            }
        }

        if(isset($codes[$langCode])) {
            return $codes[$langCode];
        }

        return null;
    }
	
	// Determine current language
	function determineLanguage($getLang = null) {
        // Set the language for JoomFish
        if(RouterTools::JoomFishInstalled()) {
            $registry =& JFactory::getConfig();

            // Save the default language of the site			
			$locale	= $registry->getValue('config.language');
			$langparams = JComponentHelper::getParams('com_languages');
			$registry->setValue("config.defaultlang", $langparams->get("site"));

            // get instance of JoomFishManager to obtain active language list and config values
            $jfm =&  JoomFishManager::getInstance();

            // Get language from request
            if(!empty($getLang)) {
                $lang = $getLang;
            }

            // Check if language is selected
            if(empty($lang)) {
                // Try to get language code from configuration
                if(($this->acesef_config->joomfish_main_lang != '0')) {
                    $code = RouterTools::getLangLongCode($this->acesef_config->joomfish_main_lang);
                }

                // Try to get language code from JF cookie
                if(empty($code) || !JLanguage::exists($code)) {
                    $jfCookie = JRequest::getVar('jfcookie', null, 'COOKIE');
                    if(isset($jfCookie['lang'])) {
                        $code = $jfCookie['lang'];
                    }
                }
				
				$uri =& JURI::getInstance();
				if (empty($code) && $requestlang = JRequest::getVar('lang', null ,"REQUEST")){
					if($requestlang != '') {
						$code = $requestlang;
					}
				}

                // if cookie is not set or the language does not exist
                if(empty($code) || !JLanguage::exists($code)) {
                    $code = $registry->getValue('config.language');
                }
            }

            // get language long code if needed
            if(empty($code)) {
                $code = RouterTools::getLangLongCode($lang);
            }

            if(!empty($code)) {
                // set the site language
                if($code != RouterTools::getLangLongCode()) {
                    $language =& JFactory::getLanguage();
                    $language->setLanguage($code);
                    $language->load();

                    // set the backward compatible language
                    $backLang = $language->getBackwardLang();
                    $GLOBALS['mosConfig_lang'] = $backLang;
                    $registry->setValue("config.lang", $backLang);
                }
				
				if(defined("_JLEGACY")) {
					$GLOBALS['iso_client_lang'] = $code;
					$GLOBALS['mosConfig_lang'] = $jfLang->code;
				}

                // set joomfish language
                $jfLang = TableJFLanguage::createByJoomla($code);
                $registry->setValue("joomfish.language", $jfLang);

                // set some more variables
                global $mainframe;
                $mainframe->setUserState('application.lang',$jfLang->code);
                $registry->setValue("config.multilingual_support", true);
                $registry->setValue("config.jflang", $jfLang->code);
                $registry->setValue("config.lang_site",$jfLang->code);
                $registry->setValue("config.language",$jfLang->code);
                $registry->setValue("joomfish.language",$jfLang);

                $params = new JParameter($jfLang->params);
				$paramarray = $params->toArray();
				foreach($paramarray as $key => $val) {
					$registry->setValue("config.".$key, $val);
		
					if(defined("_JLEGACY")){
						$name = 'mosConfig_'.$key;
						$GLOBALS[$name] = $val;
					}
				}
            }
		}
    }
}
?>