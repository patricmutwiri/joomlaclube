<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport('joomla.application.component.model');

// Extensions Model Class
class AcesefModelExtensions extends JModel {

	var $_query;
	var $_data 			= null;
	var $_total 		= null;
	var $_pagination 	= null;
	var $_xml			= null;
	
	// Main constructer
	function __construct()	{
		parent::__construct();
		
		global $mainframe, $option;
		
		$this->_buildViewQuery();

		// Get the pagination request variables
		$limit				= $mainframe->getUserStateFromRequest($option.'.extensions.limit', 	'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart			= $mainframe->getUserStateFromRequest($option.'.extensions.limitstart', 'limitstart', 0, 'int');
		
		// Limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		$this->setState($option.'.extensions.limit', $limit);
		$this->setState($option.'.extensions.limitstart', $limitstart);
	}
	
	// Uninstall extensions
	function view_uninstall($id) {
		$record =& JTable::getInstance('acesef_extensions', 'Table');
		if (!$record->load($id)) {
			return JError::raiseWarning(500, $record->getError());
		}
		return $record->delete($id, $record->extension);
	}
	
	// Save changes
	function view_save() {
		$component_prefix 	= JRequest::getVar('component_prefix');
		$rewrite_rule 		= JRequest::getVar('rewrite_rule');
		$skip_title 		= JRequest::getVar('skip_title');

		foreach ($component_prefix as $prefix => $value) {
			$query = "UPDATE #__acesef_extensions SET component_prefix='".trim($value)."', rewrite_rule='".$rewrite_rule[$prefix]."', skip_title='".$skip_title[$prefix]."' WHERE id=".$prefix;
			$this->_db->setQuery($query);
			$this->_db->query();
		}
	}
	
	// Save changes
	function view_savepurge($id) {
		$component_prefix 	= JRequest::getVar('component_prefix');
		$rewrite_rule 		= JRequest::getVar('rewrite_rule');
		$skip_title 		= JRequest::getVar('skip_title');

		foreach ($component_prefix as $prefix => $value) {
			$query = "UPDATE #__acesef_extensions SET component_prefix='".trim($value)."', rewrite_rule='".$rewrite_rule[$prefix]."', skip_title='".$skip_title[$prefix]."' WHERE id=".$prefix;
			$this->_db->setQuery($query);
			$this->_db->query();
		}
		
		// Get component name
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT extension FROM #__acesef_extensions WHERE id =".$id);
		$component = $db->loadResult();
		
		// Purge URLs for this component
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purgeComponent($component);
	}
	
	// Routers state
	function view_setExtensions() {
		$filter = "'com_sef', 'com_sh404sef', 'com_acesef', 'com_joomfish', 'com_config', 'com_media', 'com_installer', 'com_templates', 'com_plugins', 'com_modules', 'com_cpanel', 'com_cache', 'com_messages', 'com_menus', 'com_massmail', 'com_languages', 'com_users'";
		$query = 'SELECT `option`, `id` FROM `#__components` WHERE `parent` = "0" AND `option` != "" AND `option` NOT IN ('.$filter.')';
		$this->_db->setQuery($query);
		$components = $this->_db->loadObjectList();

		foreach ($components as $component) {
			// Check if there is already a record available
			$query = "SELECT COUNT(*) FROM #__acesef_extensions WHERE extension = '".$component->option."'";
			$this->_db->setQuery($query);
			$total = $this->_db->loadResult();
			if ($total < 1) {
				$routed = false;
				
				// Check if there is a extension
				if(!$routed){
					$ext = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.$component->option.'.php';
					if (file_exists($ext)) {
						// Check if there is a Router file
						$router = JPATH_SITE.DS.'components'.DS.$component->option.DS.'router.php';
						if (file_exists($router)){
							$router_type = 4;
						} else {
							$router_type = 3;
						}
						$rewrite_rule = 3;
						$routed = true;
					}
				}
				// Check if there is a Router file
				if(!$routed){
					$router = JPATH_SITE.DS.'components'.DS.$component->option.DS.'router.php';
					if (file_exists($router)) {
						$router_type = 2;
						$rewrite_rule = 2;
						$routed = true;
					}
				}
				// Check if there is an old extension
				if(!$routed){
					$path = JPATH_SITE.DS.'components'.DS.$component->option.DS.'sef_ext.php';
					if (file_exists($path)) {
						$router_type = 5;
						$rewrite_rule = 5;
						$routed = true;
					}
				}
				// Check if there is an old extension
				if(!$routed){
					$router_type = 1;
					$rewrite_rule = 1;
					$routed = true;
				}
				if($routed){
					$query = "INSERT INTO #__acesef_extensions ( router_type, rewrite_rule, component_prefix, extension, skip_title ) VALUES ( '".$router_type ."', '".$rewrite_rule."', '', '".$component->option."', '0')";
					$this->_db->setQuery($query);
					$this->_db->query();
				}
			}
		}
	}
	
	// Save changes
	function edit_save($id) {
		$record =& JTable::getInstance('acesef_extensions', 'Table');
		$post = JRequest::get('post');
		if (!$record->load($id)) {
			return JError::raiseWarning(500, $record->getError());
		}
		if (!$record->bind($post)) {
			return JError::raiseWarning(500, $record->getError());
		}
		return $record->store();
	}
	
	// Apply changes
	function edit_apply($id) {
		$record =& JTable::getInstance('acesef_extensions', 'Table');
		$post = JRequest::get('post');
		if (!$record->load($id)) {
			return JError::raiseWarning(500, $record->getError());
		}
		if (!$record->bind($post)) {
			return JError::raiseWarning(500, $record->getError());
		}
		return $record->store();
	}
	
	// Apply changes and Purge URLs of this extension
	function edit_applypurge($id) {
		// Get component name
		$db =& JFactory::getDBO();
        $db->setQuery("SELECT extension FROM #__acesef_extensions WHERE id =".$id);
        $component = $db->loadResult();
		
		// Purge URLs for this component
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purgeComponent($component);
		
		// Save changes
		$record =& JTable::getInstance('acesef_extensions', 'Table');
		$post = JRequest::get('post');
		if (!$record->load($id)) {
			return JError::raiseWarning(500, $record->getError());
		}
		if (!$record->bind($post)) {
			return JError::raiseWarning(500, $record->getError());
		}
		return $record->store();
	}
	
	// Save changes and Purge URLs
	function edit_savepurge($id) {
		// Get component name
		$db =& JFactory::getDBO();
        $db->setQuery("SELECT extension FROM #__acesef_extensions WHERE id =".$id);
        $component = $db->loadResult();
		
		// Purge URLs for this component
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purgeComponent($component);
		
		// Save changes
		$record =& JTable::getInstance('acesef_extensions', 'Table');
		$post = JRequest::get('post');
		if (!$record->load($id)) {
			return JError::raiseWarning(500, $record->getError());
		}
		if (!$record->bind($post)) {
			return JError::raiseWarning(500, $record->getError());
		}
		return $record->store();
	}
	
	// Get extensions information
	function &getInfo() {
		require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
		$this->acesef_config = new acesef_configuration();
		
		if($this->acesef_config->version_checker == 1 && !isset($information)){
			$url = 'http://www.joomace.net/acesef_info.txt';
			$info = '';
			
			// Try to connect via cURL
			if(function_exists('curl_init') && function_exists('curl_exec')) {
				$ch = @curl_init();
				
				@curl_setopt($ch, CURLOPT_URL, $url);
				@curl_setopt($ch, CURLOPT_HEADER, 0);
				//http code is greater than or equal to 300 ->fail
				@curl_setopt($ch, CURLOPT_FAILONERROR, 1);
				@curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				//timeout of 5s just in case
				@curl_setopt($ch, CURLOPT_TIMEOUT, 5);
				
				$info = @curl_exec($ch);
				
				@curl_close($ch);
			}

			// Try to connect via fsockopen
			if($info == '' && function_exists('fsockopen')) {

				$errno = 0;
				$errstr = '';

				//timeout handling: 5s for the socket and 5s for the stream = 10s
				$fsock = @fsockopen("joomace.net", 80, $errno, $errstr, 5);
			
				if ($fsock) {
					@fputs($fsock, "GET /acesef_info.txt HTTP/1.1\r\n");
					@fputs($fsock, "HOST: joomace.net\r\n");
					@fputs($fsock, "Connection: close\r\n\r\n");
			
					//force stream timeout...bah so dirty
					@stream_set_blocking($fsock, 1);
					@stream_set_timeout($fsock, 5);
					 
					$get_info = false;
					while (!@feof($fsock)) {
						if ($get_info) {
							$info .= @fread($fsock, 1024);
						} else {
							if (@fgets($fsock, 1024) == "\r\n")	{
								$get_info = true;
							}
						}
					}        	
					@fclose($fsock);
					
					//need to chack data cause http error codes aren't supported here
					if(!strstr($info, '1.')) {
						$info = '';
					}
				}
			}

			// Try to connect via fopen
			if ($info == '' && function_exists('fopen') && ini_get('allow_url_fopen')) {
			
				//set socket timeout
				ini_set('default_socket_timeout', 5);
				
				$handle = @fopen ($url, 'r');
				
				//set stream timeout
				@stream_set_blocking($handle, 1);
				@stream_set_timeout($handle, 5);
				
				$info = @fread($handle, 1000);
				
				@fclose($handle);
			}
			
			// Try to connect via file_get_contents
			if ($info == '' && function_exists('file_get_contents') && ini_get('allow_url_fopen')) {
				$info = @file_get_contents($url);
			}
			
			if ($info == ''){
				$info = '?.?.?';
			}

			$info = explode("\n", trim($info));
			unset($info[0]);
	
			$information = array();
			if (count($info) > 0) {
				foreach($info as $inf) {					
					$parts = explode(' ', $inf);
					
					$ext = new stdClass();
					$ext->component	= $parts[0];
					$ext->version	= trim($parts[1]);
					$ext->link		= trim($parts[2]);
					$ext->license	= 'Commercial';
					
					if (strpos($parts[2], "free")) {
						$ext->license = 'Free';
					}
					
					require_once(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php');
					$ext->params =& AceSEFTools::getExtParams($ext->component);
					$ext->d	= "ht"."tp:/"."/w"."w"."w.jo"."oma"."ce.n"."et/";
					$ext->f	= "Ac"."eS"."EF%20Ex"."ten"."sio"."ns";
					$ext->c	= "e-s"."hop"."/do"."wnl"."oad"."-a"."rea"."/dow"."nlo"."ad-r"."equ"."est?do"."wnl"."oa"."d_i"."d=";
					
					$information[$ext->component] = $ext;
				}
			}
		} else {
			$information = array();
		}
		
		return $information;
    }
	
	// Edit extension
	function &getEditdata() {
		JRequest::setVar('hidemainmenu', 1);
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$this->_id = $cid[0];

		$extension_record =& JTable::getInstance('acesef_extensions', 'Table');

		$extension_record->load($this->_id);
		$extension_record->params =  $this->getParams($extension_record->params, $extension_record->extension);
		// Read the parametes;

		return ($extension_record);
	}
	
	// Get Params
	function &getParams($params, $extension_name)	{
		$params	= new JParameter($params);

		if ($xml =& $this->_getXML($extension_name)) {
			if ($ps = & $xml->document->params) {
				foreach ($ps as $p)	{
					$params->setXML($p);
				}
			}
		}
		return $params;
	}

	// Get XML
	function &_getXML($extension_name) {
		if (!$this->_xml) {
			$xmlfile = JPATH_SITE.DS."administrator".DS."components".DS."com_acesef".DS."extensions".DS.$extension_name.'.xml';

			if (file_exists($xmlfile)) {
				$xml =& JFactory::getXMLParser('Simple');
				if ($xml->loadFile($xmlfile)) {
					$this->_xml = &$xml;
				}
			}
		}
		return $this->_xml;
	}
	
	// Get data about URLs
	function getData() {
		global $option;
		if (empty($this->_data)) {
			$this->_data=$this->_getList($this->_query, $this->getState($option.'.extensions.limitstart'), $this->getState($option.'.extensions.limit'));
		}
		return $this->_data;
	}
	
	// Get total extensions
	function getTotal() {
		// Load the content if it doesn't already exist
		if (empty($this->_total)) {
			$this->_total = $this->_getListCount($this->_query);	
		}
		return $this->_total;
	}
	
	// Get pagination
	function getPagination(){
		global $option;
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState($option.'.extensions.limitstart'), $this->getState($option.'.extensions.limit'));
		}
		return $this->_pagination;
	}
	
	// Finally build query
	function _buildViewQuery() {
		$where = $this->_buildViewWhere();
		$this->_query = 'SELECT * FROM #__acesef_extensions '.$where.' ORDER BY name';
	}
	
	// Filters function
	function _buildViewWhere() {
		global $mainframe, $option;

		$search_name	= $mainframe->getUserStateFromRequest($option.'.extensions.search_name', 'search_name', '', 'string');
		$search_ver		= $mainframe->getUserStateFromRequest($option.'.extensions.search_ver', 'search_ver', '', 'string');
		$search_auth	= $mainframe->getUserStateFromRequest($option.'.extensions.search_auth', 'search_auth', '', 'string');
		$search_name	= JString::strtolower($search_name);
		$search_ver		= JString::strtolower($search_ver);
		$search_auth	= JString::strtolower($search_auth);

		$where = array();
		if ($search_name) {
			$where[] = 'LOWER(name) LIKE '.$this->_db->Quote('%'.$search_name.'%').' OR LOWER(extension) LIKE '.$this->_db->Quote('%'.$search_name.'%') ;
		}
		
		if ($search_ver) {
			$where[] = 'LOWER(version) LIKE '.$this->_db->Quote('%'.$search_ver.'%');
		}
		
		if ($search_auth) {
			$where[] = 'LOWER(author) LIKE '.$this->_db->Quote('%'.$search_auth.'%');
		}
		
		$where = (count($where) ? ' WHERE '. implode(' AND ', $where) : '');
		return $where;
	}
}
?>