<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// XML
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'acesef.xml', 'upgrade', DS.'acesef.xml');

// Admin
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'uninstall.sql', 'upgrade', DS.'uninstall.sql');

// Assets
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-changelog.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-changelog.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-configuration.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-configuration.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-extensions.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-extensions.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-import.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-import.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-routers.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-routers.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-support.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-support.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-upgrade.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-upgrade.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-url-404.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-url-404.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-url-custom.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-url-custom.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-url-sef.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-url-sef.png');

// Classes
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php', 'upgrade', DS.'classes'.DS.'aceseftools.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'mainrouter.php', 'upgrade', DS.'classes'.DS.'mainrouter.php');

// Controllers
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'extensions.php', 'upgrade', DS.'controllers'.DS.'extensions.php');

// Extensions
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.php', 'upgrade', DS.'extensions'.DS.'com_content.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.xml', 'upgrade', DS.'extensions'.DS.'com_content.xml');

// Models
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'config.php', 'upgrade', DS.'models'.DS.'config.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'extensions.php', 'upgrade', DS.'models'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'repository.php', 'upgrade', DS.'models'.DS.'repository.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'upgrade.php', 'upgrade', DS.'models'.DS.'upgrade.php');

// Views
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'config'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'routers'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'routers'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.inc.html', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.inc.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'repository'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'repository'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'repository'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'repository'.DS.'tmpl'.DS.'default.php');

// Upgrade
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'upgrade'.DS.'reinstall.php', 'upgrade', DS.'upgrade'.DS.'reinstall.php');

// Language files
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'de-DE'.DS.'de-DE.com_acesef.ini', 'upgrade', DS.'languages'.DS.'de-DE'.DS.'de-DE.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.com_acesef.ini', 'upgrade', DS.'languages'.DS.'en-GB'.DS.'en-GB.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'es-ES'.DS.'es-ES.com_acesef.ini', 'upgrade', DS.'languages'.DS.'es-ES'.DS.'es-ES.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'it-IT'.DS.'it-IT.com_acesef.ini', 'upgrade', DS.'languages'.DS.'it-IT'.DS.'it-IT.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pl-PL'.DS.'pl-PL.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pl-PL'.DS.'pl-PL.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-BR'.DS.'pt-BR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pt-BR'.DS.'pt-BR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-PT'.DS.'pt-PT.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pt-PT'.DS.'pt-PT.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'ru-RU'.DS.'ru-RU.com_acesef.ini', 'upgrade', DS.'languages'.DS.'ru-RU'.DS.'ru-RU.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sr-RS'.DS.'sr-RS.com_acesef.ini', 'upgrade', DS.'languages'.DS.'sr-RS'.DS.'sr-RS.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-CN'.DS.'zh-CN.com_acesef.ini', 'upgrade', DS.'languages'.DS.'zh-CN'.DS.'zh-CN.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-TW'.DS.'zh-TW.com_acesef.ini', 'upgrade', DS.'languages'.DS.'zh-TW'.DS.'zh-TW.com_acesef.ini');

// DB changes
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.0.4' WHERE extension = 'com_content'");
$this->_addSQL("UPDATE #__acesef_urls SET used = '10' WHERE used = '1'");
$this->_addSQL("UPDATE #__acesef_urls SET used = '5' WHERE used = '9'");

$db =& JFactory::getDBO();
$db->setQuery("SELECT `id` FROM `#__components` WHERE `admin_menu_link` = 'option=com_acesef' LIMIT 1");
$menuid = $db->loadResult();
if($menuid) {
    $this->_addSQL("INSERT INTO `#__components`(`name`, `link`, `parent`, `admin_menu_link`, `admin_menu_alt`, `option`, `ordering`, `admin_menu_img`, `params`, `enabled`) VALUES ".
                   " ('Control Panel',       '', '{$menuid}', 'option=com_acesef',                                				'Control Panel',       '',     '0', 	'components/com_acesef/assets/images/favicon.png',					'', '1')".
                   ",('Configuration',       '', '{$menuid}', 'option=com_acesef&controller=config&task=edit',    				'Configuration',       '',     '1', 	'components/com_acesef/assets/images/icon-16-configuration.png',	'', '1')".
                   ",('Extensions',          '', '{$menuid}', 'option=com_acesef&controller=extension&task=view',       		'Extensions',          '',     '2', 	'components/com_acesef/assets/images/icon-16-extensions.png',		'', '1')".
                   ",('Routers',             '', '{$menuid}', 'option=com_acesef&controller=routers&task=view',    				'Routers',             '',     '3', 	'components/com_acesef/assets/images/icon-16-routers.png', 			'', '1')".
                   ",('Import / Migrate',    '', '{$menuid}', 'option=com_acesef&controller=import&task=view',    				'Import / Migrate',    '',     '4', 	'components/com_acesef/assets/images/icon-16-import.png',			'', '1')".
                   ",('Upgrade',             '', '{$menuid}', 'option=com_acesef&controller=upgrade&task=view',  				'Upgrade',             '',     '5', 	'components/com_acesef/assets/images/icon-16-upgrade.png',			'', '1')".
                   ",('SEF URLs',            '', '{$menuid}', 'option=com_acesef&controller=repository&task=view&type=1',  		'SEF URLs',            '',     '6', 	'components/com_acesef/assets/images/icon-16-url-sef.png',			'', '1')".
                   ",('Custom URLs',         '', '{$menuid}', 'option=com_acesef&controller=repository&task=view&type=2',  		'Custom URLs',         '',     '7', 	'components/com_acesef/assets/images/icon-16-url-custom.png',		'', '1')".
                   ",('404 URLs',            '', '{$menuid}', 'option=com_acesef&controller=repository&task=view&type=3',       '404 URLs',            '',     '8', 	'components/com_acesef/assets/images/icon-16-url-404.png',			'', '1')".
                   ",('Support',             '', '{$menuid}', 'option=com_acesef&controller=support&task=support',       		'Support',             '',     '9',		'components/com_acesef/assets/images/icon-16-support.png',			'', '1')".
                   ",('Changelog',           '', '{$menuid}', 'option=com_acesef&controller=support&task=changelog', 			'Changelog',           '',     '10',	'components/com_acesef/assets/images/icon-16-changelog.png',		'', '1')"
                    );
}

?>