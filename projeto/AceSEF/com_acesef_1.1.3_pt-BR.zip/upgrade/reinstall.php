<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// XML definition file
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'acesef.xml', 'upgrade', DS.'acesef.xml');

// Admin files
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'admin.acesef.php', 'upgrade', DS.'admin.acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'configuration.php', 'upgrade', DS.'configuration.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controller.php', 'upgrade', DS.'controller.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'index.html', 'upgrade', DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'install.acesef.php', 'upgrade', DS.'install.acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'install.sql', 'upgrade', DS.'install.sql');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'toolbar.acesef.php', 'upgrade', DS.'toolbar.acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'uninstall.acesef.php', 'upgrade', DS.'uninstall.acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'uninstall.sql', 'upgrade', DS.'uninstall.sql');

// Assets
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'index.html', 'upgrade', DS.'assets'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'css'.DS.'acesef.css', 'upgrade', DS.'assets'.DS.'css'.DS.'acesef.css');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'css'.DS.'index.html', 'upgrade', DS.'assets'.DS.'css'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-changelog.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-changelog.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-configuration.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-configuration.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-doc.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-doc.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-extensions.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-extensions.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-import.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-import.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-purge-urls404.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-purge-urls404.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-purge-urlscustom.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-purge-urlscustom.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-router.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-router.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-support.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-support.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-upgrade.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-upgrade.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-urls404.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-urls404.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-urlscustom.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-urlscustom.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'favicon.png', 'upgrade', DS.'assets'.DS.'images'.DS.'favicon.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-block-off.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-block-off.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-block-on.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-block-on.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-changelog.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-changelog.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-configuration.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-configuration.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-extensions.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-extensions.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-import.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-import.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-lock-off.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-lock-off.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-lock-on.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-lock-on.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-published-off.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-published-off.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-published-on.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-published-on.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-routers.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-routers.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-support.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-support.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-upgrade.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-upgrade.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-url-404.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-url-404.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-url-custom.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-url-custom.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-url-sef.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-url-sef.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-used-off.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-used-off.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-used-on.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-used-on.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-used-on2.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-used-on2.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-approve.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-approve.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-block.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-block.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-cancel1.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-cancel1.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-deletefiltered.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-deletefiltered.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-deleteselected.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-deleteselected.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-editurl.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-editurl.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-exportfiltered.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-exportfiltered.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-exportselected.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-exportselected.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-home.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-home.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-lock.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-lock.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-newurl.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-newurl.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-purgeurls.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-purgeurls.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-rebuild.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-rebuild.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-save1.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-save1.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-uninstall.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-uninstall.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-use.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-use.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'index.html', 'upgrade', DS.'assets'.DS.'images'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'logo.png', 'upgrade', DS.'assets'.DS.'images'.DS.'logo.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'toolbar.png', 'upgrade', DS.'assets'.DS.'images'.DS.'toolbar.png');

// Classes
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'404handler.php', 'upgrade', DS.'classes'.DS.'404handler.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php', 'upgrade', DS.'classes'.DS.'aceseftools.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'functions.php', 'upgrade', DS.'classes'.DS.'functions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'index.html', 'upgrade', DS.'classes'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'mainrouter.php', 'upgrade', DS.'classes'.DS.'mainrouter.php');

// Controllers
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'acesef.php', 'upgrade', DS.'controllers'.DS.'acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'config.php', 'upgrade', DS.'controllers'.DS.'config.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'editurl.php', 'upgrade', DS.'controllers'.DS.'editurl.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'extensions.php', 'upgrade', DS.'controllers'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'index.html', 'upgrade', DS.'controllers'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'import.php', 'upgrade', DS.'controllers'.DS.'import.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'purge.php', 'upgrade', DS.'controllers'.DS.'purge.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'repository.php', 'upgrade', DS.'controllers'.DS.'repository.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'routers.php', 'upgrade', DS.'controllers'.DS.'routers.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'support.php', 'upgrade', DS.'controllers'.DS.'support.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'upgrade.php', 'upgrade', DS.'controllers'.DS.'upgrade.php');

// Models
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'acesef.php', 'upgrade', DS.'models'.DS.'acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'config.php', 'upgrade', DS.'models'.DS.'config.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'editurl.php', 'upgrade', DS.'models'.DS.'editurl.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'extensions.php', 'upgrade', DS.'models'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'index.html', 'upgrade', DS.'models'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'import.php', 'upgrade', DS.'models'.DS.'import.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php', 'upgrade', DS.'models'.DS.'purge.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'repository.php', 'upgrade', DS.'models'.DS.'repository.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'routers.php', 'upgrade', DS.'models'.DS.'routers.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'upgrade.php', 'upgrade', DS.'models'.DS.'upgrade.php');

// Tables
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_extensions.php', 'upgrade', DS.'tables'.DS.'acesef_extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_urls.php', 'upgrade', DS.'tables'.DS.'acesef_urls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'index.html', 'upgrade', DS.'tables'.DS.'index.html');

// Views
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'acesef'.DS.'index.html', 'upgrade', DS.'views'.DS.'acesef'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'acesef'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'acesef'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'index.html', 'upgrade', DS.'views'.DS.'config'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'config'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'views'.DS.'config'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl'.DS.'index.html', 'upgrade', DS.'views'.DS.'editurl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'editurl'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'editurl'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'views'.DS.'editurl'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'index.html', 'upgrade', DS.'views'.DS.'extensions'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'view.edit.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'view.edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'extension_edit.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'extension_edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'import'.DS.'index.html', 'upgrade', DS.'views'.DS.'import'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'import'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'import'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'import'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'import'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'import'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'views'.DS.'import'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'purge'.DS.'index.html', 'upgrade', DS.'views'.DS.'purge'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'purge'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'purge'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'purge'.DS.'tmpl'.DS.'doc.php', 'upgrade', DS.'views'.DS.'purge'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'purge'.DS.'tmpl'.DS.'help.php', 'upgrade', DS.'views'.DS.'purge'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'repository'.DS.'index.html', 'upgrade', DS.'views'.DS.'repository'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'repository'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'repository'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'repository'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'repository'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'repository'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'views'.DS.'repository'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'routers'.DS.'index.html', 'upgrade', DS.'views'.DS.'routers'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'routers'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'routers'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'routers'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'routers'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'routers'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'views'.DS.'routers'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'index.html', 'upgrade', DS.'views'.DS.'support'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'support'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.inc.html', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.inc.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'support.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'upgrade'.DS.'index.html', 'upgrade', DS.'views'.DS.'upgrade'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'upgrade'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'upgrade'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'message.php', 'upgrade', DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'message.php');

// Extensions
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_banners.php', 'upgrade', DS.'extensions'.DS.'com_banners.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_banners.xml', 'upgrade', DS.'extensions'.DS.'com_banners.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_contact.php', 'upgrade', DS.'extensions'.DS.'com_contact.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_contact.xml', 'upgrade', DS.'extensions'.DS.'com_contact.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.php', 'upgrade', DS.'extensions'.DS.'com_content.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.xml', 'upgrade', DS.'extensions'.DS.'com_content.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_mailto.php', 'upgrade', DS.'extensions'.DS.'com_mailto.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_mailto.xml', 'upgrade', DS.'extensions'.DS.'com_mailto.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_newsfeeds.php', 'upgrade', DS.'extensions'.DS.'com_newsfeeds.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_newsfeeds.xml', 'upgrade', DS.'extensions'.DS.'com_newsfeeds.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_poll.php', 'upgrade', DS.'extensions'.DS.'com_poll.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_poll.xml', 'upgrade', DS.'extensions'.DS.'com_poll.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_search.php', 'upgrade', DS.'extensions'.DS.'com_search.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_search.xml', 'upgrade', DS.'extensions'.DS.'com_search.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_user.php', 'upgrade', DS.'extensions'.DS.'com_user.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_user.xml', 'upgrade', DS.'extensions'.DS.'com_user.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_weblinks.php', 'upgrade', DS.'extensions'.DS.'com_weblinks.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_weblinks.xml', 'upgrade', DS.'extensions'.DS.'com_weblinks.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_wrapper.php', 'upgrade', DS.'extensions'.DS.'com_wrapper.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_wrapper.xml', 'upgrade', DS.'extensions'.DS.'com_wrapper.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'index.html', 'upgrade', DS.'extensions'.DS.'index.html');

// Language files
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'da-DK'.DS.'da-DK.com_acesef.ini', 'upgrade', DS.'languages'.DS.'da-DK'.DS.'da-DK.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'de-DE'.DS.'de-DE.com_acesef.ini', 'upgrade', DS.'languages'.DS.'de-DE'.DS.'de-DE.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.com_acesef.ini', 'upgrade', DS.'languages'.DS.'en-GB'.DS.'en-GB.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'es-ES'.DS.'es-ES.com_acesef.ini', 'upgrade', DS.'languages'.DS.'es-ES'.DS.'es-ES.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'hu-HU'.DS.'hu-HU.com_acesef.ini', 'upgrade', DS.'languages'.DS.'hu-HU'.DS.'hu-HU.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'it-IT'.DS.'it-IT.com_acesef.ini', 'upgrade', DS.'languages'.DS.'it-IT'.DS.'it-IT.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pl-PL'.DS.'pl-PL.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pl-PL'.DS.'pl-PL.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-BR'.DS.'pt-BR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pt-BR'.DS.'pt-BR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-PT'.DS.'pt-PT.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pt-PT'.DS.'pt-PT.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'ru-RU'.DS.'ru-RU.com_acesef.ini', 'upgrade', DS.'languages'.DS.'ru-RU'.DS.'ru-RU.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sr-RS'.DS.'sr-RS.com_acesef.ini', 'upgrade', DS.'languages'.DS.'sr-RS'.DS.'sr-RS.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-CN'.DS.'zh-CN.com_acesef.ini', 'upgrade', DS.'languages'.DS.'zh-CN'.DS.'zh-CN.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-TW'.DS.'zh-TW.com_acesef.ini', 'upgrade', DS.'languages'.DS.'zh-TW'.DS.'zh-TW.com_acesef.ini');

// Tables
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_urls.php', 'upgrade', DS.'tables'.DS.'acesef_urls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_extensions.php', 'upgrade', DS.'tables'.DS.'acesef_extensions.php');

// Plugin
$this->_addFileOp(DS.'plugins'.DS.'system'.DS.'acesef.php', 'upgrade', DS.'plugin'.DS.'acesef.php');
$this->_addFileOp(DS.'plugins'.DS.'system'.DS.'acesef.xml', 'upgrade', DS.'plugin'.DS.'acesef.xml');

?>