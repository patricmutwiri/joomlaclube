<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport('joomla.application.component.view');

// Repository View Class
class AcesefViewRepository extends JView {

	// View URLs
	function view($tpl = null) {
		global $mainframe, $option;
		
		// Get data from the model
		$items		= & $this->get('Data');
		$total		= & $this->get('Total');
		$pagination = & $this->get('Pagination');
		
		// Import CSS
  		$document =& JFactory::getDocument();
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set Toolbar
		JToolBarHelper::title(JText::_('ACESEF_URL_REPOS_TITLE' ), 'acesef');
		$bar =& JToolBar::getInstance();
		JToolBarHelper::custom('add', 'newurl.png', 'newurl.png', JTEXT::_('New'), false);
		JToolBarHelper::custom('edit', 'editurl.png', 'editurl.png', JTEXT::_('Edit'), true);
		JToolBarHelper::custom('delete', 'deleteselected.png', 'deleteselected.png', JTEXT::_('Delete'), true);
		$bar->appendButton('Confirm', JText::_('ACESEF_URL_REPOS_CONFIRM_DELETE_FILTERED'), 'deletefiltered', JTEXT::_('ACESEF_URL_REPOS_TOOLBAR_DEL_FILTERED'), 'deleteFiltered', false, false);
		JToolBarHelper::divider();
		JToolBarHelper::custom('publish', 'approve.png', 'approve.png', JTEXT::_('ACESEF_URL_REPOS_TOOLBAR_PUBLISH'), true);
		JToolBarHelper::custom('used', 'use.png', 'use.png', JTEXT::_('ACESEF_URL_REPOS_TOOLBAR_USE'), true);
		JToolBarHelper::custom('lock', 'lock.png', 'lock.png', JTEXT::_('ACESEF_URL_REPOS_TOOLBAR_LOCK'), true);
		JToolBarHelper::custom('block', 'block.png', 'block.png', JTEXT::_('ACESEF_URL_REPOS_TOOLBAR_BLOCK'), true);
		JToolBarHelper::divider();
		JToolBarHelper::custom('exportsel', 'exportselected.png', 'exportselected.png', JTEXT::_('ACESEF_URL_REPOS_TOOLBAR_EXPORT_SELECTED'), true);
		JToolBarHelper::custom('exportall', 'exportfiltered.png', 'exportfiltered.png', JTEXT::_('ACESEF_URL_REPOS_TOOLBAR_EXPORT_FILTERED'), false);
		
		// Get filters
        $search_sef			= $mainframe->getUserStateFromRequest($option.'search_sef', 		'search_sef', 		'');
        $search_real		= $mainframe->getUserStateFromRequest($option.'search_real', 		'search_real', 		'');
        $search_itemid		= $mainframe->getUserStateFromRequest($option.'search_itemid', 		'search_itemid', 	'');
		$filter_order		= $mainframe->getUserStateFromRequest($option.'filter_order',		'filter_order',		'url_sef');
		$filter_order_Dir	= $mainframe->getUserStateFromRequest($option.'filter_order_Dir',	'filter_order_Dir',	'ASC');
		$type				= $mainframe->getUserStateFromRequest($option.'type', 				'type', 			1);
        $filter_component	= $mainframe->getUserStateFromRequest($option.'filter_component', 	'filter_component', '');
		$filter_published	= $mainframe->getUserStateFromRequest($option.'filter_published',	'filter_published',	'-1');
		$filter_used		= $mainframe->getUserStateFromRequest($option.'filter_used',	'filter_used',		'-1');
		$filter_locked		= $mainframe->getUserStateFromRequest($option.'filter_locked', 		'filter_locked',	'-1');
		$filter_blocked		= $mainframe->getUserStateFromRequest($option.'filter_blocked', 	'filter_blocked',	'-1');
		$search_sef			= JString::strtolower($search_sef);
		$search_real		= JString::strtolower($search_real);
		$search_itemid		= JString::strtolower($search_itemid);

		// Filter's action
		$javascript 	= 'onchange="document.adminForm.submit();"';
		
		// Make the input box for SEF URL search
        $lists['search_sef'] = "<input type=\"text\" name=\"search_sef\" value=\"{$search_sef}\" size=\"40\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";

		// Make the input box for Real URL search
        $lists['search_real'] = "<input type=\"text\" name=\"search_real\" value=\"{$search_real}\" size=\"40\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";
		
		// Make the input box for Itemid search
        $lists['search_itemid'] = "<input type=\"text\" name=\"search_itemid\" value=\"{$search_itemid}\" size=\"5\" maxlength=\"10\" onchange=\"document.adminForm.submit();\" />";

		// Table ordering
		$lists['order_dir'] = $filter_order_Dir;
		$lists['order'] 	= $filter_order;
		
		// Type List
		$type_list[] = JHTML::_('select.option', '1', JTEXT::_('ACESEF_URL_REPOS_SELECT_TYPE_SEF'));
		$type_list[] = JHTML::_('select.option', '2', JTEXT::_('ACESEF_URL_REPOS_SELECT_TYPE_CUSTOM'));
		$type_list[] = JHTML::_('select.option', '3', JTEXT::_('ACESEF_URL_REPOS_SELECT_TYPE_404'));
   	   	$lists['type_list'] = JHTML::_('select.genericlist', $type_list, 'type', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $type);
		
		// Component List
        $component_list[] = JHTML::_('select.option', '', JText::_('ACESEF_URL_REPOS_SELECT_ALL_COM'));
		$this->db =& JFactory::getDBO();
        $this->db->setQuery("SELECT `name`, `option` FROM `#__components` WHERE `parent` = '0' ORDER BY `name`");
        $rows = $this->db->loadObjectList();
        if ($this->db->getErrorNum()) {
            echo $this->db->stderr();
            return false;
        }
        foreach(array_keys($rows) as $i) {
            $row = &$rows[$i];
            $component_list[] = JHTML::_('select.option', $row->option, $row->name);
        }
        $lists['component_list'] = JHTML::_('select.genericlist', $component_list, 'filter_component', "class=\"inputbox\" onchange=\"document.adminForm.submit();\" size=\"1\"", 'value', 'text', $filter_component);
		
		// Published Filter
		$published_list[] = JHTMLSelect::Option('-1', JTEXT::_('ACESEF_URL_REPOS_SELECT_PUBLISHED'));
		$published_list[] = JHTMLSelect::Option('1', JTEXT::_('ACESEF_URL_REPOS_SELECT_PUBLISHED_YES'));
		$published_list[] = JHTMLSelect::Option('0', JTEXT::_('ACESEF_URL_REPOS_SELECT_PUBLISHED_NO'));
   	   	$lists['published_list'] = JHTMLSelect::genericlist($published_list, 'filter_published', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_published);
		
   	   	// Published Filter
		$used_list[] = JHTMLSelect::Option('-1', JTEXT::_('ACESEF_URL_REPOS_SELECT_USED'));
		$used_list[] = JHTMLSelect::Option('10', JTEXT::_('ACESEF_URL_REPOS_SELECT_USED_YES'));
		$used_list[] = JHTMLSelect::Option('0', JTEXT::_('ACESEF_URL_REPOS_SELECT_USED_NO'));
		$used_list[] = JHTMLSelect::Option('5', JTEXT::_('ACESEF_URL_REPOS_SELECT_USED_NON'));
   	   	$lists['used_list'] = JHTMLSelect::genericlist($used_list, 'filter_used', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_used);
		
		// Locked Filter
		$locked_list[] = JHTMLSelect::Option('-1', JTEXT::_('ACESEF_URL_REPOS_SELECT_LOCKED'));
		$locked_list[] = JHTMLSelect::Option('1', JTEXT::_('ACESEF_URL_REPOS_SELECT_LOCKED_YES'));
		$locked_list[] = JHTMLSelect::Option('0', JTEXT::_('ACESEF_URL_REPOS_SELECT_LOCKED_NO'));
   	   	$lists['locked_list'] = JHTMLSelect::genericlist($locked_list, 'filter_locked', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_locked);
		
		// Blocked Filter
   	   	$blocked_list[] = JHTMLSelect::Option('-1', JTEXT::_('ACESEF_URL_REPOS_SELECT_BLOCKED'));
		$blocked_list[] = JHTMLSelect::Option('1', JTEXT::_('ACESEF_URL_REPOS_SELECT_BLOCKED_YES'));
		$blocked_list[] = JHTMLSelect::Option('0', JTEXT::_('ACESEF_URL_REPOS_SELECT_BLOCKED_NO'));
   	   	$lists['blocked_list'] = JHTMLSelect::genericlist($blocked_list, 'filter_blocked', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_blocked);

		$this->assignRef('lists',		$lists);
		$this->assignRef('items',		$items);
		$this->assignRef('pagination',	$pagination);

		parent::display($tpl);
	}
}
?>