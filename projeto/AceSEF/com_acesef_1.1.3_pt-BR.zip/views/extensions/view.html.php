<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport('joomla.application.component.view');


// Extensions View Class
class AcesefViewExtensions extends JView {

	// Display extensions
	function view($tpl = null) {
		global $mainframe, $option;
		
		// Get data from the model
		$items		= & $this->get('Data');
		$versions	= & $this->get('Versions');
		$total		= & $this->get('Total');
		$pagination = & $this->get('Pagination');
		
		// Import CSS
  		$document =& JFactory::getDocument();
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set Toolbar
		JToolBarHelper::title(JText::_('ACESEF_EXTENSION_DEFAULT_TITLE'), 'acesef');
		JToolBarHelper::custom('edit', 'editurl.png', 'editurl.png', JTEXT::_('Edit'), true);
		JToolBarHelper::custom('delete', 'uninstall.png', 'uninstall.png', JTEXT::_('Uninstall'), true);
		JToolBarHelper::divider();
		JToolBarHelper::custom('purge', 'purgeurls.png', 'purgeurls.png', JText::_('ACESEF_EXTENSION_DEFAULT_PURGE'), true);
		JToolBarHelper::divider();
		JToolBarHelper::custom('back', 'home.png', 'home.png', JText::_('ACESEF_COMMON_HOME'), false);
		
		// Get search values
		$search_name	= $mainframe->getUserStateFromRequest($option.'.extensions.search_name', 'search_name', '', 'string');
		$search_ver		= $mainframe->getUserStateFromRequest($option.'.extensions.search_ver', 'search_ver', '', 'string');
		$search_auth	= $mainframe->getUserStateFromRequest($option.'.extensions.search_auth', 'search_auth', '', 'string');
		$search_name	= JString::strtolower($search_name);
		$search_ver		= JString::strtolower($search_ver);
		$search_auth	= JString::strtolower($search_auth);
		
		// Make the input box for search extension name
        $lists['search_name'] = "<input type=\"text\" name=\"search_name\" value=\"{$search_name}\" size=\"40\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";

		// Make the input box for search extension version
        $lists['search_ver'] = "<input type=\"text\" name=\"search_ver\" value=\"{$search_ver}\" size=\"10\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";
		
        // Make the input box for search extension author
        $lists['search_auth'] = "<input type=\"text\" name=\"search_auth\" value=\"{$search_auth}\" size=\"30\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";
        
		$this->assignRef('lists',		$lists);
		$this->assignRef('items',		$items);
		$this->assignRef('versions',	$versions);
		$this->assignRef('pagination',	$pagination);

		parent::display($tpl);
	}
}
?>