<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

?>
<form enctype="multipart/form-data" action="index.php" method="post" name="adminForm_pck">
	<fieldset class="adminform">
	<legend><?php echo JText::_('ACESEF_EXTENSION_DEFAULT_INSTALL'); ?></legend>
	<table class="adminform">
		<tbody>
			<tr>
				<td width="120">
					<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
				</td>
				<td>
					<input class="input_box" type="file" size="57" id="install_package" name="install_package" />
					<input class="button" type="submit" onclick="submitbutton()" value="<?php echo JText::_('ACESEF_EXTENSION_DEFAULT_UPLOAD'); ?>" />
				</td>
			</tr>
		</tbody>
	</table>
	</fieldset>
	<input type="hidden" name="type" value="" />
	<input type="hidden" name="task" value="doinstall" />
	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="extensions" />
</form>

<br />

<form action="index.php" method="post" name="adminForm">
	<table>
	<tr>
		<td nowrap="nowrap">
				<?php echo JText::_('ACESEF_EXTENSION_NAME').'<br />'.$this->lists['search_name']; ?>
		</td>
		<td nowrap="nowrap">
			<?php echo JText::_('ACESEF_EXTENSION_VERSION').'<br />'.$this->lists['search_ver']; ?>
		</td>
		<td nowrap="nowrap">
			<?php echo JText::_('ACESEF_EXTENSION_AUTHOR').'<br />'.$this->lists['search_auth']; ?>
		</td>
	</tr>
	</table>
	<div id="editcell">
		<table class="adminlist">
		<thead>
			<tr>
				<th width="5">
					<?php echo JText::_('ACESEF_COMMON_NUM'); ?>
				</th>
				<th width="20">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
				</th>
				<th class="title">
					<?php echo  JTEXT::_('ACESEF_EXTENSION_NAME'); ?>
				</th>
				<th width="5%" class="title">
					<?php echo JTEXT::_('ACESEF_EXTENSION_VERSION'); ?>
				</th>
				<th width="5%" class="title">
					<?php echo JTEXT::_('ACESEF_CPANEL_LATEST_VERSION'); ?>
				</th>
				<th class="title">
					<?php echo JTEXT::_('ACESEF_EXTENSION_DESCR'); ?>
				</th>
				<th width="10%" class="title">
					<?php echo JTEXT::_('ACESEF_EXTENSION_AUTHOR'); ?>
				</th>
				<th width="10%" class="title">
					<?php echo JTEXT::_('ACESEF_EXTENSION_AUTHOR_URL'); ?>
				</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="9">
					<?php echo $this->pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
		<tbody>
		<?php
		$k = 0;
		for ($i=0, $n=count($this->items); $i < $n; $i++) {
			$row = &$this->items[$i];

			$link 	= JRoute::_('index.php?option=com_acesef&controller=extensions&task=edit&cid[]='.$row->id);
			$checked 		= JHTML::_('grid.checkedout', $row, $i);

			?>
			<tr class="<?php echo "row$k"; ?>">
				<td>
					<?php echo $this->pagination->getRowOffset($i); ?>
				</td>
				<td>
					<?php echo $checked; ?>
				</td>
				<td>
					<a href="<?php echo $link; ?>" title="<?php echo JText::_('ACESEF_EXTENSION_DEFAULT_EDIT'); ?>">
						<?php echo $row->name; ?>
					</a>
				</td>
				<td align="center">
					<?php echo $row->version; ?>
				</td>
				<td align="center">
					<?php 
						$versions	= array();
						$versions	= $this->versions;
						$ver 		= $versions[$row->extension];
						
						if(empty($ver)) {
							$ver = '1.0.0';
							echo $ver;
						} else {
							$compared = version_compare($row->version, $ver);
							if ($compared == 0)
								echo '<strong><font color="green">'.$ver.'</font></strong>';
							elseif($compared == -1)
								echo '<a href="http://www.joomace.net" target="_blank"><b><font color="red">'.$ver.'</font></b></a>';
							else
								echo '<a href="http://www.joomace.net" target="_blank"><b><font color="orange">'.$ver.'</font></b></a>';
						}
					?>
				</td>
				<td>
					<?php echo $row->description; ?>
				</td>
				<td>
					<?php echo $row->author; ?>
				</td>
				<td>
					<a href="http://<?php echo $row->author_url; ?>"><?php echo $row->author_url; ?></a>
				</td>
			</tr>
			<?php
			$k = 1 - $k;
		}
		?>
		</tbody>
		</table>
	</div>

	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="extensions" />
	<input type="hidden" name="task" value="view" />
	<input type="hidden" name="boxchecked" value="0" />
</form>