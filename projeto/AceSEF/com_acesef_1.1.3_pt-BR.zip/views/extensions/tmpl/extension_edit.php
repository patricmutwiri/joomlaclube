<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

// Clean item data
jimport('joomla.filter.output');
JFilterOutput::objectHTMLSafe($row, ENT_QUOTES, 'content');

// Check for component metadata.xml file
//$path = JApplicationHelper::getPath($client->extension.'.xml', $row->extension);
//$params = new JParameter($row->params, $path);
$document =& JFactory::getDocument();

JHTML::_('behavior.combobox');

jimport('joomla.html.pane');
$pane =& JPane::getInstance('sliders');

JHTML::_('behavior.tooltip');
?>
<form action="index.php" method="post" name="adminForm">
	<div class="col width-60">
		<fieldset class="adminform">
			<legend><?php echo JText::_('ACESEF_EXTENSION_EDIT_DETAILS'); ?></legend>

		<table class="admintable" cellspacing="1">
			<tr>
				<td valign="top" class="key">
					<?php echo JText::_('ACESEF_EXTENSION_NAME'); ?>
				</td>
				<td>
					<?php echo $this->row->name; ?>
				</td>
			</tr>
			<tr>
				<td valign="top" class="key">
					<?php echo JText::_('ACESEF_EXTENSION_VERSION'); ?>
				</td>
				<td>
					<?php echo $this->row->version; ?>
				</td>
			</tr>
			<tr>
				<td valign="top" class="key">
					<?php echo JText::_('ACESEF_CPANEL_LATEST_VERSION'); ?>
				</td>
				<td>
					<?php 
						$versions	= array();
						$versions	= $this->versions;
						$ver 		= $versions[$this->row->extension];
						
						if(empty($ver)) {
							$ver = '1.0.0';
						} else {
							$compared = version_compare($this->row->version, $ver);
							if ($compared == 0)
								echo '<strong><font color="green">'.$ver.'</font></strong>';
							elseif($compared == -1)
								echo '<a href="http://www.joomace.net" target="_blank"><b><font color="red">'.$ver.'</font></b></a>';
							else
								echo '<a href="http://www.joomace.net" target="_blank"><b><font color="orange">'.$ver.'</font></b></a>';
						}
					?>
				</td>
			</tr>
			<tr>
				<td valign="top" class="key">
					<?php echo JText::_('ACESEF_EXTENSION_DESCR'); ?>
				</td>
				<td>
					<?php echo $this->row->description; ?>
				</td>
			</tr>
			<tr>
				<td valign="top" class="key">
					<?php echo JText::_('ACESEF_EXTENSION_AUTHOR'); ?>
				</td>
				<td>
					<?php echo $this->row->author; ?>
				</td>
			</tr>
			<tr>
				<td valign="top" class="key">
					<?php echo JText::_('ACESEF_EXTENSION_AUTHOR_URL'); ?>
				</td>
				<td>
					<a href="http://<?php echo $this->row->author_url; ?>" target="_blank">
					<?php echo $this->row->author_url; ?>
					</a>
				</td>
			</tr>
			</table>
		</fieldset>
	</div>
	<div class="col width-40">
		<fieldset class="adminform">
			<legend><?php echo JText::_('PARAMETERS'); ?></legend>

			<?php
				echo $pane->startPane("extension");
				
				// URL Layout Panel
				echo $pane->startPanel(JText::_('URL Layout'), "sef");
				$p = $this->params;
				if($params = $this->row->params->render('params', 'sef'))
					echo $params;
				else
					echo "<div style=\"text-align: center; padding: 5px; \">".JText::_('There are no parameters for this extension')."</div>";
				echo $pane->endPanel();
				
				// Meta Tags Panel
				echo $pane->startPanel(JText::_('Meta Tags'), "seo");
				$p = $this->params;
				if($params = $this->row->params->render('params', 'seo'))
					echo $params;
				else
					echo "<div style=\"text-align: center; padding: 5px; \">".JText::_('There are no parameters for this extension')."</div>";
				echo $pane->endPanel();
				
				echo $pane->endPane();
			?>
		</fieldset>
	</div>
	<div class="clr">
	</div>
	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="extensions" />
	<input type="hidden" name="task" value="edit" />
	<input type="hidden" name="id" value="<?php echo $this->row->id; ?>" />
</form>