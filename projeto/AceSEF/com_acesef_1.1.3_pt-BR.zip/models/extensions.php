<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport('joomla.application.component.model');

// Extensions Model Class
class AcesefModelExtensions extends JModel {

	var $_query;
	var $_data 			= null;
	var $_total 		= null;
	var $_pagination 	= null;
	var $_xml			= null;
	
	// Main constructer
	function __construct()	{
		parent::__construct();
		
		global $mainframe, $option;
		
		$this->_buildViewQuery();

		// Get the pagination request variables
		$limit				= $mainframe->getUserStateFromRequest($option.'.extensions.limit', 	'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart			= $mainframe->getUserStateFromRequest($option.'.extensions.limitstart', 'limitstart', 0, 'int');
		
		// Limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		$this->setState($option.'.extensions.limit', $limit);
		$this->setState($option.'.extensions.limitstart', $limitstart);
	}
	
	// Uninstall extensions
	function delete($id) {
		$acesef_record =& JTable::getInstance('acesef_extensions', 'Table');
		if (!$acesef_record->load($id)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		return $acesef_record->delete($id, $acesef_record->extension);
	}
	
	// Purge URLs of this extension
	function purge($id) {
		// Get component name
		$db =& JFactory::getDBO();
        $db->setQuery("SELECT extension FROM #__acesef_extensions WHERE id =".$id);
        $component = $db->loadResult();
		
		// Purge URLs for this component
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purgeComponent($component);
	}
	
	// Save changes
	function save($id) {
		$acesef_record =& JTable::getInstance('acesef_extensions', 'Table');
		$post = JRequest::get('post');
		if (!$acesef_record->load($id)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		if (!$acesef_record->bind($post)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		return $acesef_record->store();
	}
	
	// Apply changes
	function apply($id) {
		$acesef_record =& JTable::getInstance('acesef_extensions', 'Table');
		$post = JRequest::get('post');
		if (!$acesef_record->load($id)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		if (!$acesef_record->bind($post)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		return $acesef_record->store();
	}
	
	// Apply changes and Purge URLs of this extension
	function applypurge($id) {
		// Get component name
		$db =& JFactory::getDBO();
        $db->setQuery("SELECT extension FROM #__acesef_extensions WHERE id =".$id);
        $component = $db->loadResult();
		
		// Purge URLs for this component
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purgeComponent($component);
		
		// Save changes
		$acesef_record =& JTable::getInstance('acesef_extensions', 'Table');
		$post = JRequest::get('post');
		if (!$acesef_record->load($id)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		if (!$acesef_record->bind($post)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		return $acesef_record->store();
	}
	
	// Save changes and Purge URLs
	function savepurge($id) {
		// Get component name
		$db =& JFactory::getDBO();
        $db->setQuery("SELECT extension FROM #__acesef_extensions WHERE id =".$id);
        $component = $db->loadResult();
		
		// Purge URLs for this component
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purgeComponent($component);
		
		// Save changes
		$acesef_record =& JTable::getInstance('acesef_extensions', 'Table');
		$post = JRequest::get('post');
		if (!$acesef_record->load($id)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		if (!$acesef_record->bind($post)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		return $acesef_record->store();
	}	
	
	// Edit extension
	function &getEditdata() {
		JRequest::setVar('hidemainmenu', 1);
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$this->_id = $cid[0];

		$extension_record =& JTable::getInstance('acesef_extensions', 'Table');

		$extension_record->load($this->_id);
		$extension_record->params =  $this->getParams($extension_record->params, $extension_record->extension);
		// Read the parametes;

		return ($extension_record);
	}
	
	// Get Params
	function &getParams($params, $extension_name)	{
		$params	= new JParameter($params);

		if ($xml =& $this->_getXML($extension_name)) {
			if ($ps = & $xml->document->params) {
				foreach ($ps as $p)	{
					$params->setXML($p);
				}
			}
		}
		return $params;
	}

	// Get XML
	function &_getXML($extension_name) {
		if (!$this->_xml) {
			$xmlfile = JPATH_SITE.DS."administrator".DS."components".DS."com_acesef".DS."extensions".DS.$extension_name.'.xml';

			if (file_exists($xmlfile)) {
				$xml =& JFactory::getXMLParser('Simple');
				if ($xml->loadFile($xmlfile)) {
					$this->_xml = &$xml;
				}
			}
		}
		return $this->_xml;
	}
	
	// Get data about URLs
	function getData() {
		global $option;
		if (empty($this->_data)) {
			$this->_data=$this->_getList($this->_query, $this->getState($option.'.extensions.limitstart'), $this->getState($option.'.extensions.limit'));
		}
		return $this->_data;
	}
	
	// Get total extensions
	function getTotal() {
		// Load the content if it doesn't already exist
		if (empty($this->_total)) {
			$this->_total = $this->_getListCount($this->_query);	
		}
		return $this->_total;
	}
	
	// Get pagination
	function getPagination(){
		global $option;
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState($option.'.extensions.limitstart'), $this->getState($option.'.extensions.limit'));
		}
		return $this->_pagination;
	}
	
	// Get extensions versions
	function &getVersions() {
		if(!isset($extVersions)){
			$path = 'http://www.joomace.net/acesef_versions.txt';
			$versions = @file_get_contents($path);
			if (!$versions) {
				$versions = '?.?.?';
			}

			$versions = explode("\n", trim($versions));
			unset($versions[0]);

			$extVersions = array();
			if (count($versions) > 0) {
				foreach($versions as $version) {
					list($ext, $ver) = explode(' ', $version);
					$extVersions[$ext] = trim($ver);
				}
			}
		}
		return $extVersions;
    }
	
	// Finally build query
	function _buildViewQuery() {
		$where = $this->_buildViewWhere();
		$this->_query = 'SELECT * FROM #__acesef_extensions '.$where.' ORDER BY name';
	}
	
	// Filters function
	function _buildViewWhere() {
		global $mainframe, $option;

		$search_name	= $mainframe->getUserStateFromRequest($option.'.extensions.search_name', 'search_name', '', 'string');
		$search_ver		= $mainframe->getUserStateFromRequest($option.'.extensions.search_ver', 'search_ver', '', 'string');
		$search_auth	= $mainframe->getUserStateFromRequest($option.'.extensions.search_auth', 'search_auth', '', 'string');
		$search_name	= JString::strtolower($search_name);
		$search_ver		= JString::strtolower($search_ver);
		$search_auth	= JString::strtolower($search_auth);

		$where = array();
		if ($search_name) {
			$where[] = 'LOWER(name) LIKE '.$this->_db->Quote('%'.$search_name.'%');
		}
		
		if ($search_ver) {
			$where[] = 'LOWER(version) LIKE '.$this->_db->Quote('%'.$search_ver.'%');
		}
		
		if ($search_auth) {
			$where[] = 'LOWER(author) LIKE '.$this->_db->Quote('%'.$search_auth.'%');
		}
		
		$where = (count($where) ? ' WHERE '. implode(' AND ', $where) : '');
		return $where;
	}
}
?>