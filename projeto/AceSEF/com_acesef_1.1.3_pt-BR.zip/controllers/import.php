<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Import Controller Class
class AcesefControllerImport extends AcesefController {

	// Main constructer
    function __construct() {
        parent::__construct();
    }
	
	// Import page
    function display() {
        JRequest::setVar('view', 'import');
        JRequest::setVar('layout' , 'default');

        parent::display();
    }
	
	// Go home ;)
	function back() {
		$this->setRedirect('index.php?option=com_acesef');
	}
	
	// Import URLs
    function import() {
        $model = $this->getModel('import');
        
		// Import URLs
		if(!$model->import())
			$msg = JText::_('ACESEF_IMPORT_ERROR');
		else
			$msg = JText::_('ACESEF_IMPORT_SUCCESS');
			
		// Go to Repository
		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view', $msg );
    }
	
	// Migrate form sh404SEF
    function importsh404sef() {
        $model = $this->getModel('import');
			
		// sh404SEF Migration
		if(!$model->importsh404sef())
			$msg = JText::_('sh404SEF ').JText::_('ACESEF_IMPORT_ERROR');
		else
			$msg = JText::_('sh404SEF ').JText::_('ACESEF_IMPORT_SUCCESS');
			
		// Go to Repository
		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view', $msg );
    }
	
	// Migrate form sh404SEF meta data
    function importsh404sefmeta() {
        $model = $this->getModel('import');
			
		// sh404SEF Migration
		if(!$model->importsh404sefmeta())
			$msg = JText::_('sh404SEF ').JText::_('ACESEF_IMPORT_SH404SEF_META_ERROR');
		else
			$msg = JText::_('sh404SEF ').JText::_('ACESEF_IMPORT_SH404SEF_META_SUCCESS');
			
		// Go to Repository
		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view', $msg );
    }
	
	// Migrate form JoomSEF
    function importjoomsef() {
        $model = $this->getModel('import');
		
		// JoomSEF Migration
		if(!$model->importjoomsef())
			$msg = JText::_('JoomSEF ').JText::_('ACESEF_IMPORT_ERROR');
		else
			$msg = JText::_('JoomSEF ').JText::_('ACESEF_IMPORT_SUCCESS');
			
		// Go to Repository
		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view', $msg );
    }
}
?>