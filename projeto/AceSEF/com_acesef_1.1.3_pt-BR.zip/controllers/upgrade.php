<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Upgrade Controller Class
class AcesefControllerUpgrade extends AcesefController {

	// Main constructer
    function __construct() {
        parent::__construct();
    }
	
	// Import page
    function display() {
        JRequest::setVar('view', 'upgrade');
        JRequest::setVar('layout' , 'default');

        parent::display();
    }
	
	// Upgrade
    function upgrade() {
        $model = $this->getModel('upgrade');
        
		// Upgrade
		if(!$model->upgrade())
			$msg = JText::_('ACESEF_UPGRADE_UNSUCCESS');
		else
			$msg = JText::_('ACESEF_UPGRADE_SUCCESS');
			
		// Go to Repository
		$this->setRedirect('index.php?option=com_acesef&controller=upgrade&task=view', $msg);
    }
}
?>