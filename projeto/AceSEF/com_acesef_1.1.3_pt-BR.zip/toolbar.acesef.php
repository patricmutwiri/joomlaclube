<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

$controller	= JRequest::getCmd('controller', 'acesef');

JHTML::_('behavior.switcher');

// Load submenu's
$views	= array(''												=> JText::_('ACESEF_COMMON_HOME'),
				'&controller=config&task=edit'					=> JText::_('ACESEF_CPANEL_CONFIGURATION'),
				'&controller=extensions&task=view'				=> JText::_('ACESEF_CPANEL_EXTENSIONS'),
				'&controller=routers&task=view' 				=> JText::_('ACESEF_CPANEL_ROUTER_SETTINGS'),
				'&controller=repository&task=view'				=> JText::_('ACESEF_CPANEL_URL_REPOSITORY'),
				'&controller=import&task=view'					=> JText::_('ACESEF_CPANEL_IMPORT'),
				'&controller=upgrade&task=view'					=> JText::_('ACESEF_CPANEL_UPGRADE'),
				'&controller=support&task=support'				=> JText::_('ACESEF_CPANEL_SUPPORT')
				);	

foreach($views as $key => $val) {
	$active	= ($controller == $key);
	JSubMenuHelper::addEntry($val, 'index.php?option=com_acesef'.$key, $active);
}
?>