<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Imports
jimport('joomla.application.component.model');
jimport('joomla.filesystem.file');

// Model Class
class AcesefModelImport extends JModel {
	
	// Main constructer
	function __construct() {
		parent::__construct();
	}
	
	// Migrate from sh404SEF
    function importsh404sef() {
        // Get the uploaded file information
        $userfile = JRequest::getVar('importsh404sef', null, 'files', 'array');

        // Make sure that file uploads are enabled in php
        if (!(bool) ini_get('file_uploads')) {
            JError::raiseWarning(100, JText::_('Uploads not allowed.'));
            return false;
        }

        // If there is no uploaded file, we have a problem...
        if (!is_array($userfile)) {
            JError::raiseWarning(100, JText::_('No file selected'));
            return false;
        }

        // Check if there was a problem uploading the file.
        if ($userfile['error'] || $userfile['size'] < 1) {
            JError::raiseWarning(100, JText::_('Error while uploading the file.'));
            return false;
        }

        // Build the appropriate paths
        $config =& JFactory::getConfig();
        $tmp_dest = $config->getValue('config.tmp_path').DS.$userfile['name'];
        $tmp_src = $userfile['tmp_name'];

        // Move uploaded file
        $uploaded = JFile::upload($tmp_src, $tmp_dest);
		
        // Load SQL
        $lines = file($tmp_dest);

        $result = true;
        $dbprefix = $config->getValue('config.dbprefix');
        $command = "INSERT INTO `{$dbprefix}acesef_urls`";
        for ($i = 0, $n = count($lines); $i < $n; $i++) {
            // Trim line
			$line = trim($lines[$i]);
			$delete = "\"id\",\"Count\",\"Rank\",\"SEF URL\",\"non-SEF URL\",\"Date added\"\n";
			$line = str_replace($delete, " ", $line);
			$line = trim(str_replace("\n", " ", $line));
			
			$field = explode('","', $line);
            $this->cleanFields($field);
            $this->shUnEmpty($field);
			
			// Remove lang string if JoomFish not installed :   index.php?option=com_banners&bid=3&lang=en&task=click
			$path = JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_joomfish'.DS.'joomfish.php';
			if (!file_exists($path) && !empty($field[4])) {
				$pos = strpos($field[4], 'lang=');
				$lang = substr($field[4], $pos, 8);
				$field[4] = str_replace($lang, "", $field[4]);
			}
			
			// Generate the SQL line
			$sql1 = "INSERT INTO `{$dbprefix}acesef_urls` (url_sef, url_real, published, used, date) VALUES ";
			$sql2 = "('$field[3]', '$field[4]', '1', '5', '$field[5]');";
			$line = $sql1.$sql2;
			
            // Ignore empty lines
            if (strlen($line) == 0) {
				continue;
			}

            // If the query continues at the next line.
            while (substr($line, -1) != ';' && $i + 1 < count($lines)) {
                $i++;
                $newLine = trim($lines[$i]);
                
				if (strlen($newLine) == 0) {
					continue;
				}
				
                $line .= ' '.$lines[$i];
            }

            if (preg_match('/^INSERT INTO `?(\w)+acesef_urls`?/', $line) > 0) {
                $this->_db->setQuery($line);
                if (!$this->_db->query()) {
                    JError::raiseWarning( 100, JText::_('Error importing line').': '.$line.'<br />'.$this->_db->getErrorMsg());
                    $result = false;
                }
            }
            else {
                JError::raiseWarning(100, JText::_('Ignoring line').': '.$line);
            }
        }
		
        JFile::delete($tmp_dest);
        return $result;
    }
	
	// Migrate from sh404SEF
    function importsh404sefmeta() {
        // Get the uploaded file information
        $userfile = JRequest::getVar('importsh404sefmeta', null, 'files', 'array' );

        // Make sure that file uploads are enabled in php
        if (!(bool) ini_get('file_uploads')) {
            JError::raiseWarning(100, JText::_('Uploads not allowed.'));
            return false;
        }

        // If there is no uploaded file, we have a problem...
        if (!is_array($userfile)) {
            JError::raiseWarning(100, JText::_('No file selected'));
            return false;
        }

        // Check if there was a problem uploading the file.
        if ($userfile['error'] || $userfile['size'] < 1) {
            JError::raiseWarning(100, JText::_('Error while uploading the file.'));
            return false;
        }

        // Build the appropriate paths
        $config =& JFactory::getConfig();
        $tmp_dest = $config->getValue('config.tmp_path').DS.$userfile['name'];
        $tmp_src = $userfile['tmp_name'];

        // Move uploaded file
        $uploaded = JFile::upload($tmp_src, $tmp_dest);
		
        // Load SQL
        $lines = file($tmp_dest);

        $result = true;
        $dbprefix = $config->getValue('config.dbprefix');
        $command = "UPDATE `{$dbprefix}acesef_urls`";
        for ($i = 0, $n = count($lines); $i < $n; $i++) {
            // Trim line
			$line = trim($lines[$i]);
			$line = trim(str_replace(";;", "", $line));
			$delete = '"id","newurl","metadesc","metakey","metatitle","metalang","metarobots"';
			$line = str_replace($delete, " ", $line);
			$line = trim(str_replace("\n", " ", $line));
			
			$field = explode('","', $line);
            $this->cleanFields($field);
            $this->shUnEmpty($field);
			
			// Remove lang string if JoomFish not installed :   index.php?option=com_banners&bid=3&lang=en&task=click
			$path = JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_joomfish'.DS.'joomfish.php';
			if (!file_exists($path) && !empty($field[1])) {
				$pos = strpos($field[1], 'lang=');
				$lang = substr($field[1], $pos, 8);
				$field[1] = str_replace($lang, "", $field[1]);
			}
			
			// Generate the SQL line
			$line = "UPDATE `{$dbprefix}acesef_urls` SET metadesc = '$field[2]', metakey = '$field[3]', metatitle = '$field[4]', metalang = '$field[5]', metarobots = '$field[6]' WHERE url_real = '$field[1]';";
			
            // Ignore empty lines
            if (strlen($line) == 0){
				continue;
			}

            // If the query continues at the next line.
            while (substr($line, -1) != ';' && $i + 1 < count($lines)) {
                $i++;
                $newLine = trim($lines[$i]);
                if (strlen($newLine) == 0) continue;
                $line .= ' '.$lines[$i];
            }

            if (preg_match('/^UPDATE `?(\w)+acesef_urls`?/', $line) > 0) {
                $this->_db->setQuery($line);
                if (!$this->_db->query()) {
                    JError::raiseWarning( 100, JText::_('Error importing line').': '.$line.'<br />'.$this->_db->getErrorMsg());
                    $result = false;
                }
            }
            else {
                JError::raiseWarning(100, JText::_('Ignoring line').': '.$line);
            }
        }
		
        JFile::delete($tmp_dest);
        return $result;
    }
	
	// Migrate from JoomSEF
    function importjoomsef() {
        // Get the uploaded file information
        $userfile = JRequest::getVar('importjoomsef', null, 'files', 'array' );

        // Make sure that file uploads are enabled in php
        if (!(bool) ini_get('file_uploads')) {
            JError::raiseWarning(100, JText::_('Uploads not allowed.'));
            return false;
        }

        // If there is no uploaded file, we have a problem...
        if (!is_array($userfile)) {
            JError::raiseWarning(100, JText::_('No file selected'));
            return false;
        }

        // Check if there was a problem uploading the file.
        if ($userfile['error'] || $userfile['size'] < 1) {
            JError::raiseWarning(100, JText::_('Error while uploading the file.'));
            return false;
        }

        // Build the appropriate paths
        $config =& JFactory::getConfig();
        $tmp_dest = $config->getValue('config.tmp_path').DS.$userfile['name'];
        $tmp_src = $userfile['tmp_name'];

        // Move uploaded file
        $uploaded = JFile::upload($tmp_src, $tmp_dest);

        // Load SQL
        $lines = file($tmp_dest);

        $result = true;
        $dbprefix = $config->getValue('config.dbprefix');
        $command = "INSERT INTO `{$dbprefix}acesef_urls`";
        for ($i = 0, $n = count($lines); $i < $n; $i++) {
		
            // Trim line
			$line = trim($lines[$i]);
			$backupLine = $line;
			
			// First check the table version then remove unwanted parts
			$pos1 = strpos($backupLine, 'jos_sefurls');
			if($pos1 != false){
				$q = "INSERT INTO `{$dbprefix}sefurls` (cpt, sefurl, origurl, Itemid, metadesc, metakey, metatitle, metalang, metarobots, metagoogle, canonicallink, dateadd) VALUES ('";
			} else {
				$q = "INSERT INTO `{$dbprefix}redirection` (cpt, oldurl, newurl, Itemid, metadesc, metakey, metatitle, metalang, metarobots, metagoogle, dateadd) VALUES ('";
			}
			$line = str_replace($q, " ", $line);
			$line = trim(str_replace("');", " ", $line));
			
			// Get fields as array
			$field = array();
			$field = explode("', '", $line);
            $this->cleanFields($field);
			
			$real_url = $field[2];
			$itemId = $field[3];
			
			// Sort JoomSEF URL structure according to AceSEF
			if(!empty($real_url) && !empty($itemId)){
				$urlArray = explode("&", $real_url); // explode url to insert itemid after option
				$real_url = $urlArray[0]."&Itemid=".$itemId; // join itemid
				//for($i = 1; $i < 1; $i++) // add left parts
				//	$real_url .= '&'.$urlArray[$i];
				if(!empty($urlArray[1])) $real_url .= '&'.$urlArray[1];
				if(!empty($urlArray[2])) $real_url .= '&'.$urlArray[2];
				if(!empty($urlArray[3])) $real_url .= '&'.$urlArray[3];
				if(!empty($urlArray[4])) $real_url .= '&'.$urlArray[4];
				if(!empty($urlArray[5])) $real_url .= '&'.$urlArray[5];
				if(!empty($urlArray[6])) $real_url .= '&'.$urlArray[6];
				if(!empty($urlArray[7])) $real_url .= '&'.$urlArray[7];
				if(!empty($urlArray[8])) $real_url .= '&'.$urlArray[8];
			}
				
			// Generate the SQL line
			$sql1 = "INSERT INTO `{$dbprefix}acesef_urls` (url_sef, url_real, metadesc, metakey, metatitle, metalang, metarobots, metagoogle, linkcanonical, published, used, date) VALUES ";
			$find = strpos($backupLine, "{$dbprefix}sefurls");
			if($find != false){
				$sql2 = "('$field[1]', '$real_url', '$field[4]', '$field[5]', '$field[6]', '$field[7]', '$field[8]', '$field[9]', '$field[10]', '1', '5', '$field[11]');";
			} else {
				$sql2 = "('$field[1]', '$real_url', '$field[4]', '$field[5]', '$field[6]', '$field[7]', '$field[8]', '$field[9]', '', '1', '5', '$field[10]');";
			}
			$line = $sql1.$sql2;
			
            // Ignore empty lines
            if (strlen($line) == 0) {
				continue;
			}

            // If the query continues at the next line.
            while (substr($line, -1) != ';' && $i + 1 < count($lines)) {
                $i++;
                $newLine = trim($lines[$i]);
				
                if (strlen($newLine) == 0) {
					continue;
				}
				
                $line .= ' '.$lines[$i];
            }

            if (preg_match('/^INSERT INTO `?(\w)+acesef_urls`?/', $line) > 0) {
                $this->_db->setQuery($line);
                if (!$this->_db->query()) {
                    JError::raiseWarning( 100, JText::_('Error importing line').': '.$line.'<br />'.$this->_db->getErrorMsg());
                    $result = false;
                }
            }
            else {
                JError::raiseWarning(100, JText::_('Ignoring line').': '.$line);
            }
        }
		
        JFile::delete($tmp_dest);
        return $result;
    }
	
	// Import URLs
    function import() {
        // Get the uploaded file information
        $userfile = JRequest::getVar('importurls', null, 'files', 'array' );

        // Make sure that file uploads are enabled in php
        if (!(bool) ini_get('file_uploads')) {
            JError::raiseWarning(100, JText::_('Uploads not allowed.'));
            return false;
        }

        // If there is no uploaded file, we have a problem...
        if (!is_array($userfile)) {
            JError::raiseWarning(100, JText::_('No file selected'));
            return false;
        }

        // Check if there was a problem uploading the file.
        if ($userfile['error'] || $userfile['size'] < 1) {
            JError::raiseWarning(100, JText::_('Error while uploading the file.'));
            return false;
        }

        // Build the appropriate paths
        $config =& JFactory::getConfig();
        $tmp_dest = $config->getValue('config.tmp_path').DS.$userfile['name'];
        $tmp_src = $userfile['tmp_name'];

        // Move uploaded file
        $uploaded = JFile::upload($tmp_src, $tmp_dest);

        // Load SQL
        $lines = file($tmp_dest);

        $result = true;
        $dbprefix = $config->getValue('config.dbprefix');
        $command = "INSERT INTO `{$dbprefix}acesef_urls`";
        for ($i = 0, $n = count($lines); $i < $n; $i++) {
            // Trim line
            $line = trim($lines[$i]);
			
			// First check if the file is exported from AceSEF 1.1.x
			if(strpos($line, 'metacanonical')){
				$line = str_replace('metacanonical', 'linkcanonical', $line);
			}
			
            // Ignore empty lines
            if (strlen($line) == 0) {
				continue;
			}

            // If the query continues at the next line.
            while (substr($line, -1) != ';' && $i + 1 < count($lines)) {
                $i++;
                $newLine = trim($lines[$i]);
				
                if (strlen($newLine) == 0) {
					continue;
				}
				
                $line .= ' '.$lines[$i];
            }

            if (preg_match('/^INSERT INTO `?(\w)+acesef_urls`?/', $line) > 0) {
                $this->_db->setQuery($line);
                if (!$this->_db->query()) {
                    JError::raiseWarning( 100, JText::_('Error importing line').': '.$line.'<br />'.$this->_db->getErrorMsg());
                    $result = false;
                }
            }
            else {
                JError::raiseWarning(100, JText::_('Ignoring line').': '.$line);
            }
        }

        JFile::delete($tmp_dest);
        return $result;
    }
	
	// Import Meta data
    function importmeta() {
        // Get the uploaded file information
        $userfile = JRequest::getVar('importmeta', null, 'files', 'array' );

        // Make sure that file uploads are enabled in php
        if (!(bool) ini_get('file_uploads')) {
            JError::raiseWarning(100, JText::_('Uploads not allowed.'));
            return false;
        }

        // If there is no uploaded file, we have a problem...
        if (!is_array($userfile)) {
            JError::raiseWarning(100, JText::_('No file selected'));
            return false;
        }

        // Check if there was a problem uploading the file.
        if ($userfile['error'] || $userfile['size'] < 1) {
            JError::raiseWarning(100, JText::_('Error while uploading the file.'));
            return false;
        }

        // Build the appropriate paths
        $config =& JFactory::getConfig();
        $tmp_dest = $config->getValue('config.tmp_path').DS.$userfile['name'];
        $tmp_src = $userfile['tmp_name'];

        // Move uploaded file
        $uploaded = JFile::upload($tmp_src, $tmp_dest);
		
        // Load SQL
        $lines = file($tmp_dest);

        $result = true;
        $dbprefix = $config->getValue('config.dbprefix');
        $command = "UPDATE `{$dbprefix}acesef_urls`";
        for ($i = 0, $n = count($lines); $i < $n; $i++) {
            // Trim line
			$line = trim($lines[$i]);
			
			$field = explode(',b,', $line);
			
			// Generate the SQL line
			$line = "UPDATE `{$dbprefix}acesef_urls` SET metatitle = $field[1], metadesc = $field[2], metakey = $field[3], metalang = $field[4], metarobots = $field[5] WHERE url_real = $field[0];";
			
            // Ignore empty lines
            if (strlen($line) == 0) {
				continue;
			}

            // If the query continues at the next line.
            while (substr($line, -1) != ';' && $i + 1 < count($lines)) {
                $i++;
                $newLine = trim($lines[$i]);
				
                if (strlen($newLine) == 0) {
					continue;
				}
				
                $line .= ' '.$lines[$i];
            }

            if (preg_match('/^UPDATE `?(\w)+acesef_urls`?/', $line) > 0) {
                $this->_db->setQuery($line);
                if (!$this->_db->query()) {
                    JError::raiseWarning( 100, JText::_('Error importing line').': '.$line.'<br />'.$this->_db->getErrorMsg());
                    $result = false;
                }
            }
            else {
                JError::raiseWarning(100, JText::_('Ignoring line').': '.$line);
            }
        }
		
        JFile::delete($tmp_dest);
        return $result;
    }
	
	// Import Sitemap
    function importsitemap() {
        // Get the uploaded file information
        $userfile = JRequest::getVar('importsitemap', null, 'files', 'array' );

        // Make sure that file uploads are enabled in php
        if (!(bool) ini_get('file_uploads')) {
            JError::raiseWarning(100, JText::_('Uploads not allowed.'));
            return false;
        }

        // If there is no uploaded file, we have a problem...
        if (!is_array($userfile)) {
            JError::raiseWarning(100, JText::_('No file selected'));
            return false;
        }

        // Check if there was a problem uploading the file.
        if ($userfile['error'] || $userfile['size'] < 1) {
            JError::raiseWarning(100, JText::_('Error while uploading the file.'));
            return false;
        }

        // Build the appropriate paths
        $config =& JFactory::getConfig();
        $tmp_dest = $config->getValue('config.tmp_path').DS.$userfile['name'];
        $tmp_src = $userfile['tmp_name'];

        // Move uploaded file
        $uploaded = JFile::upload($tmp_src, $tmp_dest);
		
        // Load SQL
        $lines = file($tmp_dest);

        $result = true;
        $dbprefix = $config->getValue('config.dbprefix');
        $command = "UPDATE `{$dbprefix}acesef_urls`";
        for ($i = 0, $n = count($lines); $i < $n; $i++) {
            // Trim line
			$line = trim($lines[$i]);
			
			$field = explode(',b,', $line);
			
			// Generate the SQL line
			$line = "UPDATE `{$dbprefix}acesef_urls` SET sm_indexed = $field[1], sm_date = $field[2], sm_freq = $field[3], sm_priority = $field[4] WHERE url_real = $field[0];";
			
            // Ignore empty lines
            if (strlen($line) == 0) {
				continue;
			}

            // If the query continues at the next line.
            while (substr($line, -1) != ';' && $i + 1 < count($lines)) {
                $i++;
                $newLine = trim($lines[$i]);
				
                if (strlen($newLine) == 0) {
					continue;
				}
				
                $line .= ' '.$lines[$i];
            }

            if (preg_match('/^UPDATE `?(\w)+acesef_urls`?/', $line) > 0) {
                $this->_db->setQuery($line);
                if (!$this->_db->query()) {
                    JError::raiseWarning( 100, JText::_('Error importing line').': '.$line.'<br />'.$this->_db->getErrorMsg());
                    $result = false;
                }
            }
            else {
                JError::raiseWarning(100, JText::_('Ignoring line').': '.$line);
            }
        }
		
        JFile::delete($tmp_dest);
        return $result;
    }
	
	// Import Moved URLs
    function importmoved() {
        // Get the uploaded file information
        $userfile = JRequest::getVar('importmoved', null, 'files', 'array' );

        // Make sure that file uploads are enabled in php
        if (!(bool) ini_get('file_uploads')) {
            JError::raiseWarning(100, JText::_('Uploads not allowed.'));
            return false;
        }

        // If there is no uploaded file, we have a problem...
        if (!is_array($userfile)) {
            JError::raiseWarning(100, JText::_('No file selected'));
            return false;
        }

        // Check if there was a problem uploading the file.
        if ($userfile['error'] || $userfile['size'] < 1) {
            JError::raiseWarning(100, JText::_('Error while uploading the file.'));
            return false;
        }

        // Build the appropriate paths
        $config =& JFactory::getConfig();
        $tmp_dest = $config->getValue('config.tmp_path').DS.$userfile['name'];
        $tmp_src = $userfile['tmp_name'];

        // Move uploaded file
        $uploaded = JFile::upload($tmp_src, $tmp_dest);

        // Load SQL
        $lines = file($tmp_dest);

        $result = true;
        $dbprefix = $config->getValue('config.dbprefix');
        $command = "INSERT INTO `{$dbprefix}acesef_urls_moved`";
        for ($i = 0, $n = count($lines); $i < $n; $i++) {
            // Trim line
            $line = trim($lines[$i]);
			
            // Ignore empty lines
            if (strlen($line) == 0) {
				continue;
			}

            // If the query continues at the next line.
            while (substr($line, -1) != ';' && $i + 1 < count($lines)) {
                $i++;
                $newLine = trim($lines[$i]);
				
                if (strlen($newLine) == 0) {
					continue;
				}
				
                $line .= ' '.$lines[$i];
            }

            if (preg_match('/^INSERT INTO `?(\w)+acesef_urls_moved`?/', $line) > 0) {
                $this->_db->setQuery($line);
                if (!$this->_db->query()) {
                    JError::raiseWarning( 100, JText::_('Error importing line').': '.$line.'<br />'.$this->_db->getErrorMsg());
                    $result = false;
                }
            }
            else {
                JError::raiseWarning(100, JText::_('Ignoring line').': '.$line);
            }
        }

        JFile::delete($tmp_dest);
        return $result;
    }
	
	function cleanFields(&$fields) {
        for($i = 0, $n = count($fields); $i < $n; $i++) {
			$fields[$i] = str_replace(array('"', '\'', '#', '`', '�', '�', '�'), '', $fields[$i]);
        }
    }

    function shUnEmpty(&$fields) {
        for($i = 0, $n = count($fields); $i < $n; $i++) {
            if($fields[$i] == '&nbsp') {
                $fields[$i] = '';
            }
        }
    }
}
?>