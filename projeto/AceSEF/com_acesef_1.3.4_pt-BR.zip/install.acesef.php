<?php
/*
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('JPATH_BASE') or die('Restricted Access');

// Import Libraries
jimport('joomla.installer.installer');
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

global $mainframe;

// Install the extension installer adapter
$adpSrc = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'adapters'.DS.'acesef_ext.php';
$adpDst = JPATH_LIBRARIES.DS.'joomla'.DS.'installer'.DS.'adapters'.DS.'acesef_ext.php';
if(is_writable(dirname($adpDst))){
	JFile::copy($adpSrc, $adpDst);
}

// Install AceSEF system plugin
$plgSrc = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'plugin'.DS;
$plgDst = JPATH_ROOT.DS.'plugins'.DS.'system'.DS;
$plgCopied = JFile::copy($plgSrc.'acesef.php', $plgDst.'acesef.php');
$plgCopied = $plgCopied && JFile::copy($plgSrc.'acesef.xml', $plgDst.'acesef.xml');

// Check the sitemap file
$sitemap = JPATH_ROOT.DS.'sitemap.xml';
if(!JFile::exists($sitemap)) {
	JFile::write($sitemap, '');
}

// Make the redirection to AceSEF Control Panel with the proper message
if ($plgCopied) {
	$mainframe->redirect('index.php?option=com_acesef', 'AceSEF installed succesfully!');
} else {
	$mainframe->redirect('index.php?option=com_acesef', JError::raiseWarning(100, JText::_('AceSEF plugin is not installed. Please upload the files in plugin folder manually')));
}
?>