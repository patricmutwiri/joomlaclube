<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

function acesef_404handler ($acesef_config, $url2search) {
	if ($acesef_config->log_404_errors == '1' && $acesef_config->log_404_path != '') {
		// check if the file is writeble;
		if (!(JPath::isOwner($acesef_config->log_404_path) && !JPath::setPermissions($acesef_config->log_404_path, '0755'))) {
			if ($handle = fopen($acesef_config->log_404_path, 'a')) {
				// Make a line based logfile, date;
				$log_string = date('Y-m-d G:i:s');
				$log_string .= ';'.$url2search ;
				fwrite($handle, "\n".$log_string);
				//fwrite ( $handle,  );
				fclose($handle);
			}
		}
	}
}
?>