<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport('joomla.application.component.view');

// Control Panel View Class
class AcesefViewAcesef extends JView {
	
	// Display cpanel
	function display($tpl = null) {
		// Load pane behavior
		jimport('joomla.html.pane');

		// Initialise variables
		$document	= & JFactory::getDocument();
		$pane   	= & JPane::getInstance('sliders');
		
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		JToolBarHelper::title(JText::_('ACESEF_COMMON_PANEL'), 'acesef');
		
		// Get data from the model
		$info = & $this->get('Info');

		// Assign vars to the template
		$this->assignRef('pane', $pane);
		$this->assignRef('info', $info);

		parent::display($tpl);
	}

	// Quickicon Buttons
	function quickiconButton( $link, $image, $text, $modal = 0 ) {
		//initialise variables
		$lang = & JFactory::getLanguage();
  		?>

		<div style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
			<div class="icon">
				<?php
				if ($modal == 1) {
					JHTML::_('behavior.modal');
				?>
					<a href="<?php echo $link.'&amp;tmpl=component'; ?>" style="cursor:pointer" class="modal" rel="{handler: 'iframe', size: {x: 650, y: 400}}">
				<?php
				} else {
				?>
					<a href="<?php echo $link; ?>">
				<?php
				}
					echo JHTML::_('image', 'administrator/components/com_acesef/assets/images/'.$image, $text );
				?>
					<span><?php echo $text; ?></span>
				</a>
			</div>
		</div>
		<?php
	}
}
?>