<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');
jimport('joomla.application.component.helper');
jimport('joomla.application.component.model');
jimport('joomla.filesystem.file');
jimport('joomla.installer.installer');
jimport('joomla.installer.helper');

// Inlcude extension installation adapter
require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'adapters'.DS.'acesef_ext.php');

// Controller Class
class AcesefControllerExtensions extends AcesefController {
	
	// Main constructer
	function __construct() 	{
		parent::__construct();
	}

	// Display extensions
	function view() {
		$model =& $this->getModel('extensions');
		$model->view_setExtensions();
		$view = $this->getView('extensions', 'html');
		$view->setModel($model, true);
		$view->view();
	}

	// Edit extension
	function edit() {
		$model =& $this->getModel('extensions');
		$view  = $this->getView('extensions', 'edit');
		$view->setModel($model, true);
		$view->edit('edit');
	}
	
	// Uninstall extensions
	function view_uninstall() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('extensions');
		foreach ($cid as $id) {
			$model->view_uninstall($id);
		}
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view', JTEXT::_('ACESEF_EXTENSIONS_VIEW_REMOVED'));
	}
	
	// Save changes
	function view_save() {
		$model =& $this->getModel('extensions');
		$model->view_save();
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view', JTEXT::_('ACESEF_EXTENSIONS_VIEW_SAVED'));
	}
	
	// Save changes & Purge URLs
	function view_savepurge() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('extensions');
		foreach ($cid as $id) {
			$model->view_savepurge($id);
		}
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view', JTEXT::_('ACESEF_EXTENSIONS_VIEW_SAVED_PURGED'));
	}
	
	// Go home ;)
	function view_home() {
		// Return
		$this->setRedirect('index.php?option=com_acesef');
	}
	
	// Install a new extension
	function view_install() {
		
		// Check if the extensions directory is writable
		$directory = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'extensions';
		if (!is_writable($directory)) {
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSIONS_VIEW_INSTALL_DIR_CHMOD_ERROR'));
		}
		
		$result = false;
		// Make sure that file uploads are enabled in php
		if (!(bool) ini_get('file_uploads')) {
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSIONS_VIEW_INSTALL_PHP_SETTINGS'));
			$result = false;
			return false;
		}

		// Make sure that zlib is loaded so that the package can be unpacked
		if (!extension_loaded('zlib')) {
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSIONS_VIEW_INSTALL_PHP_ZLIB'));
			$result = false;
			return false;
		}

		$userfile = JRequest::getVar('install_package', null, 'files', 'array');

		// If there is no uploaded file, we have a problem...
		if (!is_array($userfile)) {
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSIONS_VIEW_INSTALL_NO_FILE'));
			$result = false;
			return false;
		}

		// Check if there was a problem uploading the file.
		if ($userfile['error'] || $userfile['size'] < 1) {
			JError::raiseWarning('1001', JText::_('WARNINSTALLUPLOADERROR'));
			$result = false;
			return false;
		}

		$config =& JFactory::getConfig();
		$tmp_dest = $config->getValue('config.tmp_path').DS.$userfile['name'];
		$tmp_src = $userfile['tmp_name'];

		// Move uploaded file
		$uploaded = JFile::upload($tmp_src, $tmp_dest);
		$package = JInstallerHelper::unpack($tmp_dest);

		// Get an installer instance
		$installer =& JInstaller::getInstance();
		$adapter = new JInstallerAcesef_Ext($installer);
		$installer->_adapters['acesef_ext'] =& $adapter;

		// Install the package
		if (!$installer->install($package['dir'])) {
			// There was an error installing the package
			$msg = JText::sprintf('INSTALLEXT', JText::_($package['type']), JText::_('Error'));
			$result = false;
		} else {
			// Package installed sucessfully
			$msg = JText::sprintf('INSTALLEXT', JText::_($package['type']), JText::_('Success'));
			$result = true;
		}

		// Cleanup the install files
		if (!is_file($package['packagefile'])) {
			$config =& JFactory::getConfig();
			$package['packagefile'] = $config->getValue('config.tmp_path').DS.$package['packagefile'];
		}
		JInstallerHelper::cleanupInstall($package['packagefile'], $package['extractdir']);
		if(!$result){
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSIONS_VIEW_NOT_INSTALLED'));
		} else {
			// Return
			$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view', JTEXT::_('ACESEF_EXTENSIONS_VIEW_INSTALLED'));
		}
		return $package;

	}
	
	// Upgrade extension
	function view_upgrade() {
		
		// Check if the extensions directory is writable
		$directory = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'extensions';
		if (!is_writable($directory)) {
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSIONS_VIEW_INSTALL_DIR_CHMOD_ERROR'));
		}
		
		$result = false;
		
		// Make sure that file uploads are enabled in php
		if (!(bool) ini_get('file_uploads')) {
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSIONS_VIEW_INSTALL_PHP_SETTINGS'));
			$result = false;
			return false;
		}

		// Make sure that zlib is loaded so that the package can be unpacked
		if (!extension_loaded('zlib')) {
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSIONS_VIEW_INSTALL_PHP_ZLIB'));
			$result = false;
			return false;
		}
		
		// Get info
		$ext = JRequest::getVar('acesefext');
		$url = JRequest::getVar('aceseffile');

		// Download the package at the URL given
		$p_file = JInstallerHelper::downloadPackage($url);
		
		// Was the package downloaded?
		if (!$p_file) {
			JError::raiseWarning('SOME_ERROR_CODE', JText::_('Invalid Download-ID'));
			return false;
		}
		
		// Delete old files
		$ext_php = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.$ext.'.php';
		$ext_xml = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.$ext.'.xml';
		JFile::delete($ext_php);
		JFile::delete($ext_xml);

		$config =& JFactory::getConfig();
		$tmp_dest = $config->getValue('config.tmp_path');

		// Unpack the downloaded package file
		$package = JInstallerHelper::unpack($tmp_dest.DS.$p_file);

		// Get an installer instance
		$installer =& JInstaller::getInstance();
		$adapter = new JInstallerAcesef_Ext($installer);
		$installer->_adapters['acesef_ext'] =& $adapter;

		// Install the package
		if (!$installer->install($package['dir'])) {
			// There was an error installing the package
			$msg = JText::sprintf('INSTALLEXT', JText::_($package['type']), JText::_('Error'));
			$result = false;
		} else {
			// Package installed sucessfully
			$msg = JText::sprintf('INSTALLEXT', JText::_($package['type']), JText::_('Success'));
			$result = true;
		}

		// Cleanup the install files
		if (!is_file($package['packagefile'])) {
			$config =& JFactory::getConfig();
			$package['packagefile'] = $config->getValue('config.tmp_path').DS.$package['packagefile'];
		}
		JInstallerHelper::cleanupInstall($package['packagefile'], $package['extractdir']);
		if(!$result){
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSIONS_VIEW_NOT_UPGRADED'));
		} else {
			// Return
			$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view', JTEXT::_('ACESEF_EXTENSIONS_VIEW_UPGRADED'));
		}
		return $package;

	}
	
	// Save changes
	function edit_save() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('extensions');
		if (!$model->edit_save($id)) {
			return JError::raiseWarning(500, $url_record->getError());
		}
		
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view', JTEXT::_('ACESEF_EXTENSIONS_EDIT_SAVED'));
	}
	
	// Apply changes
	function edit_apply() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('extensions');
		if (!$model->edit_apply($id)) {
			return JError::raiseWarning(500, $url_record->getError());
		}
		
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=edit&cid[]='.$id, JTEXT::_('ACESEF_EXTENSIONS_EDIT_SAVED'));
	}
	
	// Go to extensions page
	function edit_cancel() {
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view');
	}
	
	// Save changes and Purge URLs of this extension
	function edit_savepurge() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('extensions');
		if (!$model->edit_savepurge($id)) {
			return JError::raiseWarning(500, $url_record->getError());
		}
		
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view', JTEXT::_('ACESEF_EXTENSIONS_EDIT_SAVED_PURGED'));
	}
	
	// Apply changes and Purge URLs of this extension
	function edit_applypurge() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('extensions');
		if (!$model->edit_applypurge($id)) {
			return JError::raiseWarning(500, $url_record->getError());
		}
		
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=edit&cid[]='.$id, JTEXT::_('ACESEF_EXTENSIONS_EDIT_SAVED_PURGED'));
	}
}
?>