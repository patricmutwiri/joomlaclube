<?php
/**
* @version		1.5.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009-2010 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

//No Permision
defined('_JEXEC') or die('Restricted access');
?>
<table align="center">
	<tr>
		<td nowrap="nowrap">
			<br/><b><?php echo JText::_('ACESEF_COMMON_PRO_VERSION'); ?></b><br/><br/>
		</td>
	</tr>
	<tr>
		<td width="505">
			<a href="http://www.joomace.net/joomla-extensions/acesef" target="_blank">
			<img border="0" src="http://www.joomace.net/acesef_packages.png" width="505" height="413">
			</a>
		</td>
	</tr>
</table>