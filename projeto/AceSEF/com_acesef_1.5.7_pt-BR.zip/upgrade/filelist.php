<?php
/**
* @version		1.5.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009-2010 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// Files
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'acesef.xml', 'acesef.xml');
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'acesef.php', 'admin'.DS.'acesef.php');
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'index.html', 'admin'.DS.'index.html');
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'install.php', 'admin'.DS.'install.php');
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'install.sql', 'admin'.DS.'install.sql');
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'toolbar.php', 'admin'.DS.'toolbar.acesef.php');
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'uninstall.php', 'admin'.DS.'uninstall.php');
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'uninstall.sql', 'admin'.DS.'uninstall.sql');

// Folders
$this->_addFile(JPATH_ACESEF, 'site', 'upgrade', true);
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'adapters', 'admin'.DS.'adapters', 'upgrade', true);
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'assets', 'admin'.DS.'assets', 'upgrade', true);
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'controllers', 'admin'.DS.'controllers', 'upgrade', true);
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'extensions', 'admin'.DS.'extensions', 'upgrade', true);
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'library', 'admin'.DS.'library', 'upgrade', true);
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'models', 'admin'.DS.'models', 'upgrade', true);
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'tables', 'admin'.DS.'tables', 'upgrade', true);
$this->_addFile(JPATH_ACESEF_ADMIN.DS.'views', 'admin'.DS.'views', 'upgrade', true);

// Languages
$this->_addFile(JPATH_ROOT.DS.'language', DS.'languages'.DS.'site', 'upgrade', true);
$this->_addFile(JPATH_ROOT.DS.'administrator'.DS.'language', DS.'languages'.DS.'admin', 'upgrade', true);

// Plugins
$this->_addFile(JPATH_ROOT.DS.'plugins'.DS.'system'.DS.'acesef.php', DS.'plugins'.DS.'acesef'.DS.'acesef.php', 'upgrade');
$this->_addFile(JPATH_ROOT.DS.'plugins'.DS.'system'.DS.'acesef.xml', DS.'plugins'.DS.'acesef'.DS.'acesef.xml', 'upgrade');
$this->_addFile(JPATH_ROOT.DS.'plugins'.DS.'system'.DS.'acesefmetacontent.php', DS.'plugins'.DS.'acesefmetacontent'.DS.'acesefmetacontent.php', 'upgrade');
$this->_addFile(JPATH_ROOT.DS.'plugins'.DS.'system'.DS.'acesefmetacontent.xml', DS.'plugins'.DS.'acesefmetacontent'.DS.'acesefmetacontent.xml', 'upgrade');
$this->_addFile(JPATH_ROOT.DS.'plugins'.DS.'system'.DS.'acesefmetacontent_tmpl.php', DS.'plugins'.DS.'acesefmetacontent'.DS.'acesefmetacontent_tmpl.php', 'upgrade');

// Modules
$this->_addFile(JPATH_ROOT.DS.'administrator'.DS.'modules'.DS.'mod_acesef_quickicons'.DS.'mod_acesef_quickicons.xml', DS.'modules'.DS.'mod_acesef_quickicons'.DS.'mod_acesef_quickicons.xml', 'upgrade');
$this->_addFile(JPATH_ROOT.DS.'administrator'.DS.'modules'.DS.'mod_acesef_quickicons'.DS.'mod_acesef_quickicons.php', DS.'modules'.DS.'mod_acesef_quickicons'.DS.'mod_acesef_quickicons.php', 'upgrade');

// Adapter
$this->_addFile(JPATH_ROOT.DS.'libraries'.DS.'joomla'.DS.'installer'.DS.'adapters'.DS.'acesef_ext.php', DS.'admin'.DS.'adapters'.DS.'acesef_ext.php', 'upgrade');

?>