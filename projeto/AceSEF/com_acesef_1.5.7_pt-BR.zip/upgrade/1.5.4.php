<?php
/**
* @version		1.5.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU GPL
*/

require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
if (class_exists('AcesefConfig')) {
	$AcesefConfig = new AcesefConfig();
	$AcesefConfig->sm_auto_cron_mode = '0';
	
	// Store the configuration
	jimport('joomla.filesystem.file');
	jimport('joomla.filesystem.folder');
	$config = new JRegistry('config');
	$config->loadObject($AcesefConfig);
	if (!JFile::write(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php', $config->toString('PHP', 'config', array('class' => 'AcesefConfig')))) {
		$msg = JText::_('Error writing AceSEF configuration');
	}
}

?>