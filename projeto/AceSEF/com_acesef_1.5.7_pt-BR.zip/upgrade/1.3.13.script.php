<?php
/**
* @version		1.5.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009-2010 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

upgradeConfig();
upgradeURLsTable();
upgradeExtensionsTable();
upgradeOtherTables();

function upgradeURLsTable() {
	$db =& JFactory::getDBO();
	
	// Rename table
	$db->setQuery("RENAME TABLE #__acesef_urls TO #__acesef_urls_upgrade");
	$db->query();
	
	// Create new tables
	$db->setQuery("CREATE TABLE IF NOT EXISTS `#__acesef_urls` (
  `id` INT(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `url_sef` VARCHAR(255) NOT NULL DEFAULT '',
  `url_real` VARCHAR(255) NOT NULL DEFAULT '',
  `cdate` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mdate` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
  `used` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `hits` INT(12) UNSIGNED NOT NULL DEFAULT '0',
  `source` TEXT NOT NULL,
  `params` TEXT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url_real` (`url_real`),
  KEY `url_sef` (`url_sef`)
) TYPE=MyISAM CHARACTER SET `utf8`;");
	$db->query();
	
	$db->setQuery("CREATE TABLE IF NOT EXISTS `#__acesef_metadata` (
  `id` INT(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `url_sef` VARCHAR(255) NOT NULL DEFAULT '',
  `published` TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
  `title` VARCHAR(255) NOT NULL DEFAULT '',
  `description` VARCHAR(255) NOT NULL DEFAULT '',
  `keywords` VARCHAR(255) NOT NULL DEFAULT '',
  `lang` VARCHAR(30) NOT NULL DEFAULT '',
  `robots` VARCHAR(30) NOT NULL DEFAULT '',
  `googlebot` VARCHAR(30) NOT NULL DEFAULT '',
  `canonical` VARCHAR(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url_sef` (`url_sef`)
) TYPE=MyISAM CHARACTER SET `utf8`;");
	$db->query();
	
	$db->setQuery("CREATE TABLE IF NOT EXISTS `#__acesef_sitemap` (
  `id` INT(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `url_sef` VARCHAR(255) NOT NULL DEFAULT '',
  `published` TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
  `sdate` DATE NOT NULL DEFAULT '0000-00-00',
  `frequency` VARCHAR(30) NOT NULL DEFAULT '',
  `priority` VARCHAR(10) NOT NULL DEFAULT '',
  `sparent` INT(12) UNSIGNED NOT NULL DEFAULT '0',
  `sorder` INT(5) UNSIGNED NOT NULL DEFAULT '1000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url_sef` (`url_sef`)
) TYPE=MyISAM CHARACTER SET `utf8`;");
	$db->query();
	
	$offset = 0;
	
	// Get URLs
	do {
		$have_data = false;
		
		$db->setQuery("SELECT * FROM #__acesef_urls_upgrade ORDER BY id LIMIT {$offset}, 500");
		$rows = $db->loadObjectList();
		
		if (!empty($rows)) {
			$have_data = true;
			
			foreach ($rows as $row) {
				$url_real = $row->url_real;
				$notfound = 0;
				if ($url_real == "") {
					$url_real = $row->url_sef;
					$notfound = 1;
				}
				
				$custom = 0;
				if ($row->date != '0000-00-00') {
					$custom = 1;
				}
				
				$u = $row->used;
				switch($u) {
					case 10:
						$used = 2;
						break;
					case 0:
						$used = 1;
						break;
					case 5:
						$used = 0;
						break;
					default:
						$used = 0;
						break;
				}
				
				$notes = cleanText($row->notes);
				
				$params = "custom={$custom}";
				$params .= "\npublished={$row->published}";
				$params .= "\nlocked={$row->locked}";
				$params .= "\nblocked={$row->blocked}";
				$params .= "\ntrashed=0";
				$params .= "\nnotfound={$notfound}";
				$params .= "\ntags=0";
				$params .= "\nilinks=0";
				$params .= "\nbookmarks=0";
				$params .= "\nvisited=0";
				$params .= "\nnotes={$notes}";
				
				// URLs
				$f_url = "url_sef, url_real, mdate, used, source, params";
				$v_url = "'{$row->url_sef}', '{$url_real}', '{$row->date} 00:00:00', '{$used}', ' ', '{$params}'";
				$db->setQuery("INSERT INTO #__acesef_urls ({$f_url}) VALUES ({$v_url})");
				$db->query();
				
				// Metadata
				$no_meta = (empty($row->metatitle) && empty($row->metadesc) && empty($row->metakey));
				$db->setQuery("SELECT url_sef FROM #__acesef_metadata WHERE url_sef = '{$row->url_sef}'");
				$metadata = $db->loadObject();
				if (!$no_meta && !is_object($metadata)) {
					$f_meta = "url_sef, title, description, keywords, lang, robots, googlebot, canonical";
					$title = cleanText($row->metatitle);
					$desc = cleanText($row->metadesc);
					$key = cleanText($row->metakey);
					$v_meta = "'{$row->url_sef}', '{$title}', '{$desc}', '{$rkey}', '{$row->metalang}', '{$row->metarobots}', '{$row->metagoogle}', '{$row->linkcanonical}'";
					$db->setQuery("INSERT INTO #__acesef_metadata ({$f_meta}) VALUES ({$v_meta})");
					$db->query();
				}
				
				// Sitemap
				$db->setQuery("SELECT url_sef FROM #__acesef_sitemap WHERE url_sef = '{$row->url_sef}'");
				$sitemap = $db->loadObject();
				if (!is_object($sitemap)) {
					$f_sitemap = "url_sef, published, sdate, frequency, priority, sparent, sorder";
					$v_sitemap = "'{$row->url_sef}', '{$row->sm_indexed}', '{$row->sm_date}', '{$row->sm_freq}', '{$row->sm_priority}', '0', '1000'";
					$db->setQuery("INSERT INTO #__acesef_sitemap ({$f_sitemap}) VALUES ({$v_sitemap})");
					$db->query();
				}
			}
		}
		
		$offset += 500;
		
	} while ($have_data);
}

function upgradeExtensionsTable() {
	$db =& JFactory::getDBO();
	
	// Get URLs
	$db->setQuery("SELECT name, params, extension, router_type, rewrite_rule, component_prefix, skip_title FROM #__acesef_extensions");
	$rows = $db->loadObjectList();
	
	// Rename table
	$db->setQuery("RENAME TABLE #__acesef_extensions TO #__acesef_extensions_upgrade");
	$db->query();
	
	// Create new tables
	$db->setQuery("CREATE TABLE IF NOT EXISTS `#__acesef_extensions` (
  `id` INT(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL DEFAULT '',
  `extension` VARCHAR(45) NOT NULL DEFAULT '',
  `params` TEXT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `extension` (`extension`)
) TYPE=MyISAM CHARACTER SET `utf8`;");
	$db->query();
	
	if (!empty($rows)) {
		foreach ($rows as $row) {
			$prm = new JParameter($row->params);
			$prm->set('router', $row->rewrite_rule);
			$prm->set('prefix', $row->component_prefix);
			$prm->set('skip_menu', $row->skip_title);
			
			$params = $prm->toString();
			
			$f = "name, extension, params";
			$v = "'{$row->name}', '{$row->extension}', '{$params}'";
			$db->setQuery("INSERT INTO #__acesef_extensions ({$f}) VALUES ({$v})");
			$db->query();
		}
		
		$f = "name, extension, params";
		$v = "'AceSEF', 'com_acesef', 'router=3\nprefix=\nskip_menu=0'";
		$db->setQuery("INSERT INTO #__acesef_extensions ({$f}) VALUES ({$v})");
		$db->query();
	}	
}

function upgradeOtherTables() {
	$db =& JFactory::getDBO();
	
	// Create new tables
	$db->setQuery("CREATE TABLE IF NOT EXISTS `#__acesef_tags` (
  `id` INT(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(150) NOT NULL DEFAULT '',
  `alias` VARCHAR(150) NOT NULL DEFAULT '',
  `description` VARCHAR(150) NOT NULL DEFAULT '',
  `published` TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
  `ordering` INT(12) NOT NULL DEFAULT '0',
  `hits` INT(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) TYPE=MyISAM CHARACTER SET `utf8`;");
	$db->query();
	
	$db->setQuery("CREATE TABLE IF NOT EXISTS `#__acesef_tags_map` (
  `url_sef` VARCHAR(255) NOT NULL DEFAULT '',
  `tag` VARCHAR(150) NOT NULL DEFAULT ''
) TYPE=MyISAM CHARACTER SET `utf8`;");
	$db->query();
	
	$db->setQuery("CREATE TABLE IF NOT EXISTS `#__acesef_ilinks` (
  `id` INT(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `word` VARCHAR(255) NOT NULL DEFAULT '',
  `link` VARCHAR(255) NOT NULL DEFAULT '',
  `published` TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
  `nofollow` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `iblank` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `ilimit` VARCHAR(30) NOT NULL DEFAULT '10',
  PRIMARY KEY (`id`),
  UNIQUE KEY `word` (`word`)
) TYPE=MyISAM CHARACTER SET `utf8`;");
	$db->query();
	
	$db->setQuery("CREATE TABLE IF NOT EXISTS `#__acesef_bookmarks` (
  `id` INT(12) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL DEFAULT '',
  `html` TEXT NOT NULL DEFAULT '',
  `btype` VARCHAR(20) NOT NULL DEFAULT '',
  `placeholder` VARCHAR(150) NOT NULL DEFAULT '',
  `published` TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) TYPE=MyISAM CHARACTER SET `utf8`;");
	$db->query();
}

function upgradeConfig() {
	require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
	$AcesefConfig = new acesef_configuration();
	
	$AcesefConfig->generate_sef = '1';
	$AcesefConfig->purge_ext_urls = '1';
	$AcesefConfig->cache_instant = '1';
	$AcesefConfig->cache_versions = '1';
	$AcesefConfig->cache_extensions = '0';
	$AcesefConfig->cache_urls = '0';
	$AcesefConfig->cache_urls_size = '10000';
	$AcesefConfig->cache_metadata = '0';
	$AcesefConfig->cache_sitemap = '0';
	$AcesefConfig->cache_urls_moved = '0';
	$AcesefConfig->cache_tags = '0';
	$AcesefConfig->cache_ilinks = '1';
	$AcesefConfig->joomfish_main_lang_del = '0';
	$AcesefConfig->joomfish_cookie = '1';
	$AcesefConfig->joomfish_browser = '1';
	$AcesefConfig->skip_menu_vars = '';
	$AcesefConfig->redirect_to_sef_gen = '0';
	$AcesefConfig->jsef_to_acesef = '1';
	$AcesefConfig->force_ssl = array();
	$AcesefConfig->url_append_limit = '0';
	$AcesefConfig->prevent_dup_error = '1';
	$AcesefConfig->show_db_errors = '0';
	$AcesefConfig->check_url_by_id = '1';
	$AcesefConfig->meta_core = '1';
	$AcesefConfig->meta_title_tag = '1';
	$AcesefConfig->meta_generator_rem = '1';
	$AcesefConfig->meta_key_whitelist = '';
	$AcesefConfig->sm_ping_type = 'link';
	$AcesefConfig->sm_xml_date = '1';
	$AcesefConfig->sm_xml_freq = '1';
	$AcesefConfig->sm_xml_prior = '1';
	$AcesefConfig->sm_auto_mode = '1';
	$AcesefConfig->sm_auto_components = array("0" => "com_content");
	$AcesefConfig->sm_auto_enable_cats = '0';
	$AcesefConfig->sm_auto_filter_s = '.pdf';
	$AcesefConfig->sm_auto_filter_r = 'format=pdf, format=feed, type=rss';
	$AcesefConfig->sm_auto_cron_mode = '0';
	$AcesefConfig->sm_auto_cron_freq = '24';
	$AcesefConfig->sm_auto_cron_last = '1283362008';
	$AcesefConfig->sm_auto_xml = '1';
	$AcesefConfig->sm_auto_ping_c = '0';
	$AcesefConfig->sm_auto_ping_s = '0';
	$AcesefConfig->tags_mode = '1';
	$AcesefConfig->tags_area = '1';
	$AcesefConfig->tags_components = array("0" => "com_content");
	$AcesefConfig->tags_enable_cats = '0';
	$AcesefConfig->tags_in_cats = '0';
	$AcesefConfig->tags_in_page = '15';
	$AcesefConfig->tags_order = 'ordering';
	$AcesefConfig->tags_position = '2';
	$AcesefConfig->tags_limit = '20';
	$AcesefConfig->tags_show_tag_desc = '0';
	$AcesefConfig->tags_show_prefix = '1';
	$AcesefConfig->tags_show_item_desc = '1';
	$AcesefConfig->tags_exp_item_desc = '0';
	$AcesefConfig->tags_published = '1';
	$AcesefConfig->tags_auto_mode = '0';
	$AcesefConfig->tags_auto_components = array("0" => "com_content");
	$AcesefConfig->tags_auto_length = '4';
	$AcesefConfig->tags_auto_filter_s = '.pdf';
	$AcesefConfig->tags_auto_filter_r = 'format=pdf, format=feed, type=rss';
	$AcesefConfig->tags_auto_blacklist = 'a, able, about, above, abroad, according, accordingly, across, actually, adj, after, afterwards, again, against, ago, ahead, ain\'t, all, allow, allows, almost, alone, along, alongside, already, also, although, always, am, amid, amidst, among, amongst, an, and, another, any, anybody, anyhow, anyone, anything, anyway, anyways, anywhere, apart, appear, appreciate, appropriate, are, aren\'t, around, as, a\'s, aside, ask, asking, associated, at, available, away, awfully, b, back, backward, backwards, be, became, because, become, becomes, becoming, been, before, beforehand, begin, behind, being, believe, below, beside, besides, best, better, between, beyond, both, brief, but, by, c, came, can, cannot, cant, can\'t, caption, cause, causes, certain, certainly, changes, clearly, c\'mon, co, co., com, come, comes, concerning, consequently, consider, considering, contain, containing, contains, corresponding, could, couldn\'t, course, c\'s, currently, d, dare, daren\'t, definitely, described, despite, did, didn\'t, different, directly, do, does, doesn\'t, doing, done, don\'t, down, downwards, during, e, each, edu, eg, eight, eighty, either, else, elsewhere, end, ending, enough, entirely, especially, et, etc, even, ever, evermore, every, everybody, everyone, everything, everywhere, ex, exactly, example, except, f, fairly, far, farther, few, fewer, fifth, first, five, followed, following, follows, for, forever, former, formerly, forth, forward, found, four, from, further, furthermore, g, get, gets, getting, given, gives, go, goes, going, gone, got, gotten, greetings, h, had, hadn\'t, half, happens, hardly, has, hasn\'t, have, haven\'t, having, he, he\'d, he\'ll, hello, help, , hence, her, here, hereafter, hereby, herein, here\'s, hereupon, hers, herself, he\'s, hi, him, himself, his, hither, hopefully, how, howbeit, however, hundred, i, i\'d, ie, if, ignored, i\'ll, i\'m, immediate, in, inasmuch, inc, inc., indeed, indicate, indicated, indicates, inner, inside, insofar, instead, into, inward, is, isn\'t, it, it\'d, it\'ll, its, it\'s, itself, i\'ve, j, just, k, keep, keeps, kept, know, known, knows, l, last, lately, later, latter, latterly, least, less, lest, let, let\'s, like, liked, likely, likewise, little, look, looking, looks, low, lower, ltd, m, made, mainly, make, makes, many, may, maybe, mayn\'t, me, mean, meantime, meanwhile, merely, might, mightn\'t, mine, minus, miss, more, moreover, most, mostly, mr, mrs, much, must, mustn\'t, my, myself, n, name, namely, nd, near, nearly, necessary, need, needn\'t, needs, neither, never, neverf, neverless, nevertheless, new, next, nine, ninety, no, nobody, non, none, nonetheless, noone, no-one, nor, normally, not, nothing, notwithstanding, novel, now, nowhere, o, obviously, of, off, often, oh, ok, okay, old, on, once, one, ones, one\'s, only, onto, opposite, or, other, others, otherwise, ought, oughtn\'t, our, ours, ourselves, out, outside, over, overall, own, p, particular, particularly, past, per, perhaps, placed, please, plus, possible, presumably, probably, provided, provides, q, que, quite, qv, r, rather, rd, re, really, reasonably, recent, recently, regarding, regardless, regards, relatively, respectively, right, round, s, said, same, saw, say, saying, says, second, secondly, , see, seeing, seem, seemed, seeming, seems, seen, self, selves, sensible, sent, serious, seriously, seven, several, shall, shan\'t, she, she\'d, she\'ll, she\'s, should, shouldn\'t, since, six, so, some, somebody, someday, somehow, someone, something, sometime, sometimes, somewhat, somewhere, soon, sorry, specified, specify, specifying, still, sub, such, sup, sure, t, take, taken, taking, tell, tends, th, than, thank, thanks, thanx, that, that\'ll, thats, that\'s, that\'ve, the, their, theirs, them, themselves, then, thence, there, thereafter, thereby, there\'d, therefore, therein, there\'ll, there\'re, theres, there\'s, thereupon, there\'ve, these, they, they\'d, they\'ll, they\'re, they\'ve, thing, things, think, third, thirty, this, thorough, thoroughly, those, though, three, through, throughout, thru, thus, till, to, together, too, took, toward, towards, tried, tries, truly, try, trying, t\'s, twice, two, u, un, under, underneath, undoing, unfortunately, unless, unlike, unlikely, until, unto, up, upon, upwards, us, use, used, useful, uses, using, usually, v, value, various, versus, very, via, viz, vs, w, want, wants, was, wasn\'t, way, we, we\'d, welcome, well, we\'ll, went, were, we\'re, weren\'t, we\'ve, what, whatever, what\'ll, what\'s, what\'ve, when, whence, whenever, where, whereafter, whereas, whereby, wherein, where\'s, whereupon, wherever, whether, which, whichever, while, whilst, whither, who, who\'d, whoever, whole, who\'ll, whom, whomever, who\'s, whose, why, will, willing, wish, with, within, without, wonder, won\'t, would, wouldn\'t, x, y, yes, yet, you, you\'d, you\'ll, your, you\'re, yours, yourself, yourselves, you\'ve, z, zero';
	$AcesefConfig->ilinks_mode = '1';
	$AcesefConfig->ilinks_area = '1';
	$AcesefConfig->ilinks_components = array("0" => "com_content");
	$AcesefConfig->ilinks_enable_cats = '0';
	$AcesefConfig->ilinks_in_cats = '0';
	$AcesefConfig->ilinks_case = '1';
	$AcesefConfig->ilinks_published = '1';
	$AcesefConfig->ilinks_nofollow = '0';
	$AcesefConfig->ilinks_blank = '0';
	$AcesefConfig->ilinks_limit = '10';
	$AcesefConfig->bookmarks_mode = '1';
	$AcesefConfig->bookmarks_area = '1';
	$AcesefConfig->bookmarks_components = array("0" => "com_content");
	$AcesefConfig->bookmarks_enable_cats = '0';
	$AcesefConfig->bookmarks_in_cats = '0';
	$AcesefConfig->bookmarks_twitter = '';
	$AcesefConfig->bookmarks_addthis = '';
	$AcesefConfig->bookmarks_taf = '';
	$AcesefConfig->bookmarks_icons_pos = '2';
	$AcesefConfig->bookmarks_icons_txt = 'Share:';
	$AcesefConfig->bookmarks_icons_line = '35';
	$AcesefConfig->bookmarks_published = '1';
	$AcesefConfig->bookmarks_type = '0';
	$AcesefConfig->ui_cpanel = '2';
	$AcesefConfig->ui_sef_language = '0';
	$AcesefConfig->ui_sef_published = '1';
	$AcesefConfig->ui_sef_used = '1';
	$AcesefConfig->ui_sef_locked = '1';
	$AcesefConfig->ui_sef_blocked = '0';
	$AcesefConfig->ui_sef_cached = '1';
	$AcesefConfig->ui_sef_date = '0';
	$AcesefConfig->ui_sef_hits = '1';
	$AcesefConfig->ui_sef_id = '0';
	$AcesefConfig->ui_moved_published = '1';
	$AcesefConfig->ui_moved_hits = '1';
	$AcesefConfig->ui_moved_clicked = '1';
	$AcesefConfig->ui_moved_cached = '1';
	$AcesefConfig->ui_moved_id = '1';
	$AcesefConfig->ui_metadata_keys = '1';
	$AcesefConfig->ui_metadata_published = '1';
	$AcesefConfig->ui_metadata_cached = '1';
	$AcesefConfig->ui_metadata_id = '0';
	$AcesefConfig->ui_sitemap_title = '1';
	$AcesefConfig->ui_sitemap_published = '1';
	$AcesefConfig->ui_sitemap_id = '1';
	$AcesefConfig->ui_sitemap_parent = '1';
	$AcesefConfig->ui_sitemap_order = '1';
	$AcesefConfig->ui_sitemap_date = '1';
	$AcesefConfig->ui_sitemap_frequency = '1';
	$AcesefConfig->ui_sitemap_priority = '1';
	$AcesefConfig->ui_sitemap_cached = '1';
	$AcesefConfig->ui_tags_published = '1';
	$AcesefConfig->ui_tags_ordering = '1';
	$AcesefConfig->ui_tags_cached = '1';
	$AcesefConfig->ui_tags_hits = '1';
	$AcesefConfig->ui_tags_id = '0';
	$AcesefConfig->ui_ilinks_published = '1';
	$AcesefConfig->ui_ilinks_nofollow = '1';
	$AcesefConfig->ui_ilinks_blank = '1';
	$AcesefConfig->ui_ilinks_limit = '1';
	$AcesefConfig->ui_ilinks_cached = '1';
	$AcesefConfig->ui_ilinks_id = '1';
	$AcesefConfig->ui_bookmarks_published = '1';
	$AcesefConfig->ui_bookmarks_id = '1';
	
	unset($AcesefConfig->seo_il);
	unset($AcesefConfig->seo_il_nofollow);
	unset($AcesefConfig->seo_il_target);
	unset($AcesefConfig->seo_il_limit);
	unset($AcesefConfig->seo_il_words);
	
	// Store the configuration
	jimport('joomla.filesystem.file');
	jimport('joomla.filesystem.folder');
	$config = new JRegistry('config');
	$config->loadObject($AcesefConfig);
	if (!JFile::write(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php', $config->toString('PHP', 'config', array('class' => 'AcesefConfig')))) {
		$msg = JText::_('Error writing AceSEF configuration');
	}
}

function cleanText($text) {
	$text = strip_tags($text);
	$text = preg_replace(array('/&amp;quot;/', '/&amp;nbsp;/', '/&amp;lt;/', '/&amp;gt;/', '/&amp;copy;/', '/&amp;amp;/', '/&amp;euro;/', '/&amp;hellip;/'), ' ', $text);
	$text = preg_replace(array('/&quot;/', '/&nbsp;/', '/&lt;/', '/&gt;/', '/&copy;/', '/&amp;/', '/&euro;/', '/&hellip;/'), ' ', $text);
	$text = preg_replace("'<script[^>]*>.*?</script>'si", ' ', $text);
	$text = preg_replace('/<a\s+.*?href="([^"]+)"[^>]*>([^<]+)<\/a>/is', '\2 (\1)', $text);
	$text = preg_replace('/<!--.+?-->/', ' ', $text);
	$text = preg_replace('/{.+?}/', ' ', $text);
	$text = preg_replace('(\{.*?\})', ' ', $text);
	$text = preg_replace('/\s\s+/', ' ', $text);
	$text = preg_replace('/\n\n+/s', ' ', $text);
	$text = preg_replace('/<[^<|^>]*>/u', ' ', $text);
	$text = preg_replace('/{[^}]*}[\s\S]*{[^}]*}/u', ' ', $text);
	$text = preg_replace('/{[^}]*}/u', ' ', $text);
	$text = trim($text);
	$text = str_replace(array('\r\n', '\r', '\n', '\t', '\n\n', '<', '>', ':', '#', '`', '�', '�', '�', '\0', '\x0B', '"', '&quot;', '&quot'), ' ', $text);
	$text = preg_replace('/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/', ' ', $text);
	while(strpos($text, '  ')) {
		$text = str_replace('  ', ' ', $text);
	}
	
	// Space
	$text = preg_replace('/\s/u', ' ', $text);
	
	// Special chars
	$text = replaceSpecialChars($text);
	
	$text = rtrim($text, "'");
	$text = rtrim($text, "\\");
	
	return $text;
}

// Replace some special chars
function replaceSpecialChars($text, $reverse = false) {
	if (is_string($text)) {
		if (!$reverse) {
			$text = str_replace("\'", "'", $text);
			$text = addslashes($text);
		} else {
			$text = stripslashes($text);
		}
	}
	
	return $text;
}
?>