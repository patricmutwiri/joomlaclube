<?php
/**
* @version		1.5.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU GPL
*/

// Create folders
JFolder::create(JPATH_ROOT.DS.'components'.DS.'com_acesef'.DS.'assets');
JFolder::create(JPATH_ROOT.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images');
JFolder::create(JPATH_ROOT.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks');
JFolder::create(JPATH_ROOT.DS.'components'.DS.'com_acesef'.DS.'controllers');
JFolder::create(JPATH_ROOT.DS.'components'.DS.'com_acesef'.DS.'models');
JFolder::create(JPATH_ROOT.DS.'components'.DS.'com_acesef'.DS.'views');
JFolder::create(JPATH_ROOT.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap');
JFolder::create(JPATH_ROOT.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'tmpl');
JFolder::create(JPATH_ROOT.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags');
JFolder::create(JPATH_ROOT.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags'.DS.'tmpl');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'js');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'library');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'autocompleters');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'elements');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'bookmarks');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'bookmarks'.DS.'tmpl');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'ilinks');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'ilinks'.DS.'tmpl');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'metadata');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'metadata'.DS.'tmpl');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'purgeupdate');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'purgeupdate'.DS.'tmpl');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'restoremigrate');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'restoremigrate'.DS.'tmpl');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurlsdp');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurlsdp'.DS.'tmpl');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags'.DS.'tmpl');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tagsmap');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tagsmap'.DS.'tmpl');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tagsmap'.DS.'tmpl');
JFolder::create(JPATH_ADMINISTRATOR.DS.'modules'.DS.'mod_acesef_quickicons');

// Delete folders
if(JFolder::exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'classes')) {
	JFolder::delete(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'classes');
}
if(JFolder::exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl')) {
	JFolder::delete(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl');
}
if(JFolder::exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurlmoved')) {
	JFolder::delete(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurlmoved');
}
if(JFolder::exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'import')) {
	JFolder::delete(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'import');
}
if(JFolder::exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'metamanager')) {
	JFolder::delete(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'metamanager');
}
if(JFolder::exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'purge')) {
	JFolder::delete(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'purge');
}

// Site
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'acesef.php', 'upgrade', DS.'site'.DS.'acesef.php');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'index.html', 'upgrade', DS.'site'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'toggle.jpg', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'toggle.jpg');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'ask.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'ask.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'blinkbits.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'blinkbits.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'blinklist.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'blinklist.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'blogmarks.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'blogmarks.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'blogmemes.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'blogmemes.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'blogrolling.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'blogrolling.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'cannotea.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'cannotea.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'delicious.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'delicious.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'digg.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'digg.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'diigo.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'diigo.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'disasterrecoverydata.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'disasterrecoverydata.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'dzone.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'dzone.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'entirelyopensource.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'entirelyopensource.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'facebook.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'facebook.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'fark.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'fark.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'faves.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'faves.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'feedmelinks.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'feedmelinks.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'furl.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'furl.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'godsurfer.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'godsurfer.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'google.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'google.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'googlebuzz.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'googlebuzz.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'index.html', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'joomladigger.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'joomladigger.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'joomlavote.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'joomlavote.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'linkagogo.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'linkagogo.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'live.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'live.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'magnolia.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'magnolia.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'maple.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'maple.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'mister-wong.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'mister-wong.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'mixx.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'mixx.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'mylinkvault.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'mylinkvault.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'myspace.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'myspace.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'netscape.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'netscape.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'netvouz.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'netvouz.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'newsvine.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'newsvine.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'plugim.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'plugim.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'rawsugar.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'rawsugar.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'reddit.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'reddit.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'shoutwire.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'shoutwire.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'simpy.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'simpy.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'slashdot.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'slashdot.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'smarking.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'smarking.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'spurl.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'spurl.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'squidoo.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'squidoo.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'stumbleupon.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'stumbleupon.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'swik.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'swik.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'tailrank.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'tailrank.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'technorati.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'technorati.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'wists.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'wists.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'yahoo.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'bookmarks'.DS.'yahoo.png');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'index.html', 'upgrade', DS.'site'.DS.'controllers'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'sitemap.php', 'upgrade', DS.'site'.DS.'controllers'.DS.'sitemap.php');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'tags.php', 'upgrade', DS.'site'.DS.'controllers'.DS.'tags.php');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'models'.DS.'index.html', 'upgrade', DS.'site'.DS.'models'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'models'.DS.'sitemap.php', 'upgrade', DS.'site'.DS.'models'.DS.'sitemap.php');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'models'.DS.'tags.php', 'upgrade', DS.'site'.DS.'models'.DS.'tags.php');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'views'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'sitemap'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'view.html.php', 'upgrade', DS.'site'.DS.'views'.DS.'sitemap'.DS.'view.html.php');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'sitemap'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'site'.DS.'views'.DS.'sitemap'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'tmpl'.DS.'default.xml', 'upgrade', DS.'site'.DS.'views'.DS.'sitemap'.DS.'tmpl'.DS.'default.xml');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'tags'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags'.DS.'view.html.php', 'upgrade', DS.'site'.DS.'views'.DS.'tags'.DS.'view.html.php');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'tags'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'site'.DS.'views'.DS.'tags'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags'.DS.'tmpl'.DS.'default.xml', 'upgrade', DS.'site'.DS.'views'.DS.'tags'.DS.'tmpl'.DS.'default.xml');

// Admin files
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'acesef.xml', 'upgrade', DS.'acesef.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'admin.acesef.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'acesef.php', 'upgrade', DS.'admin'.DS.'acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controller.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'index.html', 'upgrade', DS.'admin'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'install.acesef.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'install.php', 'upgrade', DS.'admin'.DS.'install.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'install.sql', 'upgrade', DS.'admin'.DS.'install.sql');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'toolbar.acesef.php', 'upgrade', DS.'admin'.DS.'toolbar.acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'uninstall.acesef.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'uninstall.php', 'upgrade', DS.'admin'.DS.'uninstall.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'uninstall.sql', 'upgrade', DS.'admin'.DS.'uninstall.sql');

// Adapters
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'adapters'.DS.'acesef_ext.php', 'upgrade', DS.'admin'.DS.'adapters'.DS.'acesef_ext.php');
$this->_addFileOp(DS.'libraries'.DS.'joomla'.DS.'installer'.DS.'adapters'.DS.'acesef_ext.php', 'upgrade', DS.'admin'.DS.'adapters'.DS.'acesef_ext.php');

// Assets
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'index.html', 'upgrade', DS.'admin'.DS.'assets'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'css'.DS.'acesef.css', 'upgrade', DS.'admin'.DS.'assets'.DS.'css'.DS.'acesef.css');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'css'.DS.'index.html', 'upgrade', DS.'admin'.DS.'assets'.DS.'css'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'js'.DS.'index.html', 'upgrade', DS.'admin'.DS.'assets'.DS.'js'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'js'.DS.'jquery.autocomplete.js', 'upgrade', DS.'admin'.DS.'assets'.DS.'js'.DS.'jquery.autocomplete.js');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'js'.DS.'jquery.bgiframe.min.js', 'upgrade', DS.'admin'.DS.'assets'.DS.'js'.DS.'jquery.bgiframe.min.js');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'js'.DS.'jquery-1.4.2.min.js', 'upgrade', DS.'admin'.DS.'assets'.DS.'js'.DS.'jquery-1.4.2.min.js');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'acesef.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'acesef.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-changelog.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-configuration.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-doc.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-extensions.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-import.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-metamanager.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-urlsmoved.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-purge-urls404.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-purge-urlscustom.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-purge-urlslocked.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-purge-urlsmoved.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-purge-urlssef.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-sitemap.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-translators.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-support.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-upgrade.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-urls404.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-urlscustom.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-urlslocked.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-urlssef.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-10-external.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-10-external.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-14-tooltip.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-14-tooltip.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-block-off.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-block-off.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-blank-on.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-blank-on.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-block-off.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-block-off.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-block-on.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-block-on.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-bookmarks.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-bookmarks.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-cache-off.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-cache-off.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-cache-on.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-cache-on.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-changelog.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-configuration.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-config.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-config.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-downarrow-g.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-downarrow-g.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-extensions.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-extensions.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-ilinks.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-ilinks.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-import.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-interface.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-interface.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-lock-off.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-lock-off.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-lock-on.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-lock-on.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-metamanager.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-metadata.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-metadata.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-nofollow-off.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-nofollow-off.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-nofollow-on.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-nofollow-on.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-published-off.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-published-off.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-published-on.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-published-on.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-sitemap.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-sitemap.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-support.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-support.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-tags.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-tags.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-uparrow-g.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-uparrow-g.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-upgrade.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-upgrade.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-urls.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-urls.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-url-moved.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-url-sef.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-used-off.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-used-off.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-used-on.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-used-on.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-used-on2.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-used-on2.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-approve.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-apply1.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-apply1.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-block.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-cancel1.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-cancel1.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-deletefiltered.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-deleteselected.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-editurl.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-edit1.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-edit1.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-exportfiltered.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-exportselected.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-home.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-generatemetadata.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-generatemetadata.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-generatesitemap.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-generatesitemap.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-generatetags.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-generatetags.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-generateurls.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-generateurls.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-generatexml.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-generatexml.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-indexed.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-lock.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-newurl.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-new1.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-new1.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-popup-cache.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-popup-cache.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-popup-help1.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-popup-help1.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-purgeupdate.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-purgeupdate.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-save1.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-save1.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-uninstall.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-32-uninstall.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-use.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-xml.png', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-bookmarks.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-bookmarks.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-changelog.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-changelog.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-config.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-config.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-extensions.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-extensions.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-ilinks.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-ilinks.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-metadata.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-metadata.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-purgeupdate.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-purgeupdate.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-restoremigrate.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-restoremigrate.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-sitemap.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-sitemap.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-support.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-support.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-tags.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-tags.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-translators.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-translators.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-upgrade.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-upgrade.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-urls.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-urls.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-urls404.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-urls404.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-urlscustom.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-urlscustom.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-urlslocked.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-urlslocked.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-urlsmoved.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-urlsmoved.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-urlssef.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-urlssef.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-version-ok.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-version-ok.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-48-version-up.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-version-up.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'index.html', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'indicator.gif', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'indicator.gif');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'loading.gif', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'loading.gif');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'logo.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'logo.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'toolbar.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'toolbar.png');

// Library
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'autocompleters'.DS.'index.html', 'upgrade', DS.'admin'.DS.'library'.DS.'autocompleters'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'autocompleters'.DS.'keywords.php', 'upgrade', DS.'admin'.DS.'library'.DS.'autocompleters'.DS.'keywords.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'autocompleters'.DS.'notfoundurls.php', 'upgrade', DS.'admin'.DS.'library'.DS.'autocompleters'.DS.'notfoundurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'autocompleters'.DS.'sefurls.php', 'upgrade', DS.'admin'.DS.'library'.DS.'autocompleters'.DS.'sefurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'autocompleters'.DS.'tags.php', 'upgrade', DS.'admin'.DS.'library'.DS.'autocompleters'.DS.'tags.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'elements'.DS.'categorylist.php', 'upgrade', DS.'admin'.DS.'library'.DS.'elements'.DS.'categorylist.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'elements'.DS.'componentlist.php', 'upgrade', DS.'admin'.DS.'library'.DS.'elements'.DS.'componentlist.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'elements'.DS.'index.html', 'upgrade', DS.'admin'.DS.'library'.DS.'elements'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'elements'.DS.'routerlist.php', 'upgrade', DS.'admin'.DS.'library'.DS.'elements'.DS.'routerlist.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'elements'.DS.'tags.php', 'upgrade', DS.'admin'.DS.'library'.DS.'elements'.DS.'tags.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'autocompleter.php', 'upgrade', DS.'admin'.DS.'library'.DS.'autocompleter.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'backuprestore.php', 'upgrade', DS.'admin'.DS.'library'.DS.'backuprestore.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'bookmarks.php', 'upgrade', DS.'admin'.DS.'library'.DS.'bookmarks.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'cache.php', 'upgrade', DS.'admin'.DS.'library'.DS.'cache.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'controller.php', 'upgrade', DS.'admin'.DS.'library'.DS.'controller.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'database.php', 'upgrade', DS.'admin'.DS.'library'.DS.'database.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'error.php', 'upgrade', DS.'admin'.DS.'library'.DS.'error.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'extension.php', 'upgrade', DS.'admin'.DS.'library'.DS.'extension.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'factory.php', 'upgrade', DS.'admin'.DS.'library'.DS.'factory.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'ilinks.php', 'upgrade', DS.'admin'.DS.'library'.DS.'ilinks.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'index.html', 'upgrade', DS.'admin'.DS.'library'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'installer.php', 'upgrade', DS.'admin'.DS.'library'.DS.'installer.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'loader.php', 'upgrade', DS.'admin'.DS.'library'.DS.'loader.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'metadata.php', 'upgrade', DS.'admin'.DS.'library'.DS.'metadata.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'model.php', 'upgrade', DS.'admin'.DS.'library'.DS.'model.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'plugin.php', 'upgrade', DS.'admin'.DS.'library'.DS.'plugin.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'router.php', 'upgrade', DS.'admin'.DS.'library'.DS.'router.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'sitemap.php', 'upgrade', DS.'admin'.DS.'library'.DS.'sitemap.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'tags.php', 'upgrade', DS.'admin'.DS.'library'.DS.'tags.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'uri.php', 'upgrade', DS.'admin'.DS.'library'.DS.'uri.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'utility.php', 'upgrade', DS.'admin'.DS.'library'.DS.'utility.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'view.php', 'upgrade', DS.'admin'.DS.'library'.DS.'view.php');

// Controllers
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'acesef.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'bookmarks.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'bookmarks.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'config.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'config.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'editurl.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'editurlmoved.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'extensions.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'ilinks.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'ilinks.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'import.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'metamanager.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'metadata.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'metadata.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'movedurls.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'movedurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'purge.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'purgeupdate.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'purgeupdate.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'restoremigrate.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'restoremigrate.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'sefurls.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'sefurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'sefurlsdp.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'sefurlsdp.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'sitemap.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'sitemap.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'support.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'support.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'tags.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'tags.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'tagsmap.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'tagsmap.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'upgrade.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'upgrade.php');

// Models
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'acesef.php', 'upgrade', DS.'admin'.DS.'models'.DS.'acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'bookmarks.php', 'upgrade', DS.'admin'.DS.'models'.DS.'bookmarks.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'config.php', 'upgrade', DS.'admin'.DS.'models'.DS.'config.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'editurl.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'editurlmoved.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'extensions.php', 'upgrade', DS.'admin'.DS.'models'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'ilinks.php', 'upgrade', DS.'admin'.DS.'models'.DS.'ilinks.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'import.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'metamanager.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'metadata.php', 'upgrade', DS.'admin'.DS.'models'.DS.'metadata.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'movedurls.php', 'upgrade', DS.'admin'.DS.'models'.DS.'movedurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purgeupdate.php', 'upgrade', DS.'admin'.DS.'models'.DS.'purgeupdate.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'restoremigrate.php', 'upgrade', DS.'admin'.DS.'models'.DS.'restoremigrate.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'sefurls.php', 'upgrade', DS.'admin'.DS.'models'.DS.'sefurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'sefurlsdp.php', 'upgrade', DS.'admin'.DS.'models'.DS.'sefurlsdp.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'sitemap.php', 'upgrade', DS.'admin'.DS.'models'.DS.'sitemap.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'tags.php', 'upgrade', DS.'admin'.DS.'models'.DS.'tags.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'tagsmap.php', 'upgrade', DS.'admin'.DS.'models'.DS.'tagsmap.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'upgrade.php', 'upgrade', DS.'admin'.DS.'models'.DS.'upgrade.php');

// Views
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'acesef'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'acesef'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'bookmarks'.DS.'view.edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'bookmarks'.DS.'view.edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'bookmarks'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'bookmarks'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'bookmarks'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'bookmarks'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'bookmarks'.DS.'tmpl'.DS.'default_edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'bookmarks'.DS.'tmpl'.DS.'default_edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'view.html.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'view.edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'config'.DS.'view.edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'default_edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'default_edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'view.edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'extensions'.DS.'view.edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'extensions'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'extension_edit.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default_edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default_edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'ilinks'.DS.'view.edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'ilinks'.DS.'view.edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'ilinks'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'ilinks'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'ilinks'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'ilinks'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'ilinks'.DS.'tmpl'.DS.'default_edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'ilinks'.DS.'tmpl'.DS.'default_edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'metadata'.DS.'view.edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'metadata'.DS.'view.edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'metadata'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'metadata'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'metadata'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'metadata'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'metadata'.DS.'tmpl'.DS.'default_edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'metadata'.DS.'tmpl'.DS.'default_edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'movedurls'.DS.'view.edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'movedurls'.DS.'view.edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'movedurls'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'movedurls'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'movedurls'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'movedurls'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'movedurls'.DS.'tmpl'.DS.'default_edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'movedurls'.DS.'tmpl'.DS.'default_edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'purgeupdate'.DS.'view.cache.php', 'upgrade', DS.'admin'.DS.'views'.DS.'purgeupdate'.DS.'view.cache.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'purgeupdate'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'purgeupdate'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'purgeupdate'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'purgeupdate'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'purgeupdate'.DS.'tmpl'.DS.'default_cache.php', 'upgrade', DS.'admin'.DS.'views'.DS.'purgeupdate'.DS.'tmpl'.DS.'default_cache.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'restoremigrate'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'restoremigrate'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'restoremigrate'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'restoremigrate'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurls'.DS.'view.edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sefurls'.DS.'view.edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurls'.DS.'view.generate.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sefurls'.DS.'view.generate.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurls'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sefurls'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurls'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sefurls'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurls'.DS.'tmpl'.DS.'default_edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sefurls'.DS.'tmpl'.DS.'default_edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurls'.DS.'tmpl'.DS.'default_generate.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sefurls'.DS.'tmpl'.DS.'default_generate.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurls'.DS.'tmpl'.DS.'default_quickedit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sefurls'.DS.'tmpl'.DS.'default_quickedit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurlsdp'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sefurlsdp'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurlsdp'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sefurlsdp'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'view.edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sitemap'.DS.'view.edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sitemap'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sitemap'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'tmpl'.DS.'default_edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'sitemap'.DS.'tmpl'.DS.'default_edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'support'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'support'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'translators.php', 'upgrade', DS.'admin'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'translators.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'support.php', 'upgrade', DS.'admin'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'support.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags'.DS.'view.edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'tags'.DS.'view.edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'tags'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'tags'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags'.DS.'tmpl'.DS.'default_edit.php', 'upgrade', DS.'admin'.DS.'views'.DS.'tags'.DS.'tmpl'.DS.'default_edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tags'.DS.'tmpl'.DS.'default_modal.php', 'upgrade', DS.'admin'.DS.'views'.DS.'tags'.DS.'tmpl'.DS.'default_modal.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tagsmap'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'tagsmap'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'tagsmap'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'tagsmap'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'upgrade'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'upgrade'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'message.php', 'delete');

// Extensions
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_acesef.php', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_acesef.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_acesef.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_banners.php', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_banners.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_banners.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_banners.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_contact.php', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_contact.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_contact.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_contact.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.php', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_content.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_content.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_mailto.php', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_mailto.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_mailto.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_mailto.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_newsfeeds.php', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_newsfeeds.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_newsfeeds.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_newsfeeds.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_poll.php', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_poll.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_poll.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_poll.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_search.php', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_search.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_search.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_search.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_user.php', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_user.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_user.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_user.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_weblinks.php', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_weblinks.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_weblinks.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_weblinks.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_wrapper.php', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_wrapper.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_wrapper.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'com_wrapper.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'default_bookmarks.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'default_bookmarks.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'default_ilinks.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'default_ilinks.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'default_meta.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'default_meta.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'default_sitemap.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'default_sitemap.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'default_tags.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'default_tags.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'default_url.xml', 'upgrade', DS.'admin'.DS.'extensions'.DS.'default_url.xml');

// Language files
$this->_addFileOp(DS.'language'.DS.'en-GB'.DS.'en-GB.com_acesef.ini', 'upgrade', DS.'languages'.DS.'site'.DS.'en-GB'.DS.'en-GB.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.com_acesef.ini', 'upgrade', DS.'languages'.DS.'admin'.DS.'en-GB'.DS.'en-GB.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'admin'.DS.'en-GB'.DS.'en-GB.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.mod_acesef_quickicons.ini', 'upgrade', DS.'modules'.DS.'mod_acesef_quickicons'.DS.'language'.DS.'en-GB.mod_acesef_quickicons.ini');

// Tables
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_extensions.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_urls.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_urls_moved.php', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesefbookmarks.php', 'upgrade', DS.'admin'.DS.'tables'.DS.'acesefbookmarks.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesefextensions.php', 'upgrade', DS.'admin'.DS.'tables'.DS.'acesefextensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesefilinks.php', 'upgrade', DS.'admin'.DS.'tables'.DS.'acesefilinks.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesefmetadata.php', 'upgrade', DS.'admin'.DS.'tables'.DS.'acesefmetadata.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesefmovedurls.php', 'upgrade', DS.'admin'.DS.'tables'.DS.'acesefmovedurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesefsefurls.php', 'upgrade', DS.'admin'.DS.'tables'.DS.'acesefsefurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesefsitemap.php', 'upgrade', DS.'admin'.DS.'tables'.DS.'acesefsitemap.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'aceseftags.php', 'upgrade', DS.'admin'.DS.'tables'.DS.'aceseftags.php');

// Plugins
$this->_addFileOp(DS.'plugins'.DS.'system'.DS.'acesef.php', 'upgrade', DS.'plugins'.DS.'acesef'.DS.'acesef.php');
$this->_addFileOp(DS.'plugins'.DS.'system'.DS.'acesef.xml', 'upgrade', DS.'plugins'.DS.'acesef'.DS.'acesef.xml');
$this->_addFileOp(DS.'plugins'.DS.'system'.DS.'acesefmetacontent.php', 'upgrade', DS.'plugins'.DS.'acesefmetacontent'.DS.'acesefmetacontent.php');
$this->_addFileOp(DS.'plugins'.DS.'system'.DS.'acesefmetacontent.xml', 'upgrade', DS.'plugins'.DS.'acesefmetacontent'.DS.'acesefmetacontent.xml');
$this->_addFileOp(DS.'plugins'.DS.'system'.DS.'acesefmetacontent_tmpl.php', 'upgrade', DS.'plugins'.DS.'acesefmetacontent'.DS.'acesefmetacontent_tmpl.php');

// Modules
$this->_addFileOp(DS.'administrator'.DS.'modules'.DS.'mod_acesef_quickicons'.DS.'index.html', 'upgrade', DS.'modules'.DS.'mod_acesef_quickicons'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'modules'.DS.'mod_acesef_quickicons'.DS.'mod_acesef_quickicons.php', 'upgrade', DS.'modules'.DS.'mod_acesef_quickicons'.DS.'mod_acesef_quickicons.php');
$this->_addFileOp(DS.'administrator'.DS.'modules'.DS.'mod_acesef_quickicons'.DS.'mod_acesef_quickicons.xml', 'upgrade', DS.'modules'.DS.'mod_acesef_quickicons'.DS.'mod_acesef_quickicons.xml');

// Languages
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'da-DK'.DS.'da-DK.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'de-DE'.DS.'de-DE.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'el-GR'.DS.'el-GR.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'es-ES'.DS.'es-ES.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'fr-FR'.DS.'fr-FR.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'hr-HR'.DS.'hr-HR.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'hu-HU'.DS.'hu-HU.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'it-IT'.DS.'it-IT.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'nb-NO'.DS.'nb-NO.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'nl-NL'.DS.'nl-NL.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pl-PL'.DS.'pl-PL.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-BR'.DS.'pt-BR.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-PT'.DS.'pt-PT.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'ru-RU'.DS.'ru-RU.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sl-SI'.DS.'sl-SI.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sr-RS'.DS.'sr-RS.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sv-SE'.DS.'sv-SE.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-CN'.DS.'zh-CN.com_acesef.ini', 'delete');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-TW'.DS.'zh-TW.com_acesef.ini', 'delete');

// SQL definitions
$db =& JFactory::getDBO();
$db->setQuery("SELECT `id` FROM `#__components` WHERE `admin_menu_link` = 'option=com_acesef' LIMIT 1");
$menuid = $db->loadResult();
if ($menuid) {
	$this->_addSQL("DELETE FROM #__components WHERE parent = {$menuid}");
    $this->_addSQL("INSERT INTO `#__components`(`name`, `link`, `parent`, `admin_menu_link`, `admin_menu_alt`, `option`, `ordering`, `admin_menu_img`, `params`, `enabled`) VALUES ".
                   " ('Control Panel',       '', '{$menuid}', 'option=com_acesef',                                				'Control Panel',       '',     '0', 	'components/com_acesef/assets/images/acesef.png',					'', '1')".
                   ",('Configuration',       '', '{$menuid}', 'option=com_acesef&controller=config&task=edit',    				'Configuration',       '',     '1', 	'components/com_acesef/assets/images/icon-16-config.png',			'', '1')".
                   ",('Extensions',          '', '{$menuid}', 'option=com_acesef&controller=extensions&task=view',       		'Extensions',          '',     '2', 	'components/com_acesef/assets/images/icon-16-extensions.png',		'', '1')".
                   ",('URLs',            	 '', '{$menuid}', 'option=com_acesef&controller=sefurls&task=view',  				'URLs',            	   '',     '3', 	'components/com_acesef/assets/images/icon-16-urls.png',				'', '1')".
                   ",('Metadata',        	 '', '{$menuid}', 'option=com_acesef&controller=metadata&task=view',  				'Metadata',        	   '',     '4', 	'components/com_acesef/assets/images/icon-16-metadata.png',			'', '1')".
                   ",('Sitemap',       		 '', '{$menuid}', 'option=com_acesef&controller=sitemap&task=view',  				'Sitemap',       	   '',     '5', 	'components/com_acesef/assets/images/icon-16-sitemap.png',			'', '1')".
                   ",('Tags',          		 '', '{$menuid}', 'option=com_acesef&controller=tags&task=view',     				'Tags',          	   '',     '6', 	'components/com_acesef/assets/images/icon-16-tags.png',				'', '1')".
                   ",('Internal Links',      '', '{$menuid}', 'option=com_acesef&controller=ilinks&task=view',    				'Internal Links',      '',     '7', 	'components/com_acesef/assets/images/icon-16-ilinks.png',			'', '1')".
                   ",('S. Bookmarks',    	 '', '{$menuid}', 'option=com_acesef&controller=bookmarks&task=view',    			'S. Bookmarks',        '',     '8', 	'components/com_acesef/assets/images/icon-16-bookmarks.png',		'', '1')".
                   ",('Upgrade',             '', '{$menuid}', 'option=com_acesef&controller=upgrade&task=view',  				'Upgrade',             '',     '9', 	'components/com_acesef/assets/images/icon-16-upgrade.png',			'', '1')".
                   ",('Support',             '', '{$menuid}', 'option=com_acesef&controller=support&task=support',       		'Support',             '',     '10',	'components/com_acesef/assets/images/icon-16-support.png',			'', '1')"
    );
}

$this->_addSQL("INSERT INTO `#__plugins` (`name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES ('System - AceSEF Metadata (Content)', 'acesefmetacontent', 'system', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', '')");

$db =& JFactory::getDBO();
$db->setQuery("SELECT `id` FROM `#__modules` WHERE `module` = 'mod_acesef_quickicons' LIMIT 1");
$moduleid = $db->loadResult();
if (!$moduleid) {
	$this->_addSQL("INSERT INTO `#__modules` (`title`, `position`, `published`, `module`, `access`, `showtitle`, `params`, `iscore`, `client_id`) VALUES ('AceSEF - Quick Icons', 'icon', 1, 'mod_acesef_quickicons', 2, 0, '', 0, '1')");
}

// Add upgrade script
$this->_addScript(DS.'upgrade'.DS.'1.3.13.script.php');

?>