<?php
/*
* @package		AceSEF
* @subpackage	Content
* @copyright	2009-2010 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die ('Restricted access');

class AceSEF_com_content extends AcesefExtension {
	
	function beforeBuild(&$uri) {
		AcesefURI::fixUriVar($uri, 'id');
        AcesefURI::fixUriVar($uri, 'catid');
		
		// Change task=view to view=article for old urls
        if (!is_null($uri->getVar('task')) && ($uri->getVar('task') == 'view')) {
            $uri->delVar('task');
            $uri->setVar('view', 'article');
        }
		
		if (is_null($uri->getVar('limitstart')) && !is_null($uri->getVar('start'))) {
            $uri->setVar('limitstart', $uri->getVar('start'));
			$uri->delVar('start');
        }
        
		// Remove the limitstart and limit variables if they point to the first page
		if (is_null($uri->getVar('limitstart')) || $uri->getVar('limitstart') == '0') {
            $uri->delVar('limitstart');
            $uri->delVar('limit');
        }
        
		if (!is_null($uri->getVar('view')) && ($uri->getVar('view') == 'article') && (is_null($uri->getVar('catid')) || $uri->getVar('catid') == 0) && !is_null($uri->getVar('id'))) {
			$catid = self::_getItemCatId(intval($uri->getVar('id')));
			
			if (!empty($catid)) {
				$uri->setVar('catid', $catid);
			}
		}
		
		// Add the view variable if it's not set
		if (is_null($uri->getVar('view'))) {
            if (is_null($uri->getVar('id'))) {
                $uri->setVar('view', 'frontpage');
            } else {
                $uri->setVar('view', 'article');
			}
        }
        
		// Fix for AlphaContent
		if (!is_null($uri->getVar('directory'))) {
            $uri->delVar('directory');
		}
		
		$route_helper = JPATH_ROOT.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php';
		if (($this->params->get('smart_itemid', '1') == '2') && file_exists($route_helper) && !is_null($uri->getVar('view'))) {
			require_once($route_helper);
			
			if (!class_exists('ContentHelperRoute')) {
				return;
			}
			
			if (!method_exists('ContentHelperRoute', '_findItem')) {
				return;
			}
			
			if ($uri->getVar('view') == 'section' && !is_null($uri->getVar('id'))) {
				$id = $uri->getVar('id');
				$needles = array('section' => (int) $id);
		
				$item = ContentHelperRoute::_findItem($needles);
				if (!empty($item)) {
					$uri->setVar('Itemid', $item->id);
				}
			}
			
			if ($uri->getVar('view') == 'category' && !is_null($uri->getVar('id'))) {
				$id = $uri->getVar('id');
				$needles = array('category' => (int) $id);
		
				$item = ContentHelperRoute::_findItem($needles);
				if (!empty($item)) {
					$uri->setVar('Itemid', $item->id);
				}
			}
			
			if ($uri->getVar('view') == 'article' && !is_null($uri->getVar('id'))) {
				$id = $uri->getVar('id');
				
				$catid = 0;
				if (!is_null($uri->getVar('catid'))) {
					$catid = $uri->getVar('catid');
				}
				
				$needles = array('article' => (int) $id, 'category' => (int) $catid, 'section' => 0);
		
				$item = ContentHelperRoute::_findItem($needles);
				if (!empty($item)) {
					$uri->setVar('Itemid', $item->id);
				}
			}
		}
    }
	
	function _getItemCatId($id) {
		static $cache = array();
		
		if (!isset($cache[$id])) {
			if ($this->AcesefConfig->cache_instant == 1) {
				$rows = AceDatabase::loadRowList("SELECT id, catid FROM #__content");
				foreach ($rows as $row) {
					$cache[$row[0]] = $row[1];
				}
			} else {
				$cache[$id] = AceDatabase::loadResult("SELECT catid FROM #__content WHERE id = {$id}");
			}
		}
		
		if (!isset($cache[$id])) {
			$cache[$id] = "";
		}
		
		return $cache[$id];
    }
	
	function catParam($vars, $real_url) {
        extract($vars);
		
		if (isset($view)) {
            switch($view) {
                case 'category':
					if (!empty($id)) {
						parent::categoryParams($id, 1, $real_url);
					}
                    break;
				case 'article':
					if (!empty($catid)) {
						parent::categoryParams($catid, 0, $real_url);
					}
                    break;
            }
        }
	}
	
	function build(&$vars, &$segments, &$do_sef, &$metadata, &$item_limitstart) {
        extract($vars);
		
		$cat_suffix 	= $this->params->get('cat_suffix', '1');
		$default_index	= $this->params->get('default_index', '');
		$layout_prefix	= $this->params->get('layout_prefix', '2');
		$list_prefix	= $this->params->get('list_prefix', '');
		$blog_prefix	= $this->params->get('blog_prefix', '');
	
		if (isset($view)) {
            switch($view) {
				case 'archive':
					$segments[] = JText::_('ARCHIVES');
					if (!empty($year)) {
						$segments[] = $year;
						unset($vars['year']);
					}
					
					if (!empty($month)) {
						$segments[] = $month;
						unset($vars['month']);
					}
					break;
				case 'section':
					if (!empty($layout)) {
						if (!empty($layout) && $layout == 'blog' && !empty($blog_prefix)) {
							$segments[] = $blog_prefix;
						}
						if (!empty($layout) && $layout == 'default' && !empty($list_prefix)) {
							$segments[] = $list_prefix;
						}
                    }
					unset($vars['layout']);
					
                    if (!empty($id)) {
						$add_sec = ($this->params->get('section_inc', '2') == '2' || ($this->params->get('section_inc', '2') == '1') && $this->params->get('skip_menu', '1') == '1');
						if ($add_sec) {
							$segments[] = self::_getSection(intval($id));
						}
						unset($vars['id']);
					}
					
					if ($cat_suffix == '1' && $default_index == '') {
						$segments[] = "/";
					}
					
					if ($default_index != '') {
						$segments[] = $default_index;
					}
                    break;
                case 'category':
					if (!empty($layout) && $layout_prefix != '1') {
						if ($layout == 'blog' && !empty($blog_prefix)) {
							$segments[] = $blog_prefix;
						}
						if ($layout == 'default' && !empty($list_prefix)) {
							$segments[] = $list_prefix;
						}
                    }
					unset($vars['layout']);
					
					if (!empty($id)) {
						$add_cat = ($this->params->get('category_inc', '2') == '2' || ($this->params->get('category_inc', '2') == '1') && $this->params->get('skip_menu', '1') == '1');
						if ($add_cat) {
							$segments = array_merge($segments, self::_getCategory(intval($id)));
						}
						unset($vars['id']);
					}
					
					if ($cat_suffix == '1' && $default_index == '') {
						$segments[] = "/";
					}
					
					if ($default_index != '') {
						$segments[] = $default_index;
					}
                    break;
				case 'article':
					if (!empty($catid)) {
						if ($this->params->get('category_inc', '2') == '2') {
							$segments = array_merge($segments, self::_getCategory(intval($catid)));
						}
						unset($vars['catid']);
					}
					
					if (!empty($id)) {
						$segments[] = self::_getArticle(intval($id));
						unset($vars['catid']);
						unset($vars['id']);
					}
					
					// Google News
					if (!empty($id) && $this->params->get('google_news', '1') != '1' && !empty($catid)) {
						$categories = $this->params->get('google_news_cats', 'all');
						
						$apply_gn = false;
						if ($categories == 'all') {
							$apply_gn = true;
						}
						elseif (is_array($categories) && in_array($catid, $categories)) {
							$apply_gn = true;
						}
						elseif ($categories == $catid) {
							$apply_gn = true;
						}
						
						if ($apply_gn) {
							$i = count($segments) - 1;
							$segments[$i] = self::_googleNews($segments[$i], intval($id));
						}
					}
					
					if (!empty($limitstart)) {
						$item_limitstart = true;
					}
					
					if (isset($task)) {
						$segments[] = $task;
						unset($vars['task']);
					}
					
					if (isset($print)) {
						$segments[] = JText::_('PRINT');
						unset($vars['print']);
					}
					
					if (isset($showall) && $showall == 1) {
						$segments[] = JText::_('ALL');
						unset($vars['showall']);
					}
					
					if (isset($layout) && $layout == 'form') {
						$segments[] = JText::_('NEW ITEM');
						unset($vars['layout']);
					}
                    break;
				case 'frontpage':
					break;
				default:
					$segments[] = $view;
					break;
            }
			unset($vars['view']);
        }
		
		if (!empty($format)) {
			$segments[] = $format;
			unset($vars['format']);
		}
		
		if (!empty($type)) {
			$segments[] = $type;
			unset($vars['type']);
		}
		
		$metadata = parent::getMetaData($vars, $item_limitstart);
		
		unset($vars['limit']);
		unset($vars['limitstart']);
	}
	
	function _getSection($id) {
		static $cache = array();
		
		if (!isset($cache[$id])) {
			$joomfish = $this->AcesefConfig->joomfish_trans_url ? ', id' : '';
			$row = AceDatabase::loadRow("SELECT title, alias, description{$joomfish} FROM #__sections WHERE id = {$id}");
			
			$name = (($this->params->get('sectionid_inc', '1') != '1') ? $id.' ' : '');
			if (parent::urlPart($this->params->get('section_part', 'global')) == 'title') {
				$name .= $row[0];
			} else {
				$name .= $row[1];
			}
			
			$cache[$id]['name'] = $name;
			$cache[$id]['meta_title'] = $row[0];
			$cache[$id]['meta_desc'] = $row[2];
		}
		
		$this->meta_title[] = $cache[$id]['meta_title'];
		$this->meta_desc = $cache[$id]['meta_desc'];
		
		return $cache[$id]['name'];
    }
	
	function _getCategory($id) {
		static $cache = array();
		
		if (!isset($cache[$id])) {
			$joomfish = $this->AcesefConfig->joomfish_trans_url ? ', id' : '';
			$row = AceDatabase::loadRow("SELECT title, alias, section, description{$joomfish} FROM #__categories WHERE id = {$id}");
			
			$name = (($this->params->get('categoryid_inc', '1') != '1') ? $id.' ' : '');
			if (parent::urlPart($this->params->get('category_part', 'global')) == 'title') {
				$name .= $row[0];
			} else {
				$name .= $row[1];
			}
			
			$cache[$id]['name'] = $name;
			$cache[$id]['section'] = $row[2];
			$cache[$id]['meta_title'] = $row[0];
			$cache[$id]['meta_desc'] = $row[3];
		}
		
		$this->meta_title[] = $cache[$id]['meta_title'];
		$this->meta_desc = $cache[$id]['meta_desc'];
		
		if ($this->params->get('section_inc', '1') != '2') {
			return array($cache[$id]['name']);
		} else {
			return array(self::_getSection(intval($cache[$id]['section'])), $cache[$id]['name']);
		}
    }

    function _getArticle($id) {
		static $cache = array();
		
		if (!isset($cache[$id])) {
			$joomfish = $this->AcesefConfig->joomfish_trans_url ? ', id' : '';
			$row = AceDatabase::loadRow("SELECT title, alias, catid, introtext, metadesc{$joomfish} FROM #__content WHERE id = {$id}");
			
			if (!empty($row) && is_array($row)) {
				$name = (($this->params->get('articleid_inc', '1') != '1') ? $id.' ' : '');
				if (parent::urlPart($this->params->get('article_part', 'global')) == 'title') {
					$name .= $row[0];
				} else {
					$name .= $row[1];
				}
				
				$cache[$id]['name'] = $name;
				$cache[$id]['meta_title'] = $row[0];
				
				if ($this->params->get('item_desc', '1') == '1') {
					$cache[$id]['meta_desc'] = $row[3];
				} else {
					$cache[$id]['meta_desc'] = $row[4];
				}
			} else {
				$cache[$id]['name'] = $cache[$id]['meta_title'] = $cache[$id]['meta_desc'] = "";
			}
		}
		
		array_unshift($this->meta_title, $cache[$id]['meta_title']);
		$this->meta_desc = $cache[$id]['meta_desc'];
		
		return $cache[$id]['name'];
    }
	
	// Google New numbering
	function _googleNews($title, $id) {
        $num = '';
        $add = $this->params->get('google_news', '1');

		// ID
		$digits = trim($this->params->get('google_news_digits', '3'));
		if (!is_numeric($digits)) {
			$digits = '3';
		}
		$articleid = sprintf('%0'.$digits.'d', $id);
        
		// Date
		if ($add == '3' || $add == '4') {
			$time = AceDatabase::loadResult("SELECT publish_up FROM #__content WHERE id = {$id}");

			$time = strtotime($time);

			$date = $this->params->get('google_news_dateformat', 'ddmm');

			$search = array('dd', 'd', 'mm', 'm', 'yyyy', 'yy');
			$replace = array(date('d', $time), date('j', $time), date('m', $time), date('n', $time), date('Y', $time), date('y', $time));
			$articledate = str_replace($search, $replace, $date);
		}
		
		if ($add == '2') {
			$num = $articleid;
		} elseif ($add == '3') {
			$num = $articledate;
		} elseif ($add == '4') {
			$num = $articledate.$articleid;
		}

        if (!empty($num)) {
            $sep = $this->AcesefConfig->replacement_character;
            $where = $this->params->get('google_news_pos', '2');

            if ($where == '2') {
                $title = $title.$sep.$num;
            } else {
                $title = $num.$sep.$title;
            }
        }

        return $title;
    }

	function getCategoryList($query) {
		$rows = AceDatabase::loadObjectList("SELECT c.id, CONCAT_WS( ' / ', s.title, c.title) AS name FROM #__categories AS c, #__sections AS s WHERE s.scope = 'content' AND c.section = s.id ORDER BY s.title, c.title");
		return $rows;
	}
}
?>