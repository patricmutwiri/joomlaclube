<?php
/**
* @version		1.5.0
* @package		AceSEF Library
* @subpackage	Factory
* @copyright	2009-2010 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Factory class
class AcesefFactory {
	
	function &getConfig() {
		static $instance;
		
		if (!is_object($instance)) {
			require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
			$instance = new AcesefConfig();
		}
		
		return $instance;
	}
	
	function &getCache($lifetime = '315360000') {
		static $instances = array();
		
		if (!isset($instances[$lifetime])) {
			require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'library'.DS.'cache.php');
			$instances[$lifetime] = new AcesefCache($lifetime);
		}
		
		return $instances[$lifetime];
	}
	
	function getTable($name) {
		static $tables = array();
		
		if (!isset($tables[$name])) {
			JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'tables');
			$tables[$name] =& JTable::getInstance($name, 'Table');
		}
		
		return $tables[$name];
	}
}
?>