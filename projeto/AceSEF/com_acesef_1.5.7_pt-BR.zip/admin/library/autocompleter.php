<?php
/**
* @version		1.5.0
* @package		AceSEF Library
* @subpackage	Autocompleter
* @copyright	2009-2010 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// Autocompleter class
class AcesefAutocompleter {
	
	function getJoomlaConfig() {
		static $config;
		
		if (!isset($config)) {
			$root = dirname(dirname(dirname(dirname(dirname(__FILE__)))));
			require_once($root.'/configuration.php');
			$config = new JConfig();
		}
		
		return $config;
	}

	function loadResultArray($select, $table, $where, $index = 0) {
		$JoomlaConfig = self::getJoomlaConfig();
		$db_type = $JoomlaConfig->dbtype;
		
		$query = $select." ".$JoomlaConfig->dbprefix.$table." ".$where;
		
		if (!($results = self::_getResults($JoomlaConfig, $db_type, $query))) {
			return null;
		}

		$rows = array();
		$db_fetch = $db_type.'_fetch_row';
		while ($row = $db_fetch($results)) {
			$rows[] = $row[$index];
		}
		
		$db_free_result = $db_type.'_free_result';
		$db_free_result($results);
		
		return $rows;
	}
	
	function _getResults($JoomlaConfig, $db_type, $query) {
		$db_connect = $db_type.'_connect';
		$db_select = $db_type.'_select_db';
		$db_query = $db_type.'_query';
		
		$connection = $db_connect($JoomlaConfig->host, $JoomlaConfig->user, $JoomlaConfig->password) or die("Could not connect: " . mysql_error());
		
		if ($db_type == 'mysql') {
			$db_select($JoomlaConfig->db, $connection);
			$results = $db_query($query, $connection);
		} elseif ($db_type == 'mysqli') {
			$db_select($connection, $JoomlaConfig->db);
			$results = $db_query($connection, $query);
		}
		
		if (!$results) {
			return false;
		}
		
		return $results;
	}
}
?>