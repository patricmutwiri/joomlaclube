<?php
/**
* @version		1.5.0
* @package		AceSEF Library
* @subpackage	Bookmarks
* @copyright	2009-2010 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Social Bookmarks class
class AcesefBookmarks {
}