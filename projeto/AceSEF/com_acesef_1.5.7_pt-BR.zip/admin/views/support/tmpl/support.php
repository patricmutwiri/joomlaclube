<?php
/**
* @version		1.5.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009-2010 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die('Restricted access');
?>
<br />

<table align="center" width="600" border="1">
	<tr>
		<td width="170" style="padding-left: 5px;">
			<h2>Free Services</h2>
		</td>
		<td width="170" style="padding-left: 5px;">
			<h2>Paid Services</h2>
		</td>
		<td width="170" style="padding-left: 5px;">
			<h2>VIP Services</h2>
		</td>
	</tr>
	<tr>
		<td height="30" style="padding-left: 5px;">
			<a href="http://www.joomace.net/support/docs/acesef" target="_blank">
				Documentation
			</a>
		</td>
		<td height="30" style="padding-left: 5px;">
			<a href="http://www.joomace.net/e-shop/joomla-services/new-extension" target="_blank">
				New Extension Request
			</a>
		</td>
		<td height="30" style="padding-left: 5px;">
			<a href="http://www.joomace.net/support/tickets" target="_blank">
				Tickets System
			</a>
		</td>
	</tr>
	<tr>
		<td height="30" style="padding-left: 5px;">
			<a href="http://www.joomace.net/support/forums" target="_blank">
				Support Forums
			</a>
		</td>
		<td height="30" style="padding-left: 5px;">
			<a href="http://www.joomace.net/e-shop/joomla-services/acesef-installation-on-apache" target="_blank">
				AceSEF Installation
			</a>
		</td>
		<td height="30" style="padding-left: 5px;">
			<a href="http://www.joomace.net/support/docs/acesef/video-tutorials" target="_blank">
				Video Tutorials
			</a>
		</td>
	</tr>
	<tr>
		<td height="30" style="padding-left: 5px;">
			<a href="http://www.joomace.net/support/docs/general/pre-sales-faq" target="_blank">
				Pre-Sale Questions
			</a>
		</td>
		<td height="30" style="padding-left: 5px;">
			<a href="http://www.joomace.net/e-shop/joomla-services/extension-support" target="_blank">
				Extension Support
			</a>
		</td>
		<td height="30" style="padding-left: 5px;">
			&nbsp;
		</td>
	</tr>
	<tr>
		<td align="center" colspan="3">
			<br />
			<a href="http://www.joomace.net/free-downloads/components/acesef" target="_blank">
				<img border="0" src="http://www.joomace.net/acesef_basic.png" width="129" height="174">
			</a>
			&nbsp;
			<a href="http://www.joomace.net/e-shop/acesef/acesef-plus" target="_blank">
				<img border="0" src="http://www.joomace.net/acesef_plus.png" width="129" height="174">
			</a>
			&nbsp;
			<a href="http://www.joomace.net/e-shop/acesef/acesef-pro" target="_blank">
				<img border="0" src="http://www.joomace.net/acesef_pro.png" width="129" height="174">
			</a>
			&nbsp;
			<a href="http://www.joomace.net/e-shop/acesef/acesef-vip" target="_blank">
				<img border="0" src="http://www.joomace.net/acesef_vip.png" width="129" height="174">
			</a>
			<br />
		</td>
	</tr>
</table>