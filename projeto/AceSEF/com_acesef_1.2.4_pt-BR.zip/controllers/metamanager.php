<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Meta Manager Controller Class
class AcesefControllerMetamanager extends AcesefController {
	
	// Main constructer
	function __construct() 	{
		parent::__construct();
	}

	// Display URLs
	function view() {
		$model =& $this->getModel('metamanager');
		$view = $this->getView('metamanager','html');
		$view->setModel($model, true);
		$view->view();
	}
	
	// Save changes
	function save() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('metamanager');
		foreach ($cid as $id) {
			$model->save($id);
		}
		// Return to Control Panel
		$this->setRedirect('index.php?option=com_acesef', JTEXT::_('ACESEF_META_MANAGER_SAVED'));
	}
	
	// Apply changes
	function apply() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('metamanager');
		foreach ($cid as $id) {
			$model->save($id);
		}
		// Return to Meta Manager
		$this->setRedirect('index.php?option=com_acesef&controller=metamanager&task=view', JTEXT::_('ACESEF_META_MANAGER_SAVED'));
	}
}
?>