<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Repository Controller Class
class AcesefControllerRepository extends AcesefController {
	
	// Main constructer
	function __construct() 	{
		parent::__construct();
		$this->registerTask('add', 'edit');
		$this->registerTask('unlock', 'lock');
		$this->registerTask('unblock', 'block');
		$this->registerTask('unpublish', 'publish');
		$this->registerTask('unused', 'used');
	}

	// Display URLs
	function view() {
		$model =& $this->getModel('repository');
		$view = $this->getView('repository','html');
		$view->setModel($model, true);
		$view->view();
	}
	
	// Edit URL
	function edit() {
		$this->addModelPath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models');
		$model = $this->getModel('editurl', 'AcesefModel');

		$this->addViewPath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl');
		$view = $this->getView('editurl', 'html', 'AcesefView');
		$view->setModel($model, true);
		
        JRequest::setVar( 'hidemainmenu', 1 );
		$view->edit();
	}
	
	// Delete URLs
	function delete() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');

		$model = $this->getModel('repository');
		foreach ($cid as $id) {
			$model->delete($id);
		}
		// Go to Repository
		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view');
	}
	
	// Publish URLs
	function publish() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('repository');
		foreach ($cid as $id) {
			$model->publish($id);
		}
		// Go to Repository
		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view');
	}
	
	// Use URL
	function used() {
		// active the selected URL as the primary SEF link
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');

		if (count($cid) == 0) {
			// Go to Repository
			$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view');
			return;
		}

		//$id = $cid[0];
		$model = $this->getModel('repository');
		foreach ($cid as $id) {
			$model->used($id);
		}
		// Go to Repository
		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view');
	}
	
	// Lock URLs from deleting
	function lock() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('repository');
		foreach ($cid as $id) {
			$model->lock($id);
		}
		// Go to Repository
		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view');
	}
	
	// Block URL from rewriting
	function block() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('repository');
		foreach ($cid as $id) {
			$model->block($id);
		}
		// Go to Repository
		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view');
	}
	
	// Delete filtered URLs
	function deleteFiltered() {
        $model = $this->getModel('repository');
        
		if(!$model->deleteFiltered()) {
			$msg = JText::_('ACESEF_URL_REPOS_CONFIRM_DELETE_FILTERED');
		} else {
			$msg = JText::_('ACESEF_URL_REPOS_MESSAGE_DELETE_FILTERED_SUCCESS');
		}

		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view', $msg);
    }
    
	// Export Selected URLs
    function exportsel() {
        $model =& $this->getModel('repository');
        $where = $model->WhereIds();
        
		if(!$model->export($where))
			$msg = JText::_('ACESEF_URL_REPOS_MESSAGE_URLS_NOT_EXPORTED');
		else
			$msg = JText::_('ACESEF_URL_REPOS_MESSAGE_URLS_EXPORTED');
		// Go to Repository
		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view', $msg);
    }
    
	// Export All URLs
    function exportall() {
        $model =& $this->getModel('repository');
        $where = $model->_buildViewWhere();
        
		if(!$model->export($where))
			$msg = JText::_('ACESEF_URL_REPOS_MESSAGE_URLS_NOT_EXPORTED');
		else
			$msg = JText::_('ACESEF_URL_REPOS_MESSAGE_URLS_EXPORTED');
		// Go to Repository
		$this->setRedirect( 'index.php?option=com_acesef&controller=repository&task=view', $msg );
    }
}
?>