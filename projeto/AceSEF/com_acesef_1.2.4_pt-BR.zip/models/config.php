<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport('joomla.application.component.model');

// Configuration Model Class
class AcesefModelConfig extends Jmodel {
	var $_configuration = null;
	
	// Main constructer
	function __construct(){
		parent::__construct();
	}

	function _set_configuration () {
		require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
		$this->_configuration = new acesef_configuration();
	}

	// Save configuration
	function _save_configuration() {
		$config = new JRegistry('config');
		$config_array = array();
		// Main
		$config_array['mode']							= JRequest::getVar('mode', 							0, 			'post', 'int');
		$config_array['url_lowercase']					= JRequest::getVar('url_lowercase', 				0, 			'post', 'int');
		$config_array['numeral_duplicated']				= JRequest::getVar('numeral_duplicated', 			0, 			'post', 'int');
		$config_array['record_duplicated']				= JRequest::getVar('record_duplicated', 			1, 			'post', 'int');
		$config_array['url_suffix']						= JRequest::getVar('url_suffix', 					'', 		'post', 'string');
		$config_array['replacement_character']			= JRequest::getVar('replacement_character',			'', 		'post', 'string');
		$config_array['menu_url_part']					= JRequest::getVar('menu_url_part',					'title', 	'post', 'string');
		$config_array['title_alias']					= JRequest::getVar('title_alias', 					'title', 	'post', 'string');
		// JoomFish
		$config_array['joomfish_main_lang']				= JRequest::getVar('joomfish_main_lang', 			0, 			'post', 'string');
		$config_array['joomfish_lang_code']				= JRequest::getVar('joomfish_lang_code', 			0, 			'post', 'int');
		$config_array['joomfish_trans_url']				= JRequest::getVar('joomfish_trans_url', 			0, 			'post', 'int');
		// Advanced
		$config_array['append_itemid']					= JRequest::getVar('append_itemid', 				0, 			'post', 'int');
		$config_array['remove_trailing_slash']			= JRequest::getVar('remove_trailing_slash', 		1, 			'post', 'int');
		$config_array['tolerant_to_trailing_slash']		= JRequest::getVar('tolerant_to_trailing_slash', 	1, 			'post', 'int');
		$config_array['redirect_to_www']				= JRequest::getVar('redirect_to_www', 				0, 			'post', 'int');
		$config_array['url_strip_chars']				= JRequest::getVar('url_strip_chars',				'', 		'post', 'string');
		$config_array['utf8_url']						= JRequest::getVar('utf8_url', 						0, 			'post', 'int');
		$config_array['char_replacements']				= JRequest::getVar('char_replacements',				'', 		'post', 'string');
		// Very Advanced
		$config_array['insert_active_itemid']			= JRequest::getVar('insert_active_itemid', 			0, 			'post', 'int');
		$config_array['redirect_to_sef']				= JRequest::getVar('redirect_to_sef', 				1, 			'post', 'int');
		$config_array['remove_sid']						= JRequest::getVar('remove_sid', 					1, 			'post', 'int');
		$config_array['set_query_string']				= JRequest::getVar('set_query_string', 				0, 			'post', 'int');
		$config_array['base_href']						= JRequest::getVar('base_href', 					3, 			'post', 'int');
		$config_array['force_ssl']						= JRequest::getVar('force_ssl', 					0, 			'post', 'int');
		$config_array['append_non_sef']					= JRequest::getVar('append_non_sef', 				1, 			'post', 'int');
		$config_array['non_sef_vars']					= JRequest::getVar('non_sef_vars', 					'', 		'post', 'string');
		$config_array['disable_sef_vars']				= JRequest::getVar('disable_sef_vars', 				'', 		'post', 'string');
		$config_array['log_404_errors']					= JRequest::getVar('log_404_errors', 				0, 			'post', 'int');
		$config_array['log_404_path']					= JRequest::getVar('log_404_path', 					'', 		'post', 'string');
		// Meta Tags
		$config_array['meta_autotitle']					= JRequest::getVar('meta_autotitle', 				1, 			'post', 'int');
		$config_array['meta_autodesc']					= JRequest::getVar('meta_autodesc', 				1, 			'post', 'int');
		$config_array['meta_autokey']					= JRequest::getVar('meta_autokey', 					1, 			'post', 'int');
		$config_array['meta_generator']					= JRequest::getVar('meta_generator', 				'', 		'post', 'string');
		$config_array['meta_abstract']					= JRequest::getVar('meta_abstract', 				'', 		'post', 'string');
		$config_array['meta_revisit']					= JRequest::getVar('meta_revisit', 					'', 		'post', 'string');
		$config_array['meta_direction']					= JRequest::getVar('meta_direction', 				'', 		'post', 'string');
		$config_array['meta_googlekey']					= JRequest::getVar('meta_googlekey', 				'', 		'post', 'string');
		$config_array['meta_livekey']					= JRequest::getVar('meta_livekey', 					'', 		'post', 'string');
		$config_array['meta_yahookey']					= JRequest::getVar('meta_yahookey', 				'', 		'post', 'string');
		$config_array['meta_alexa']						= JRequest::getVar('meta_alexa', 					'', 		'post', 'string');
		$config_array['meta_name_1']					= JRequest::getVar('meta_name_1', 					'', 		'post', 'string');
		$config_array['meta_name_2']					= JRequest::getVar('meta_name_2', 					'', 		'post', 'string');
		$config_array['meta_name_3']					= JRequest::getVar('meta_name_3', 					'', 		'post', 'string');
		$config_array['meta_con_1']						= JRequest::getVar('meta_con_1', 					'', 		'post', 'string');
		$config_array['meta_con_2']						= JRequest::getVar('meta_con_2', 					'', 		'post', 'string');
		$config_array['meta_con_3']						= JRequest::getVar('meta_con_3', 					'', 		'post', 'string');
		// SEO
		$config_array['seo_h1']							= JRequest::getVar('seo_h1', 						0, 			'post', 'int');
		$config_array['seo_nofollow']					= JRequest::getVar('seo_nofollow', 					0, 			'post', 'int');
		$config_array['seo_il']							= JRequest::getVar('seo_il', 						0, 			'post', 'int');
		$config_array['seo_il_nofollow']				= JRequest::getVar('seo_il_nofollow', 				0, 			'post', 'int');
		$config_array['seo_il_target']					= JRequest::getVar('seo_il_target', 				0, 			'post', 'int');
		$config_array['seo_il_limit']					= JRequest::getVar('seo_il_limit', 					'10', 		'post', 'string');
		$config_array['seo_il_words']					= JRequest::getVar('seo_il_words', 					'', 		'post', 'string');
		// 404
		$config_array['page404']						= JRequest::getVar('page404', 						'custom', 	'post', 'string');
		// auto upgrade
		$config_array['download_id']					= JRequest::getVar('download_id', 					'custom', 	'post', 'string');
		
		$config->loadArray($config_array);
		
		// Save 404 Page
		$db =& JFactory::getDBO();
		$db->setQuery('SELECT id FROM #__content WHERE `title` = "404"');
        $introtext = (get_magic_quotes_gpc() ? $_POST['introtext'] : addslashes($_POST['introtext']));
        if ($id = $db->loadResult()){
            $sql = 'UPDATE #__content SET introtext="'.$introtext.'",  modified ="'.date("Y-m-d H:i:s").'" WHERE `id` = "'.$id.'";';
        } else {
            $sql='SELECT MAX(id) FROM #__content';
            $db->setQuery($sql);
            if ($max = $db->loadResult()) {
                $max++;
                $sql = 'INSERT INTO #__content (id, title, alias, introtext, `fulltext`, state, sectionid, mask, catid, created, created_by, created_by_alias, modified, modified_by, checked_out, checked_out_time, publish_up, publish_down, images, urls, attribs, version, parentid, ordering, metakey, metadesc, access, hits) '.
                'VALUES( "'.$max.'", "404", "404", "'.$introtext.'", "", "1", "0", "0", "0", "2004-11-11 12:44:38", "62", "", "'.date("Y-m-d H:i:s").'", "0", "62", "2004-11-11 12:45:09", "2004-10-17 00:00:00", "0000-00-00 00:00:00", "", "", "menu_image=-1\nitem_title=0\npageclass_sfx=\nback_button=\nrating=0\nauthor=0\ncreatedate=0\nmodifydate=0\npdf=0\nprint=0\nemail=0", "1", "0", "0", "", "", "0", "750");';
            }
        }
		$db->setQuery($sql);
		$db->query();
		
		// Set the configuration filename
		$filename = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php';

		if (JPath::isOwner($filename) && !JPath::setPermissions($filename, '0644')) {
			JError::raiseNotice('2002', 'Could not make the '.$filename.' writable');
		}

		jimport('joomla.filesystem.file');
		if (JFile::write($filename, $config->toString('PHP', 'config', array('class' => 'acesef_configuration')))) {
			return true;
		} else {
			return false;
		}
	}
}
?>