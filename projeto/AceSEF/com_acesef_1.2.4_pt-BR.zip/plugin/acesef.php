<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

// Include configuration file
require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');

class plgSystemAcesef extends JPlugin {

	function plgSystemAcesef(& $subject, $config) {
		parent::__construct($subject, $config);
		
		// Load plugin parameters
        $this->_plugin = & JPluginHelper::getPlugin('system', 'acesef');
        $this->_params = new JParameter($this->_plugin->params);
		$this->acesef_config = new acesef_configuration();
	}
	
	function onPrepareContent(&$row, &$params, $page=0){
		global $mainframe;
		
		// Word Linker
		if (is_object($row) && $this->acesef_config->seo_il == 1) {
			$nofollow	= $this->acesef_config->seo_il_nofollow;
			$target		= $this->acesef_config->seo_il_target;
			$limit		= $this->acesef_config->seo_il_limit;
			$words		= $this->acesef_config->seo_il_words;
			
			$row->text	= $this->wordLinker($row->text, $nofollow, $target, $limit, $words);
		}
		
		// No follow
		if (JString::strpos($row->text, 'href="') === false) {
			return true;
		}
		
		if ($this->acesef_config->seo_nofollow == 1) {
			$regex = '/<a (.*?)href=[\"\'](.*?)\/\/(.*?)[\"\'](.*?)>(.*?)<\/a>/i';
			$row->text = preg_replace_callback($regex, array(&$this, 'noFollow'), $row->text);
		}
		
		$metakey  = str_replace('"', '&quot;', $mainframe->get('acesef.meta.key'));
		
		
		return true;
	}
	
	function onBeforeDisplayContent(& $article, & $params, $limitstart)	{
		global $mainframe;
		if ($mainframe->isAdmin()) return true;
		
		// Set h1 tag
		if($this->acesef_config->seo_h1 == 1)
			$article->title = '{h1}'.$article->title.'{/h1}';

		return '';
	}

	// Assign the new router for the SEF URL rewritting
	function onAfterInitialise() {
		global $mainframe;
		
		// Administration area
        if ($mainframe->isAdmin()) return true;

        // Joomla SEF is disabled
        $config =& JFactory::getConfig();
        if (!$config->getValue('sef')) return true;

		// Check if AceSEF is enabled
		if ($this->acesef_config->mode == 1) {
			$router =& $mainframe->getRouter();
			require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'mainrouter.php');
			$router = new JRouterAcesef();
		}
		
		// SSL and non-www settings
		$uri  =& JURI::getInstance();
		$host =& $uri->getHost();
		
		$redirect = false;
		
		// non-www
		if($this->acesef_config->redirect_to_www == 1 && strpos($host, 'www') === false) {
			$redirect = true;
			$uri->setHost('www.'.$host);
		}
		
		// forse ssl
		if($this->acesef_config->force_ssl == 1 && !$uri->isSSL()) {
			$redirect = true;
			$uri->setScheme('https');
		}
		
		if ($redirect) {
			$url = $uri->toString();
			header('Location: '. $url, true, 301);
			$app = & JFactory::getApplication();
			$app->close();
		}
	}
	
	function onAfterRoute() {
        global $mainframe;

        // Administration area
        if ($mainframe->isAdmin()) return true;

        // Joomla SEF is disabled
        $config =& JFactory::getConfig();
        if (!$config->getValue('sef')) return true;

        // Check if AceSEF is enabled
        if ($this->acesef_config->mode == 0) return true;

        return true;
    }

    function onAfterDispatch() {
        global $mainframe;
		
		$document =& JFactory::getDocument();
		$config = &JFactory::getConfig();

        // Administration area
        if ($mainframe->isAdmin()) return true;
		
		// Joomla SEF is disabled
        $config =& JFactory::getConfig();
        if (!$config->getValue('sef')) return true;

        // Check if AceSEF is enabled
        if ($this->acesef_config->mode == 0) return true;
		
		// Get Meta Tags
		$metatitle  	= str_replace('"', '&quot;', $mainframe->get('acesef.meta.title'));
		$metadesc   	= str_replace('"', '&quot;', $mainframe->get('acesef.meta.desc'));
        $metakey    	= str_replace('"', '&quot;', $mainframe->get('acesef.meta.key'));
        $metalang   	= str_replace('"', '&quot;', $mainframe->get('acesef.meta.lang'));
        $metarobots		= str_replace('"', '&quot;', $mainframe->get('acesef.meta.robots'));
        $metagoogle		= str_replace('"', '&quot;', $mainframe->get('acesef.meta.google'));
        $linkcanonical	= str_replace('"', '&quot;', $mainframe->get('acesef.link.canonical'));
		$generator  	= str_replace('"', '&quot;', $this->acesef_config->meta_generator);
		$abstract  		= str_replace('"', '&quot;', $this->acesef_config->meta_abstract);
		$revisit  		= str_replace('"', '&quot;', $this->acesef_config->meta_revisit);
		$direction 		= str_replace('"', '&quot;', $this->acesef_config->meta_direction);
		$googlekey  	= str_replace('"', '&quot;', $this->acesef_config->meta_googlekey);
		$livekey  		= str_replace('"', '&quot;', $this->acesef_config->meta_livekey);
		$yahookey  		= str_replace('"', '&quot;', $this->acesef_config->meta_yahookey);
		$alexa  		= str_replace('"', '&quot;', $this->acesef_config->meta_alexa);
		$name_1  		= str_replace('"', '&quot;', $this->acesef_config->meta_name_1);
		$name_2  		= str_replace('"', '&quot;', $this->acesef_config->meta_name_2);
		$name_3  		= str_replace('"', '&quot;', $this->acesef_config->meta_name_3);
		$con_1  		= str_replace('"', '&quot;', $this->acesef_config->meta_con_1);
		$con_2  		= str_replace('"', '&quot;', $this->acesef_config->meta_con_2);
		$con_3  		= str_replace('"', '&quot;', $this->acesef_config->meta_con_3);
		
		// Set Meta Tags
		$pageTitle = $document->getTitle();
		if (!empty($metatitle))
			$pageTitle = $metatitle;
			
		if(!empty($pageTitle))		$document->setTitle($pageTitle);
		if(!empty($pageTitle))		$document->setMetaData('title', $pageTitle);
		if(!empty($metadesc))		$document->setDescription($metadesc);
		if(!empty($metakey))		$document->setMetaData('keywords', $metakey);
		if(!empty($metarobots))		$document->setMetaData('robots', $metarobots);
		if(!empty($metalang))		$document->setMetaData('language', $metalang);
		if(!empty($metagoogle))		$document->setMetaData('googlebot', $metagoogle);
		if(!empty($linkcanonical)) 	$document->addHeadLink($linkcanonical, 'canonical');
		if(!empty($generator)) 		$document->setGenerator($generator);
		if(!empty($abstract)) 		$document->setMetaData('abstract', $abstract);
		if(!empty($revisit)) 		$document->setMetaData('revisit', $revisit);
		if(!empty($direction)) 		$document->setDirection($direction);
		if(!empty($googlekey))		$document->setMetaData('verify-v1', $googlekey);
		if(!empty($livekey))		$document->setMetaData('msvalidate.01', $livekey);
		if(!empty($yahookey))		$document->setMetaData('y_key', $yahookey);
		if(!empty($alexa))			$document->setMetaData('alexa', $alexa);
		if(!empty($name_1))			$document->setMetaData($name_1, $con_1);
		if(!empty($name_2))			$document->setMetaData($name_2, $con_2);
		if(!empty($name_3))			$document->setMetaData($name_3, $con_3);
		
		// Set base href
    	if ($this->acesef_config->base_href == 2) {
        	$document->setBase(JURI::current());
        } elseif ($this->acesef_config->base_href == 3) {
        	$document->setBase(JURI::base());
        } elseif ($this->acesef_config->base_href == 4) {
        	$document->setBase('');
        }
		
        return true;
    }
    
    // H1 tag
	function onAfterRender(){
		global $mainframe;

		$document	=& JFactory::getDocument();
		$docType	= $document->getType();

		// Return if page is not html
		if ($docType != 'html') return true;

		// Return if we are on the administrator area
		if ($mainframe->isAdmin()) return true;
		
		// h1 tag
		if($this->acesef_config->seo_h1 == 1) {
			// Get body contents
			$body = JResponse::getBody();
			
			// Replace {h1} and {/h1} placeholders by the corresponding
			$body = str_replace('{h1}', '<h1>', $body);
			$body = str_replace('{/h1}', '</h1>', $body);
	
			// Set new body contents
			JResponse::setBody($body);
		}

		return;
	}
	
	function preg_callback_url($matches) {
	    //var_dump($matches);
	    $url = $matches[1].$matches[2];
	    $text = '';
	    $pos = strpos($url,' ');
	    if ($pos !== FALSE) {
	    	$text = trim(substr($url, $pos+1));
	    	$url = substr($url, 0, $pos);
	    }
	 	return '<a href="'.$url.'" rel="nofollow">'.(($text!='') ? $text : $url).'</a>';
	 } 
	
	// No follow

	function noFollow($match){
		$local	=& JFactory::getURI();
	
		if ($this->getDomainFromLink($match[3]) != $local->getHost() && !$this->alreadyNofollow($match[1]) && !$this->alreadyNofollow($match[4])){
			return '<a href="' . $match[2] . '//' . $match[3] . '"' . $match[1] . $match[4] . ' rel="nofollow" >' . $match[5] . '</a>';
		} else {
			return '<a href="' . $match[2] . '//' . $match[3] . '"' . $match[1] . $match[4] . '>' . $match[5] . '</a>';
		}
	}
	
	function getDomainFromLink($url){
		preg_match("/^(http:\/\/)?([^\/]+)/i", $url, $match);
		$domain = $match[2];
		preg_match("/[^\.\/]+\.[^\.\/]+$/", $domain, $match);
		return $match[0];
	}
	
	
	function alreadyNofollow($text){
		return (preg_match("/rel=[\"\'].*?nofollow.*?[\"\']/i", $text )) ? true : false ;
	}
	
	function wordLinker(&$text, $nofollow, $target, $limit, $words) {
		if($nofollow == 1)
			$nofollow = 'rel="nofollow"';
		else
			$nofollow = "";
		
		
		if($target == 0)
			$target = 'target="_parent"';
		else
			$target = 'target="_blank"';
		
		$keys = explode(", ", $words);
		
		foreach ($keys as $key)	{
			$pat='/([\w\W]*?)\|([\w\W]*)/';
			if(preg_match_all($pat, $key, $matches, PREG_SET_ORDER)) {
				foreach ($matches as $match) {
					$keyword = $match[1];
					$link = $match[2];
					$replace = '<a href="'.$link.'" '.$target.' title="'.$keyword.'" '.$nofollow.'>'.$keyword.'</a>';
					
					$case = "i";
					$regEx = '\'(?!((<.*?)|(<a.*?)))(\b'.$keyword.'\b)(?!(([^<>]*?)>)|([^>]*?</a>))\'s'.$case;				 
					$text = preg_replace($regEx, $replace, $text, $limit);	
				}
			}
		}
		return $text;
	}
}
?>