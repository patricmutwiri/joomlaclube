# -----------------------
# AceSEF SQL Installation
# -----------------------
DROP TABLE IF EXISTS `#__acesef_urls`;
CREATE TABLE  `#__acesef_urls` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `url_sef` varchar(255) NOT NULL default '',
  `url_real` varchar(255) NOT NULL default '',
  `url_moved` tinyint(1) NOT NULL default '0',
  `metatitle` varchar(255) default '',
  `metadesc` varchar(255) default '',
  `metakey` varchar(255) default '',
  `metalang` varchar(30) default '',
  `metarobots` varchar(30) default '',
  `metagoogle` varchar(30) default '',
  `linkcanonical` varchar(255) default '',
  `published` tinyint(1) unsigned NOT NULL default '0',
  `used` tinyint(1) unsigned NOT NULL default '5',
  `locked` tinyint(1) unsigned NOT NULL default '0',
  `blocked` tinyint(1) unsigned NOT NULL default '0',
  `notes` text default '',
  `sef_tmp_url` varchar(255) NOT NULL default '',
  `checked_out` int(11) NOT NULL,
  `date` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`),
  KEY `url_real` (`url_real`),
  KEY `url_sef` (`url_sef`)
) TYPE=MyISAM CHARACTER SET `utf8`;

DROP TABLE IF EXISTS `#__acesef_urls_moved`;
CREATE TABLE IF NOT EXISTS `#__acesef_urls_moved` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `url_old` varchar(255) NOT NULL default '',
  `url_new` varchar(255) NOT NULL default '',
  `published` tinyint(1) unsigned NOT NULL default '1',
  `hits` int(11) unsigned NOT NULL default '0',
  `last_hit` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `url_old` (`url_old`)
) TYPE=MyISAM CHARACTER SET `utf8`;

DROP TABLE IF EXISTS `#__acesef_extensions`;
CREATE TABLE  `#__acesef_extensions` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `version` varchar(10) NOT NULL,
  `author` varchar(255) NOT NULL default '',
  `author_url` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `extension` varchar(45) NOT NULL,
  `router_type` tinyint(1) unsigned NOT NULL default '0',
  `rewrite_rule` tinyint(1) unsigned NOT NULL default '0',
  `component_prefix` varchar(255) NOT NULL default '',
  `skip_title` tinyint(1) unsigned NOT NULL default '0',
  `checked_out` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM CHARACTER SET `utf8`;

INSERT INTO `#__acesef_extensions` (`id`, `name`, `params`, `author`, `description`, `version`, `author_url`, `extension`, `router_type`, `rewrite_rule`, `component_prefix`, `skip_title`) VALUES
(1, 'News Feeds', 'limitnum=5\n', 'JoomAce LLC', 'News Feeds extension for AceSEF.', '1.2.2', 'www.joomace.net', 'com_newsfeeds', '4', '3', '', '0'),
(2, 'Web Links', 'limitnum=5\n', 'JoomAce LLC', 'Web Links extension for AceSEF.', '1.2.2', 'www.joomace.net', 'com_weblinks', '4', '3', '', '0'),
(3, 'User', 'limitnum=5\n', 'JoomAce LLC', 'User extension for AceSEF.', '1.2.3', 'www.joomace.net', 'com_user', '4', '3', 'user', '0'),
(4, 'Mailto', 'limitnum=5\n', 'JoomAce LLC', 'Mailto extension for AceSEF.', '1.2.2', 'www.joomace.net', 'com_mailto', '4', '3', 'mail', '0'),
(5, 'Search', 'limitnum=5\n', 'JoomAce LLC', 'Search extension for AceSEF.', '1.2.2', 'www.joomace.net', 'com_search', '4', '3', 'search', '0'),
(6, 'Contact', 'limitnum=5\n', 'JoomAce LLC', 'Contact extension for AceSEF.', '1.2.2', 'www.joomace.net', 'com_contact', '4', '3', '', '1'),
(7, 'Polls', 'limitnum=5\n', 'JoomAce LLC', 'Polls extension for AceSEF.', '1.2.2', 'www.joomace.net', 'com_poll', '4', '3', 'poll', '0'),
(8, 'Banners', 'limitnum=5\n', 'JoomAce LLC', 'Banners extension for AceSEF.', '1.2.2', 'www.joomace.net', 'com_banners', '4', '3', 'banner', '0'),
(9, 'Content', 'limitnum=5\n', 'JoomAce LLC', 'Content (Articles) extension for AceSEF.', '1.2.2', 'www.joomace.net', 'com_content', '4', '3', '', '1'),
(10, 'Wrapper', 'limitnum=5\n', 'JoomAce LLC', 'Wrapper extension for AceSEF.', '1.2.2', 'www.joomace.net', 'com_wrapper', '4', '3', '', '0');

INSERT INTO `#__plugins` ( `name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES ('System - AceSEF', 'acesef', 'system', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', '');