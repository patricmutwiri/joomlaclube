<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

?>
<script language="javascript" type="text/javascript">
<!--
	function getCom(file) {
	    var form = document.adminForm;
	    
	    form.task.value = 'upgrade';
	    form.acesefupgradefile.value = file;
		form.submit();
	}
//-->
</script>

<form action="index.php" method="post" name="adminForm">
	<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<th>		
				<?php
					$config			=& JFactory::getConfig();
					$sef_enabled	= $config->getValue('sef');
					$mod_rewrite	= $config->getValue('sef_rewrite');
					$htaccess		= file_exists(JPATH_ROOT.DS.'.htaccess');
					$joomfish		= file_exists(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_joomfish'.DS.'joomfish.php');
					if (!$sef_enabled) {
						JError::raiseNotice('100', JText::sprintf('ACESEF_COMMON_SEF_DISABLED', '<a href="index.php?option=com_config">', '</a>'));
					}
					if ($sef_enabled && !$mod_rewrite) {
						JError::raiseWarning('100', JText::sprintf('ACESEF_COMMON_SEF_MOD_REWRITE', '<a href="index.php?option=com_config">', '</a>'));
					}
					if ($config->getValue('sef') && !$htaccess) {
						JError::raiseWarning('100', JText::sprintf('ACESEF_COMMON_NO_HTACCESS'));
					}
					if (!$htaccess || !$mod_rewrite || !$sef_enabled) {
						JError::raiseNotice('100', JText::sprintf('ACESEF_COMMON_ACESE_REQUIREMENTS', '<a href="http://www.joomace.net/documentation/acesef/user-manual/acesef-requirements">', '</a>'));
					}
					if ($joomfish) {
						$db =& JFactory::getDBO();
						$db->setQuery("SELECT id FROM #__plugins WHERE element = 'jfrouter' AND published = '1'");
						$jf_id = $db->loadResult();
						if(!is_null($jf_id))
							JError::raiseNotice('100', JText::sprintf('ACESEF_COMMON_JFROUTER_ENABLED', '<a href="index.php?option=com_plugins&view=plugin&client=site&task=edit&cid[]='.$jf_id.'">', '</a>'));
					}
				?>	
			</th>
		</tr>
		<tr>
			<td valign="top">
				<table class="adminlist">
					<tr>
						<td>
							<div id="cpanel" width="50%">
							<?php
							global $option;

							$link = 'index.php?option='.$option.'&amp;controller=config&amp;task=edit';
							AcesefViewAcesef::quickiconButton($link, 'cp-configuration.png', JText::_('ACESEF_CPANEL_CONFIGURATION'));

							$link = 'index.php?option='.$option.'&amp;controller=extensions&amp;task=view';
							AcesefViewAcesef::quickiconButton($link, 'cp-extensions.png', JText::_('ACESEF_CPANEL_EXTENSIONS'));
							
							$link = 'index.php?option='.$option.'&amp;controller=metamanager&amp;task=view';
							AcesefViewAcesef::quickiconButton($link, 'cp-metamanager.png', JText::_('ACESEF_CPANEL_META_MANAGER'));
							
							$link = 'index.php?option='.$option.'&amp;controller=import&amp;task=view';
							AcesefViewAcesef::quickiconButton($link, 'cp-import.png', JText::_('ACESEF_CPANEL_IMPORT'));
							
							$link = 'index.php?option='.$option.'&amp;controller=upgrade&amp;task=view';
							AcesefViewAcesef::quickiconButton($link, 'cp-upgrade.png', JText::_('ACESEF_CPANEL_UPGRADE'));
							?>
							<br /><br /><br /><br /><br /><br /><br /><br />
							<?php
							$link = 'index.php?option='.$option.'&amp;controller=repository&amp;task=view&amp;type=1';
							AcesefViewAcesef::quickiconButton($link, 'cp-urlssef.png', JText::_('ACESEF_CPANEL_SEF_URLS'));
							
							$link = 'index.php?option='.$option.'&amp;controller=repository&amp;task=view&amp;type=2';
							AcesefViewAcesef::quickiconButton($link, 'cp-urlslocked.png', JText::_('ACESEF_CPANEL_LOCKED_URLS'));
							
							$link = 'index.php?option='.$option.'&amp;controller=repository&amp;task=view&amp;type=3';
							AcesefViewAcesef::quickiconButton($link, 'cp-urlscustom.png', JText::_('ACESEF_CPANEL_CUSTOM_URLS'));

							$link = 'index.php?option='.$option.'&amp;controller=repository&amp;task=view&amp;type=4';
							AcesefViewAcesef::quickiconButton($link, 'cp-urls404.png', JText::_('ACESEF_CPANEL_404_URLS'));
							
							$link = 'index.php?option='.$option.'&amp;controller=movedurls&amp;task=view';
							AcesefViewAcesef::quickiconButton($link, 'cp-urlsmoved.png', JText::_('ACESEF_CPANEL_MOVED_URLS'));
							?>
							<br /><br /><br /><br /><br /><br /><br /><br />
							<?php
							$link = 'index.php?option='.$option.'&amp;controller=purge&task=purge&amp;type=1&amp;do=0';
							AcesefViewAcesef::quickiconButton($link, 'cp-purge-urlssef.png', JText::_('ACESEF_CPANEL_PURGE_SEF_URLS'));
							
							$link = 'index.php?option='.$option.'&amp;controller=purge&task=purge&amp;type=2&amp;do=0';
							AcesefViewAcesef::quickiconButton($link, 'cp-purge-urlslocked.png', JText::_('ACESEF_CPANEL_PURGE_LOCKED_URLS'));
							
							$link = 'index.php?option='.$option.'&amp;controller=purge&task=purge&amp;type=3&amp;do=0';
							AcesefViewAcesef::quickiconButton($link, 'cp-purge-urlscustom.png', JText::_( 'ACESEF_CPANEL_PURGE_CUSTOM_URLS'));

							$link = 'index.php?option='.$option.'&amp;controller=purge&task=purge&amp;type=4&amp;do=0';
							AcesefViewAcesef::quickiconButton($link, 'cp-purge-urls404.png', JText::_('ACESEF_CPANEL_PURGE_404_URLS'));
							
							$link = 'index.php?option='.$option.'&amp;controller=purge&task=purge&amp;type=5&amp;do=0';
							AcesefViewAcesef::quickiconButton($link, 'cp-purge-urlsmoved.png', JText::_('ACESEF_CPANEL_PURGE_MOVED_URLS'));
							?>
							<br /><br /><br /><br /><br /><br /><br /><br />
							<?php
							
							$link = 'http://www.joomace.net/documentation/acesef/user-manual';
							AcesefViewAcesef::quickiconButton($link, 'cp-doc.png', JText::_('ACESEF_CPANEL_DOC'));
							
							$link = 'index.php?option='.$option.'&amp;controller=support&amp;task=support';
							AcesefViewAcesef::quickiconButton($link, 'cp-support.png', JText::_('ACESEF_CPANEL_SUPPORT'));
							
							$link = 'index.php?option='.$option.'&amp;controller=support&amp;task=translators';
							AcesefViewAcesef::quickiconButton($link, 'cp-translators.png', JText::_('ACESEF_CPANEL_TRANSLATORS'));
							
							$link = 'index.php?option='.$option.'&amp;controller=support&amp;task=changelog';
							AcesefViewAcesef::quickiconButton($link, 'cp-changelog.png', JText::_('ACESEF_CPANEL_CHANGELOG'));
							
							?>
							</div>
						</td>
					</tr>
				</table>
			</td>
			<td valign="top" width="45%" style="padding: 7px 0 0 5px">
				<?php
				$title = JText::_('ACESEF_CPANEL_WELLCOME');
				echo $this->pane->startPane('stat-pane');
				echo $this->pane->startPanel($title, 'wellcome');
				?>
				<table class="adminlist">
					<tr>
						<td valign="top" width="50%" align="center">
							<table class="adminlist">
								<tr>
									<td width="%25">
										<?php
											if ($this->version['status'] == 0) {
												echo JHTML::_('image', 'administrator/templates/khepri/images/header/icon-48-checkin.png', null);
											} elseif($this->version['status'] == -1) {
												echo JHTML::_('image', 'administrator/templates/khepri/images/header/icon-48-help_header.png', null);
											} else {
												echo JHTML::_('image', 'administrator/templates/khepri/images/header/icon-48-help_header.png', null);
											}
										?>
									</td>
									<td width="%35">
										<?php
											if ($this->version['status'] == 0) {
												echo '<strong><font color="green">'.JText::_('ACESEF_CPANEL_LATEST_VERSION_INSTALLED').'</font></strong>';
											} elseif($this->version['status'] == -1) {
												echo '<b><font color="red">'.JText::_('ACESEF_CPANEL_OLD_VERSION').'</font></b>';
											} else {
												echo '<b><font color="orange">'.JText::_('ACESEF_CPANEL_NEWER_VERSION').'</font></b>';
											}
										?>
									</td>
									<td align="center" rowspan="5">
										<a href="http://www.joomace.net/joomla-extensions/acesef">
										<img src="components/com_acesef/assets/images/logo.png" width="165" height="232" alt="AceSEF" title="AceSEF" align="middle" border="0">
										</a>
									</td>
								</tr>
								<tr>
									<td>
										<?php
											if ($this->version['status'] == 0) {
												echo JText::_('ACESEF_CPANEL_LATEST_VERSION');
											} elseif($this->version['status'] == -1) {
												echo '<b><font color="red">'.JText::_('ACESEF_CPANEL_LATEST_VERSION').'</font></b>';
											} else {
												echo '<b><font color="orange">'.JText::_('ACESEF_CPANEL_LATEST_VERSION').'</font></b>';
											}
										?>
									</td>
									<td>
										<?php
											if ($this->version['status'] == 0) {
												echo $this->version['latest_version'];
											} elseif($this->version['status'] == -1) {
												// Version output in red
												echo '<b><font color="red">'.$this->version['latest_version'].'</font></b>&nbsp;&nbsp;&nbsp;&nbsp;';
												// Upgrade buton
												require_once(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
												$this->acesef_config = new acesef_configuration();
												$f = "fr"."ee"."-d"."own"."loa"."ds/c"."ompo"."nen"."ts/"."ac"."es"."ef/d"."own"."lo"."ad";
												$c = "e-s"."hop"."/do"."wnl"."oad"."-a"."rea"."/dow"."nlo"."ad-r"."equ"."est?do"."wnl"."oa"."d_i"."d=";
												$download_id = $this->acesef_config->download_id;
												if(strlen($download_id) == 32){
													$file = $c.$download_id;
													$func = "getCom('".$file."');";
												} else {
													echo '<b><font color="red">'.JText::_('ACESEF_CPANEL_UPGRADE_NO_DOWNLOAD_ID').'</font></b>&nbsp;&nbsp;&nbsp;&nbsp;';
													$file = $f;
													$func = "getCom('".$file."');";
												}
												?>
												<input type="button" class="button hasTip" value="<?php echo JText::_('ACESEF_CPANEL_UPGRADE'); ?>" onclick="<?php echo $func; ?>" />
												<?php
											} else {
												echo '<b><font color="orange">'.$this->version['latest_version'].'</font></b>';
											}
										?>
									</td>
								</tr>
								<tr>
									<td>
										<?php echo JText::_('ACESEF_CPANEL_INSTALLED_VERSION'); ?>
									</td>
									<td>
										<?php echo $this->version['installed_version']; ?>
									</td>
								</tr>
								<tr>
									<td>
										<?php echo JText::_('ACESEF_CPANEL_COPYRIGHT'); ?>
									</td>
									<td>
										<a href="http://www.joomace.net" target="_blank">&copy 2009 JoomAce LLC</a>
									</td>
								</tr>
								<tr>
									<td>
										<?php echo JText::_('ACESEF_CPANEL_LICENSE'); ?>
									</td>
									<td>
										<a href="http://www.joomace.net/company/license" target="_blank">Combined License</a>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<?php
				$title = JText::_('ACESEF_CPANEL_REQUIREMENTS');
				echo $this->pane->endPanel();
				echo $this->pane->startPanel($title, 'requirements');
				?>
				<table class="adminlist">
					<tr>
						<td width="25%">
							<?php echo JText::_('ACESEF_CPANEL_REQUIREMENTS_PHP'); ?>
						</td>
						<td width="75%">
							<?php 
							if(version_compare(PHP_VERSION, '5.0.0', '>')) {
								echo '<strong><font color="green">'.JText::_('ACESEF_CPANEL_REQUIREMENTS_PHP_OK').'</font></strong>'; 
							} else
								echo '<strong><font color="red">'.JText::_('ACESEF_CPANEL_REQUIREMENTS_PHP_NO').'</font></strong>'; 
							?>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo JText::_('ACESEF_CPANEL_REQUIREMENTS_SEF'); ?>
						</td>
						<td>
							<?php 
							if($sef_enabled) {
								echo '<strong><font color="green">'.JText::_('ACESEF_CPANEL_REQUIREMENTS_SEF_OK').'</font></strong>'; 
							} else
								echo '<strong><font color="red">'.JText::_('ACESEF_CPANEL_REQUIREMENTS_SEF_NO').'</font></strong>'; 
							?>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo JText::_('ACESEF_CPANEL_REQUIREMENTS_MOD_ENABLED'); ?>
						</td>
						<td>
							<?php 
							if($mod_rewrite) {
								echo '<strong><font color="green">'.JText::_('ACESEF_CPANEL_REQUIREMENTS_MOD_ENABLED_OK').'</font></strong>'; 
							} else
								echo '<strong><font color="red">'.JText::_('ACESEF_CPANEL_REQUIREMENTS_MOD_ENABLED_NO').'</font></strong>';
							?>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo JText::_('ACESEF_CPANEL_REQUIREMENTS_HTA'); ?>
						</td>
						<td>
							<?php 
							if($htaccess) {
								echo '<strong><font color="green">'.JText::_('ACESEF_CPANEL_REQUIREMENTS_HTA_OK').'</font></strong>'; 
							} else
								echo '<strong><font color="red">'.JText::_('ACESEF_CPANEL_REQUIREMENTS_HTA_NO').'</font></strong>'; 
							?>
						</td>
					</tr>
				</table>
				<?php
				$title = JText::_('ACESEF_CPANEL_URLS_STATS');
				echo $this->pane->endPanel();
				echo $this->pane->startPanel($title, 'stats');
				?>
				<table class="adminlist">
					<tr>
						<td width="25%">
							<?php echo JText::_('ACESEF_CPANEL_SEF_URLS'); ?>
						</td>
						<td width="75%">
							<b><?php echo $this->urls['sef']; ?></b>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo JText::_('ACESEF_CPANEL_404_URLS'); ?>
						</td>
						<td>
							<b><?php echo $this->urls['404']; ?></b>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo JText::_('ACESEF_CPANEL_MOVED_URLS'); ?>
						</td>
						<td>
							<b><?php echo $this->urls['moved']; ?></b>
						</td>
					</tr>
					<tr>
						<td>
							<b><?php echo JText::_('ACESEF_CPANEL_TOTAL_URLS'); ?></b>
						</td>
						<td>
							<b><?php echo $this->urls['total']; ?></b>
						</td>
					</tr>
					<tr>
						<td>
							&nbsp;
						</td>
						<td>
							&nbsp;
						</td>
					</tr>
					<tr>
						<td>
							<?php echo JText::_('ACESEF_CPANEL_LOCKED_URLS'); ?>
						</td>
						<td>
							<b><?php echo $this->urls['locked']; ?></b>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo JText::_('ACESEF_CPANEL_CUSTOM_URLS'); ?>
						</td>
						<td>
							<b><?php echo $this->urls['custom']; ?></b>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo JText::_('ACESEF_CPANEL_BLOCKED_URLS'); ?>
						</td>
						<td>
							<b><?php echo $this->urls['blocked']; ?></b>
						</td>
					</tr>
				</table>
				<?php
				$title = JText::_('ACESEF_CPANEL_DONATE');
				echo $this->pane->endPanel();
				echo $this->pane->startPanel($title, 'donate');
				?>
				<table class="adminlist">
					<tbody>
					<tr>
						<td width="60%">
							<?php echo JText::_('ACESEF_CPANEL_DONATE_TEXT'); ?>
						</td>
						<td>
							<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
							<input type="hidden" name="cmd" value="_s-xclick">
							<input type="hidden" name="hosted_button_id" value="8072927">
							<input type="image" src="https://www.paypal.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
							<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
							</form>
						</td>
					</tr>
					</tbody>
				</table>
				<?php
				echo $this->pane->endPanel();
				echo $this->pane->endPane();
				?>
			</td>
		</tr>
	</table>
	
	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="acesef" />
	<input type="hidden" name="task" value="view" />
	<input type="hidden" name="acesefupgradefile" value="" />
</form>