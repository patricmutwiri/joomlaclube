<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport('joomla.application.component.model');

// Model Class
class AcesefModelEditurlmoved extends JModel {
	
	var $_id = NULL;
	var $_data = NULL;
	
	// Main constructer
	function __construct() {
		parent::__construct();
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		
		$this->_id = $cid[0];
	}
	
	// Get data about the URL
	function getData() {
		// Load the record
		$db =& JFactory::getDBO();
		
		if (is_numeric($this->_id)){
			$this->_data =& JTable::getInstance('acesef_urls_moved', 'Table'); 
			$this->_data->load($this->_id);
		} else {
			$db->setQuery("SELECT * FROM #__acesef_urls_moved WHERE url_new = '".$this->_id."' ORDER BY id");
			$this->_data = $db->loadObject();
		}
	
		return $this->_data;
	}
	
	// Save URL changes
	function save($id = 0) {
		$db =& JFactory::getDBO();
		$row =& JTable::getInstance('acesef_urls_moved', 'Table'); 
		$post = JRequest::get('post');
		
		// Bind the form fields to the table
		if (!$row->bind($post)) {
			return JError::raiseWarning(500, $row->getError());
		}

		// Make sure the record is valid
		if (!$row->check()) {
			return JError::raiseWarning(500, $row->getError());
		}
		
		// Save the changes
		if (!$row->store()) {
			return JError::raiseWarning(500, $row->getError());
		}
		
		return true;
	}
}
?>