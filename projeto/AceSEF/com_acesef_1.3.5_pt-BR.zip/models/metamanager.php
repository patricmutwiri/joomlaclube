<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport( 'joomla.application.component.model' );

// Model Class
class AcesefModelMetamanager extends JModel {
	
	var $_query;
	var $_data 			= null;
	var $_total 		= null;
	var $_pagination 	= null;
	
	// Main constructer
	function __construct()	{
		parent::__construct();
		
		global $mainframe, $option;
		
		$this->_buildViewQuery();

		// Get the pagination request variables
		$limit		= $mainframe->getUserStateFromRequest($option.'.metamanager.limit',	'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart	= $mainframe->getUserStateFromRequest($option.'.metamanager.limitstart', 'limitstart', 0, 'int');
		
		// Limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		$this->setState($option.'.metamanager.limit', $limit);
		$this->setState($option.'.metamanager.limitstart', $limitstart);
	}
	
	// Save changes
	function save($id) {		
		$sef_id = JRequest::getVar('id');
		$title = JRequest::getVar('metatitle');
		$desc = JRequest::getVar('metadesc');
		$key = JRequest::getVar('metakey');
		
		// Some clean up
		$title = str_replace(array('\n\n', '\n', '\r', '\\', '"', '\'', '>'), array('', '', '', '', '\"', '\\\'', ''), $title);
		$desc = str_replace(array('\n\n', '\n', '\r', '\\', '"', '\'', ';'), array('', '', '', '', '\"', '\\\'', ''), $desc);
		$key = str_replace(array('\n\n', '\n', '\r', '\\', '"', '\'', ';'), array('', '', '', '', '\"', '\\\'', ''), $key);
		
		foreach ($sef_id as $prefix => $value) {
			$query = "UPDATE #__acesef_urls SET metatitle='".$title[$prefix]."', metadesc='".$desc[$prefix]."', metakey='".$key[$prefix]."' WHERE id=".$prefix;
			$this->_db->setQuery($query);
			$this->_db->query();
		}
	}
	
	// Get the id's of selected records
	function whereIds() {
		$ids = JRequest::getVar('cid', array(), 'post', 'array');	
		$where = '';
		if(count($ids) > 0){
			$where = ' WHERE `id` IN ('.implode(', ', $ids).')';
		}

		return $where;
	}
	
	// Export Meta
	function export($where = '') {
        $config =& JFactory::getConfig();
        $dbprefix = $config->getValue('config.dbprefix');
        $sql_data = '';
        $filename = 'acesef_meta.sql';
        $fields = array('url_real', 'metatitle', 'metadesc', 'metakey', 'metalang', 'metarobots', 'metagoogle', 'linkcanonical');

        $query = "SELECT * FROM `#__acesef_urls`";
        if(!empty($where)) {
            $query .= $where;
        }
        $this->_db->setQuery($query);
        $rows = $this->_db->loadObjectList();

        if (!empty($rows)) {
            foreach ($rows as $row) {
                $values = array();
                foreach ($fields as $field) {
                    if (isset($row->$field)) {
						require_once(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php');
                        $values[] = "'".str_replace("\n", "", AceSEFTools::replaceSpecialChars($row->$field))."'";
                    } else {
                        $values[] = "''";
                    }
                }
                $sql_data .= implode(',b,', $values)."\n";
            }
        } else {
            return false;
        }

        if(!headers_sent()) {
            // flush the output buffer
            while(ob_get_level() > 0) {
                ob_end_clean();
            }

            ob_start();
            header ('Expires: 0');
            header ('Last-Modified: '.gmdate ('D, d M Y H:i:s', time()) . ' GMT');
            header ('Pragma: public');
            header ('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header ('Accept-Ranges: bytes');
            header ('Content-Length: ' . strlen($sql_data));
            header ('Content-Type: Application/octet-stream');
            header ('Content-Disposition: attachment; filename="' . $filename . '"');
            header ('Connection: close');

            echo($sql_data);

            ob_end_flush();
            die();
            return true;
        } else {
            return false;
        }
    }
	
	// Get data
	function getData() {
		global $option;
		if (empty($this->_data)) {
			$this->_data=$this->_getList($this->_query, $this->getState($option.'.metamanager.limitstart'), $this->getState($option.'.metamanager.limit'));
		}
		return $this->_data;
	}
	
	// Get total extensions
	function getTotal() {
		// Load the content if it doesn't already exist
		if (empty($this->_total)) {
			$this->_total = $this->_getListCount($this->_query);	
		}
		return $this->_total;
	}
	
	// Get pagination
	function getPagination(){
		global $option;
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState($option.'.metamanager.limitstart'), $this->getState($option.'.metamanager.limit'));
		}
		return $this->_pagination;
	}
	
	// Finally build query
	function _buildViewQuery() {
		$where		= $this->_buildViewWhere();
		$orderby	= $this->_buildViewOrderBy();

		$this->_query = 'SELECT * FROM #__acesef_urls '.$where.$orderby;
	}

	// Query fileters
	function _buildViewWhere() {
		global $mainframe, $option;
		
        $search_sef			= $mainframe->getUserStateFromRequest($option.'.metamanager.search_sef', 		'search_sef', 		'');
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_order',		'filter_order',		'url_sef');
		$filter_order_Dir	= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_order_Dir',	'filter_order_Dir',	'ASC');
        $filter_component	= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_component', 	'filter_component', '');
			$filter_lang		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_lang', 		'filter_lang', 		'');
		$filter_used		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_used', 		'filter_used',		-1);
		$filter_locked		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_locked', 	'filter_locked',	-1);
		$filter_all			= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_all',		'filter_all',		-1);
		$filter_title		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_title',		'filter_title',		-1);
		$filter_desc		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_desc',		'filter_desc',		-1);
		$filter_key			= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_key',		'filter_key',		-1);
		$search_sef			= JString::strtolower($search_sef);

		$where = array();
		
		// Search SEF URL
		if ($search_sef != '') {
			$where[] = 'LOWER(url_sef) LIKE '.$this->_db->Quote('%'.$search_sef.'%');
		}
		
		// Component Filter
		if ($filter_component != '') {
			$where[]= "(url_real LIKE '%option=$filter_component&%' OR url_real LIKE '%option=$filter_component')";
		}
			
		// Language Filter
		if ($filter_lang != '') {
			$where[]= "(url_real LIKE '%lang=$filter_lang&%' OR url_real LIKE '%lang=$filter_lang')";
		}
	
		// Used Filter
		if ($filter_used != -1) {
			$where[] = 'used ='.$filter_used;
		}
		
		// Locked Filter
		if ($filter_locked != -1) {
			$where[] = 'locked ='.$filter_locked;
		}
		
		// All fields Filter
		if ($filter_all != -1) {
			if ($filter_all == 1){
				$where[]= "metatitle = '' AND metadesc = '' AND metakey = ''";
			} elseif ($filter_all == 2){
				$where[]= "metatitle != '' AND metadesc != '' AND metakey != ''";
			}
		}
		
		// Title Filter
		if ($filter_title != -1) {
			if ($filter_title == 1){
				$where[]= "metatitle = ''";
			} elseif ($filter_title == 2){
				$where[]= "metatitle != ''";
			}
		}
		
		// Description Filter
		if ($filter_desc != -1) {
			if ($filter_desc == 1){
				$where[]= "metadesc = ''";
			} elseif ($filter_desc == 2){
				$where[]= "metadesc != ''";
			}
		}
		
		// Keywords Filter
		if ($filter_key != -1) {
			if ($filter_key == 1){
				$where[]= "metakey = ''";
			} elseif ($filter_key == 2){
				$where[]= "metakey != ''";
			}
		}
		
		// Not 404 URLs
		$where[] = "url_real != ''";
		
		// Execute
		$where = (count($where) ? ' WHERE '. implode(' AND ', $where) : '');
		return $where;
	}
	
	// Orderby Filter
	function _buildViewOrderBy() {
		global $mainframe, $option;

		$filter_order		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_order',		'filter_order',		'url_sef',	'cmd');
		$filter_order_Dir	= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_order_Dir',	'filter_order_Dir',	'ASC',		'word');

		if ($filter_order == 'a.used'){
			$orderby = ' ORDER BY category, used '.$filter_order_Dir;
		} else {
			$orderby = ' ORDER BY '.$filter_order.' '.$filter_order_Dir ;
		}
		return $orderby;
	}
}
?>