<?php
/*
* @package		AceSEF
* @subpackage	Wrapper
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_wrapper extends AceSEFTools {
	
	function beforeBuildRoute(&$uri) {
        if(is_null($uri->getVar('view'))){
            $uri->setVar('view', 'wrapper');
		}
    }

	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();
		
		return $title;
	}
	
	function metaTags(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		
		$separator			= $this->params->get('separator', '-');
		$desc_length		= $this->params->get('desc_length', '250');
		$keywords_word		= $this->params->get('keywords_word', '3');
		$keywords_count		= $this->params->get('keywords_count', '15');
		$blacklist			= $this->params->get('blacklist', '');
		
		$acesef_title = $acesef_desc = $acesef_key = "";
		
		$acesef_title = AceSEFTools::getMenuTitle($option, $Itemid);
		
		$meta = AceSEFTools::setMetaData($acesef_title, $acesef_desc, $acesef_key);
		
		return $meta;
	}
}
?>