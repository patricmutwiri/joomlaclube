<?php
/*
* @package		AceSEF
* @subpackage	User
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_user extends AceSEFTools {
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();
		
		if (isset($activation) || isset($return)) {
			$title[] = 'dosef_false';
			return $title;
		}

		if (isset($view)) {
			$title[] = $view;
		}
		
		if (isset($task)) {
			$title[] = $task;
		}

		return $title;
	}
}
?>