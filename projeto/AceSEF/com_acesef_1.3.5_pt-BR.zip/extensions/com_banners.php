<?php
/*
* @package		AceSEF
* @subpackage	Contact
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_banners extends AceSEFTools {
	
	function getBannerTitle($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', bid' : '';
		
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT name, alias$joomfish FROM #__banner WHERE bid =".$id);
        $rows = $database->loadRow();

		$name = (($this->params->get('bannerid_inc', '1') != '1') ? $id.'-' : '');
		if($this->params->get('banner_part', 'title') == 'title'){
			$name .= $rows[0];
		} else {
			$name .= $rows[1];
		}
			
		return $name;
    }
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();

		if(isset($task)) {
            switch($task) {
				case 'click':
                    if(isset($bid)){
                        $title[] = $this->getBannerTitle($bid);
					}
                    break;
            }
        }

		return $title;
	}
}
?>