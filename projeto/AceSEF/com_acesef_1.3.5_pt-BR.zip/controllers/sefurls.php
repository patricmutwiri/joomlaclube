<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Controller Class
class AcesefControllerSefurls extends AcesefController {
	
	// Main constructer
	function __construct() 	{
		parent::__construct();
		$this->registerTask('add', 'edit');
		$this->registerTask('unlock', 'lock');
		$this->registerTask('unblock', 'block');
		$this->registerTask('unpublish', 'publish');
		$this->registerTask('unused', 'used'); 
	}

	// Display URLs
	function view() {
		$model =& $this->getModel('sefurls');
		$view = $this->getView('sefurls','html');
		$view->setModel($model, true);
		$view->view();
	}
	
	// Edit URL
	function edit() {
		$this->addModelPath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models');
		$model = $this->getModel('editurl', 'AcesefModel');

		$this->addViewPath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl');
		$view = $this->getView('editurl', 'html', 'AcesefView');
		$view->setModel($model, true);
		
        JRequest::setVar( 'hidemainmenu', 1 );
		$view->edit();
	}
	
	// Delete URLs
	function delete() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');

		$model = $this->getModel('sefurls');
		foreach ($cid as $id) {
			$model->delete($id);
		}
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=sefurls&task=view');
	}
	
	// Publish URLs
	function publish() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('sefurls');
		foreach ($cid as $id) {
			$model->publish($id);
		}
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=sefurls&task=view');
	}
	
	// Use URL
	function used() {
		// active the selected URL as the primary SEF link
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');

		if (count($cid) == 0) {
			// Return
			$this->setRedirect('index.php?option=com_acesef&controller=sefurls&task=view');
			return;
		}

		//$id = $cid[0];
		$model = $this->getModel('sefurls');
		foreach ($cid as $id) {
			$model->used($id);
		}
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=sefurls&task=view');
	}
	
	// Lock URLs from deleting
	function lock() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('sefurls');
		foreach ($cid as $id) {
			$model->lock($id);
		}
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=sefurls&task=view');
	}
	
	// Block URL from rewriting
	function block() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('sefurls');
		foreach ($cid as $id) {
			$model->block($id);
		}
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=sefurls&task=view');
	}
	
	// Delete filtered URLs
	function deleteFiltered() {
        $model = $this->getModel('sefurls');
        
		if(!$model->deleteFiltered()) {
			$msg = JText::_('ACESEF_URL_SEF_CONFIRM_DELETE_FILTERED');
		} else {
			$msg = JText::_('ACESEF_URL_SEF_MESSAGE_DELETE_FILTERED_SUCCESS');
		}
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=sefurls&task=view', $msg);
    }
    
	// Export Selected URLs
    function exportSelected() {
        $model =& $this->getModel('sefurls');
        $where = $model->whereIds();
        
		if(!$model->export($where)){
			$msg = JText::_('ACESEF_URL_SEF_MESSAGE_URLS_NOT_EXPORTED');
		} else {
			$msg = JText::_('ACESEF_URL_SEF_MESSAGE_URLS_EXPORTED');
		}
		// Return
		$this->setRedirect('index.php?option=com_acesef&controller=sefurls&task=view', $msg);
    }
    
	// Export Filtered URLs
    function exportFiltered() {
        $model =& $this->getModel('sefurls');
        $where = $model->_buildViewWhere();
        
		if(!$model->export($where)){
			$msg = JText::_('ACESEF_URL_SEF_MESSAGE_URLS_NOT_EXPORTED');
		} else {
			$msg = JText::_('ACESEF_URL_SEF_MESSAGE_URLS_EXPORTED');
		}
		// Return
		$this->setRedirect( 'index.php?option=com_acesef&controller=sefurls&task=view', $msg );
    }
}
?>