<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Controller Class
class AcesefControllerEditurl extends AcesefController {
	
	// Main constructer
	function __construct() {
		parent::__construct();
	}

	// Edit URL
	function edit() {
		JRequest::setVar('hidemainmenu', 1);
		$model = $this->getModel('editurl');
		$view = $this->getView('editurl', 'html');
		$view->setModel($model, true);

		$view->edit();
	}
	
	// Save changes
	function save() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('editurl');
		if (!$model->save($id)) {
		 	return JError::raiseWarning(500, JTEXT::_('ACESEF_URL_EDIT_NOT_SAVED'));
		}
		// Return to repository
		$this->setRedirect('index.php?option=com_acesef&controller=sefurls&task=view', JTEXT::_('ACESEF_URL_EDIT_SAVED'));
	}
	
	// Apply changes
	function apply() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('editurl');
		if (!$model->save($id)) {
		 	return JError::raiseWarning(500, JTEXT::_('ACESEF_URL_EDIT_NOT_SAVED'));
		}
		// Return to edit url page
		$this->setRedirect('index.php?option=com_acesef&controller=editurl&task=edit&cid[]='.$id, JTEXT::_('ACESEF_URL_EDIT_SAVED'));
	}
	
	// Cancel changes
	function cancel() {
		// Return to repository
		$this->setRedirect('index.php?option=com_acesef&controller=sefurls&task=view', JTEXT::_('ACESEF_URL_EDIT_NOT_SAVED'));
	}
	
	// Save & Moved
	function savemoved() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('editurl');
		if (!$model->savemoved($id)) {
		 	return JError::raiseWarning(500, JTEXT::_('ACESEF_URL_EDIT_NOT_SAVED'));
		}
		// Return to repository
		$this->setRedirect('index.php?option=com_acesef&controller=sefurls&task=view', JTEXT::_('ACESEF_URL_EDIT_SAVED_MOVED'));
	}
}
?>