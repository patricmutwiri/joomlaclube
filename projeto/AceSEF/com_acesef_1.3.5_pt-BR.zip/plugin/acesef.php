<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

// Include configuration file
require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');

class plgSystemAcesef extends JPlugin {

	function plgSystemAcesef(& $subject, $config) {
		parent::__construct($subject, $config);
		
		// Load configuration
		$this->acesef_config = new acesef_configuration();
	}
	
	function onPrepareContent(&$row, &$params, $page=0){
		global $mainframe;
		
		// Is backend
		if($mainframe->isAdmin()){
			return true;
		}

        // Joomla SEF is disabled
        $config =& JFactory::getConfig();
        if(!$config->getValue('sef')){
			return true;
		}

        // Check if AceSEF is enabled
        if($this->acesef_config->mode == 0){
			return true;
		}
		
		// Word Linker
		if(is_object($row) && $this->acesef_config->seo_il == 1) {
			$nofollow	= $this->acesef_config->seo_il_nofollow;
			$target		= $this->acesef_config->seo_il_target;
			$limit		= $this->acesef_config->seo_il_limit;
			$words		= $this->acesef_config->seo_il_words;
			
			$row->text	= $this->wordLinker($row->text, $nofollow, $target, $limit, $words);
		}
		
		// No follow
		if(JString::strpos($row->text, 'href="') === false) {
			return true;
		}
		
		if($this->acesef_config->seo_nofollow == 1) {
			$regex = '/<a (.*?)href=[\"\'](.*?)\/\/(.*?)[\"\'](.*?)>(.*?)<\/a>/i';
			$row->text = preg_replace_callback($regex, array(&$this, 'noFollow'), $row->text);
		}
		return true;
	}
	
	function onBeforeDisplayContent(& $article, & $params, $limitstart)	{
		global $mainframe;
		
		// Is backend
		if($mainframe->isAdmin()){
			return;
		}

        // Check if AceSEF is enabled
        if($this->acesef_config->mode == 0){
			return;
		}

        // Joomla SEF is disabled
        $config =& JFactory::getConfig();
        if(!$config->getValue('sef')){
			return;
		}
		
		// Set h1 tag
		if($this->acesef_config->seo_h1 == 1){
			$article->title = '{h1}'.$article->title.'{/h1}';
		}

		return;
	}

	// Assign the new router for the SEF URL rewritting
	function onAfterInitialise() {
		global $mainframe;
		
		// // Is backend
        if($mainframe->isAdmin()){
			return true;
		}

        // Joomla SEF is disabled
        $config =& JFactory::getConfig();
        if(!$config->getValue('sef')){
			return true;
		}

		// Check if AceSEF is enabled		
		if($this->acesef_config->mode == 1) {
			// Store the router for later use
			$router =& $mainframe->getRouter();
            $mainframe->set('acesef.global.jrouter', $router);
			
			// Activate AceSEF router
			require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'mainrouter.php');
			$router = new JRouterAcesef();
		}
		
		// SSL and non-www settings
		$uri  =& JURI::getInstance();
		$host =& $uri->getHost();
		
		$redirect = false;
		
		// non-www
		if($this->acesef_config->redirect_to_www == 1 && strpos($host, 'www') === false) {
			$redirect = true;
			$uri->setHost('www.'.$host);
		}
		
		// SSL
		if($this->acesef_config->force_ssl == 1 && !$uri->isSSL()) {
			$redirect = true;
			$uri->setScheme('https');
		}
		
		if($redirect) {
			$url = $uri->toString();
			header('Location: '. $url, true, 301);
			$app = & JFactory::getApplication();
			$app->close();
		}
		
		return true;
	}
	
	function onAfterRoute() {
        global $mainframe;

        // Administration area
        if($mainframe->isAdmin()){
			return true;
		}

        // Joomla SEF is disabled
        $config =& JFactory::getConfig();
        if(!$config->getValue('sef')){
			return true;
		}

        // Check if AceSEF is enabled
        if($this->acesef_config->mode == 0){
			return true;
		}

        return true;
    }

    function onAfterDispatch() {
        global $mainframe;
		
		$document =& JFactory::getDocument();

        // Administration area
        if($mainframe->isAdmin()){
			return true;
		}
		
		// Joomla SEF is disabled
		$config = &JFactory::getConfig();
        if(!$config->getValue('sef')){
			return true;
		}

        // Check if AceSEF is enabled
        if($this->acesef_config->mode == 0){
			return true;
		}
		
        if(!class_exists('RouterTools') || RouterTools::is($this) == ''){
			return true;
		}
		
		// Get data from mainframe
		$url_id 		= $mainframe->get('acesef.url.id');
		$auto_desc 		= AceSEFTools::replaceSpecialChars($mainframe->get('acesef.meta.autodesc'), true);
		$auto_key 		= AceSEFTools::replaceSpecialChars($mainframe->get('acesef.meta.autokey'), true);
		$meta_title  	= AceSEFTools::replaceSpecialChars($mainframe->get('acesef.meta.title'), true);
		$meta_desc   	= AceSEFTools::replaceSpecialChars($mainframe->get('acesef.meta.desc'), true);
		$meta_key    	= AceSEFTools::replaceSpecialChars($mainframe->get('acesef.meta.key'), true);
		$meta_lang   	= AceSEFTools::replaceSpecialChars($mainframe->get('acesef.meta.lang'), true);
		$meta_robots	= AceSEFTools::replaceSpecialChars($mainframe->get('acesef.meta.robots'), true);
		$meta_google	= AceSEFTools::replaceSpecialChars($mainframe->get('acesef.meta.google'), true);
		$link_canonical	= AceSEFTools::replaceSpecialChars($mainframe->get('acesef.link.canonical'), true);
		$generator  	= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_generator, true);
		$abstract  		= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_abstract, true);
		$revisit  		= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_revisit, true);
		$direction 		= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_direction, true);
		$google_key  	= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_googlekey, true);
		$live_key  		= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_livekey, true);
		$yahoo_key  	= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_yahookey, true);
		$alexa_key  	= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_alexa, true);
		$name_1  		= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_name_1, true);
		$name_2  		= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_name_2, true);
		$name_3  		= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_name_3, true);
		$con_1  		= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_con_1, true);
		$con_2  		= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_con_2, true);
		$con_3  		= AceSEFTools::replaceSpecialChars($this->acesef_config->meta_con_3, true);
		
		//
		//
		//
		// Set Meta Tags
		//
		//
		//
	
		// Get original title, desc and keys
		$org_title = $document->getTitle();
		$org_desc = $document->getDescription();
		$org_key = $document->getMetaData('keywords');
		
		// Title
		$title = AceSEFTools::pluginMetaTitle($url_id, $org_title, $meta_title);
		if(!empty($title)){
			$document->setTitle($title);
			$document->setMetaData('title', str_replace('"', '', $title));
		}
		
		// Description
		$desc = AceSEFTools::pluginMetaDesc($url_id, $org_desc, $meta_desc, $auto_desc);
		if(!empty($desc)){
			$document->setDescription($desc);
		}
		
		// Keywords
		$key = AceSEFTools::pluginMetaKey($url_id, $org_key, $meta_key, $auto_key);
		if(!empty($key)){
			$document->setMetaData('keywords', $key);
		}
		
		// Others
		if(!empty($meta_robots))	$document->setMetaData('robots', $meta_robots);
		if(!empty($meta_lang))		$document->setMetaData('language', $meta_lang);
		if(!empty($meta_google))	$document->setMetaData('googlebot', $meta_google);
		if(!empty($link_canonical)) $document->addHeadLink($link_canonical, 'canonical');
		if(!empty($generator)) 		$document->setGenerator($generator);
		if(!empty($abstract)) 		$document->setMetaData('abstract', $abstract);
		if(!empty($revisit)) 		$document->setMetaData('revisit', $revisit);
		if(!empty($direction)) 		$document->setDirection($direction);
		if(!empty($google_key))		$document->setMetaData('google-site-verification', $google_key);
		if(!empty($live_key))		$document->setMetaData('msvalidate.01', $live_key);
		if(!empty($yahoo_key))		$document->setMetaData('y_key', $yahoo_key);
		if(!empty($alexa_key))		$document->setMetaData('alexaverifyid', $alexa_key);
		if(!empty($name_1))			$document->setMetaData($name_1, $con_1);
		if(!empty($name_2))			$document->setMetaData($name_2, $con_2);
		if(!empty($name_3))			$document->setMetaData($name_3, $con_3);
		
		// Set base href
    	if($this->acesef_config->base_href == 2) {
        	$document->setBase(JURI::current());
        } elseif($this->acesef_config->base_href == 3) {
        	$document->setBase(JURI::base());
        } elseif($this->acesef_config->base_href == 4) {
        	$document->setBase('');
        }
		
        return true;
    }
    
    // H1 tag
	function onAfterRender(){
		global $mainframe;

		$document	=& JFactory::getDocument();
		$docType	= $document->getType();

		// Return if page is not html
		if($docType != 'html') return true;

		// Return if we are on the administrator area
		if($mainframe->isAdmin()) return true;
		
		// h1 tag
		if($this->acesef_config->seo_h1 == 1) {
			// Get body contents
			$body = JResponse::getBody();
			
			// Replace {h1} and {/h1} placeholders by the corresponding
			$body = str_replace('{h1}', '<h1>', $body);
			$body = str_replace('{/h1}', '</h1>', $body);
	
			// Set new body contents
			JResponse::setBody($body);
		}

		return;
	}
	
	// No follow
	function noFollow($match){
		$local	=& JFactory::getURI();
	
		if($this->getDomainFromLink($match[3]) != $local->getHost() && !$this->alreadyNofollow($match[1]) && !$this->alreadyNofollow($match[4])){
			return '<a href="' . $match[2] . '//' . $match[3] . '"' . $match[1] . $match[4] . ' rel="nofollow" >' . $match[5] . '</a>';
		} else {
			return '<a href="' . $match[2] . '//' . $match[3] . '"' . $match[1] . $match[4] . '>' . $match[5] . '</a>';
		}
	}
	
	function getDomainFromLink($url){
		preg_match("/^(http:\/\/)?([^\/]+)/i", $url, $match);
		$domain = $match[2];
		preg_match("/[^\.\/]+\.[^\.\/]+$/", $domain, $match);
		return $match[0];
	}
	
	
	function alreadyNofollow($text){
		return (preg_match("/rel=[\"\'].*?nofollow.*?[\"\']/i", $text )) ? true : false ;
	}
	
	function wordLinker(&$text, $nofollow, $target, $limit, $words) {
		if($nofollow == 1)
			$nofollow = 'rel="nofollow"';
		else
			$nofollow = "";
		
		
		if($target == 0)
			$target = 'target="_parent"';
		else
			$target = 'target="_blank"';
		
		$keys = explode(", ", $words);
		
		foreach ($keys as $key)	{
			$pat='/([\w\W]*?)\|([\w\W]*)/';
			if(preg_match_all($pat, $key, $matches, PREG_SET_ORDER)) {
				foreach ($matches as $match) {
					$keyword = $match[1];
					$link = $match[2];
					$replace = '<a href="'.$link.'" '.$target.' title="'.$keyword.'" '.$nofollow.'>'.$keyword.'</a>';
					
					$case = "i";
					$regEx = '\'(?!((<.*?)|(<a.*?)))(\b'.$keyword.'\b)(?!(([^<>]*?)>)|([^>]*?</a>))\'s'.$case;				 
					$text = preg_replace($regEx, $replace, $text, $limit);	
				}
			}
		}
		return $text;
	}
}
?>