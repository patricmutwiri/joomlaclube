<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

?>
<script language="javascript" type="text/javascript">
<!--
	function getExt(option, file) {
	    var form = document.adminForm;
	    
	    form.task.value = 'view_upgrade';
	    form.acesefext.value = option;
	    form.aceseffile.value = file;
		form.submit();
	}
//-->
</script>

<form enctype="multipart/form-data" action="index.php" method="post" name="adminForm_pck">
	<fieldset class="adminform">
	<legend><?php echo JText::_('ACESEF_EXTENSIONS_VIEW_INSTALL'); ?></legend>
	<table class="adminform">
		<tbody>
			<tr>
				<td width="120">
					<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
				</td>
				<td>
					<input class="input_box" type="file" size="57" id="install_package" name="install_package" />
					<input class="button" type="submit" onclick="submitbutton()" value="<?php echo JText::_('ACESEF_EXTENSIONS_VIEW_INSTALL_UPLOAD'); ?>" />
				</td>
			</tr>
		</tbody>
	</table>
	</fieldset>
	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="extensions" />
	<input type="hidden" name="task" value="view_install" />
	<input type="hidden" name="type" value="" />
</form>

<br />

<form action="index.php" method="post" name="adminForm">
	<table>
	<tr>
		<td nowrap="nowrap">
				<?php echo JText::_('ACESEF_EXTENSIONS_VIEW_COMPONENT').'<br />'.$this->lists['search_name']; ?>
		</td>
		<td nowrap="nowrap">
			<?php echo JText::_('ACESEF_EXTENSIONS_VIEW_VERSION').'<br />'.$this->lists['search_ver']; ?>
		</td>
		<td nowrap="nowrap">
			<?php echo JText::_('ACESEF_EXTENSIONS_VIEW_AUTHOR').'<br />'.$this->lists['search_auth']; ?>
		</td>
	</tr>
	</table>
	<div id="editcell">
		<table class="adminlist">
		<thead>
			<tr>
				<th width="%1">
					<?php echo JText::_('ACESEF_COMMON_NUM'); ?>
				</th>
				<th width="%1">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
				</th>
				<th width="13%" class="title">
					<?php echo  JTEXT::_('ACESEF_EXTENSIONS_VIEW_COMPONENT'); ?>
				</th>
				<th width="5%" class="title">
					<?php echo JTEXT::_('ACESEF_EXTENSIONS_VIEW_VERSION'); ?>
				</th>
				<th width="5%" class="title">
					<?php echo JTEXT::_('ACESEF_CPANEL_LATEST_VERSION'); ?>
				</th>
				<th width="7%" class="title">
					<?php echo JTEXT::_('ACESEF_EXTENSIONS_VIEW_LICENSE'); ?>
				</th>
				<th width="10%" class="title">
					<?php echo JTEXT::_('ACESEF_EXTENSIONS_VIEW_STATUS'); ?>
				</th>
				<th width="10%" class="title">
					<?php echo JTEXT::_('ACESEF_EXTENSIONS_VIEW_ROUTER'); ?>
				</th>
				<th width="15%" class="title">
					<?php echo JTEXT::_('ACESEF_EXTENSIONS_VIEW_PREFIX'); ?>
				</th>
				<th width="12%" class="title">
					<?php echo JTEXT::_('ACESEF_EXTENSIONS_VIEW_SKIP'); ?>
				</th>
				<th width="10%" class="title">
					<?php echo JTEXT::_('ACESEF_EXTENSIONS_VIEW_AUTHOR'); ?>
				</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="12">
					<?php echo $this->pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
		<tbody>
		<?php
		$k = 0;
		for ($i=0, $n=count($this->items); $i < $n; $i++) {
			$row	= &$this->items[$i];
			$info	= &$this->info[$row->extension];
			
			// Version checker is disabled
			if(is_null($info)) {
				$info->version = '';
				$info->license = 'disabled';
				
			}
				
			$checked = JHTML::_('grid.checkedout', $row, $i);

			?>
			<tr class="<?php echo "row$k"; ?>">
				<td>
					<?php echo $this->pagination->getRowOffset($i); ?>
				</td>
				<td>
					<?php echo $checked; ?>
				</td>
				<td>
					<?php
						// Component Name
						if(!empty($row->name)){
							$link = JRoute::_('index.php?option=com_acesef&controller=extensions&task=edit&cid[]='.$row->id);
							$component = '<a href="'.$link.'" title="'.JText::_('Edit').'">'.$row->name.'</a>';
						} else
							$component = $row->extension;
					
						echo $component;
					?>
				</td>
				<td align="center">
					<?php 
						// Version
						if(!empty($row->version)){
							$version = $row->version;
						} else
							$version = '-';
							
						echo $version; 
					?>
				</td>
				<td align="center">
					<?php							
						if(empty($info->version)) {
							$ver = '-';
							echo $ver;
						} else {
							$ver = $info->version;
							$compared = version_compare($row->version, $ver);
							if ($compared == 0)
								echo '<strong><font color="green">'.$ver.'</font></strong>';
							elseif($compared == -1)
								echo '<a href="http://www.joomace.net" target="_blank"><b><font color="red">'.$ver.'</font></b></a>';
							else
								echo '<a href="http://www.joomace.net" target="_blank"><b><font color="orange">'.$ver.'</font></b></a>';
						}
					?>
				</td>
				<td align="center">
					<?php 
						if($info->license == 'disabled') {
							echo '-';
						} elseif(!empty($info->license)) {
							echo $info->license;
						} else {
							echo "Commercial";
						}
					?>
				</td>
				<td align="center">
					<?php
						// Status						
						$ext = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.$row->extension.'.php';
						// Extension found, check if it should be an upgrade or not
						if(file_exists($ext)){
							if(empty($info->version)) {
								echo '-';
							} else {
								$ver = $info->version;
								$compared = version_compare($row->version, $ver);
								if($compared == 0){ // Up-to-date
									echo JText::_('ACESEF_EXTENSIONS_VIEW_STATUS_1');
								} elseif($compared == -1){ // Upgrade needed
									$download_id = $info->params->get('download_id', '');
									if($info->license == 'Free') {
										$file = $info->d."fi"."le"."s/".$info->f."/ex"."t_a"."ce"."se"."f_".substr($info->component, 4)."-fr"."ee.z"."ip";
										$func = "getExt('".$info->component."', '".$file."');";
									} elseif(isset($download_id)) {
										if(strlen($download_id) == 32){
											$file = $info->d.$info->c.$info->params->get('download_id', '');
											$func = "getExt('".$info->component."', '".$file."');";
										}
									} else {
										$func = 'window.open(\''.$info->link.'\');';
									}
									?>
									<input type="button" class="button hasTip" value="<?php echo JText::_('ACESEF_EXTENSIONS_VIEW_STATUS_2'); ?>" onclick="<?php echo $func; ?>" />
									<?php
								}
							}
						} elseif(!empty($info->version)) {
							echo '<input type="button" class="button hasTip" value="'.JText::_('ACESEF_EXTENSIONS_VIEW_STATUS_3').'" onclick="window.open(\''.$info->link.'\');" title="'.JText::_('ACESEF_EXTENSIONS_VIEW_STATUS_GET').'" />';
						} else {
							echo '<input type="button" class="button hasTip" value="'.JText::_('ACESEF_EXTENSIONS_VIEW_STATUS_4').'" onclick="window.open(\'http://www.joomace.net/e-shop/joomla-services/new-extension\');" title="'.JText::_('ACESEF_EXTENSIONS_VIEW_STATUS_GET').'" />';
						}
					?>
				</td>
				<td align="center">
					<?php echo $row->rewrite_rule; ?>
					<input type="hidden" name="id[<?php echo $row->id; ?>]" value="<?php echo $row->id; ?>">
				</td>
				<td align="center">
					<input type="text" name="component_prefix[<?php echo $row->id; ?>]" size="25" value="<?php echo $row->component_prefix; ?>" />
				</td>
				<td align="center">
					<?php echo $row->skip_title; ?>
				</td>
				<td align="center">
					<?php 
						// Author
						if(!empty($row->author)){
							$author = '<a href="http://'.$row->author_url.'" target= "_blank">'.$row->author.'</a>';
						} else
							$author = '-';
				
						echo $author; 
					?>
				</td>
			</tr>
			<?php
			$k = 1 - $k;
		}
		?>
		</tbody>
		</table>
	</div>

	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="extensions" />
	<input type="hidden" name="task" value="view" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="acesefext" value="" />
	<input type="hidden" name="aceseffile" value="" />
</form>