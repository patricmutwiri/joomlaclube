<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');
?>
<form action="index.php" method="post" name="adminForm">
<div id="editcell">
<table class="adminform">
    <tr>
		<td width="430">
			<a href="http://www.joomace.net/documentation/acesef" target="_blank">
			<img border="0" src="http://www.joomace.net/s-documantation.png" width="400" height="200">
			</a>
		</td>
		<td align="left">
			<a href="http://www.joomace.net/support-forums" target="_blank">
			<img border="0" src="http://www.joomace.net/s-forum.png" width="400" height="200">
			</a>
		</td>
	</tr>
	<tr>
		<td width="430">&nbsp;</td>
		<td align="left">&nbsp;</td>
	</tr>
	<tr>
		<td width="430">
			<a href="http://www.joomace.net/e-shop/acesef" target="_blank">
			<img border="0" src="http://www.joomace.net/s-proversion.png" width="400" height="200">
			</a>
		</td>
		<td align="left">
			<a href="http://www.joomace.net/e-shop/joomla-services" target="_blank">
			<img border="0" src="http://www.joomace.net/s-customwork.png" width="400" height="200">
			</a>
		</td>
	</tr>
</table>
</div>

<input type="hidden" name="option" value="com_acesef" />
<input type="hidden" name="task" value="support" />
<input type="hidden" name="controller" value="support" />
</form>