<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');
?>

<script language="javascript" type="text/javascript">
<!--
	function submitimport(pressbutton) {
		var form = document.importAcesef;

		form.task.value = 'import';
		form.submit();
	}

	function submitimportmoved(pressbutton) {
		var form = document.importMoved;
	
		form.task.value = 'importmoved';
		form.submit();
	}
	
	function submitimportmeta(pressbutton) {
		var form = document.importMeta;
	
		form.task.value = 'importmeta';
		form.submit();
	}
	
	function submitimportsitemap(pressbutton) {
		var form = document.importSitemap;
	
		form.task.value = 'importsitemap';
		form.submit();
	}
	
	function submitimportjoomsef(pressbutton) {
		var form = document.importJoomsef;

		form.task.value = 'importjoomsef';
		form.submit();
	}
	
	function submitimportsh404sef(pressbutton) {
		var form = document.importSh404sef;

		form.task.value = 'importsh404sef';
		form.submit();
	}
	
	function submitimportsh404sefmeta(pressbutton) {
		var form = document.importSh404sefMeta;

		form.task.value = 'importsh404sefmeta';
		form.submit();
	}
//-->
</script>
<table class="noshow">
			<tr>
				<td width="50%">
						<form enctype="multipart/form-data" action="index.php" method="post" name="importAcesef">
							<fieldset class="adminform">
								<legend><?php echo JText::_('ACESEF_IMPORT_ACESEF'); ?></legend>
								<table class="adminform">
								<tr>
									<td width="120">
										<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
									</td>
									<td>
										<input class="input_box" id="importurls" name="importurls" type="file" size="40" />
										<input class="button" type="button" value="<?php echo JText::_('ACESEF_IMPORT_BUTTON'); ?>" onclick="submitimport()" />
									</td>
								</tr>
								</table>
							</fieldset>

							<input type="hidden" name="option" value="com_acesef" />
							<input type="hidden" name="controller" value="import" />
							<input type="hidden" name="task" value="view" />
						</form>
						
						<form enctype="multipart/form-data" action="index.php" method="post" name="importMeta">
							<fieldset class="adminform">
								<legend><?php echo JText::_('ACESEF_IMPORT_ACESEF_META'); ?></legend>
								<table class="adminform">
								<tr>
									<td width="120">
										<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
									</td>
									<td>
										<input class="input_box" id="importmeta" name="importmeta" type="file" size="40" />
										<input class="button" type="button" value="<?php echo JText::_('ACESEF_IMPORT_BUTTON'); ?>" onclick="submitimportmeta()" />
									</td>
								</tr>
								</table>
							</fieldset>

							<input type="hidden" name="option" value="com_acesef" />
							<input type="hidden" name="controller" value="import" />
							<input type="hidden" name="task" value="view" />
						</form>
						
						<form enctype="multipart/form-data" action="index.php" method="post" name="importSitemap">
							<fieldset class="adminform">
								<legend><?php echo JText::_('ACESEF_IMPORT_ACESEF_SITEMAP'); ?></legend>
								<table class="adminform">
								<tr>
									<td width="120">
										<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
									</td>
									<td>
										<input class="input_box" id="importsitemap" name="importsitemap" type="file" size="40" />
										<input class="button" type="button" value="<?php echo JText::_('ACESEF_IMPORT_BUTTON'); ?>" onclick="submitimportsitemap()" />
									</td>
								</tr>
								</table>
							</fieldset>

							<input type="hidden" name="option" value="com_acesef" />
							<input type="hidden" name="controller" value="import" />
							<input type="hidden" name="task" value="view" />
						</form>
						
						<form enctype="multipart/form-data" action="index.php" method="post" name="importMoved">
							<fieldset class="adminform">
								<legend><?php echo JText::_('ACESEF_IMPORT_ACESEF_MOVED'); ?></legend>
								<table class="adminform">
								<tr>
									<td width="120">
										<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
									</td>
									<td>
										<input class="input_box" id="importmoved" name="importmoved" type="file" size="40" />
										<input class="button" type="button" value="<?php echo JText::_('ACESEF_IMPORT_BUTTON'); ?>" onclick="submitimportmoved()" />
									</td>
								</tr>
								</table>
							</fieldset>

							<input type="hidden" name="option" value="com_acesef" />
							<input type="hidden" name="controller" value="import" />
							<input type="hidden" name="task" value="view" />
						</form>
					</td>
					<td width="50%">
						<form enctype="multipart/form-data" action="index.php" method="post" name="importJoomsef">
							<fieldset class="adminform">
								<legend><?php echo JText::_('ACESEF_IMPORT_JOOMSEF'); ?></legend>
								<table class="adminform">
								<tr>
									<td width="120">
										<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
									</td>
									<td>
										<input class="input_box" id="importjoomsef" name="importjoomsef" type="file" size="40" />
										<input class="button" type="button" value="<?php echo JText::_('ACESEF_IMPORT_BUTTON'); ?>" onclick="submitimportjoomsef()" />
									</td>
								</tr>
								</table>
							</fieldset>

							<input type="hidden" name="option" value="com_acesef" />
							<input type="hidden" name="controller" value="import" />
							<input type="hidden" name="task" value="view" />
						</form>
						
						<form enctype="multipart/form-data" action="index.php" method="post" name="importSh404sef">
							<fieldset class="adminform">
								<legend><?php echo JText::_('ACESEF_IMPORT_SH404SEF'); ?></legend>
								<table class="adminform">
								<tr>
									<td width="120">
										<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
									</td>
									<td>
										<input class="input_box" id="importsh404sef" name="importsh404sef" type="file" size="40" />
										<input class="button" type="button" value="<?php echo JText::_('ACESEF_IMPORT_BUTTON'); ?>" onclick="submitimportsh404sef()" />
									</td>
								</tr>
								</table>
							</fieldset>

							<input type="hidden" name="option" value="com_acesef" />
							<input type="hidden" name="controller" value="import" />
							<input type="hidden" name="task" value="view" />
						</form>

						<form enctype="multipart/form-data" action="index.php" method="post" name="importSh404sefMeta">
							<fieldset class="adminform">
								<legend><?php echo JText::_('ACESEF_IMPORT_SH404SEF_META'); ?></legend>
								<table class="adminform">
								<tr>
									<td width="120">
										<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
									</td>
									<td>
										<input class="input_box" id="importsh404sefmeta" name="importsh404sefmeta" type="file" size="40" />
										<input class="button" type="button" value="<?php echo JText::_('ACESEF_IMPORT_BUTTON'); ?>" onclick="submitimportsh404sefmeta()" />
									</td>
								</tr>
								</table>
							</fieldset>

							<input type="hidden" name="option" value="com_acesef" />
							<input type="hidden" name="controller" value="import" />
							<input type="hidden" name="task" value="view" />
						</form>
					</td>
				</tr>
			</table>