<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

// Import JPane
jimport('joomla.html.pane');
?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_URL_MOVED_EDIT_LEGEND'); ?></legend>
		<table class="admintable">
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_MOVED_OLD'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="url_old" id="url_old" size="100" value="<?php echo $this->row->url_old; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_MOVED_NEW'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="url_new" id="url_new" size="100" value="<?php echo $this->row->url_new; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_MOVED_PUBLISHED'); ?>
					</label>
				</td>
				<td width="80%">
					<?php echo $this->lists['published']; ?>
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_MOVED_HITS'); ?>
					</label>
				</td>
				<td width="80%">
					<input type="text" name="hits" id="hits" class="inputbox" size="7" value="<?php echo $this->row->hits; ?>" />
				</td>
			</tr>
		</table>
	</fieldset>
	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="editurlmoved" />
	<input type="hidden" name="task" value="edit" />
	<input type="hidden" name="id" value="<?php echo $this->row->id; ?>" />
</form>