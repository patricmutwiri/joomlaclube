<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Imports
jimport( 'joomla.application.component.view');
include_once(JPATH_ROOT.DS.'libraries'.DS.'joomla'.DS.'html'.DS.'html'.DS.'select.php');

// View Class
class AcesefViewConfig extends JView {

	// Edit configuration
	function edit($tpl = null) {
		$db =& JFactory::getDBO();
		
		// Import CSS
  		$document =& JFactory::getDocument();
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set Toolbar
		JToolBarHelper::title(JText::_('ACESEF_CONFIG_TITLE'), 'acesef');
		JToolBarHelper::custom('save', 'save1.png', 'save1.png', JText::_('Save'), false);
		JToolBarHelper::custom('apply', 'approve.png', 'approve.png', JText::_('Apply'), false);
		JToolBarHelper::custom('cancel', 'cancel1.png', 'cancel1.png', JText::_('Cancel'), false);
		JToolBarHelper::divider();
		$bar =& JToolBar::getInstance();
		$bar->appendButton('Confirm', JText::_('ACESEF_CONFIG_WARNING_SAVE'), 'save1', JText::_('ACESEF_CONFIG_SAVE_PURGE'), 'savepurge', false, false);
		$bar->appendButton('Confirm', JText::_('ACESEF_CONFIG_WARNING_SAVE'), 'approve', JText::_('ACESEF_CONFIG_APPLY_PURGE'), 'applypurge', false, false);

		
		// Create the select lists
  		JHTML::_('behavior.mootools');
		JHTML::_('behavior.tooltip');
		
		// Yes-No options list
		include_once(JPATH_ROOT.DS.'libraries'.DS.'joomla'.DS.'html'.DS.'html'.DS.'select.php');
		
		// Main
		$lists['mode'] 						= JHTMLSelect::booleanlist('mode',							null,	$this->acesef_config->mode);
		$lists['url_lowercase'] 			= JHTMLSelect::booleanlist('url_lowercase',					null,	$this->acesef_config->url_lowercase);
		$lists['numeral_duplicated'] 		= JHTMLSelect::booleanlist('numeral_duplicated',			null,	$this->acesef_config->numeral_duplicated);
		$lists['version_checker'] 			= JHTMLSelect::booleanlist('version_checker',				null,	$this->acesef_config->version_checker);
		$lists['parent_menus'] 				= JHTMLSelect::booleanlist('parent_menus',					null,	$this->acesef_config->parent_menus);
		// JoomFish
		$lists['joomfish_lang_code'] 		= JHTMLSelect::booleanlist('joomfish_lang_code',			null,	$this->acesef_config->joomfish_lang_code);
		$lists['joomfish_trans_url'] 		= JHTMLSelect::booleanlist('joomfish_trans_url',			null,	$this->acesef_config->joomfish_trans_url);
		$lists['joomfish_cookie_lang'] 		= JHTMLSelect::booleanlist('joomfish_cookie_lang',			null,	$this->acesef_config->joomfish_cookie_lang);
		// Advanced
		$lists['append_itemid'] 			= JHTMLSelect::booleanlist('append_itemid',					null,	$this->acesef_config->append_itemid);
		$lists['remove_trailing_slash'] 	= JHTMLSelect::booleanlist('remove_trailing_slash',			null,	$this->acesef_config->remove_trailing_slash);
		$lists['tolerant_to_trailing_slash']= JHTMLSelect::booleanlist('tolerant_to_trailing_slash',	null,	$this->acesef_config->tolerant_to_trailing_slash);
		$lists['redirect_to_www'] 			= JHTMLSelect::booleanlist('redirect_to_www',				null,	$this->acesef_config->redirect_to_www);
		// Very Advanced
		$lists['source_tracker'] 			= JHTMLSelect::booleanlist('source_tracker',				null,	$this->acesef_config->source_tracker);
		$lists['insert_active_itemid'] 		= JHTMLSelect::booleanlist('insert_active_itemid',			null,	$this->acesef_config->insert_active_itemid);
		$lists['redirect_to_sef'] 			= JHTMLSelect::booleanlist('redirect_to_sef',				null,	$this->acesef_config->redirect_to_sef);
		$lists['record_duplicated'] 		= JHTMLSelect::booleanlist('record_duplicated',				null,	$this->acesef_config->record_duplicated);
		$lists['remove_sid'] 				= JHTMLSelect::booleanlist('remove_sid',					null,	$this->acesef_config->remove_sid);
		$lists['set_query_string'] 			= JHTMLSelect::booleanlist('set_query_string',				null,	$this->acesef_config->set_query_string);
		$lists['force_ssl'] 				= JHTMLSelect::booleanlist('force_ssl',						null,	$this->acesef_config->force_ssl);
		$lists['utf8_url'] 					= JHTMLSelect::booleanlist('utf8_url',						null,	$this->acesef_config->utf8_url);
		$lists['append_non_sef'] 			= JHTMLSelect::booleanlist('append_non_sef',				null,	$this->acesef_config->append_non_sef);
		$lists['db_404_errors'] 			= JHTMLSelect::booleanlist('db_404_errors',					null,	$this->acesef_config->db_404_errors);
		$lists['log_404_errors'] 			= JHTMLSelect::booleanlist('log_404_errors',				null,	$this->acesef_config->log_404_errors);
		// Meta Tags
		$lists['meta_title'] 				= JHTMLSelect::booleanlist('meta_title',					null,	$this->acesef_config->meta_title);
		// SEO
		$lists['seo_h1'] 					= JHTMLSelect::booleanlist('seo_h1',						null,	$this->acesef_config->seo_h1);
		$lists['seo_nofollow'] 				= JHTMLSelect::booleanlist('seo_nofollow',					null,	$this->acesef_config->seo_nofollow);
		$lists['seo_il'] 					= JHTMLSelect::booleanlist('seo_il',						null,	$this->acesef_config->seo_il);
		$lists['seo_il_nofollow'] 			= JHTMLSelect::booleanlist('seo_il_nofollow',				null,	$this->acesef_config->seo_il_nofollow);
		$lists['seo_il_target'] 			= JHTMLSelect::booleanlist('seo_il_target',					null,	$this->acesef_config->seo_il_target);
		// Sitemap
		$lists['sm_indexed'] 				= JHTMLSelect::booleanlist('sm_indexed',					null,	$this->acesef_config->sm_indexed);
		$lists['sm_ping'] 					= JHTMLSelect::booleanlist('sm_ping',						null,	$this->acesef_config->sm_ping);
		
		$url_part = array();
  		$url_part[] = JHTMLSelect::Option('alias', JText::_('ACESEF_CONFIG_MAIN_ALIAS_FIELD'));
		$url_part[] = JHTMLSelect::Option('title', JText::_('ACESEF_CONFIG_MAIN_TITLE_FIELD'));
		
		// Title / Alias
		$lists['title_alias'] = JHTMLSelect::genericlist($url_part, 'title_alias', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->title_alias);
		
		// Menu URL part
		$lists['menu_url_part'] = JHTMLSelect::genericlist($url_part, 'menu_url_part', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->menu_url_part);
			
		// JoomFish languages list
		$joomfish_main_lang = array();
		$joomfish_main_lang[] = JHTMLSelect::Option('0', JText::_('ACESEF_CONFIG_JOOMFISH_MAINLANG_NONE'));
		
		// Check if languages table exists
		$tables	= $db->getTableList();
		$prefix	= $db->getPrefix();
		$langs	= $prefix."languages";
		if (in_array($langs, $tables)){
			// Get installed languages and add them to list
			$db->setQuery("SELECT `id`, `shortcode`, `name` FROM `#__languages` WHERE `active` = '1' ORDER BY `ordering`");
			$langs = $db->loadObjectList();
			if( @count(@$langs) ) {	
				foreach($langs as $lang) {
					$l = new stdClass();
					$l->code = $lang->shortcode;
					$l->name = $lang->name;
					
					// Load languages
					$joomfish_main_lang[] = JHTMLSelect::Option($l->code, $l->name);
				}
			}
		}
		$lists['joomfish_main_lang'] = JHTMLSelect::genericlist($joomfish_main_lang, 'joomfish_main_lang', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->joomfish_main_lang);
		
		// Determine Joom!Fish language
		$joomfish_determine_lang = array();
  		$joomfish_determine_lang[] = JHTMLSelect::Option('1', JText::_('ACESEF_CONFIG_JOOMFISH_DETERMINE_BROWSER'));
		$joomfish_determine_lang[] = JHTMLSelect::Option('2', JText::_('ACESEF_CONFIG_JOOMFISH_DETERMINE_ORDER'));
		$joomfish_determine_lang[] = JHTMLSelect::Option('3', JText::_('ACESEF_CONFIG_JOOMFISH_DETERMINE_SITELANG'));
		$lists['joomfish_determine_lang'] = JHTMLSelect::genericlist($joomfish_determine_lang, 'joomfish_determine_lang', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->joomfish_determine_lang);
		
		// Meta Tags list
		$meta = array();
  		$meta[] = JHTMLSelect::Option('1', JText::_('ACESEF_CONFIG_METATAGS_TDK_ALWAYS'));
		$meta[] = JHTMLSelect::Option('2', JText::_('ACESEF_CONFIG_METATAGS_TDK_NEVER'));
		$meta[] = JHTMLSelect::Option('3', JText::_('ACESEF_CONFIG_METATAGS_TDK_EMPTY'));
		
		// Meta Description
		$lists['meta_desc'] = JHTMLSelect::genericlist($meta, 'meta_desc', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->meta_desc);
		
		// Meta Keywords
		$lists['meta_key'] = JHTMLSelect::genericlist($meta, 'meta_key', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->meta_key);
		
		// Use sitename
		$sitename = array();
  		$sitename[] = JHTMLSelect::Option('1', JText::_('ACESEF_CONFIG_METATAGS_T_USE_SITENAME_1'));
		$sitename[] = JHTMLSelect::Option('2', JText::_('ACESEF_CONFIG_METATAGS_T_USE_SITENAME_2'));
		$sitename[] = JHTMLSelect::Option('3', JText::_('ACESEF_CONFIG_METATAGS_T_USE_SITENAME_3'));
		
		// USe sitename
		$lists['meta_t_usesitename'] = JHTMLSelect::genericlist($sitename, 'meta_t_usesitename', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->meta_t_usesitename);
		
		// 404 Page
		$page404 = array();
  		$page404[] = JHTMLSelect::Option('home', JText::_('ACESEF_CONFIG_404_HOME'));
		$page404[] = JHTMLSelect::Option('custom', JText::_('ACESEF_CONFIG_404_CUSTOM'));
		$lists['page404'] = JHTMLSelect::genericlist($page404, 'page404', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->page404);
		
		// Custom 404 Page
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT `id`, `introtext` FROM `#__content` WHERE `title` = '404'");
        $row = $db->loadObject();
		$lists['custom404'] = isset($row->introtext) ? $row->introtext : JText::_('<h1>404: Not Found</h1><h4>Sorry, but the content you requested could not be found</h4>');
		
		// Base href value
		$base_href = array();
  		$base_href[] = JHTMLSelect::Option('1', JText::_('ACESEF_CONFIG_ADVANCED_BASEHREF_ORG'));
		$base_href[] = JHTMLSelect::Option('2', JText::_('ACESEF_CONFIG_ADVANCED_BASEHREF_URL'));
		$base_href[] = JHTMLSelect::Option('3', JText::_('ACESEF_CONFIG_ADVANCED_BASEHREF_HOME'));
		$base_href[] = JHTMLSelect::Option('4', JText::_('ACESEF_CONFIG_ADVANCED_BASEHREF_DISABLE'));
		$lists['base_href'] = JHTMLSelect::genericlist($base_href, 'base_href', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->base_href);
		
		// Sitemap Change Frequency
		$sm_freq = array();
		$sm_freq[] = JHTMLSelect::Option('always', JText::_('ACESEF_SITEMAP_SELECT_ALWAYS'));
		$sm_freq[] = JHTMLSelect::Option('hourly', JText::_('ACESEF_SITEMAP_SELECT_HOURLY'));
		$sm_freq[] = JHTMLSelect::Option('daily', JText::_('ACESEF_SITEMAP_SELECT_DAILY'));
		$sm_freq[] = JHTMLSelect::Option('weekly', JText::_('ACESEF_SITEMAP_SELECT_WEEKLY'));
		$sm_freq[] = JHTMLSelect::Option('monthly', JText::_('ACESEF_SITEMAP_SELECT_MONTHLY'));
		$sm_freq[] = JHTMLSelect::Option('yearly', JText::_('ACESEF_SITEMAP_SELECT_YEARLY'));
		$sm_freq[] = JHTMLSelect::Option('never', JText::_('ACESEF_SITEMAP_SELECT_NEVER'));
		$lists['sm_freq'] = JHTMLSelect::genericlist($sm_freq, 'sm_freq', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->sm_freq);
		
		// Sitemap Priority
		$sm_priority = array();
		$sm_priority[] = JHTMLSelect::Option('0.0', '0.0');
		$sm_priority[] = JHTMLSelect::Option('0.1', '0.1');
		$sm_priority[] = JHTMLSelect::Option('0.2', '0.2');
		$sm_priority[] = JHTMLSelect::Option('0.3', '0.3');
		$sm_priority[] = JHTMLSelect::Option('0.4', '0.4');
		$sm_priority[] = JHTMLSelect::Option('0.5', '0.5');
		$sm_priority[] = JHTMLSelect::Option('0.6', '0.6');
		$sm_priority[] = JHTMLSelect::Option('0.7', '0.7');
		$sm_priority[] = JHTMLSelect::Option('0.8', '0.8');
		$sm_priority[] = JHTMLSelect::Option('0.9', '0.9');
		$sm_priority[] = JHTMLSelect::Option('1.0', '1.0');
		$lists['sm_priority'] = JHTMLSelect::genericlist($sm_priority, 'sm_priority', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->sm_priority);
		
		// Check if the 404_logfile is empty
		if ( $this->acesef_config->log_404_path == "") {
			$this->acesef_config->log_404_path = JPATH_ROOT.DS.'logs'.DS.'acesef_404.log';
		}
		
		$this->assignRef('lists', $lists);
		parent::display($tpl) ;
	}
}
?>