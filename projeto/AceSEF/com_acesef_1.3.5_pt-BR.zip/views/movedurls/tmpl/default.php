<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

?>
<form action="index.php" method="post" name="adminForm" id="adminForm">
	<table>
		<tr>
			<td nowrap="nowrap">
				<?php echo JText::_('ACESEF_URL_MOVED_NEW').'<br />'.$this->lists['search_new']; ?>
			</td>
			<td nowrap="nowrap">
				<?php echo JText::_('ACESEF_URL_MOVED_OLD').'<br />'.$this->lists['search_old']; ?>
			</td>
			<td align="left" width="100%">
				&nbsp;
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['published_list']; ?>
			</td>
		</tr>
	</table>
	<div id="editcell">
		<table class="adminlist">
		<thead>
			<tr>
				<th width="1%">
					<?php echo JText::_('ACESEF_COMMON_NUM'); ?>
				</th>
				<th width="1%">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
				</th>
				<th width="30%" class="title">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_URL_MOVED_NEW'), 'url_new', $this->lists['order_dir'], $this->lists['order']); ?>
				</th>
				<th width="20%" class="title">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_URL_MOVED_OLD'), 'url_old', $this->lists['order_dir'], $this->lists['order']); ?>
				</th>
				<th width="3%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_URL_MOVED_PUBLISHED'), 'published', $this->lists['order_dir'], $this->lists['order']); ?>
				</th>
				<th width="3%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_URL_MOVED_HITS'), 'hits', $this->lists['order_dir'], $this->lists['order']); ?>
				</th>
				<th width="3%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_URL_MOVED_LAST_HIT'), 'latest_hit', $this->lists['order_dir'], $this->lists['order']); ?>
				</th>
				<th width="1%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', 'ID', 'id', $this->lists['order_dir'], $this->lists['order']); ?>
				</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="8">
					<?php echo $this->pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
		<tbody>
		<?php
		$k = 0;
		for ($i=0, $n=count($this->items); $i < $n; $i++) {
			$row = &$this->items[$i];

			$link 		= JRoute::_('index.php?option=com_acesef&controller=editurlmoved&task=edit&cid[]='.$row->id);
			$checked = JHTML::_('grid.id', $i, $row->id);
			
			// Published icon
			$img_published		= $row->published ? '../components/com_acesef/assets/images/icon-16-published-on.png' : '../components/com_acesef/assets/images/icon-16-published-off.png';
			$task_published		= $row->published ? 'unpublish' : 'publish';
			$alt_published		= $row->published ? JText::_('ACESEF_URL_SEF_TOOLTIP_PUBLISH_NOT') : JText::_('ACESEF_URL_SEF_TOOLTIP_PUBLISH');
			$action_published	= $row->published ? JText::_('ACESEF_URL_SEF_TOOLTIP_PUBLISH_NOT') : JText::_('ACESEF_URL_SEF_TOOLTIP_PUBLISH');
			
			$href_published = '
			<a href="javascript:void(0);" onclick="return listItemTask(\'cb'.$i.'\',\''.$task_published.'\')" title="'.$action_published.'">
			<img src="images/'.$img_published.'" border="0" alt="'.$alt_published.'" />
			</a>';
			
			if (preg_match("/^(https?|ftps?|itpc|telnet|gopher):\/\//i", $row->url_new)) {
				$preview_link = $row->url_new;
			} else {
				$preview_link = '../'.$row->url_new;
			}
			
			$edit_link = JRoute::_('index.php?option=com_acesef&controller=movedurls&task=edit&cid[]='.$row->id);
			
			?>
			<tr class="<?php echo "row$k"; ?>">
				<td>
					<?php echo $this->pagination->getRowOffset($i); ?>
				</td>
				<td>
					<?php echo $checked; ?>
				</td>
				<td>
					<a href="<?php echo $preview_link; ?>" title="<?php echo JText::_('ACESEF_URL_SEF_TOOLTIP_SEF_URL'); ?>" target="_blank">
					<?php echo substr($row->url_new, 0, 173); ?></a>
				</td>
				<td>
					<a href="<?php echo $edit_link; ?>"><?php echo htmlentities(substr($row->url_old, 0, 173)); ?></a>
				</td>
				<td align="center">
					<?php echo $href_published;?>
				</td>
				<td align="center">
					<?php echo $row->hits;?>
				</td>
				<td align="center">
					<?php echo (substr($row->last_hit, 0, 10) == '0000-00-00' ? JText::_('Never') : $row->last_hit); ?>
				</td>
				<td align="center">
					<?php echo $row->id;?>
				</td>
			</tr>
			<?php
			$k = 1 - $k;
		}
		?>
		</tbody>
		</table>
	</div>

	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="movedurls" />
	<input type="hidden" name="task" value="view" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_dir']; ?>" />
</form>