<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('JPATH_BASE') or die('Restricted Access');

class Tableacesef_urls_moved extends JTable {
	var $id 	 		= null;
	var $url_old 		= null;
	var $url_new 		= null;
	var $published		= null;
	var $hits			= null;
	var $last_hit		= null;

	function Tableacesef_urls_moved (&$db) {
		parent::__construct('#__acesef_urls_moved', 'id', $db);
	}
}