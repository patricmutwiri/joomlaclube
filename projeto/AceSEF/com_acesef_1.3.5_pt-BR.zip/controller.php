<?php
/**
* @version		1.2.2
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');
class AcesefController extends JController {
	function display() {
		parent::display();
	}
}