<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined( '_JEXEC' ) or die( 'Restricted access' );

class AceversionsControllerCategories extends AceversionsController {

	function __construct(){
		parent::__construct();	
		$this->registerTask('add', 'edit');
	}
	
	function view(){
		JRequest::setVar('view','categories');
		parent::display();
	}
	
	function edit(){
		JRequest::setVar('view', 'addcategory');
		JRequest::setVar('hidemainmenu', 1);
		parent::display();
	}
	
	function publish() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		
		$model = $this->getModel('categories');
		foreach ($cid as $id) {
			$model->publish($id);
		}
		
		// Return
		$this->setRedirect('index.php?option=com_aceversions&controller=categories&task=view');
	}
	
	function unpublish() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		
		$model = $this->getModel('categories');
		foreach ($cid as $id) {
			$model->unpublish($id);
		}
		
		// Return
		$this->setRedirect('index.php?option=com_aceversions&controller=categories&task=view');
	}
	
	function remove() {
		$model = $this->getModel('categories');
		if(!$model->delete()) {
			$msg = JText::_( 'Hata: Bir veya Daha fazla kategori silinemedi' );
		} else {
			$msg = JText::_( 'Kategori(ler) silindi' );
		}
		
		$this->setRedirect( 'index.php?option=com_aceversions&controller=categories&task=view', $msg );
	}
}