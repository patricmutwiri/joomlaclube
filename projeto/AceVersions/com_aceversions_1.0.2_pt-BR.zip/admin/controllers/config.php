<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted Access');

// Controller Class
class AceversionsControllerConfig extends AceversionsController {
	
	// Main constructer
 	function __construct() {
		parent::__construct();
	}
	
	// Edit Configuration
	function edit() {
		$model = $this->getModel('config');
		$view = $this->getView('config', 'html');
		$model->_set_configuration();

		$view->assignRef('AceversionsConfig', $model->_configuration);
		$view->display();
	}
	
	// Save changes
	function save() {
		$model = $this->getModel('config');
		if ($model->_save_configuration()){
			$this->setRedirect('index.php?option=com_aceversions', JTEXT::_('ACEVER_CONFIG_SAVED'));
		} else {
			$this->setRedirect('index.php?option=com_aceversions', JTEXT::_('ACEVER_CONFIG_ERROR'));
		}
	}
	
	// Apply changes
	function apply() {
		$model = $this->getModel('config');
		if ($model->_save_configuration()){
			$this->setRedirect('index.php?option=com_aceversions&controller=config&task=edit', JTEXT::_('ACEVER_CONFIG_SAVED'));
		} else {
			$this->setRedirect('index.php?option=com_aceversions&controller=config&task=edit', JTEXT::_('ACEVER_CONFIG_ERROR'));
		}
	}
	
	// Cancel saving changes
	function cancel() {
		$this->setRedirect('index.php?option=com_aceversions', JTEXT::_('ACEVER_CONFIG_NOT_SAVED'));
	}
}
?>