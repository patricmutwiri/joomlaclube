<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined( '_JEXEC' ) or die( 'Restricted access' );

class AceversionsControllerExtensions extends AceversionsController {

	function __construct() {
		parent::__construct();
		$this->registerTask('add', 'edit');
	}	 
	
	function display(){
		parent::display();
	}	
	
	function view() {
		$model =& $this->getModel('extensions');
		$view = $this->getView('extensions', 'html');	
		$view->setModel($model, true);	
		$view->display();		
	}
	
	function edit() {
		JRequest::setVar('view','addextension');
        JRequest::setVar( 'hidemainmenu', 1 );
		parent::display();
	}
	
	function publish() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		
		$model = $this->getModel('extensions');
		foreach ($cid as $id) {
			$model->publish($id);
		}
		
		// Return
		$this->setRedirect('index.php?option=com_aceversions&controller=extensions&task=view');
	}
	
	function unpublish() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		
		$model = $this->getModel('extensions');
		foreach ($cid as $id) {
			$model->unpublish($id);
		}
		
		// Return
		$this->setRedirect('index.php?option=com_aceversions&controller=extensions&task=view');
	}
	
	function remove() {
		$model = $this->getModel('extensions');
		if(!$model->delete()) {
			$msg = JText::_( 'Error: Component or components could not deleted' );
		} else {
			$msg = JText::_( 'Component(s) deleted' );
		}
		
		$this->setRedirect( 'index.php?option=com_aceversions&controller=extensions&task=view', $msg );
	}
}