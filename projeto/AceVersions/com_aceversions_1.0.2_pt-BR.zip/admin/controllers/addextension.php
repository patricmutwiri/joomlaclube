<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined( '_JEXEC' ) or die( 'Restricted access' );

class AceversionsControllerAddextension extends AceversionsController {

	function __construct(){
		parent::__construct();		
	}
	
	function save(){
		JRequest::checkToken() or jexit('Invalid Token');
		
		$model = $this->getModel('AddExtension');
		
		if (!$model->save()) {
			$msg = JText::_('ACEVER_SAVE_NOT_EXT');
		} else {
			$msg = JText::_('ACEVER_SAVE_EXT');
		}
		
		$this->setRedirect('index.php?option=com_aceversions&controller=extensions&task=view', $msg);
	}
	
	function apply(){
		JRequest::checkToken() or jexit('Invalid Token');
		
		$model = $this->getModel('AddExtension');
		
		if (!$model->save()) {
			$msg = JText::_('ACEVER_SAVE_NOT_EXT');
		} else {
			$msg = JText::_('ACEVER_SAVE_EXT');
		}
		
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$this->setRedirect('index.php?option=com_aceversions&controller=extensions&task=edit&cid[]='.$id, $msg);
	}
	
	function cancel(){
		$this->setRedirect("index.php?option=com_aceversions&controller=extensions&task=view");
	}
}