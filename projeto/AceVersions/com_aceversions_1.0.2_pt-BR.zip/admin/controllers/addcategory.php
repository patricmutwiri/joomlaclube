<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined( '_JEXEC' ) or die( 'Restricted access' );

class AceversionsControllerAddcategory extends AceversionsController {
	
	function __construct(){
		parent::__construct();	
	}
	
	function save(){
		JRequest::checkToken() or jexit('Invalid Token');
		
		$model = $this->getModel('AddCategory');
		
		if (!$model->save()) {
			$msg = JText::_('ACEVER_SAVE_NOT_CAT');
		} else {
			$msg = JText::_('ACEVER_SAVE_CAT');
		}
		
		$this->setRedirect('index.php?option=com_aceversions&controller=categories&task=view', $msg);
	}
	
	function cancel(){
		$this->setRedirect("index.php?option=com_aceversions&controller=categories&task=view");
	}
}