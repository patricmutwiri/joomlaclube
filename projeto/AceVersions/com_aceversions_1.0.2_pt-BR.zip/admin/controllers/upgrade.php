<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted Access');

// Controller Class
class AceversionsControllerUpgrade extends AceversionsController {

	// Main constructer
    function __construct() {
        parent::__construct();
    }
	
	// Import page
    function display() {
        JRequest::setVar('view', 'upgrade');
        JRequest::setVar('layout' , 'default');

        parent::display();
    }
	
	// Upgrade
    function upgrade() {
        $model = $this->getModel('upgrade');
        
		// Upgrade
		if(!$model->upgrade()){
			$msg = JText::_('ACEVER_UPGRADE_UNSUCCESS');
		} else {
			$msg = JText::_('ACEVER_UPGRADE_SUCCESS');
		}
		
		// Return
		$this->setRedirect('index.php?option=com_aceversions&controller=upgrade&task=view', $msg);
    }
}
?>