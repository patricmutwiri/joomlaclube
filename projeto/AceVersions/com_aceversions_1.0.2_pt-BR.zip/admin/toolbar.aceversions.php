<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

$controller	= JRequest::getCmd('controller', 'aceversions');

JHTML::_('behavior.switcher');

// Load submenus
$views = array(''											=> JText::_('ACEVERSION_COMMON_HOME'),
				'&controller=config&task=edit'				=> JText::_('ACEVER_CPANEL_CONFIGURATION'),
				'&controller=extensions&task=view'			=> JText::_('ACEVER_CPANEL_EXTENSIONS'),
				'&controller=categories&task=view'			=> JText::_('ACEVER_CPANEL_CATEGORIES'),
				'&controller=upgrade&task=view'				=> JText::_('ACEVER_CPANEL_UPGRADE'),
				'&controller=aceversions&task=changelog'	=> JText::_('ACESEF_CPANEL_CHANGELOG')
				);	

foreach($views as $key => $val) {
	$active	= ($controller == $key);
	JSubMenuHelper::addEntry($val, 'index.php?option=com_aceversions'.$key, $active);
}
?>