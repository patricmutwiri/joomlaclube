<?php
class AceversionsConfig {
	var $version_checker = '1';
	var $status_xml = '0';
	var $download_xml = '0';
	var $changelog_xml = '0';
	var $date_xml = '1';
	var $comp_xml = '1';
	var $option_xml = '0';
	var $desc_xml = '0';
}
?>