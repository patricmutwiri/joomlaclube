<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class AceversionsViewExtensions extends JView{

	function display($tpl = null) {
		// Add CSS
		$document = & JFactory::getDocument();
		$document->addStyleSheet('components/com_aceversions/assets/css/aceversions.css');

		JToolBarHelper::title(JText::_('ACEVER_CPANEL_EXTENSIONS'), 'aceversions');
		JToolBarHelper::addNew();
		JToolBarHelper::editList();
		JToolBarHelper::deleteList();
		JToolBarHelper::divider();
		JToolBarHelper::publishList();
		JToolBarHelper::unpublishList();
		
		global $mainframe,$option;
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.extensions.filter_order',		'filter_order',		'name' ,'cmd');
		$filter_order_Dir	= $mainframe->getUserStateFromRequest($option.'.extensions.filter_order_Dir',	'filter_order_Dir',	'ASC'	,'word');
		$filter_category 	= $mainframe->getUserStateFromRequest($option.'.extensions.filter_category',  	'filter_category', 	'-1');
		$filter_comp		= $mainframe->getUserStateFromRequest($option.'.extensions.filter_comp',		'filter_comp',		'-1');
		$filter_status	 	= $mainframe->getUserStateFromRequest($option.'.extensions.filter_status',  	'filter_status', 	'-1');
		$search				= $mainframe->getUserStateFromRequest($option.'.extensions.search',			'search',			'');
		$search 			= JString::strtolower($search);
	
		$javascript 	= 'onchange="document.adminForm.submit();"';
		
		$rows = & $this->get('CategoryList');
		$category[] = JHTML::_('select.option', -1, JText::_('ACEVER_ADD_SCAT'));
		foreach(array_keys($rows) as $i){
			$row = &$rows[$i];
			$category[] = JHTML::_('select.option', $i, $row->name);
		}
		
		$comp[] = JHTML::_('select.option', -1, JText::_('ACEVER_ADD_SCAMP'));
		$comp[] = JHTML::_('select.option', 15, JText::_('Joomla! 1.5'));
		$comp[] = JHTML::_('select.option', 16, JText::_('Joomla! 1.6'));
		
		$status[] = JHTML::_('select.option', -1,JText::_('- Status -'));
		$status[] = JHTML::_('select.option', 0, JText::_('Alpha'));
		$status[] = JHTML::_('select.option', 1, JText::_('Beta'));
		$status[] = JHTML::_('select.option', 2, JText::_('RC'));
		$status[] = JHTML::_('select.option', 3, JText::_('Stable'));
		$status[] = JHTML::_('select.option', 4, JText::_('ACEVER_ADD_SCTS'));
	
		$lists['order']				= $filter_order;
		$lists['order_dir']			= $filter_order_Dir;
		$lists['category_list'] 	= JHTML::_('select.genericlist', $category, 'filter_category', 'class="inputbox" size="1 "'.$javascript, 'value', 'text', $filter_category);
		$lists['comp_list']			= JHTML::_('select.genericlist', $comp, 'filter_comp', 'class="inputbox" size="1 "'.$javascript, 'value', 'text', $filter_comp);
		$lists['status_list']		= JHTML::_('select.genericlist', $status, 'filter_status', 'class="inputbox" size="1 "'.$javascript, 'value', 'text', $filter_status);
		$lists['search'] 			= "<input type=\"text\" name=\"search\" value=\"{$search}\" size=\"30\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";
		
		$this->assignRef('lists',			$lists);
		$this->assignRef('items',			$this->get('Data'));
		$this->assignRef('pagination',		$this->get('Pagination'));
		$this->assignRef('cats',			$this->get('CategoryList'));
		$this->assignRef('compatibility',	$this->get('Compatibility'));
		
		parent::display($tpl);
	}
}