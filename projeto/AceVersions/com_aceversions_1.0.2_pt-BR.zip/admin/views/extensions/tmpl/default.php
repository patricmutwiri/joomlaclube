<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');
?>

<form action="index.php" method="post" name="adminForm">
	<table>
		<tr>
			<td align="left" width="100%">
				<?php echo JText::_( 'ACEVER_ADD_FILTER' ); ?>:
				<?php echo $this->lists['search'];?>
			</td>
			<td nowrap="nowrap">
				<?php?>
			</td>
			<td nowrap="nowrap">
				<?php echo $this->lists['category_list'];?>
			</td>
			<td nowrap="nowrap">
				<?php echo $this->lists['comp_list'];?>
			</td>
			<td nowrap="nowrap">
				<?php echo $this->lists['status_list'];?>
			</td>
		</tr>
	</table>
	<div id="editcell">
		<table class="adminlist" cellspacing="1">
			<thead>
				<tr>
					<th width="2%"><?php echo JText::_('#');?></th>
					<th width="2%">
						<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
					</th>
					<th class="title" width="10%">
					<?php echo JHTML::_('grid.sort', JText::_( 'ACEVER_ADD_NAME' ), 'name', $this->lists['order_dir'], $this->lists['order']); ?>
					</th>
					<th class="title" width="3%">
					<?php echo JHTML::_('grid.sort', JText::_( 'ACEVER_ADD_VERSION' ), 'version', $this->lists['order_dir'], $this->lists['order']); ?></th>
					<th class="title" width="7%">
					<?php echo JHTML::_('grid.sort', JText::_( 'ACEVER_ADD_CATEGORY' ), 'category', $this->lists['order_dir'], $this->lists['order']); ?></th>
					<th class="title" width="3%"><?php echo JText::_( 'ACEVER_ADD_DATE' ); ?></th>
					<th class="title" width="5%"><?php echo JText::_( 'ACEVER_ADD_COMP' ); ?></th>
					<th class="title" width="22%"><?php echo JText::_( 'ACEVER_ADD_DES' ); ?></th>
					<th class="title" width="4%">
					<?php echo JHTML::_('grid.sort', JText::_( 'ACEVER_ADD_OPTION' ), 'com_option', $this->lists['order_dir'], $this->lists['order']); ?></th>
					<th class="title" width="5%"><?php echo JText::_( 'ACEVER_ADD_PUBLISHED' ); ?></th>
					<th class="title" width="3%"><?php echo JText::_('id');?>
				</tr>
			</thead>
			
				<?php
				$k =0;
				for ($i = 0, $n=count($this->items); $i <  $n; $i ++)
				{
					$row = $this->items[$i];
					$category = " ";
					if($row->category){
					$category = $this->cats[$row->category]->name;
					}
					
					$comp = " ";
					if($row->compatibility!= -1){
						$comp = $this->compatibility[$row->compatibility];
					}
					
					$checked = JHTML::_('grid.id', $i ,$row->id);
					$link       = JRoute::_( 'index.php?option=com_aceversions&controller=extensions&task=edit&cid[]='. $row->id );
					$published 	= JHTML::_('grid.published', $row, $i );
					?>
					
						<tr class="<?php echo "row$k";?>">
							<td>
								<?php echo $this->pagination->getRowOffset($i); ?>
							</td>
							<td>
								<?php echo $checked;?>
							</td>
							
							<td>
								<a href="<?php echo $link;?>"><?php echo $row->name;?></a>
							</td>
							<td>
								<?php echo $row->version;?>
							</td>
							<td>
								<?php echo $category;?>
							</td>
							<td>
								<?php echo $row->vdate;?>
							</td>
							<td>
								<?php echo $comp;?>
							</td>
							<td>
								<?php echo $row->description;?>
							</td>
							<td>
								<?php echo $row->com_option;?>
							</td>
							<td align="center">
									<?php echo $published;?>
							</td>
							<td>
							<?php echo $row->id;?>
							</td>
						</tr>
					<?php
					$k = 1 - $k;
				}
				?>

			 <tfoot>
				<tr align="center">
					<td colspan="9" align="center"><?php echo $this->pagination->getListFooter(); ?></td>
				</tr>
			</tfoot>
		</table>
	</div>
<input type="hidden" name="option" value="com_aceversions" />
<input type="hidden" name="controller" value="extensions"/>
<input type="hidden" name="task" value="view" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_dir']; ?>" />
</form>
				