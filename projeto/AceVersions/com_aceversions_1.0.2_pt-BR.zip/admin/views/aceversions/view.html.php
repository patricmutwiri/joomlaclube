<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class AceversionsViewAceversions extends JView{

	function display($tpl = null){
		// Add CSS
		$document = & JFactory::getDocument();
		$document->addStyleSheet('components/com_aceversions/assets/css/aceversions.css');
		
		JToolBarHelper::title(JText::_('ACEVER_COMMON_PANEL'), 'aceversions');

		jimport('joomla.html.pane');
		$pane = & JPane::getInstance('sliders');
		
		// Assign vars to the template
		$this->assignRef('pane',	$pane);
		$this->assignRef('info', 	$this->get('Info'));
		$this->assignRef('stats',	$this->get('Stats'));
		parent::display($tpl);
	}
	
	function quickiconButton( $link, $image, $text, $modal = 0 ) {
	//initialise variables
		$lang = & JFactory::getLanguage();
		?>

		<div style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
		<div class="icon">
		<?php
		if ($modal == 1) {
			JHTML::_('behavior.modal');
		?>
			<a href="<?php echo $link.'&amp;tmpl=component'; ?>" style="cursor:pointer" class="modal" rel="{handler: 'iframe', size: {x: 650, y: 400}}">
		<?php
		} else {
		?>
			<a href="<?php echo $link; ?>">
		<?php
		}
			echo JHTML::_('image', 'administrator/components/com_aceversions/assets/images/'.$image, $text );
		?>
			<span><?php echo $text; ?></span>
		</a>
		</div>
		</div>
		<?php
	}
}