<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

?>

<script language="javascript" type="text/javascript">
<!--
	function upgrade() {	    
	    document.adminForm.task.value = 'upgrade';
		document.adminForm.submit();
	}
//-->
</script>

<form action="index.php" method="post" name="adminForm">
	<table cellspacing="0" cellpadding="0" border="0" width="100%">
		
		<tr>
			<td valign="top">
				<table class="adminlist">
					<tr>
						<td>
							<div id="cpanel" width="50%">
							<?php
							global $option;
							
							$link = 'index.php?option='.$option.'&amp;controller=config&amp;task=edit';
							AceversionsViewAceversions::quickiconButton($link, 'icon-48-configuration.png', JText::_('ACEVER_CPANEL_CONFIGURATION'));

							$link = 'index.php?option='.$option.'&controller=extensions&task=view';
							AceversionsViewAceversions::quickiconButton($link, 'icon-48-extensions.png', JText::_('ACEVER_CPANEL_EXTENSIONS'));
							
							$link = 'index.php?option='.$option.'&controller=categories&task=view';
							AceversionsViewAceversions::quickiconButton($link, 'icon-48-categories.png', JText::_('ACEVER_CPANEL_CATEGORIES'));
							
							$link = 'index.php?option='.$option.'&amp;controller=upgrade&amp;task=view';
							AceversionsViewAceversions::quickiconButton($link, 'icon-48-upgrade.png', JText::_('ACEVER_CPANEL_UPGRADE'));
							
							$link = 'http://www.joomace.net/support';
							AceversionsViewAceversions::quickiconButton($link, 'icon-48-support.png', JText::_('ACEVER_CPANEL_SUPPORT'));
							
							$link = 'index.php?option='.$option.'&amp;controller=aceversions&amp;task=changelog';
							AceversionsViewAceversions::quickiconButton($link, 'icon-48-changelog.png', JText::_('ACESEF_CPANEL_CHANGELOG'));
							
							?>
							</div>
						</td>
					</tr>
				</table>
			</td>
		
		<td valign="top" width="45%" style="padding: 7px 0 0 5px">
				<?php
				$title = JText::_('ACEVER_CPANEL_WELLCOME');
				echo $this->pane->startPane('stat-pane');
				echo $this->pane->startPanel($title, 'wellcome');
				?>
				<table class="adminlist">
					<tr>
						<td valign="top" width="50%" align="center">
							<table class="adminlist">
								<tr>
									<td width="%25">
										<?php
											if ($this->info['version_enabled'] == 0) {
												echo JHTML::_('image', 'administrator/templates/khepri/images/header/icon-48-info.png', null);
											} elseif ($this->info['version_status'] == 0) {
												echo JHTML::_('image', 'administrator/templates/khepri/images/header/icon-48-checkin.png', null);
											} elseif($this->info['version_status'] == -1) {
												echo JHTML::_('image', 'administrator/templates/khepri/images/header/icon-48-help_header.png', null);
											} else {
												echo JHTML::_('image', 'administrator/templates/khepri/images/header/icon-48-help_header.png', null);
											}
										?>
									</td>
									<td width="%35">
										<?php
											if ($this->info['version_enabled'] == 0) {
												echo '<b>'.JText::_('ACEVER_CPANEL_VERSION_CHECKER_DISABLED_1').'</b>';
											} elseif ($this->info['version_status'] == 0) {
												echo '<b><font color="green">'.JText::_('ACEVER_CPANEL_LATEST_VERSION_INSTALLED').'</font></b>';
											} elseif($this->info['version_status'] == -1) {
												echo '<b><font color="red">'.JText::_('ACEVER_CPANEL_OLD_VERSION').'</font></b>';
											} else {
												echo '<b><font color="orange">'.JText::_('ACEVER_CPANEL_NEWER_VERSION').'</font></b>';
											}
										?>
									</td>
									<td align="center" rowspan="5">
										<a href="http://www.joomace.net/joomla-extensions/acesef">
										<img src="components/com_aceversions/assets/images/logo.png" width="149" height="222" alt="AceVersions" title="AceVersions" align="middle" border="0">
										</a>
									</td>
								</tr>
								<tr>
									<td>
										<?php
											if($this->info['version_status'] == 0 || $this->info['version_enabled'] == 0) {
												echo JText::_('ACEVER_CPANEL_LATEST_VERSION');
											} elseif($this->info['version_status'] == -1) {
												echo '<b><font color="red">'.JText::_('ACEVER_CPANEL_LATEST_VERSION').'</font></b>';
											} else {
												echo '<b><font color="orange">'.JText::_('ACEVER_CPANEL_LATEST_VERSION').'</font></b>';
											}
										?>
									</td>
									<td>
										<?php
											if ($this->info['version_enabled'] == 0) {
												echo JText::_('ACEVER_CPANEL_VERSION_CHECKER_DISABLED_2');
											} elseif($this->info['version_status'] == 0) {
												echo $this->info['version_latest'];
											} elseif($this->info['version_status'] == -1) {
												// Version output in red
												echo '<b><font color="red">'.$this->info['version_latest'].'</font></b>&nbsp;&nbsp;&nbsp;&nbsp;';
												?>
												<input type="button" class="button hasTip" value="<?php echo JText::_('ACEVER_CPANEL_UPGRADE'); ?>" onclick="upgrade();" />
												<?php
											} else {
												echo '<b><font color="orange">'.$this->info['version_latest'].'</font></b>';
											}
										?>
									</td>
								</tr>
								<tr>
									<td>
										<?php echo JText::_('ACEVER_CPANEL_INSTALLED_VERSION'); ?>
									</td>
									<td>
										<?php 
											if ($this->info['version_enabled'] == 0) {
												echo JText::_('ACEVER_CPANEL_VERSION_CHECKER_DISABLED_2');
											} else {
												echo $this->info['version_installed'];
											}
										?>
									</td>
								</tr>
								<tr>
									<td>
										<?php echo JText::_('ACEVER_CPANEL_COPYRIGHT'); ?>
									</td>
									<td>
										<a href="http://www.joomace.net" target="_blank">&copy 2009-2010 JoomAce LLC</a>
									</td>
								</tr>
								<tr>
									<td>
										<?php echo JText::_('ACEVER_CPANEL_LICENSE'); ?>
									</td>
									<td>
										<a href="http://www.gnu.org/licenses/agpl-3.0.html" target="_blank">GNU AGPL v3</a>
									</td>
								</tr>
							</table>
						</td>		
					</tr>
				</table>
				
				
				<?php
				$title = JText::_('ACEVER_CPANEL_URLS_STATS');
				echo $this->pane->endPanel();
				echo $this->pane->startPanel($title, 'stats');
				?>
				<table class="adminlist">
					<tr>
						<td width="25%">
							<?php echo JText::_('ACEVER_CPANEL_EXTENTIONS_LINK'); ?>
						</td>
						<td width="75%">
							<b><?php echo $this->stats['extensions']; ?></b>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo JText::_('ACEVER_CPANEL_CATEGORIES_LINK'); ?>
						</td>
						<td>
							<b><?php echo $this->stats['categories']; ?></b>
						</td>
					</tr>
								
				</table>
				<?php
				$title = JText::_('ACEVER_CPANEL_DONATE');
				echo $this->pane->endPanel();
				echo $this->pane->startPanel($title, 'donate');
				?>
				<table class="adminlist">
					<tbody>
					<tr>
						<td width="60%">
							<?php echo JText::_('ACEVER_CPANEL_DONATE_TEXT'); ?>
						</td>
						<td>
							<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
							<input type="hidden" name="cmd" value="_s-xclick">
							<input type="hidden" name="hosted_button_id" value="8072927">
							<input type="image" src="https://www.paypal.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
							<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
							</form>
						</td>
					</tr>
					</tbody>
				</table>
				<?php
				echo $this->pane->endPanel();
				echo $this->pane->endPane();
				?>
			</td>
		</tr>
	</table>	
	<input type="hidden" name="option" value="com_aceversions" />
	<input type="hidden" name="controller" value="aceversions"/>
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
</form>