<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');
?>

<style type="text/css">
h2 { color: #A1B754; }
h1, h3, h4 { color: #666666; }
div.docs,div.docs p,div.docs ul li,div.docs ol li {
	text-align: left;
	font-weight: lighter;
	font-family: Tahoma, Arial, Verdana;
}
span.link { cursor: pointer; }
div.docs p { padding-left: 3em; font-weight: lighter; }
div.docs li p { padding-left: 0em; }
div.docs .small {
	color: #666666; font-size: 90%;
}
span.bold {
	font-weight: bold;
}
</style>

<div class="docs">
	<h1><a name="top"></a>AceVersions Changelog</h1>
	<h3>Legend</h3>
	<ul>
		<li># -> Bug Fix</li>
		<li>+ -> Addition</li>
		<li>^ -> Change</li>
		<li>-- -> Removed</li>
	</ul>
	<h3>1.0.2 &nbsp;&nbsp;&nbsp;<span class="small">27 July 2010</span></h3>
	<ul>
		<li>+ : Added single extension view page to category</li>
		<li># : Fixed several security issues (thanks to Jeff Channell)</li>
		<li># : Fixed some CSS issues</li>
	</ul>
	<h3>1.0.1 &nbsp;&nbsp;&nbsp;<span class="small">26 July 2010</span></h3>
	<ul>
		<li>+ : Added single extension view page</li>
	</ul>
	<h3>1.0.0 &nbsp;&nbsp;&nbsp;<span class="small">15 July 2010</span></h3>
	<ul>
		<li>First Release</li>
	</ul>
</div>