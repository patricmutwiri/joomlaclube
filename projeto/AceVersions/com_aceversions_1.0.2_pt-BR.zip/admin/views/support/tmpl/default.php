<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

?>

<form action="index.php" method="post" name="adminForm">
	<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td valign="top">
				&nbsp;
			</td>
		</tr>
	</table>
	<input type="hidden" name="option" value="com_aceversions" />
	<input type="hidden" name="controller" value="aceversions"/>
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
</form>