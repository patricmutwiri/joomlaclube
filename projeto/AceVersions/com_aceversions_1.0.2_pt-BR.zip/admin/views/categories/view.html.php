<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class AceversionsViewCategories extends JView{

	function display($tpl = null){
		// Add CSS
		$document = & JFactory::getDocument();
		$document->addStyleSheet('components/com_aceversions/assets/css/aceversions.css');
		
		JToolBarHelper::title(JText::_('ACEVER_CPANEL_CATEGORIES'), 'aceversions');
		JToolBarHelper::addNew();
		JToolBarHelper::editList();
		JToolBarHelper::deleteList();
		JToolBarHelper::divider();
		JToolBarHelper::publishList();
		JToolBarHelper::unpublishList();
		
		global $mainframe,$option;
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.categories.filter_order',		'filter_order',		'name' ,'cmd');
		$filter_order_Dir	= $mainframe->getUserStateFromRequest($option.'.categories.filter_order_Dir',	'filter_order_Dir',	'ASC'	,'word');
		
		$lists['order']				= $filter_order;
		$lists['order_dir']			= $filter_order_Dir;
		
		$this->assignRef('lists'		,$lists);
		$this->assignRef('pagination'	,$this->get('Pagination'));
		$this->assignRef('items'		,$this->get('Data'));
		parent::display($tpl);
	}
}