<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class AceversionsViewAddcategory extends JView{

	function display($tpl = null) {
		// Add CSS
		$document = & JFactory::getDocument();
		$document->addStyleSheet('components/com_aceversions/assets/css/aceversions.css');
		
		JToolBarHelper::title(JText::_('ACEVER_CPANEL_CATEGORIES'), 'aceversions');
		JToolBarHelper::save();
		JToolBarHelper::cancel();
		
		$items 		=& $this->get('Data');
		$published  = JHTML::_('select.booleanlist', 'published', null ,$items->published);
		
		$this->assignRef('items',$items);
		$this->assignRef('published', $published);
		
		parent::display($tpl);		
	}
}