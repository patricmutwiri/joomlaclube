<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<script language="Javascript">
	function submitbutton(pressbutton){
		var form = document.adminForm;
		if (pressbutton == 'cancel') {
			submitform(pressbutton);
			return;
		}
		
		// Check name field
		if (form.name.value != '') {
			submitform(pressbutton);
		} else {
			alert("<?php echo JText::_('Please, enter category name'); ?>");
		}
	}
</script>
	
<form action="index.php" method="post" name="adminForm" id="adminForm">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'ACEVER_ADD_ADDCAT' ); ?>:</legend>
			<table class="admintable">
				<tr>
					<td class="key">
						<label for="catid">
							<?php echo JText::_( 'ACEVER_ADD_NAME' ); ?>:
						</label>
					</td>
					<td>
						<input class="text_area" type="text" name="name" id="name" value="<?php echo $this->items->name;?>"/>
					</td>
				</tr>
				<tr>
					<td class="key">
						<label for="description">
							<?php echo JText::_( 'ACEVER_ADD_DES' ); ?>:
						</label>
					</td>
					<td>
						<textarea  class="inputbox" name="description" id="description"   rows="5" cols="40" ><?php echo $this->items->description;?></textarea>
					</td>
				</tr>
				<tr>
					<td class="key">
						<label for="catid">
							<?php echo JText::_( 'ACEVER_ADD_PUBLISHED' ); ?>:
						</label>
					</td>
					<td>
						<?php echo $this->published;?>
					</td>
				</tr>
			</table>
		<legend>
	</fieldset>
	
	<input type="hidden" name="option" value="<?php echo $option;?>" />
	<input type="hidden" name="id" value="<?php echo $this->items->id; ?>" />
	<input type="hidden" name="task" value="edit" />
	<input type="hidden" name="controller" value="addcategory"/>
	<?php echo JHTML::_( 'form.token' ); ?>
</form>