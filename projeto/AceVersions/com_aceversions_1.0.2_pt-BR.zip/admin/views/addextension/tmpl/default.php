<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined( '_JEXEC' ) or die( 'Restricted access' );
JHTML::_('behavior.calendar');
?>

<script language="Javascript">
	function submitbutton(pressbutton){
		var form = document.adminForm;
		if (pressbutton == 'cancel') {
			submitform(pressbutton);
			return;
		}
		
		// Check category field
		if (form.category.value == '-1') {
			alert("<?php echo JText::_('Please, select a category'); ?>");
			return;
		}
		
		// Check name field
		if (form.name.value == '') {
			alert("<?php echo JText::_('Please, enter extension name'); ?>");
			return;
		}
		
		// Check version field
		if (form.version.value == '') {
			alert("<?php echo JText::_('Please, enter version number'); ?>");
			return;
		}
		
		submitform(pressbutton);
	}
</script>
	
<form action="index.php" method="post" name="adminForm" id="adminForm">
	<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td valign="top" width="50%">
				<fieldset class="adminform">
					<legend><?php echo JText::_( 'ACEVER_ADD_MANDATORY' ); ?></legend>
						<table class="admintable">
							
							<tr>
								<td class="key">
									<label for="catid">
										<?php echo JText::_( 'ACEVER_ADD_NAME' ); ?>:
									</label>
								</td>
								<td>
									<input class="text_area" type="text" name="name" id="name" value="<?php echo $this->items->name;?>"/>
								</td>
							</tr>
							
							<tr>
								<td class="key">
									<label for="catid">
										<?php echo JText::_( 'ACEVER_ADD_VERSION' ); ?>:
									</label>
								</td>
								<td>
									<input class="text_area" type="text" name="version"  id="version" value="<?php echo $this->items->version;?>"/>
								</td>
							</tr>
							<tr>
								<td class="key">
									<label for="catid">
										<?php echo JText::_( 'ACEVER_ADD_CATEGORY' ); ?>:
									</label>
								</td>
								<td>
									<?php echo $this->list['category_list'];?>
								</td>
							</tr>
							<tr>
								<td class="key">
									<label for="catid">
										<?php echo JText::_( 'ACEVER_ADD_PUBLISHED' ); ?>:
									</label>
								</td>
								<td>
									<?php echo $this->list['published'];?>
								</td>
							</tr>
							
							
						</table>
					<legend>
				</fieldset>
			</td>
			<td valign="top" width="50%">
				<fieldset class="adminform">
					<legend>Optional</legend>
						<table class="admintable">
							<tr>
								<td class="key">
									<label for="catid">
										<?php echo JText::_( 'ACEVER_ADD_OPTION' ); ?>:
									</label>
								</td>
								<td>
									<input class="text_area" type="text" name="com_option"  id="com_option" value="<?php echo $this->items->com_option;?>"/>
								</td>
							</tr>
							<tr>
								<td class="key">
									<label for="catid">
										<?php echo JText::_( 'ACEVER_ADD_COMP' ); ?>:
									</label>
								</td>
								<td>
									<?php echo $this->list['comp_list'];?>
								</td>
							</tr>		
							<tr>
								<td class="key">
									<label for="catid">
										<?php echo JText::_( 'ACEVER_ADD_DOWN' ); ?>:
									</label>
								</td>
								<td>
									<input class="text_area" size="70" type="text" name="download"  id="download" value="<?php echo $this->items->download;?>"/>
								</td>
							</tr>
							<tr>
								<td class="key">
									<label for="catid">
										<?php echo JText::_( 'ACEVER_ADD_CHAN' ); ?>:
									</label>
								</td>
								<td>
									<input class="text_area" type="text" size="70" name="changelog"  id="changelog" value="<?php echo $this->items->changelog;?>"/>
								</td>
							</tr>
							<tr>
								<td class="key">
									<label for="catid">
										<?php echo JText::_( 'ACEVER_ADD_STATUS' ); ?>:
									</label>
								</td>
								<td>
									<?php echo $this->list['status_list'];?>
								</td>
							</tr>
							<tr>
								<td class="key">
									<label for="catid">
										<?php echo JText::_( 'ACEVER_ADD_DATE' ); ?>:
									</label>
								</td>
								<td>
									<?php echo $this->vdate;?>
								</td>
							</tr>
							<tr>
								<td class="key">
									<label for="catid">
										<?php echo JText::_( 'ACEVER_ADD_DES' ); ?>:
									</label>
								</td>
								<td>
									<textarea   name="description" id="description"   rows="5" cols="40" ><?php echo $this->items->description;?></textarea>
								</td>
							</tr>
						</table>
					</legend>
				</fieldset>
			</tr>
		</table>
	
		<input type="hidden" name="option" value="<?php echo $option;?>" />
		<input type="hidden" name="controller" value="addextension" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="id" value="<?php echo $this->items->id; ?>" />
		<?php echo JHTML::_( 'form.token' ); ?>
</form>