<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class AceversionsViewAddextension extends JView{

	function display($tpl = null){
		// Add CSS
		$document = & JFactory::getDocument();
		$document->addStyleSheet('components/com_aceversions/assets/css/aceversions.css');
		
		JToolBarHelper::title(JText::_('ACEVER_CPANEL_EXTENSIONS'), 'aceversions');
		JToolBarHelper::save();
		if(JRequest::getVar('task') == "edit") {
			JToolBarHelper::apply();
		}
		JToolBarHelper::cancel();
		
		//get Datas
		$items	 	=& 	$this->get('Data');
		$rows 		=& 	$this->get('Category');	
		
		$category[] = JHTML::_('select.option', -1, JText::_('ACEVER_ADD_SCAT'));
		foreach(array_keys($rows) as $i){
			$row = &$rows[$i];
			$category[] = JHTML::_('select.option', $row->id, $row->name);
		}
		
		//get compability
		$comp[] = JHTML::_('select.option', -1, JText::_('ACEVER_ADD_SCAMP'));
		$comp[] = JHTML::_('select.option', 15, JText::_('Joomla! 1.5'));
		$comp[] = JHTML::_('select.option', 16, JText::_('Joomla! 1.6'));
		
		//get satus
		$status[] = JHTML::_('select.option', -1, JText::_('ACEVER_ADD_SCTS'));
		$status[] = JHTML::_('select.option', 0, JText::_('Alpha'));
		$status[] = JHTML::_('select.option', 1, JText::_('Beta'));
		$status[] = JHTML::_('select.option', 2, JText::_('RC'));
		$status[] = JHTML::_('select.option', 3, JText::_('Stable'));
		$status[] = JHTML::_('select.option', 4, JText::_('Securty Release'));
		
		$list['category_list'] 	 = JHTML::_('select.genericlist', $category, 'category', '', 'value', 'text', $items->category);
		$list['comp_list']		 = JHTML::_('select.genericlist', $comp, 'compatibility', '', 'value', 'text', $items->compatibility);
		$list['status_list'] 	 = JHTML::_('select.genericlist', $status, 'status', '', 'value', 'text', $items->status);
		$list['published']		 = JHTML::_('select.booleanlist', 'published', null ,$items->published);
		
		$this->assignRef('items',$items);
		$this->assignRef('list',$list);
		$this->assignRef('vdate',JHTML::_('calendar',$items->vdate,'vdate','vdate'));
		
		parent::display($tpl);	
	}
}