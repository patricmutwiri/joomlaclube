<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Imports
jimport( 'joomla.application.component.view');

class AceversionsViewConfig extends JView {

	function display($tpl = null) {
		// Add CSS
		$document = & JFactory::getDocument();
		$document->addStyleSheet('components/com_aceversions/assets/css/aceversions.css');
		
		require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_aceversions'.DS.'configuration.php');
		
		JToolBarHelper::title(JText::_('ACEVER_CONFIG_TITLE'), 'aceversions');
		JToolBarHelper::save();
		JToolBarHelper::apply();
		JToolBarHelper::cancel();
		JToolBarHelper::divider();
		
		$lists['status_xml']		=JHTML::_('select.booleanlist','status_xml'			,null,	$this->AceversionsConfig->status_xml);
		$lists['changelog_xml']		=JHTML::_('select.booleanlist','changelog_xml'		,null,	$this->AceversionsConfig->changelog_xml);
		$lists['download_xml']		=JHTML::_('select.booleanlist','download_xml'		,null,	$this->AceversionsConfig->download_xml);
		$lists['date_xml']			=JHTML::_('select.booleanlist','date_xml'			,null,	$this->AceversionsConfig->date_xml);
		$lists['comp_xml']			=JHTML::_('select.booleanlist','comp_xml'			,null,	$this->AceversionsConfig->comp_xml);
		$lists['option_xml']		=JHTML::_('select.booleanlist','option_xml'			,null,	$this->AceversionsConfig->option_xml);
		$lists['desc_xml']			=JHTML::_('select.booleanlist','desc_xml'			,null,	$this->AceversionsConfig->desc_xml);
		$this->assignRef('lists',	$lists);
		parent::display($tpl);
	}
}