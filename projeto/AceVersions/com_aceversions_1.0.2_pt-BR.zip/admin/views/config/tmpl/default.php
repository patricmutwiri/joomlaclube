<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');
?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
	<fieldset class="adminform">
		<legend><?php echo JText::_('XML'); ?></legend>
			<table class="admintable">
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('URL'); ?>;">
							<?php echo JText::_('URL'); ?>
						</span>
					</td>
					<td>
						<a href="../index.php?option=com_aceversions&view=xml&format=xml">index.php?option=com_aceversions&view=xml&format=xml</a>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACEVER_CONFIG_MAIN_CHANGELOG'); ?>;">
							<?php echo JText::_('ACEVER_CONFIG_MAIN_DATE'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['date_xml']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACEVER_CONFIG_MAIN_CHANGELOG'); ?>;">
							<?php echo JText::_('ACEVER_CONFIG_MAIN_COMP'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['comp_xml']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACEVER_CONFIG_MAIN_CHANGELOG'); ?>;">
							<?php echo JText::_('ACEVER_CONFIG_MAIN_OPTION'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['option_xml']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACEVER_CONFIG_MAIN_CHANGELOG'); ?>;">
							<?php echo JText::_('ACEVER_CONFIG_MAIN_DESC'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['desc_xml']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACEVER_CONFIG_MAIN_STATUS'); ?>">
							<?php echo JText::_('ACEVER_CONFIG_MAIN_STATUS'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['status_xml']; ?>
					</td>
				</tr>
										
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACEVER_CONFIG_MAIN_DOWNLOAD'); ?>; ">
							<?php echo JText::_('ACEVER_CONFIG_MAIN_DOWNLOAD'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['download_xml']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACEVER_CONFIG_MAIN_CHANGELOG'); ?>;">
							<?php echo JText::_('ACEVER_CONFIG_MAIN_CHANGELOG'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['changelog_xml']; ?>
					</td>
				</tr>
			</table>
		</legend>
	</fieldset>
	
	<input type="hidden" name="id" value="" />
	<input type="hidden" name="option" value="com_aceversions" />
	<input type="hidden" name="controller" value="config" />
	<input type="hidden" name="task" value="edit" />
</form>