<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

// Import View
jimport('joomla.application.component.view');

// Upgrade View Class
class AceversionsViewUpgrade extends JView {

	function __construct($config = null) {
		parent::__construct($config);
	}

	function display($tpl = null) {
		// Add CSS
		$document = & JFactory::getDocument();
		$document->addStyleSheet('components/com_aceversions/assets/css/aceversions.css');
		
		JToolBarHelper::title(JText::_('ACEVER_UPGRADE_TITLE'), 'aceversions');
		JToolBarHelper::back('Back', 'index.php?option=com_aceversions');

		parent::display($tpl);
	}
}