<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

// Imports
jimport('joomla.application.component.model');

class AceversionsModelAddextension extends JModel {

	var $_data;
	
	function __construct() {
		parent::__construct();
		
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$this->_id = $cid[0];
	}

	function getData() {
		if (is_numeric($this->_id)) {
			$this->_data = & JTable::getInstance('extensions','Table');
			$this->_data->load($this->_id);
		}
		else {
			$db =& JFactory::getDBO();
			$db->setQuery("SELECT * FROM #__aceversions WHERE id = {$this->_id} ORDER BY id");
			$this->_data = $db->loadObject();
		}

		return $this->_data;
	}
	
	function getCategory() {
		return $this->_getList("SELECT * FROM #__aceversions_cats WHERE published = 1 ORDER BY name");
	}
	
	function save(){
		// Get table instance
		$row = & JTable::getInstance('extensions', 'Table');
		$row->mdate =date(" Y-m-d H:i:s");
		
		// Bind the form fields to the table
		if (!$row->bind(JRequest::get('post'))){
			JError::raiseError(500, $row->getError());
		}
		
		// Make sure the record is valid
		if (!$row->check()) {
			return JError::raiseWarning(500, $row->getError());
		}
				
		// Store
		if (!$row->store()){
			JError::raiseError(500, $row->getError());
		}
		
		return true;
	}
}