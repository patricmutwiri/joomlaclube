<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.filesystem.file');
jimport('joomla.application.component.model');

class AceversionsModelAceversions extends JModel {
	
	// Main constructer
	function __construct() {
		parent::__construct();
	}
	
	function getStats() {
		$db =& JFactory::getDBO();
		
		$db->setQuery('SELECT COUNT(*) FROM #__aceversions');
		$count['extensions'] = $db->loadResult();
		
		$db->setQuery('SELECT COUNT(*) FROM #__aceversions_cats');
		$count['categories'] = $db->loadResult();
		
		return $count;
	}
	
	// Upgrade
    function upgrade($package) {

        // Was the package unpacked?
        if (!$package) {
            $this->setState('message', 'Unable to find install package.');
            return false;
        }
		
		// Get current version
        $curVersion = $this->getInstalledVersion();
        if (empty($curVersion)) {
            $this->setState('message', JText::_('Could not find current version.'));
            JFolder::delete($package['dir']);
            return false;
        }

        // Create an array of upgrade files
        $upgradeDir = $package['dir'].DS.'upgrade';
        $upgradeFiles = JFolder::files($upgradeDir, '.php$');

        if (empty($upgradeFiles)) {
            $this->setState('message', JText::_('This package does not contain any upgrade informations.'));
            JFolder::delete($package['dir']);
            return false;
        }

        natcasesort($upgradeFiles);

        // prepare arrays of upgrade operations and functions to manipulate them
        $this->_fileError = false;
        $this->_fileList = array();
        $this->_sqlList = array();
        $this->_scriptList = array();

		// load each upgrade file starting with current version in ascending order
		foreach ($upgradeFiles as $uFile) {
			if (!eregi("^[0-9]+\.[0-9]+\.[0-9]+\.php$", $uFile)) {
				continue;
			}
			if (strnatcasecmp($uFile, $curVersion.".php") >= 0) {
				require_once($upgradeDir.DS.$uFile);
			}
		}

        if ($this->_fileError == false) {
            // set errors variable
            $errors = false;

            // first of all check if all the files are writeable
            foreach ($this->_fileList as $dest => $op) {
                $file = JPath::clean(JPATH_ROOT.DS.$dest);

                // check if source file is present in upgrade package
                if ($op->operation == 'upgrade') {
                    $from = JPath::clean($package['dir'].DS.$op->packagePath);
                    if( !JFile::exists($from) ) {
                        JError::raiseWarning( 100, JText::_('ACEVER_UPGRADE_FILENOT').': '.$op->packagePath );
                        $errors = true;
                    }
                }

                if ((($op->operation == 'delete') && (JFile::exists($file))) || (($op->operation == 'upgrade') && (!JFile::exists($file)))) {

                    // if the file is to be deleted or created, the file's directory must be writable
                    $dir = dirname($file);
                    if (!JFolder::exists($dir)) {
                        // we need to create the directory where the file is to be created
                        if(!JFolder::create($dir)) {
                            JError::raiseWarning( 100, JText::_('ACEVER_UPGRADE_DIRECTORY') . ': ' . $dir );
                            $errors = true;
                        }
                    }

                    if (!is_writable($dir)) {
                        if (!JPath::setPermissions($dir, '0755', '0777')) {
                            JError::raiseWarning( 100, JText::_('ACEVER_UPGRADE_DIRECTORY_WRT') . ': ' . $dir );
                            $errors = true;
                        }
                    }
                }
                elseif ($op->operation == 'upgrade') {

                    // the file itself must be writeable
                    if (!is_writable($file)) {
                        if (!JPath::setPermissions($file, '0755', '0777')) {
                            JError::raiseWarning( 100, JText::_('ACEVER_UPGRADE_DIRECTORY_FILE') . ': ' . $file );
                            $errors = true;
                        }
                    }
                }
            }

            if (!$errors) {
                $db =& JFactory::getDBO();

                // execute SQL queries
                foreach ($this->_sqlList as $sql) {
                    $db->setQuery($sql);
                    if( !$db->query() ) {
                        JError::raiseWarning(100, JText::_('ACEVER_UPGRADE_DIRECTORY_SQL') . ': ' . $sql);
                        $errors = true;
                    }
                }

                // perform file operations
                foreach ($this->_fileList as $dest => $op) {
                    if ($op->operation == 'delete') {
                        $file = JPath::clean(JPATH_ROOT.DS.$dest);
                        if (JFile::exists($file)) {
                            $success = JFile::delete($file);
                            if (!$success) {
                                JError::raiseWarning(100, JText::_('ACEVER_UPGRADE_DIRECTORY_DELETE').' '.$dest);
                                $errors = true;
                            }
                        }
                    }
                    elseif ($op->operation == 'upgrade') {
                        $from = JPath::clean($package['dir'].DS.$op->packagePath);
                        $to = JPath::clean(JPATH_ROOT.DS.$dest);
                        $destDir = dirname($to);

                        // create the destination directory if needed
                        if (!JFolder::exists($destDir)) {
                            JFolder::create($destDir);
                        }

                        $success = JFile::copy($from, $to);
                        if (!$success) {
                            JError::raiseWarning(100, JText::_('ACEVER_UPGRADE_DIRECTORY_A24').' '.$dest);
                            $errors = true;
                        }
                    }
                }

                // run scripts
                foreach ($this->_scriptList as $script) {
                    $file = JPath::clean($package['dir'].DS.$script);
                    if( !JFile::exists($file) ) {
                        JError::raiseWarning(100, JText::_('ACEVER_UPGRADE_DIRECTORY_A25').': '.$script);
                        $errors = true;
                    } else {
                        include($file);
                    }
                }
            }

            if (!$errors) {
                $this->setState('message', JText::_('ACESEF_UPGRADE_SUCCESS'));
            }
            else {
                $this->setState('message', JText::_('ACESEF_UPGRADE_UNSUCCESS'));
            }
        }

        JFolder::delete($package['dir']);
        return true;
    }
	
	// Adds a file operation to $fileList
    // $joomlaPath - destination file path (e.g. '/administrator/components/com_aceversions/admin.acesef.php')
    // $operation - can be 'delete' or 'upgrade'
    // $packagePath - source file path in upgrade package if $operation is 'upgrade' (e.g. '/admin.acesef.php')
	function _addFileOp($joomlaPath, $operation, $packagePath = '') {
        if (!in_array($operation, array('upgrade', 'delete'))) {
            $this->fileError = true;
            JError::raiseWarning(100, JText::_('Invalid upgrade operation') . ': ' . $operation);
            return false;
        }

        // Do not check if file in package exists - it may be deleted in some future version during upgrade
        // It will be checked before running file operations
        $file = new stdClass();
        $file->operation = $operation;
        $file->packagePath = $packagePath;

        $this->_fileList[$joomlaPath] = $file;
    }
	
	function _addSQL($sql) {
        $this->_sqlList[] = $sql;
    }

    function _addScript($script) {
        $this->_scriptList[] = $script;
    }
	
	// Check info
	function &getInfo() {
       
        $info = array();
        // Get installed version
        $info['version_installed'] = $this->getInstalledVersion();
       
        // Get latest version
        $info['version_latest'] = '?.?.?';
        $content = self::getRemoteData('http://www.joomace.net/index.php?option=com_aceversions&view=xml&format=xml');
       
        if($content && strstr($content, '<?xml version="1.0" encoding="UTF-8" ?>')) {
            $xml =& JFactory::getXMLparser('Simple');
            $xml->loadString($content);
            $manifest = $xml->document;
           
            if (is_a($manifest, 'JSimpleXMLElement') && count($manifest->children())) {
                foreach ($manifest->children() as $category) {
                    $catname = $category->attributes('name');
                    if ($catname == 'components') {
                        foreach ($category->children() as $extension) {
                            $option = $extension->attributes('option');
                            if ($option == 'com_aceversions') {
                                $info['version_latest'] = trim($extension->attributes('version'));
                                break;
                            }
                        }
                        break;
                    }
                }
            } else {
                unset ($xml);
            }
        }
       
        // Set the version status
        $info['version_status'] = version_compare($info['version_installed'], $info['version_latest']);
        $info['version_enabled'] = 1;
       
        return $info;
    }

	function &getInstalledVersion()  {
        static $version;

        if (!isset($version)) {
            $xml = JFactory::getXMLParser('Simple');

            $xmlFile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_aceversions'.DS.'aceversions.xml';

             if (JFile::exists($xmlFile)) {
                if ($xml->loadFile($xmlFile)) {
                    $root =& $xml->document;
                    $element =& $root->getElementByPath('version');
                    $version = $element ? $element->data() : '';
                }
            }
			
        }

        return $version;
    }
	
	function getRemoteData($url) {
		$useragent = "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)";
		$data = false;

		// cURL
		if (extension_loaded('curl')) {
			// Init cURL
			$ch = @curl_init();
			
			// Set options
			@curl_setopt($ch, CURLOPT_URL, $url);
			@curl_setopt($ch, CURLOPT_HEADER, 0);
			@curl_setopt($ch, CURLOPT_FAILONERROR, 1);
			@curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			@curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
			
			// Set timeout
			@curl_setopt($ch, CURLOPT_TIMEOUT, 5);
			
			// Grab data
			$data = @curl_exec($ch);
			
			// Clean up
			@curl_close($ch);
			
			// Return data
			if ($data !== false) {
				return $data;
			}
		}

		// fsockopen
		if (function_exists('fsockopen')) {
			$errno = 0;
			$errstr = '';
			
			$url_info = parse_url($url);
			if($url_info['host'] == 'localhost')  {
				$url_info['host'] = '127.0.0.1';
			}

			// Set timeout
			$fsock = @fsockopen($url_info['scheme'].'://'.$url_info['host'], 80, $errno, $errstr, 5);
		
			if ($fsock) {
				@fputs($fsock, 'GET '.$url_info['path'].(!empty($url_info['query']) ? '?'.$url_info['query'] : '').' HTTP/1.1'."\r\n");
				@fputs($fsock, 'HOST: '.$url_info['host']."\r\n");
				@fputs($fsock, "User-Agent: ".$useragent."\n");
				@fputs($fsock, 'Connection: close'."\r\n\r\n");
		
				// Set timeout
				@stream_set_blocking($fsock, 1);
				@stream_set_timeout($fsock, 5);
				
				$data = '';
				$passed_header = false;
				while (!@feof($fsock)) {
					if ($passed_header) {
						$data .= @fread($fsock, 1024);
					} else {
						if (@fgets($fsock, 1024) == "\r\n")
							$passed_header = true;
					}
				}
				
				// Clean up
				@fclose($fsock);
				
				// Return data
				if ($data !== false) {
					return $data;
				}
			}
		}

		// fopen
		if (function_exists('fopen') && ini_get('allow_url_fopen')) {
			// Set timeout
			if (ini_get('default_socket_timeout') < 5) {
				ini_set('default_socket_timeout', 5);
			}
			@stream_set_blocking($handle, 1);
			@stream_set_timeout($handle, 5);
			@ini_set('user_agent',$useragent);
			
			$url = str_replace('://localhost', '://127.0.0.1', $url);
			
			$handle = @fopen ($url, 'r');
			
			if ($handle) {
				$data = '';
				while (!feof($handle)) {
					$data .= @fread($handle, 8192);
				}
				
				// Clean up
				@fclose($handle);
			
				// Return data
				if ($data !== false) {
					return $data;
				}
			}
		}
		
		// file_get_contents
		if(function_exists('file_get_contents') && ini_get('allow_url_fopen')) {
			$url = str_replace('://localhost', '://127.0.0.1', $url);
			@ini_set('user_agent',$useragent);
			$data = @file_get_contents($url);
			
			// Return data
			if ($data !== false) {
				return $data;
			}
		}
		
		return $data;
	}
}	