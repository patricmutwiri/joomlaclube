<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport('joomla.application.component.model');

// Model Class
class AceversionsModelConfig extends JModel {

	var $_configuration = null;
	
	// Main constructer
	function __construct(){
		parent::__construct();
	}

	function _set_configuration () {
		require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_aceversions'.DS.'configuration.php');
		$this->_configuration = new AceversionsConfig();
	}

	// Save configuration
	function _save_configuration() {
		$config = new JRegistry('config');
		$config_array = array();
		// Main
		
		$config_array['version_checker']= JRequest::getVar('version_checker', 				1, 			'post', 'int');
		$config_array['status_xml']		= JRequest::getVar('status_xml', 					0, 			'post', 'int');
		$config_array['category_xml']	= JRequest::getVar('category_xml', 					0, 			'post', 'int');
		$config_array['download_xml']	= JRequest::getVar('download_xml', 					0, 			'post', 'int');
		$config_array['changelog_xml']	= JRequest::getVar('changelog_xml', 				0, 			'post', 'int');
		$config_array['date_xml']		= JRequest::getVar('date_xml', 						0, 			'post', 'int');
		$config_array['comp_xml']		= JRequest::getVar('comp_xml', 						0, 			'post', 'int');
		$config_array['option_xml']		= JRequest::getVar('option_xml', 					0, 			'post', 'int');
		$config_array['desc_xml']		= JRequest::getVar('desc_xml', 						0, 			'post', 'int');
		
		$config->loadArray($config_array);
		
		// Set the configuration filename
		$filename = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_aceversions'.DS.'configuration.php';

		if (JPath::isOwner($filename) && !JPath::setPermissions($filename, '0644')) {
			JError::raiseNotice('2002', 'Could not make the '.$filename.' writable');
		}

		jimport('joomla.filesystem.file');
		if (JFile::write($filename, $config->toString('PHP', 'config', array('class' => 'AceversionsConfig')))) {
			return true;
		} else {
			return false;
		}
	}
}
?>