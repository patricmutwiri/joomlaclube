<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

class AceversionsModelExtensions extends JModel {
	
	var $_total = null;
	var $_query = null;
	var $_pagination = null;
	
	function __construct(){
        parent::__construct();
		
		$this->_buildQuery();
 
        global $mainframe, $option;
 
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
        $limitstart = JRequest::getVar('limitstart', 0, '', 'int');
 
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
	}
	
	function getData(){
		if (empty($this->_data)) {
            $this->_data = $this->_getList($this->_query, $this->getState('limitstart'), $this->getState('limit')); 
        }
		
        return $this->_data;
	}
	
	function getTotal() {
		if (empty($this->_total)) {
			$this->_total = $this->_getListCount($this->_query);	
		}
		
		return $this->_total;
	}
	
	function getPagination() {
        if (empty($this->_pagination)) {
            jimport('joomla.html.pagination');
            $this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
        }
		
        return $this->_pagination;
	}
	
	function _buildQuery() {
		global $mainframe, $option;
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.extensions.filter_order',		'filter_order',		'name', 'cmd');
		$filter_order_Dir	= $mainframe->getUserStateFromRequest($option.'.extensions.filter_order_Dir',	'filter_order_Dir',	'ASC' , 'word');
		$where = $this->_buildViewWhere();
		$this->_query = 'SELECT * FROM #__aceversions '.$where.' ORDER BY '.$filter_order. ' '.$filter_order_Dir ;
	}
	
	//Get where
	function _buildViewWhere(){	
		$db = & JFactory::getDBO();
		
		global $mainframe, $option;
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.extensions.filter_order',		'filter_order',		'extensions');
		$filter_order_Dir	= $mainframe->getUserStateFromRequest($option.'.extensions.filter_order_Dir',	'filter_order_Dir',	'ASC');
		$filter_category 	= $mainframe->getUserStateFromRequest($option.'.extensions.filter_category',  	'filter_category', 	'-1');
		$filter_comp		= $mainframe->getUserStateFromRequest($option.'.extensions.filter_comp',		'filter_comp',		'-1');
		$filter_status	 	= $mainframe->getUserStateFromRequest($option.'.extensions.filter_status',  	'filter_status', 	'-1');
		$search				= $mainframe->getUserStateFromRequest($option.'.extensions.search',				'search',			'');
		$search				= JString::strtolower($search);

		$where = array();
		if ($filter_category != '-1') {
			$where[] = "category = ".$filter_category;
		}
		
		if($filter_comp  != '-1'){
			$where[] = "compatibility = ".$filter_comp;
		}
		
		if ($search != '') {
			$where[] = 'LOWER(name) LIKE '.$this->_db->Quote('%'.$search.'%');
		}
		
		if($filter_status  !='-1'){	
			$where[] = "status = ".$filter_status;
		}
		
		$where = (count($where) ? ' WHERE '. implode(' AND ', $where) : '');
		
		return $where;
	}
		
		
	function getCategoryList() {
		$db =& JFactory::getDBO();
		$db->setQuery('SELECT id, name, published FROM #__aceversions_cats WHERE published = 1 ORDER BY name');
		$rows = $db->loadObjectList('id');
		
		return $rows;	
	}
	
	
	
	function getCompatibility(){
		$comp[15] = "Joomla! 1.5";
		$comp[16] = "Joomla! 1.6";
		
		return $comp;
	}
	
	function getStatus(){
		$status[0] = "Alpha";
		$status[1] = "Beta";
		$status[2] = "RC";
		$status[3] = "Stable";
		$status[4] = "Securty Release";
	}
	
	function delete(){
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$row =& $this->getTable();
		
		if (count($cids)){
			foreach($cids as $cid) {
				if (!$row->delete($cid)) {
					$this->setError($row->getErrorMsg());
					return false;
				}
			}
		}
		
	    return true;
	}
	
	function publish($id) {
		$row =& JTable::getInstance('extensions', 'Table');
		$row->load($id);
		
		$row->published = 1;
		
		$row->store();
	}
	
	function unpublish($id) {
		$row =& JTable::getInstance('extensions', 'Table');
		$row->load($id);
		
		$row->published = 0;
		
		$row->store();
	}
}	