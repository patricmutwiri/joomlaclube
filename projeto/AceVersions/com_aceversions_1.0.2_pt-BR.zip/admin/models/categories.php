<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

class AceversionsModelCategories extends JModel{

	var $_total = null;
	var $_query = null;
	var $_pagination = null;
	
	function __construct(){
        parent::__construct();
		
		$this->_buildQuery();
 
        global $mainframe, $option;
 
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
        $limitstart = JRequest::getVar('limitstart', 0, '', 'int');
 
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
	}
	function getData(){
	
		if (empty($this->_data)) {
            $this->_data = $this->_getList($this->_query, $this->getState('limitstart'), $this->getState('limit')); 
        }
		
        return $this->_data;
	}
	
	function getTotal() {
		// Load the content if it doesn't already exist
		if (empty($this->_total)) {
			$this->_total = $this->_getListCount($this->_query);	
		}
		return $this->_total;
	}
	
	function getPagination(){
        // Load the content if it doesn't already exist
        if (empty($this->_pagination)) {
            jimport('joomla.html.pagination');
            $this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
        }
        return $this->_pagination;
	}
	
	//get data
	function _buildQuery() {
		global $mainframe, $option;
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.categories.filter_order',		'filter_order',		'name', 'cmd');
		$filter_order_Dir	= $mainframe->getUserStateFromRequest($option.'.categories.filter_order_Dir',	'filter_order_Dir',	'ASC' , 'word');
		$this->_query = 'SELECT * FROM #__aceversions_cats ORDER BY '.$filter_order. ' '.$filter_order_Dir;
	}
	
	function publish($id) {
		$row =& JTable::getInstance('categories', 'Table');
		$row->load($id);
		
		$row->published = 1;
		
		$row->store();
	}
	
	function unpublish($id) {
		$row =& JTable::getInstance('categories', 'Table');
		$row->load($id);
		
		$row->published = 0;
		
		$row->store();
	}
	
	function delete(){
		$cids = JRequest::getVar('cid', array(0), 'post', 'array');
		$row =& $this->getTable();
		if (count($cids)) {
			foreach($cids as $cid) {
				if (!$row->delete($cid)) {
					$this->setError($row->getErrorMsg());
					return false;
				}
			}
		}
		
		return true;
	}
}