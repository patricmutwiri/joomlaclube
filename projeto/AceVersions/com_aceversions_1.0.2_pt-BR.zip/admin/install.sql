# -----------------------
# AceVersions SQL Installation
# -----------------------
DROP TABLE IF EXISTS `#__aceversions`;
CREATE TABLE IF NOT EXISTS `#__aceversions`(
	`id` INT(25) NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(255) NOT NULL DEFAULT '',
	`com_option` VARCHAR(255) NOT NULL DEFAULT '',
	`version` VARCHAR(255) NOT NULL DEFAULT '',
	`compatibility`  VARCHAR(255) NOT NULL DEFAULT '',
	`vdate` DATE NOT NULL DEFAULT '0000-00-00',
	`mdate` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
	`category`  VARCHAR(255) NOT NULL DEFAULT '',
	`download`  VARCHAR(255) NOT NULL DEFAULT '',
	`changelog`  VARCHAR(255) NOT NULL DEFAULT '',
	`status`  VARCHAR(255) NOT NULL DEFAULT '3',
	`published` INT(2) NOT NULL DEFAULT '1',
	`description` TEXT NOT NULL DEFAULT '',
	PRIMARY KEY(`id`)
) TYPE=MyISAM CHARACTER SET `utf8`;

DROP TABLE IF EXISTS `#__aceversions_cats`;
CREATE TABLE IF NOT EXISTS `#__aceversions_cats`(
	`id` INT(25) NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(255) NOT NULL DEFAULT '',
	`published` INT(2) NOT NULL DEFAULT '1',
	`description` TEXT NOT NULL DEFAULT '',
	PRIMARY KEY(`id`)
) TYPE=MyISAM CHARACTER SET `utf8`;