<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

class TableExtensions extends JTable {

	var $id = null;
	var $name = null;
	var $vdate = null;
	var $status = null;
	var $com_option = null;
	var $download = null;
	var $category = null;
	var $version  = null;
	var $changelog = null;
	var $description = null;
	var $compatibility = null;
	var $published = null;
	var $mdate		= null;
	function __construct(& $db){
		parent::__construct('#__aceversions','id',$db);
	}
}