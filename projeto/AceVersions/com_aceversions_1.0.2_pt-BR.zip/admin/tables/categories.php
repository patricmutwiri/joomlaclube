<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

class TableCategories extends JTable {

	var $id = null;
	var $name = null;		
	var $description = null;
	var $published = null;
	
	function __construct(& $db){
		parent::__construct('#__aceversions_cats','id',$db);
	}
}