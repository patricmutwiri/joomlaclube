DROP TABLE IF EXISTS `#__aceversions_backup`;
RENAME TABLE `#__aceversions` TO `#__aceversions_backup`;

DROP TABLE IF EXISTS `#__aceversions_cats_backup`;
RENAME TABLE `#__aceversions_cats` TO `#__aceversions_cats_backup`;

DELETE FROM `#__components` WHERE admin_menu_link LIKE 'com_aceversions';