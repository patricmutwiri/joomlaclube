<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// XML definition file
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'aceversions.xml', 'upgrade', DS.'aceversions.xml');

// Admin files
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'aceversions.php', 'upgrade',DS.'admin'. DS.'aceversions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'controller.php', 'upgrade',DS.'admin'. DS.'controller.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'index.html', 'upgrade',DS.'admin'. DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'install.sql', 'upgrade',DS.'admin'. DS.'install.sql');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'toolbar.aceversions.php', 'upgrade',DS.'admin'. DS.'toolbar.aceversions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'uninstall.sql', 'upgrade',DS.'admin'. DS.'uninstall.sql');

// Assets
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'index.html', 'upgrade',DS.'admin'. DS.'assets'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'css'.DS.'aceversions.css', 'upgrade', DS.'admin'.DS.'assets'.DS.'css'.DS.'aceversions.css');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'css'.DS.'index.html', 'upgrade',DS.'admin'. DS.'assets'.DS.'css'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'aceversions.png', 'upgrade',DS.'admin'. DS.'assets'.DS.'images'.DS.'aceversions.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'icon-16-avcategories.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-16-avcategories.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'icon-16-avconfig.png', 'upgrade',DS.'admin'. DS.'assets'.DS.'images'.DS.'icon-16-avconfig.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'icon-16-avsupport.png', 'upgrade',DS.'admin'. DS.'assets'.DS.'images'.DS.'icon-16-avsupport.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'icon-16-avupgrade.png', 'upgrade',DS.'admin'. DS.'assets'.DS.'images'.DS.'icon-16-avupgrade.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'icon-16-avextensions.png', 'upgrade',DS.'admin'. DS.'assets'.DS.'images'.DS.'icon-16-avextensions.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'icon-48-categories.png', 'upgrade',DS.'admin'. DS.'assets'.DS.'images'.DS.'icon-48-categories.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'icon-48-changelog.png', 'upgrade',DS.'admin'. DS.'assets'.DS.'images'.DS.'icon-48-changelog.png');

$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'icon-48-configuration.png', 'upgrade',DS.'admin'. DS.'assets'.DS.'images'.DS.'icon-48-configuration.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'icon-48-extensions.png', 'upgrade',DS.'admin'. DS.'assets'.DS.'images'.DS.'icon-48-extensions.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'icon-48-support.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-support.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'icon-48-upgrade.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'icon-48-upgrade.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'logo.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'logo.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'toolbar.png', 'upgrade', DS.'admin'.DS.'assets'.DS.'images'.DS.'toolbar.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'index.html', 'upgrade',DS.'admin'. DS.'assets'.DS.'images'.DS.'index.html');

// Controllers
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'aceversions.php', 'upgrade',DS.'admin'. DS.'controllers'.DS.'aceversions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'config.php', 'upgrade',DS.'admin'. DS.'controllers'.DS.'config.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'addcategory.php', 'upgrade',DS.'admin'. DS.'controllers'.DS.'addcategory.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'addextension.php', 'upgrade',DS.'admin'. DS.'controllers'.DS.'addextension.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'extensions.php', 'upgrade',DS.'admin'. DS.'controllers'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'index.html', 'upgrade', DS.'admin'.DS.'controllers'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'categories.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'categories.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'upgrade.php', 'upgrade', DS.'admin'.DS.'controllers'.DS.'upgrade.php');

// Models
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'aceversions.php', 'upgrade',DS.'admin'. DS.'models'.DS.'aceversions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'config.php', 'upgrade', DS.'admin'.DS.'models'.DS.'config.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'addcategory.php', 'upgrade',DS.'admin'. DS.'models'.DS.'addcategory.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'addextension.php', 'upgrade',DS.'admin'. DS.'models'.DS.'addextension.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'extensions.php', 'upgrade',DS.'admin'. DS.'models'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'index.html', 'upgrade', DS.'admin'.DS.'models'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'categories.php', 'upgrade', DS.'admin'.DS.'models'.DS.'categories.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'upgrade.php', 'upgrade',DS.'admin'. DS.'models'.DS.'upgrade.php');

// Views
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'aceversions'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'aceversions'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'aceversions'.DS.'view.html.php', 'upgrade',DS.'admin'. DS.'views'.DS.'aceversions'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'aceversions'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'admin'. DS.'views'.DS.'aceversions'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'aceversions'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'aceversions'.DS.'tmpl'.DS.'index.html');

$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'addcategory'.DS.'index.html', 'upgrade',DS.'admin'. DS.'views'.DS.'addcategory'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'addcategory'.DS.'view.html.php', 'upgrade',DS.'admin'. DS.'views'.DS.'addcategory'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'addcategory'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'admin'. DS.'views'.DS.'addcategory'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'addcategory'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'addcategory'.DS.'tmpl'.DS.'index.html');

$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'addextension'.DS.'index.html', 'upgrade',DS.'admin'. DS.'views'.DS.'addextension'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'addextension'.DS.'view.html.php', 'upgrade',DS.'admin'. DS.'views'.DS.'addextension'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'addextension'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'admin'. DS.'views'.DS.'addextension'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'addextension'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'addextension'.DS.'tmpl'.DS.'index.html');

$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'categories'.DS.'index.html', 'upgrade',DS.'admin'. DS.'views'.DS.'categories'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'categories'.DS.'view.html.php', 'upgrade',DS.'admin'. DS.'views'.DS.'categories'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'categories'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'admin'. DS.'views'.DS.'categories'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'categories'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'categories'.DS.'tmpl'.DS.'index.html');


$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'config'.DS.'index.html', 'upgrade',DS.'admin'. DS.'views'.DS.'config'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'config'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'config'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'admin'. DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'index.html');

$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'extensions'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'view.html.php', 'upgrade',DS.'admin'. DS.'views'.DS.'extensions'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'admin'. DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'index.html');

$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'support'.DS.'index.html', 'upgrade',DS.'admin'. DS.'views'.DS.'support'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'support'.DS.'view.html.php', 'upgrade',DS.'admin'. DS.'views'.DS.'support'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php', 'upgrade',DS.'admin'. DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php');

$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'admin'. DS.'views'.DS.'support'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'index.html');

$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'upgrade'.DS.'index.html', 'upgrade',DS.'admin'. DS.'views'.DS.'upgrade'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'upgrade'.DS.'view.html.php', 'upgrade', DS.'admin'.DS.'views'.DS.'upgrade'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'admin'.DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'upgrade'.DS.'tmpl'.DS.'index.html');

// Language files
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.com_aceversions.ini', 'upgrade', DS.'admin'.DS.'languages'.DS.'en-GB'.DS.'en-GB.com_aceversions.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.com_aceversions.menu.ini', 'upgrade', DS.'admin'.DS.'languages'.DS.'en-GB'.DS.'en-GB.com_aceversions.menu.ini');

// Upgrade
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'upgrade'.DS.'reinstall.php', 'upgrade', DS.'upgrade'.DS.'reinstall.php');

// Tables
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'tables'.DS.'extensions.php', 'upgrade',DS.'admin'. DS.'tables'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'tables'.DS.'categories.php', 'upgrade',DS.'admin'. DS.'tables'.DS.'categories.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'tables'.DS.'index.html', 	   'upgrade',DS.'admin'. DS.'tables'.DS.'index.html');


//site files

$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'aceversions.php', 'upgrade',DS.'site'. DS.'aceversions.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'controller.php', 'upgrade',DS.'site'. DS.'controller.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'index.html', 'upgrade',DS.'site'. DS.'index.html');

// Assets
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'index.html', 'upgrade',DS.'site'. DS.'assets'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'css'.DS.'aceversions.css', 'upgrade', DS.'site'.DS.'assets'.DS.'css'.DS.'aceversions.css');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'css'.DS.'index.html', 'upgrade',DS.'site'. DS.'assets'.DS.'css'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'css'.DS.'resim.png', 'upgrade',DS.'site'. DS.'assets'.DS.'css'.DS.'resim.png');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'down-icon.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'down-icon.png');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'extension.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'extension.png');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'resim.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'resim.png');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'index.html', 'upgrade',DS.'site'. DS.'assets'.DS.'images'.DS.'index.html');

// Controllers
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'extensions.php', 'upgrade',DS.'site'. DS.'controllers'.DS.'extensions.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'index.html', 'upgrade', DS.'site'.DS.'controllers'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'category.php', 'upgrade', DS.'site'.DS.'controllers'.DS.'category.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'xml.php', 'upgrade', DS.'site'.DS.'controllers'.DS.'xml.php');

// Models
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'extensions.php', 'upgrade',DS.'site'. DS.'models'.DS.'extensions.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'index.html', 'upgrade', DS.'site'.DS.'models'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'category.php', 'upgrade', DS.'site'.DS.'models'.DS.'category.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'extension.php', 'upgrade',DS.'site'. DS.'models'.DS.'extension.php');

// Views
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'category'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'category'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'category'.DS.'view.html.php', 'upgrade',DS.'site'. DS.'views'.DS.'category'.DS.'view.html.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'category'.DS.'view.feed.php', 'upgrade',DS.'site'. DS.'views'.DS.'category'.DS.'view.feed.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'category'.DS.'metadata.php', 'upgrade',DS.'site'. DS.'views'.DS.'category'.DS.'metadata.xml');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'category'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'site'. DS.'views'.DS.'category'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'category'.DS.'tmpl'.DS.'default.xml', 'upgrade',DS.'site'. DS.'views'.DS.'category'.DS.'tmpl'.DS.'default.xml');

$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'extensions'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'view.html.php', 'upgrade',DS.'site'. DS.'views'.DS.'extensions'.DS.'view.html.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'view.feed.php', 'upgrade',DS.'site'. DS.'views'.DS.'extensions'.DS.'view.feed.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'metadata.php', 'upgrade',DS.'site'. DS.'views'.DS.'extensions'.DS.'metadata.xml');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'site'. DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.xml', 'upgrade',DS.'site'. DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.xml');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'index.html');


$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extension'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'extension'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extension'.DS.'view.html.php', 'upgrade',DS.'site'. DS.'views'.DS.'extension'.DS.'view.html.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extension'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'site'. DS.'views'.DS.'extension'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extension'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'extension'.DS.'tmpl'.DS.'index.html');
?>