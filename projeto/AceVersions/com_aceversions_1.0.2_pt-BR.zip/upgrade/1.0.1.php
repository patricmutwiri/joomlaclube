<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// XML definition file
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'aceversions.xml', 'upgrade', DS.'aceversions.xml');

// Admin files
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'aceversions.php', 'upgrade',DS.'admin'. DS.'aceversions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'controller.php', 'upgrade',DS.'admin'. DS.'controller.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'index.html', 'upgrade',DS.'admin'. DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'install.sql', 'upgrade',DS.'admin'. DS.'install.sql');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'toolbar.aceversions.php', 'upgrade',DS.'admin'. DS.'toolbar.aceversions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'uninstall.sql', 'upgrade',DS.'admin'. DS.'uninstall.sql');

// Views
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'categories'.DS.'index.html', 'upgrade',DS.'admin'. DS.'views'.DS.'categories'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'categories'.DS.'view.html.php', 'upgrade',DS.'admin'. DS.'views'.DS.'categories'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'categories'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'admin'. DS.'views'.DS.'categories'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'categories'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'categories'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'extensions'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'view.html.php', 'upgrade',DS.'admin'. DS.'views'.DS.'extensions'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'admin'. DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'admin'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php', 'upgrade',DS.'admin'. DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php');

//site files
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'aceversions.php', 'upgrade',DS.'site'. DS.'aceversions.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'controller.php', 'upgrade',DS.'site'. DS.'controller.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'index.html', 'upgrade',DS.'site'. DS.'index.html');

// Assets
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'index.html', 'upgrade',DS.'site'. DS.'assets'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'css'.DS.'aceversions.css', 'upgrade', DS.'site'.DS.'assets'.DS.'css'.DS.'aceversions.css');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'css'.DS.'index.html', 'upgrade',DS.'site'. DS.'assets'.DS.'css'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'css'.DS.'resim.png', 'upgrade',DS.'site'. DS.'assets'.DS.'css'.DS.'resim.png');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'down-icon.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'down-icon.png');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'extension.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'extension.png');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'resim.png', 'upgrade', DS.'site'.DS.'assets'.DS.'images'.DS.'resim.png');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'assets'.DS.'images'.DS.'index.html', 'upgrade',DS.'site'. DS.'assets'.DS.'images'.DS.'index.html');

// Controllers
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'extensions.php', 'upgrade',DS.'site'. DS.'controllers'.DS.'extensions.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'index.html', 'upgrade', DS.'site'.DS.'controllers'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'category.php', 'upgrade', DS.'site'.DS.'controllers'.DS.'category.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'controllers'.DS.'xml.php', 'upgrade', DS.'site'.DS.'controllers'.DS.'xml.php');

// Models
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'extensions.php', 'upgrade',DS.'site'. DS.'models'.DS.'extensions.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'index.html', 'upgrade', DS.'site'.DS.'models'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'category.php', 'upgrade', DS.'site'.DS.'models'.DS.'category.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'models'.DS.'extension.php', 'upgrade',DS.'site'. DS.'models'.DS.'extension.php');

// Views
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'category'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'category'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'category'.DS.'view.html.php', 'upgrade',DS.'site'. DS.'views'.DS.'category'.DS.'view.html.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'category'.DS.'view.feed.php', 'upgrade',DS.'site'. DS.'views'.DS.'category'.DS.'view.feed.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'category'.DS.'metadata.php', 'upgrade',DS.'site'. DS.'views'.DS.'category'.DS.'metadata.xml');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'category'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'site'. DS.'views'.DS.'category'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'category'.DS.'tmpl'.DS.'default.xml', 'upgrade',DS.'site'. DS.'views'.DS.'category'.DS.'tmpl'.DS.'default.xml');

$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'extensions'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'view.html.php', 'upgrade',DS.'site'. DS.'views'.DS.'extensions'.DS.'view.html.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'view.feed.php', 'upgrade',DS.'site'. DS.'views'.DS.'extensions'.DS.'view.feed.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'metadata.php', 'upgrade',DS.'site'. DS.'views'.DS.'extensions'.DS.'metadata.xml');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'site'. DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.xml', 'upgrade',DS.'site'. DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.xml');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'index.html');

$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extension'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'extension'.DS.'index.html');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extension'.DS.'view.html.php', 'upgrade',DS.'site'. DS.'views'.DS.'extension'.DS.'view.html.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extension'.DS.'tmpl'.DS.'default.php', 'upgrade',DS.'site'. DS.'views'.DS.'extension'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'components'.DS.'com_aceversions'.DS.'views'.DS.'extension'.DS.'tmpl'.DS.'index.html', 'upgrade', DS.'site'.DS.'views'.DS.'extension'.DS.'tmpl'.DS.'index.html');
?>