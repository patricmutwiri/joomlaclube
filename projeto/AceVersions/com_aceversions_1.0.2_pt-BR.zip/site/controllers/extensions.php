<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

class AceversionsControllerExtensions extends AceversionsController {

	function display(){
		$model =& $this->getModel('extensions');
		$format = JRequest::getVar('format');
		
		if ($format && $format == 'feed') {
			$view = $this->getView('extensions', 'feed');	
		} else {
			$view = $this->getView('extensions', 'html');	
		}
		$view->setModel($model, true);	
		$view->display();		
	}
	
	function xml(){
		$model =& $this->getModel('xml');
		$view = $this->getView('xml', 'xml');	
		
		$view->setModel($model, true);	
		$view->display();	
	}
}
	
	
