<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined( '_JEXEC' ) or die( 'Restricted access' );

class AceversionsControllerXml extends AceversionsController {
	
	function _construct() {
		parent::_construct();
	}
	
	function XML() {
		$doc =& JFactory::getDocument();
		$doc->setMimeEncoding('text/xml');
		
		echo '<?xml version="1.0" encoding="UTF-8" ?>' . "\n";
		echo '<versions>' . "\n";
		
		$cat_id = JRequest::getCmd('catid');
		$categories	= self::getCategories($cat_id);
		if (!empty($categories)) {
			require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_aceversions'.DS.'configuration.php');
			$config 		= new AceversionsConfig();
			$extensions 	= self::getExtensions();
			$compatibility  = self::getCompatibility();
			$ace_status		= self::getStatus();
			
			foreach ($categories as $catid => $category) {
				if (!empty($extensions)) {
					echo "\t" . '<category name="' . strtolower($category->name) . '">' . "\n";
					foreach ($extensions as $k => $extension) {
						if ($catid == $extension->category) {
							$option = $date = $status = $download = $changelog = $comp = $desc = $com = $sts = "";
							
							if($extension->compatibility != -1){
								$com = $compatibility[$extension->compatibility];
							}
							
							if($extension->status != -1){
								$sts = $ace_status[$extension->status];
							}
						
							if($config->date_xml){
								$date = ' date="' . $extension->vdate . '"';
							}
							
							if($config->option_xml) {
								$option = ' option="' . strtolower($extension->com_option) . '"';
							}
							
							if($config->status_xml){
								$status = ' status="' . strtolower($sts) . '"';
							}
							
							if($config->download_xml){
								$download = ' download="' . strtolower($extension->download) . '"';
							}
							
							if($config->changelog_xml){
								$changelog = ' changelog="' . strtolower($extension->changelog) . '"';
							}
							
							if($config->comp_xml){
								$comp = ' compability="' . strtolower($com) . '"';
							}
							
							if($config->desc_xml){
								$desc = ' description="' . strtolower($extension->description) . '"';
							}
							
							echo "\t\t" . '<extension name="' . strtolower($extension->name) . '" version="' . strtolower($extension->version) . '"'.$date.''.$comp.''.$desc.''.$option.''.$download.''.$changelog.''.$status.' />' . "\n";
						}
					}
					echo "\t" . '</category>' . "\n";
				}
			}
		}
		
		echo '</versions>' . "\n";
	}
	
	function getExtensions() {
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__aceversions WHERE published = 1 ORDER BY name");
		$rows = $db->loadObjectList();
		
		return $rows;
	}
	
	function getCategories($catid) {
		$db =& JFactory::getDBO();
		
		if (!empty($catid) && is_numeric($catid)) {
			$catid = $db->Quote($catid);
			$db->setQuery("SELECT id, name FROM #__aceversions_cats WHERE published = 1 AND id = {$catid} ORDER BY name");
		} else {
			$db->setQuery("SELECT id, name FROM #__aceversions_cats WHERE published = 1 ORDER BY name");
		}
		
		$rows = $db->loadObjectList('id');
		
		return $rows;	
	}

	function getCompatibility(){
		$comp[15] = "1.5";
		$comp[16] = "1.6";
		
		return $comp;
	}
	function getStatus() {
		$sts[0] = "Alpha";
		$sts[1] = "Beta";
		$sts[2] = "RC";
		$sts[3] = "Stable";
		$sts[4] = "Securty Relaese";
		
		return $sts;
	}
}