<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

class AceversionsControllerCategory extends AceversionsController
{
	function _construct() {
		parent::_construct();
	}
	
	function category() {
		$model =& $this->getModel('category');
		
		$format = JRequest::getVar('format');
		if ($format && $format == 'feed') {
			$view = $this->getView('category', 'feed');	
		} else {
			$view = $this->getView('category', 'html');	
		}
		
		$view->setModel($model, true);	
		$view->display();	
	}
	
}
