<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

class AceversionsModelCategory extends JModel{

	var $_total = null;
	var $_query = null;
 	var $_pagination = null;
	
	function __construct(){
        parent::__construct();
		
		$this->_buildQuery();
 
        global $mainframe, $option;
 
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
        $limitstart = JRequest::getVar('limitstart', 0, '', 'int');
 
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
	}
	
	function getData() {
		if (empty($this->_data)) {
            $this->_data = $this->_getList($this->_query, $this->getState('limitstart'), $this->getState('limit')); 
        }
		
        return $this->_data;
	}
	
	function getTotal() {
		// Load the content if it doesn't already exist
		if (empty($this->_total)) {
			$this->_total = $this->_getListCount($this->_query);	
		}
		return $this->_total;
	}
	
	function getPagination(){
        // Load the content if it doesn't already exist
        if (empty($this->_pagination)) {
            jimport('joomla.html.pagination');
            $this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
        }
        return $this->_pagination;
	}
	
	//get data
	function _buildQuery() {
	
		global $mainframe, $option;
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.category.filter_order',		'filter_order',		'name');
		$filter_order_Dir	= $mainframe->getUserStateFromRequest($option.'.category.filter_order_Dir',	'filter_order_Dir',	'ASC');
		
		$where = $this->_buildViewWhere();
		$this->_query = 'SELECT * FROM #__aceversions '.$where.' ORDER BY ' . $filter_order .' '. $filter_order_Dir;
	}
	
	//Get where
	function _buildViewWhere(){	
		global $mainframe, $option;
		
		$filter_category 	= JRequest::getCmd('catid');
		$filter_comp		= $mainframe->getUserStateFromRequest($option.'.category.filter_comp',		'filter_comp',		'-1');
		$filter_status	 	= $mainframe->getUserStateFromRequest($option.'.category.filter_status',  	'filter_status', 	'-1');
		$search				= $mainframe->getUserStateFromRequest($option.'.category.search',			'search',			'');
		$search				= JString::strtolower($search);
		
		$where = array();
		
		if ($filter_category != '-1' && is_numeric($filter_category)) {
			$where[] = "category = ".$this->_db->Quote($filter_category);
		}

		if ($filter_comp != '-1' && is_numeric($filter_comp)) {
			$where[] = "compatibility = ".$this->_db->Quote($filter_comp);
		}
		
		if ($search != '') {
			$where[] = ('LOWER(name) LIKE '.$this->_db->Quote('%'.$search.'%') . ' OR LOWER(description) LIKE '.$this->_db->Quote('%'.$search.'%'));
		}
		
		if ($filter_status != '-1' && is_numeric($filter_status)) {	
			$where[] = "status = ".$this->_db->Quote($filter_status);
		}
		
		$where[] = 'published = 1';
		
		$where = (count($where) ? ' WHERE '. implode(' AND ', $where) : '');
		
		return $where;
	}
	
	function getCategroyList(){
		$db =& JFactory::getDBO();
		$db->setQuery('SELECT id,name, published,description FROM #__aceversions_cats WHERE published = 1 ORDER BY name');
		$rows = $db->loadObjectList('id');
		
		return $rows;
	}
	
	function getCompatibility(){
		$comp[15] = "Joomla 1.5";
		$comp[16] = "Joomla 1.6";
		
		return $comp;
	}
	
	function getStatus(){
		$sts[0] 	="Alpha";
		$sts[1]		="Beta";
		$sts[2]		="RC";
		$sts[3]		="Stable";
		$sts[4]		="Securty Relaese";
		
		return $sts;
	}
}