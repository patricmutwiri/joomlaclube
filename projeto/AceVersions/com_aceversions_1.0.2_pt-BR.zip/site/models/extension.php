<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

class AceversionsModelExtension extends JModel{
	
	function getData(){
		$id = JRequest::getCmd('id');
		
		$item = null;
		if (is_numeric($id)) {
			$db =& JFactory::getDBO();
			$db->setQuery("SELECT * FROM #__aceversions WHERE id = ".$this->_db->Quote($id));
			$item = $db->loadObject();
		}
		
		return $item;
	}
	
	function getCategories(){
		$db =& JFactory::getDBO();
		$db->setQuery('SELECT * FROM #__aceversions_cats ORDER BY name');
		$categories = $db->loadObjectList();
		
		return $categories;
	}
	
	function getCompatibility(){
		$comp[15] = "Joomla! 1.5";
		$comp[16] = "Joomla! 1.6";
		
		return $comp;
	}
	
	function getStatus(){
		$status[0] = "Alpha";
		$status[1] = "Beta";
		$status[2] = "RC";
		$status[3] = "Stable";
		$status[4] = "Securty Release";
		
		return $status;
	}
}