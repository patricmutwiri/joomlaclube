<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

// SInclude controller
require_once(JPATH_COMPONENT.DS.'controller.php');

// Get controller
if($controller = JRequest::getCmd('view')) {
	$path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
	if(file_exists($path)) {
	    require_once($path);
	} else {
	    $controller = '';
	}
}

$classname  = 'AceversionsController'.$controller;
$controller = new $classname();

// Perform the Request task
$controller->execute(JRequest::getCmd('view'));

// Redirect if set by the controller
$controller->redirect();