<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

$catid = JRequest::getVar('catid');
?>
<script language="javascript" type="text/javascript">
	function tableOrdering( order, dir, task ) {
	var form = document.adminForm;

	form.filter_order.value 	= order;
	form.filter_order_Dir.value	= dir;
	document.adminForm.submit( task );
}
</script>

<?php if ( $this->params->get( 'show_page_title', 1 ) ) : ?>
<div class="componentheading<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>">
<?php echo $this->escape($this->params->get('page_title')); ?>
</div>
<?php endif; ?>
<?php  if( $this->params->get('show_cat_desc',1)):?>
<div>
<?php echo $this->category[$catid]->description;?>
</div>
<?php endif;?>
<form action="<?php echo JFilterOutput::ampReplace(JFactory::getURI()->toString()); ?>" method="post" name="adminForm">
	<table>
		<tr>
			<td align="left" width="100%">
				<?php echo JText::_('Search'); ?>:
				<?php echo $this->lists['search'];?>
			</td>
			<td nowrap="nowrap">
				<?php?>
			</td>
				<?php if($this->params->get( 'show_display', 1 )):	?>
			<td nowrap="nowrap">
				<?php echo JText::_('Display') . ' # ' . $this->pagination->getLimitBox(); ?>
			</td>
				<?php endif;?>
				<?php if($this->params->get( 'show_comp', 1 )):?>
			<td nowrap="nowrap">
				<?php echo $this->lists['comp_list'];?>
			</td>
				<?php endif;?>
				<?php if($this->params->get( 'show_status', 1 )):?>
			<td nowrap="nowrap">
				<?php echo $this->lists['status_list'];?>
			</td>
				<?php endif;?>
		</tr>
		
	</table>
	<div id="editcell">
		<table class="adminlist" cellspacing="1">
			<thead>
				<tr>
					<td class="sectiontableheader<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>"  width="1%"><?php echo JText::_( 'Num' ); ?></td>
					<td class="sectiontableheader<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>"  width="10%">
					<?php echo JHTML::_('grid.sort', JText::_('Name'), 'name', $this->lists['order_dir'], $this->lists['order']); ?>
					</td>
					<td class="sectiontableheader<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>" width="2%">
					<?php echo JHTML::_('grid.sort', JText::_('Version'), 'version', $this->lists['order_dir'], $this->lists['order']); ?>
					</td>
					<?php if($this->params->get( 'show_date', 1 )):?>
					<td class="sectiontableheader<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>" width="2%"><?php echo JText::_( 'Date' ); ?></td>
					<?php endif; ?>
					<?php if($this->params->get( 'show_comp', 1 )):?>
					<td class="sectiontableheader<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>" width="2%"><?php echo JText::_( 'Compatibilty' ); ?></td>
					<?php endif;?>
					<?php if($this->params->get( 'show_ext_desc', 1 )):?>
					<td class="sectiontableheader<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>" width="10%"><?php echo JText::_( 'Description' ); ?></td>
					<?php endif;?>
					<?php if($this->params->get( 'show_option', 1 )):?>			
					<td class="sectiontableheader<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>" width="3%">
					<?php echo JHTML::_('grid.sort', JText::_('com_option'), 'com_option', $this->lists['order_dir'], $this->lists['order']); ?>
					</td>
					<?php endif;?>
					<?php if($this->params->get( 'show_status', 1 )):?>			
					<td class="sectiontableheader<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>" width="3%">
					<?php echo JHTML::_('grid.sort', JText::_('Status'), 'status', $this->lists['order_dir'], $this->lists['order']); ?>
					</td>
					<?php endif;?>
					<?php 
					if($this->params->get( 'show_download', 1 )):?>			
					<td class="sectiontableheader<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>" width="3%"><?php echo JText::_( 'Download' ); ?></td>
					<?php endif;?>
					<?php 
					if($this->params->get( 'show_changelog', 1 )):?>			
					<td class="sectiontableheader<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>" width="3%"><?php echo JText::_( 'Changelog' ); ?></td>
					<?php endif;?>
					
				</tr>
			</thead>
			
			<?php
			$k =0;
			for ($i = 0, $n=count($this->items); $i <  $n; $i ++) {
				$b = $k + 1;
				$row 		= $this->items[$i];
				if($row->compatibility!= -1){
				$comp 		= $this->compatibility[$row->compatibility];}
				else{
				$comp 		= "";}
				if($row->status!= -1){
				$sts		= $this->status[$row->status];}
				else{
				$sts 		=	"";}
				
				
				$cat_pbl	= $this->category[$row->category]->published;
				$checked 	= JHTML::_('grid.id', $i ,$row->id);
				$link		= 'index.php?option=com_aceversions&view=extension&id='.$row->id;
			
				if ($cat_pbl) { ?>
					<tr class="sectiontableentry<?php echo $b;?>">
						<td>
							<?php echo $this->pagination->getRowOffset($i); ?>
						</td>
						<td>
							<?php if($this->params->get('link_extension',1)){?>
								<a href="<?php echo JRoute::_($link);?>"><?php echo $row->name;?></a>
							<?php }
							else{
								echo $row->name;
							}						
							?>
							
						</td>
						<td>
							<?php echo $row->version;?>
						</td>
							<?php if($this->params->get( 'show_date', 1 )):?>
						<td>
							<?php echo $row->vdate;?>
						</td>
							<?php endif;?>
							<?php if($this->params->get( 'show_comp', 1 )):?>
						<td>
							<?php echo $comp;?>
						</td>
							<?php endif;?>
							<?php if($this->params->get( 'show_ext_desc', 1 )):?>
						<td>
							<?php echo $row->description;?>
						</td>
							<?php endif;?>
							<?php if($this->params->get( 'show_option', 1 )):?>
						<td>
							<?php echo $row->com_option;?>
						</td>
							<?php endif;?>
							<?php if($this->params->get( 'show_status', 1 )):?>
						<td>
							<?php echo $sts;?>
						</td>
							<?php endif;?>
							<?php if($this->params->get( 'show_download', 1 )):?>
						<td>
							<a href="<?php echo $row->download;?>">Download</a>
						</td>
							<?php endif;?>
							<?php if($this->params->get( 'show_changelog', 1 )):?>
						<td>
							<a href="<?php echo $row->changelog;?>">Changelog</a>
						</td>
							<?php endif;?>
											
					</tr>
					<?php
					$k = 1 - $k;
				}
			}
			?>
			<tfoot>
				<tr>
					<td colspan="9" align="center">
						<?php echo $this->pagination->getPagesLinks(); ?>
					</td>
				</tr>
			</tfoot>
		</table>
	</div>
	<input type="hidden" name="option" value="com_aceversions" />
	<input type="hidden" name="view" value="category" />
	<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_dir']; ?>" />
</form>