<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class AceversionsViewCategory extends JView{
	
	function display($tpl = null){
		global $mainframe,$option;
		$document	=& JFactory::getDocument();
		$menus		=& JSite::getMenu();
		$menu 		= $menus->getActive();
		$params 	= &$mainframe->getParams();
		
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.category.filter_order',		'filter_order',		'name' , 'cmd');
		$filter_order_Dir	= $mainframe->getUserStateFromRequest($option.'.category.filter_order_Dir',	'filter_order_Dir',	'ASC'  , 'word');
		$filter_comp		= $mainframe->getUserStateFromRequest($option.'.category.filter_comp',		'filter_comp',		'-1');
		$filter_status	 	= $mainframe->getUserStateFromRequest($option.'.category.filter_status',  	'filter_status', 	'-1');
		$search				= $mainframe->getUserStateFromRequest($option.'.category.search',				'search',			'');
		$search 			= JString::strtolower($search);
	
		$javascript = 'onchange="document.adminForm.submit();"';
		
		$comp[]   = JHTML::_('select.option', -1, JText::_('Compatibilty'));
		$comp[]   = JHTML::_('select.option', 15, JText::_('Joomla! 1.5'));
		$comp[]   = JHTML::_('select.option', 16, JText::_('Joomla! 1.6'));

		$status[] = JHTML::_('select.option',-1,JText::_('Status'));
		$status[] = JHTML::_('select.option',0 ,JText::_('Alpha'));
		$status[] = JHTML::_('select.option',1 ,JText::_('Beta'));
		$status[] = JHTML::_('select.option',2 ,JText::_('RC'));
		$status[] = JHTML::_('select.option',3 ,JText::_('Stable'));
		$status[] = JHTML::_('select.option',4 ,JText::_('Securty Release'));
		
		$lists['order']				= $filter_order;
		$lists['order_dir']			= $filter_order_Dir;
		$lists['comp_list']			= JHTMLSelect::genericlist($comp		, 'filter_comp'		, 'class="inputbox" size="1 "'.$javascript, 'value', 'text', $filter_comp);
		$lists['status_list']		= JHTMLSelect::genericlist($status		, 'filter_status'	, 'class="inputbox" size="1 "'.$javascript, 'value', 'text', $filter_status);
		$lists['search'] 			= "<input class=\"inputbox\" type=\"text\" name=\"search\" value=\"{$search}\" size=\"30\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";
		
		if ($params->get('show_feed_link')) {
			$catid 	= JRequest::getVar('catid');
			$link	= '&view=category&format=feed';
			$document->addHeadLink(JRoute::_($link.'&type=rss'), 'alternate', 'rel', array ('type' => 'application/rss+xml',  'title' =>'RSS 2.0'));
			$document->addHeadLink(JRoute::_($link.'&type=atom'), 'alternate', 'rel', array	('type' => 'application/atom+xml', 'title' => 'Atom 1.0'));
		}
		
		$params	= &$mainframe->getParams('com_aceversions');
		
		$this->assignRef('pagination'		, $this->get('Pagination'));
		$this->assignRef('params'			, $params);
		$this->assignRef('status'			, $this->get('Status'));
		$this->assignRef('lists'			, $lists);
		$this->assignRef('items'			, $this->get('Data'));
		$this->assignRef('category'			, $this->get('CategroyList'));
		$this->assignRef('compatibility'	, $this->get('Compatibility'));
		
		parent::display($tpl);
	}
}