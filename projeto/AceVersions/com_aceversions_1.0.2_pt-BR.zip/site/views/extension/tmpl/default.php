<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');
?>

<div id="body">
	
	<div id="ortasag">
	
		<div><span><?php echo JText::_('Name');?></span></div>
		<div><span><?php echo JText::_('Version');?></span></div>
		<div><span><?php echo JText::_('Category');?></span></div>
		<div><span><?php echo JText::_('Compatibility');?></span></div>
		<div><span><?php echo JText::_('Status');?></span></div>
		<div><span><?php echo JText::_('com_option');?></span></div>
		<div><span><?php echo JText::_('Download Link');?></span></div>
		<div><span><?php echo JText::_('Changelog Link');?></span></div>
		<div><span><?php echo JText::_('Description');?></span></div>
		<div><span><?php echo JText::_('Date');?></span></div>
	</div>
	<div id="ortasol">
		<div><span><?php echo $this->item->name;?></span></div>
		<div><span><?php echo $this->item->version;?></span></div>
		<div><span><?php echo $this->categories[$this->item->category-1]->name;?></span></div>
		<div><span>
		<?php 
		if($this->item->compatibility!=-1){ 
			echo $this->compatibility[$this->item->compatibility];
		}
		else{
			echo ' ';
		}?>
		</span></div>
		<div><span><?php
			if($this->item->status != -1){
				echo $this->status[$this->item->status];
			}
			else{
				echo ' ';}?>
		</span></div>
		<div><span><?php echo $this->item->com_option ;?></span></div>
		<div><span><a href="<?php echo $this->item->download;?>">Download</a></span></div>
		<div><span><a href="<?php echo $this->item->changelog;?>">Changelog</a></span></div>
		<div><span><?php echo $this->item->description;?></span></div>
		<div><span><?php echo $this->item->mdate;?></span></div>
	</div>
	
</div>