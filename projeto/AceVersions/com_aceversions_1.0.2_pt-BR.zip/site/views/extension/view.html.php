<?php
/**
* @version		1.0.0
* @package		AceVersions
* @subpackage	AceVersions
* @copyright	2010 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

//No Permision
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class AceversionsViewExtension extends JView{

	function display ($tpl = null){
		
		$document =& JFactory::getDocument();
		$document->addStyleSheet('components/com_aceversions/assets/css/aceversions.css');
		$this->assignRef('status' 				,$this->get('Status'));
		$this->assignRef('compatibility'		,$this->get('Compatibility'));
		$this->assignRef('categories'			,$this->get('Categories'));
		$this->assignRef('item'					,$this->get('Data'));
		
		parent::display($tpl);
	}
}