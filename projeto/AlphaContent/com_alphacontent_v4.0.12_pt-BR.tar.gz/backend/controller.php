<?php
/*
 * @component AlphaContent
 * @copyright Copyright (C) 2005 - 2009 Bernard Gilly. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @Website : http://www.alphaplug.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.controller' );

/**
 * @package AlphaContent
 */
class configurationController extends JController
{
	/**
	 * Custom Constructor
	 */
 	function __construct()	{
		parent::__construct( );
	}	

	
	/**
	* Show/Edit Configuration
	*/
	function edit() {

		$model 			= &$this->getModel( 'alphacontent' );
		$modelUpdate 	= &$this->getModel( 'upgrade' );
		
		$view  			= $this->getView( 'alphacontent','html');
		
		$model->_set_configuration ();
		$_check = $modelUpdate->_getUpdate();
		
		$view->assign('check', $_check);
		$view->assign('alphacontent_configuration', $model->_configuration);

		$view->edit();
	}

	/**
	* Save the configuration file
	*/
	function save() {		
		// get the model
		$model = &$this->getModel('alphacontent');
		if ( $model->_save_configuration() ) {
			$this->setRedirect('index.php?option=com_alphacontent', JTEXT::_('AC_CONFIGURATION_SAVED'));
		} else {
			$this->setRedirect('index.php?option=com_alphacontent', JTEXT::_('AC_CONFIGURATION_ERROR'));
		}
	}

}

?>