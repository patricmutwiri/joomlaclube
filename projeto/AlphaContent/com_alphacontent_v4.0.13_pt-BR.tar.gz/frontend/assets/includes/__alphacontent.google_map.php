<?php 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml">
<head>
<meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script type="text/javascript">
  function initialize() {
	var latlng = new google.maps.LatLng(<?php echo $_GET['latitude']; ?>, <?php echo $_GET['longitude']; ?>);
	var myOptions = {
	  zoom: <?php echo $_GET['zoom']; ?>,
	  center: latlng,
	  navigationControl: <?php echo $_GET['control_map']; ?>,
	  mapTypeControl: <?php echo $_GET['menu_map']; ?>,
	  mapTypeId: google.maps.MapTypeId.ROADMAP
	};
	var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
	
    var marker = new google.maps.Marker({
        position: myLatlng, 
        map: map,
        title:"<?php echo $_GET['messag']; ?>"
    }); 	
	
  }		
</script>
</head>  
<body onload="initialize()">
  <div id="map_canvas" style="width: <?php echo $_GET['map_width'];?>px; height: <?php echo $_GET['map_height']; ?>px;border: 1px solid black; float: rigth;" align="center"></div>
</body>
</html>