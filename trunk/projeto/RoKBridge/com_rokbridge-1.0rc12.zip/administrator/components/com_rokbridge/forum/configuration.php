<?php 
class JConfigForum 
{
    var $phpbb_path = 'phpbb3';
    var $sef = '0';
    var $sef_rewrite = '0';
    var $remember_login = false;
}
?>
