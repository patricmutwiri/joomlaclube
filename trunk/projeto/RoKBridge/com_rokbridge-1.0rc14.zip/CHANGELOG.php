<?php
/**
 * @version		$Id: CHANGELOG.php 3381 2008-02-02 13:41:29Z rhuk $ 
 * @package RokBridge - phpBB3 edition
 * @copyright Copyright (C) 2009 RocketTheme. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * @author RocketTheme, LLC
 */
 
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
?>

1. Copyright and disclaimer
---------------------------


2. Changelog
------------
This is a non-exhaustive (but still near complete) changelog for
the RocketTheme phpBB3 bridge, including alpha, beta and release 
candidate versions.

Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

-----------RC14 Released-----------------
02-Nov-2010 Juozas Kaziukenas
* Fix for numeric usernames

01-Sep-2010 Juozas Kaziukenas
+ Better handling of empty bridge/distribution folders
+ Checks for various edge cases and installation combinations

19-Aug-2010 Juozas Kaziukenas
^ Moved admin to MVC architecture

-----------RC13 Released-----------------
11-Aug-2010
* Fix for SDI issue

24-Sep-2009 Brian Towles
# Fixed Re: issue in latest posts module
# Fixed live_site working with bridge site

-----------RC12 Released-----------------

23-Sep-2009 Andy Miller
^ Refreshed Admin UI with new images and css
# Bug fixes for default config options

23-Sep-2009 Brian Towles
# Fixed exclude and include bug in latest posts module
^ Speeded up Latest Active Topics query for latest posts module
+ Added indexes install option to admin

22-Sep-2009 Andy Miller
+ Auto-saves default configuration on first run.
^ Changed patch process to take into account > 3.0.5 not needing as much patching
+ Added auto-setting of auth method in phpBB3 when applying/removing auth plugin


15-Sep-2009 Brian Towles
# Fixed phpbb 3.0.6RC1 style compatibility

-----------RC11 Released-----------------

23-Jun-2009
+ Added ability to toggle Bridge or Sync style links in modules/menu
+ Added new Members Module - Support Latest Members, Top Members, and Online Members
+ Added default avatar functionality to login module
# Fixed a translation problem in login module
# Fixed remote avatars in modules functionality

-----------RC10 Released-----------------

09-Jun-2009
+ created Login and Latest posts module
+ Added new RokBridge Icon
+ Added stripping of leading and trailing / on bridge and forum path to prevent errors
# Added to phpbb3 patch to fix file paths bug
# Fixed SEF again
# Fixed .htaccess URL rewrite bug - thanks Roeland
# Fix for application.php to use $livesite if set
^ Minor typo in auth_joomla.php

-----------RC9 Released-----------------

18-Feb-2009 Andy Miller
+ Added test link on successful installation
+ Added patch fix for bridged advanced search
# Fixed bug with IE6/7 and image attatchments

-----------RC8 Released-----------------

18-Jan-2009 Andy Miller
# More SEF fixes, especially for windows machines and ADM login
# Fixed Joomla logout not logging out of phpBB3
# Changed order of plugins so Joomla plugins before phpBB3 ones
# .htaccess file only writes URL rewrite section if sef_rewrite is 1
# Mixed case usernames are now syncing to phpBB3 from Joomla

-----------RC7 Released-----------------

15-Jan-2009 Andy Miller
# Fixed SEF 
# Removed plugins support causing errors such as with sh404SEF

-----------RC6 Released-----------------

13-Jan-2009 Andy Miller
+ Added new all-in-one installer
+ Added admin component for configuration and installation/removal of bridge elements
+ Added phpBB3 patching ability to fix bug in phpBB3
+ Added phpBB3 login "remember me" toggle
# Fixed issue with changing the bridge location from "forum" to another directory
# Fixed "Mark All Forums Read" bug
# Fixed issue with logging off of Joomla admin, logged you out of bridge
# Fixed UCP problems deleting PMs
# Fixed UCP problem with saving drafts
# Fixed UCP problem with adding or removing friends and foes
# Fixed moderator's quick tools box
# Fixed issue with latest phpBB3 version 3.0.4 and user profiles


-----------RC5b3 Released-----------------

03-Oct-2008 James Lukensow
#Fix for Jtext error - thanks benblee
#Fix for Fatal Error in distribution/includes/db/dbal.php on line 602 - thanks mveaudry

-----------RC5b2 Released-----------------

26-May-2008 Andy Miller
 # Fix for JText issue - thanks rdoroshenko

22-May-2008 Andy Miller
 # Various login/sync issues
 # Bug fixes to fullname support
 + Added dkarlovi's .htaccess fix for email links

------------- RC4 Released ---------------

06-May-2008 Johan Janssens
 # Fixed Registration/login problems for Joomla side !

29-Apr-2008 Johan Janssens
 # Fixed All users as shown as browsing the index

28-Mar-2008 Johan Janssens
 # Fixed sticky via moderator panel on a thread, causes error
 # Fixed issue with inline images not showing
 # Fixed [#9449] rank images paths
 # Fixed [#9478] Polls

27-Mar-2008 Johan Janssens
 # Fixed problems with username that have upercase characters. 
 # Fixed [#10320] Call to a member function get() on a non-object in user plugin
 # Fixed [#10020] Wrong default group is set for new users in phpbb
 # Fixed 'view' variable collisions, renamed to rb_v 

------------- RC3 Released ---------------

29-Jan-2008 Johan Janssens
 # Fixed issue with not activated Joomla! account being able to login into phpBB3

------------- RC2 Released ---------------

24-Jan-2008 Johan Janssens
 # Fixed issue with admin login
 # multiple other issues in RC1

------------- RC1 Released ---------------

11-Jan-2008 Johan Janssens
 # Fixed multiple issues with SMF convertor support

07-Jan-2008 Johan Janssens
 + Improved support for the SMF to phpBB3 convertor, allowed username and name syncing from
   Joomla! to phpBB3.

22-Dec-2007 Johan Janssens
 + Added support for SMF to phpBB3 convertor

15-Dec-2007 Johan Janssens
 ! Preparing code for internal beta 2 release

02-Oct-2007 Johan Janssens
 ! Preparing code for internal beta release

02-Sept-2007 Johan Janssens
 ! Initial import
 

 

