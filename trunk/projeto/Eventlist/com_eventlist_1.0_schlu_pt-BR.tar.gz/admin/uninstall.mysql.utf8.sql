DROP TABLE IF EXISTS 
`#__eventlist_events`,
`#__eventlist_venues`,
`#__eventlist_categories`,
`#__eventlist_groups`,
`#__eventlist_groupmembers`,
`#__eventlist_register`,
`#__eventlist_settings`;