<div class="submenu-box">
	<div class="submenu-pad">
		<ul id="submenu">
			<li><a id="basic" class="active"><?php echo JText::_( 'BASIC SETTINGS' ); ?></a></li>
			<li><a id="usercontrol"><?php echo JText::_( 'USER CONTROL' ); ?></a></li>
			<li><a id="details"><?php echo JText::_( 'DETAILS PAGE' ); ?></a></li>
			<li><a id="layout"><?php echo JText::_( 'LAYOUT' ); ?></a></li>
			<li><a id="parameters"><?php echo JText::_( 'GLOBAL PARAMETERS' ); ?></a></li>
		</ul>
		<div class="clr"></div>
	</div>
</div>
<div class="clr"></div>
