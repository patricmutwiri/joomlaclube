<?php
/**
* @package		Joomla Updater
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.0.1
*/
	defined('_JEXEC') or die( 'Restricted access' );	
	// 1 install plugin System - JUC	
	obInstallPlugin('System - Foobla JUC','objuc','system');
	function obInstallPlugin($name,$element,$folder){
		$db = &JFactory::getDBO();
		$qry	= "SELECT `id` FROM `#__plugins` WHERE `element`='objuc' AND `folder`='system' ORDER BY `id` DESC";
		$db->setQuery($qry);
		$ids	= $db->LoadObjectList();		
		if(count($ids)==1){
			return;
		}elseif (count($ids)>1){
			$qry	= "DELETE FROM `#__plugins` WHERE `element`='objuc' AND `folder`='system' AND `id`<".$ids[0]->id;
			$db->setQuery($qry);	
			$db->query();
		}else {
			$src	= JPATH_ADMINISTRATOR.DS.'components'.DS.'com_obupdater'.DS.'aio'.DS.'plugins'.DS.$folder;
			$dest	= JPATH_SITE.DS.'plugins'.DS.$folder.DS;
			JFolder::copy($src,$dest,'',true);			 
			$qry	="INSERT IGNORE INTO `#__plugins`(`name`,`element`,`folder`,`published`)
					VALUES('$name','$element','$folder',1)";
			$db->setQuery($qry);	
			if(!$db->query()){echo $db->getErrorMsg();}			
		}
	}	
