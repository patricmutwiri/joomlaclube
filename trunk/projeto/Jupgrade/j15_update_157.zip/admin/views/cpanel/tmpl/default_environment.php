<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
echo '<div id="juc_list_env_check">&nbsp;</div>';
if(JRequest::getInt('showenvi',0)==1){echo '<script>jucShowInv();</script>';}