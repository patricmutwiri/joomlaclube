<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
$keySearch = 'search your extension here...';
echo "<script type=\"text/javascript\"> <!--
 var juksearch='$keySearch'; 
 //--></script>";
JHTML::script('jusearch.js','administrator'.DS.'components'.DS.$option.DS.'assets'.DS.'js'.DS);
?>
<style type="text/css">
.ju-svalue{
	background: #f8f8f8;
}
#ju_basic_search{
	text-align: center;
	margin-bottom:10px; 	
}
#ju_advance_search{	
	padding-left:100px;	
}
#key_search{
	border: 2px solid #666;	
	font-size: 14px;
	padding:2px  5px;
	color: #333333;
}
#ju_bt_search:hover{
	border-color:#f90 #f93 #f93 #f90;
	background:#ffffdd; 
}
#ju_bt_search{
	background:#eee;
	border:2px solid;
	border-color:#bbb #888 #888 #bbb;
	font-size: 12px;
	color:#333;
	font-weight:bold;
	padding: 4px;  
	cursor: pointer;	
}
#ju-search-result{
	margin-top:10px;	
	border: 1px solid #ddd;
	padding: 10px; 
}
#ju-loading {	
	padding-left:100px;
	display: none;
	
}
.ext-img img{
	padding-left:5px;
}
.ext-img {
	padding-left:20px;	
}
.ext-item{overflow:auto;color:#333333;height:105px;margin-bottom:5px;border-bottom:1px solid #dddddd;}
</style>
<form name = "ju_search" method="post" action="" onsubmit="juc_search();return false;">
	<div id="ju_basic_search">
		<h1 class="componentheading">Joomla! Extensions</h1>
		<input type="text" value="<?php echo $keySearch?>" name="key_search" id="key_search" size="45" class="inputbox" onfocus="if(this.value=='<?php echo $keySearch?>') this.value='';" onblur="if(this.value=='') this.value='<?php echo $keySearch?>';"/>
		<span id="ju_bt_search">Search</span> 
		<div style="padding: 5px 50px;height:15px;overflow: auto;">			
			<span onclick="toggleAdvanceSearch();" style="text-decoration: underline;float: right;color: #3366cc;cursor: pointer;">Advance Search</span>
			<span id="ju-loading">
				<img width="16" height="16" border="0" src="<?php echo JURI::base();?>components/com_obupdater/assets/images/loading.gif" alt="Loading ..." title="Loading ..."/>
				Loading...
			</span>			
		</div>
	</div>
	<div id="ju_advance_search" style="display:none;">
		<table class="admintable" style="border: 1px solid #ddd;background:#fefefe;">
			<tbody>
				<tr>
					<td colspan="2" style="background: #dddddd;border:1px solid; border-color: #bbb #999 #999 #bbb;">
						<div style="color: #0066cc;text-align: center;font-weight: bold;">Advance Search</div>
					</td>
				</tr>			
				<tr>
					<td class="key" >Categories:</td>
					<td class="ju-svalue" id="catlist"><i>Loading ...</i><input type="hidden" value="0" id="catid" name="catid" /></td>
				</tr>
				<tr>
					<td class="key" nowrap="nowrap" >Extension Includes:</td>					
					<td class="ju-svalue">											
						<label><input type="checkbox" value="com" name="ext_includes[]" id="ext_inc_0"/> Components</label><br />
						<label><input type="checkbox" value="mod" name="ext_includes[]" id="ext_inc_1"/> Modules</label><br />
						<label><input type="checkbox" value="plugin" name="ext_includes[]" id="ext_inc_2"/> Plugins</label><br />
						<label><input type="checkbox" value="tem" name="ext_includes[]" id="ext_inc_3"/> Templates</label><br />
						<label><input type="checkbox" value="lang" name="ext_includes[]" id="ext_inc_4"/> Language</label><br />						
						<label><input type="checkbox" value="esp" name="ext_includes[]" id="ext_inc_5"/> Extension Specific Addon</label>
					</td>
				</tr>
				<tr>
				<td class="key">Type:</td>
				<td>
					<label><input type="radio" value="0" id="ext_tp_0" name="ext_types[]" checked="checked"/> All</label>					
					<label><input type="radio" value="1" id="ext_tp_1" name="ext_types[]"/> Commercial</label>
					<label><input type="radio" value="2" id="ext_tp_2" name="ext_types[]"/> Non-Commercial</label>
				</td></tr>
			</tbody>
		</table>
	</div>
</form>
<div id="ju-search-result" style="display: none">&nbsp;Joomla! Extensions result</div>
