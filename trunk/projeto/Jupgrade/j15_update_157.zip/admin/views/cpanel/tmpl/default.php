<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
JHTML::script('dashboard.js','administrator'.DS.'components'.DS.$option.DS.'assets'.DS.'js'.DS);
?>
<div id="ju-dashboard">
<div id="juc-msg">&nbsp;</div>
	<table width="100%" cellspacing="0" cellpadding="0" border="0">
		<tbody>		
			<tr>
				<td width="45%" valign="top">
					<?php echo $this->juc_get_tmpl('search','Search')?>
					<?php //echo $this->juc_get_tmpl('active','Active')?>
					<?php //echo $this->juc_get_tmpl('cronjob','Cronjob')?>
					<?php echo $this->juc_get_tmpl('update','Joomla Core')?>
				</td>
				<td width="1%"></td>				
				<td width="45%" valign="top">
					<div id="juc_environment_check" style="margin:0px;padding:0px;display: none;">
						<?php echo $this->juc_get_tmpl('environment','Environment')?>
					</div>
					<?php echo $this->juc_get_tmpl('installed','Installed Extensions')?>
				</td>
			</tr>
		</tbody>
	</table>
</div>
<script>function submitbutton(pressbutton){if(goCtrl(pressbutton))return false;}</script>
<form id="adminForm" name="adminForm" method="POST" action="index.php?option=com_obupdater">
	<input type="hidden" value="" name="task" />
</form>

