<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.view');
jimport('joomla.html.pane');
class FOOBLACOREViewCpanel extends JView
{
	function display($tpl = null){
		/*$document = &JFactory::getDocument();
		$document->addStyleSheet('components/com_obupdater/assets/juc.css');*/
		JToolBarHelper::title(JText::_('Joomla Updater'), 'home.png');
		JToolBarHelper::preferences('com_obupdater', '300', '500');
		JUCommon::getToolBarDefault();		
		parent::display($tpl);
	}
	function juc_get_tmpl($tmpl,$title){
		$content = $this->loadTemplate($tmpl);		
		return '<fieldset class="adminForm"><legend>'.$title.'</legend>'.$content.'</fieldset>';
	}
}
?>