<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.view');

class FooblaCoreViewBrowse extends JView
{
	function display($tpl = null) {
		global $option,$mainframe;
		#JHTML::stylesheet( 'jlord_core.css', 'administrator'.DS.'components'.DS.$option.DS.'assets'.DS );		
		$model 	= $this->getModel("browse");
		$task	= JRequest::getVar('task');
		if ($task == 'detail') {
			JToolBarHelper::title(JText::_('Extension').' <small><small>[ Details ]</small></small>', 'extensions.png');
			$res	= $model->getLibVersion();
			JToolbarHelper::back();
			JToolBarHelper::divider();
		} elseif ($task == 'update') {
			JToolBarHelper::title(JText::_('Extension').' <small><small>[ Update ]</small></small>', 'extensions.png');			
			JToolbarHelper::back();
			JToolBarHelper::divider();
		} else {
			JToolBarHelper::title(JText::_('Extensions'), 'extensions.png');
			$res 	= $this->get('ShowData');
			$rsfirst	= JRequest::getInt('rsfirst','0');		
			if($rsfirst==1){
				$mainframe->redirect('index.php?option='.$option.'&controller=browse&task=detail&cid[]='.$res->rows->id);
			}
		}
		$this->assignRef('res',$res);
		JUCommon::getToolBarDefault();
		parent::display($tpl);
	}
} // end class
?>
