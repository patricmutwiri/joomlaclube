<?php
/**
* @package		jLord Core
* @author 		Thong Tran - The Joomlord Team.
* @copyright	Copyright (C) 2008 The Joomlord Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		default.php 1.5.0.1	20081119.1635	thongta
* 20081120.1635	thongta	- modified copyright information
*/

// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
$lists 		= $this->res->lists;
$rows 		= $this->res->rows;
$pageNav	= $this->res->pageNav;
$server		= 'http://'.JUInstaller::getServer().'/';
$path_img	= $server.'administrator'.DS.'components'.DS.$option.DS.'assets'.DS.'images'.DS.'icons';
JHTML::_('behavior.tooltip');
?>
<style>.ext-img img{margin-right:3px;}</style>
<script>function submitbutton(pressbutton){if(goCtrl(pressbutton)) return false;}</script>
<form action="index.php?option=<?php echo $option;?>&controller=browse" method="POST" name="adminForm" id="adminForm">
	<table>
	<tr>
		<td align="left" width="100%">
			<?php echo JText::_( 'Filter' ); ?>:
			<input type="text" name="search" id="search" value="<?php echo $lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
			<button onclick="this.form.submit();"><?php echo JText::_( 'Go' ); ?></button>
			<button onclick="document.getElementById('search').value=''; document.getElementById('typeExt').value='All'; document.getElementById('filter_commercial').value='';"><?php echo JText::_( 'Reset' ); ?></button>
		</td>
		<td nowrap="nowrap">
		<?php
			echo $lists['type'];
		?>
		</td>
		<td nowrap="nowrap">
		<?php
			echo $lists['commercial'];
		?>
		</td>
	</tr>
	</table>
	<table class="adminlist" cellspacing="1">
		<thead>
			<tr>
				<th width="1%"><?php echo JText::_( 'Num' ); ?></th>
				<th class="title" width="20%">
					<?php echo JHTML::_('grid.sort',  JText::_('NAME'), 'i.lib_name', @$lists['order_Dir'], @$lists['order'] ); ?>
				</th>
				<th class="title" width="10%">
					<?php echo JText::_('TYPE'); ?>					
				</th>
				<th class="title" width="5%">
					<?php echo JText::_('VERSION'); ?>					
				</th>
				<th class="title" width="5%">Package</th>		
				<th width="1%">
					<?php echo JHTML::_('grid.sort',  JText::_('ID'), 'i.lib_id', @$lists['order_Dir'], @$lists['order'] ); ?>
				</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="11">
					<?php echo $pageNav->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
		<?php 
		$k	= 0;
		$link	= 'index.php?option='.$option.'&controller=browse&task=detail&cid[]=';
		for ($i=0, $n = count($rows); $i<$n; $i++) {
			$row	= &$rows[$i];
			$package	= strval($row->install_pk);
			?>
			<tr class="<?php echo "row$k";?>">
				<td align="center"><?php echo $pageNav->getRowOffset( $i ); ?></td> 
				<td>
					<a href="<?php echo $link.$row->id;?>"><?php echo $row->name; ?></a>
					<?php
					if($row->commercial == 1)
						echo  '<img src="'.JURI::base().'components/com_obupdater/assets/images/icons/ext_commercial.png" width="16" height="16" alt="Commercial" title="Commercial" />';
					?>
				</td>				
				<td nowrap="nowrap">
					<?php echo '<span class="ext-img">'.JUCommon::getExtImg($row->type).'</span>';?>
				</td>
				<td align="center"><?php echo $row->version; ?></td>
				<td><?php echo $package==''?'<i style="color:#bbbbbb;">None</i>':$package;?></td>
				<td align="center"><?php echo $row->id; ?></td>
			</tr>
			<?php 
			$k = 1-$k;
		}?>
	</table>
	<input type="hidden" name="option" value="<?php echo $option; ?>" />
	<input type="hidden" name="task" value="" />	
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="filter_order" value="<?php echo $lists['order']; ?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $lists['order_Dir']; ?>" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>