<?php
/**
* @package		jLord Core
* @author 		Thong Tran - The Joomlord Team.
* @copyright	Copyright (C) 2008 The Joomlord Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		form.php 1.5.0.1	20081119.1635	thongta
* 20081120.1635	thongta	- modified copyright information
*/

global $mainframe,$option;
$search	= $mainframe->getUserStateFromRequest($option.'search','search','','string');
$row	= $this->res;
//echo '<pre>';print_r($row);echo '</pre>';
$server		= 'http://'.JUInstaller::getServer().'/';  
$path_img	= JURI::base().'components'.DS.$option.DS.'assets'.DS.'images'.DS.'icons';

$vers = $row->versions->children();
$cuVer = '';
if(isset($vers[0])){
	$cuVer	= JUCommon::getCuVer($vers[0]->ext_name,$vers[0]->type);	
}
if($cuVer=='') $cuVer = '<i>None</i>';
?>
<script>
function submitbutton(pressbutton){
	if(pressbutton=='cancel')pressbutton='goextension';
	if(goCtrl(pressbutton)) return false;	
}
</script>
<style>.ext-img img{margin-right:3px;}</style>
<?php
JToolBarHelper::title(JText::_('Extension').' - '.$row->name, 'extensions.png');
?>

<div style="padding-left: 100px;">
	<form action="index.php?option=<?php echo $option;?>&controller=browse" method="POST" name="adminForm" id="adminForm">
		Extension: <input type="text" name="search" value="<?php echo $search; ?>" onfocus="this.select();"/>		
		<input type="hidden" name="task" value=""/>
		<input type="hidden" name="rsfirst" value="0"/>
		<input type="submit" value="Search"/>
		<input type="button" value="I'm Feeling Lucky" onclick="this.form.rsfirst.value='1';this.form.submit();"/>		
	</form>
</div>	

<table cellspacing="0" cellpadding="0" border="0" width="100%">
	<tr>
		<td valign="top" width="50%">
			<fieldset class="adminForm">
			<legend>Details</legend>
			<table class="admintable">
			<?php if (count($row)) {?>
				<tr>
					<td width="80" align="right" class="key">Product name:</td>
					<td>
						<?php echo $row->name;?>
					</td>
				</tr>
				<tr>
					<td width="80" align="right" class="key">Type</td>
					<td nowrap="nowrap">
						<?php echo '<span class="ext-img">'.JUCommon::getExtImg($row->lib_type).'</span>';?>
					</td>		
				</tr>
				<tr>
					<td width="80" align="right" class="key">Current version</td>
					<td><?php echo $cuVer;?></td>
				</tr>				
				<tr>
					<td width="80" align="right" class="key">Newest version</td>
					<td><?php echo $row->last_version;?></td>
				</tr>
				<tr>
					<td width="80" align="right" class="key">Urls</td>
					<td>
						<?php if($row->url_download!=''){ ?>						
							<span><a target="_blank" href="<?php echo $row->url_download;?>">Download</a></span> |
						<?php }?>
						<?php if($row->url_support!=''){ ?>						
							<span><a target="_blank" href="<?php echo $row->url_support;?>">Support</a></span> |
						<?php }?>
						<?php if($row->url_demo!=''){ ?>						
							<span><a target="_blank" href="<?php echo $row->url_demo;?>">Demo</a></span> |
						<?php }?>
						<?php if($row->url_docs!=''){ ?>						
							<span><a target="_blank" href="<?php echo $row->url_docs;?>">Document</a></span> |
						<?php }?>
						<?php if(intval($row->jed_id)>0){ ?>						
							<span><a target="_blank" href="http://extensions.joomla.org/extensions/<?php echo $row->jed_id;?>">JED</a></span>
						<?php }?>
					</td>
				</tr>
				<tr>
					<td width="80" align="right" class="key">Description:</td>
					<td>
						<?php echo '<img src="'.$server.$row->lib_image.'" align="left" style="padding-right: 5px;" alt="'.$server.$row->lib_image.'"/>'; ?>
						<?php echo $row->description;?>
					</td>
				</tr>						
				<?php }?>
			</table>
			</fieldset>	
		</td>
		<td valign="top">
			<fieldset class="adminForm">
			<legend>Versions</legend>
			<table class="adminlist">
				<thead>
					<tr>
						<th class="key" width="1%">#</th>
						<th class="key" width="25%">Install Package</th>								
						<th class="key" width="1%">version</th>
						<th class="key" width="1%">Commercial</th>								
						<th class="key" width="15%">Action</th>								
					</tr>
				</thead>
				<tbody>
					<?php 
				$k = 0;$i = 0;										
				if ($vers) {
					$model 	= $this->getModel();
					//echo '<pre>';print_r($vers);echo '</pre>';							
					$url = 'index.php?option=com_obupdater&controller=browse';
					foreach ($vers as $obj) {
						$actUrl		= $url.'&lid='.$row->id.'&ver='.$obj->version.'&ex_type='.$obj->type;
						$action		= '<a href="'.$actUrl.'&task=juinstall"><span style="padding:0px 5px;">Install</span></a>';
						$action 	.= $obj->patch_pk=='yes'?'/<a href="'.$actUrl.'&task=juupgrade"><span style="padding:0px 5px;">Upgrade</span></a>':'';
						
						$status 	= $model->getLibStatus($obj, $obj->ext_name);
						if($obj->install_pk!=''){
							$maction = array('task'=>'juinstall','title'=>'Install');	
						}else $maction = array('task'=>'','title'=>'None package');						
						if($status && $status['version']){
							$vcp = version_compare($obj->version,$status['version']);
							if($vcp==0){
								$vfolder = $obj->plg_group?"&folder=$obj->plg_group":"";
								$maction = array('task'=>"juuninstall&type=".$obj->type."&lib_code=".$obj->ext_name.$vfolder,'title'=>"UnInstall");
							}elseif($vcp=="1"){
								if($obj->patch_pk=='yes'){
									//$maction = array('task'=>"juupgrade",'title'=>"Upgrade");//
									$maction = array('task'=>"update",'title'=>"Update");//											
								}else {
									$maction = array('task'=>"",'title'=>"None Pacth");
								}
							} else {
								$maction = array('task'=>"",'title'=>"Old Version");
							}
						}
					?>
					<tr class="<?php echo "row$k";?>">
						<td align="right"><?php echo ++$i;?></td>
						<td><?php echo $obj->install_pk;?></td>
						<td align="center"><?php echo $obj->version;?></td>
						<td align="center"><?php echo ($obj->commercial == 1) ? "Yes" : "No";?></td>
						<td align="center">
						<?php if($maction['task']!=''){
							if($maction['task']=='update'){
								?><a href="<?php echo$url.'&task='.$maction['task'].'&type='.$obj->type.'&code='.$obj->ext_name.'&tover='.urlencode($obj->version);?>" title="<?php echo $maction['title'] ?>"><?php echo $maction['title'] ?></a><?php
							}else {
								?><a href="<?php echo$actUrl.'&task='.$maction['task'] ?>" title="<?php echo $maction['title'] ?>"><?php echo $maction['title'] ?></a><?php	
							}
						}else echo '<i>'.$maction['title'].'</i>';?>
						</td>
					</tr>
					<?php $k = 1 - $k;
					}
				}else { ?>
					<tr>
						<td colspan="5"><center><i>None Data</i></center></td>								
					</tr>
				<?php }?>
				</tbody>
			</table>
			</fieldset>	
		</td>
	</tr>
</table>
