<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
//type,code,tover
$type	= JRequest::getCmd('type','');
$code	= JRequest::getCmd('code','');
$tover	= JRequest::getString('tover','');
$tover	= urlencode($tover);

?>
<script>
function getPatch(){
	var type = '<?php echo $type;?>';	
	var code = '<?php echo $code;?>';
	var tover = '<?php echo $tover;?>';
	var url	= 'index.php?option=<?php echo $option; ?>&controller=browse&task=extgetpatch&type='+type+'&code='+code+'&tover='+tover;
	var msg	= gelid('re-upg');
	msg.innerHTML	= '<i>Loading ...</i>';
	var req = new Ajax(url,{
		onComplete: function(txt){			
			msg.innerHTML = txt;					
		}
	}).request();	
	
}
function submitbutton(pressbutton){
	if(pressbutton=='cancel')pressbutton='goextension';
	if(goCtrl(pressbutton)) return false;
	submitform( pressbutton );
	return;
}
window.addEventListener('load',function(){
	getPatch();
},true);
</script>
<form id="adminForm" name="adminForm" method="POST" action="index.php?option=com_obupdater">
	<input type="hidden" value="" name="task" />
</form>
<div id="re-upg">&nbsp;</div>