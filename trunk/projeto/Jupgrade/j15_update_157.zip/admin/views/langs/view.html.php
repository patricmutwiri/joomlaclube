<?php
/**
* @package		jLord Core
* @author 		Thong Tran - The Joomlord Team.
* @copyright	Copyright (C) 2008 The Joomlord Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		view.html.php 1.5.0.1	20081119.1635	thongta
* 20081120.1635	thongta	- modified copyright information
*/

// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.view');

class FooblaCoreViewLangs extends JView
{
	function display($tpl = null)
	{
		global $option;
		JHTML::stylesheet( 'jlord_core.css', 'administrator'.DS.'components'.DS.$option.DS.'assets'.DS );
		if(JRequest::getVar('task','showlanguage') == 'showlanguage') {
			JToolBarHelper::title( JText::_('jLord Core - Langs'), 'jlord-langs.png' );
			JToolBarHelper::editList('getrwlanguage');
			//JToolBarHelper::preferences('com_obupdater', 500, 700, 'Settings');
			//JToolBarHelper::help('langs.html', true);
			$res = $this->get('language');
			$this->assignRef('res',$res);
		} elseif(JRequest::getVar('task','showlanguage') == 'search_keyword') {
			JToolBarHelper::title( JText::_('jLord Core - Langs: <small><small>[ Search and Update] </small></small>'), 'jlord-langs.png' );
			JToolBarHelper::save('save_into_file');
			//JToolBarHelper::preferences('com_obupdater', 500, 700, 'Settings');
			//JToolBarHelper::help('langs.html', true);
			JToolBarHelper::cancel('cancelSearch');
			$search_keyword = $this->get('search_keyword');
			$this->assignRef('search_keyword',$search_keyword);
		} elseif (JRequest::getVar('task','showlanguage') == 'newline') { 
			JToolBarHelper::title( JText::_('jLord Core - Langs: <small><small>[ Edit] </small></small>'), 'jlord-langs.png' );
			JToolBarHelper::save('insert_newline');
			//JToolBarHelper::preferences('com_obupdater', 500, 700, 'Settings');
			//JToolBarHelper::help('langs.html', true);			
			JToolBarHelper::cancel('cancelAddLine');
		} else {
			JToolBarHelper::title( JText::_('jLord Core - Langs: <small><small>[ Edit] </small></small>'), 'jlord-langs.png' );
			JToolBarHelper::addNew('newline','Add Line');
			JToolBarHelper::save('save_language');
			//JToolBarHelper::preferences('com_obupdater', 500, 700, 'Settings');
			//JToolBarHelper::help('langs.html', true);			
			JToolBarHelper::cancel('cancelLangs');
			$display = $this->get( 'rwlanguage');
			if(isset($display->total)) {
				$total = $display->total;
			}
			$this->assignRef( 'rwlanguage',	$display);
			$this->assignRef( 'totalObject',$total);	
		}
		parent::display($tpl);
	}
} // end class
?>