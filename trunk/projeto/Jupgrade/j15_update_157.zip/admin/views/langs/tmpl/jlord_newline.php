<?php
/**
 * JLord Core component for Joomla 1.5 Native
 * @author		Thong Tran - The Joomlord Team
 * @copyright	Copyright (C) 2008 The Joomlord Team. All rights reserved.
 * @package		JLord Core
 * @version		1.5.0.1
 */

// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
?>
<script type="text/javascript">
function submitbutton(pressbutton){
	if(pressbutton=='insert_newline') {
		if(document.getElementById('jlord_character_defined').value == '') {
			alert('You can entre into least a character ');
			document.getElementById('jlord_character_defined').focus();
			return false;
		} else if(document.getElementById('jlord_character_update').value == '') {
			alert('You can entre into least a character ');
			document.getElementById('jlord_character_update').focus();
			return false;
		} else {
			submitform(pressbutton);
			return;
		}
	} else {
		submitform(pressbutton);
		return;
	}
}
</script>
<?php 
	$cid = JRequest::getVar('cid');
	$cid = $cid[0];
?>
<form action ="index.php?option=com_obupdater" method="POST" name="adminForm" id ="adminForm" >
	<table class="adminform">
		<tr>
			<td>
				<label for="title">
					Comment:				
				</label>
			</td>
			<td>
				<input type="text" value="" maxlength="255" size="40" id="jlord_comment" name="jlord_comment" class="inputbox"/>
			</td>
		</tr>		
		<tr>
			<td>
				<label for="title">
					Character defined:				
				</label>
			</td>
			<td>
				<input type="text" value="" maxlength="255" size="40" id="jlord_character_defined" name="jlord_character_defined" class="inputbox"/>
			</td>
		</tr>		
		<tr>
			<td>
				<label for="title">
					Update Character Language:				
				</label>
			</td>
			<td>
				<input type="text" value="" maxlength="255" size="40" id="jlord_character_update" name="jlord_character_update" class="inputbox"/>
			</td>
		</tr>
	</table>
	<input type="hidden" value="langs" name ="controller" />
	<input type="hidden" value="" name ="task" />
	<input type="hidden" value="<?php echo $cid;?>" name ="cid[]" />
</form>