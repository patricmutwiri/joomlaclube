<?php
/**
* @package		jLord Core
* @author 		Thong Tran - The Joomlord Team.
* @copyright	Copyright (C) 2008 The Joomlord Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		view.html.php 1.5.0.1	20081119.1635	thongta
* 20081120.1635	thongta	- modified copyright information
*/

// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.view');

class FooblaCoreViewJupgrade extends JView {
	function display($tpl = null) {
		$task	= JRequest::getVar('task');
		switch ($task){
			case 'baklist':
				JToolBarHelper::title(JText::_('Joomla Restore'), 'upgrade.png');
				JToolBarHelper::custom('back','back','back','Back',false);
				JToolBarHelper::divider();
				$res 	= $this->get('Backups');
				$this->assignRef('res',$res);
				break;
			default:
				JToolBarHelper::title(JText::_('Joomla Upgrade'), 'upgrade.png');			
				JToolBarHelper::custom('baklist','restore','restore','Restore',false);
				JToolBarHelper::divider();
		}
				
		JUCommon::getToolBarDefault();
		parent::display($tpl);
	}
}