<?php 
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
?>
<script>
function submitbutton(pressbutton){
	if(pressbutton=='back')pressbutton='gojupgrade';
	if(goCtrl(pressbutton)) return false;
	submitform( pressbutton );
	return;
}</script>
<form id="adminForm" name="adminForm" method="POST" action="index.php?option=com_obupdater">
	<input type="hidden" value="" name="task" />
</form>
<?php
$res	= $this->res;
if(!$res) {
	echo '<div align="center"><b><i>None !</i></b></div>';
	return;
}
$ext	= $res->ext;
$backups	= $res->items;
$info	= $res->info;
$key	= $res->key;
$extLists	= $res->extlist;

$extListsTxt	= '';
$url = 'index.php?option=com_obupdater&controller=jupgrade&task=baklist&ext=';
for($i=0;$i<count($extLists);$i++){
	$name = $extLists[$i];
	if($ext == $name)$name = "<b>$name</b>";
	$extListsTxt .= "<li><a href=\"$url$extLists[$i]\">$name</a></li>";
}
//echo '<pre>';print_r($backups);echo '</pre>';
$lists	= '';
$title	= '<i>None</i>';
for($i=0;$i<count($backups);$i++){	
	if($key== $backups[$i]->key){
		$name	= '<b>'.$backups[$i]->info.'</b>';		
		$title	= $backups[$i]->info;
	}else $name = $backups[$i]->info;
	$lists .=  '<li><a href="'.$url."$ext&f=".$backups[$i]->key.'">'.$name.'</a></li>';
}
?>
<style type="text/css">
	.dev-col{
		float: left;
		border: 1px solid #dddddd;
		padding: 10px;
		margin: 5px 2px
	}
</style>
<div>
	<div class="dev-col">
		<b>Log detailt:</b> 
		<?php echo $title; ?>
		<?php if($res->reStore!=''){
			echo '<span style="float:right;">[ <a href="index.php?option=com_obupdater&task=restore&controller='.$res->reStore.'"><b>Restore</b></a> ]</span>';			
		}?>
		<hr />		
		<?php echo $info?$info:'<i>none</i>';?>
	</div>
	<div class="dev-col"><b>Upgrade logs: <span style="color: #3366cc;"><?php echo $ext?></span></b><hr /><?php echo $lists==''?'<i>None</i>':"<ol>$lists</ol>";?></div>
	<div class="dev-col"><b>Extensions updated list</b><hr />
	<?php echo $extLists==''?'<i>None</i>':"<ol>$extListsTxt</ol>";?></div>	
</div>