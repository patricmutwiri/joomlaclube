var jucHost,jucNo=false;
function jucRun(){
	checkJVer();
	var divMsg = document.createElement('div');
		divMsg.style.display = 'none';
		document.getElementsByTagName('body')[0].appendChild(divMsg);	
	function checkUpdateJuc(){
		var url = jucHost+'index.php?juctask=checkupdate';
		divMsg.innerHTML = '<i>Loading...</i>';
		var req = new Ajax(url,{
			onComplete: function(res){
			divMsg.innerHTML	= res;
			if(gid('cronupd-stop').value=='0'){
				checkUpdateJuc();
			}else if(jucNo) {
				getJUCExtState();
			}
		}
		}).request();
	}
	function checkJVer(){
		var url = jucHost+'index.php?juctask=checkver';
		var req = new Ajax(url,{
			onComplete: function(res){
				if(jucNo)jucNotice(res);
				checkUpdateJuc();
			}
		}).request();
	}
	function getJUCExtState(){		
		var jver = gid('juc0727');
		if(!jver)return;		
		var url = jucHost+'index.php?juctask=getudstate';
		var req = new Ajax(url,{
			onComplete: function(res){
				var pjvr = jver.parentNode;		
				var spanExt = document.createElement('span');		
				pjvr.appendChild(spanExt);
				spanExt.innerHTML = res;
			}
		}).request();	
	}
	function jucNotice(res){
		var head = document.getElementById('border-top');
		if(!head)return;
		var span = head.getElementsByTagName('span');	
		for(var i=0;i<span.length;i++){
			if(span[i].className == 'version'){
				var spanMsg = document.createElement('span');
					spanMsg.id='juc0727';
				span[i].appendChild(spanMsg);
				spanMsg.innerHTML = res;
				showInv();
				break;
			}
		}
	}
	
	function gid(id){return document.getElementById(id);}
	function showInv(){
		var dashboard	= gid('juc-check-jupgarde');
		if(!dashboard)return;
		jucCheckJver();
		
		var showInv	= gid('juc-show-inv');	
		if(!showInv)return;
		jucShowInv();
	}	
}