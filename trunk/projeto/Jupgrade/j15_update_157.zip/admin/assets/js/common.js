function gelid(id){return document.getElementById(id)}
function goCtrl(ctrl){
	var ctr;
	switch(ctrl){
		case 'godashboard':ctr='';break;
		case 'goextension':ctr='browse';break;
		case 'gojupgrade':ctr='jupgrade';break;
		case 'goabout':ctr='about';break;
		default:return false;
	}
	ctr = 'index.php?option=com_obupdater'+(ctr!=''?'&controller='+ctr:'');
	document.location = ctr;
	//alert(ctrl);
	return true;
}
function uninstall(el){
	var answer = confirm('Are you sure you want to Uninstall this extension?');
	if (answer){
		el.parentNode.innerHTML='<b>Uninstalled</b>';
	}
}
