<?php 
defined("_JEXEC") or die("Cannot Access!");

class JUCEnvironment {
	public $libraries 	= array('curl','json','zlib');
	public $dirpaths 	= array();

	public function __construct() {
		global $mainframe;
		$tmpdir = $mainframe->getCfg('tmp_path');
		$this->dirpaths = array(
			$tmpdir
		);
	}

	public function isLoaded($exname){
		if($exname){
			return extension_loaded($exname);
		}
		return false;
	}

	public function isCurlLoaded(){
		$res->loaded = $this->isLoaded('curl');
		$res->message = JText::_("Curl");
		return $res;
	}

	public function isJsonLoaded(){
		$res->loaded = $this->isLoaded('json');
		$res->message = JText::_("Json");
		return $res;
	}

	public function isZlibLoaded(){
		$res->loaded = $this->isLoaded('zlib');
		$res->message = JText::_("Zlib");
		return $res;
	}

	public function phpVersion(){
		$version = phpversion();
		$no	= version_compare($version,'5.2.1') >=0;		
		$res->loaded = $no;
		$res->message = 'PHP version: <b>'.$version.'</b>'.($no?'':' ( Need >= 5.2.1 )');
		return $res;
	}
	
	public function isWriteable($dirpath){
		$res->dirpath 		= $dirpath;
		$res->is_writable 	= is_writable($dirpath);
		return $res;
	}
	
	public function isWriteables(){
		$arr_dir = $this->dirpaths;
		$arr_res = array();
		for($i=0; $i<count($arr_dir); $i++){
			$arr_res[] = $this->isWriteable($arr_dir[$i]);
		}
		return $arr_res;
	}
}
?>