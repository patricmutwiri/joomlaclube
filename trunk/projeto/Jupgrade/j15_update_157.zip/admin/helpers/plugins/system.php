<?php
/**
* @package		Joomla Updater Creator
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.6
*/
define('JUC_HELPER', realpath(dirname(__FILE__).'/../').DS );
define('JUC_CRONOFF', JPATH_ROOT.DS.'cache'.DS.'juc'.DS.'cronoff.html');	  
class JUC_Plugin_system { 
	function run(){
		$task	= JRequest::getVar('juctask','ajax');		
		if($task!='ajax'){
			require_once JUC_HELPER.'common.php';
			$envErr = JUCommon::envErr();
			if($envErr > 0){
				$notice	= ' [ <b style="color:#ff9900;">JUC Notice: </b><a style="color:#ff0000;" href="index.php?option=com_obupdater"><b id="juc-show-inv">Environment not full!</b> ('.$envErr.')</a> ]';
				exit($notice);
			}
			//if($task == 'checkver')JUC_Plugin_system::countCron();
		}
		switch ($task){
			case 'checkver':JUC_ABC::checkVer();break;
			case 'checkupdate':
				require_once JUC_HELPER.'cron'.DS.'extupdate.php';
				JUC_ExtUpdate::checkRun();exit();break;
			case 'clearcache':JUC_ABC::clearCache();break;
			case 'setcron':JUC_ABC::setCron();break;
			case 'getudstate':
				require_once JUC_HELPER.'cron'.DS.'extupdate.php';
				$needUp	= JUC_ExtUpdate::getUdState();
				if($needUp > 0){
					echo '[ <a href= "index.php?option=com_obupdater"><b style="color:#ff6600;">Update Extensions ('.$needUp.')</b></a> ]'; 
				}else echo '&nbsp;';
/*				if($needUp > 0){
					$msg	= 'Update Extensions ('.$needUp.')';
					$color	= 'ff6600';					
				}else{
					$msg	= 'Not found any extension need to update';
					$color	= '00ff00';
				}
				echo '[ <a href= "index.php?option=com_obupdater"><b style="color:#'.$color.';">'.$msg.'</b></a> ]';*/
				exit();break;
			default:JUC_Plugin_system::runAjax();				
		}
	}
	function countCron(){
		$pathC	= JUC_CACHE.'countcron'.DS.date('Y-m-d').'.html';		
		if(!JUCommon::createIndexHtml($pathC)){
			if(isset($_GET['x'])){echo '<br/>azx[1]<br/>';}
			return;
		}
		$info	= @file_get_contents($pathC);
		$info	= @json_decode($info);
		if(!is_object($info)) $info	= new stdClass();
		$h		= date('H');
		$info->$h	= isset($info->$h)?(intval(@$info->$h) + 1):1;		
		file_put_contents($pathC,json_encode($info));		
	}
	function runAjax(){
		if(JUC_ABC::cronOff())return;
		global $mainframe;
		$host	= JURI::root();
		$js	= "jucHost='$host';window.addEvent('domready',function(){jucRun();});";		
		if($mainframe->isAdmin() && @$_REQUEST['option']!='com_installer'){$js='jucNo=true;'.$js;}
		JHTML::_('behavior.mootools');
		$doc	= &JFactory::getDocument();
		$doc->addScript($host.'administrator'.DS.'components'.DS.'com_obupdater'.DS.'assets'.DS.'js'.DS.'jucscript.js');
		$doc->addScriptDeclaration($js, 'text/javascript');
	}
}
class JUC_ABC{
	function setCron(){
		$jukey	= JRequest::getCmd('jukey','');
		if($jukey == '') exit('<h4>No 1</h4>');			
		
		$url	= "&view=service&task=stopcron";
		echo '<br />'.date('Y-d-m H:i:s');
		$res = JUCommon::getJUSJson($url);		
		if(isset($res->error)){
			echo $res->msg;exit();		
		}
		$key	= @$res->key;
		if(($key=='0' || $jukey != $key)) exit('<h4>No 2</h4>'); 
		if(isset($_GET['x'])){			
			echo '<br />Key: '.$key;
			echo '<br />'.date('Y-d-m H:i:s');
		}			
		$off = JRequest::getInt('off',0);
		echo "<br />Cron off: [ ".JUC_ABC::getCronState()." ]";
		@file_put_contents(JUC_CRONOFF,"$off");
		echo " => [ ".JUC_ABC::getCronState()." ]";
		echo "<br /><b style=\"color:#009900;\"><br />Change state Cronjob success!</b>";
		exit();
	}
	function getCronState(){
		if(!is_file(JUC_CRONOFF)) return '0';		
		return @file_get_contents(JUC_CRONOFF);		
	}
	function cronOff(){
		$off	= (int)JUC_ABC::getCronState();
		$off	= $off>0?true:false;		
		return $off;
	}
	function clearCache(){
		jimport('joomla.filesystem.file');
		$cachePath	= JPATH_ROOT.DS.'cache'.DS.'juc';
		if (is_dir($cachePath)) {
			$msg	= 'Clear '.(!JFolder::delete($cachePath)?'Fail':'Success'); 
		}else $msg	= 'JUC cache don\'t exist ['.$cachePath.']';
		exit($msg);
	}
	function checkVer(){
		$JCVer	= JUCommon::getJCurVer();
		$JLVer	= JUCommon::getJLastVer();
		$upgrUrl	= 'index.php?option=com_obupdater';	
		if($JLVer==$JCVer){
			$notice = ' [ <a href="'.$upgrUrl.'" title="check version"><span style="color:#00ff00;"><b>Latest Version</b></span></a> ]'; 
		}else {			
			$obConfig	= JUCommon::getConfig();		
			if(isset($_GET['x'])){
				echo '<hr /><pre>';print_r($obConfig);echo '</pre><hr />';
			}
			if(@$obConfig->auto_ju == '1'){
				require_once JUC_HELPER.'jupgrade.php';
				$jUpdate	= new S4JUpdate();
				$jUpdate->checkRun($JCVer,$JLVer);
			}elseif(@$obConfig->notice_jupdate == '1'){
				JUC_ABC::noticeJupdate($JLVer,@$obConfig->to_mail);
			}
			$upgadeLink = ' [ <a style="color:#ffcc00;" href="'.$upgrUrl.'&controller=jupgrade"><b><blink>Upgrade now</blink></b></a> ]';		 		
			$notice	= ' [ <span style="color:#ff0000;">Latest version: <b>'.$JLVer.'</b></span> ]'.$upgadeLink;			
		}
		exit($notice);
	}
	function noticeJupdate($JLVer,$toMail){
		$cache	= JUC_CACHE.'noticejupdate.html';	
		if(is_file($cache)){
			$info	= file_get_contents($cache);
			$info	= json_decode($info);
			if(isset($_GET['x'])){
				//echo "[ $cache ]";
				echo '<pre>';
				print_r($info);
				echo '</pre>';
			}
			if(isset($info->newver) && $info->newver == $JLVer){
				return ;
			}
		}
		preg_match('/^[^@]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$/', $toMail,$check);		 
		if(!$check){
			return ;
			//exit('No run II');
		}
		$toName	= explode('@',$toMail);
		$toName	= ucfirst($toName[0]);
		
		$sender	= array('support@foobla.com', 'Foobla');
		
		$thisSite	= JURI::root();
		$urlUpdate	= $thisSite.'administrator/index.php?option=com_obupdater&controller=jupgrade';
		$subject	= "Verison $JLVer of Joomla has been released";		
		$msg	= "Hi $toName, <br /><br /> Version <b>$JLVer</b> of Joomla has been released. <br /><br />";
		$msg	.= "You should update for your joomla sites soon as possible!<br /><br />";
		$msg	.= "<b>Update now for <a href=\"$urlUpdate\">$thisSite</a></b>";
		$send	= JUCommon::sendMail($sender, $subject, $msg, $toMail);
				
		if(isset($_GET['x'])){
			echo '<br />Sendmail: ';
			var_dump($send);	
		}
		if($send){
			$info	= new stdClass();
			$info->newver	= $JLVer;
			$info->time	= date('Y-m-d H:i:s');
			$info	= json_encode($info);
			file_put_contents($cache,$info);					
		}
	}
}