<?php 
/**
* @package		Joomla Updater Creator
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.6
*/
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
define('JUC_CACHE', JPATH_ROOT.DS.'cache'.DS.'juc'.DS);
define('JUC_COM', 'com_obupdater');
class JUCommon{
	function sendMail($sender,$subject,$msg,$toMail,$hiName = false){		
		preg_match('/^[^@]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$/', $toMail,$check);				 
		if(!$check){
			return false;
		}
		if($hiName == true){
			$hiName	= explode('@',$toMail);
			$hiName	= ucfirst($hiName[0]);
			$msg	= "Hi $hiName, <br /><br />".$msg;
		}
		$mailer = &JFactory::getMailer();
		$mailer->setSender($sender);
		$mailer->addRecipient($toMail);
		$mailer->setSubject($subject);
		$mailer->setBody($msg);
		$mailer->IsHTML(1);
		$send = $mailer->Send();
		return $send;
	}
	function getConfig(){
		global $obJuConfig;
		if (empty($obJuConfig)){
			$path	= JPATH_ADMINISTRATOR.DS.'components'.DS.JUC_COM.DS.'config.xml';			
			$params	= &JComponentHelper::getParams(JUC_COM,$path);			
			$params	= $params->toObject();
			$obJuConfig = $params;			
		}
		return $obJuConfig; 		
	}
	function getJUSJson($url){
		$sever	= JUCommon::getJusHost();
		$dm		= JUCommon::getDomain();
		$url	= "http://$sever/index.php?option=com_joomlaupdater_server$url&dm=$dm";
		//exit($url);
		@$json	= file_get_contents($url);
		if(!$json){
			$res = new stdClass(); 
			$res->error = true;
			$res->msg	= JText::_('CONNECT_ERROR');//CONNECT_ERROR;			
		} else $res	= json_decode($json);
		return $res;	
	}
	function getExtList($type=''){
		$db		= &JFactory::getDBO();
		switch ($type){
			case 'com':$qry	= "SELECT `id`,`name`,`option` FROM #__components WHERE `parent`=0 AND `option`!='' AND `id` > 33 ORDER BY `id` DESC";break;
			case 'mod':$qry	= "SELECT `id`,`title`,`module`,`client_id` FROM #__modules WHERE `id` > 42 GROUP BY `module` ORDER BY `client_id`,`id`";break;
			default:$qry = "SELECT `id`,`name`,`element`,`folder` FROM #__plugins WHERE `id` > 33 ORDER BY `folder`,`id` DESC";
		}
		$db->setQuery($qry);
		$items	= $db->LoadObjectList();
		return $items;
	}
	function section($atc,$var,$val=''){
		$session	= &JFactory::getSession();		
		if($atc=='set'){
			$session->set($var, $val);	
		}else {
			return $session->get($var);			 	
		}
	}
	function debug(){
		$path	= strval(@$_REQUEST['p']);
		$path	= JPATH_ROOT.DS.'cache'.$path;			
		if(is_dir($path) || is_file($path)){				
			$perm	= fileperms($path);			
			$rs	= '[ chmod: '.substr(sprintf('%o',$perm), -4).' ] Path: '.$path;
		}else $rs = 'Path don\'t exist';
		return "$rs<br />";		
	}
	function envErr(){//return 4;
		if(isset($_GET['x'])){echo JUCommon::debug();}
		$juc_cache_test = JUC_CACHE.'checkenv.html';
		$today	= date('Y-m-d');	
		if(is_file($juc_cache_test)){
			$info	= @file_get_contents($juc_cache_test);
			if(!$info) return 3; //file_get_contents();			
			$info	= json_decode($info);
			if (!is_object($info))return 4; // JSON 				
			if($info->date == $today)return 0;
		}
		if(!JUCommon::createIndexHtml($juc_cache_test)) return 1; //Writable
		$info	= new stdClass();
		$info->date	= date('Y-m-d');
		$info->time	= date('H:i:s');
		$info->gmt	= gmdate('Y-m-d H:i:s');
		$info->ju	= '20100616';
		$info	= json_encode($info);
		if(!@file_put_contents($juc_cache_test,$info)) return 2; //file_put_contents();
		return 0;
	}
	function checkCache(){//return true;
		$juc_cache_test = JUC_CACHE.'check';
		$today	= date('Y-m-d');	
		if(is_file($juc_cache_test)){
			$info	= @file_get_contents($juc_cache_test);
			if(!$info) return false;
			elseif($info == $today)  return true; 	
		}
		if(!JUCommon::createIndexHtml($juc_cache_test)) return false;
		if(!@file_put_contents($juc_cache_test,$today)) return false;
		return true;
	}
	function checkExtVer($code,$type){
		$ext	= new stdClass();
		$ext->error	= '';
		$ext->cuVer	= JUCommon::getCuVer($code,$type);						
		$cacheVer	= JPATH_ROOT.DS.'cache'.DS.'juc'.DS.'extverinfo'.DS.$type.'_'.$code;
		$getOnline	= true;
		$today	= date('Y-m-d');
		if(is_file($cacheVer)){
			$info	= file_get_contents($cacheVer);
			$info	= json_decode($info);				
			if(@$info->date == $today && @$info->cuVer == $ext->cuVer){
				$getOnline	= false;
				$ext->lid	= $info->lid;				
			}
		}
		if($getOnline){
			$name	= JUCommon::getExtName($code,$type);		
			$url	= "&view=service&task=juccheckupgrade&ext=$code&type=$type&cuver=".urlencode($ext->cuVer)."&name=".urlencode($name);
			$res	= JUCommon::getJUSJson($url);
			if(isset($res->error)){
				$ext->error =  '<div title="'.$res->msg.'">'.JUCommon::getMsg('Error Access','error').'</div>';
				return $ext;
			} 
			$ext->date	= $today;
			$ext->lid	= intval($res->lid);			 
			JUCommon::createIndexHtml($cacheVer);
			file_put_contents($cacheVer,json_encode($ext));
		}
		if($ext->lid>0 && isset($res->nextVer))$ext->nextVer = $res->nextVer;
		return $ext;
	}
	function createIndexHtml($file){		
		$dir = dirname(JPath::clean($file));		
		if(!is_dir($dir)){
			$file = $dir.DS.'index1.html';
			jimport('joomla.filesystem.file');
			if(!JFile::write($file,'<html><body bgcolor="#FFFFFF">&nbsp;</body></html><html>'))return false;		
		}
		return true;
	}
	function getJCurVer(){ //return '1.5.17';
		$JVer	= new JVersion();
		$JCVer	= $JVer->getShortVersion();
		return $JCVer;
	}
	function getJLastVer(){ //return '1.5.20';
		$cPathVer	= JPATH_ROOT.DS.'cache'.DS.'juc'.DS.'jlatestver';		
		if(!is_file($cPathVer)){JUCommon::createIndexHtml($cPathVer);}
		$cacheVer = @file_get_contents($cPathVer);
		if($cacheVer){
			$cver = json_decode($cacheVer);
			if($cver->date == date('Y-m-d')){
				return $cver->lastver;
			}
		}
		$phpVer	= phpversion();
		$lVer = JUCommon::getJUSJson('&view=service&task=getjlastver&php='.urlencode($phpVer));
		if(isset($lVer->error) || $lVer->lastVer==''){
			return @$cver->lastver;
		}
		$lastVer	= $lVer->lastVer;					
		$res	= new stdClass();
		$res->lastver	= $lastVer;
		$res->date	= date('Y-m-d');
		@file_put_contents($cPathVer,json_encode($res));
		return $lastVer;
	}
	function getExtImg($extStr) {
		$extAlt = array(
			"com"		=> "Component",
			"mod"		=> "Module",
			"plugin"	=> "Plugin",
			"lang"		=> "Language",
			"speacial"	=> "Ext. Specific Addon", 
			"tool"		=> "Tool",
			"patch"		=> "Patch",
			"tem"		=> "Template",
			"new"		=> "New!"
		);		
		$extStr = trim(strval($extStr));
		if($extStr == '') {
			$extArr = array('unknow');					
		} else
			$extArr = explode('|',$extStr);		
		$host = &JURI::base();
		$imgPath	= $host.'components/com_obupdater/assets/images/icons/';
		$imgs	= '';
		#var_dump($extArr);
		foreach ($extArr as $ext){
			$alt	= isset($extAlt[$ext]) ? $extAlt[$ext]:$ext;
			if($ext=='New!') {
				$imgs .= "<span class=\"ext-new\">New!</span>&nbsp;";
			} else {
				$imgSrc	= strtolower($imgPath.'ext_'.$ext.'.png');
				$imgs .= "<img width=\"16\" height=\"16\" border=\"0\" alt=\"$alt\" title=\"$alt\" src=\"$imgSrc\" />";
			}
		}
		return $imgs;
	}
	function getDomain(){
		$dm = JURI::root();
		$dm = str_replace('http://','',$dm);
		$dm = str_replace('www.','',$dm);
		if(substr($dm,-1)=='/'){$dm	= substr($dm,0,-1);}
		return base64_encode($dm);		
	}
	function getJusHost(){
		return 'obupdater.com';
	}
	function getToolBarDefault(){
		global $option;
		
		$document = &JFactory::getDocument();
		$document->addStyleSheet('components/com_obupdater/assets/juc.css');

		#JToolBarHelper::divider();
		JToolBarHelper::custom('godashboard','cpanel','cpanel','Dashboard',false);
		JToolBarHelper::custom('goextension','extensions','extensions','Extensions',false);
		JToolBarHelper::custom('gojupgrade','upgrade','upgrade','Update Joomla',false);
		JToolBarHelper::custom('goabout','foobla','foobla','Support',false);	
		JHTML::script('common.js','administrator'.DS.'components'.DS.$option.DS.'assets'.DS.'js'.DS);		
	}
	
	function getExtInfo($code,$type){
		switch ($type){
			case 'com':
				jimport('joomla.filesystem.folder');
				$path = JPATH_ADMINISTRATOR.DS."components".DS.'com_'.$code;
				if(!is_dir($path))return '';
				$files = JFolder::files($path, '.xml', false, true);
				for($i = 0; $i < count($files);$i++ ){
					$info = JUCommon::getInfoFromXMLInstallFile($files[$i]);
					if($info) return $info;
				}
				break;
			case 'mod':				
				$path	= "modules".DS.'mod_'.$code.DS.'mod_'.$code.".xml";
				if(is_file(JPATH_SITE.DS.$path)) $path = JPATH_SITE.DS.$path;				
				else $path	= JPATH_ADMINISTRATOR.DS.$path;
				break;
			default:
				$group	= substr($type,(strpos($type,'.')+1)); 
				$path 	= JPATH_SITE.DS.'plugins'.DS.$group.DS.$code.'.xml';		
		}
		if(!is_file($path)){return false;}
		return JUCommon::getInfoFromXMLInstallFile($path);		
	}
	function getInfoFromXMLInstallFile($path) {
		$xml = &JFactory::getXMLParser('Simple');		
		if (!$xml->loadFile($path)) {			
			unset($xml);
			return false;
		}
		if ( !is_object($xml->document) || ($xml->document->name() != 'install' && $xml->document->name() != 'mosinstall')) {
			unset($xml);
			return false;
		}
		$root	= $xml->document;
		$type	= $root->attributes('type');
				
		switch ($type){
			case 'component':
				$name	= $root->name[0];
				$info->code	= strtolower(str_replace(" ", "",$name->data()));
				$info->type	= 'com';
				$method = @$root->attributes('method');				
				$info->upg_method = $method == 'upgrade'?'1':'0';
				break;
			case 'module':
				$info->type	= 'mod';
				$info->code	= substr(basename($path),4,-4);
				break;
			case 'plugin':
				$info->type	= 'plugin';
				$info->code	= substr(basename($path),0,-4);				
				$info->group = $root->attributes('group');
				break;
			default:
				return false;
		}
		$element = $root->version[0];
		$info->version = $element ? trim($element->data()) : '';		
		return $info;
	}
	function getExtName($code,$type){
		$db		= &JFactory::getDBO();
		switch ($type){
			case 'com':$qry	= "SELECT `name` FROM #__components WHERE `parent`=0 AND `option`='com_$code'";break;
			case 'mod':
				$path	= "modules".DS.'mod_'.$code.DS.'mod_'.$code.".xml";
				if(is_file(JPATH_SITE.DS.$path)) $path = JPATH_SITE.DS.$path;				
				else $path	= JPATH_ADMINISTRATOR.DS.$path;
				if(!is_file($path))	return '';
				$xml = &JFactory::getXMLParser('Simple');		
				if (!$xml->loadFile($path)) {
					unset($xml);
					return false;
				}
				if ( !is_object($xml->document) || ($xml->document->name() != 'install' && $xml->document->name() != 'mosinstall')) {
					unset($xml);
					return false;
				}
				$root	= $xml->document;				
				$name	= $root->name[0];
				return $name->data();				
				break;
			default:
				$qry = "SELECT `name` FROM #__plugins WHERE `element`='$code',`folder`='".substr($type,7)."'";
		}
		$db->setQuery($qry);
		$name	= $db->LoadResult();
		return $name;		
	}	
	function getCuVer($code,$type){
		switch ($type){
			case 'com':
				jimport('joomla.filesystem.folder');
				$path = JPATH_ADMINISTRATOR.DS."components".DS.'com_'.$code;
				if(!is_dir($path))return '';
				$files = JFolder::files($path, '.xml', false, true);
				for($i = 0; $i < count($files);$i++ ){
					$cuVer = JUCommon::getVersionFromXMLInstallFile($files[$i]);
					if($cuVer) return $cuVer;
				}
				break;
			case 'mod':				
				$path	= "modules".DS.'mod_'.$code.DS.'mod_'.$code.".xml";
				if(is_file(JPATH_SITE.DS.$path)) $path = JPATH_SITE.DS.$path;				
				else $path	= JPATH_ADMINISTRATOR.DS.$path;
				break;
			default:
				$group	= substr($type,(strpos($type,'.')+1)); 
				$path 	= JPATH_SITE.DS.'plugins'.DS.$group.DS.$code.'.xml';		
		}
		if(!is_file($path)){return '';}
		return JUCommon::getVersionFromXMLInstallFile($path);
	}
	function getVersionFromXMLInstallFile($path){
		if(!is_file($path))return '';
		$xml = & JFactory::getXMLParser('Simple');
		if (!$xml->loadFile($path)) {
			unset($xml);
			return '';
		}
		if ( !is_object($xml->document) || ($xml->document->name() != 'install' && $xml->document->name() != 'mosinstall')) {
			unset($xml);
			return '';
		}
		$element = &$xml->document->version[0];
		$version = $element ? $element->data() : '';			
		return $version;		
	}
	function getMsg($text,$type='error'){
		switch ($type){
			case 'error':$color	= 'ff2200';break;
			default:$color = 'ff2200';			
		}
		return '<div align="center" style="color:#'.$color.';"><b><i>'.$text.'</i></b></div>';		
	}
}
