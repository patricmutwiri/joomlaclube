<?php 
/**
* @package		Joomla Updater Creator
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.6
*/
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
define('JUC_UPDCRON', JUC_CACHE.'updcron');
define('JUC_EXTUPL', JUC_CACHE.'extupdl');
define('JUC_EXTCHECk', JUC_CACHE.'extcheck');
class JUC_ExtUpdate{
	function getUdState(){
		$extCheck	= @file_get_contents(JUC_EXTCHECk);
		$extCheck	= @json_decode($extCheck);
		$total = 0;
		if(!is_object($extCheck)) return $total;		
		if(isset($extCheck->com)){
			$total += count($extCheck->com);
		}
		if(isset($extCheck->mod)){
			$total += count($extCheck->mod);
		}
		if(isset($extCheck->plu)){
			$total += count($extCheck->plu);
		}
		return $total;
	}
	function checkRun(){
		if(isset($_GET['x'])){
			echo '<br>'.JUC_UPDCRON;
		}
		$info	= @file_get_contents(JUC_UPDCRON);
		$info	= json_decode($info);
		//echo '<pre>';print_r($info);echo '</pre>';
		$today	= date('Y-m-d');		
		$now	= time();
		//echo '<pre>';print_r($info);echo '</pre>';		
		if(!is_object($info) || @$info->date!=$today){
			$info	= new stdClass();
			$info->date	= $today;			
			$info->done	= '0';			
		}else {
			$runing	= intval(@$info->runing);
			if($runing>0 && $now-$runing<600){
				echo JUC_ExtUpdate::setStop('cronupd-stop','1');
				if(isset($_GET['x'])){
					echo '<pre>';
					print_r($info);
					echo '</pre>';
				}
				exit();
			}
			if(@$info->done	!= '0'){
				echo JUC_ExtUpdate::setStop('cronupd-stop','1');
				if(isset($_GET['x'])){
					echo '<pre>';
					print_r($info);
					echo '</pre>';
				}
				exit();
			}
		}
		$info->runing	= $now;
		file_put_contents(JUC_UPDCRON,json_encode($info));
		$done = JUC_ExtUpdate::checkUpdate();
		$info->done	= $done;
		$info->runing	= '0';
		file_put_contents(JUC_UPDCRON,json_encode($info));				
		echo JUC_ExtUpdate::setStop('cronupd-stop',$done);
		if(isset($_GET['x'])){
			echo '<pre>';
			print_r($info);
			echo '</pre>';
		}
		exit();
	}
	function infoInit(){
		$extCheck	= new stdClass();
		$extCheck->task	= 'checkCom';
		$extCheck->lastSend	= '0';
		$extCheck->willSend	= '0';
		$extCheck->com		= array();
		$extCheck->mod		= array();
		$extCheck->plu		= array();
		return $extCheck;
	}
	function checkUpdate(){		
		if(isset($_GET['x'])){
			echo '<br>'.JUC_EXTCHECk;
		}
		$extCheck	= @file_get_contents(JUC_EXTCHECk);
		$extCheck	= @json_decode($extCheck);
		$today	= strtotime('- 1 day');
		if(!is_object($extCheck)){
			$extCheck	= JUC_ExtUpdate::infoInit();
		}else {
			$lastSend	= intval(@$extCheck->lastSend);
			if($lastSend>0 && ($today - $lastSend > 432000)){
				$extCheck	= JUC_ExtUpdate::infoInit();
			}
		}
		if(isset($_GET['x'])){
			echo '<pre>';
			print_r($extCheck);
			echo '</pre>';
		}
		$task	= $extCheck->task;
				
		if($task != 'extNotice'){			
			$listUd	= JUC_ExtUpdate::$task();
			$type	= $listUd[0]->type;
			if (!in_array($type,array('com','mod'))) $type = 'plu';			
			$needUds= $extCheck->$type;
			for ($j=0;$j<count($listUd);$j++){
				$ud =  $listUd[$j];
				$isNew	= true;
				for ($i=0;$i<count($needUds);$i++){
					$need	= $needUds[$i];
					if($need->type == $ud->type && $need->code == $ud->code){
						$isNew	= false;										
					}
				}
				if($isNew){
					$extCheck->willSend	= '1';
					break;
				}
			}
			$extCheck->$type	= $listUd;
			$tasks	= array('checkCom','checkMod','checkPluin','extNotice');
			for($i=0;$i<4;$i++){
				if($tasks[$i]==$task){
					$extCheck->task	= $tasks[$i+1];
					break;
				}
			}
			$done = '0';
		}else {
			if($extCheck->willSend=='1'){
				$extCheck->lastSend = $today;//1280164978;
				$extCheck->willSend	= '0';	
				JUC_ExtUpdate::extNotice($extCheck);				
			}
			$extCheck->task	= 'checkCom';
			$done = '1';
		}
		//echo '<pre>Done: '.$done.'<br />Last send: '.date('Y-m-d H:i:s',$lastSend).' [ '.$lastSend.' ]<br />';print_r($extCheck);echo '</pre>';		
		file_put_contents(JUC_EXTCHECk,json_encode($extCheck));
		return $done;
	}
	function extNotice($extCheck){		
		//echo '<h3>Notice:</h3>';
		$obConfig	= JUCommon::getConfig();		
		if(@$obConfig->notice_extpdate!='1'){
			echo '<br>No run I';
			return false;
		}
		global $jucDm;		
		$jucDm	= JURI::root();		
		$msg = "There are some extensions need to update on your site ($jucDm)";
		$coms	= $extCheck->com;
		$msg	.= '<h4>The components need update:</h4>';
		$msg	.= JUC_ExtUpdate::getList($coms);
		
		$mods	= $extCheck->mod;
		$msg	.= '<h4>The modules need update:</h4>';
		$msg	.= JUC_ExtUpdate::getList($mods);
		
		$plus	= $extCheck->plu;
		$msg	.= '<h4>The Plugins need update:</h4>';
		$msg	.= JUC_ExtUpdate::getList($plus);

		$toMail	= @$obConfig->to_mail;
		$sender	= array('support@foobla.com','Foobla');
		$subject	= "Your site need update extension [ $jucDm ]";		
		$send	= JUCommon::sendMail($sender,$subject,$msg,$toMail,true);
		return $send;
	}
	function getList($items){
		global $jucDm;
		$html	= '';
		$edit	= $jucDm.'administrator/index.php?option=com_obupdater&controller=browse&task=detail&cid[]=';
		for ($i=0;$i<count($items);$i++){	
			$html .= '<li><a href="'.$edit.$items[$i]->lid.'">'.$items[$i]->name.'</a></li>';
		}
		$html	= $html != ''?"<ol>$html</ol>":'<i>None</i>';
		return $html;
	}
	function checkCom(){
		$listUd	= array();
		$coms	= JUCommon::getExtList('com');
		for ($i=0;$i<count($coms);$i++){
			$com	= $coms[$i];
			$code = substr($com->option,4);			
			$ext	= JUCommon::checkExtVer($code,'com');
			if($ext->lid > 0){
				$obj	= new stdClass();
				$obj->type	= 'com';
				$obj->code	= $code;
				$obj->name	= $com->name;
				$obj->lid	= $ext->lid;				
				$listUd[]	= $obj;
			}
		}
		return $listUd;
	}
	function checkMod(){
		$listUd	= array();
		$mods	= JUCommon::getExtList('mod');
		for ($i=0;$i<count($mods);$i++){
			$mod	= $mods[$i];
			$code = substr($mod->module,4);			
			$ext	= JUCommon::checkExtVer($code,'mod');
			if($ext->lid > 0){
				$obj	= new stdClass();
				$obj->type	= 'mod';
				$obj->code	= $code;
				$obj->name	= $mod->title;
				$obj->lid	= $ext->lid;							
				$listUd[]	= $obj;
			}
		}
		return $listUd;
	}
	function checkPluin(){
		$listUd	= array();
		$plugs	= JUCommon::getExtList('plugin');
		for ($i=0;$i<count($plugs);$i++){
			$plug	= $plugs[$i];
			$code	= $plug->element;
			$type	= 'plugin.'.$plug->folder;
			$ext	= JUCommon::checkExtVer($code,$type);
			if($ext->lid > 0){
				$obj	= new stdClass();
				$obj->type	= $type;
				$obj->code	= $code;
				$obj->name	= $plug->name;
				$obj->lid	= $ext->lid;				
				$listUd[]	= $obj;
			}
		}
		return $listUd;
	}
	function setStop($id,$value){
		return "<input type=\"hidden\" id=\"$id\" value=\"$value\"/>";
	}
}