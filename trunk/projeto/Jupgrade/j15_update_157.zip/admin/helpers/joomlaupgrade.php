<?php
/**
* @package		Joomla Updater
* @author 		loquocphong@gmail.com
* @copyright	Copyright (C) 2008 The Joomla! Updater Team. All rights reserved.
* @license		GNU
* @version		1.5.2 		
*/
class FooblaJoomlaUpgrade{
	public $cversion = '1.5.0';
	public $lversion = '[^-]+';
	
	public function __construct($cversion, $lversion){
		@session_start();
		if(!$cversion) $cversion = $this->cversion;
		if(!$lversion) $lversion = $this->lversion;
		$this->cversion = $cversion;
		$this->lversion = $lversion;
	}
	
	public function getUrlPages($content){
		$matches_all = null;
		preg_match_all('/\/gf\/project\/joomla\/frs\/\?action=\&amp;_br_pkgrls_total=\d+\&amp;_br_pkgrls_page=\d+/',$content,$matches_all);
		$pages = array();
		if(count($matches_all[0])){
			for($i=0;$i<count($matches_all[0]);$i++){
				$pages[] = "http://joomlacode.org".$matches_all[0][$i];
			}
		}
		return $pages;
	}
	
	function getLink() {
		global $option;
		$cversion = $this->cversion;
		$lversion = $this->lversion;
		$urlpages 	= null;
		if(isset($_SESSION['joomlacode_pages']) && count($_SESSION['joomlacode_pages'])){
			$urlpages = array_unique($_SESSION['joomlacode_pages']);
		}
		
		$url 		= "";
		$content 	= "";
		if(!count($urlpages)||!$urlpages){
			$url 		= "http://joomlacode.org/gf/project/joomla/frs";
			$url = str_replace("&amp;","&",$url);
			$content 	= file_get_contents($url);
			$urlpages 	= $this->getUrlPages($content);
			$_SESSION['joomlacode_pages'] 	= array_unique($urlpages);
			$_SESSION['mypages'] 			= array_unique($urlpages);
			$_SESSION['browses'][] 			= $url;
		} else {
			$url = $urlpages[0];
			$url = str_replace("&amp;","&",$url);
			$urlpages = array_slice($urlpages,1);
			$_SESSION['joomlacode_pages'] = $urlpages;
			$content = file_get_contents($url);
			$_SESSION['browses'][] 			= $url;
		}
		
		$down_urls 	= array();
		if(isset($_SESSION['joomlacode_down_urls']) && count($_SESSION['joomlacode_down_urls'])){
			 $down_urls = array_unique($_SESSION['joomlacode_down_urls']);
		}
		$matches_all = null;
		preg_match_all("/\/gf\/download\/frsrelease\/\d+\/\d+\/Joomla_".$cversion."_to_$lversion-Stable-Patch_Package.zip/",$content,$matches_all);
		if(count($matches_all[0])){
			for($i = 0; $i < count($matches_all[0]); $i++){
				$down_urls[] = "http://joomlacode.org".$matches_all[0][$i];
			}
		}
		
		$_SESSION['joomlacode_down_urls'] = array_unique($down_urls);
		$_SESSION['joomlacode_debug'][] = $matches_all;
	
		if (!count($_SESSION['joomlacode_pages'])) {
			#echo json_encode($_SESSION['joomlacode_down_urls']);
			$res = $_SESSION['joomlacode_down_urls'];
			unset($_SESSION['joomlacode_down_urls']);
			unset($_SESSION['joomlacode_pages']);
			unset($_SESSION['mypages']);
			unset($_SESSION['browses']);
			unset($_SESSION['joomlacode_debug']);
			return $res;
		} else {
			if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS'])) {
				$uri = 'https://';
			} else {
				$uri = 'http://';
			}
			$uri 		.= $_SERVER['HTTP_HOST'];
			$controller	= 'jupgrade';
			$task 		= $_REQUEST['task'];
			header('Location: '.$uri.$_SERVER['SCRIPT_NAME']."?option=$option&controller=$controller&task=$task&cversion=$cversion&lversion=$lversion");
			exit();
		}
	}
}
//$cversion = $_REQUEST['cversion'];
//$lversion = $_REQUEST['lversion'];
//
//$x = new FooblaJoomlaUpgrade($cversion,$lversion);
//$x->getLink();