<?php
/**
* @package		Joomla Updater
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		2009-12-05 10h00 AM
*/
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
define('JUC_UDINFO', JUC_CACHE.'jupdateinfo');
define('JUC_UDRUNING', JUC_CACHE.'runing');
define('JUC_UDLOGS', JUC_CACHE.'jupdatelog.html');
define('JUC_BACKUP',JPATH_ADMINISTRATOR.DS.'backups'.DS.'jubackup'.DS);
jimport("joomla.filesystem.folder");
jimport("joomla.filesystem.file");
class S4JUpdate{
	function isRuning(){ return false;
		$runAt	= intval(@file_get_contents(JUC_UDRUNING));
		if($runAt>0){if(time()-$runAt<600)return true;}
		file_put_contents(JUC_UDRUNING,time());
		return false;
	}
	function checkOut(){
		file_put_contents(JUC_UDRUNING,'0');
	}
	function saveInfo($info){
		$info	= json_encode($info);
		file_put_contents(JUC_UDINFO,$info);
	}
	function saveLog($logs){
		file_put_contents(JUC_UDLOGS,$logs,FILE_APPEND);
	}
	function seachPatch(&$info,&$logs='') {
		$rows	= JUCommon::getJUSJson("&view=service&task=getjpatch&curver=$info->cVer&newver=$info->lVer");	
		if(isset($rows->error)){
			$logs .= "<b style=\"color:#ff3300;\">".$rows->error.' [ '.@$rows->msg.' ]</b>';
		}elseif (isset($rows->patch) && substr($rows->patch,0,4)=='http'){
			$info->patchLink	= $rows->patch;						
			$logs .= "<b style=\"color:#009900;\">Found: </b> $rows->patch";
			return 1;
		}else $logs .= "<b style=\"color:#ff3300;\">Result error: $rows->patch )</b>";		
		return 0;
	}	
	function getPatch(&$info,&$logs){
		if(!isset($info->patchLink)){
			$logs .= 'patchLink don\'t exist';
			return -1;
		}
		$logs .= date('Y-m-d H:i:s').' [ Start download ]<br />';
		jimport("joomla.installer.helper");
		$info->tmpFile = JInstallerHelper::downloadPackage($info->patchLink);		
		//$info->tmpFile = 'Joomla_1.5.19_to_1.5.20-Stable-Patch_Package.zip';
		$logs .= date('Y-m-d H:i:s').' [ Done ]<br /> <b style=\"color:#009900;\">tmpFile:</b> '.$info->tmpFile;		
		return 1;
	}
	function extraPatch(&$info,&$logs){
		if(!isset($info->tmpFile)){
			$logs .= 'tmpFile don\'t exist';
			return -1;
		}
		$config	= &JFactory::getConfig();
		$tmp	= $config->getValue('config.tmp_path');		
		//$tmpdir = uniqid('jupgrade_');
		$tmpdir	= 'jupgrade_'.date('ymd');
		$extDir = JPath::clean($tmp.DS.$tmpdir);
		if(!JFolder::create($extDir)){
			$logs .= '<b style="color:#ff3300;">Error</b><br />Can\'t create extDir: '.$extDir;
			return 0;
		}
		$archivename = JPath::clean($tmp.DS.$info->tmpFile);
		require_once JPATH_LIBRARIES.DS."joomla".DS."filesystem".DS."archive".DS."zip.php";
		$zip = new JArchiveZip();
		$a = $zip->extract($archivename,$extDir);
		if(!$a){
			$logs .= '<b style="color:#ff3300;">Extract fail</b>';
			return 0;
		}
		$info->extDir	= $extDir;
		$logs .= '<b style="color:#009900;">Extract Dir: </b> '.$extDir;
		return 1;		
	}
	function backup(&$info,&$logs){
		if(!isset($info->extDir)){
			$logs .= 'tmpFile don\'t exist';
			return -1;
		}
		$bakname	= date('Y.m.d_H.i',$info->stAt).'_'.$info->cVer.'_to_'.$info->lVer;
		$info->bakzip = $this->createBackUp($info->extDir,$bakname,$logs);		
		$info->ableUpdate = $info->bakzip?'1':'0';		
		return 1; 		
	}
	function doUpdate(&$info,&$logs){
		if(!isset($info->extDir)){
			$logs .= '<b style="color:#ff3300;">tmpFile don\'t exist</b>';
			return -2;
		}
		if(!isset($info->bakzip)){
			$logs .= '<b style="color:#ff3300;">Don\'t Upgrade</b>';
			return 1;
		}else {
			if(@$info->ableUpdate=='1'){
				JFolder::copy($info->extDir,JPATH_SITE,'',true);
				$error	= 0;
				$msg	= 'Upgraded successful! Your Joomla is now up-to-date';
			}else {	
				$error	= 1;
				$msg	= 'Upgraded Fail, Please set permission write on site';
			}
		}
		JFolder::delete($info->extDir);
		$logs .= '<b style="color:#'.($error?'FF3300':'009900').';">'.$msg.'!</b>';		
		return 1;		
	}	
	function createBackUp($extractdir,$bakname,&$logs) {		
		$files = JFolder::files($extractdir,'.',true,true);
		$bakfiles = array();
		$updateList = '';
		$newList	= '';
		$lengExtDir	= strlen($extractdir);
		$lengRoot	= strlen(JPATH_SITE);
		$noUpgrade	= 0;
		$Unwritable	= array();
		for ($i = 0; $i < count($files); $i++) {
			$bfile = JPath::clean(JPATH_SITE.DS.substr($files[$i],$lengExtDir));
			$writable = '<img border="0" width="16" height="16" src="components/com_obupdater/assets/images/saccess.png" alt="Writable" title="Writable">';
			$msg	= '';
			if(is_file($bfile)){
				$bakfiles[] = $bfile;
				if(!is_writable($bfile)){
					$noUpgrade++;
					$Unwritable[] = substr($bfile,$lengRoot);
					$perm	= fileperms($bfile);
					$chmod	= substr(sprintf('%o',$perm), -4);						
					$writable	= '<img border="0" width="16" height="16" alt="Unwritable" src="images/publish_x.png">';
					$msg	= '<b style="color:#ff1100;">[ Unwritable ][ Perms: '.$chmod.' ]</b>';
				}
				$updateList .= "<li>".$writable.substr($bfile,$lengRoot)." $msg</li>\n";
			}else {
				if(!$this->checkWrite($bfile)){
					$noUpgrade++;
					$Unwritable[] = substr($bfile,$lengRoot);
					$writable	= '<img border="0" width="16" height="16" alt="Unwritable" src="images/publish_x.png">';
					$msg	= '<b style="color:#ff1100;">[ Unwritable ]</b>';
				}
				$newList.= "<li>$writable ".substr($bfile,$lengRoot)." $msg</li>\n";
			}
		}
		$logs	= "<h3>Modified files list: </h3><ol style=\"border:1px solid #DDDDDD;max-height:400px;overflow:auto;max-width:500px;\">$updateList</ol>\n";
		$logs	.= "<h3>New Files list: </h3>".($newList?"<ol>$newList</ol>":'[<i> None </i>]')."</ol>";
		$path_zipbak	= false;
		
		if(!$noUpgrade){
			$path_zipbak= JUC_BACKUP.'joomla_core'.DS.'zipbak'.DS.$bakname.'.zip';			
			JUCommon::createIndexHtml($path_zipbak);
			require_once JUC_HELPER.'ziplib'.DS.'zip.class.php';
			$zip	= new Archive_Zip($path_zipbak);
			$backup_create	=  $zip->create( $bakfiles, array( 'add_path' => '', 'remove_path' => JPATH_SITE) );
			$backupLink	= substr($path_zipbak,($lengRoot+15));
			$logs	.= "<br /><br /><b>Backup:</b> <a href=\"$backupLink\">$backupLink</a> ";						
		}else {
			JFolder::delete($extractdir);
			$msg	= "Error: Unwritable, Please set writable for all, then start Upgrade again ![ $noUpgrade file(s) ]";
			$logs	.= "<br /><br /><span style=\"border2px solid #ff1100;color:#ff1100;font-weight:bold;\">$msg</span>";
			$logs	.= "<h3>Unwritable list:</h3><ol style=\"border:1px solid #DDDDDD;max-height:400px;overflow:auto;max-width:500px;\">";
			for ($i=0;$i<count($Unwritable);$i++){
				$logs	.= "<li style=\"color:#ff1100;\">$Unwritable[$i]</li>";	
			}
			$logs	.= '</ol>';
		}
		return $path_zipbak;
	}
	function checkRun($JCVer,$JLVer){
		if($this->isRuning())return;
		$info	= @file_get_contents(JUC_UDINFO);		
		$info	= json_decode($info);
		$Init	= true;
		$tasks	= array('seachPatch','getPatch','extraPatch','backup','doUpdate');
		if(is_object($info)){
			$inited = date('Y-m-d',$info->stAt) == date('Y-m-d');			
			$taskValid	= in_array(@$info->task,$tasks);			
			if($inited && !$taskValid) return;
			if($taskValid && $JCVer == @$info->cVer && $JLVer == @$info->lVer) {								
				$Init	= false;					
			}
		}
		//$Init	= true;		
		if($Init){
			$info	= new stdClass();
			$info->stAt	= time();
			$info->cVer	= $JCVer;
			$info->lVer	= $JLVer;
			$info->task	= 'seachPatch';
			$this->saveInfo($info);
		}
		$task	= $info->task;
		if(isset($_GET['y'])){
			echo '<pre>';print_r($info);echo '</pre>';
		}
		$startAt	= date('Y-m-d H:i:s');
		$logs	= "";
		$next	= $this->$task($info,$logs);
		if(isset($_GET['y'])){
			echo "<hr/>[ Next: $next ] $logs<hr/>";
		}
		$cTask = count($tasks);
		for ($i=0;$i<$cTask;$i++){
			if($task==$tasks[$i]){
				if($i<($cTask-1)){
					$info->task	= @$tasks[($i+$next)];
				}else $info->task	= false;
			}
		}
		$logs = "[ Start at: $startAt ][ Task: $task ][ cVer: $JCVer ][ lVer: $JLVer ][ Done: ".date('Y-m-d H:i:s')." ]<br />$logs<hr />\n";
		$this->saveLog($logs);
		if(!$info->task){
			$bakname	= date('Y.m.d_H.i',$info->stAt).'_'.$info->cVer.'_to_'.$info->lVer;
			$bakHtml	= JUC_BACKUP.'joomla_core'.DS.$bakname.'.html';			
			$alertMail	= $this->alert($JLVer);
			$logOld		= file_get_contents(JUC_UDLOGS);						
			$logOld		= $logOld.'<br /><b>Alert via email:  <span style="color:#'.($alertMail?'009900;">saccess':'ff3300;">fail').'</span></b>';								
			file_put_contents($bakHtml,$logOld);
			file_put_contents(JUC_UDLOGS,'');			
		}
		$this->saveInfo($info);
		$this->checkOut();
	}
	function alert($JLVer){
		$obConfig	= &JUCommon::getConfig();
		$toMail	= @$obConfig->to_mail;
		$sender	= array('support@foobla.com', 'Foobla');
		$thisSite	= JURI::root();
		$urlUpdate	= $thisSite.'administrator/index.php?option=com_obupdater&controller=jupgrade&task=baklist';
		
		$subject	= "Your joomla site has been Update to version $JLVer";				
		$msg	= "Your joomla site has been Update to version $JLVer. <br /><br />";
		$msg	.= "Please view report at here: <a href=\"$urlUpdate\">$thisSite</a></b>";		
		$send	= JUCommon::sendMail($sender, $subject, $msg, $toMail,true);
		return $send;
	}
	function checkWrite($file){
		if(!JFile::write($file,'<?php echo "ju-write"; ?>'))return false;		
		return true;
	}
}