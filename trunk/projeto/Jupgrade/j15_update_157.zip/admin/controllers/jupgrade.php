<?php
/**
* @package		Joomla Updater Creator
* @author 		The Foobla Team.(foobla.com)
* @copyright	Copyright (C) 2008 The foobla Team. All rights reserved.
* @license		Commercial. You DO NOT allow to use this without a license from the author.
* @version		1.5.6
*/
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
jimport('joomla.application.component.controller');
require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'juinstaller.php');
class FOOBLACOREControllerJupgrade extends JController{
	public function __construct(){
		parent::__construct();
	}
	public function display(){
		$document 	= JFactory::getDocument();
		$vType 		= $document->getType();
		$vName 		= 'jupgrade';
		$mName 		= 'jupgrade';
		switch ($this->getTask()){			
			case 'baklist':
				$vLayout	= 'baklist';								
				break; 
			default:
				$vLayout	= 'default';								
		}
		$view = $this->getView($vName, $vType);
		$view->setLayout($vLayout);		
		if ($model 	= &$this->getModel($mName)){
			$view->setModel($model, true);
		}
		$view->display();
	}
	
	public function lvcheck(){
		$JLasVer = JUCommon::getJLastVer();
		$res = '<input type="hidden" name="lversion" value="'.($JLasVer?$JLasVer:'<i>Error check</i>').'" /><input type="hidden" name="err_lvcheck" value="'.($JLasVer?'0':'1').'" />';
		exit($res);
	}
	function checkjupgr(){
		$JCVer	= JUCommon::getJCurVer();
		$JLVer	= JUCommon::getJLastVer();
		JUCommon::section('set','juc.jcver',$JCVer);
		JUCommon::section('set','juc.jlver',$JLVer);		
		$res	= '<b style="color: #444444;">Joomla curent Version: </b>'.$JCVer;
		if($JLVer==$JCVer){
			$res	.= '<span style="color:#009900;font-weight: bold;"> [ Latest version ]</span>';
		}else {		 		
			$act	= ' [<span id="juc-act"><button onclick="getJPatchLink();"><b style="color:#ff6600;">Start Upgarde</b></button></span>]';
			$res	.= ' [<span style="color:#ff0000;"> Latest version: <b>'.$JLVer.'</b></span> ]'.$act;			
		}
		exit($res);
	}
	public function getlink(){
		$JCVer	= JUCommon::section('get','juc.jcver');
		$JLVer	= JUCommon::section('get','juc.jlver');
		//$rows->patch	= 'http://joomlacode.org/gf/download/frsrelease/12611/53384/Joomla_1.5.19_to_1.5.20-Stable-Patch_Package.zip';
		$rows	= JUCommon::getJUSJson("&view=service&task=getjpatch&curver=$JCVer&newver=$JLVer");
		//echo '<pre>';print_r($rows);echo '</pre>';
		$error	= true;	
		if(isset($rows->error)){
			$msg = $rows->error;			
		}elseif (isset($rows->patch) && substr($rows->patch,0,4)=='http'){
			$msg = "<b style=\"color:#009900;\">Found: </b> $rows->patch";
			$error	= false;
			JUCommon::section('set','juc.jpatch_url',$rows->patch);			
		}else {
			$msg = "Result error, please try again later! ( Result: $rows->patch )";			
		}
		if($error){
			$msg = "<b style=\"color:#ff3300;\">$msg</b>";
		}
		$finish = '<input type="hidden" name="jupgr-finish" id="jupgr-finish" value="'.($error?'1':'0').'"/>';	
		exit("<b>Search Patch package:</b> [ $msg ] $finish");
	}
	public function getpack(){
		$url_download	= JUCommon::section('get','juc.jpatch_url');		
		$model 		= $this->getModel('jupgrade');
		$pack_path	= $model->getPack($url_download);
		//$pack_path	= 'Joomla_1.5.19_to_1.5.20-Stable-Patch_Package.zip';
		$extractdir = $model->extractPack($pack_path);
		if($extractdir=='') exit("Can't extract file [$pack_path]");
		JUCommon::section('set','juc.extractdir',$extractdir);
		$msg	= '<b style="color:#009900;">success</b>';
		exit("<b>Get Patch package:</b> [ $msg ]");
	}
	function jbackup(){
		$JCVer	= JUCommon::section('get','juc.jcver');
		$JLVer	= JUCommon::section('get','juc.jlver');		
		$extractdir	= JUCommon::section('get','juc.extractdir');					
		$bakname	= date('Y.m.d_H.i').'_'.$JCVer.'_to_'.$JLVer;
		$model	= $this->getModel('jupgrade');
		$log	= $model->createBackUp($extractdir,$bakname);						 
		exit($log);
	}
	public function doupgrade() {
		$extractdir	= JUCommon::section('get','juc.extractdir');
		$model 	= $this->getModel('jupgrade');
		$res	= $model->upgradeJBase($extractdir);	
		$color	= $res->error?'cc0000':'009900';
		exit("<b>Result:</b> <b style=\"color:#$color;\">$res->msg</b>");
	}
	function restore(){
		$model 	= $this->getModel('jupgrade');
		if(!$model->restore()){
			$msg	= 'fial';
			$tmsg	= 'error';			
		}else {
			$msg	= 'success';
			$tmsg	= 'message';			
		}
		global $mainframe,$option;
		$mainframe->redirect("index.php?option=$option&controller=jupgrade&task=baklist",'Restore '.$msg.' !',$tmsg);		
	}
} 