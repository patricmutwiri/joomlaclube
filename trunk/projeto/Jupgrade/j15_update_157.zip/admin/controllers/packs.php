<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.controller');
require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'juinstaller.php');
class FooblaCoreControllerPacks extends JController{	
	function __construct(){
		parent::__construct();
	}
	
	function display(){		
		JHTML::_('behavior.tooltip');
		JUCommon::getToolBar();
		switch ($this->getTask()){
			case 'exts':$this->showExtsP();break;
			default:$this->showPacks();				
		}		
		//echo 'coding ...';
		return; 
		
		global $option;
		$mvc	= 'packs';
		switch ($this->getTask()){
			case 'add':
			case 'edit':
				JRequest::setVar('layout','form');
				break;	
			default:				
				$vLayout   	= 'default';
		}
		$vLayout	= JRequest::getVar('layout', 'default');
		$document	= JFactory::getDocument();
		$vType		= $document->getType();
		if($model = &$this->getModel($mvc)){
			$view->setModel($model, true);
		}
		$view = $this->getView($mvc, $vType);
		$view->setLayout($vLayout);		
		$view->display();
	}
	function showPacks(){
		JToolBarHelper::title(JText::_('Packs <small>[ List ]</small>'));
		$sever	= JUInstaller::getServer();
		$http 	= "http://$sever/";
		$url	= $http.'index.php?option=com_joomlaupdater_server&view=packs&task=lpacks';
		@$json	= 	file_get_contents($url);
		if(!$json){			
			$msg = JUCommon::connectError();
			echo '<div align="center">'.JText::_(CONNECT_ERROR).'</div>';
			return;
		}					
		$rows = json_decode($json);
		$urlSxts = 'index.php?option=com_obupdater&controller=packs&task=exts&pid=';
		
		//$style	= 'style="border-bottom:1px solid #ddd;"';
		$style = '';
		echo '<table class="adminlist">';
		echo "<thead><tr>
					<th class=\"key\" width=\"1%\">#</th>
					<th class=\"key\" width=\"25%\">Pack Name</th>
					<th class=\"key\" width=\"70%\">Description</th>
					<th class=\"key\" width=\"1%\">id</th>
				</tr></thead>";
		$j=0;
		for ($i=0;$i<count($rows);$i++){			
			$row= $rows[$i];
			echo '<tr class="row'.$j.'"><td align="right">'.($i+1).'</td>';
			echo '<td><a class="hasTip" title="Open details::'.$row->name.'" href="'.$urlSxts.$row->id.'">'.$row->name.'</a></td> ';			
			echo "<td><i>None Description</i></td>";
			echo "<td align=\"right\">$row->id</td>";
			echo '</tr>';
			$j=1-$j;
		}
		echo '</table>';
	}	
	function showExtsP(){
		JToolBarHelper::title(JText::_('Packs <small>[ Details ]</small>'));
		$pid	= JRequest::getVar('pid',0,'int');		
		if(!$pid){echo 'id?'; return;}
		$sever	= JUInstaller::getServer();
		$url	= "http://$sever/index.php?option=com_joomlaupdater_server&view=packs&task=lexts&pid=$pid";
		@$json	= 	file_get_contents($url);
		if(!$json){			
			$msg = JUCommon::connectError();
			echo '<div align="center">'.JText::_(CONNECT_ERROR).'</div>';
			return;
		}	
		$rows	= json_decode($json);
		$urlCExt	= 'index.php?option=com_obupdater&controller=browse&task=detail&cid[]=';
		$style	= 'class="td-h"';
		$style2	= 'style="border:1px solid #ddd;padding:2px;"';
		echo '<div align="center">
				<style>
				.td-h{
					background: #ddd;
					font-weight: bold;
					color: #333;
					text-align:center;
				}
				.td-stt{width:10px;text-align:right;}
				.td-cb{width:10px;}
				.td-name{width:250px;}
				.td-type{width:20px;text-align:center;}
				.td-ver{width:50px;text-align:right;}
				.td-res{width:60px;text-align:center;cursor:pointer}
				.td-des{width:250px;}
				.ext-ins-start{
					font-weight:bold;
				}
				.ext-ins-saccess{
					font-weight:bold;
					color:#009900;
				}
				.ext-ins-fail{
					font-weight:bold;
					color:#cc3300;
				}		
				.ins-done{
					font-weight:bold;
					color:#666666;									
				}		
				#pkmsg{padding:5px;}
				</style>
		<form name="adminForm" method="post" action="#">
		<table class="adminlist">';
		echo "<thead><tr>
					<th class=\"key\" width=\"1%\">#</th>
					<th class=\"key\" width=\"20%\">Extension Name</th>					
					<th class=\"key\" width=\"75%\">Packages</th>					
				</tr></thead>";
				$k=0;$l=0;
		for ($i=0;$i<count($rows);$i++){			
			$row= $rows[$i];
			$vers = $row->ver;			
			echo '<tr><td style="background:#F9F9F9;">'.($i+1).'</td>';
			echo '<td style="background:#F9F9F9;"><a target="_blank" class="hasTip" title="View details::'.$row->name.'" href="'.$urlCExt.$row->id.'">'.$row->name.'</a></td>';
			echo '<td><table class="adminlist">';
			for ($j=0;$j<count($vers);$j++){
				$ver= $vers[$j];
				$extType	= JUCommon::getExtImg($ver->type);
				$extVal	= "&lid=$row->id&ext_name=$ver->ext_name&ex_type=$ver->type&ver=$ver->version";
				
				echo '<tr class="row'.$l.'"><td class="td-stt">'.($k+1).'.</td>';
				echo '<td class="td-cb"><input type="checkbox" checked = "checked" value="'.$extVal.'" name="cid[]" id="cb'.$k.'" /></td>';
				echo "<td class=\"td-name\" id=\"ext_name_$k\">$ver->ext_name </td>	";
				echo "<td class=\"td-type\">$extType</td>";
				echo "<td class=\"td-ver\">$ver->version</td>";
				echo "<td class=\"td-res\" id=\"msg_$k\"><i>State</i></td>";
				echo '<td class=\"td-des\"><i id="des_'.$k.'">Result</i></td></tr>';
				$k++;
				$l=1-$l;
			}
			echo '</table>';
			echo '</td>';			
			echo '</tr>';
		}		
		echo '</table></form>
		<div id="pkmsg">&nbsp;</div>
		<button onclick="installPacks(this);">Install</button>
		<button onclick="backP();" id="pback">Back</button>		
		</div>';
		$host = JURI::base();
		echo "<script>var extTotal=$k;chost='$host'</script>";
		?>
		<script>
		var insList = new Array();
		function gId(id){return document.getElementById(id);}
		function backP(){document.location = 'index.php?option=com_obupdater&controller=packs';}
		function installPacks(bt){
			bt.disabled = 'disabled';			
			gId('pback').disabled = 'disabled';
			var f=document.adminForm,cb,txt='',id;
			for(var i=0;i<extTotal;i++){				
				cb=eval('f.cb'+i);
				id= cb.id.substr(2);				
				insList[id]='';				
				if(cb.checked){
					insList[id] = cb.value;
				}
				cb.disabled='disabled';				
			}
			installExt();
		}
		function getImg(img,alt){			
			var imgPath= chost+'components/com_obupdater/assets/images/';
			return '<img width="16" height="16" border="0" title="'+alt+'" alt="'+alt+'" src="'+imgPath+img+'"/>';
		}
		function installExt() {
			var done,data,id;						
			for(var i=0;i<insList.length;i++){				
				done = true;
				if(insList[i] !=''){
					done=false;
					id=i;					
					data=insList[i];
					insList[i] = '';
					break;
				}
			}
			if(done){
				gId('pkmsg').innerHTML = '<span class="ins-done">Done install</span>';
				gId('pback').disabled = '';
				return;
			}
			var msg =  gId('msg_'+id);
			var ext =  gId('ext_name_'+id);			
			var extClass	= ext.className;
			ext.className	= extClass+' ext-ins-start';			
			var msgClass	= msg.className;			
			msg.innerHTML	= getImg('loading.gif','Loading ...');					
			var url = 'index.php?option=com_obupdater&controller=packs&task=insext'+data;						
			var req = new Ajax(url,{onComplete: function(res){
					var obj = eval(res),img,color;
					if(obj.res=='ok'){
						img = 'saccess';
						color = '3366cc';						
						ext.className	= extClass+' ext-ins-saccess';					
					}else{
						img = 'fail';
						color = 'cc3300';
						ext.className	= extClass+' ext-ins-fail';											
					}
					var des = gId('des_'+id);
					des.innerHTML = obj.msg;
					des.style.color='#'+color;		 
					msg.innerHTML=getImg(img+'.png',obj.msg);
					installExt();
				}
			}).request();
		}
		</script>
		<?php
	}
	function insext(){
		$install = new JUInstaller;
		$res	= $install->install();				
		if($res->ok){
			$msg	= 'success';
			$res	= 'ok';
		}else {
			$msg	= 'fail';
			$res	= 'no';			
		}
		$msg	= 'Install '.JText::_($res->ltype).' '.$msg;
		$res	= '({res:"'.$res.'",msg:"'.$msg.'"})';
		exit($res);	
	}	
}
?>