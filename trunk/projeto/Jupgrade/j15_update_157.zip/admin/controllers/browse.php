<?php
/**
 * @package		Joomla Updater
 * @author 		joomlaupdater.com
 * @copyright	Copyright (C) 2008 The Joomla! Updater Team. All rights reserved.
 * @license		Commercial. You DO NOT allow to use this without a license from the author.
 * @version		1.5.0.1
 */

// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.controller');
require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'juinstaller.php');
class FOOBLACOREControllerBrowse extends JController{
	function __construct(){
		parent::__construct();
	}	
	function display(){
		
		switch ($this->getTask()){
			case 'update':
				JRequest::setVar('layout','update');
				break;
			case 'detail':
				JRequest::setVar('layout','detail');
				break;		
		}		
		$document 	= JFactory::getDocument();
		$vType 		= $document->getType();		
		$name 		= 'browse';
		
		$view = $this->getView($name, $vType);
		$vLayout = JRequest::getCmd('layout','default');
		$view->setLayout($vLayout);		
		if ($model 	= &$this->getModel($name)){
			$view->setModel($model, true);
		}
		$view->display();
	}
	function extgetpatch(){
		$type	= JRequest::getCmd('type','');
		$code	= JRequest::getCmd('code','');
		$tover	= JRequest::getString('tover','');
		echo "<b>Extension: </b>[ Type: $type ][ Code: $code ]";
		if(!$code || !$type || !$tover){
			exit('Error[1]');
		}
		$cuVer	= JUCommon::getCuVer($code,$type);
		//$cuVer	='1.5.0.3';
		echo "[ Cu Ver: $cuVer ][ To Ver: $tover ]";
		if(!$cuVer){
			exit('Error[2]');
		}		
		$installer = new JUInstaller;
		$log = $installer->extUpdate($type, $code, $cuVer, $tover);
		exit($log);
	}
	function restore(){
		$ext	= JRequest::getCmd('ext');
		if(!$ext){
			echo '<b>Ext None</b>';
			return;
		}
		$installer = new JUInstaller;
		$log = $installer->extRestore($ext);
		echo $log;
		echo "<hr /><b>[ <a href=\"index.php?option=com_obupdater&controller=jupgrade&task=baklist&ext=$ext\">Back</a> ]</b>";
/*		
		$log = $installer->extRestore($type, $code, $cuVer,$pathBak);
		echo $log;*/
	}
	function ugrcore(){
		$install = new JUInstaller;
		$install->ugr_core();
	}
	function juinstall(){
		//global $mainframe,$option;
		$install = new JUInstaller;
		$res = $install->install();
		$install->jucRedirect($res);
		//$mainframe->redirect('index.php?option='.$option.'&controller=browse&task=detail&cid[]='.$res->lid,$res->msg,$res->state);	
	}
	function juupgrade(){
		$install = new JUInstaller;
		$res = $install->upgrade();
		if($res->redirect){$install->jucRedirect($res);}
		else {
			global $option;
			echo '<br>[ <a href="index.php?option='.$option.'&controller=browse&task=detail&cid[]='.$res->lid.'"><b>Back</b></a> ]';
		}
	}	
	public function juuninstall() {
		global $mainframe,$option;
		jimport('joomla.installer.installer');
		//http://ju.foobla.com/administrator/index.php?option=com_obupdater&controller=browse&lid=3&ver=1.5.2.0&ex_type=mod&task=juuninstall&type=mod&lib_code=mod_foobla_todo&folder=
		$type 	= &JRequest::getVar("type");
		$code 	= &JRequest::getVar("lib_code");
		$folder = &JRequest::getVar("folder");
//		#get id		
		$where = "";
		$select = " `id` ";
		switch ($type) {
			case 'com':
				$type="component";
				$where = " `option`='com_$code' ";
				$from = "components";
			break;
			case 'mod':
				$type="module";
				$where = " `module`='mod_$code' ";
				$select.=', `client_id` ';
				$from = 'modules';
			break;
			case 'plugin':
				$type="plugin";
				$where = " `element`='$code' and `folder`='$folder' ";
				$from = 'plugins';
				break;
		}
		$query = "Select $select from `#__$from` where $where";
		//exit($query);
		$db 	= &JFactory::getDBO();
		$db->setQuery($query);
		$res 	= $db->loadObject();
		$client_id = (isset($res->client_id))?$res->client_id:0; 
		$installer 	= & JInstaller::getInstance();
		$cid = &JRequest::getVar('lid');
		$result		= $installer->uninstall($type, $res->id ,$client_id);
		if($result){
			$mainframe->redirect("index.php?option=$option&controller=browse&task=detail&cid[]=$cid",JText::_("Success on uninstall extension!"));
		}
		$mainframe->redirect("index.php?option=$option&controller=browse&task=detail&cid[]=$cid");
	}
} // end class
?>