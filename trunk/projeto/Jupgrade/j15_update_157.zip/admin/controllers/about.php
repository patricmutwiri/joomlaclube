<?php
// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
jimport('joomla.application.component.controller');
//require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'juinstaller.php');	  
class FooblaCoreControllerAbout extends JController
{
	function __construct(){
		parent::__construct();
	}
	
	function display(){
		JUCommon::getToolBarDefault();
		JToolBarHelper::title(JText::_('Support'), 'foobla.png');				
		$obUpdater = JUCommon::checkExtVer('obupdater','com');			
		echo '<div style="float:right;"><b>Joomla Updater Client version '.$obUpdater->cuVer.'</b>';
		echo '<hr>Project\'s Homepage: <a href="http://obupdater.com" target="_blank">http://obupdater.com</a>';
		echo '<br>Support Forum: <a href="http://obupdater.com/forum.html" target="_blank">http://obupdater.com/forum.html</a></div>';
		echo '<script>function submitbutton(pressbutton){if(goCtrl(pressbutton))return false;}</script>
<form id="adminForm" name="adminForm" method="POST" action="index.php?option=com_obupdater">
	<input type="hidden" value="" name="task"/>
</form>';
		return ;
		$mvc	= 'about';	
		$doc	= &JFactory::getDocument();
		$vType	= $doc->getType();
		$view	= &$this->getView( $mvc, $vType);
		$view->setLayout('default');
		$view->display();
	}
}