<?php

/*
 * @copyright	Copyright (C)  2009 Daniel Brettschneider
 * @license		GNU/GPL, see LICENSE.php
*/
   	defined('_JEXEC') or die('Restricted access');
   	
	JHTML::script('script.js', 'modules/mod_binary_clock/', false);
	$document = &JFactory::getDocument();
	$live_path = JURI::base(true) . '/';
	$document->addStyleSheet($live_path . "modules/mod_binary_clock/tmpl/css/mod_binary_clock.css", "text/css");
   	require(JModuleHelper::getLayoutPath('mod_binary_clock', 'default'));
?>
