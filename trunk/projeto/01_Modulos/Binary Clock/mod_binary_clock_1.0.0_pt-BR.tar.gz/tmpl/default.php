<?php
/*
 * @copyright	Copyright (C)  2009 Daniel Brettschneider
 * @license		GNU/GPL, see LICENSE.php
*/
	# Get backend parameters
	$showTime = $params->get("showTime");
  	$color = $params->get("color");
?>
<script type="text/javascript">
	startClock(<?php echo "'".$showTime."', '".$color."', '".JURI::base(true).'/'."modules/mod_binary_clock/images/'"; ?>);
</script>
<div id="binary_clock">
	<table border="0" cellpadding="0" cellspacing="0">
		<tr>
            <td valign="bottom">
                <span class="hidden"></span>
                <span id="h1_4" class="hidden"></span>
                <span id="h1_2" class="clock_box"></span>
                <span id="h1_1" class="clock_box"></span>
            </td>
            <td valign="bottom">
                <span id="h2_8" class="clock_box"></span>
                <span id="h2_4" class="clock_box"></span>
                <span id="h2_2" class="clock_box"></span>
                <span id="h2_1" class="clock_box"></span>
            </td>
            <td valign="bottom">
                <span class="hidden"></span>
                <span id="m1_4" class="clock_box"></span>
                <span id="m1_2" class="clock_box"></span>
                <span id="m1_1" class="clock_box"></span>
            </td>
            <td valign="bottom">
                <span id="m2_8" class="clock_box"></span>
                <span id="m2_4" class="clock_box"></span>
                <span id="m2_2" class="clock_box"></span>
                <span id="m2_1" class="clock_box"></span>
            </td>
            <td valign="bottom">
                <span class="hidden"></span>
                <span id="s1_4" class="clock_box"></span>
                <span id="s1_2" class="clock_box"></span>
                <span id="s1_1" class="clock_box"></span>
            </td>
            <td valign="bottom">
                <span id="s2_8" class="clock_box"></span>
                <span id="s2_4" class="clock_box"></span>
                <span id="s2_2" class="clock_box"></span>
                <span id="s2_1" class="clock_box"></span>
            </td>
		</tr>
	</table>
    
    <span id="binary_clock_string"></span>
</div>