<?php
/**
* @version $Id:  mod_pensamentos.php, V1.0.0  2009-01-01 $
* @module Joomla
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*
* Adaptado do módulo vivi_code do Serra Antonio (tonio@vivigrosseto.it)
* http://www.vivigrosseto.it/ 
*/

/* **************************************************** */
/* Pensamentos Module, version 1.0        */
/* **************************************************** */

// no direct access
defined('_JEXEC') or die('Restricted access');

$module_code 			= $params->def( 'code', '' );
$module_height 			= $params->def( 'height', '' );
$module_width 			= $params->def( 'width', '' );
$moduleclass_sfx 			= $params->def( 'moduleclass_sfx', '' );
?>
<div align="left" style="
<?php if(!empty($module_height)) echo "height:".$module_height."px;";?>
<?php if(!empty($module_width)) echo "width:".$module_width."px;";?>
">

<?php
class pensamentos
{
	function pensamento_aleatorio(){
		print $this->baseurl;
		$f_contents = file ('modules/mod_pensamentododia/mod_pensamentododia.txt');
		srand ((double)microtime()*1000000);
		$linha_aleatoria = $f_contents[ rand (0, (count ($f_contents) - 1)) ];
		print $linha_aleatoria;
	}	
}
?>

<?php pensamentos::pensamento_aleatorio(); ?><br><br>
</div>
