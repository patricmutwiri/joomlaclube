<?php
/**
* Module Camp26 Google Page Rank For Joomla 1.0
* Vers�o		: 1.2
* Criado por	: Rony Sandra Yofa Zebua e camp26.biz Team
* Email			: ronysyz@gmail.com
* Criado em	: 24 March 2008
* �ltima Atualiza��o	: 5 Janeiro 2009
* URL			: www.camp26.biz
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

?>