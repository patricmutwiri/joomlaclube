<?php
/**
* Module Camp26 Google Page Rank For Joomla 1.5
* Vers�o		: 1.2
* Criado por	: Rony Sandra Yofa Zebua e camp26.biz Team
* Email			: ronysyz@gmail.com
* Criado em	: 24 March 2008
* Ultima atualiza��o	: 5 January 2009
* URL			: www.camp26.biz
*/

/*Start Camp26 Google Page Rank by http://www.camp26.biz*/
defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once (dirname(__FILE__).DS.'helper.php');

require(JModuleHelper::getLayoutPath('mod_camp26_gpagerank'));
?>

