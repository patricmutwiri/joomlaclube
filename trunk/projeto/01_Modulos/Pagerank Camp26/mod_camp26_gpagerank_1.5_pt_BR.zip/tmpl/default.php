<?php
/**
* MOdulo Camp26 Google Page Rank para Joomla 1.5
* Vers�o		: 1.2
* Criado por	: Rony Sandra Yofa Zebua e camp26.biz Team
* Email			: ronysyz@gmail.com
* Criado em	: 24 Mar�o 2008
* Ultima atualiza��o	: 5 Janeiro 2009
* URL			: www.camp26.biz
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

$domain				= $params->get( 'domain', 'joomla.org') ;
$align 				= $params->get( 'align', '0') ;
$borderset 			= $params->get( 'borderset', '0') ;
$altset 			= $params->get( 'altset', 'My Google Page Rank') ;
$prtype 			= $params->get( 'prtype', '0') ;
$createdby 			= $params->get( 'createdby', '0') ;


/*Start Camp26 Google Page Rank Type by http://www.camp26.biz*/
switch ($prtype) {
	case "1" :
		$prtype = "<a href=\"http://www.google-pagerank.net\" target=\"_blank\"><img src=\"http://www.google-pagerank.net/rank.php\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "2" :
		$prtype = "<a href=\"http://www.prlookup.com\"><img src=\"http://www.prlookup.com/myrank.php\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "3" :
		$prtype = "<a href=\"http://www.mypagerank.net\" target=\"_blank\"><img src=\"http://www.mypagerank.net/smerankcheck.php?site=$domain&s=style1\" border=\"$borderset\" alt=\"$altset\"></a>";
	break;
	case "4" :
		$prtype = "<a href=\"http://www.mypagerank.net\" target=\"_blank\"><img src=\"http://www.mypagerank.net/smerankcheck.php?site=$domain&s=style2\" border=\"$borderset\" alt=\"$altset\"></a>";
	break;
	case "5" :
		$prtype = "<a href=\"http://www.mypagerank.net\" target=\"_blank\"><img src=\"http://www.mypagerank.net/smerankcheck.php?site=$domain&s=style3\" border=\"$borderset\" alt=\"$altset\"></a>";
	break;
	case "6" :
		$prtype = "<a href=\"http://www.mypagerank.net\" target=\"_blank\"><img src=\"http://www.mypagerank.net/smerankcheck.php?site=$domain&s=style4\" border=\"$borderset\" alt=\"$altset\"></a>";
	break;
	case "7" :
		$prtype = "<a href=\"http://www.mypagerank.net\" target=\"_blank\"><img src=\"http://www.mypagerank.net/smerankcheck.php?site=$domain&s=style5\" border=\"$borderset\" alt=\"$altset\"></a>";
	break;
	case "8" :
		$prtype = "<a href=\"http://www.mypagerank.net\" target=\"_blank\"><img src=\"http://www.mypagerank.net/smerankcheck.php?site=$domain&s=style6\" border=\"$borderset\" alt=\"$altset\"></a>";
	break;
	case "9" :
		$prtype = "<a href=\"http://www.mypagerank.net\" target=\"_blank\"><img src=\"http://www.mypagerank.net/smerankcheck.php?site=$domain&s=style7\" border=\"$borderset\" alt=\"$altset\"></a>";
	break;
	case "10" :
		$prtype = "<a href=\"http://www.mypagerank.net\" target=\"_blank\"><img src=\"http://www.mypagerank.net/smerankcheck.php?site=$domain&s=style8\" border=\"$borderset\" alt=\"$altset\"></a>";
	break;
	case "11" :
		$prtype = "<A HREF=\"http://www.mypagerank.net\" target=\"_blank\"><IMG SRC=\"http://www.mypagerank.net/srank.php?site=$domain\" border=\"$borderset\" ALT=\"$altset\"></A>";
	break;
	case "12" :
		$prtype = "<a href=\"http://www.prchecker.info\" target=\"_blank\"><img src=\"http://www.prchecker.info/PR1_img.gif\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "13" :
		$prtype = "<a href=\"http://www.prchecker.info\" target=\"_blank\"><img src=\"http://www.prchecker.info/PR2_img.gif\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "14" :
		$prtype = "<a href=\"http://www.prchecker.info\" target=\"_blank\"><img src=\"http://www.prchecker.info/PR3_img.gif\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "15" :
		$prtype = "<a href=\"http://pr.blogflux.com\"><img src=\"http://pr.blogflux.com/pr.php\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "16" :
		$prtype = "<a href=\"http://www.whatsmypagerank.com\" target=\"_blank\"><img src=\"http://www.whatsmypagerank.com/button.php\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "17" :
		$prtype = "<a href=\"http://www.singerdesign.com\" target=\"_blank\"><img src=\"http://www.singerdesign.com/pagerank.php?type=apple\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "18" :
		$prtype = "<a href=\"http://www.singerdesign.com\" target=\"_blank\"><img src=\"http://www.singerdesign.com/pagerank.php?type=gulp\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "19" :
		$prtype = "<a href=\"http://www.singerdesign.com\" target=\"_blank\"><img src=\"http://www.singerdesign.com/pagerank.php?type=purple\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "20" :
		$prtype = "<a href=\"http://www.singerdesign.com\" target=\"_blank\"><img src=\"http://www.singerdesign.com/pagerank.php?type=pink\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "21" :
		$prtype = "<a href=\"http://www.singerdesign.com\" target=\"_blank\"><img src=\"http://www.singerdesign.com/pagerank.php?type=large\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "22" :
		$prtype = "<a href=\"http://www.singerdesign.com\" target=\"_blank\"><img src=\"http://www.singerdesign.com/pagerank.php?type=med\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "23" :
		$prtype = "<a href=\"http://www.singerdesign.com\" target=\"_blank\"><img src=\"http://www.singerdesign.com/pagerank.php?type=small\" alt=\"$altset\" border=\"$borderset\"></a>";
	break;
	case "24" :
		$prtype = "<a href=\"http://www.urltrends.com\" target=\"_blank\" title=\"Get your Google PageRank\"><img src=\"http://www.urltrends.com/pagerankimg.php\" border=\"$borderset\" height=\"25\" width=\"100\" alt=\"$altset\"></a>";

	break;
	case "25" :
		$prtype = "<script language=\"JavaScript\" src=\"http://www.thegooglepagerank.com/google-pagerank.php\"> </script><a href=\"http://www.thegooglepagerank.com/\" target=\"_blank\"><img  src=\"http://www.thegooglepagerank.com/images/pr.gif\" alt=\"Google PageRank Checking tool\" border=\"0\"></a>";

	break;
	case "26" :
		$prtype = "<script language=\"JavaScript\" src=\"http://www.thegooglepagerank.com/google-pagerank2.php\"> </script><a href=\"http://www.thegooglepagerank.com/\" target=\"_blank\"><img  src=\"http://www.thegooglepagerank.com/images/pr.gif\" alt=\"Google PageRank Checking tool\" border=\"0\"></a>";

	break;
	case "27" :
		$prtype = "<a href=\"http://www.pagerankbar.com/\" target=\"_blank\"><img src=\"http://www.pagerankbar.com/prbutton.png\" alt=\"Page Rank Checker Button\" border=\"0\" /></a>";

	break;
	default:
		$prtype = "<a href=\"http://www.mypagerank.net\" target=\"_blank\"><img src=\"http://www.mypagerank.net/smerankcheck.php?site=$domain&s=style4\" border=\"$borderset\" alt=\"$altset\"></a>";
	break;
}

switch ($align) {
  case "1" :
    $align = "<left>";
	$alignc = "</left>";
  break;
  case "2" :
    $align = "<center>";
	$alignc = "</center>";
  break;
  case "3" :
    $align = "<right>";
	$alignc = "</right>";
  break;
  default:
	$align = "<left>";
	$alignc = "</left>";
  break;
}

switch ($createdby) {
  case "0" :
    $createdby = "<font size=1><center>Made by: <a href=http://www.camp26.biz>Camp26</a></font></center>";
  break;
  case "1" :
    $createdby = "";
  break;
  default:
    $createdby = "";
  break;
}

?>
<TABLE WIDTH="100%" BORDER=0 align="" CELLPADDING=0 CELLSPACING=0 style="background-repeat:no-repeat; background-position:center;">
		<TR><TD>
		<?php echo $align;?>
		<?php echo $prtype;?>
		<?php echo $alignc;?>
		<?php echo $createdby;?>
		</TD></TR>
</TABLE>