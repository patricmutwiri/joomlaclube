<?php

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
JHTML::script('ulticounter.js','modules/mod_ulti_counter/javascript/',false);
?>
<div id="ulti_counter" class="ulti_counter<?php echo $moduleclass_sfx;?>">
<div class="ulti_counter_leading">
<?php echo $leading; echo " "; ?> 
</div>
<div class="ulti_counter_middle"><div id="counter<?php echo $counterID; ?>"></div>

<script type="text/javascript">
var langarray = new Array();
langarray[0] = '<?php echo JText::_('DAY');?>';
langarray[1] = '<?php echo JText::_('DAYS');?>';
langarray[2] = '<?php echo JText::_('HOUR');?>';
langarray[3] = '<?php echo JText::_('HOURS');?>';
langarray[4] = '<?php echo JText::_('MINUTE');?>';
langarray[5] = '<?php echo JText::_('MINUTES');?>';
langarray[6] = '<?php echo JText::_('SECOND');?>';
langarray[7] = '<?php echo JText::_('SECONDS');?>';
ulticountdown(<?php echo $timeleft;?>,<?php echo $counterID; ?>,<?php echo $format; ?>,<?php echo $keepCounting; ?>,<?php echo $zero; ?>, langarray);
</script>
</div>
<div class="ulti_counter_tailing">
<?php  echo " "; echo $tailing; ?> 
</div>
</div>
