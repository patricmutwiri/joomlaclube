<?php
/**
 * @author	Roberson Carlos AKA robersonfox AKA Carl Robers
 * @version	0.1
 * @package	Show Avatars for Identi.ca 
 * @copyright	(C) 2010 Roberson Carlos
 * @license	GNU General Public License version 2
 *
 * Identi.ca Show Avatar Module for Joomla! 1.5+. 
 */


// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Include the syndicate functions only once
require_once (dirname(__FILE__).DS.'helper.php');
$show_updates_on = $params->get( 'show_updates_on','graficalivre' );
$moduleclass_sfx = $params->get( 'moduleclass_sfx','' );
$limit = $params->get( 'limit','16' );
$show_image  = $params->get( 'show_image','1' );
$w = $params->get( 'w','48' );
$h = $params->get( 'h','48' );
$br = $params->get( 'br','4' );

$updates=modShowAvatarIdenticaHelper::getUpdates($show_updates_on);

require(JModuleHelper::getLayoutPath('mod_ShowAvatarIdentica'));
