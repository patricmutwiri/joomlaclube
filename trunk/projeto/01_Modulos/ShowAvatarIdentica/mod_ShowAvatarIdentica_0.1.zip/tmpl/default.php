<?php 
/**
 * @author	Roberson Carlos AKA robersonfox AKA Carl Robers
 * @version	0.1
 * @package	Show Avatars Identi.ca 
 * @copyright	(C) 2009-2010 Roberson Carlos
 * @license	GNU General Public License version 2
 *
 * Identi.ca Show Avatar Module for Joomla! 1.5+. 
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 
?>

<div style="<?php echo $moduleclass_sfx; ?>">

<?php
 $count=0;
 $str="";
 //print_r($updates);
 foreach ($updates as $item)
 {
    	$count=$count+1;
	$count2=$count2+1;

    	$str=$str."\n";


    if($show_image) {
        preg_match('([0-9]{1,})', $item->get_id(), $matches);
      
        $tmp = $item->get_item_tags("http://rdfs.org/sioc/ns#", "has_creator");
        $profile_url = $tmp[0]['attribs']['http://www.w3.org/1999/02/22-rdf-syntax-ns#']['resource'];
	
	preg_match('([0-9]{1,})', $profile_url, $matches);
      
	$tmp = $item->get_item_tags("http://status.net/ont/", "postIcon");
        $image_url = $tmp[0]['attribs']['http://www.w3.org/1999/02/22-rdf-syntax-ns#']['resource'];
	
	$alt=strip_tags(($item->get_content()));

        $str=$str."<a title=\"$alt\" href='".$item->get_link()."' style='font-weight:bold;'>
	<img alt=\"$alt\" style=\"border:#000 solid 1px;\" align=\"left\" width=\"$w\" height=\"$h\" src=\"$image_url\" /> </a>";

	if ($count2==$br) {
		$str=$str."<br>";
		$count2=0;	
	}
     }

   
    
    if($count==$limit)
        break;
 }
 echo $str;
        ?>
</div>
