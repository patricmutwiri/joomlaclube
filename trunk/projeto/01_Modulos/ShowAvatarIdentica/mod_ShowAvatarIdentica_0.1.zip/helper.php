<?php
/**
 * @author	Gianluca Urgese
 * @version	0.3
 * @package	Show Updates Identi.ca 
 * @copyright	(C) 2009-2010 Gianluca Urgese
 * @license	GNU General Public License version 2
 *
 * Identi.ca Show Updates Module for Joomla! 1.5+. 
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class modShowAvatarIdenticaHelper
{
    function getUpdates($search_term)
    {
        jimport('simplepie.simplepie');
        $search_term=str_replace(' ','+',$search_term);
        $url= "http://identi.ca/search/notice/rss?q=".$search_term."&search=Search";
        $feed=new SimplePie();
		$feed->set_feed_url($url);
		$feed->enable_cache(false);
		$feed->enable_order_by_date(true);
		$feed->init();
		
		$feed->handle_content_type();
        return $feed->get_items() ;
    }
    
}
