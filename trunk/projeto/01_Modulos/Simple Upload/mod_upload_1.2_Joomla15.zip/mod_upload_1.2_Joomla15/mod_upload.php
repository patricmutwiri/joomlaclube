<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

$module_dir = $params->get( 'dir','upload' );
$module_max = $params->get( 'max', 2097152 );
$file_type = $params->get( 'type', 'image/gif' );

?>

<form enctype="multipart/form-data" action="" method="post">
    <input type="hidden" name="MAX_FILE_SIZE" value="2097152" /> <!-- Max 2MB -->
    <?php echo JText::_('CHOOSE_FILE'); ?> <input name="uploaded_file" type="file" size="10"/>
    <input name="submit" type="submit" value="Upload" />
</form>

<?php
if(isset($_POST['submit'])){
    if(!file_exists ($module_dir)) {
       //print $mainframe->enqueueMessage('Crie antes o diretório para o upload', 'error');
  	   print JFactory::getApplication()->enqueueMessage( JText::_('CREATE_DIRECTORY'), 'error' );
    }else{
      function uploader($dir_upload, $type, $max=2097152) // Max = 2MB
      {
            //Сheck that we have a file
            if((!empty($_FILES["uploaded_file"])) && ($_FILES['uploaded_file']['error'] == 0)) {
              //Check if the file size is less than 350KbCHOOSE_FILE
              $filename = basename($_FILES['uploaded_file']['name']);

              if ($_FILES["uploaded_file"]["size"] < $max && ($_FILES['uploaded_file']['type']==$type || $type=='*')) {
                   //Determine the path to which we want to save this file

                   //$newname = JPATH_BASE.'/'.$dir_upload.'/'.$filename;
					$newname = $dir_upload.'/'.$filename;

                //Check if the file with the same name is already exists on the server
                //if (!file_exists($newname)) {
                  //Attempt to move the uploaded file to it's new place
                   if ((@move_uploaded_file($_FILES['uploaded_file']['tmp_name'],$newname))) {

                       //echo JText::_('FILE_SAVE_AS').$newname;
						print JFactory::getApplication()->enqueueMessage( JText::_('FILE_SAVE_AS').$newname );

                   }else{
                       //echo JText::_('ERROR_IN_UPLOAD');
				  	   print JFactory::getApplication()->enqueueMessage( JText::_('ERROR_IN_UPLOAD'), 'error' );
                   }
                //}else{
                  //  echo JText::_('ERROR_FILE').$_FILES["uploaded_file"]["name"].JText::_('ALREADY_EXISTS');
                //}
              }else{
                //echo JText::_('ONLY_FILES_UNDER').$max;
 		  	    print JFactory::getApplication()->enqueueMessage( JText::_('ONLY_FILES_UNDER').$max, 'error' );
              }
            }else{
             	//echo JText::_('NO_FILES_UPLOADES');
 		  	    print JFactory::getApplication()->enqueueMessage( JText::_('NO_FILES_UPLOADES'), 'error' );
            }
      }

    uploader($module_dir, $file_type, $module_max);

//Original in: http://webcheatsheet.com/php/file_upload.php
    }
}
?>
