Simple Upload 1.2

Create the directory, give write permission to webserver and enter the directory in parameter.
Enter the max lenght of file to upload (see php.ini to adjust this). Default is 2097152.
Enter the file type or * to all type files.

Then change access nivel to this module only to your users and not to all.

News in this version 1.2:
Overvrite existing files without confirmation.
Accept all file types with and selected types.

_______________________________________________________
Ribamar FS - http://ribafs.org - 21 de novembro de 2009
