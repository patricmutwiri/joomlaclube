<?php defined('_JEXEC') or die('Restricted access');
/*------------------------------------------------------------------------
# JOOFORGE.com - Il Web All'Italiana
# ------------------------------------------------------------------------
# Copyright © 2004-2009 JOOFORGE.com. Tutti i diritti riservati.
# Website:  http://www.jooforge.com/
-------------------------------------------------------------------------*/

$mostraOggi = $params->get('oggi');
$mostraSett = $params->get('sett');
$mostraMese = $params->get('mese');
$mostraUltimo = $params->get('ultimo');
$iconset = $params->get('iconset');

$db =& JFactory::getDBO();

// TOTALI
$utenti_totali = "SELECT COUNT(id) FROM #__users WHERE usertype <> \"administrator\" AND usertype <> \"superadministrator\"";
$db->setQuery($utenti_totali);
$totali =& $db->loadResultArray();

// OGGI
$reg_oggi = "SELECT COUNT(id) FROM #__users WHERE TO_DAYS(registerDate) = TO_DAYS(curdate()) AND usertype <> \"administrator\" AND usertype <> \"superadministrator\"";
$db->setQuery($reg_oggi);
$oggi =& $db->loadResultArray();

// IN SETTIMANA
$reg_sett = "SELECT COUNT(id) FROM #__users WHERE YEARWEEK(registerDate) = YEARWEEK(curdate()) AND usertype <> \"administrator\" AND usertype <> \"superadministrator\"";
$db->setQuery($reg_sett);
$sett =& $db->loadResultArray();

// NEL MESE
$reg_mese = "SELECT COUNT(id) FROM #__users WHERE MONTH(registerDate) = MONTH(curdate()) AND usertype <> \"administrator\" AND usertype <> \"superadministrator\"";
$db->setQuery($reg_mese);
$mese =& $db->loadResultArray();

// ULTIMO
$ultimo_reg = "SELECT username FROM #__users  WHERE block=\"0\" AND usertype <> \"administrator\" AND usertype <> \"superadministrator\" ORDER BY registerDate DESC LIMIT 1";
$db->setQuery($ultimo_reg);
$ultimo =& $db->loadResultArray();

require(JModuleHelper::getLayoutPath('mod_jf-totalusers'));

?>
