<?php defined('_JEXEC') or die('Restricted access');
/*------------------------------------------------------------------------
# JOOFORGE.com - Il Web All'Italiana
# ------------------------------------------------------------------------
# Copyright © 2004-2009 JOOFORGE.com. Tutti i diritti riservati.
# Website:  http://www.jooforge.com/
-------------------------------------------------------------------------*/
$doc=JFactory::getDocument();
$base=JURI::base();
$doc->addStyleSheet($base.'modules/mod_jf-totalusers/assets/css/totalusers.css');

echo '<ul class="jf-totalusers '.$iconset.'">';
	echo '<li class="totali">'.$totali[0].' '.JText::_('TOTALI').'</li>';
	if($mostraOggi == 1)
		echo '<li class="oggi">'.$oggi[0].' '.JText::_('OGGI').'</li>';
	if($mostraSett == 1)
		echo '<li class="sett">'.$sett[0].' '.JText::_('SETT').'</li>';
	if($mostraMese == 1)
		echo '<li class="mese">'.$mese[0].' '.JText::_('MESE').'</li>';
	if($mostraUltimo == 1)
		echo '<li class="ultimo">'.JText::_('ULTIMO').' <span>'.$ultimo[0].'</span></li>';
echo '</ul>';

?>
