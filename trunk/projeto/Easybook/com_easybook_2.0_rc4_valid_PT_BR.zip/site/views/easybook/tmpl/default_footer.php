<?php // no direct access
defined('_JEXEC') or die('Restricted access');
?>
<p id="easyfooter" align="center">
<a href='http://www.easy-joomla.org/' target='_blank'>
<img src="<?php echo JURI::base(); ?>components/com_easybook/images/logo_sm.png" class="png" alt="EasyBook" border="0" width="138" height="26" />
</a></p>
