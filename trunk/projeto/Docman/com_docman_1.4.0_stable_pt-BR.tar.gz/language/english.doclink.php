<?php
/**
 * DOCman 1.4.x - Joomla! Document Manager
 * @version $Id: english.doclink.php 765 2009-01-05 20:55:57Z mathias $
 * @package DOCman_1.4
 * @copyright (C) 2003-2009 Joomlatools
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.joomlatools.eu/ Official web site
 **/
defined('_VALID_MOS') or die('Restricted access');

/**
 * TRANSLATORS:
 * PLEASE ADD THE INFO BELOW
 */

/**
 * Language:
 * Creator:  
 * Website:  
 * E-mail:   
 * Revision: 
 * Date:
 */

define('_DML_DCL_TITLE', "Insert DOCman Link");
define('_DML_DCL_LOADING', "Loading ...");
define('_DML_DCL_MANAGER', "Manager");
define('_DML_DCL_SETTINGS', "Settings");

define('_DML_DCL_CATEGORY', "Category");
define('_DML_DCL_UP', "Up");

define('_DML_DCL_URL', "URL");
define('_DML_DCL_CAPTION', "Caption");
define('_DML_DCL_INSERTICON', "Insert filetype icon");
define('_DML_DCL_INSERTSIZE', "Insert file size");
define('_DML_DCL_INSERTDATE', "Insert file modification date");