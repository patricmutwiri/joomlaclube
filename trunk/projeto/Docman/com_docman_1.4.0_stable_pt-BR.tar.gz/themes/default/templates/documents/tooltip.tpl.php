<?php
/**
 * DOCman 1.4.x - Joomla! Document Manager
 * @version $Id: tooltip.tpl.php 773 2009-01-08 17:38:08Z mathias $
 * @package DOCman_1.4
 * @copyright (C) 2003-2009 Joomlatools
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.joomlatools.eu/ Official website
 **/
defined('_VALID_MOS') or die('Restricted access');

/**
 * Default DOCman Theme
 *
 * Creator:  Joomlatools
 * Website:  http://www.joomlatools.eu/
 * Email:    support@joomlatools.eu
 * Revision: 1.4
 * Date:     February 2007
 **/

/*
* Display document details (called by document/list_item.tpl.php)
*
* General variables  :
*	$this->theme->path (string) : template path
* 	$this->theme->name (string) : template name
* 	$this->theme->conf (object) : template configuartion parameters
*	$this->theme->icon (string) : template icon path
*   $this->theme->png  (boolean): browser png transparency support
*
* Template variables :
*  $this->doc->data	 (object) : holds the document data
*  $this->doc->links (object) : holds the document operations
*  $this->doc->paths (object) : holds the document paths
*/

if($this->theme->conf->details_filename)
{
	echo $this->doc->data->filename;
}

if($this->theme->conf->details_filesize)
{
    echo ' ('.$this->doc->data->filesize.') ';
}

if($this->theme->conf->details_filetype)
{
    echo $this->doc->data->mime;
}