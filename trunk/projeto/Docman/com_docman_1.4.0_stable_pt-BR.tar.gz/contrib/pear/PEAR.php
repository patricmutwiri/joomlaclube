<?php
// DOCMAN 1.4RC4 uses joomla's pear
if( defined('_DM_J15') ) {
    jimport('pear.PEAR');
} else {
	require_once $GLOBALS['mosConfig_absolute_path'].DS.'includes'.DS.'PEAR'.DS.'PEAR.php';
}
