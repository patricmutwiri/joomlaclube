<?php
/**
 * DOCman 1.4.x - Joomla! Document Manager
 * @version $Id: footer.php 773 2009-01-08 17:38:08Z mathias $
 * @package DOCman_1.4
 * @copyright (C) 2003-2009 Joomlatools
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.joomlatools.eu/ Official website
 **/
defined('_VALID_MOS') or die('Restricted access');

global $_DOCMAN;
?><span class="small">
DOCman v<?php echo _DM_VERSION;?> - 2003-<?php echo date('Y');?> Joomlatools - <a href="http://www.joomlatools.eu/" target="_blank">http://www.joomlatools.eu</a>
</span>