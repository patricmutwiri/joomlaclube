<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('AKEEBA_PRO', '0');
define('AKEEBA_VERSION', '3.0.b2');
define('AKEEBA_DATE', '2010-04-27');