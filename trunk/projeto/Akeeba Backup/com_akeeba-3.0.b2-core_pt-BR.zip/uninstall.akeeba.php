<?php
/**
 * @package Akeeba
 * @copyright Copyright (C) 2009 Nicholas K. Dionysopoulos. All rights reserved.
 *
 * Modelled after the work done by RocketWerx
 */

// no direct access
defined('_JEXEC') or die('Restricted access');
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

?>
<h1>Akeeba Uninstallation</h1>
