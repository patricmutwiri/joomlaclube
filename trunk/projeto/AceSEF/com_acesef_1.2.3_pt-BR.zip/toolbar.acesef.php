<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

$controller	= JRequest::getCmd('controller', 'acesef');

JHTML::_('behavior.switcher');

// Load submenus
$views	= array(''										=> JText::_('ACESEF_COMMON_HOME'),
				'&controller=config&task=edit'			=> JText::_('ACESEF_CPANEL_CONFIGURATION'),
				'&controller=extensions&task=view'		=> JText::_('ACESEF_CPANEL_EXTENSIONS'),
				'&controller=repository&task=view'		=> JText::_('ACESEF_CPANEL_SEF_URLS'),
				'&controller=metamanager&task=view'		=> JText::_('ACESEF_CPANEL_META_MANAGER'),
				'&controller=movedurls&task=view'		=> JText::_('ACESEF_CPANEL_MOVED_URLS'),
				'&controller=import&task=view'			=> JText::_('ACESEF_CPANEL_IMPORT'),
				'&controller=upgrade&task=view'			=> JText::_('ACESEF_CPANEL_UPGRADE'),
				'&controller=support&task=support'		=> JText::_('ACESEF_CPANEL_SUPPORT')
				);	

foreach($views as $key => $val) {
	$active	= ($controller == $key);
	JSubMenuHelper::addEntry($val, 'index.php?option=com_acesef'.$key, $active);
}
?>