<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport( 'joomla.application.component.model' );
jimport('joomla.filesystem.file');

// Control Panel Model Class
class AcesefModelAcesef extends JModel {
	
	// Main constructer
	function __construct() {
		parent::__construct();
	}
	
	// Check AceSEF version
	function &getVersion() {
		$version = array();
		
		// Get installed version
		$version['installed_version'] = $this->getInstalledVersion();
		
		// Get latest version
		$acesef_versions = @file_get_contents('http://www.joomace.net/acesef_info.txt');
		if (!$acesef_versions)
			$acesef_versions = '?.?.?';
		$acesef_versions = explode("\n", trim($acesef_versions));
		$version['latest_version'] = trim(array_shift($acesef_versions));
		
		// Set the version status
		$version['status'] = version_compare($version['installed_version'], $version['latest_version']);

		return $version;
	}
	
	function &getInstalledVersion()  {
        static $version;

        if (!isset($version)) {
            $xml = JFactory::getXMLParser('Simple');

            $xmlFile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'acesef.xml';

            if (JFile::exists($xmlFile)) {
                if ($xml->loadFile($xmlFile)) {
                    $root =& $xml->document;
                    $element =& $root->getElementByPath('version');
                    $version = $element ? $element->data() : '';
                }
            }
        }

        return $version;
    }
	
	// Get nr of URLs
	function &getURLs() {
		$urls = array();
		$db =& JFactory::getDBO();
		
		// Get nr of all SEF URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls WHERE date = '0000-00-00' AND url_real != ''");
  		$urls['sef'] = $db->loadResult();
		
		// Get nr of all Locked URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls WHERE locked = '1' ");
  		$urls['locked'] = $db->loadResult();
		
		// Get nr of all Custom URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls WHERE date > '0000-00-00' ");
  		$urls['custom'] = $db->loadResult();
		
		// Get nr of all 404 URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls WHERE url_real = '' ");
  		$urls['404'] = $db->loadResult();
		
		// Get nr of all Moved URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls_moved WHERE published = '1' ");
  		$urls['moved'] = $db->loadResult();
		
		// Get nr of all Blocked URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls WHERE blocked = '1' ");
  		$urls['blocked'] = $db->loadResult();

  		// Get nr of all Total URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls");
		$sef = $db->loadResult();
		
		$urls['total'] = $sef + $urls['moved'];
		
		return $urls;
	}
}
?>