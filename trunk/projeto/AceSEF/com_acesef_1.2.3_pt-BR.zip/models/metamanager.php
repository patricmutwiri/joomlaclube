<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport( 'joomla.application.component.model' );

// Meta Manager Model Class
class AcesefModelMetamanager extends JModel {
	
	var $_query;
	var $_data 			= null;
	var $_total 		= null;
	var $_pagination 	= null;
	
	// Main constructer
	function __construct()	{
		parent::__construct();
		
		global $mainframe, $option;
		
		$this->_buildViewQuery();

		// Get the pagination request variables
		$limit		= $mainframe->getUserStateFromRequest($option.'.metamanager.limit', 	'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart	= $mainframe->getUserStateFromRequest($option.'.metamanager.limitstart', 'limitstart', 0, 'int');
		
		// Limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		$this->setState($option.'.metamanager.limit', $limit);
		$this->setState($option.'.metamanager.limitstart', $limitstart);
	}
	
	// Save changes
	function save($id) {		
		$sef_id = JRequest::getVar('id');
		$title = JRequest::getVar('metatitle');
		$desc = JRequest::getVar('metadesc');
		$key = JRequest::getVar('metakey');
		
		// Some clean up
		$title = str_replace(array('\n\n', '\n', '\r', '"', '\'', '>'), array('', '', '', '', '', ''), $title);
		$desc = str_replace(array('\n\n', '\n', '\r', '"', '\'', ';'), array('', '', '', '', '', ''), $desc);
		$key = str_replace(array('\n\n', '\n', '\r', '"', '\'', ';'), array('', '', '', '', '', ''), $key);
		
		foreach ($sef_id as $prefix => $value) {
			$query = "UPDATE #__acesef_urls SET metatitle='".$title[$prefix]."', metadesc='".$desc[$prefix]."', metakey='".$key[$prefix]."' WHERE id=".$prefix;
			$this->_db->setQuery($query);
			$this->_db->query();
		}
	}
	
	// Get data about extensions
	function getData() {
		global $option;
		if (empty($this->_data)) {
			$this->_data=$this->_getList($this->_query, $this->getState($option.'.metamanager.limitstart'), $this->getState($option.'.metamanager.limit'));
		}
		return $this->_data;
	}
	
	// Get total extensions
	function getTotal() {
		// Load the content if it doesn't already exist
		if (empty($this->_total)) {
			$this->_total = $this->_getListCount($this->_query);	
		}
		return $this->_total;
	}
	
	// Get pagination
	function getPagination(){
		global $option;
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState($option.'.metamanager.limitstart'), $this->getState($option.'.metamanager.limit'));
		}
		return $this->_pagination;
	}
	
	// Finally build query
	function _buildViewQuery() {
		$where		= $this->_buildViewWhere();
		$orderby	= $this->_buildViewOrderBy();

		$this->_query = 'SELECT * FROM #__acesef_urls '.$where.$orderby;
	}

	// Query fileters
	function _buildViewWhere() {
		global $mainframe, $option;
		
        $search_sef			= $mainframe->getUserStateFromRequest($option.'.metamanager.search_sef', 		'search_sef', 		'');
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_order',		'filter_order',		'url_sef');
		$filter_order_dir	= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_order_dir',	'filter_order_dir',	'ASC');
		$type				= $mainframe->getUserStateFromRequest($option.'.metamanager.type', 				'type', 			1);
        $filter_component	= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_component', 	'filter_component', '');
		$filter_empty		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_empty',		'filter_empty',		-1);
		$filter_published	= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_published',	'filter_published',	-1);
		$filter_used		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_used', 		'filter_used',		-1);
		$filter_locked		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_locked', 	'filter_locked',	-1);
		$filter_blocked		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_blocked', 	'filter_blocked',	-1);
		$search_sef			= JString::strtolower($search_sef);

		$where = array();
		
		// Search SEF URL
		if ($search_sef != '') {
			$where[] = 'LOWER(url_sef) LIKE '.$this->_db->Quote('%'.$search_sef.'%');
		}
		
		// Type Filter
		if ($type == 1) { // SEF URLs
			$where[] = "date = '0000-00-00' AND url_real != ''";
		} elseif ($type == 2) { // Custom URLs
			$where[] = "date > '0000-00-00' AND url_real != ''";
		}
		
		// Component Filter
		if ($filter_component != '') {
			$where[]= "url_real LIKE '%option=$filter_component&%' OR url_real LIKE '%option=$filter_component'";
		}
		
		// Empty fields Filter
		if ($filter_empty != -1) {
			if ($filter_empty == 1)
				$where[]= "metatitle = ''";
			elseif ($filter_empty == 2)
				$where[]= "metadesc = ''";
			elseif ($filter_empty == 3)
				$where[]= "metakey = ''";
			elseif ($filter_empty == 4)
				$where[]= "metatitle = '' AND metadesc = '' AND metakey = ''";
			elseif ($filter_empty == 5)
				$where[]= "metatitle != '' AND metadesc != '' AND metakey != ''";
		}
		
		// Published Filter
		if ($filter_published != -1) {
			$where[] = 'published ='.$filter_published;
		}
	
		// Used Filter
		if ($filter_used != -1) {
			$where[] = 'used ='.$filter_used;
		}
		
		// Locked Filter
		if ($filter_locked != -1) {
			$where[] = 'locked ='.$filter_locked;
		}
		
		// Blocked Filter
		if ($filter_blocked != -1) {
			$where[] = 'blocked ='.$filter_blocked;
		}
		
		// Execute
		$where = (count($where) ? ' WHERE '. implode(' AND ', $where) : '');
		return $where;
	}
	
	// Orderby Filter
	function _buildViewOrderBy() {
		global $mainframe, $option;

		$filter_order		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_order',		'filter_order',		'url_sef',	'cmd');
		$filter_order_dir	= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_order_dir',	'filter_order_dir',	'ASC',		'word');

		if ($filter_order == 'a.used'){
			$orderby = ' ORDER BY category, used '.$filter_order_dir;
		} else {
			$orderby = ' ORDER BY '.$filter_order.' '.$filter_order_dir ;
		}
		return $orderby;
	}
}
?>