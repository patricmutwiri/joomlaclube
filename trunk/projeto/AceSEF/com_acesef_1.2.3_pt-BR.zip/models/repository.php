<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport( 'joomla.application.component.model' );

// Repository Model Class
class AcesefModelRepository extends JModel {
	
	var $_query;
	var $_data 			= null;
	var $_total 		= null;
	var $_pagination 	= null;
	
	// Main constructer
	function __construct()	{
		parent::__construct();
		
		global $mainframe, $option;
		
		$this->_buildViewQuery();

		// Get the pagination request variables
		$limit		= $mainframe->getUserStateFromRequest($option.'.repository.limit', 	'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart	= $mainframe->getUserStateFromRequest($option.'.repository.limitstart', 'limitstart', 0, 'int');
		
		// Limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		$this->setState($option.'.repository.limit', $limit);
		$this->setState($option.'.repository.limitstart', $limitstart);
	}
	
	// Get data about extensions
	function getData() {
		global $option;
		if (empty($this->_data)) {
			$this->_data=$this->_getList($this->_query, $this->getState($option.'.repository.limitstart'), $this->getState($option.'.repository.limit'));
		}
		return $this->_data;
	}
	
	// Get total extensions
	function getTotal() {
		// Load the content if it doesn't already exist
		if (empty($this->_total)) {
			$this->_total = $this->_getListCount($this->_query);	
		}
		return $this->_total;
	}
	
	// Get pagination
	function getPagination(){
		global $option;
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState($option.'.repository.limitstart'), $this->getState($option.'.repository.limit'));
		}
		return $this->_pagination;
	}
	
	// Finally build query
	function _buildViewQuery() {
		$where		= $this->_buildViewWhere();
		$orderby	= $this->_buildViewOrderBy();

		$this->_query = 'SELECT * FROM #__acesef_urls '.$where.$orderby;
	}

	// Query fileters
	function _buildViewWhere() {
		global $mainframe, $option;
		
        $search_sef			= $mainframe->getUserStateFromRequest($option.'.repository.search_sef', 		'search_sef', 		'');
        $search_real		= $mainframe->getUserStateFromRequest($option.'.repository.search_real', 		'search_real', 		'');
        $search_itemid		= $mainframe->getUserStateFromRequest($option.'.repository.search_itemid', 		'search_itemid', 	'');
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.repository.filter_order',		'filter_order',		'url_sef');
		$filter_order_dir	= $mainframe->getUserStateFromRequest($option.'.repository.filter_order_dir',	'filter_order_dir',	'ASC');
		$type				= $mainframe->getUserStateFromRequest($option.'.repository.type', 				'type', 			1);
        $filter_component	= $mainframe->getUserStateFromRequest($option.'.repository.filter_component', 	'filter_component', '');
        $filter_lang		= $mainframe->getUserStateFromRequest($option.'.repository.filter_lang', 		'filter_lang', '');
		$filter_published	= $mainframe->getUserStateFromRequest($option.'.repository.filter_published',	'filter_published',	-1);
		$filter_used		= $mainframe->getUserStateFromRequest($option.'.repository.filter_used', 		'filter_used',		-1);
		$filter_locked		= $mainframe->getUserStateFromRequest($option.'.repository.filter_locked', 		'filter_locked',	-1);
		$filter_blocked		= $mainframe->getUserStateFromRequest($option.'.repository.filter_blocked', 	'filter_blocked',	-1);
		$search_sef			= JString::strtolower($search_sef);
		$search_real		= JString::strtolower($search_real);
		$search_itemid		= JString::strtolower($search_itemid);

		$where = array();
		
		// Search SEF URL
		if ($search_sef != '') {
			$where[] = 'LOWER(url_sef) LIKE '.$this->_db->Quote('%'.$search_sef.'%');
		}
		
		// Search Real URL
		if ($search_real != '' && $this->type != 4) {
			$where[] = 'LOWER(url_real) LIKE '.$this->_db->Quote('%'.$search_real.'%');
		}
		
		// Search ItemID
		if ($search_itemid != '' && $this->type != 4) {
			$where[]= "LOWER(url_real) LIKE '%Itemid=$search_itemid&%' OR LOWER(url_real) LIKE '%Itemid=$search_itemid'";
		}
		
		// Type Filter
		if ($type == 1) {
			$where[] = "date = '0000-00-00' AND url_real != '' "; // SEF URLs
		}  elseif ($type == 2) {
			$where[] = "locked = '1' "; // Locked URLs
		} elseif ($type == 3) {
			$where[] = "date > '0000-00-00' AND url_real != ''  "; // Custom URLs
		} elseif ($type == 4) {
			$where[] = "url_real = '' "; // 404 URLs
		}
		
		// Component Filter
		if ($filter_component != '' && $type != 4) {
			$where[]= "url_real LIKE '%option=$filter_component&%' OR url_real LIKE '%option=$filter_component'";
		}
		
		// Langauge Filter
		if ($filter_lang != '') {
			$where[]= "url_real LIKE '%lang=$filter_lang&%' OR url_real LIKE '%lang=$filter_lang'";
		}
		
		// Published Filter
		if ($filter_published != -1) {
			$where[] = 'published ='.$filter_published;
		}
	
		// Used Filter
		if ($filter_used != -1) {
			$where[] = 'used ='.$filter_used;
		}
		
		// Locked Filter
		if ($filter_locked != -1) {
			$where[] = 'locked ='.$filter_locked;
		}
		
		// Blocked Filter
		if ($filter_blocked != -1) {
			$where[] = 'blocked ='.$filter_blocked;
		}
		
		// Execute
		$where = (count($where) ? ' WHERE '. implode(' AND ', $where) : '');
		return $where;
	}
	
	// Orderby Filter
	function _buildViewOrderBy() {
		global $mainframe, $option;

		$filter_order		= $mainframe->getUserStateFromRequest($option.'filter_order',		'filter_order',		'url_sef',	'cmd');
		$filter_order_dir	= $mainframe->getUserStateFromRequest($option.'filter_order_dir',	'filter_order_dir',	'ASC',		'word');

		if ($filter_order == 'a.used'){
			$orderby = ' ORDER BY category, used '.$filter_order_dir;
		} else {
			$orderby = ' ORDER BY '.$filter_order.' '.$filter_order_dir ;
		}
		return $orderby;
	}
	
	// Delete URLs
	function delete($id) {
		$sefurl =& JTable::getInstance('acesef_urls', 'Table');
		$sefurl->load ($id);

		// First remove the Joomla user account
		if ($sefurl->locked == 0) {
			$sefurl->delete();
		}
	}
	
	// Publish URLs
	function publish($id) {
		$sefurl =& JTable::getInstance('acesef_urls', 'Table');
		$sefurl->load ($id);

		// First remove the Joomla user account
		if ($sefurl->published == 0) {
			$sefurl->published = 1;
		} else {
			$sefurl->published = 0;
		}
		$sefurl->store();
	}
	
	// Use the URL
	function used($id) {
		$sefurl =& JTable::getInstance('acesef_urls', 'Table');
		$sefurl->load($id);

		// Set used to 1 for active URL
		$sefurl->used = 10;
		$sefurl->store();

		// Set used to 0 for all inactive SEF URLS
		$query = "UPDATE #__acesef_urls SET used = 0 WHERE url_sef = '".$sefurl->url_sef."' AND id != ".$sefurl->id;
		$this->_db->setQuery($query);
		$this->_db->query();
	}

	// Lock URLs
	function lock($id) {
		$sefurl =& JTable::getInstance('acesef_urls', 'Table');
		$sefurl->load ($id);

		if ($sefurl->locked == 0) {
			$sefurl->locked = 1;
		} else {
			$sefurl->locked = 0;
		}
		$sefurl->store();
	}
	
	// Block URLs
	function block($id) {
		$sefurl =& JTable::getInstance('acesef_urls', 'Table');
		$sefurl->load ($id);

		if ($sefurl->blocked == 0) {
			$sefurl->blocked = 1;
			$sefurl->sef_tmp_url = $sefurl->url_sef ;
			$sefurl->url_sef = $sefurl->url_real;
		} else {
			$sefurl->blocked = 0;
			$sefurl->url_sef = $sefurl->sef_tmp_url;
		}
		$sefurl->store();
	}
	
	function WhereIds() {
		$ids = JRequest::getVar('cid', array(), 'post', 'array');	
		$where = '';
		if( count($ids) > 0 )
			$where = ' WHERE `id` IN ('.implode(', ', $ids).')';

		return $where;
	}
	
	function deleteFiltered() {
        $query = "DELETE FROM `#__acesef_urls` ".$this->_buildViewWhere();
        $this->_db->setQuery($query);
        if (!$this->_db->query()) {
            $this->setError( $this->_db->getErrorMsg());
            return false;
        }

        return true;
    }
	
	// Export URLs
	function export($where = '') {
        $config =& JFactory::getConfig();
        $dbprefix = $config->getValue('config.dbprefix');
        $sql_data = '';
        $filename = 'acesef_urls.sql';
        $fields = array('url_sef', 'url_real', 'metadesc', 'metakey', 'metatitle', 'metalang', 'metarobots', 'metagoogle', 'linkcanonical', 'published', 'used', 'locked', 'blocked', 'notes', 'sef_tmp_url', 'checked_out', 'date');

        $query = "SELECT * FROM `#__acesef_urls`";
        if(!empty($where)) {
            $query .= $where;
        }
        $this->_db->setQuery($query);
        $rows = $this->_db->loadObjectList();

        if (!empty($rows)) {
            foreach ($rows as $row) {
                $values = array();
                foreach ($fields as $field) {
                    if (isset($row->$field)) {
                        $values[] = "'".str_replace(array("'", ";"), array("", ""), $row->$field)."'";
                    } else {
                        $values[] = "''";
                    }
                }
                $sql_data .= "INSERT INTO `{$dbprefix}acesef_urls` (".implode(', ', $fields).") VALUES (".implode(', ', $values).");\n";
            }
        } else {
            return false;
        }

        if( !headers_sent() ) {
            // flush the output buffer
            while( ob_get_level() > 0 ) {
                ob_end_clean();
            }

            ob_start();
            header ('Expires: 0');
            header ('Last-Modified: '.gmdate ('D, d M Y H:i:s', time()) . ' GMT');
            header ('Pragma: public');
            header ('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header ('Accept-Ranges: bytes');
            header ('Content-Length: ' . strlen($sql_data));
            header ('Content-Type: Application/octet-stream');
            header ('Content-Disposition: attachment; filename="' . $filename . '"');
            header ('Connection: close');

            echo($sql_data);

            ob_end_flush();
            die();
            return true;
        } else {
            return false;
        }
    }
}
?>