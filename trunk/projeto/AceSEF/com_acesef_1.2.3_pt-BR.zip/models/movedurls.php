<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport( 'joomla.application.component.model' );

// Repository Model Class
class AcesefModelMovedurls extends JModel {
	
	var $_query;
	var $_data 			= null;
	var $_total 		= null;
	var $_pagination 	= null;
	
	// Main constructer
	function __construct()	{
		parent::__construct();
		
		global $mainframe, $option;
		
		$this->_buildViewQuery();

		// Get the pagination request variables
		$limit		= $mainframe->getUserStateFromRequest($option.'.movedurls.limit', 	'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart	= $mainframe->getUserStateFromRequest($option.'.movedurls.limitstart', 'limitstart', 0, 'int');
		
		// Limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		$this->setState($option.'.movedurls.limit', $limit);
		$this->setState($option.'.movedurls.limitstart', $limitstart);
	}
	
	// Get data about extensions
	function getData() {
		global $option;
		if (empty($this->_data)) {
			$this->_data=$this->_getList($this->_query, $this->getState($option.'.movedurls.limitstart'), $this->getState($option.'.movedurls.limit'));
		}
		return $this->_data;
	}
	
	// Get total extensions
	function getTotal() {
		// Load the content if it doesn't already exist
		if (empty($this->_total)) {
			$this->_total = $this->_getListCount($this->_query);	
		}
		return $this->_total;
	}
	
	// Get pagination
	function getPagination(){
		global $option;
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState($option.'.movedurls.limitstart'), $this->getState($option.'.movedurls.limit'));
		}
		return $this->_pagination;
	}
	
	// Finally build query
	function _buildViewQuery() {
		$where		= $this->_buildViewWhere();
		$orderby	= $this->_buildViewOrderBy();

		$this->_query = 'SELECT * FROM #__acesef_urls_moved '.$where.$orderby;
	}

	// Query fileters
	function _buildViewWhere() {
		global $mainframe, $option;
		
        $search_old			= $mainframe->getUserStateFromRequest($option.'.movedurls.search_old', 			'search_old', 		'');
        $search_new			= $mainframe->getUserStateFromRequest($option.'.movedurls.search_new', 			'search_new', 		'');
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.movedurls.filter_order',		'filter_order',		'url_old');
		$filter_order_dir	= $mainframe->getUserStateFromRequest($option.'.movedurls.filter_order_dir',	'filter_order_dir',	'ASC');
		$filter_published	= $mainframe->getUserStateFromRequest($option.'.movedurls.filter_published',	'filter_published',	-1);
		$search_old			= JString::strtolower($search_old);
		$search_new			= JString::strtolower($search_new);

		$where = array();
		
		// Search SEF URL
		if ($search_old != '') {
			$where[] = 'LOWER(url_old) LIKE '.$this->_db->Quote('%'.$search_old.'%');
		}
		
		// Search Real URL
		if ($search_new != '') {
			$where[] = 'LOWER(url_new) LIKE '.$this->_db->Quote('%'.$search_new.'%');
		}
		
		// Published Filter
		if ($filter_published != -1) {
			$where[] = 'published ='.$filter_published;
		}
		
		// Execute
		$where = (count($where) ? ' WHERE '. implode(' AND ', $where) : '');
		return $where;
	}
	
	// Orderby Filter
	function _buildViewOrderBy() {
		global $mainframe, $option;

		$filter_order		= $mainframe->getUserStateFromRequest($option.'.movedurls.filter_order',		'filter_order',		'url_old',	'cmd');
		$filter_order_dir	= $mainframe->getUserStateFromRequest($option.'.movedurls.filter_order_dir',	'filter_order_dir',	'ASC',		'word');

		if ($filter_order == 'a.url_old'){
			$orderby = ' ORDER BY category, url_old '.$filter_order_dir;
		} else {
			$orderby = ' ORDER BY '.$filter_order.' '.$filter_order_dir ;
		}
		return $orderby;
	}
	
	// Delete URLs
	function delete($id) {
		$sefurl =& JTable::getInstance('acesef_urls_moved', 'Table');
		$sefurl->load($id);

		// First remove the Joomla user account
		$sefurl->delete();
	}
	
	// Publish URLs
	function publish($id) {
		$sefurl =& JTable::getInstance('acesef_urls_moved', 'Table');
		$sefurl->load($id);

		// First remove the Joomla user account
		if ($sefurl->published == 0) {
			$sefurl->published = 1;
		} else {
			$sefurl->published = 0;
		}
		$sefurl->store();
	}
	
	function WhereIds() {
		$ids = JRequest::getVar('cid', array(), 'post', 'array');	
		$where = '';
		if( count($ids) > 0 )
			$where = ' WHERE `id` IN ('.implode(', ', $ids).')';

		return $where;
	}
	
	function deleteFiltered() {
        $query = "DELETE FROM `#__acesef_urls_moved` ".$this->_buildViewWhere();
        $this->_db->setQuery($query);
        if (!$this->_db->query()) {
            $this->setError( $this->_db->getErrorMsg());
            return false;
        }

        return true;
    }
	
	// Export URLs
	function export($where = '') {
        $config =& JFactory::getConfig();
        $dbprefix = $config->getValue('config.dbprefix');
        $sql_data = '';
        $filename = 'acesef_urls_moved.sql';
        $fields = array('url_old', 'url_new', 'published', 'hits', 'last_hit');

        $query = "SELECT * FROM `#__acesef_urls_moved`";
        if(!empty($where)) {
            $query .= $where;
        }
        $this->_db->setQuery($query);
        $rows = $this->_db->loadObjectList();

        if (!empty($rows)) {
            foreach ($rows as $row) {
                $values = array();
                foreach ($fields as $field) {
                    if (isset($row->$field)) {
                        $values[] = "'".str_replace(array("'", ";"), array("", ""), $row->$field)."'";
                    } else {
                        $values[] = "''";
                    }
                }
                $sql_data .= "INSERT INTO `{$dbprefix}acesef_urls_moved` (".implode(', ', $fields).") VALUES (".implode(', ', $values).");\n";
            }
        } else {
            return false;
        }

        if( !headers_sent() ) {
            // flush the output buffer
            while( ob_get_level() > 0 ) {
                ob_end_clean();
            }

            ob_start();
            header ('Expires: 0');
            header ('Last-Modified: '.gmdate ('D, d M Y H:i:s', time()) . ' GMT');
            header ('Pragma: public');
            header ('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header ('Accept-Ranges: bytes');
            header ('Content-Length: ' . strlen($sql_data));
            header ('Content-Type: Application/octet-stream');
            header ('Content-Disposition: attachment; filename="' . $filename . '"');
            header ('Connection: close');

            echo($sql_data);

            ob_end_flush();
            die();
            return true;
        } else {
            return false;
        }
    }
}
?>