<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Support Controller Class
class AcesefControllerSupport extends AcesefController {

	// Main constructer
    function __construct() {
        parent::__construct();
    }
	
	// Support page
    function support() {
        JRequest::setVar('view', 'support');
        JRequest::setVar('layout' , 'support');

        parent::display();
    }
    
	// Changelog page
    function changelog() {
        JRequest::setVar('view', 'support');
        JRequest::setVar('layout', 'changelog');
        
        parent::display();
    }
    
	// Changelog page
    function translators() {
        JRequest::setVar('view', 'support');
        JRequest::setVar('layout', 'translators');
        
        parent::display();
    }
}
?>