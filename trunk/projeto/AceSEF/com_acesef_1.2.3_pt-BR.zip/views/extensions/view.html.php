<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport('joomla.application.component.view');


// Extensions View Class
class AcesefViewExtensions extends JView {

	// Display extensions
	function view($tpl = null) {
		global $mainframe, $option;
		
		// Get data from the model
		$items		= & $this->get('Data');
		$info		= & $this->get('Info');
		$total		= & $this->get('Total');
		$pagination = & $this->get('Pagination');
		
		// Import CSS
  		$document =& JFactory::getDocument();
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set Toolbar
		JToolBarHelper::title(JText::_('ACESEF_EXTENSION_DEFAULT_TITLE'), 'acesef');
		JToolBarHelper::custom('edit', 'editurl.png', 'editurl.png', JTEXT::_('Edit'), true);
		JToolBarHelper::custom('view_uninstall', 'uninstall.png', 'uninstall.png', JTEXT::_('Uninstall'), true);
		JToolBarHelper::divider();
		JToolBarHelper::custom('view_save', 'save1.png', 'save1.png', JText::_('Save'), false);
		JToolBarHelper::custom('view_savepurge', 'save1.png', 'save1.png', JText::_('ACESEF_CONFIG_SAVE_PURGE'), true);
		JToolBarHelper::divider();
		JToolBarHelper::custom('view_home', 'home.png', 'home.png', JText::_('ACESEF_COMMON_HOME'), false);
		
		// Get search values
		$search_name	= $mainframe->getUserStateFromRequest($option.'.extensions.search_name', 'search_name', '', 'string');
		$search_ver		= $mainframe->getUserStateFromRequest($option.'.extensions.search_ver', 'search_ver', '', 'string');
		$search_auth	= $mainframe->getUserStateFromRequest($option.'.extensions.search_auth', 'search_auth', '', 'string');
		$search_name	= JString::strtolower($search_name);
		$search_ver		= JString::strtolower($search_ver);
		$search_auth	= JString::strtolower($search_auth);
		
		// Make the input box for search extension name
        $lists['search_name'] = "<input type=\"text\" name=\"search_name\" value=\"{$search_name}\" size=\"40\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";

		// Make the input box for search extension version
        $lists['search_ver'] = "<input type=\"text\" name=\"search_ver\" value=\"{$search_ver}\" size=\"10\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";
		
        // Make the input box for search extension author
        $lists['search_auth'] = "<input type=\"text\" name=\"search_auth\" value=\"{$search_auth}\" size=\"30\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";
        
		// Set router
		foreach ($items as $item) {
			// Make a select list
			$selections = array();
			if ($item->router_type == 1) {
				$selections[] = JHTML::_('select.option', 1, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_ACESEF'));
				$selections[] = JHTML::_('select.option', 0, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_DISABLE'));
			}
			if ($item->router_type == 2) {
				$selections[] = JHTML::_('select.option', 2, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_15_ROUTER'));
				$selections[] = JHTML::_('select.option', 1, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_ACESEF'));
				$selections[] = JHTML::_('select.option', 0, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_DISABLE'));
			}
			if ($item->router_type == 3) {
				$selections[] = JHTML::_('select.option', 3, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_EXTENSION'));
				$selections[] = JHTML::_('select.option', 1, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_ACESEF'));
				$selections[] = JHTML::_('select.option', 0, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_DISABLE'));
			}
			if ($item->router_type == 4) {
				$selections[] = JHTML::_('select.option', 3, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_EXTENSION'));
				$selections[] = JHTML::_('select.option', 2, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_15_ROUTER'));
				$selections[] = JHTML::_('select.option', 1, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_ACESEF'));
				$selections[] = JHTML::_('select.option', 0, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_DISABLE'));
			}
			if ($item->router_type == 5) {
				$selections[] = JHTML::_('select.option', 4, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_J10_WITH_PREFIX'));
				$selections[] = JHTML::_('select.option', 5, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_J10_WITHOUT_PREFIX'));
				$selections[] = JHTML::_('select.option', 1, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_ACESEF'));
				$selections[] = JHTML::_('select.option', 0, JTEXT::_('ACESEF_EXTENSION_VIEW_SELECT_DISABLE'));
			}
			
			// Routers options
			$fieldname = 'rewrite_rule['.$item->id.']';
			$item->rewrite_rule = JHTML::_('select.genericlist', $selections, $fieldname, 'class="inputbox" size="1"', 'value', 'text', $item->rewrite_rule);
			
			// Skip title option
			$fieldname_skip_title = 'skip_title['.$item->id.']';
			$item->skip_title = $lists['mode'] = JHTMLSelect::booleanlist($fieldname_skip_title, null, $item->skip_title);
		}
		
		$this->assignRef('lists',		$lists);
		$this->assignRef('items',		$items);
		$this->assignRef('info',		$info);
		$this->assignRef('pagination',	$pagination);

		parent::display($tpl);
	}
}
?>