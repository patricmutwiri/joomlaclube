<?php
/*
* @package		AceSEF
* @subpackage	Search
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_search extends AceSEFTools {

	var $params;
	
	function beforeBuildRoute(&$uri) {
        $ord = $uri->getVar('ordering', null);
        if($ord == '') {
            $uri->delVar('ordering');
        }
        
        $phrase = $uri->getVar('searchphrase', null);
        if($phrase == 'all') {
            $uri->delVar('searchphrase');
        }
		return;
    }
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();
		
		$this->params = AceSEFTools::getExtParams('com_search');
		
		if(isset($ordering))
            $title[] = $ordering;
        
        if(isset($searchphrase))
            $title[] = $searchphrase;
        
        if(isset($submit))
            $title[] = $submit;
		
		if(isset($searchword))
            $title[] = $searchword;
			
		return $title;
	}
	
	function metaTags(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$meta = array();

		$config =& JFactory::getConfig();
		
		$enable_title		= AceSEFTools::autoTitle($this->params->get('enable_title', 'global'));
		$enable_desc		= AceSEFTools::autoDesc($this->params->get('enable_desc', 'global'));
		$enable_key			= AceSEFTools::autoKey($this->params->get('enable_key', 'global'));
		$separator			= $this->params->get('separator', '-');
		$sitename			= $config->getValue('sitename');
		$custom_sitename	= $this->params->get('custom_sitename', '');
		$use_sitename		= $this->params->get('use_sitename', '2');
		$title_prefix		= $this->params->get('title_prefix', '');
		$title_suffix		= $this->params->get('title_suffix', '');
		$desc_length		= $this->params->get('desc_length', '250');
		$keywords_word		= $this->params->get('keywords_word', '3');
		$keywords_count		= $this->params->get('keywords_count', '15');
		$blacklist			= $this->params->get('blacklist', '');
		
		$title = $desc = "";

		if(isset($searchword)){
			$title	= JText::_('SEARCH')." ".$separator." ".$searchword;
			$desc	= AceSEFTools::cleanText($searchword);
		} else {
			$title = AceSEFTools::getMenuTitle($option, $Itemid);
		}
		
		// Set meta tags
		if($enable_title && !empty($title)){
			// Prepare meta title			
			if(!empty($custom_sitename))
				$sitename = $custom_sitename;
			
			if($use_sitename == 1)
				$title = $sitename." ".$separator." ".$title;
			elseif ($use_sitename == 2)
				$title = $title." ".$separator." ".$sitename;
				
			if(!empty($title_prefix))
				$title = $title_prefix." ".$separator." ".$title;
				
			if(!empty($title_suffix))
				$title = $title." ".$separator." ".$title_suffix;
			
			$meta['metatitle']	= $title;
		}
	
		if($enable_desc && !empty($desc))
			$meta['metadesc']	= AceSEFTools::cleanText($desc, $desc_length);
		if($enable_key && !empty($desc))
			$meta['metakey']	= AceSEFTools::generateKeywords($desc, $blacklist, $keywords_count, $keywords_word);
		
		return $meta;
	}
}
?>