<?php
/*
* @package		AceSEF
* @subpackage	Contact
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_contact extends AceSEFTools {

	var $params;
	var $title_cat;
	var $title_item;
	var $desc_cat;
	
	function getCategoryTitle($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();

        $database->setQuery("SELECT title, alias, description$joomfish FROM #__categories WHERE id =".$id);
        $rows = $database->loadRow();

		$name = (($this->params->get('categoryid_inc', '1') != '1') ? $id.'-' : '');
		if(AceSEFTools::urlPart($this->params->get('category_part', 'global')) == 'title')
			$name .= $rows[0];
		else
			$name .= $rows[1];
		
		$this->desc_cat = $rows[2];
		$this->title_cat = $name;
			
		return $name;
    }

    function getContactTitle($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();

        $database->setQuery("SELECT name, alias, catid$joomfish FROM #__contact_details WHERE id =".$id);
        $rows = $database->loadRow();

		$name = (($this->params->get('contactid_inc', '1') != '1') ? $id.'-' : '');
		if(AceSEFTools::urlPart($this->params->get('category_part', 'global')) == 'title')
			$name .= $rows[0];
		else
			$name .= $rows[1];
		
		if($this->params->get('category_inc', '1') != '2') {
			$this->title_item = array($rows[0]);
			return array($name);
		} else {
			$this->title_item = array($this->getCategoryTitle($rows[2]), $rows[0]);
			return array($this->getCategoryTitle($rows[2]), $name);
		}
    }
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();
		
		$this->params = AceSEFTools::getExtParams('com_contact');
		
		if(isset($view)) {
            switch($view) {
				case 'category':
                    if(isset($catid))
                        $title[] = $this->getCategoryTitle($catid);
                    break;
                case 'contact':
					if(isset($id))
						$title = array_merge($title, $this->getContactTitle($id));
                    break;
            }
        }

		return $title;
	}
	
	function metaTags(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$meta = array();

		$config =& JFactory::getConfig();
		
		$enable_title		= AceSEFTools::autoTitle($this->params->get('enable_title', 'global'));
		$enable_desc		= AceSEFTools::autoDesc($this->params->get('enable_desc', 'global'));
		$enable_key			= AceSEFTools::autoKey($this->params->get('enable_key', 'global'));
		$separator			= $this->params->get('separator', '-');
		$sitename			= $config->getValue('sitename');
		$custom_sitename	= $this->params->get('custom_sitename', '');
		$use_sitename		= $this->params->get('use_sitename', '2');
		$title_prefix		= $this->params->get('title_prefix', '');
		$title_suffix		= $this->params->get('title_suffix', '');
		$desc_length		= $this->params->get('desc_length', '250');
		$keywords_word		= $this->params->get('keywords_word', '3');
		$keywords_count		= $this->params->get('keywords_count', '15');
		$blacklist			= $this->params->get('blacklist', '');
		
		$title = $desc = "";
		
		if (isset($view)){
			switch ($view){
				case 'category': 
					if(isset($catid)){
						$title	= $this->title_cat;
						$desc	= AceSEFTools::cleanText($this->desc_cat);
					}
					break;
				case 'contact': 
					if(isset($id))
						$title	= implode(" ".$separator." ", array_reverse($this->title_item));
					break;
			}
		}
		
		// Set meta tags
		if($enable_title && !empty($title)){
			// Prepare meta title			
			if(!empty($custom_sitename))
				$sitename = $custom_sitename;
			
			if($use_sitename == 1)
				$title = $sitename." ".$separator." ".$title;
			elseif ($use_sitename == 2)
				$title = $title." ".$separator." ".$sitename;
				
			if(!empty($title_prefix))
				$title = $title_prefix." ".$separator." ".$title;
				
			if(!empty($title_suffix))
				$title = $title." ".$separator." ".$title_suffix;
			
			$meta['metatitle']	= $title;
		}
		
		if($enable_desc && !empty($desc))
			$meta['metadesc']	= AceSEFTools::clipDesc($desc, $desc_length);
		if($enable_key && !empty($desc))
			$meta['metakey']	= AceSEFTools::generateKeywords($desc, $blacklist, $keywords_count, $keywords_word);

		return $meta;
	}
}
?>