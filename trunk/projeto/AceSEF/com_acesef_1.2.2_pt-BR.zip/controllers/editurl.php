<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Edit URL Controller Class
class AcesefControllerEditurl extends AcesefController {
	
	// Main constructer
	function __construct() {
		parent::__construct();
	}

	// Edit URL
	function edit() {
		JRequest::setVar('hidemainmenu', 1);
		$model = $this->getModel('editurl');
		$view = $this->getView('editurl', 'html');
		$view->setModel($model, true);

		$view->edit();
	}
	
	// Save changes
	function save() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('editurl');
		if (!$model->save($id)) {
		 	return JError::raiseWarning(500, JTEXT::_('ACESEF_URL_NOT_SAVED'));
			return JError::raiseWarning(500, $url_record->getError());
		}
		// Return to repository
		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view', JTEXT::_('ACESEF_URL_SAVED'));
	}
	
	// Apply changes
	function apply() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('editurl');
		if (!$model->save($id)) {
		 	return JError::raiseWarning(500, JTEXT::_('ACESEF_URL_NOT_SAVED'));
			return JError::raiseWarning(500, $url_record->getError());
		}
		// Return to edit url page
		$this->setRedirect('index.php?option=com_acesef&controller=editurl&task=edit&cid[]='.$id, JTEXT::_('ACESEF_URL_SAVED'));
	}
	
	// Cancel changes
	function cancel() {
		// Return to repository
		$this->setRedirect('index.php?option=com_acesef&controller=repository&task=view', JTEXT::_('ACESEF_URL_NOT_SAVED'));
	}
}
?>