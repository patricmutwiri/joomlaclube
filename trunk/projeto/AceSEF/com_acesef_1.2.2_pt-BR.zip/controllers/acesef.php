<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Control Panel Controller Class
class AcesefControllerAcesef extends AcesefController {

	// Main construct
 	function __construct() {
		parent::__construct();	
	}
	
	// Call display function of Model
	function display() {
		parent::display();
	}
}
?>