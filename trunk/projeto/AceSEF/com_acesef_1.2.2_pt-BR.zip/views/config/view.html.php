<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport( 'joomla.application.component.view');

// Configuration View Class
class AcesefViewConfig extends JView {

	// Edit configuration
	function edit($tpl = null) {
		$db =& JFactory::getDBO();
		
		// Import CSS
  		$document =& JFactory::getDocument();
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set Toolbar
		JToolBarHelper::title(JText::_('ACESEF_CONFIG_TITLE'), 'acesef');
		JToolBarHelper::custom('save', 'save1.png', 'save1.png', JTEXT::_('Save'), false);
		JToolBarHelper::custom('apply', 'approve.png', 'approve.png', JTEXT::_('Apply'), false);
		JToolBarHelper::custom('cancel', 'cancel1.png', 'cancel1.png', JTEXT::_('Cancel'), false);
		JToolBarHelper::divider();
		$bar =& JToolBar::getInstance();
		$bar->appendButton('Confirm', JText::_('ACESEF_CONFIG_WARNING_SAVE'), 'save1', JText::_('ACESEF_CONFIG_SAVE_PURGE'), 'savepurge', false, false);
		$bar->appendButton('Confirm', JText::_('ACESEF_CONFIG_WARNING_SAVE'), 'approve', JText::_('ACESEF_CONFIG_APPLY_PURGE'), 'applypurge', false, false);

		
		// Create the select lists
  		JHTML::_('behavior.mootools');
		$document->addScriptDeclaration("window.addEvent('domready', function(){ var JTooltips = new Tips($$('.hasTip'), { maxTitleChars: 60, fixed: false}); });");

		// Yes-No options list
		smart_import('joomla.html.html.select');
		// Main
		$lists['mode'] 						= JHTMLSelect::booleanlist('mode',					null,	$this->acesef_config->mode);
		$lists['url_lowercase'] 			= JHTMLSelect::booleanlist('url_lowercase',			null,	$this->acesef_config->url_lowercase);
		$lists['numeral_duplicated'] 		= JHTMLSelect::booleanlist('numeral_duplicated',	null,	$this->acesef_config->numeral_duplicated);
		// JoomFish
		$lists['joomfish_lang_code'] 		= JHTMLSelect::booleanlist('joomfish_lang_code',	null,	$this->acesef_config->joomfish_lang_code);
		$lists['joomfish_trans_url'] 		= JHTMLSelect::booleanlist('joomfish_trans_url',	null,	$this->acesef_config->joomfish_trans_url);
		// Advanced
		$lists['append_itemid'] 			= JHTMLSelect::booleanlist('append_itemid',			null,	$this->acesef_config->append_itemid);
		$lists['remove_trailing_slash'] 	= JHTMLSelect::booleanlist('remove_trailing_slash',	null,	$this->acesef_config->remove_trailing_slash);
		$lists['redirect_to_www'] 			= JHTMLSelect::booleanlist('redirect_to_www',		null,	$this->acesef_config->redirect_to_www);
		// Very Advanced
		$lists['insert_active_itemid'] 		= JHTMLSelect::booleanlist('insert_active_itemid',	null,	$this->acesef_config->insert_active_itemid);
		$lists['redirect_to_sef'] 			= JHTMLSelect::booleanlist('redirect_to_sef',		null,	$this->acesef_config->redirect_to_sef);
		$lists['record_duplicated'] 		= JHTMLSelect::booleanlist('record_duplicated',		null,	$this->acesef_config->record_duplicated);
		$lists['remove_sid'] 				= JHTMLSelect::booleanlist('remove_sid',			null,	$this->acesef_config->remove_sid);
		$lists['set_query_string'] 			= JHTMLSelect::booleanlist('set_query_string',		null,	$this->acesef_config->set_query_string);
		$lists['force_ssl'] 				= JHTMLSelect::booleanlist('force_ssl',				null,	$this->acesef_config->force_ssl);
		$lists['utf8_url'] 					= JHTMLSelect::booleanlist('utf8_url',				null,	$this->acesef_config->utf8_url);
		$lists['append_non_sef'] 			= JHTMLSelect::booleanlist('append_non_sef',		null,	$this->acesef_config->append_non_sef);
		$lists['log_404_errors'] 			= JHTMLSelect::booleanlist('log_404_errors',		null,	$this->acesef_config->log_404_errors);
		// Meta Tags
		$lists['meta_autotitle'] 			= JHTMLSelect::booleanlist('meta_autotitle',		null,	$this->acesef_config->meta_autotitle);
		$lists['meta_autodesc'] 			= JHTMLSelect::booleanlist('meta_autodesc',			null,	$this->acesef_config->meta_autodesc);
		$lists['meta_autokey'] 				= JHTMLSelect::booleanlist('meta_autokey',			null,	$this->acesef_config->meta_autokey);
		// SEO
		$lists['seo_h1'] 					= JHTMLSelect::booleanlist('seo_h1',				null,	$this->acesef_config->seo_h1);
		$lists['seo_nofollow'] 				= JHTMLSelect::booleanlist('seo_nofollow',			null,	$this->acesef_config->seo_nofollow);
		$lists['seo_il'] 					= JHTMLSelect::booleanlist('seo_il',				null,	$this->acesef_config->seo_il);
		$lists['seo_il_nofollow'] 			= JHTMLSelect::booleanlist('seo_il_nofollow',		null,	$this->acesef_config->seo_il_nofollow);
		$lists['seo_il_target'] 			= JHTMLSelect::booleanlist('seo_il_target',			null,	$this->acesef_config->seo_il_target);
		
		$url_part = array();
  		$url_part[] = JHTMLSelect::Option('alias', JText::_('ACESEF_CONFIG_MAIN_ALIAS_FIELD'));
		$url_part[] = JHTMLSelect::Option('title', JText::_('ACESEF_CONFIG_MAIN_TITLE_FIELD'));
		
		// Title / Alias
		$lists['title_alias'] 		= JHTMLSelect::genericlist($url_part, 'title_alias', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->title_alias);
		
		// Menu URL part
		$lists['menu_url_part'] 	= JHTMLSelect::genericlist($url_part, 'menu_url_part', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->menu_url_part);
			
		// JoomFish languages list
		$joomfish_main_lang = array();
		$joomfish_main_lang[] = JHTMLSelect::Option('0', JText::_('ACESEF_CONFIG_JOOMFISH_MAINLANG_NONE'));
		
		// Check if languages table exists
		$tables	= $db->getTableList();
		$prefix	= $db->getPrefix();
		$langs	= $prefix."languages";
		if (in_array($langs, $tables)){
			// Get installed languages and add them to list
			$db->setQuery("SELECT `id`, `shortcode`, `name` FROM `#__languages` WHERE `active` = '1' ORDER BY `ordering`");
			$langs = $db->loadObjectList();
			if( @count(@$langs) ) {	
				foreach($langs as $lang) {
					$l = new stdClass();
					$l->code = $lang->shortcode;
					$l->name = $lang->name;
					
					// Load languages
					$joomfish_main_lang[] = JHTMLSelect::Option($l->code, $l->name);
				}
			}
		}
		$lists['joomfish_main_lang'] = JHTMLSelect::genericlist($joomfish_main_lang, 'joomfish_main_lang', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->joomfish_main_lang);
		
		// 404 Page	
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT `id`, `introtext` FROM `#__content` WHERE `title` = '404'");
        $row = $db->loadObject();
		$lists['notfound'] = isset($row->introtext) ? $row->introtext : JText::_('<h1>404: Not Found</h1><h4>Sorry, but the content you requested could not be found</h4>');
		
		// base href
		$base_href = array();
  		$base_href[] = JHTMLSelect::Option('1', JText::_('ACESEF_CONFIG_ADVANCED_BASEHREF_ORG'));
		$base_href[] = JHTMLSelect::Option('2', JText::_('ACESEF_CONFIG_ADVANCED_BASEHREF_URL'));
		$base_href[] = JHTMLSelect::Option('3', JText::_('ACESEF_CONFIG_ADVANCED_BASEHREF_HOME'));
		$lists['base_href'] = JHTMLSelect::genericlist($base_href, 'base_href', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->base_href);
		
		// Check if the 404_logfile is empty
		if ( $this->acesef_config->log_404_path == "") {
			$this->acesef_config->log_404_path = JPATH_ROOT.DS.'logs'.DS.'acesef_404.log';
		}
		
		$this->assignRef('lists', $lists);
		parent::display($tpl) ;
	}
}
?>