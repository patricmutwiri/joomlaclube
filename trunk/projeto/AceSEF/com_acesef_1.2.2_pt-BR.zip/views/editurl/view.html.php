<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport('joomla.application.component.view');

// Edit URL View Class
class AcesefViewEditurl extends JView {

	// Edit URL
	function edit ($tpl = null) {
	
		// Get data from model
		$record	= & $this->get('Data');
		
		// Import CSS
		$document =& JFactory::getDocument();
		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set toolbar
		JToolBarHelper::title(JText::_('ACESEF_URL_EDIT_TITLE').' '.$record->url_sef, 'acesef');
		JToolBarHelper::custom('save', 'save1.png', 'save1.png', JTEXT::_('Save'), false);
		JToolBarHelper::custom('apply', 'approve.png', 'approve.png', JTEXT::_('Apply'), false);
		JToolBarHelper::custom('cancel', 'cancel1.png', 'cancel1.png', JTEXT::_('Cancel'), false);

		// Import library
		smart_import('joomla.html.html.select');
		
		// Options array
		$select = array();
		$select[] = JHTMLSelect::Option('0', JTEXT::_('No'));
		$select[] = JHTMLSelect::Option('1', JTEXT::_('Yes'));
		
		// Published list
   	   	$lists['published'] = JHTMLSelect::genericlist($select, 'published', 'class="inputbox" size="1 "','value', 'text', $record->published);
		
		// Locked list
   	   	$lists['locked'] = JHTMLSelect::genericlist($select, 'locked', 'class="inputbox" size="1 "','value', 'text', $record->locked);
		
		// Assign values
		$this->assignRef('row', $record);
		$this->assignRef('lists', $lists);

		parent::display($tpl);
	}
}
?>