<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');
?>
<form action="index.php" method="post" name="adminForm">

<?php
include("changelog.inc.html");
?>

<input type="hidden" name="option" value="com_acesef" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="" />
</form>