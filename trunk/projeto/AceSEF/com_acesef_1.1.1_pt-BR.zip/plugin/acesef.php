<?php
/**
* @version		1.0.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class  plgSystemAcesef extends JPlugin {

	function plgSystemAcesef(& $subject, $config) {
		parent::__construct($subject, $config);
		
		// Load plugin parameters
        $this->_plugin = & JPluginHelper::getPlugin('system', 'acesef');
        $this->_params = new JParameter($this->_plugin->params);
	}

	// Assign the new router for the SEF URL rewritting
	function onAfterInitialise() {
		global $mainframe;
		
		// Administration area
        if ($mainframe->isAdmin()) return true;

        // Joomla SEF is disabled
        $config =& JFactory::getConfig();
        if (!$config->getValue('sef')) return true;

		// Check if AceSEF is enabled
		require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
		$acesef_config =  new acesef_configuration();
		if ($acesef_config->mode == 1) {
			$router =& $mainframe->getRouter();
			require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'mainrouter.php');
			$router = new acesefRouter();
		}
	}
	
	function onAfterRoute() {
        global $mainframe;

        // Administration area
        if ($mainframe->isAdmin()) return true;

        // Joomla SEF is disabled
        $config =& JFactory::getConfig();
        if (!$config->getValue('sef')) return true;

        // Check if AceSEF is enabled
        require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
		$acesef_config = new acesef_configuration();
        if ($acesef_config->mode == 0) return true;

        return true;
    }

    function onAfterDispatch() {
        global $mainframe;
		
		$document =& JFactory::getDocument();
		$config = &JFactory::getConfig();

        // Administration area
        if ($mainframe->isAdmin()) return true;
		
		// Joomla SEF is disabled
        $config =& JFactory::getConfig();
        if (!$config->getValue('sef')) return true;

        // Check if AceSEF is enabled
        require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
		$acesef_config = new acesef_configuration();
        if ($acesef_config->mode == 0) return true;
		
        if (!class_exists('AceSEFTools') || !AceSEFTools::on($this)) return true;
		
		// Get Router
		$router =& $mainframe->getRouter();
		
		// Set Meta Tags
		if (!empty($router->metatags)) {
			$meta = $router->metatags;
		
			$metatitle		= $meta['metatitle'];
			$metadesc   	= $meta['metadesc'];
			$metakey		= $meta['metakey'];
			$metalang   	= $meta['metalang'];
			$metarobots 	= $meta['metarobots'];
			$metagoogle 	= $meta['metagoogle'];
			$metacanonical	= $meta['metacanonical'];
			
			$pageTitle = $document->getTitle();
			if (!empty($metatitle))
				$pageTitle = $metatitle;
				
			if (!empty($pageTitle))			$document->setTitle($pageTitle);
			if (!empty($pageTitle))			$document->setMetaData('title', $pageTitle);
			if (!empty($metadesc))			$document->setDescription($metadesc);
			if (!empty($metakey))			$document->setMetaData('keywords', $metakey);
			if (!empty($metarobots))		$document->setMetaData('robots', $metarobots);
			if (!empty($metalang))			$document->setMetaData('language', $metalang);
			if (!empty($metagoogle))		$document->setMetaData('googlebot', $metagoogle);
			if (!empty($metacanonical)) 	$document->addHeadLink($metacanonical, 'canonical');
			
		}
		
		// Set Generator
		$generator = $router->generator;
		if (!empty($generator)) 	$document->setGenerator($generator);
		
        return true;
    }
}
?>