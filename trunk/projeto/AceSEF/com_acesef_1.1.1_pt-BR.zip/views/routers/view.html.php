<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport( 'joomla.application.component.view');

// Router View Class
class AcesefViewRouters extends JView {

	// Display Routers
	function view($tpl = null) {
		// Import CSS
		$document =& JFactory::getDocument();
		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');

		// Toolbar Buttons
		JToolBarHelper::title(JText::_('ACESEF_ROUTER_TITLE'), 'acesef');
		$bar =& JToolBar::getInstance();
		JToolBarHelper::custom('save', 'save1.png', 'save1.png', JText::_('Save'), false);
		JToolBarHelper::custom('savepurge', 'save1.png', 'save1.png', JText::_('ACESEF_CONFIG_SAVE_PURGE'), true);
		JToolBarHelper::divider();
		$bar->appendButton('Confirm', JText::_('ACESEF_ROUTER_WARNING_REBUILD'), 'rebuild', JText::_('ACESEF_ROUTER_REBUILD'), 'rebuild', false, false);
		JToolBarHelper::divider();
		JToolBarHelper::custom('back', 'home.png', 'home.png', JText::_('ACESEF_COMMON_HOME'), false);

		// Get data from the model
		$items = & $this->get('Data');

		foreach ($items as $item) {
			// Make a select list
			$selections = array();
			if ($item->router_type == 1) {
				$selections[] = JHTML::_('select.option', 1, JTEXT::_('ACESEF_ROUTER_SELECT_ACESEF'));
				$selections[] = JHTML::_('select.option', 0, JTEXT::_('ACESEF_ROUTER_SELECT_DISABLE'));
			}
			if ($item->router_type == 2) {
				$selections[] = JHTML::_('select.option', 2, JTEXT::_('ACESEF_ROUTER_SELECT_15_ROUTER'));
				$selections[] = JHTML::_('select.option', 1, JTEXT::_('ACESEF_ROUTER_SELECT_ACESEF'));
				$selections[] = JHTML::_('select.option', 0, JTEXT::_('ACESEF_ROUTER_SELECT_DISABLE'));
			}
			if ($item->router_type == 3) {
				$selections[] = JHTML::_('select.option', 3, JTEXT::_('ACESEF_ROUTER_SELECT_EXTENSION'));
				$selections[] = JHTML::_('select.option', 1, JTEXT::_('ACESEF_ROUTER_SELECT_ACESEF'));
				$selections[] = JHTML::_('select.option', 0, JTEXT::_('ACESEF_ROUTER_SELECT_DISABLE'));
			}
			if ($item->router_type == 4) {
				$selections[] = JHTML::_('select.option', 3, JTEXT::_('ACESEF_ROUTER_SELECT_EXTENSION'));
				$selections[] = JHTML::_('select.option', 2, JTEXT::_('ACESEF_ROUTER_SELECT_15_ROUTER'));
				$selections[] = JHTML::_('select.option', 1, JTEXT::_('ACESEF_ROUTER_SELECT_ACESEF'));
				$selections[] = JHTML::_('select.option', 0, JTEXT::_('ACESEF_ROUTER_SELECT_DISABLE'));
			}
			if ($item->router_type == 5) {
				$selections[] = JHTML::_('select.option', 4, JTEXT::_('ACESEF_ROUTER_SELECT_J10_WITH_PREFIX'));
				$selections[] = JHTML::_('select.option', 5, JTEXT::_('ACESEF_ROUTER_SELECT_J10_WITHOUT_PREFIX'));
				$selections[] = JHTML::_('select.option', 1, JTEXT::_('ACESEF_ROUTER_SELECT_ACESEF'));
				$selections[] = JHTML::_('select.option', 0, JTEXT::_('ACESEF_ROUTER_SELECT_DISABLE'));
			}
			
			// Routers options
			$fieldname = 'rewrite_rule['.$item->id.']';
			$item->router_select = JHTML::_('select.genericlist', $selections, $fieldname, 'class="inputbox" size="1"', 'value', 'text', $item->rewrite_rule);
			
			// Skip title option
			$fieldname_skip_title = 'skip_title['.$item->id.']';
			$item->skip_title = $lists['mode'] = JHTMLSelect::booleanlist($fieldname_skip_title, null, $item->skip_title);
			
			// Bypass redirects option
			$fieldname_bypass_post = 'bypass_post_redirect['.$item->id.']';
			$item->bypass_post_redirect = $lists['mode'] = JHTMLSelect::booleanlist($fieldname_bypass_post, null, $item->bypass_post_redirect);

		}
		
		$this->assignRef('items', $items);
		
		parent::display($tpl);
	}
}
?>