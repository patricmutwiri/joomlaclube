<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport('joomla.application.component.view');


// Extensions View Class
class AcesefViewExtensions extends JView {

	// Display extensions
	function view($tpl = null) {
		
		// Import CSS
  		$document =& JFactory::getDocument();
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set Toolbar
		JToolBarHelper::title(JText::_('ACESEF_EXTENSION_DEFAULT_TITLE'), 'acesef');
		JToolBarHelper::custom('edit', 'editurl.png', 'editurl.png', JTEXT::_('Edit'), true);
		JToolBarHelper::custom('delete', 'uninstall.png', 'uninstall.png', JTEXT::_('Uninstall'), true);
		JToolBarHelper::divider();
		JToolBarHelper::custom('purge', 'purgeurls.png', 'purgeurls.png', JText::_('ACESEF_EXTENSION_DEFAULT_PURGE'), true);
		JToolBarHelper::divider();
		JToolBarHelper::custom('back', 'home.png', 'home.png', JText::_('ACESEF_COMMON_HOME'), false);

		global $mainframe, $option;

		$search				= $mainframe->getUserStateFromRequest($option.'search','search','','string');
		$search				= JString::strtolower($search);

		// Get data from the model
		$items		= & $this->get('Data');
		$versions	= & $this->get('Versions');
		$total		= & $this->get('Total');
		$pagination = & $this->get('Pagination');

		// Build list of categories
		$javascript 	= 'onchange="document.adminForm.submit();"';

		// Search filter
		$lists['search']= $search;

		$this->assignRef('lists',		$lists);
		$this->assignRef('items',		$items);
		$this->assignRef('versions',	$versions);
		$this->assignRef('pagination',	$pagination);

		parent::display($tpl);
	}
}
?>