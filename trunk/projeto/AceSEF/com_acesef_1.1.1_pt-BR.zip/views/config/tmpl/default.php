<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	Copyright (C) 2009 www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined( '_JEXEC' ) or die( 'Restricted access' );

// Import JPane
jimport( 'joomla.html.pane');
$pane =& JPane::getInstance('Tabs');

?>

<form action="index.php" method="post" name="adminForm">
	<script language="Javascript">
		function submitbutton(pressbutton) {
			<?php
			jimport( 'joomla.html.editor' );
			$editor =& JFactory::getEditor();
			echo $editor->save('introtext');
			?>
			submitform(pressbutton);
		}
	</script>
	<?php
	echo $pane->startPane('pane');
	echo $pane->startPanel(JText::_('ACESEF_CONFIG_TABS_MAIN'), 'main');
	?>
		<table class="noshow">
			<tr>
				<td width="50%">
					<table width="100%" class="noshow">
						<tr>
							<td width="100%">
								<fieldset class="adminform">
								<legend><?php echo JText::_('ACESEF_CONFIG_LEGEND_MAIN'); ?></legend>
								<table class="admintable">
									<tbody>
										<tr>
											<td width="185" class="key">
												<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ENABLE'); ?>::<?php echo JText::_('ACESEF_CONFIG_ENABLE_HELP'); ?>">
													<?php echo JText::_('ACESEF_CONFIG_ENABLE'); ?>
												</span>
											</td>
											<td>
												<?php echo $this->lists['mode']; ?>
											</td>
										</tr>
										<tr>
											<td width="185" class="key">
												<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_LOWERCASE'); ?>::<?php echo JText::_('ACESEF_CONFIG_LOWERCASE_HELP'); ?>">
													<?php echo JText::_('ACESEF_CONFIG_LOWERCASE'); ?>
												</span>
											</td>
											<td>
												<?php echo $this->lists['url_lowercase']; ?>
											</td>
										</tr>
										<tr>
											<td width="185" class="key">
												<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_DUPLICATE_URL'); ?>::<?php echo JText::_('ACESEF_CONFIG_DUPLICATE_URL_HELP'); ?>">
													<?php echo JText::_('ACESEF_CONFIG_DUPLICATE_URL'); ?>
												</span>
											</td>
											<td>
												<?php echo $this->lists['duplicate_url']; ?>
											</td>
										</tr>
										<tr>
											<td width="185" class="key">
												<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_SUFFIX'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_SUFFIX_HELP'); ?>">
													<?php echo JText::_('ACESEF_CONFIG_SUFFIX'); ?>
												</span>
											</td>
											<td>
												<input type="text" name="url_suffix" id="url_suffix" class="inputbox" size="10" value="<?php echo $this->acesef_config->url_suffix; ?>" />
											</td>
										</tr>
										<tr>
											<td width="185" class="key">
												<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_REPLACEMENT_CHAR'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_REPLACEMENT_CHAR_HELP'); ?>">
													<?php echo JText::_('ACESEF_CONFIG_REPLACEMENT_CHAR'); ?>
												</span>
											</td>
											<td>
												<input type="text" name="replacement_character" id="replacement_character" class="inputbox" size="10" value="<?php echo $this->acesef_config->replacement_character; ?>" />
											</td>
										</tr>
										<tr>
											<td width="185" class="key">
												<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_PART_MENU'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_PART_MENU_HELP'); ?>">
													<?php echo JText::_( 'ACESEF_CONFIG_PART_MENU' ); ?>
												</span>
											</td>
											<td>
												<?php echo $this->lists['menu_url_part']; ?>
											</td>
										</tr>
										<tr>
											<td width="185" class="key">
												<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_GENERATOR'); ?>::<?php echo JText::_('ACESEF_CONFIG_GENERATOR_HELP'); ?>">
													<?php echo JText::_('ACESEF_CONFIG_GENERATOR'); ?>
												</span>
											</td>
											<td>
												<input type="text" name="generator" id="generator" class="inputbox" size="40" value="<?php echo $this->acesef_config->generator; ?>" />
											</td>
										</tr>
									</tbody>
								</table>
								</fieldset>
							</td>
						</tr>
						<tr>
							<td width="100%">
								<fieldset class="adminform">
									<legend><?php echo JText::_('ACESEF_CONFIG_LEGEND_JOOMFISH'); ?></legend>
									<table class="admintable">
										<tbody>
											<tr>
												<td width="185" class="key">
													<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_MAINLANG'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_JOOMFISH_MAINLANG_HELP'); ?>">
														<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_MAINLANG'); ?>
													</span>
												</td>
												<td>
													<?php echo $this->lists['joomfish_main_lang']; ?>
												</td>
											</tr>
											<tr>
												<td width="185" class="key">
													<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_CODE'); ?>::<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_CODE_HELP'); ?>">
														<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_CODE'); ?>
													</span>
												</td>
												<td>
													<?php echo $this->lists['joomfish_lang_code']; ?>
												</td>
											</tr>
											<tr>
												<td width="185" class="key">
													<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_TRANSLATE'); ?>::<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_TRANSLATE_HELP'); ?>">
														<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_TRANSLATE'); ?>
													</span>
												</td>
												<td>
													<?php echo $this->lists['joomfish_trans_url']; ?>
												</td>
											</tr>
										</tbody>
									</table>
								</fieldset>
							</td>
						</tr>
					</table>
				</td>
				<td width="50%">
					<fieldset class="adminform">
						<legend><?php echo JText::_('ACESEF_CONFIG_LEGEND_ADVANCED'); ?></legend>
						<table class="admintable">
							<tbody>
								<tr>
									<td width="185" class="key">
										<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ACTIVE_ITEMID'); ?>::<?php echo JText::_('ACESEF_CONFIG_ACTIVE_ITEMID_HELP'); ?>">
											<?php echo JText::_('ACESEF_CONFIG_ACTIVE_ITEMID'); ?>
										</span>
									</td>
									<td>
										<?php echo $this->lists['insert_active_itemid']; ?>
									</td>
								</tr>
								<tr>
									<td width="185" class="key">
										<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_APPEND_ITEMID'); ?>::<?php echo JText::_('ACESEF_CONFIG_APPEND_ITEMID_HELP'); ?>">
											<?php echo JText::_('ACESEF_CONFIG_APPEND_ITEMID'); ?>
										</span>
									</td>
									<td>
										<?php echo $this->lists['append_itemid']; ?>
									</td>
								</tr>
								<tr>
									<td width="185" class="key">
										<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_QUERY_STRING'); ?>::<?php echo JText::_('ACESEF_CONFIG_QUERY_STRING_HELP'); ?>">
											<?php echo JText::_('ACESEF_CONFIG_QUERY_STRING'); ?>
										</span>
									</td>
									<td>
										<?php echo $this->lists['set_query_string']; ?>
									</td>
								</tr>
								<tr>
									<td width="185" class="key">
										<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_TRAILING_SLASH'); ?>::<?php echo JText::_('ACESEF_CONFIG_TRAILING_SLASH_HELP'); ?>">
											<?php echo JText::_('ACESEF_CONFIG_TRAILING_SLASH'); ?>
										</span>
									</td>
									<td>
										<?php echo $this->lists['remove_trailing_slash']; ?>
									</td>
								</tr>
								<tr>
									<td width="185" class="key">
										<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_STRIP_CHARS'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_STRIP_CHARS_HELP'); ?>">
											<?php echo JText::_('ACESEF_CONFIG_STRIP_CHARS'); ?>
										</span>
									</td>
									<td>
										<input type="text" name="url_strip_chars" id="url_strip_chars" class="inputbox" size="40" value="<?php echo $this->acesef_config->url_strip_chars; ?>" />
									</td>
								</tr>
								<tr>
									<td width="185" class="key">
										<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_CHAR_REPLACE'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_CHAR_REPLACE_HELP'); ?>">
											<?php echo JText::_('ACESEF_CONFIG_CHAR_REPLACE'); ?>
										</span>
									</td>
									<td>
										<textarea name="char_replacements" cols="50" rows="6"><?php echo $this->acesef_config->char_replacements; ?></textarea>
									</td>
								</tr>
								<tr>
									<td width="185" class="key">
										<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_404_LOG'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_404_LOG_HELP'); ?>">
											<?php echo JText::_('ACESEF_CONFIG_404_LOG'); ?>
										</span>
									</td>
									<td>
										<?php echo $this->lists['log_404_errors']; ?>
									</td>
								</tr>
								<tr>
									<td width="185" class="key">
										<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_404_LOG_PATH'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_404_LOG_PATH_HELP'); ?>">
											<?php echo JText::_('ACESEF_CONFIG_404_LOG_PATH'); ?>
										</span>
									</td>
									<td>
										<input type="text" name="log_404_path" id="log_404_path" class="inputbox" size="88" value="<?php echo $this->acesef_config->log_404_path; ?>">
									</td>
								</tr>
							</tbody>
						</table>
					</fieldset>
				</td>
			</tr>
		</table>
	<?php
	echo $pane->endPanel();
	echo $pane->startPanel(JText::_('ACESEF_CONFIG_TABS_404'), '404');
	?>
	<table class="admintable">
		<tbody>
			<tr>
				<td>
					<?php
						jimport( 'joomla.html.editor' );
						$editor =& JFactory::getEditor();
						echo $editor->display('notfound', $this->lists['notfound'], '600', '350', '50', '11');
					?>
				</td>
			</tr>
		</tbody>
	</table>
	<?php
	echo $pane->endPanel();
	echo $pane->endPane();
	?>
	<input type="hidden" name="id" value="" />
	<input type="hidden" name="controller" value="config" />
	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="task" value="edit" />
</form>