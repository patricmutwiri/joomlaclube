<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');
?>

<script language="javascript" type="text/javascript">
<!--
	function submitimport(pressbutton) {
		var form = document.importForm1;

		form.task.value = 'import';
		form.submit();
	}
	
	function submitimportsh404sef(pressbutton) {
		var form = document.importForm2;

		form.task.value = 'importsh404sef';
		form.submit();
	}
	
	function submitimportjoomsef(pressbutton) {
		var form = document.importForm3;

		form.task.value = 'importjoomsef';
		form.submit();
	}
	
	function submitimportsh404sefmeta(pressbutton) {
		var form = document.importForm4;

		form.task.value = 'importsh404sefmeta';
		form.submit();
	}
//-->
</script>
<table class="noshow">
			<tr>
				<td width="50%">
						<form enctype="multipart/form-data" action="index.php" method="post" name="importForm1">
							<fieldset class="adminform">
								<legend><?php echo JText::_('ACESEF_IMPORT_ACESEF'); ?></legend>
								<table class="adminform">
								<tr>
									<td width="120">
										<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
									</td>
									<td>
										<input class="input_box" id="importfile" name="importfile" type="file" size="40" />
										<input class="button" type="button" value="<?php echo JText::_('ACESEF_IMPORT_IMPORT'); ?>" onclick="submitimport()" />
									</td>
								</tr>
								</table>
							</fieldset>

							<input type="hidden" name="option" value="com_acesef" />
							<input type="hidden" name="task" value="view" />
							<input type="hidden" name="controller" value="import" />
						</form>

						<form enctype="multipart/form-data" action="index.php" method="post" name="importForm3">
							<fieldset class="adminform">
								<legend><?php echo JText::_('ACESEF_IMPORT_JOOMSEF'); ?></legend>
								<table class="adminform">
								<tr>
									<td width="120">
										<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
									</td>
									<td>
										<input class="input_box" id="importjoomsef" name="importjoomsef" type="file" size="40" />
										<input class="button" type="button" value="<?php echo JText::_('ACESEF_IMPORT_IMPORT'); ?>" onclick="submitimportjoomsef()" />
									</td>
								</tr>
								</table>
							</fieldset>

							<input type="hidden" name="option" value="com_acesef" />
							<input type="hidden" name="task" value="view" />
							<input type="hidden" name="controller" value="import" />
						</form>
					</td>
					<td width="50%">
						<form enctype="multipart/form-data" action="index.php" method="post" name="importForm2">
							<fieldset class="adminform">
								<legend><?php echo JText::_('ACESEF_IMPORT_SH404SEF'); ?></legend>
								<table class="adminform">
								<tr>
									<td width="120">
										<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
									</td>
									<td>
										<input class="input_box" id="importsh404sef" name="importsh404sef" type="file" size="40" />
										<input class="button" type="button" value="<?php echo JText::_('ACESEF_IMPORT_IMPORT'); ?>" onclick="submitimportsh404sef()" />
									</td>
								</tr>
								</table>
							</fieldset>

							<input type="hidden" name="option" value="com_acesef" />
							<input type="hidden" name="task" value="view" />
							<input type="hidden" name="controller" value="import" />
						</form>

						<form enctype="multipart/form-data" action="index.php" method="post" name="importForm4">
							<fieldset class="adminform">
								<legend><?php echo JText::_('ACESEF_IMPORT_SH404SEF_META'); ?></legend>
								<table class="adminform">
								<tr>
									<td width="120">
										<label for="install_package"><?php echo JText::_('ACESEF_COMMON_SELECT_FILE'); ?>:</label>
									</td>
									<td>
										<input class="input_box" id="importsh404sefmeta" name="importsh404sefmeta" type="file" size="40" />
										<input class="button" type="button" value="<?php echo JText::_('ACESEF_IMPORT_SH404SEF_META_GO'); ?>" onclick="submitimportsh404sefmeta()" />
									</td>
								</tr>
								</table>
							</fieldset>

							<input type="hidden" name="option" value="com_acesef" />
							<input type="hidden" name="task" value="view" />
							<input type="hidden" name="controller" value="import" />
						</form>
						<table>
						<tr>
							<td>
								&nbsp;&nbsp;<a href="http://www.joomace.net/faq/acesef/how-to-export-meta-data-from-sh404sef" ><?php echo JText::_('ACESEF_IMPORT_SH404SEF_HOWTO_META'); ?></a>
							</td>
						</tr>
						<tr>
							<td>
								&nbsp;
							</td>
						</tr>
						<tr>
							<td>
								&nbsp;
							</td>
						</tr>
						</table>
					</td>
				</tr>
			</table>