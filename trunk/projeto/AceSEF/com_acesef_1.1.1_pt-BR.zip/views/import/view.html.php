<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport( 'joomla.application.component.view');

// Import View Class
class AcesefViewImport extends JView {

	// Display import
	function display($tpl = null) {
		$document =& JFactory::getDocument();
		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Toolbar Buttons
		JToolBarHelper::title(JText::_('ACESEF_IMPORT_TITLE'), 'acesef');
		JToolBarHelper::custom('back', 'home.png', 'home.png', JText::_('ACESEF_COMMON_HOME'), false);
		
		parent::display($tpl);
	}
}