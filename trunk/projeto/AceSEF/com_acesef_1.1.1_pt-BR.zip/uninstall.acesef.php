<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('JPATH_BASE') or die('Restricted Access');

function com_uninstall() {
	global $mainframe;
	$file_destination_php = JPATH_PLUGINS.DS.'system'.DS.'acesef.php';
	$file_destination_xml = JPATH_PLUGINS.DS.'system'.DS.'acesef.xml';
	@unlink($file_destination_php);
	@unlink($file_destination_xml);
	//$mainframe->setRedirect('index.php?option=com_installer','AceSEF has been successfully uninstalled');
	return true;
}
?>