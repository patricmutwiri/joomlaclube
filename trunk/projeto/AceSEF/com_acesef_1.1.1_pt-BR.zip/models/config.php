<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport('joomla.application.component.model');

// Configuration Model Class
class AcesefModelConfig extends Jmodel {
	var $_configuration = null;
	
	// Main constructer
	function __construct(){
		parent::__construct();
	}

	function _set_configuration () {
		require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
		$this->_configuration = new acesef_configuration();
	}

	// Save configuration
	function _save_configuration() {
		$config = new JRegistry('config');
		$config_array = array();

		$config_array['mode']							= JRequest::getVar('mode', 							0, 			'post', 'int');
		$config_array['url_lowercase']					= JRequest::getVar('url_lowercase', 				0, 			'post', 'int');
		$config_array['duplicate_url']					= JRequest::getVar('duplicate_url', 				0, 			'post', 'int');
		$config_array['url_suffix']						= JRequest::getVar('url_suffix', 					'', 		'post', 'string');
		$config_array['url_strip_chars']				= JRequest::getVar('url_strip_chars',				'', 		'post', 'string');
		$config_array['replacement_character']			= JRequest::getVar('replacement_character',			'', 		'post', 'string');
		$config_array['menu_url_part']					= JRequest::getVar('menu_url_part',					'title', 	'post', 'string');
		$config_array['char_replacements']				= JRequest::getVar('char_replacements',				'', 		'post', 'string');
		$config_array['log_404_errors']					= JRequest::getVar('log_404_errors', 				0, 			'post', 'int');
		$config_array['log_404_path']					= JRequest::getVar('log_404_path', 					'', 		'post', 'string');
		$config_array['joomfish_main_lang']				= JRequest::getVar('joomfish_main_lang', 			0, 			'post', 'string');
		$config_array['joomfish_lang_code']				= JRequest::getVar('joomfish_lang_code', 			0, 			'post', 'int');
		$config_array['joomfish_trans_url']				= JRequest::getVar('joomfish_trans_url', 			0, 			'post', 'int');
		$config_array['remove_trailing_slash']			= JRequest::getVar('remove_trailing_slash', 		1, 			'post', 'int');
		$config_array['insert_active_itemid']			= JRequest::getVar('insert_active_itemid', 			0, 			'post', 'int');
		$config_array['append_itemid']					= JRequest::getVar('append_itemid', 				0, 			'post', 'int');
		$config_array['set_query_string']				= JRequest::getVar('set_query_string', 				0, 			'post', 'int');
		$config_array['generator']						= JRequest::getVar('generator', 					'', 		'post', 'string');
		
		$config->loadArray($config_array);
		
		// Save 404 Page
		$db =& JFactory::getDBO();
		$db->setQuery('SELECT id FROM #__content WHERE `title` = "404"');
        $notfound = (get_magic_quotes_gpc() ? $_POST['notfound'] : addslashes($_POST['notfound']));
        if ($id = $db->loadResult()){
            $sql = 'UPDATE #__content SET introtext="'.$notfound.'",  modified ="'.date("Y-m-d H:i:s").'" WHERE `id` = "'.$id.'";';
        }
        else {
            $sql='SELECT MAX(id) FROM #__content';
            $db->setQuery($sql);
            if ($max = $db->loadResult()) {
                $max++;
                $sql = 'INSERT INTO #__content (id, title, alias, introtext, `fulltext`, state, sectionid, mask, catid, created, created_by, created_by_alias, modified, modified_by, checked_out, checked_out_time, publish_up, publish_down, images, urls, attribs, version, parentid, ordering, metakey, metadesc, access, hits) '.
                'VALUES( "'.$max.'", "404", "404", "'.$notfound.'", "", "1", "0", "0", "0", "2004-11-11 12:44:38", "62", "", "'.date("Y-m-d H:i:s").'", "0", "62", "2004-11-11 12:45:09", "2004-10-17 00:00:00", "0000-00-00 00:00:00", "", "", "menu_image=-1\nitem_title=0\npageclass_sfx=\nback_button=\nrating=0\nauthor=0\ncreatedate=0\nmodifydate=0\npdf=0\nprint=0\nemail=0", "1", "0", "0", "", "", "0", "750");';
            }
        }
		$db->setQuery($sql);
		$db->query();
		
		// Set the configuration filename
		$filename = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php';

		if (JPath::isOwner($filename) && !JPath::setPermissions($filename, '0644')) {
			JError::raiseNotice('2002', 'Could not make the '.$filename.' writable');
		}

		jimport('joomla.filesystem.file');
		if (JFile::write($filename, $config->toString('PHP', 'config', array('class' => 'acesef_configuration')))) {
			return true;
		} else {
			return false;
		}
	}
}
?>