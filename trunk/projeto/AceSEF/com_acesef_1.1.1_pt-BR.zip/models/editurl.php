<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport( 'joomla.application.component.model' );

// Edit URL Model Class
class AcesefModelEditurl extends JModel {
	
	var $_id = NULL;
	var $_data = NULL;
	
	// Main constructer
	function __construct() {
		parent::__construct();
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		
		$this->_id = $cid[0];
	}
	
	// Get data about the URL
	function getData() {
		// Load the record
		$db =& JFactory::getDBO();
		
		if (is_numeric($this->_id)){
			$this->_data =& JTable::getInstance('acesef_urls', 'Table'); 
			$this->_data->load ($this->_id);
		} else {
			$db->setQuery("SELECT * FROM #__acesef_urls WHERE url_sef = '".$this->_id."' ORDER BY used, id");
			$this->_data = $db->loadObject();
		}
	
		return $this->_data;
	}
	
	// Save URL changes
	function save($id = 0) {
		$db =& JFactory::getDBO();
		$record =& JTable::getInstance('acesef_urls', 'Table'); 
		$post = JRequest::get('post');
		
		// Bind the data from the POST;
		if (!$record->bind($post)) {
			return JError::raiseWarning(500, $record->getError());
		}

		if (!$record->store()) {
			return JError::raiseWarning(500, $record->getError());
		}
		return true;
	}
	
	// Apply URL changes
	function apply($id = 0) {
		$db =& JFactory::getDBO();
		$record =& JTable::getInstance('acesef_urls', 'Table'); 
		$post = JRequest::get('post');
		
		// Bind the data from the POST;
		if (!$record->bind($post)) {
			return JError::raiseWarning(500, $record->getError());
		}

		if (!$record->store()) {
			return JError::raiseWarning(500, $record->getError());
		}
		return true;
	}
}
?>