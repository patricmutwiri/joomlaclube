<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport('joomla.application.component.model');

// Extensions Model Class
class AcesefModelExtensions extends JModel {

	var $_data 			= null;
	var $_total 		= null;
	var $_pagination 	= null;
	var $_xml			= null;
	
	// Main constructer
	function __construct()	{
		parent::__construct();

		global $mainframe, $option;

		// Get the pagination request variables
		$limit		= $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart	= $mainframe->getUserStateFromRequest($option.'limitstart', 'limitstart', 0, 'int');

		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
	}
	
	// Uninstall extensions
	function delete($id) {
		$acesef_record =& JTable::getInstance('acesef_extensions', 'Table');
		if (!$acesef_record->load($id)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		return $acesef_record->delete($id, $acesef_record->extension);
	}
	
	// Purge URLs of this extension
	function purge($id) {
		// Get component name
		$db =& JFactory::getDBO();
        $db->setQuery("SELECT extension FROM #__acesef_extensions WHERE id =".$id);
        $component = $db->loadResult();
		
		// Purge URLs for this component
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purgeComponent($component);
	}
	
	// Save changes
	function save($id) {
		$acesef_record =& JTable::getInstance('acesef_extensions', 'Table');
		$post = JRequest::get('post');
		if (!$acesef_record->load($id)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		if (!$acesef_record->bind($post)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		return $acesef_record->store();
	}
	
	// Apply changes
	function apply($id) {
		$acesef_record =& JTable::getInstance('acesef_extensions', 'Table');
		$post = JRequest::get('post');
		if (!$acesef_record->load($id)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		if (!$acesef_record->bind($post)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		return $acesef_record->store();
	}
	
	// Apply changes and Purge URLs of this extension
	function applypurge($id) {
		// Get component name
		$db =& JFactory::getDBO();
        $db->setQuery("SELECT extension FROM #__acesef_extensions WHERE id =".$id);
        $component = $db->loadResult();
		
		// Purge URLs for this component
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purgeComponent($component);
		
		// Save changes
		$acesef_record =& JTable::getInstance('acesef_extensions', 'Table');
		$post = JRequest::get('post');
		if (!$acesef_record->load($id)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		if (!$acesef_record->bind($post)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		return $acesef_record->store();
	}
	
	// Save changes and Purge URLs
	function savepurge($id) {
		// Get component name
		$db =& JFactory::getDBO();
        $db->setQuery("SELECT extension FROM #__acesef_extensions WHERE id =".$id);
        $component = $db->loadResult();
		
		// Purge URLs for this component
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purgeComponent($component);
		
		// Save changes
		$acesef_record =& JTable::getInstance('acesef_extensions', 'Table');
		$post = JRequest::get('post');
		if (!$acesef_record->load($id)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		if (!$acesef_record->bind($post)) {
			return JError::raiseWarning(500, $acesef_record->getError());
		}
		return $acesef_record->store();
	}	
	
	// Edit extension
	function &getEditdata() {
		JRequest::setVar('hidemainmenu', 1);
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$this->_id = $cid[0];

		$extension_record =& JTable::getInstance('acesef_extensions', 'Table');

		$extension_record->load($this->_id);
		$extension_record->params =  $this->getParams($extension_record->params, $extension_record->extension);
		// Read the parametes;

		return ($extension_record);
	}
	
	// Get Params
	function &getParams($params, $extension_name)	{
		$params	= new JParameter($params);

		if ($xml =& $this->_getXML($extension_name)) {
			if ($ps = & $xml->document->params) {
				foreach ($ps as $p)	{
					$params->setXML($p);
				}
			}
		}
		return $params;
	}

	// Get XML
	function &_getXML($extension_name) {
		if (!$this->_xml) {
			$xmlfile = JPATH_SITE.DS."administrator".DS."components".DS."com_acesef".DS."extensions".DS.$extension_name.'.xml';

			if (file_exists($xmlfile)) {
				$xml =& JFactory::getXMLParser('Simple');
				if ($xml->loadFile($xmlfile)) {
					$this->_xml = &$xml;
				}
			}
		}
		return $this->_xml;
	}
	
	// Get data about extensions
	function &getData() {
		if (empty($this->_data)){
			$query = $this->_buildViewQuery();
			$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
		}
		return $this->_data;
	}
	
	// Get total extensions
	function &getTotal() {
		if (empty($this->_total)){
			$query = $this->_buildViewQuery();
			$this->_total = $this->_getListCount($query);
		}
		return $this->_total;
	}
	
	// Get pagination
	function &getPagination(){
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit'));
		}
		return $this->_pagination;
	}
	
	// Get extensions versions
	function &getVersions() {
		if(!isset($extVersions)){
			$path = 'http://www.joomace.net/acesef_versions.txt';
			$versions = @file_get_contents($path);
			if (!$versions) {
				$versions = '?.?.?';
			}

			$versions = explode("\n", trim($versions));

			$extVersions = array();
			if (count($versions) > 0) {
				foreach($versions as $version) {
					list($ext, $ver) = explode(' ', $version);
					$extVersions[$ext] = trim($ver);
				}
			}
		}
		return $extVersions;
    }
	
	// Finally build query
	function _buildViewQuery() {
		$where = $this->_buildViewWhere();
		$query = 'SELECT * FROM #__acesef_extensions '.$where.' ORDER BY name';
		return $query;
	}
	
	// Filters function
	function _buildViewWhere() {
		global $mainframe, $option;

		$search	= $mainframe->getUserStateFromRequest($option.'search',	'search', '', 'string');
		$search	= JString::strtolower($search);

		$where = array();
		if ($search) {
			$where[] = 'LOWER(name) LIKE '.$this->_db->Quote('%'.$search.'%');
		}
		
		$where = (count($where) ? ' WHERE '. implode(' AND ', $where) : '');
		return $where;
	}
}
?>