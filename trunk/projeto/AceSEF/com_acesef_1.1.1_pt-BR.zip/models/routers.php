<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport('joomla.application.component.model');

// Routers Model Class
class AcesefModelRouters extends JModel {

	var $_data = null;
	var $_buffer_acesef_extensions = NULL;
	
	// Purge routers
	function purge() {
		$query = 'TRUNCATE TABLE #__acesef_routers';
		$this->_db->setQuery($query);
		$this->_db->query();
		
		// Cleanup the repository
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purge();
	}
	
	// Save changes
	function save() {
		$component_prefix 		= JRequest::getVar('component_prefix');
		$rewrite_rule 			= JRequest::getVar('rewrite_rule');
		$skip_title 			= JRequest::getVar('skip_title');
		$bypass_post_redirect 	= JRequest::getVar('bypass_post_redirect');

		foreach ($component_prefix as $prefix => $value) {
			$query = "UPDATE #__acesef_routers SET component_prefix='".trim($value)."', rewrite_rule='".$rewrite_rule[$prefix]."', skip_title='".$skip_title[$prefix]."', bypass_post_redirect='".$bypass_post_redirect[$prefix]."' WHERE id=".$prefix;
			$this->_db->setQuery($query);
			$this->_db->query();
		}
	}
	
	// Save changes
	function savepurge($id) {
		$component_prefix 		= JRequest::getVar('component_prefix');
		$rewrite_rule 			= JRequest::getVar('rewrite_rule');
		$skip_title 			= JRequest::getVar('skip_title');
		$bypass_post_redirect 	= JRequest::getVar('bypass_post_redirect');

		foreach ($component_prefix as $prefix => $value) {
			$query = "UPDATE #__acesef_routers SET component_prefix='".trim($value)."', rewrite_rule='".$rewrite_rule[$prefix]."', skip_title='".$skip_title[$prefix]."', bypass_post_redirect='".$bypass_post_redirect[$prefix]."' WHERE id=".$prefix;
			$this->_db->setQuery($query);
			$this->_db->query();
		}
		
		// Get component name
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT component FROM #__acesef_routers WHERE id =".$id);
		$component = $db->loadResult();
		
		// Purge URLs for this component
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purgeComponent($component);
	}
	
	// Routers state
	function check_state_routers() {
		$filter = "'com_jce', 'com_sef', 'com_sh404sef', 'com_acesef', 'com_config', 'com_media', 'com_installer', 'com_templates', 'com_plugins', 'com_modules', 'com_cpanel', 'com_cache', 'com_messages', 'com_menus', 'com_massmail', 'com_languages', 'com_users'";
		$query = 'SELECT `option`, `id` FROM `#__components` WHERE `parent` = "0" AND `option` != "" AND `option` NOT IN ('.$filter.')';
		$this->_db->setQuery($query);
		$components = $this->_db->loadObjectList();

		foreach ($components as $component) {
			// Check if there is already a record available
			$query = "SELECT COUNT(*) FROM #__acesef_routers WHERE component = '".$component->option."'";
			$this->_db->setQuery($query);
			$total = $this->_db->loadResult();
			if ($total < 1) {
				$routed = false;
				
				// Check if there is a extension
				if (!$routed){
					$ext = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.$component->option.'.php';
					if (file_exists($ext)) {
						$option = $component->option;
						$query = "SELECT extension FROM #__acesef_extensions WHERE extension = '$option'";
						$this->_db->setQuery($query);
						$this->_buffer_acesef_extensions = $this->_db->loadObject('extension');
						if (isset($this->_buffer_acesef_extensions)) {
							// Check if there is a Router file
							$router = JPATH_SITE.DS.'components'.DS.$component->option.DS.'router.php';
							if (file_exists($router))
								$router_type = 4;
							else
								$router_type = 3;
							$rewrite_rule = 3;
							$routed = true;
						}
					} 
				}
				// Check if there is a Router file
				if (!$routed){
					$router = JPATH_SITE.DS.'components'.DS.$component->option.DS.'router.php';
					if (file_exists($router)) {
						$router_type = 2;
						$rewrite_rule = 2;
						$routed = true;
					}
				}
				// Check if there is an old extension
				if (!$routed){
					$path = JPATH_SITE.DS.'components'.DS.$component->option.DS.'sef_ext.php';
					if (file_exists($path)) {
						$router_type = 5;
						$rewrite_rule = 5;
						$routed = true;
					}
				}
				// Check if there is an old extension
				if (!$routed){
					$router_type = 1;
					$rewrite_rule = 1;
					$routed = true;
				}
				if($routed){
					$query = "INSERT INTO #__acesef_routers ( router_type, rewrite_rule, component_prefix, component, skip_title, bypass_post_redirect ) VALUES ( '".$router_type ."', '".$rewrite_rule."', '', '".$component->option."', '0', '0')";
					$this->_db->setQuery($query);
					$this->_db->query();
				}
			}
		}
	}
	
	// Get data about routers
	function getData() {
		if (empty($this->_data)){
			$query = "SELECT * FROM #__acesef_routers ORDER BY component";
			$this->_data = $this->_getList($query);
		}
		return $this->_data;
	}
}
?>