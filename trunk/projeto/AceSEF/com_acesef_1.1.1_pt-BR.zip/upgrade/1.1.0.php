<?php
/**
* @version		1.0.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// XML
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'acesef.xml', 'upgrade', DS.'acesef.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'configuration.php', 'upgrade', DS.'configuration.php');

// Classes
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php', 'upgrade', DS.'classes'.DS.'aceseftools.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'mainrouter.php', 'upgrade', DS.'classes'.DS.'mainrouter.php');

// Controllers
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'extensions.php', 'upgrade', DS.'controllers'.DS.'extensions.php');

// Models
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'config.php', 'upgrade', DS.'models'.DS.'config.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'repository.php', 'upgrade', DS.'models'.DS.'repository.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'routers.php', 'upgrade', DS.'models'.DS.'routers.php');

// Views
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'config'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'repository'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'repository'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'repository'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'repository'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'routers'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'routers'.DS.'view.html.php');

// Tables
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_extensions.php', 'upgrade', DS.'tables'.DS.'acesef_extensions.php');

// Lang
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.com_acesef.ini', 'upgrade', DS.'languages'.DS.'en-GB'.DS.'en-GB.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini');

// DB changes
$this->_addSQL("UPDATE #__acesef_routers SET router_type = '5' WHERE router_type = '2'");
$this->_addSQL("UPDATE #__acesef_routers SET router_type = '4' WHERE router_type = '9'");
$this->_addSQL("UPDATE #__acesef_routers SET router_type = '3' WHERE router_type = '8'");
$this->_addSQL("UPDATE #__acesef_routers SET router_type = '2' WHERE router_type = '1'");
$this->_addSQL("UPDATE #__acesef_routers SET router_type = '1' WHERE router_type = '0'");
$this->_addSQL("UPDATE #__acesef_routers SET rewrite_rule = '5' WHERE rewrite_rule = '3'");
$this->_addSQL("UPDATE #__acesef_routers SET rewrite_rule = '3' WHERE rewrite_rule = '9'");
$this->_addSQL("UPDATE #__acesef_routers SET rewrite_rule = '2' WHERE rewrite_rule = '1'");
$this->_addSQL("UPDATE #__acesef_routers SET rewrite_rule = '1' WHERE rewrite_rule = '2' AND router_type = '1'");
?>