<?php
/*
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('JPATH_BASE') or die('Restricted Access');

// Import Libraries
jimport('joomla.installer.installer');
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

global $mainframe;

$source = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'plugin'.DS;
$destination = JPATH_ROOT.DS.'plugins'.DS.'system'.DS;

$copied = JFile::copy($source.'acesef.php', $destination.'acesef.php');
$copied = $copied && JFile::copy($source.'acesef.xml', $destination.'acesef.xml');

if ($copied) {
	$mainframe->redirect('index.php?option=com_acesef', 'AceSEF installed succesfully!');
} else {
	$mainframe->redirect('index.php?option=com_acesef', JError::raiseWarning(100, JText::_('AceSEF plugin is not installed. Please upload the files in plugin folder manually')));
}
?>