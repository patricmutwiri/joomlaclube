<?php
/*
* @package		AceSEF
* @subpackage	Content
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_content extends AceSEFTools {
	
	var $params;
	var $title_sec;
	var $title_cat;
	var $title_item;
	var $desc_sec;
	var $desc_cat;
	var $desc_item;
	
	function getSectionTitle($id) {
		$joomfish = $this->sef_config->joomfish_trans_url ? ', id' : '';

		$database =& JFactory::getDBO();
        $database->setQuery("SELECT title, alias, description$joomfish FROM #__sections WHERE id =".$id);
        $rows = $database->loadRow();
        
		$name = (($this->params->get('sectionid_inc', '1') != '1') ? $id.'-' : '');
		if($this->params->get('section_part', 'title') == 'title')
			$name .= $rows[0];
		else
			$name .= $rows[1];
		
		$this->desc_sec = $rows[2];
		$this->title_sec = $rows[0];
		
		return $name;
    }
	
	function getCategoryTitle($id) {
		$joomfish = $this->sef_config->joomfish_trans_url ? ', id' : '';
	
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT title, alias, section, description$joomfish FROM #__categories WHERE id =".$id);
        $rows = $database->loadRow();

		$name = (($this->params->get('categoryid_inc', '1') != '1') ? $id.'-' : '');
		if($this->params->get('category_part', 'title') == 'title')
			$name .= $rows[0];
		else
			$name .= $rows[1];
			
		$this->desc_cat = $rows[3];
		
		if( $this->params->get('section_inc', '2') != '2' ) {
			$this->title_cat = array($rows[0]);
			return array($name);
		} else {
			$this->title_cat = array($this->getSectionTitle($rows[2]), $rows[0]);
			return array($this->getSectionTitle($rows[2]), $name);
		}
    }

    function getArticleTitle($id) {
		$joomfish = $this->sef_config->joomfish_trans_url ? ', id' : '';
			
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT title, alias, catid, introtext$joomfish FROM #__content WHERE id =".$id);
        $rows = $database->loadRow();
		
		$category = array();
		$cat_title = array();
		if($rows[2] != 0) {
			$category	= $this->getCategoryTitle($rows[2]);
			$cat_title	= $this->getCategoryTitle($rows[2]);
		}
			
		$name = (($this->params->get('articleid_inc', '1') != '1') ? $id.'-' : '');
		if($this->params->get('article_part', 'title') == 'title')
			$name .= $rows[0];
		else
			$name .= $rows[1];
			
		$this->desc_item = $rows[3];
		
		if($this->params->get('category_inc', '2') == '2' && $rows[2] != 0){
			array_push($category, $name);
			array_push($cat_title, $rows[0]);
			$this->title_item = $cat_title;
			return $category;
		} else {
			$this->title_item = array($rows[0]);
			return array($name);
		}
    }
	
	// Google New numbering
	function googleNews($title, $id) {
        $num = '';
        $add = $this->params->get('google_news', '1');

        if($add == '2') {
            // Article ID
            $digits = trim($this->params->get('google_news_digits', '3'));
            if(!is_numeric($digits)) {
                $digits = '3';
            }

            $num = sprintf('%0'.$digits.'d', $id);
        }
        else if($add == '3') {
            // Publish date
			$db =& JFactory::getDBO();
            $query = "SELECT `publish_up` FROM `#__content` WHERE `id` = '$id'";
            $db->setQuery($query);
            $time = $db->loadResult();

            $time = strtotime($time);

            $date = $this->params->get('google_news_dateformat', 'ddmm');

            $search = array('dd', 'd', 'mm', 'm', 'yyyy', 'yy');
            $replace = array(date('d', $time), date('j', $time), date('m', $time), date('n', $time), date('Y', $time), date('y', $time));
            $num = str_replace($search, $replace, $date);
        }

        if(!empty($num)) {
            $sep = $this->sef_config->replacement_character;
            $where = $this->params->get('google_news_pos', '2');

            if($where == '2') {
                $title = $title.$sep.$num;
            } else {
                $title = $num.$sep.$title;
            }
        }

        return $title;
    }
	
	function getItemCatId($id) {
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT catid FROM #__content WHERE id =".$id);
        $rows = $database->loadResult();
		return $rows;
    }
	
	function beforeBuildRoute(&$uri) {
		if(is_null($uri->getVar('limitstart')) || ($uri->getVar('limitstart') == '0')) {
            $uri->delVar('limitstart');
            $uri->delVar('limit');
        }
		if(($uri->getVar('view') == 'article') && (is_null($uri->getVar('catid')) || ($uri->getVar('catid') == 0))){
			$catid = $this->getItemCatId($uri->getVar('id'));
			$uri->setVar('catid', $catid);
		}
		// Add the view variable if it's not set
		if (is_null($uri->getVar('view'))) {
            if (is_null($uri->getVar('id')))
                $uri->setVar('view', 'frontpage');
            else
                $uri->setVar('view', 'article');
        }
        return;
    }
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();
		
		$this->params = AceSEFTools::getExtParams('com_content');
		
		$cat_suffix 	= $this->params->get('cat_suffix', '1');
		$default_index	= $this->params->get('default_index', '');
	
		if(isset($view)) {
            switch($view) {
				case 'section':
                    if(isset($id))
                        $title[] = $this->getSectionTitle($id);
					if($cat_suffix == '1' && $default_index == '')
						$title[] = "/";
					if($default_index != '')
						$title[] = $default_index;
                    break;
                case 'category':
					if(isset($id))
						$title = array_merge($title, $this->getCategoryTitle($id));
					if($cat_suffix == '1' && $default_index == '')
						$title[] = "/";
					if($default_index != '')
						$title[] = $default_index;
                    break;
				case 'article':
					if(isset($id))
						$title = array_merge($title, $this->getArticleTitle($id));
						
					// Google News
					if($this->params->get('google_news', '1') != '1') {
						$i = count($title) - 1;
						$title[$i] = $this->googleNews($title[$i], $id);
					}
					
					if (isset($limitstart))
						$title[] = 'item_limitstart';
					
					if (isset($task))
						$title[] = $task;
					
					if (isset($print))
						$title[] = JText::_('PRINT');
					
					if (isset($showall) && $showall == 1)
						$title[] = JText::_('ALL');

                    break;
				case 'frontpage':
					if ($title == "")
						$title = "/";
					break;
            }
        }

		return $title;
	}
	
	function metaTags(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$meta = array();

		$config =& JFactory::getConfig();
		
		$enable_title		= $this->params->get('enable_title', '2');
		$enable_desc		= $this->params->get('enable_desc', '2');
		$enable_key			= $this->params->get('enable_key', '2');
		$separator			= $this->params->get('separator', '-');
		$sitename			= $config->getValue('sitename');
		$custom_sitename	= $this->params->get('custom_sitename', '');
		$use_sitename		= $this->params->get('use_sitename', '2');
		$title_prefix		= $this->params->get('title_prefix', '');
		$title_suffix		= $this->params->get('title_suffix', '');
		$desc_length		= $this->params->get('desc_length', '250');
		$keywords_word		= $this->params->get('keywords_word', '3');
		$keywords_count		= $this->params->get('keywords_count', '15');
		$blacklist			= $this->params->get('blacklist', '');
		
		$title = $desc = "";
		
		if (isset($view)){
			switch ($view){
				case 'section': 
					if(isset($id)){
						$title	= $this->title_sec;
						$desc	= AceSEFTools::cleanDesc(AceSEFTools::clipDesc($this->desc_sec, $desc_length));
					}
					if($enable_key == 2 && !empty($this->desc_sec))	
						$meta['metakey'] = AceSEFTools::generateKeywords(AceSEFTools::cleanDesc($this->desc_sec), $blacklist, $keywords_count, $keywords_word);
					break;
				case 'category': 
					if(isset($id)){
						$title	= implode(" ".$separator." ", array_reverse($this->title_cat));
						$desc	= AceSEFTools::cleanDesc(AceSEFTools::clipDesc($this->desc_cat, $desc_length));
					}
					if($enable_key == 2 && !empty($this->desc_cat))	
						$meta['metakey'] = AceSEFTools::generateKeywords(AceSEFTools::cleanDesc($this->desc_cat), $blacklist, $keywords_count, $keywords_word);
					break;
				case 'article': 
					if(isset($id)){
						$title	= implode(" ".$separator." ", array_reverse($this->title_item));
						$desc	= AceSEFTools::cleanDesc(AceSEFTools::clipDesc($this->desc_item, $desc_length));
					}
					if($enable_key == 2 && !empty($this->desc_item))	
						$meta['metakey'] = AceSEFTools::generateKeywords(AceSEFTools::cleanDesc($this->desc_item), $blacklist, $keywords_count, $keywords_word);
					break;
				case 'frontpage':
						$title = AceSEFTools::getMenuTitle($option, $Itemid);
						$desc	= $config->getValue('MetaDesc');
						$meta['metakey'] = $config->getValue('MetaKeys');
					break;
			}
		}
		
		// Set meta tags
		if($enable_title == 2 && !empty($title)){
			// Prepare meta title			
			if(!empty($custom_sitename))
				$sitename = $custom_sitename;
			
			if($use_sitename == 1)
				$title = $sitename." ".$separator." ".$title;
			elseif ($use_sitename == 2)
				$title = $title." ".$separator." ".$sitename;
				
			if(!empty($title_prefix))
				$title = $title_prefix." ".$separator." ".$title;
				
			if(!empty($title_suffix))
				$title = $title." ".$separator." ".$title_suffix;
			
			$meta['metatitle']	= $title;
		}
		
		if($enable_desc == 2 && !empty($desc))
			$meta['metadesc']	= $desc;
		
		
		return $meta;
	}
}
?>