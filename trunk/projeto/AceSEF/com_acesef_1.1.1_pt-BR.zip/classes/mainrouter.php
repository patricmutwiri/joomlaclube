<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');
require_once(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php');

// Main router class
class acesefRouter extends AceSEFTools {

	var $metatags = null;
	var $ext_meta = null;
	var $generator = null;
	var $dosef = null;
	var $item_limitstart = null;
	var $sef_config = null;
	var $_subdir = null;
	var $_buffer_routers = null;
	var $_buffer_menus = null;
	var $_is_post = null;
	var $_is_resolved = null;
	var $_is_404page = null;

	function acesefRouter($options = array()) {
		parent:: __construct($options);
		$this->_mode = 1;
		$this->metatags = array();
		$this->ext_meta = array();
		$this->generator = null;
		$this->dosef = true;
		$this->item_limitstart = false;
		// read the configuration file
		require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
		$this->sef_config = new acesef_configuration();
		$this->_is_post = false;
		$this->_is_resolved = false;
		$this->_is_404page = false;
	}

	// The parse function handles the incomming URL
	function parse(&$uri){
		global $mainframe;
		$db	=& JFactory::getDBO();
        $menu =& JSite::getMenu(true);
		$vars = array();
		$result = false;
		$this->_is_resolved = false;
		
		if(is_string($uri)) {
			$uri = JURI::getInstance($uri);
		}
		
		if (count($_POST) > 0) {
			// Establish the non-sef URL and return the POST
			// Don't rewrite the post
			$this->_is_post = true;
			$vars += parent::parse($uri);

			if (isset($_POST['return'])) {
				if (!isset($_POST['force_session'])) {
					// Virtuemart hack
					return $_REQUEST;
				}
			}
			// This should be within the router configuration

			// Check if the POST must be return direct;
			if (!empty($_REQUEST['option'])) {
				$db->setQuery("SELECT bypass_post_redirect FROM #__acesef_routers WHERE component='".$_REQUEST['option']."'");
				$bypass = $db->loadResult();

				if ($_REQUEST['option'] == 'com_user') {
					$bypass = true;
				}
				if (!empty($bypass)) {
					if ($bypass == 1) {
						return $_REQUEST;
					}
				}
			}

		}

		// If the path is equal to "/" it means that is home page
		if($this->_mode == JROUTER_MODE_SEF) {

			$is_print = false;
			
			// Check if there is any index2 page that should be returned directly
			$pos = strpos($uri->_uri, 'index2.php');
			if ($pos > 0) {
				$is_print = true;
				return ($_POST);
			}
			
			// Check the scriptname to retrieve sub-path's
			$sub_dir = str_replace('index.php', '', $_SERVER['SCRIPT_NAME']);
			$sub_dir = str_replace('index2.php', '', $sub_dir);
			$this->_subdir = $sub_dir;
			$remove_string = $uri->_scheme.'://'.$uri->_host.$sub_dir;
			$url2search = str_replace($remove_string, '', $uri->_uri);

			if ($url2search == "" || $url2search == 'index.php')
				$uri->_path = $sub_dir;

			$db->setQuery("SELECT id, url_sef, url_real, blocked FROM #__acesef_urls WHERE published = '1' AND url_sef = '".$url2search."' ORDER BY used DESC");
	    	$sef_repository = $db->loadObjectList();
	    	
	    	// Check if then URL excist in db
	    	if (count($sef_repository) > 0) {				
				// Set the QUERY_STRING, expecially for VirtueMart redirects
				$QUERY_STRING = str_replace('index.php?', '', $sef_repository[0]->url_real);
				if ($this->sef_config->set_query_string == 1)
					$_SERVER['QUERY_STRING'] = $QUERY_STRING;
				
				// Set vars
				parse_str($QUERY_STRING, $vars);
				$this->setVars($vars);
				
				// Set some variables
				$this->_is_resolved = true;
				$result = true;

				// Set meta tags and generator for plugin
				$this->metatags	= AceSEFTools::getMetaTags($sef_repository[0]->url_real);
		
	    	} else {	    		
				// Not found, first check if the URL is HOMEPAGE
    			if($uri->_path == $sub_dir || $uri->_path == "" || $uri->_path == "/") {
					// Get default menu
					$item = $menu->getDefault();

					// Set the information in the request
					$vars = $item->query;
					$url_request = $item->link.'&Itemid='.$item->id;
					
					// Get the itemid
					$vars['Itemid'] = $item->id;

					// Set the active menu item
					$menu->setActive($vars['Itemid']);
					
					// Determine language
					AceSEFTools::determineLanguage(JRequest::getVar('lang'));
					
					// Set the variables
					$this->setVars($vars);
					
					$sef_url = "/";
					
					$result = true;

				} else {
					// For security check if the URL has query
    				if (isset($uri->_query)) {
						
						// Check if the URL exits as a none sef URL
						$db->setQuery("SELECT url_sef FROM #__acesef_urls WHERE url_real = ".$uri->_query."'");
	    				$sef_url = $db->loadResult();
						if ($sef_url != "") {
							@ob_end_clean();
							if (substr($sef_url, 0, 1) != "/") {
								$sef_url = '/'.$sef_url;
							}
							$url_rewrite = $uri->_scheme."://".$uri->_host.$sef_url;
							header('Location: '.$url_rewrite);
							header('HTTP/1.1 301 Moved Permanently');
							$mainframe->close(0);
						}
						
						// URL not found so build it
    					if ($uri->_query != false) {
							$sef_url = $this->build($uri->_query, null);
		    		  		if ($sef_url->_path == null) {
		    		  			$result = false;
		    		  		} else {
		    		  			$result = true;
		    		  		}
    					} else {
    						$result = false;
    					}
    				} else {
    					$result = false;
    				}
				}
				
	    		if (!$result) {
					// This is 404 error page, save it in db
					$query = "INSERT INTO #__acesef_urls ( url_real, url_sef, published, used ) VALUES ('', '$url2search', '0', '9')";
					$db->setQuery($query);
					$db->query();
					
					// Check if should be written to a logfile
					include_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'404handler.php');
	    			$vars = acesef_404handler($this->sef_config, $url2search);
					$this->_is_404page = true;
					$this->setVars($vars);
					return $vars;
	    		} else {
					$index = strrpos($url_request, 'index.php?');
	    			if (($sef_url != null) && $index == true) {						
						// Check if the URL already exits
						if (!isset($url_request)){
							$url_request = $uri->getQuery();
							$vars = $uri->_vars;
							$sef_url = ltrim($sef_url->_uri, '/');
						}
						
						if (!headers_sent()) {
							// Clean the output header
							@ob_end_clean();
							
							if ($sef_url == "/")
								$sef_url = $sub_dir.$sef_url;
							else
								$sef_url = $subdir."/".$sef_url;
							
							// Remove double slashes
							$sef_url = str_replace('//', '/', $sef_url);

							$url_rewrite = $uri->_scheme."://".$uri->_host.$sef_url;
							header('Location: '.$url_rewrite);
							header('HTTP/1.1 301 Moved Permanently');
							$mainframe->close(0);
						}
    				}
    			}
    		}
		}

		// Handle pagination
		if($start = JRequest::getVar('start', null, 'get', 'int')) {
			$this->setVar('limitstart', $start);
			unset($this->_vars['start']);
		}
		
		$uri->_vars = $vars;

		// Check if a task is set (legacy mode)
		if (isset($vars['task'])){
			global $task;
			$task= $vars['task'];
		}
		
		$lang = isset($vars['lang']) ? $vars['lang'] : null;
        AceSEFTools::determineLanguage($lang);
		
		// Get the variables from the uri
        $this->setVars($vars);
		
		// Set vars
        $this->setRequestVars($vars);
		
		// Set generator
		$this->generator = $this->sef_config->generator;
		
		return $vars;
	}

	// Build the SEF URL
	function build($url = null, $vars = null){
		$db 		 =& JFactory::getDBO();
		$menu 		 =& JSite::getMenu();
		$is_homepage = false;
		$sef_url 	 = null;
		
		$real_url = str_replace('&amp;', '&', $url);
		
		// Fix URL of menus
		$menuArray = explode("Itemid=", $real_url);
		if($menuArray[0] == "index.php?"){
			$item = $menu->getItem($menuArray[1]);
			$real_url = $item->link.'&Itemid='.$item->id;
		}
		
		// Create variables
		$uri =& $this->_createURI($real_url);
		
		// Check if the option value is set
		if (is_null($uri->getVar('option'))) {
			if (!is_null($uri->getVar('Itemid'))) {
				$item = $menu->getItem($uri->getVar('Itemid'));
				if (is_object($item)) {
					foreach($item->query as $k => $v) {
						$uri->setVar($k, $v);
					}
				}
			}
		}

		// Get home page and set ItemID if empty
		$Itemid = $uri->getVar('Itemid');
		if(!empty($Itemid)){
			$item = $menu->getDefault();
			if ($uri->getVar('Itemid') == $item->id)
				$is_homepage = true;
		} elseif($this->sef_config->insert_active_itemid == 1) {
			$item = $menu->getActive();
			$uri->setVar('Itemid', $item->id);
		}
		
		// Add JoomFish lang code
		if (AceSEFTools::JoomFishInstalled()) {
			$lang = $uri->getVar('lang');
            // If lang not set
            if (empty($lang))
				$uri->setVar('lang', AceSEFTools::getLangCode());
			
			// Check if we should prepend the lang code to sef url
			$langCode = $this->sef_config->joomfish_lang_code;
			$mainLang = $this->sef_config->joomfish_main_lang;
			if ($langCode != '0' && ($this->sef_config->joomfish_main_lang == '0' || $uri->getVar('lang') != $mainLang))
				$sef_url = $uri->getVar('lang').'/';

            // Get the URL's language and set it as global language (for correct translation)
            $lang = $uri->getVar('lang');
            $code = '';
            if (!empty($lang)) {
                $code = AceSEFTools::getLangLongCode($lang);
                if (!is_null($code)) {
                    if ($code != AceSEFTools::getLangLongCode()) {
                        $language =& JFactory::getLanguage();
                        $prevLang = $language->setLanguage($code);
                        $language->load();
                    }
                }
            }
        }
		
		// Lets do this job, start routing
		$routed					= false;
		$this->item_limitstart	= false;
		$this->dosef 			= true;
		$component 				= $uri->getVar('option');
		
		if (isset($component)) {
			// First check if there is an AceSEF extension
			$extension = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.$component.'.php';
			
			// Check if there is any router file
			$router = JPATH_BASE.DS.'components'.DS.$component.DS.'router.php';
			
			// Check if there is any sef_ext file
			$componentName = str_replace('com_', '', $component);
			if (!class_exists('sef_'.$componentName)){
				 // Class not loaded try to fetch the class
				$sef_exts = array(
					JPATH_BASE.DS."administrator".DS."components".DS."com_$componentName".DS."sef_ext.php",
					JPATH_BASE.DS."components".DS."com_$componentName".DS."sef_ext.php",
					JPATH_BASE.DS."administrator".DS."components".DS."com_acesef".DS."extensions".DS."sef_$componentName.php",
				);
				foreach ($sef_exts as $sef_ext) {
					if (file_exists($sef_ext) && is_readable($sef_ext) && filesize($sef_ext) > 0) {
						@include_once($sef_ext);
						if (class_exists('sef_'.$componentName)){
							break;
						}
					}
				}
			}
			
			// Check if the component routing is enabled
			if ($this->_buffer_routers == null) {
				$db->setQuery("SELECT rewrite_rule, component_prefix, component, skip_title FROM #__acesef_routers");
				$this->_buffer_routers = $db->loadObjectList('component');
			}
			
			// Set the router if there is not setted
			if (!isset($this->_buffer_routers[$component])){
				if(file_exists($extension)) {
					if(file_exists($router))
						$type = 4;
					else 
						$type = 3;
					$rule = 3;
				} elseif (file_exists($router)){ 
					$type = 2;
					$rule = 2;
				} elseif (file_exists($sef_exts)){ 
					$type = 5;
					$rule = 5;
				} else { 
					$type = 1;
					$rule = 1;
				} 
				
				$db->setQuery("INSERT INTO #__acesef_routers ( router_type, rewrite_rule, component_prefix, component, skip_title, bypass_post_redirect ) VALUES ( '".$type ."', '".$rule."', '', '".$component."', '0', '0')");
				$db->query();
			
				$db->setQuery("SELECT rewrite_rule, component_prefix, component, skip_title FROM #__acesef_routers");
				$this->_buffer_routers = $db->loadObjectList('component');
			}
			
			$rewrite_rule = $this->_buffer_routers[$component]->rewrite_rule;
			
			// Start routing...
			if ($rewrite_rule != 0){
				// AceSEF extension
				if (!$routed && file_exists($extension) && $rewrite_rule == 3){
					require_once $extension;
					$class = 'AceSEF_'.$component;
					$sef_ext = new $class();
					
					// Make some pagination fixes
					if ($uri->getVar('limitstart') == '' || $uri->getVar('limitstart') == '0')
						$uri->delVar('limitstart');
					if (is_null($uri->getVar('limitstart')) && !is_null($uri->getVar('limit')))
						$uri->delVar('limit'); // this is for VirtueMart
					
					// Remove : variable from id's
					$uri = AceSEFTools::fixUriVariables($uri);
					
					// Get extension parameters
					$params = AceSEFTools::getExtParams($component);
					
					// Override menu item id if set to
					$override = $params->get('override', '1');
					$overrideId = $params->get('overrideId', '1');
					if (($override != '1') && ($overrideId != ''))
						$uri->setVar('Itemid', $overrideId);
					
					// Make changes on URI before building route
					$sef_ext->beforeBuildRoute($uri);
					
					// Build main route
					$parts = $sef_ext->buildRoute($uri);
					
					// Make changes on URI after the route is built
					$sef_ext->afterBuildRoute($uri);
					
					// Get meta tags from extension
					$this->ext_meta = $sef_ext->metaTags($uri);
					
					// Check if it is dosef is false
					if(in_array('dosef_false', $parts))
						$this->dosef = false;
					
					if(in_array('item_limitstart', $parts)){
						$this->item_limitstart = true;
						$key = array_search('item_limitstart', $parts);
						unset($parts[$key]);
					}
					
					if($this->dosef == true) {							
						// Add component prefix or menu title/alias
						$skip = $this->_buffer_routers[$component]->skip_title;
						if($skip == 0){
							$prefix = $this->_buffer_routers[$component]->component_prefix;
							if(empty($prefix))
								$prefix = AceSEFTools::getMenuTitle($component, $uri->getVar('Itemid'));
							if(!empty($prefix))
								array_unshift($parts, $prefix);
						}
						
						// Load parts as string
						if(!empty($parts))
							$result = implode('/', $parts);
						
						// Finallize the url
						if(empty($sef_url)) // Check if lang code is inserted
							$sef_url = ($result) ? $result : null;
						else
							$sef_url .= ($result) ? $result : null;
						
						$routed = true;
					}
				}
				
				// Not routed, check if there is any router.php
				if (!$routed && file_exists($router) && $rewrite_rule == 2){
					require_once $router;
					$function = substr($component, 4).'buildRoute';
					$vars = $uri->_vars;
					$parts = $function($vars);

					// Replace : with -
					$parts = $this->_encodeSegments($parts);
					
					// Include component prefix or menu title/alias
					$skip = $this->_buffer_routers[$component]->skip_title;
					if($skip == 0){
						$prefix = $this->_buffer_routers[$component]->component_prefix;
						if(empty($prefix))
							$prefix = AceSEFTools::getMenuTitle($component, $uri->getVar('Itemid'));
						if(!empty($prefix))
							array_unshift($parts, $prefix);
					}
					
					// Load parts as string
					if(!empty($parts))
						$result = implode('/', $parts);
					
					// Finallize the url
					if(empty($sef_url)) // Check if lang code is inserted
						$sef_url = ($result) ? $result : null;
					else
						$sef_url .= ($result) ? $result : null;
					
					$routed = true;
				}
				
				// Not routed, check if there is any sef_ext.php
				if (!$routed && class_exists('sef_'.$componentName) && ($rewrite_rule == 4 || $rewrite_rule == 5)){
					$class = 'sef_'.$componentName;
					$sef_ext = new $class();
					
					// Include component prefix or menu title/alias
					if ($rewrite_rule == 1) {
						$skip = $this->_buffer_routers[$component]->skip_title;
						if($skip == 0){
							$prefix = $this->_buffer_routers[$component]->component_prefix;
							if(empty($prefix))
								$prefix = AceSEFTools::getMenuTitle($component, $uri->getVar('Itemid'));
						}
					}
					
					if(empty($sef_url)) // Check if lang code is inserted
						$sef_url = $sef_ext->create(str_replace('&', '&amp;', $real_url));
					else
						$sef_url .= $sef_ext->create(str_replace('&', '&amp;', $real_url));
					
					if (strlen($sef_url) > 0) {
						if (substr($sef_url, 0, 1) == '/') {
							$sef_url .= $prefix.$sef_url;
						} else {
							$sef_url .= $prefix.'/'.$sef_url;
						}
					}
					$routed = true;
				}
				
				// Not routed, check if basic rewriting is required
				if (!$routed && $rewrite_rule == 1) {
					// Include component prefix or menu title/alias
					$skip = $this->_buffer_routers[$component]->skip_title;
					if($skip == 0){
						if(empty($sef_url)){ // Check if lang code is inserted
							if(!empty($this->_buffer_routers[$component]->component_prefix))
								$sef_url = $this->_buffer_routers[$component]->component_prefix;
							else
								$sef_url = AceSEFTools::getMenuTitle($component, $uri->getVar('Itemid'));
						} else {
							if(!empty($this->_buffer_routers[$component]->component_prefix))
								$sef_url .= $this->_buffer_routers[$component]->component_prefix;
							else
								$sef_url .= AceSEFTools::getMenuTitle($component, $uri->getVar('Itemid'));
						}
					}
					
					// Backup the option then delete it
					$tmp_option = $uri->getVar('option');
					$uri->delVar('option');
					
					$vars = $uri->_vars;
					
					// Add all values to new url
					foreach ($vars as $name => $value) {
						if (strtolower($name) != 'itemid')
							$sef_url .= "/".$value;
					}
					
					// Replace : with -
					$urlArray = explode('/', $sef_url);
					$urlArray = $this->_encodeSegments($urlArray);
					$sef_url = implode('/', $urlArray);
					
					// Reload option
					$uri->setVar('option', $tmp_option);
					
					$routed = true;
				}
			}
		}
		
		// Convert URI to real url
		$real_url = $uri->toString();
		
		// Finalize this job
		if($routed && $real_url != "" && ($sef_url != "" || $is_homepage == true)) {
			$real_url	= AceSEFTools::finalizeRealUrl($uri);
			$sef_url	= AceSEFTools::finalizeSefUrl($uri, $sef_url, $real_url, $this->item_limitstart);
			
			$db->setQuery("SELECT id, url_sef, blocked FROM #__acesef_urls WHERE url_real='".$real_url."'");
			$sef_repository = $db->loadObjectList();
			// First check if real url exists in db
			if (count($sef_repository) > 0) {
				if ($sef_repository[0]->blocked == 0) {
					// URL is not blocked so send the sef url to URI
					$uri->setPath(JURI::base(true).'/'.$sef_repository[0]->url_sef);
					$uri = new JURI($this->_subdir.$sef_repository[0]->url_sef);
				} else {
					// URL is blocked so send the real url to URI
					$uri->setPath(JURI::base(true).'/'.$sef_repository[0]->url_real);
					$uri = new JURI($this->_subdir.$sef_repository[0]->url_real);
				}
				
				return $uri;
			} else {
				// Get automatic meta tags from extension
				$ext_metatags = $ext_metavalues = "";
				$meta = $this->ext_meta;
				if (is_array($meta) && count($meta) > 0) {
					foreach($meta as $tag => $value) {
						$ext_metatags .= ", $tag";
						$ext_metavalues .= ", '".str_replace(array("'", ";"), array("\\'", "\\;"), $value)."'";
					}
				}
				
				// Save data in db
				$values = "( '".$real_url."', '".$sef_url."' ".$ext_metavalues.", '1', '9' )";
				$db->setQuery("INSERT INTO #__acesef_urls ( url_real, url_sef".$ext_metatags.", published, used ) VALUES ".$values);
				$db->query();
				if ($this->_is_post)
					$this->_is_post = false;
			}
		} else
			$sef_url = $real_url;
		
		// Add Fragment to URL
		$fragment = $uri->getFragment();
		if (!empty($fragment)) {
			$sef_url .= '#'.$fragment;
		}
			
		$uri = new JURI($this->_subdir.$sef_url);
		
		return $uri;
	}
	
	
	// Create Variables
	function _createVars($real_url) {
		$url_check = parse_url($real_url);
		$vars = null;
		if (isset($url_check['query'])) {
			$url_parts = explode('&', $url_check['query']);
			$vars = array();
			foreach ($url_parts as $element) {
				if (strpos($element,'=') == true) {
					$content = explode('=', $element);
					$vars[$content[0]] = $content[1];
				}
			}
		}
		return $vars;
	}
	
	// Set the variables to JRequest, as mainframe does not overwrite non-sef variables, so they hide the parsed ones
	function setRequestVars(&$vars) {
		if(is_array($vars) && count($vars)) {
			foreach($vars as $name => $value) {
				// Clean the var
				$GLOBALS['_JREQUEST'][$name] = array();
				
				// Set the GET array
				$_GET[$name] = $value;
				$GLOBALS['_JREQUEST'][$name]['SET.GET'] = true;
				
				// Set the REQUEST array if request method is GET
				if( $_SERVER['REQUEST_METHOD'] == 'GET' ) {
					$_REQUEST[$name] = $value;
					$GLOBALS['_JREQUEST'][$name]['SET.REQUEST'] = true;
				}
			}
		}
    }
}

?>