<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Control Panel Controller Class
class AcesefControllerAcesef extends AcesefController {

	// Main construct
 	function __construct() {
		parent::__construct();	
	}
	
	// Call display function of Model
	function display() {
		parent::display();
	}
}
?>