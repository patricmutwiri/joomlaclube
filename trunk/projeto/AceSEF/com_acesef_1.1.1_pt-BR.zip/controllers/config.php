<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Configuration Controller Class
class AcesefControllerConfig extends AcesefController {
	
	// Main constructer
 	function __construct() {
		parent::__construct();
	}
	
	// Edit Configuration
	function edit() {
		$model = $this->getModel('config');
		$view = $this->getView('config','html');
		$model->_set_configuration();

		$view->assignRef('acesef_config', $model->_configuration);
		$view->edit();
	}
	
	// Cancel saving changes
	function cancel() {
		$this->setRedirect('index.php?option=com_acesef', JTEXT::_('ACESEF_CONFIG_NOT_SAVED'));
	}
	
	// Save changes
	function save() {
		$model = $this->getModel('config');
		if ($model->_save_configuration())
			$this->setRedirect('index.php?option=com_acesef', JTEXT::_('ACESEF_CONFIG_SAVED'));
		else
			$this->setRedirect('index.php?option=com_acesef', JTEXT::_('ACESEF_CONFIG_ERROR'));
	}
	
	// Apply changes
	function apply() {
		$model = $this->getModel('config');
		$model->_save_configuration();
		$this->setRedirect('index.php?option=com_acesef&controller=config&task=edit', JTEXT::_('ACESEF_CONFIG_SAVED'));
	}
	
	// Apply changes and Purge URLs
	function applypurge() {
		$model = $this->getModel('config');
		if ($model->_save_configuration())
			$msg =  JTEXT::_('ACESEF_CONFIG_SAVED_PURGED');
		else
			$msg = JTEXT::_('ACESEF_CONFIG_ERROR');
			
		// Cleanup the repository
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purge();
		
		// Return to cpanel
		$this->setRedirect('index.php?option=com_acesef&controller=config&task=edit', $msg);
	}
	
	// Save changes and Purge URLs
	function savepurge() {
		$model = $this->getModel('config');
		if ($model->_save_configuration())
			$msg = JTEXT::_('ACESEF_CONFIG_SAVED_PURGED');
		else
			$msg = JTEXT::_('ACESEF_CONFIG_ERROR');
		
		// Cleanup the repository
		include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'purge.php');
		$purge_model =& new AcesefModelPurge();
		$purge_model->purge();
		
		// Return to cpanel
		$this->setRedirect('index.php?option=com_acesef', $msg);
	}
}
?>