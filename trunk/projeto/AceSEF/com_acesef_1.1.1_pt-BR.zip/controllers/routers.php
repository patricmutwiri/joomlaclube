<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');

// Routers Controller Class
class AcesefControllerRouters extends AcesefController {
	
	// Main constructer
	function __construct() 	{
		parent::__construct();
	}
	
	// View routers
	function view() {
		$model =& $this->getModel('routers');

		// Build up the local routers;
		$model->check_state_routers();
		$view  = $this->getView('routers','html');
		$view->setModel($model, true);
		$view->view();
	}
	
	// Save changes
	function save() {
		$model =& $this->getModel('routers');
		$model->save();
		$this->setRedirect('index.php?option=com_acesef&controller=routers&task=view', JTEXT::_('ACESEF_ROUTER_SAVED'));
	}
	
	// Save changes & Purge URLs
	function savepurge() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('routers');
		foreach ($cid as $id) {
			$model->savepurge($id);
		}
		// Return to extensions page
		$this->setRedirect('index.php?option=com_acesef&controller=routers&task=view', JTEXT::_('ACESEF_ROUTER_SAVED_PURGED'));
	}
	
	// Go home ;)
	function back() {
		$this->setRedirect('index.php?option=com_acesef', JTEXT::_('ACESEF_ROUTER_NOT_SAVED'));
	}
	
	// Rebuild routers
	function rebuild() {
		$model =& $this->getModel('routers');
		$model->purge();
		$this->view();
	}
}
?>