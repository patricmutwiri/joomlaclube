<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

?>
<table cellspacing="0" cellpadding="0" border="0" width="100%">
	<tr>
		<td valign="top">
			<table class="adminlist">
				<tr>
					<td>
						<div id="cpanel" width="50%">
						<?php
						global $option;

						$link = 'index.php?option='.$option.'&amp;controller=config&amp;task=edit';
						AcesefViewAcesef::quickiconButton($link, 'cp-configuration.png', JText::_('ACESEF_CPANEL_CONFIGURATION'));

						$link = 'index.php?option='.$option.'&amp;controller=extensions&amp;task=view';
						AcesefViewAcesef::quickiconButton($link, 'cp-extensions.png', JText::_('ACESEF_CPANEL_EXTENSIONS'));

						$link = 'index.php?option='.$option.'&amp;controller=routers&amp;task=view';
						AcesefViewAcesef::quickiconButton($link, 'cp-router.png', JText::_('ACESEF_CPANEL_ROUTER_SETTINGS'));
						
						$link = 'index.php?option='.$option.'&amp;controller=import&amp;task=view';
						AcesefViewAcesef::quickiconButton($link, 'cp-import.png', JText::_('ACESEF_CPANEL_IMPORT'));
						
						$link = 'index.php?option='.$option.'&amp;controller=upgrade&amp;task=view';
						AcesefViewAcesef::quickiconButton($link, 'cp-upgrade.png', JText::_('ACESEF_CPANEL_UPGRADE'));
						?>
						<br /><br /><br /><br /><br /><br /><br /><br />
						<?php
						$link = 'index.php?option='.$option.'&amp;controller=repository&amp;task=view&amp;type=1';
						AcesefViewAcesef::quickiconButton($link, 'cp-urlssef.png', JText::_('ACESEF_CPANEL_SEF_URLS'));
						
						$link = 'index.php?option='.$option.'&amp;controller=repository&amp;task=view&amp;type=2';
						AcesefViewAcesef::quickiconButton($link, 'cp-urlscustom.png', JText::_('ACESEF_CPANEL_CUSTOM_URLS'));

						$link = 'index.php?option='.$option.'&amp;controller=repository&amp;task=view&amp;type=3';
						AcesefViewAcesef::quickiconButton($link, 'cp-urls404.png', JText::_('ACESEF_CPANEL_404_URLS'));
						
						$link = 'http://www.joomace.net/free-downloads/manuals/acesef';
						AcesefViewAcesef::quickiconButton($link, 'cp-doc.png', JText::_('ACESEF_CPANEL_DOC'));
						
						$link = 'index.php?option='.$option.'&amp;controller=support&amp;task=support';
						AcesefViewAcesef::quickiconButton($link, 'cp-support.png', JText::_('ACESEF_CPANEL_SUPPORT'));
						?>
						<br /><br /><br /><br /><br /><br /><br /><br />
						<?php
						$link = 'index.php?option='.$option.'&amp;controller=purge&task=purge&amp;type=1&amp;do=0';
						AcesefViewAcesef::quickiconButton($link, 'cp-purge-urlssef.png', JText::_('ACESEF_CPANEL_PURGE_SEF_URLS'));
						
						$link = 'index.php?option='.$option.'&amp;controller=purge&task=purge&amp;type=2&amp;do=0';
						AcesefViewAcesef::quickiconButton($link, 'cp-purge-urlscustom.png', JText::_( 'ACESEF_CPANEL_PURGE_CUSTOM_URLS'));

						$link = 'index.php?option='.$option.'&amp;controller=purge&task=purge&amp;type=3&amp;do=0';
						AcesefViewAcesef::quickiconButton($link, 'cp-purge-urls404.png', JText::_('ACESEF_CPANEL_PURGE_404_URLS'));
						
						$link = 'index.php?option='.$option.'&amp;controller=support&amp;task=changelog';
						AcesefViewAcesef::quickiconButton($link, 'cp-changelog.png', JText::_('ACESEF_CPANEL_CHANGELOG'));
						?>
						</div>
					</td>
				</tr>
			</table>
		</td>
		<td valign="top" width="50%" style="padding: 7px 0 0 5px">
			<?php
			$title = JText::_('ACESEF_CPANEL_WELLCOME');
			echo $this->pane->startPane('stat-pane');
			echo $this->pane->startPanel($title, 'wellcome');

				?>
				<table class="adminlist">
					<tr>
						<td valign="top" width="50%" align="center">
							<table class="adminlist">
								<tr>
									<td width="%20">
										<?php
											if ($this->version['status'] == 0) {
												echo JHTML::_('image', 'administrator/templates/khepri/images/header/icon-48-checkin.png', null);
											} elseif( $this->version['status'] == -1 ) {
												echo JHTML::_('image', 'administrator/templates/khepri/images/header/icon-48-help_header.png', null);
											} else {
												echo JHTML::_('image', 'administrator/templates/khepri/images/header/icon-48-help_header.png', null);
											}
										?>
									</td>
									<td width="%40">
										<?php
											if ($this->version['status'] == 0) {
												echo '<strong><font color="green">'.JText::_('ACESEF_CPANEL_LATEST_VERSION_INSTALLED').'</font></strong>';
											} elseif($this->version['status'] == -1) {
												echo '<b><font color="red">'.JText::_('ACESEF_CPANEL_OLD_VERSION').'</font></b>';
											} else {
												echo '<b><font color="orange">'.JText::_('ACESEF_CPANEL_NEWER_VERSION').'</font></b>';
											}
										?>
									</td>
									<td align="center" rowspan="5">
										<a href="http://www.joomace.net/joomla-extensions/acesef">
										<img src="components/com_acesef/assets/images/logo.png" width="165" height="232" alt="AceSEF" title="AceSEF" align="middle" border="0">
										</a>
									</td>
								</tr>
								<tr>
									<td>
										<?php
											if ($this->version['status'] == 0) {
												echo '<strong><font color="green">'.JText::_('ACESEF_CPANEL_LATEST_VERSION').'</font></strong>';
											} elseif($this->version['status'] == -1) {
												echo '<b><font color="red">'.JText::_('ACESEF_CPANEL_LATEST_VERSION').'</font></b>';
											} else {
												echo '<b><font color="orange">'.JText::_('ACESEF_CPANEL_LATEST_VERSION').'</font></b>';
											}
										?>
									</td>
									<td>
										<?php
											if ($this->version['status'] == 0) {
												echo '<strong><font color="green">'.$this->version['latest_version'].'</font></strong>';
											} elseif($this->version['status'] == -1) {
												echo '<b><font color="red">'.$this->version['latest_version'].'</font></b>';
											} else {
												echo '<b><font color="orange">'.$this->version['latest_version'].'</font></b>';
											}
										?>
									</td>
								</tr>
								<tr>
									<td>
										<?php echo JText::_('ACESEF_CPANEL_INSTALLED_VERSION'); ?>
									</td>
									<td>
										<?php echo $this->version['installed_version']; ?>
									</td>
								</tr>
								<tr>
									<td>
										<?php echo JText::_('ACESEF_CPANEL_COPYRIGHT'); ?>
									</td>
									<td>
										<a target="_blank" href="http://www.joomace.net">&copy 2009 JoomAce LLC</a>
									</td>
								</tr>
								<tr>
									<td>
										<?php echo JText::_('ACESEF_CPANEL_LICENSE'); ?>
									</td>
									<td>
										<a target="_blank" href="http://www.gnu.org/copyleft/gpl.html">GNU GPL</a>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<?php
				$title = JText::_('ACESEF_CPANEL_URLS_STATS');
				echo $this->pane->endPanel();
				echo $this->pane->startPanel($title, 'stats');
				?>
				<table class="adminlist">
					<tr>
						<td>
							<?php echo JText::_('ACESEF_CPANEL_SEF_URLS').':'; ?>
						</td>
						<td>
							<b><?php echo $this->urls['sef']; ?></b>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo JText::_('ACESEF_CPANEL_CUSTOM_URLS').':'; ?>
						</td>
						<td>
							<b><?php echo $this->urls['custom']; ?></b>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo JText::_('ACESEF_CPANEL_404_URLS').':'; ?>
						</td>
						<td>
							<b><?php echo $this->urls['404']; ?></b>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo JText::_('ACESEF_CPANEL_URL_REPOSITORY').':'; ?>
						</td>
						<td>
							<b><?php echo $this->urls['total']; ?></b>
						</td>
					</tr>
				</table>
				<?php
				$title = JText::_('ACESEF_CPANEL_DONATE');
				echo $this->pane->endPanel();
				echo $this->pane->startPanel($title, 'donate');
				?>
				<table class="adminlist">
					<tbody>
					<tr>
						<td width="60%">
							<?php echo JText::_('ACESEF_CPANEL_DONATE_TEXT'); ?>
						</td>
						<td>
							<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
							<input type="hidden" name="cmd" value="_s-xclick">
							<input type="hidden" name="hosted_button_id" value="8072927">
							<input type="image" src="https://www.paypal.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
							<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
							</form>
						</td>
					</tr>
					</tbody>
				</table>
				<?php
				echo $this->pane->endPanel();
				echo $this->pane->endPane();
				?>
		</td>
	</tr>
</table>