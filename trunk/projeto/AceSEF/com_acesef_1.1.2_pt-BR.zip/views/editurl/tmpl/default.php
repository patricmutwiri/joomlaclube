<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

// Import JPane
jimport('joomla.html.pane');
$pane =& JPane::getInstance('Tabs');
?>
	
<form action="index.php" method="post" name="adminForm" id="adminForm">
	<?php
	echo $pane->startPane('pane');
	echo $pane->startPanel(JText::_('ACESEF_URL_EDIT_TABS_MAIN'), 'main');
	?>
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_URL_EDIT_LEGEND_MAIN'); ?></legend>
		<table class="admintable">
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_REPOS_COMMON_URL_SEF'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="url_sef" id="url_sef" size="100" value="<?php echo $this->row->url_sef; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_REPOS_COMMON_URL_REAL'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="url_real" id="url_real" size="100" value="<?php echo $this->row->url_real; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_REPOS_COMMON_PUBLISHED'); ?>
					</label>
				</td>
				<td width="80%">
					<?php echo $this->lists['published']; ?>
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_REPOS_COMMON_LOCKED'); ?>
					</label>
				</td>
				<td width="80%">
					<?php echo $this->lists['locked']; ?>
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_NOTES'); ?>
					</label>
				</td>
				<td width="80%">
					<textarea name="remarks" rows="4" cols="57" class="text_area"><?php echo $this->row->notes; ?></textarea>
				</td>
			</tr>
		</table>
	</fieldset>
	<?php
	echo $pane->endPanel();
	echo $pane->startPanel(JText::_('ACESEF_URL_EDIT_TABS_SEO'), 'seo');
	?>
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_URL_EDIT_LEGEND_SEO'); ?></legend>
		<table class="admintable">
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METATITLE'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="metatitle" id="metatitle" size="100" value="<?php echo $this->row->metatitle; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METADESC'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="metadesc" id="metadesc" size="100" value="<?php echo $this->row->metadesc; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METAKEY'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="metakey" id="metakey" size="100" value="<?php echo $this->row->metakey; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METALANG'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="metalang" id="metalang" size="30" value="<?php echo $this->row->metalang; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METAROBOTS'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="metarobots" id="metarobots" size="30" value="<?php echo $this->row->metarobots; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METAGOOGLEBOT'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="metagoogle" id="metagoogle" size="30" value="<?php echo $this->row->metagoogle; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METACANONICAL'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="metacanonical" id="metacanonical" size="100" value="<?php echo $this->row->metacanonical; ?>" />
				</td>
			</tr>
		</table>
	</fieldset>
	<?php
	echo $pane->endPanel();
	echo $pane->endPane();

	$this->row->date = date('Y-m-d');
	if($this->row->used != '0' && $this->row->used != '1'){
		$this->row->used = '9';
	}
	?>
	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="editurl" />
	<input type="hidden" name="task" value="edit" />
	<input type="hidden" name="id" value="<?php echo $this->row->id; ?>" />
	<input type="hidden" name="date" value="<?php echo $this->row->date; ?>" />
	<input type="hidden" name="used" id="used" value="<?php echo $this->row->used; ?>" />
</form>