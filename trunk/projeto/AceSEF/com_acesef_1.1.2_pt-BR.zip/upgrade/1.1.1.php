<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// XML
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'acesef.xml', 'upgrade', DS.'acesef.xml');

// Assets
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'logo.png', 'upgrade', DS.'assets'.DS.'images'.DS.'logo.png');

// Classes
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php', 'upgrade', DS.'classes'.DS.'aceseftools.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'mainrouter.php', 'upgrade', DS.'classes'.DS.'mainrouter.php');

// Models
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'repository.php', 'upgrade', DS.'models'.DS.'repository.php');

// Views
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'editurl'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.inc.html', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.inc.html');

// Extensions
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_poll.php', 'upgrade', DS.'extensions'.DS.'com_poll.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_poll.xml', 'upgrade', DS.'extensions'.DS.'com_poll.xml');

// Upgrade
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'upgrade'.DS.'reinstall.php', 'upgrade', DS.'upgrade'.DS.'reinstall.php');

// DB changes
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.0.2' WHERE extension = 'com_poll'");
?>