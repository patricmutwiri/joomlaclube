DELETE FROM `#__plugins` WHERE element = 'acesef';
DROP TABLE `#__acesef_extensions`;
DROP TABLE `#__acesef_routers`;
DROP TABLE `#__acesef_urls`;