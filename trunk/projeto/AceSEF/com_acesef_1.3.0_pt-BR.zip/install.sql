# -----------------------
# AceSEF SQL Installation
# -----------------------
DROP TABLE IF EXISTS `#__acesef_urls`;
CREATE TABLE  `#__acesef_urls` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `url_sef` varchar(255) NOT NULL default '',
  `url_real` varchar(255) NOT NULL default '',
  `metatitle` varchar(255) default '',
  `metadesc` varchar(255) default '',
  `metakey` varchar(255) default '',
  `metalang` varchar(30) default '',
  `metarobots` varchar(30) default '',
  `metagoogle` varchar(30) default '',
  `linkcanonical` varchar(255) default '',
  `published` tinyint(1) unsigned NOT NULL default '1',
  `used` tinyint(1) unsigned NOT NULL default '5',
  `locked` tinyint(1) unsigned NOT NULL default '0',
  `blocked` tinyint(1) unsigned NOT NULL default '0',
  `notes` text default '',
  `sef_tmp_url` varchar(255) NOT NULL default '',
  `checked_out` int(11) NOT NULL,
  `date` date NOT NULL default '0000-00-00',
  `source` text default '',
  `sm_indexed` varchar(3) NOT NULL default '',
  `sm_date` date NOT NULL default '0000-00-00',
  `sm_freq` varchar(30) NOT NULL default '',
  `sm_priority` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `url_real` (`url_real`),
  KEY `url_sef` (`url_sef`)
) TYPE=MyISAM CHARACTER SET `utf8`;

DROP TABLE IF EXISTS `#__acesef_urls_moved`;
CREATE TABLE IF NOT EXISTS `#__acesef_urls_moved` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `url_old` varchar(255) NOT NULL default '',
  `url_new` varchar(255) NOT NULL default '',
  `published` tinyint(1) unsigned NOT NULL default '1',
  `hits` int(11) unsigned NOT NULL default '0',
  `last_hit` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `url_old` (`url_old`)
) TYPE=MyISAM CHARACTER SET `utf8`;

DROP TABLE IF EXISTS `#__acesef_extensions`;
CREATE TABLE  `#__acesef_extensions` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `version` varchar(10) NOT NULL,
  `author` varchar(255) NOT NULL default '',
  `author_url` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `extension` varchar(45) NOT NULL,
  `router_type` tinyint(1) unsigned NOT NULL default '0',
  `rewrite_rule` tinyint(1) unsigned NOT NULL default '0',
  `component_prefix` varchar(255) NOT NULL default '',
  `skip_title` tinyint(1) unsigned NOT NULL default '0',
  `checked_out` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM CHARACTER SET `utf8`;

INSERT INTO `#__acesef_extensions` (`id`, `name`, `params`, `author`, `description`, `version`, `author_url`, `extension`, `router_type`, `rewrite_rule`, `component_prefix`, `skip_title`) VALUES
(1, 'Banners', '', 'JoomAce LLC', 'Banners extension for AceSEF.', '1.3.0', 'www.joomace.net', 'com_banners', '4', '3', 'banner', '0'),
(2, 'Contact', '', 'JoomAce LLC', 'Contact extension for AceSEF.', '1.3.0', 'www.joomace.net', 'com_contact', '4', '3', '', '1'),
(3, 'Content', '', 'JoomAce LLC', 'Content (Articles) extension for AceSEF.', '1.3.0', 'www.joomace.net', 'com_content', '4', '3', '', '1'),
(4, 'Mail To', '', 'JoomAce LLC', 'Mail To extension for AceSEF.', '1.3.0', 'www.joomace.net', 'com_mailto', '4', '3', 'mail', '0'),
(5, 'News Feeds', '', 'JoomAce LLC', 'News Feeds extension for AceSEF.', '1.3.0', 'www.joomace.net', 'com_newsfeeds', '4', '3', '', '0'),
(6, 'Polls', '', 'JoomAce LLC', 'Polls extension for AceSEF.', '1.3.0', 'www.joomace.net', 'com_poll', '4', '3', 'poll', '0'),
(7, 'Search', '', 'JoomAce LLC', 'Search extension for AceSEF.', '1.3.0', 'www.joomace.net', 'com_search', '4', '3', 'search', '0'),
(8, 'User', '', 'JoomAce LLC', 'User extension for AceSEF.', '1.3.0', 'www.joomace.net', 'com_user', '4', '3', 'user', '0'),
(9, 'Web Links', '', 'JoomAce LLC', 'Web Links extension for AceSEF.', '1.3.0', 'www.joomace.net', 'com_weblinks', '4', '3', '', '0'),
(10, 'Wrapper', '', 'JoomAce LLC', 'Wrapper extension for AceSEF.', '1.3.0', 'www.joomace.net', 'com_wrapper', '4', '3', '', '0');

INSERT INTO `#__plugins` ( `name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES ('System - AceSEF', 'acesef', 'system', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', '');