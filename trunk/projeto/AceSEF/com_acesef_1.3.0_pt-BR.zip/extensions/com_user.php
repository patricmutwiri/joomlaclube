<?php
/*
* @package		AceSEF
* @subpackage	User
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_user extends AceSEFTools {
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();

		if(isset($view)){
			$title[] = $view;
		}
		
		if(isset($task)){
			$title[] = $task;
		}

		return $title;
	}
	
	function metaTags(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		
		$acesef_title = $acesef_desc = $acesef_key = "";
		
		if (isset($view)){
			switch ($view){
				case 'register': 
					$acesef_title = JText::_('Register');
					break;
				case 'remind': 
					$acesef_title = JText::_('Forgot your Username?');
					break;
				case 'reset': 
					$acesef_title = JText::_('Forgot your Password?');
					break;
			}
		} else {
			$acesef_title = JText::_('Registered Area');
		}

		$meta = AceSEFTools::setMetaData($acesef_title, $acesef_desc, $acesef_key);
		
		return $meta;
	}
}
?>