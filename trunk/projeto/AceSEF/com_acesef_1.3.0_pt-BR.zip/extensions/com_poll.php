<?php
/*
* @package		AceSEF
* @subpackage	Polls
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_poll extends AceSEFTools {

	var $title_poll;
	
	function getPollTitle($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT title, alias$joomfish FROM #__polls WHERE id =".$id);
        $rows = $database->loadRow();
		
		$name = (($this->params->get('pollid_inc', '1') != '1') ? $id.'-' : '');
		if(AceSEFTools::urlPart($this->params->get('poll_part', 'global')) == 'title'){
			$name .= $rows[0];
		} else {
			$name .= $rows[1];
		}
		
		$this->title_poll = $rows[0];
			
		return $name;
    }
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();

		if(!empty($id)){
			$title[] = $this->getPollTitle($id);
		}

		return $title;
	}
	
	function metaTags(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		
		$separator			= $this->params->get('separator', '-');
		$desc_length		= $this->params->get('desc_length', '250');
		$keywords_word		= $this->params->get('keywords_word', '3');
		$keywords_count		= $this->params->get('keywords_count', '15');
		$blacklist			= $this->params->get('blacklist', '');
		
		$acesef_title = $acesef_desc = $acesef_key = "";
		
		if (isset($view)){
			switch ($view){
				case 'poll': 
					if(isset($id)){
						$acesef_title	= $this->title_poll;
						$acesef_desc	= AceSEFTools::clipDesc($this->title_poll, $desc_length);
					}
					break;
			}
		}
		
		$meta = AceSEFTools::setMetaData($acesef_title, $acesef_desc, $acesef_key);

		return $meta;
	}
}
?>