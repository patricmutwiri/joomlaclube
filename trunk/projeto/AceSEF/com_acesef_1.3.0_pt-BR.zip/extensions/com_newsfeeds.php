<?php
/*
* @package		AceSEF
* @subpackage	News Feeds
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_newsfeeds extends AceSEFTools {

	var $title_cat;
	var $title_item;
	var $desc_cat;
	
	function getCategoryTitle($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT title, alias, description$joomfish FROM #__categories WHERE id =".$id);
        $rows = $database->loadRow();
		
		$name = (($this->params->get('categoryid_inc', '1') != '1') ? $id.'-' : '');
		if(AceSEFTools::urlPart($this->params->get('category_part', 'global')) == 'title'){
			$name .= $rows[0];
		} else {
			$name .= $rows[1];
		}
		
		$this->desc_cat = $rows[2];
		$this->title_cat = $rows[0];
			
		return $name;
    }
	
	function getFeedTitle($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT name, alias$joomfish FROM #__newsfeeds WHERE id =".$id);
        $rows = $database->loadRow();
		
		$name = (($this->params->get('feedid_inc', '1') != '1') ? $id.'-' : '');
		if(AceSEFTools::urlPart($this->params->get('feed_part', 'global')) == 'title'){
			$name .= $rows[0];
		} else {
			$name .= $rows[1];
		}
			
		$this->title_item = $rows[0];
		
		return $name;
    }
	
	// Remove : part from News Feeds id
	function fixFeedId($var) {
        if(!is_null($var)){
			$idArray = explode('-', $var);
			$var = $idArray[0];
		}
		return $var;
    }
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();

		if (isset($view)){
			switch ($view){
				case 'categories': 
					$title[] = JText::_('Categories');
					break;
				case 'category': 
					if(isset($id)) {
						$id	= AceSEFTools::fixVar($id);
						$title[] = $this->getCategoryTitle($id);
					}
					break;
				case 'newsfeed': 
					if(isset($catid)){
						$title[] = $this->getCategoryTitle($catid);
					}
					if(isset($id)){
						$id	= $this->fixFeedId($id);
						$title[] = $this->getFeedTitle($id);
					}
					break;
			}
		}

		return $title;
	}
	
	function metaTags(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		
		$separator			= $this->params->get('separator', '-');
		$desc_length		= $this->params->get('desc_length', '250');
		$keywords_word		= $this->params->get('keywords_word', '3');
		$keywords_count		= $this->params->get('keywords_count', '15');
		$blacklist			= $this->params->get('blacklist', '');
		
		$acesef_title = $acesef_desc = $acesef_key = "";
		
		if (isset($view)){
			switch ($view){
				case 'category': 
					if(isset($id)){
						$acesef_title	= $this->title_cat;
						$acesef_desc	= AceSEFTools::clipDesc($this->desc_cat, $desc_length);
						if(!empty($acesef_desc)){
							$acesef_key = AceSEFTools::generateKeywords($acesef_desc, $blacklist, $keywords_count, $keywords_word);
						}
					}
					break;
				case 'newsfeed': 
					if(isset($catid)){
						$acesef_title	= $this->title_cat;
					}
					if(isset($id)){
						$acesef_title	= $this->title_item." ".$separator." ".$acesef_title;
					}
					break;
				case 'categories': 
					$acesef_title = AceSEFTools::getMenuTitle($option, $Itemid);
					break;
			}
		}
		
		$meta = AceSEFTools::setMetaData($acesef_title, $acesef_desc, $acesef_key);

		return $meta;
	}
}
?>
