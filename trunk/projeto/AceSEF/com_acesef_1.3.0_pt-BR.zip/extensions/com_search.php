<?php
/*
* @package		AceSEF
* @subpackage	Search
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_search extends AceSEFTools {
	
	function beforeBuildRoute(&$uri) {
        $ord = $uri->getVar('ordering', null);
        if($ord == '') {
            $uri->delVar('ordering');
        }
        
        $phrase = $uri->getVar('searchphrase', null);
        if($phrase == 'all') {
            $uri->delVar('searchphrase');
        }
		return;
    }
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();
		
		if(isset($ordering)){
            $title[] = $ordering;
		}
        
        if(isset($searchphrase)){
            $title[] = $searchphrase;
		}
        
        if(isset($submit)){
            $title[] = $submit;
		}
		
		if(isset($searchword)){
            $title[] = $searchword;
		}
			
		return $title;
	}
	
	function metaTags(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		
		$separator			= $this->params->get('separator', '-');
		$desc_length		= $this->params->get('desc_length', '250');
		$keywords_word		= $this->params->get('keywords_word', '3');
		$keywords_count		= $this->params->get('keywords_count', '15');
		$blacklist			= $this->params->get('blacklist', '');
		
		$acesef_title = $acesef_desc = $acesef_key = "";

		if(isset($searchword)){
			$acesef_title	= JText::_('SEARCH')." ".$separator." ".$searchword;
			$acesef_desc	= AceSEFTools::clipDesc($searchword, $desc_length);
		}
		
		$meta = AceSEFTools::setMetaData($acesef_title, $acesef_desc, $acesef_key);
		
		return $meta;
	}
}
?>