<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// XML
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'acesef.xml', 'upgrade', DS.'acesef.xml');

// Create folders
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap');
JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'tmpl');

// Admin
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'configuration.php', 'upgrade', DS.'configuration.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'toolbar.acesef.php', 'upgrade', DS.'toolbar.acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'uninstall.sql', 'upgrade', DS.'uninstall.sql');

// Assets
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'logo.png', 'upgrade', DS.'assets'.DS.'images'.DS.'logo.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'css'.DS.'acesef.css', 'upgrade', DS.'assets'.DS.'css'.DS.'acesef.css');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-sitemap.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-sitemap.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-16-sitemap.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-16-sitemap.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-indexed.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-indexed.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-ping.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-ping.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'icon-32-xml.png', 'upgrade', DS.'assets'.DS.'images'.DS.'icon-32-xml.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'toolbar.png', 'upgrade', DS.'assets'.DS.'images'.DS.'toolbar.png');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-translators.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-translators.png');

// Classes
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php', 'upgrade', DS.'classes'.DS.'aceseftools.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'mainrouter.php', 'upgrade', DS.'classes'.DS.'mainrouter.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'routertools.php', 'upgrade', DS.'classes'.DS.'routertools.php');

// Adapters
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'adapters'.DS.'acesef_ext.php', 'upgrade', DS.'adapters'.DS.'acesef_ext.php');
$this->_addFileOp(DS.'libraries'.DS.'joomla'.DS.'installer'.DS.'adapters'.DS.'acesef_ext.php', 'upgrade', DS.'adapters'.DS.'acesef_ext.php');

// Controllers
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'config.php', 'upgrade', DS.'controllers'.DS.'config.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'editurl.php', 'upgrade', DS.'controllers'.DS.'editurl.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'extensions.php', 'upgrade', DS.'controllers'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'import.php', 'upgrade', DS.'controllers'.DS.'import.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'metamanager.php', 'upgrade', DS.'controllers'.DS.'metamanager.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'movedurls.php', 'upgrade', DS.'controllers'.DS.'movedurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'sefurls.php', 'upgrade', DS.'controllers'.DS.'sefurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'sitemap.php', 'upgrade', DS.'controllers'.DS.'sitemap.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'support.php', 'upgrade', DS.'controllers'.DS.'support.php');

// Models
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'acesef.php', 'upgrade', DS.'models'.DS.'acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'config.php', 'upgrade', DS.'models'.DS.'config.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'editurl.php', 'upgrade', DS.'models'.DS.'editurl.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'extensions.php', 'upgrade', DS.'models'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'import.php', 'upgrade', DS.'models'.DS.'import.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'metamanager.php', 'upgrade', DS.'models'.DS.'metamanager.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'movedurls.php', 'upgrade', DS.'models'.DS.'movedurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'sefurls.php', 'upgrade', DS.'models'.DS.'sefurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'sitemap.php', 'upgrade', DS.'models'.DS.'sitemap.php');

// Views
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'acesef'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'acesef'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'config'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'editurl'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'editurl'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'view.edit.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'view.edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'extension_edit.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'extension_edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'import'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'import'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'import'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'import'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'metamanager'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'metamanager'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'metamanager'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'metamanager'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'movedurls'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'movedurls'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'movedurls'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'movedurls'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurls'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'sefurls'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sefurls'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'sefurls'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'sitemap'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'sitemap'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'sitemap'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'support.php', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'support.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'translators.php', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'translators.php');

// Language files
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'da-DK'.DS.'da-DK.com_acesef.ini', 'upgrade', DS.'languages'.DS.'da-DK'.DS.'da-DK.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'da-DK'.DS.'da-DK.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'da-DK'.DS.'da-DK.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'de-DE'.DS.'de-DE.com_acesef.ini', 'upgrade', DS.'languages'.DS.'de-DE'.DS.'de-DE.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'de-DE'.DS.'de-DE.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'de-DE'.DS.'de-DE.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'el-GR'.DS.'el-GR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'el-GR'.DS.'el-GR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'el-GR'.DS.'el-GR.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'el-GR'.DS.'el-GR.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.com_acesef.ini', 'upgrade', DS.'languages'.DS.'en-GB'.DS.'en-GB.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'en-GB'.DS.'en-GB.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'es-ES'.DS.'es-ES.com_acesef.ini', 'upgrade', DS.'languages'.DS.'es-ES'.DS.'es-ES.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'es-ES'.DS.'es-ES.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'es-ES'.DS.'es-ES.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'fr-FR'.DS.'fr-FR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'fr-FR'.DS.'fr-FR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'fr-FR'.DS.'fr-FR.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'fr-FR'.DS.'fr-FR.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'hr-HR'.DS.'hr-HR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'hr-HR'.DS.'hr-HR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'hr-HR'.DS.'hr-HR.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'hr-HR'.DS.'hr-HR.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'hu-HU'.DS.'hu-HU.com_acesef.ini', 'upgrade', DS.'languages'.DS.'hu-HU'.DS.'hu-HU.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'hu-HU'.DS.'hu-HU.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'hu-HU'.DS.'hu-HU.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'it-IT'.DS.'it-IT.com_acesef.ini', 'upgrade', DS.'languages'.DS.'it-IT'.DS.'it-IT.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'it-IT'.DS.'it-IT.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'it-IT'.DS.'it-IT.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pl-PL'.DS.'pl-PL.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pl-PL'.DS.'pl-PL.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pl-PL'.DS.'pl-PL.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'pl-PL'.DS.'pl-PL.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-BR'.DS.'pt-BR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pt-BR'.DS.'pt-BR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-BR'.DS.'pt-BR.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'pt-BR'.DS.'pt-BR.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-PT'.DS.'pt-PT.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pt-PT'.DS.'pt-PT.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-PT'.DS.'pt-PT.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'pt-PT'.DS.'pt-PT.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'ru-RU'.DS.'ru-RU.com_acesef.ini', 'upgrade', DS.'languages'.DS.'ru-RU'.DS.'ru-RU.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'ru-RU'.DS.'ru-RU.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'ru-RU'.DS.'ru-RU.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sr-RS'.DS.'sr-RS.com_acesef.ini', 'upgrade', DS.'languages'.DS.'sr-RS'.DS.'sr-RS.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sr-RS'.DS.'sr-RS.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'sr-RS'.DS.'sr-RS.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sl-SI'.DS.'sl-SI.com_acesef.ini', 'upgrade', DS.'languages'.DS.'sl-SI'.DS.'sl-SI.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sl-SI'.DS.'sl-SI.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'sl-SI'.DS.'sl-SI.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'tr-TR'.DS.'tr-TR.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'tr-TR'.DS.'tr-TR.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-CN'.DS.'zh-CN.com_acesef.ini', 'upgrade', DS.'languages'.DS.'zh-CN'.DS.'zh-CN.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-CN'.DS.'zh-CN.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'zh-CN'.DS.'zh-CN.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-TW'.DS.'zh-TW.com_acesef.ini', 'upgrade', DS.'languages'.DS.'zh-TW'.DS.'zh-TW.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-TW'.DS.'zh-TW.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'zh-TW'.DS.'zh-TW.com_acesef.menu.ini');

// Extensions
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_banners.php', 'upgrade', DS.'extensions'.DS.'com_banners.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_banners.xml', 'upgrade', DS.'extensions'.DS.'com_banners.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_contact.php', 'upgrade', DS.'extensions'.DS.'com_contact.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_contact.xml', 'upgrade', DS.'extensions'.DS.'com_contact.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.php', 'upgrade', DS.'extensions'.DS.'com_content.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.xml', 'upgrade', DS.'extensions'.DS.'com_content.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_mailto.php', 'upgrade', DS.'extensions'.DS.'com_mailto.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_mailto.xml', 'upgrade', DS.'extensions'.DS.'com_mailto.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_newsfeeds.php', 'upgrade', DS.'extensions'.DS.'com_newsfeeds.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_newsfeeds.xml', 'upgrade', DS.'extensions'.DS.'com_newsfeeds.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_poll.php', 'upgrade', DS.'extensions'.DS.'com_poll.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_poll.xml', 'upgrade', DS.'extensions'.DS.'com_poll.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_search.php', 'upgrade', DS.'extensions'.DS.'com_search.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_search.xml', 'upgrade', DS.'extensions'.DS.'com_search.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_user.php', 'upgrade', DS.'extensions'.DS.'com_user.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_user.xml', 'upgrade', DS.'extensions'.DS.'com_user.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_weblinks.php', 'upgrade', DS.'extensions'.DS.'com_weblinks.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_weblinks.xml', 'upgrade', DS.'extensions'.DS.'com_weblinks.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_wrapper.php', 'upgrade', DS.'extensions'.DS.'com_wrapper.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_wrapper.xml', 'upgrade', DS.'extensions'.DS.'com_wrapper.xml');

// Tables
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_extensions.php', 'upgrade', DS.'tables'.DS.'acesef_extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_urls.php', 'upgrade', DS.'tables'.DS.'acesef_urls.php');

// Upgrade
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'upgrade'.DS.'reinstall.php', 'upgrade', DS.'upgrade'.DS.'reinstall.php');

// DB
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.0' WHERE extension = 'com_banners'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.0' WHERE extension = 'com_contact'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.0' WHERE extension = 'com_content'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.0' WHERE extension = 'com_mailto'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.0' WHERE extension = 'com_newsfeeds'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.0' WHERE extension = 'com_poll'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.0' WHERE extension = 'com_search'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.0' WHERE extension = 'com_user'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.0' WHERE extension = 'com_weblinks'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.0' WHERE extension = 'com_wrapper'");
$this->_addSQL("ALTER TABLE `#__acesef_urls` ADD COLUMN `source` text NOT NULL DEFAULT '' AFTER `date`");
$this->_addSQL("ALTER TABLE `#__acesef_urls` ADD COLUMN `sm_indexed` varchar(3) NOT NULL DEFAULT '' AFTER `source`");
$this->_addSQL("ALTER TABLE `#__acesef_urls` ADD COLUMN `sm_date` date NOT NULL DEFAULT '0000-00-00' AFTER `sm_indexed`");
$this->_addSQL("ALTER TABLE `#__acesef_urls` ADD COLUMN `sm_freq` varchar(30) NOT NULL DEFAULT '' AFTER `sm_date`");
$this->_addSQL("ALTER TABLE `#__acesef_urls` ADD COLUMN `sm_priority` varchar(30) NOT NULL DEFAULT '' AFTER `sm_freq`");

// Submenus
$db =& JFactory::getDBO();
$db->setQuery("SELECT `id` FROM `#__components` WHERE `admin_menu_link` = 'option=com_acesef' LIMIT 1");
$menuid = $db->loadResult();
if($menuid) {
	$this->_addSQL("DELETE FROM #__components WHERE parent = {$menuid}");
    $this->_addSQL("INSERT INTO `#__components`(`name`, `link`, `parent`, `admin_menu_link`, `admin_menu_alt`, `option`, `ordering`, `admin_menu_img`, `params`, `enabled`) VALUES ".
                   " ('Control Panel',       '', '{$menuid}', 'option=com_acesef',                                				'Control Panel',       '',     '0', 	'components/com_acesef/assets/images/acesef.png',					'', '1')".
                   ",('Configuration',       '', '{$menuid}', 'option=com_acesef&controller=config&task=edit',    				'Configuration',       '',     '1', 	'components/com_acesef/assets/images/icon-16-configuration.png',	'', '1')".
                   ",('Extensions',          '', '{$menuid}', 'option=com_acesef&controller=extensions&task=view',       		'Extensions',          '',     '2', 	'components/com_acesef/assets/images/icon-16-extensions.png',		'', '1')".
                   ",('SEF URLs',            '', '{$menuid}', 'option=com_acesef&controller=sefurls&task=view',  				'SEF URLs',            '',     '3', 	'components/com_acesef/assets/images/icon-16-url-sef.png',			'', '1')".
                   ",('Meta Manager',        '', '{$menuid}', 'option=com_acesef&controller=metamanager&task=view',  			'Meta Manager',        '',     '4', 	'components/com_acesef/assets/images/icon-16-metamanager.png',		'', '1')".
                   ",('Sitemap (XML)',       '', '{$menuid}', 'option=com_acesef&controller=sitemap&task=view',  				'Sitemap (XML)',       '',     '5', 	'components/com_acesef/assets/images/icon-16-sitemap.png',			'', '1')".
                   ",('Moved URLs',          '', '{$menuid}', 'option=com_acesef&controller=movedurls&task=view',     			'Moved URLs',          '',     '6', 	'components/com_acesef/assets/images/icon-16-url-moved.png',		'', '1')".
                   ",('Import / Migrate',    '', '{$menuid}', 'option=com_acesef&controller=import&task=view',    				'Import / Migrate',    '',     '7', 	'components/com_acesef/assets/images/icon-16-import.png',			'', '1')".
                   ",('Upgrade',             '', '{$menuid}', 'option=com_acesef&controller=upgrade&task=view',  				'Upgrade',             '',     '8', 	'components/com_acesef/assets/images/icon-16-upgrade.png',			'', '1')".
                   ",('Support',             '', '{$menuid}', 'option=com_acesef&controller=support&task=support',       		'Support',             '',     '9',		'components/com_acesef/assets/images/icon-16-support.png',			'', '1')"
                    );
}
?>