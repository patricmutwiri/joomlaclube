<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('JPATH_BASE') or die('Restricted Access');

class Tableacesef_urls extends JTable {
	var $id 	 		= null;
	var $url_sef 		= null;
	var $url_real 		= null;
	var $metatitle		= null;
	var $metadesc		= null;
	var $metakey		= null;
	var $metalang		= null;
	var $metarobots		= null;
	var $metagoogle		= null;
	var $linkcanonical	= null;
	var $published		= null;
	var $used			= null;
	var $locked 		= null;
	var $blocked		= null;
	var $notes			= null;
	var $sef_tmp_url	= null;
	var $checked_out	= null;
	var $date			= null;
	var $source			= null;
	var $sm_indexed		= null;
	var $sm_date		= null;
	var $sm_freq		= null;
	var $sm_priority	= null;

	function Tableacesef_urls (&$db) {
		parent::__construct('#__acesef_urls', 'id', $db);
	}
}