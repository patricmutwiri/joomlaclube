<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport('joomla.application.component.view');

// Edit Extension View Class
class AcesefViewExtensions extends JView {

	// Edit extension
	function edit ($tpl = NULL) {
		
		$this->_layout = 'edit';
		$row 		= & $this->get('Editdata');
		$params 	= $row->params;
		$info		= & $this->get('Info');
		
		// Import CSS
  		$document =& JFactory::getDocument();
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set Toolbar
		JToolBarHelper::title(JText::_('ACESEF_EXTENSIONS_EDIT_TITLE').' '.$row->name, 'acesef');
		$bar =& JToolBar::getInstance();
		JToolBarHelper::custom('edit_save', 'save1.png', 'save1.png', JTEXT::_('Save'), false);
		JToolBarHelper::custom('edit_apply', 'approve.png', 'approve.png', JTEXT::_('Apply'), false);
		JToolBarHelper::custom('edit_cancel', 'cancel1.png', 'cancel1.png', JTEXT::_('Cancel'), false);
		JToolBarHelper::divider();
		$bar->appendButton('Confirm', JText::_('ACESEF_EXTENSIONS_EDIT_WARNING_SAVE'), 'save1', JText::_('ACESEF_CONFIG_SAVE_PURGE'), 'edit_savepurge', false, false);
		$bar->appendButton('Confirm', JText::_('ACESEF_EXTENSIONS_EDIT_WARNING_SAVE'), 'approve', JText::_('ACESEF_CONFIG_APPLY_PURGE'), 'edit_applypurge', false, false);

		
		$this->assignRef('row', 		$row);
		$this->assignRef('lists',		$lists);
		$this->assignRef('params',		$params);
		$this->assignRef('info',		$info);

		$this->_layout = 'extension';

		parent::display($tpl);
	}
}
?>