<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Imports
jimport('joomla.application.component.view');
include_once(JPATH_ROOT.DS.'libraries'.DS.'joomla'.DS.'html'.DS.'html'.DS.'select.php');

// View Class
class AcesefViewMetamanager extends JView {

	// View URLs
	function view($tpl = null) {
		global $mainframe, $option;
		
		// Get data from the model
		$items		= & $this->get('Data');
		$total		= & $this->get('Total');
		$pagination = & $this->get('Pagination');
		
		// Import CSS
  		$document =& JFactory::getDocument();
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set Toolbar
		JToolBarHelper::title(JText::_('ACESEF_META_MANAGER' ), 'acesef');
		JToolBarHelper::custom('save', 'save1.png', 'save1.png', JText::_('Save'), false);
		JToolBarHelper::custom('apply', 'approve.png', 'approve.png', JTEXT::_('Apply'), false);
		JToolBarHelper::custom('cancel', 'cancel1.png', 'cancel1.png', JTEXT::_('Cancel'), false);
		JToolBarHelper::divider();
		JToolBarHelper::custom('exportSelected', 'exportselected.png', 'exportselected.png', JText::_('ACESEF_URL_SEF_TOOLBAR_EXPORT_SELECTED'), true);
		JToolBarHelper::custom('exportFiltered', 'exportfiltered.png', 'exportfiltered.png', JText::_('ACESEF_URL_SEF_TOOLBAR_EXPORT_FILTERED'), false);
		
		// Get filters
        $search_sef			= $mainframe->getUserStateFromRequest($option.'.metamanager.search_sef', 		'search_sef', 		'');
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_order',		'filter_order',		'url_sef');
		$filter_order_Dir	= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_order_Dir',	'filter_order_Dir',	'ASC');
        $filter_component	= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_component', 	'filter_component', '');
		$filter_used		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_used',		'filter_used',		'-1');
		$filter_locked		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_locked', 	'filter_locked',	'-1');
		$filter_all			= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_all',		'filter_all',		'-1');
		$filter_title		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_title',		'filter_title',		'-1');
		$filter_desc		= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_desc',		'filter_desc',		'-1');
		$filter_key			= $mainframe->getUserStateFromRequest($option.'.metamanager.filter_key',		'filter_key',		'-1');
		$search_sef			= JString::strtolower($search_sef);

		// Filter's action
		$javascript 	= 'onchange="document.adminForm.submit();"';
		
		// Make the input box for SEF URL search
        $lists['search_sef'] = "<input type=\"text\" name=\"search_sef\" value=\"{$search_sef}\" size=\"70\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";

		// Table ordering
		$lists['order_dir'] = $filter_order_Dir;
		$lists['order'] 	= $filter_order;
		
		// Component List
        $component_list[] = JHTMLSelect::Option('', JText::_('ACESEF_URL_SEF_SELECT_ALL_COM'));
		$this->db =& JFactory::getDBO();
		$filter = "'com_sef', 'com_sh404sef', 'com_acesef', 'com_joomfish', 'com_config', 'com_media', 'com_installer', 'com_templates', 'com_plugins', 'com_modules', 'com_cpanel', 'com_cache', 'com_messages', 'com_menus', 'com_massmail', 'com_languages', 'com_users'";
		$this->db->setQuery("SELECT `name`, `option` FROM `#__components` WHERE `parent` = '0' AND `option` != '' AND `option` NOT IN (".$filter.") ORDER BY `name`");
        $rows = $this->db->loadObjectList();
        if ($this->db->getErrorNum()) {
            echo $this->db->stderr();
            return false;
        }
        foreach(array_keys($rows) as $i) {
            $row = &$rows[$i];
            $component_list[] = JHTMLSelect::Option($row->option, $row->name);
        }
        $lists['component_list'] = JHTMLSelect::genericlist($component_list, 'filter_component', "class=\"inputbox\" onchange=\"document.adminForm.submit();\" size=\"1\"", 'value', 'text', $filter_component);
	
   	   	// Used Filter
		$used_list[] = JHTMLSelect::Option('-1', JTEXT::_('ACESEF_URL_SEF_SELECT_USED'));
		$used_list[] = JHTMLSelect::Option('10', JTEXT::_('ACESEF_URL_SEF_SELECT_USED_YES'));
		$used_list[] = JHTMLSelect::Option('0', JTEXT::_('ACESEF_URL_SEF_SELECT_USED_NO'));
   	   	$lists['used_list'] = JHTMLSelect::genericlist($used_list, 'filter_used', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_used);
		
		// Locked Filter
		$locked_list[] = JHTMLSelect::Option('-1', JTEXT::_('ACESEF_URL_SEF_SELECT_LOCKED'));
		$locked_list[] = JHTMLSelect::Option('1', JTEXT::_('ACESEF_URL_SEF_SELECT_LOCKED_YES'));
		$locked_list[] = JHTMLSelect::Option('0', JTEXT::_('ACESEF_URL_SEF_SELECT_LOCKED_NO'));
   	   	$lists['locked_list'] = JHTMLSelect::genericlist($locked_list, 'filter_locked', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_locked);
		
		// Empty fields Filter
		$all_list[] = JHTMLSelect::Option('-1', JTEXT::_('ACESEF_META_MANAGER_SELECT_ALL'));
		$all_list[] = JHTMLSelect::Option('1', JTEXT::_('ACESEF_META_MANAGER_SELECT_ALL_EMPTY'));
		$all_list[] = JHTMLSelect::Option('2', JTEXT::_('ACESEF_META_MANAGER_SELECT_ALL_FULL'));
   	   	$lists['all_list'] = JHTMLSelect::genericlist($all_list, 'filter_all', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_all);
		
		// Title Filter
		$title_list[] = JHTMLSelect::Option('-1', JTEXT::_('ACESEF_META_MANAGER_SELECT_TITLE'));
		$title_list[] = JHTMLSelect::Option('1', JTEXT::_('ACESEF_META_MANAGER_SELECT_TITLE_EMPTY'));
		$title_list[] = JHTMLSelect::Option('2', JTEXT::_('ACESEF_META_MANAGER_SELECT_TITLE_FULL'));
   	   	$lists['title_list'] = JHTMLSelect::genericlist($title_list, 'filter_title', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_title);
		
		// Description Filter
		$desc_list[] = JHTMLSelect::Option('-1', JTEXT::_('ACESEF_META_MANAGER_SELECT_DESC'));
		$desc_list[] = JHTMLSelect::Option('1', JTEXT::_('ACESEF_META_MANAGER_SELECT_DESC_ALL'));
		$desc_list[] = JHTMLSelect::Option('2', JTEXT::_('ACESEF_META_MANAGER_SELECT_DESC_FULL'));
   	   	$lists['desc_list'] = JHTMLSelect::genericlist($desc_list, 'filter_desc', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_desc);
		
		// Description Filter
		$key_list[] = JHTMLSelect::Option('-1', JTEXT::_('ACESEF_META_MANAGER_SELECT_KEY'));
		$key_list[] = JHTMLSelect::Option('1', JTEXT::_('ACESEF_META_MANAGER_SELECT_KEY_EMPTY'));
		$key_list[] = JHTMLSelect::Option('2', JTEXT::_('ACESEF_META_MANAGER_SELECT_KEY_FULL'));
   	   	$lists['key_list'] = JHTMLSelect::genericlist($key_list, 'filter_key', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_key);

		$this->assignRef('lists',		$lists);
		$this->assignRef('items',		$items);
		$this->assignRef('pagination',	$pagination);

		parent::display($tpl);
	}
}
?>