<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

?>
<form action="index.php" method="post" name="adminForm" id="adminForm">
	<table>
		<tr>
			<td nowrap="nowrap">
				<?php echo JText::_('ACESEF_URL_SEF_COMMON_URL_SEF').'<br />'.$this->lists['search_sef']; ?>
			</td>
			<td align="left" width="100%">
				&nbsp;
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['component_list']; ?>
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['used_list']; ?>
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['locked_list']; ?>
			</td>
			<td nowrap="nowrap">
				<br>
				|
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['all_list']; ?>
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['title_list']; ?>
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['desc_list']; ?>
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['key_list']; ?>
			</td>
		</tr>
	</table>
	<div id="editcell">
		<table class="adminlist">
		<thead>
			<tr>
				<th width="1%">
					<?php echo JText::_('ACESEF_COMMON_NUM'); ?>
				</th>
				<th width="1%">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
				</th>
				<th width="45%" class="title">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_META_MANAGER_URL_SEF'), 'url_sef', $this->lists['order_dir'], $this->lists['order']); ?>
				</th>
				<th width="15%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_META_MANAGER_TITLE'), 'metatitle', $this->lists['order_dir'], $this->lists['order']); ?>
				</th>
				<th width="15%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_META_MANAGER_DESCRIPTION'), 'metadesc', $this->lists['order_dir'], $this->lists['order']); ?>
				</th>
				<th width="15%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_META_MANAGER_KEYWORDS'), 'metakey', $this->lists['order_dir'], $this->lists['order']); ?>
				</th>
				<th width="1%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', 'ID', 'id', $this->lists['order_dir'], $this->lists['order']); ?>
				</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="8">
					<?php echo $this->pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
		<tbody>
		<?php
		$k = 0;
		for ($i=0, $n=count($this->items); $i < $n; $i++) {
			$row		= &$this->items[$i];
			$checked 	= JHTML::_('grid.checkedout', $row, $i);
			
			?>
			<tr class="<?php echo "row$k"; ?>">
				<td>
					<?php echo $this->pagination->getRowOffset($i); ?>
				</td>
				<td>
					<?php echo $checked; ?>
				</td>
				<td>
					<a href="../<?php echo $row->url_sef; ?>" title="<?php echo JText::_('ACESEF_URL_SEF_TOOLTIP_SEF_URL'); ?>" target="_blank">
					<?php echo substr($row->url_sef, 0, 173); ?></a>
					<input type="hidden" name="id[<?php echo $row->id; ?>]" value="<?php echo $row->id; ?>">
				</td>
				<td align="center">
					<textarea name="metatitle[<?php echo $row->id; ?>]" cols="30" rows="5"><?php echo $row->metatitle; ?></textarea>
				</td>
				<td align="center">
					<textarea name="metadesc[<?php echo $row->id; ?>]" cols="30" rows="5"><?php echo $row->metadesc; ?></textarea>
				</td>
				<td align="center">
					<textarea name="metakey[<?php echo $row->id; ?>]" cols="30" rows="5"><?php echo $row->metakey; ?></textarea>
				</td>
				<td>
					<?php echo $row->id; ?>
				</td>
			</tr>
			<?php
			$k = 1 - $k;
		}
		?>
		</tbody>
		</table>
	</div>

	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="metamanager" />
	<input type="hidden" name="task" value="view" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_dir']; ?>" />
</form>