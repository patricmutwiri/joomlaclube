<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

// Import JPane
jimport('joomla.html.pane');
$pane =& JPane::getInstance('Tabs');
?>
<form action="index.php" method="post" name="adminForm" id="adminForm">
	<script language="Javascript">
		function submitbutton(pressbutton){
		    var form = document.adminForm;
		    if (pressbutton == 'cancel') {
		        submitform(pressbutton);
		        return;
		    }
			
			// Check if it will be Custom URL
		    if (form.custom.checked == true) {
		        form.date.value = "<?php echo date('Y-m-d'); ?>"
		    } else {
		        form.date.value = "0000-00-00"
		    }
			
			// Real URL must begin with index.php
			if (form.url_real.value.match(/^index.php/)) {
				submitform(pressbutton);
	        } else {
	            alert("<?php echo JText::_('The Real URL must begin with index.php'); ?>");
			}
		}
	</script>
	<?php
	echo $pane->startPane('pane');
	echo $pane->startPanel(JText::_('ACESEF_URL_EDIT_TABS_MAIN'), 'main');
	?>
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_URL_EDIT_LEGEND_MAIN'); ?></legend>
		<table class="admintable">
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_SEF_COMMON_URL_SEF'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="url_sef" id="url_sef" size="100" value="<?php echo $this->row->url_sef; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_SEF_COMMON_URL_REAL'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="url_real" id="url_real" size="100" value="<?php echo $this->row->url_real; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_SEF_COMMON_PUBLISHED'); ?>
					</label>
				</td>
				<td width="80%">
					<?php echo $this->lists['published']; ?>
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_SEF_COMMON_LOCKED'); ?>
					</label>
				</td>
				<td width="80%">
					<?php echo $this->lists['locked']; ?>
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_CUSTOM'); ?>
					</label>
				</td>
				<td width="80%">
					<input type="checkbox" name="custom" value="0" checked="checked" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_ALIAS'); ?>
					</label>
				</td>
				<td width="80%">
					<textarea name="moved_alias" rows="8" cols="57" class="text_area"><?php echo $this->row->moved_alias; ?></textarea>
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_NOTES'); ?>
					</label>
				</td>
				<td width="80%">
					<textarea name="notes" rows="3" cols="57" class="text_area"><?php echo $this->row->notes; ?></textarea>
				</td>
			</tr>
		</table>
	</fieldset>
	<?php
	echo $pane->endPanel();
	echo $pane->startPanel(JText::_('ACESEF_URL_EDIT_TABS_SEO'), 'seo');
	?>
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_URL_EDIT_LEGEND_SEO'); ?></legend>
		<table class="admintable">
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METATITLE'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="metatitle" id="metatitle" size="100" value="<?php echo $this->row->metatitle; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METADESC'); ?>
					</label>
				</td>
				<td width="80%">
					<textarea name="metadesc" rows="5" cols="57" class="text_area"><?php echo $this->row->metadesc; ?></textarea>
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METAKEY'); ?>
					</label>
				</td>
				<td width="80%">
					<textarea name="metakey" rows="3" cols="57" class="text_area"><?php echo $this->row->metakey; ?></textarea>
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METALANG'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="metalang" id="metalang" size="30" value="<?php echo $this->row->metalang; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METAROBOTS'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="metarobots" id="metarobots" size="30" value="<?php echo $this->row->metarobots; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METAGOOGLEBOT'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="metagoogle" id="metagoogle" size="30" value="<?php echo $this->row->metagoogle; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_URL_EDIT_METACANONICAL'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="linkcanonical" id="linkcanonical" size="100" value="<?php echo $this->row->linkcanonical; ?>" />
				</td>
			</tr>
		</table>
	</fieldset>
	<?php
	echo $pane->endPanel();
	echo $pane->startPanel(JText::_('ACESEF_URL_EDIT_TABS_SITEMAP'), 'sitemap');
	?>
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_URL_EDIT_LEGEND_SITEMAP'); ?></legend>
		<table class="admintable">
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_SITEMAP_INDEXED'); ?>
					</label>
				</td>
				<td width="80%">
					<?php echo $this->lists['indexed']; ?>
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_SITEMAP_DATE'); ?>
					</label>
				</td>
				<td width="80%">
					<input class="inputbox" type="text" name="sm_date" id="sm_date" size="20" value="<?php echo $this->row->sm_date; ?>" />
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_SITEMAP_FREQUENCY'); ?>
					</label>
				</td>
				<td width="80%">
					<?php echo $this->lists['frequency']; ?>
				</td>
			</tr>
			<tr>
				<td width="20%" class="key">
					<label for="name">
						<?php echo JText::_('ACESEF_SITEMAP_PRIORITY'); ?>
					</label>
				</td>
				<td width="80%">
					<?php echo $this->lists['priority']; ?>
				</td>
			</tr>
		</table>
	</fieldset>
	<?php
	echo $pane->endPanel();
	echo $pane->startPanel(JText::_('ACESEF_URL_EDIT_TABS_SOURCE'), 'sitemap');
	?>
		<?php
		$source = explode('--b1--', $this->row->source);
		
		for ($i=0; $i < 3; $i++) {
			$no = $i+1;
			$line = explode('--b2--', $source[$i]);
			?>
			<fieldset class="adminform">
			<legend><?php echo JText::_('ACESEF_URL_EDIT_LEGEND_SOURCE').' '.$no; ?></legend>
				<table class="admintable">
					<tr>
						<td width="20%" class="key">
							<label for="name">
								<?php echo JText::_('ACESEF_URL_EDIT_SOURCE_FUNCTION'); ?>
							</label>
						</td>
						<td width="80%">
							<?php echo $line[0]; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" class="key">
							<label for="name">
								<?php echo JText::_('ACESEF_URL_EDIT_SOURCE_FILE'); ?>
							</label>
						</td>
						<td width="80%">
							<?php echo $line[1]; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" class="key">
							<label for="name">
								<?php echo JText::_('ACESEF_URL_EDIT_SOURCE_LINE'); ?>
							</label>
						</td>
						<td width="80%">
							<?php echo $line[2]; ?>
						</td>
					</tr>
				</table>
			</fieldset>
		<?php
		}
	echo $pane->endPanel();
	echo $pane->endPane();
	?>
	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="editurl" />
	<input type="hidden" name="task" value="edit" />
	<input type="hidden" name="moved_old" value="<?php echo $this->row->url_sef; ?>" />
	<input type="hidden" name="id" value="<?php echo $this->row->id; ?>" />
	<input type="hidden" name="date" value="<?php echo $this->row->date; ?>" />
</form>