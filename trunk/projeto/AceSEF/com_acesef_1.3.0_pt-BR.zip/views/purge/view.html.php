<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport('joomla.application.component.view');

// View Class
class AcesefViewPurge extends JView {

	// Display purge
	function display($tpl = null) {
		// Import CSS
		$document =& JFactory::getDocument();
		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Toolbar Buttons
		JToolBarHelper::title(JText::_('ACESEF_PURGE_TITLE'), 'acesef');
		JToolBarHelper::custom('back', 'home.png', 'home.png', JText::_('ACESEF_COMMON_HOME'), false);
		
		// Get data from the model
		$count = & $this->get('Count');
		if($count == 0){
		    $msg = JText::_('ACESEF_PURGE_NO_RECORDS');
		} else {
		    $msg = JText::_('ACESEF_PURGE_WARNING').' '.$count.' '.JText::_('ACESEF_PURGE_RECORDS');
		}
			
		$this->assignRef('count', $count);
		$this->assignRef('msg', $msg);

		parent::display($tpl);
	}
}
