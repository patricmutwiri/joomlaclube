<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Imports
jimport('joomla.application.component.view');
include_once(JPATH_ROOT.DS.'libraries'.DS.'joomla'.DS.'html'.DS.'html'.DS.'select.php');

// View Class
class AcesefViewSefurls extends JView {

	// View URLs
	function view($tpl = null) {
		global $mainframe, $option;
		$db =& JFactory::getDBO();
		
		// Get data from the model
		$items		= & $this->get('Data');
		$total		= & $this->get('Total');
		$pagination = & $this->get('Pagination');
		
		// Import CSS
  		$document =& JFactory::getDocument();
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set Toolbar
		JToolBarHelper::title(JText::_('ACESEF_URL_SEF_TITLE' ), 'acesef');
		$bar =& JToolBar::getInstance();
		JToolBarHelper::custom('add', 'newurl.png', 'newurl.png', JText::_('New'), false);
		JToolBarHelper::custom('edit', 'editurl.png', 'editurl.png', JText::_('Edit'), true);
		JToolBarHelper::custom('delete', 'deleteselected.png', 'deleteselected.png', JText::_('Delete'), true);
		$bar->appendButton('Confirm', JText::_('ACESEF_URL_SEF_CONFIRM_DELETE_FILTERED'), 'deletefiltered', JText::_('ACESEF_URL_SEF_TOOLBAR_DEL_FILTERED'), 'deleteFiltered', false, false);
		JToolBarHelper::divider();
		JToolBarHelper::custom('publish', 'approve.png', 'approve.png', JText::_('ACESEF_URL_SEF_TOOLBAR_PUBLISH'), true);
		JToolBarHelper::custom('used', 'use.png', 'use.png', JText::_('ACESEF_URL_SEF_TOOLBAR_USE'), true);
		JToolBarHelper::custom('lock', 'lock.png', 'lock.png', JText::_('ACESEF_URL_SEF_TOOLBAR_LOCK'), true);
		JToolBarHelper::custom('block', 'block.png', 'block.png', JText::_('ACESEF_URL_SEF_TOOLBAR_BLOCK'), true);
		JToolBarHelper::divider();
		JToolBarHelper::custom('exportSelected', 'exportselected.png', 'exportselected.png', JText::_('ACESEF_URL_SEF_TOOLBAR_EXPORT_SELECTED'), true);
		JToolBarHelper::custom('exportFiltered', 'exportfiltered.png', 'exportfiltered.png', JText::_('ACESEF_URL_SEF_TOOLBAR_EXPORT_FILTERED'), false);
		
		// Get filters
        $search_sef			= $mainframe->getUserStateFromRequest($option.'.sefurls.search_sef', 		'search_sef', 		'');
        $search_real		= $mainframe->getUserStateFromRequest($option.'.sefurls.search_real', 		'search_real', 		'');
        $search_itemid		= $mainframe->getUserStateFromRequest($option.'.sefurls.search_itemid', 	'search_itemid', 	'');
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.sefurls.filter_order',		'filter_order',		'url_sef');
		$filter_order_Dir	= $mainframe->getUserStateFromRequest($option.'.sefurls.filter_order_Dir',	'filter_order_Dir',	'ASC');
        $filter_component	= $mainframe->getUserStateFromRequest($option.'.sefurls.filter_component', 	'filter_component', '');
		$type				= $mainframe->getUserStateFromRequest($option.'.sefurls.type', 				'type', 			1);
        $filter_lang		= $mainframe->getUserStateFromRequest($option.'.sefurls.filter_lang', 		'filter_lang', 		'');
		$filter_published	= $mainframe->getUserStateFromRequest($option.'.sefurls.filter_published',	'filter_published',	'-1');
		$filter_used		= $mainframe->getUserStateFromRequest($option.'.sefurls.filter_used',		'filter_used',		'-1');
		$filter_locked		= $mainframe->getUserStateFromRequest($option.'.sefurls.filter_locked', 	'filter_locked',	'-1');
		$filter_blocked		= $mainframe->getUserStateFromRequest($option.'.sefurls.filter_blocked', 	'filter_blocked',	'-1');
		$search_sef			= JString::strtolower($search_sef);
		$search_real		= JString::strtolower($search_real);
		$search_itemid		= JString::strtolower($search_itemid);

		// Filter's action
		$javascript 	= 'onchange="document.adminForm.submit();"';
		
		// Make the input box for SEF URL search
        $lists['search_sef'] = "<input type=\"text\" name=\"search_sef\" value=\"{$search_sef}\" size=\"40\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";

		// Make the input box for Real URL search
        $lists['search_real'] = "<input type=\"text\" name=\"search_real\" value=\"{$search_real}\" size=\"40\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";
		
		// Make the input box for Itemid search
        $lists['search_itemid'] = "<input type=\"text\" name=\"search_itemid\" value=\"{$search_itemid}\" size=\"5\" maxlength=\"10\" onchange=\"document.adminForm.submit();\" />";

		// Table ordering
		$lists['order_dir'] = $filter_order_Dir;
		$lists['order'] 	= $filter_order;
		
		// Component List
        $component_list[] = JHTMLSelect::Option('', JText::_('ACESEF_URL_SEF_SELECT_ALL_COM'));
		$this->db =& JFactory::getDBO();
        $filter = "'com_sef', 'com_sh404sef', 'com_acesef', 'com_joomfish', 'com_config', 'com_media', 'com_installer', 'com_templates', 'com_plugins', 'com_modules', 'com_cpanel', 'com_cache', 'com_messages', 'com_menus', 'com_massmail', 'com_languages', 'com_users'";
		$this->db->setQuery("SELECT `name`, `option` FROM `#__components` WHERE `parent` = '0' AND `option` != '' AND `option` NOT IN (".$filter.") ORDER BY `name`");
        $rows = $this->db->loadObjectList();
        if ($this->db->getErrorNum()) {
            echo $this->db->stderr();
            return false;
        }
        foreach(array_keys($rows) as $i) {
            $row = &$rows[$i];
            $component_list[] = JHTMLSelect::Option($row->option, $row->name);
        }
        $lists['component_list'] = JHTMLSelect::genericlist($component_list, 'filter_component', "class=\"inputbox\" onchange=\"document.adminForm.submit();\" size=\"1\"", 'value', 'text', $filter_component);
		
		// Type List
		$type_list[] = JHTMLSelect::Option('1', JText::_('ACESEF_URL_SEF_SELECT_TYPE_SEF'));
		$type_list[] = JHTMLSelect::Option('3', JText::_('ACESEF_URL_SEF_SELECT_TYPE_CUSTOM'));
		$type_list[] = JHTMLSelect::Option('4', JText::_('ACESEF_URL_SEF_SELECT_TYPE_404'));
   	   	$lists['type_list'] = JHTMLSelect::genericlist($type_list, 'type', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $type);
		
		// JoomFish languages list
		$lang_list = array();
		$lang_list[] = JHTMLSelect::Option('', JText::_('ACESEF_URL_SEF_SELECT_LANGUAGE_FILTER'));
		
		// Check if languages table exists
		$tables	= $db->getTableList();
		$prefix	= $db->getPrefix();
		$langs	= $prefix."languages";
		if (in_array($langs, $tables)){
			// Get installed languages and add them to list
			$db->setQuery("SELECT `id`, `shortcode`, `name` FROM `#__languages` WHERE `active` = '1' ORDER BY `ordering`");
			$langs = $db->loadObjectList();
			if( @count(@$langs) ) {	
				foreach($langs as $lang) {
					$l = new stdClass();
					$l->code = $lang->shortcode;
					$l->name = $lang->name;
					
					// Load languages
					$lang_list[] = JHTMLSelect::Option($l->code, $l->name);
				}
			}
		}
        $lists['lang_list'] = JHTMLSelect::genericlist($lang_list, 'filter_lang', "class=\"inputbox\" onchange=\"document.adminForm.submit();\" size=\"1\"", 'value', 'text', $filter_lang);
		
		// Published Filter
		$published_list[] = JHTMLSelect::Option('-1', JText::_('ACESEF_URL_SEF_SELECT_PUBLISHED'));
		$published_list[] = JHTMLSelect::Option('1', JText::_('ACESEF_URL_SEF_SELECT_PUBLISHED_YES'));
		$published_list[] = JHTMLSelect::Option('0', JText::_('ACESEF_URL_SEF_SELECT_PUBLISHED_NO'));
   	   	$lists['published_list'] = JHTMLSelect::genericlist($published_list, 'filter_published', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_published);
		
   	   	// Used Filter
		$used_list[] = JHTMLSelect::Option('-1', JText::_('ACESEF_URL_SEF_SELECT_USED'));
		$used_list[] = JHTMLSelect::Option('10', JText::_('ACESEF_URL_SEF_SELECT_USED_YES'));
		$used_list[] = JHTMLSelect::Option('0', JText::_('ACESEF_URL_SEF_SELECT_USED_NO'));
   	   	$lists['used_list'] = JHTMLSelect::genericlist($used_list, 'filter_used', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_used);
		
		// Locked Filter
		$locked_list[] = JHTMLSelect::Option('-1', JText::_('ACESEF_URL_SEF_SELECT_LOCKED'));
		$locked_list[] = JHTMLSelect::Option('1', JText::_('ACESEF_URL_SEF_SELECT_LOCKED_YES'));
		$locked_list[] = JHTMLSelect::Option('0', JText::_('ACESEF_URL_SEF_SELECT_LOCKED_NO'));
   	   	$lists['locked_list'] = JHTMLSelect::genericlist($locked_list, 'filter_locked', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_locked);
		
		// Blocked Filter
   	   	$blocked_list[] = JHTMLSelect::Option('-1', JText::_('ACESEF_URL_SEF_SELECT_BLOCKED'));
		$blocked_list[] = JHTMLSelect::Option('1', JText::_('ACESEF_URL_SEF_SELECT_BLOCKED_YES'));
		$blocked_list[] = JHTMLSelect::Option('0', JText::_('ACESEF_URL_SEF_SELECT_BLOCKED_NO'));
   	   	$lists['blocked_list'] = JHTMLSelect::genericlist($blocked_list, 'filter_blocked', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_blocked);

		$this->assignRef('lists',		$lists);
		$this->assignRef('items',		$items);
		$this->assignRef('pagination',	$pagination);

		parent::display($tpl);
	}
}
?>