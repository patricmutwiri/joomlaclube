<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('JPATH_BASE') or die('Restricted Access');

// Import Libraries
jimport('joomla.installer.installer');
jimport('joomla.filesystem.file');

function com_uninstall() {
	global $mainframe;
	
	// Delete plugin
	$plugin_php = JPATH_PLUGINS.DS.'system'.DS.'acesef.php';
	$plugin_xml = JPATH_PLUGINS.DS.'system'.DS.'acesef.xml';
	JFile::delete($plugin_php);
	JFile::delete($plugin_xml);
	
	$db =& JFactory::getDBO();
    $db->setQuery("DELETE FROM `#__plugins` WHERE `folder` = 'system' AND `element` = 'acesef' LIMIT 1");
    $db->query();
	
	// Delete extensions adapter
	$adapter = JPATH_LIBRARIES.DS.'joomla'.DS.'installer'.DS.'adapters'.DS.'acesef_ext.php';
	if(JFile::exists($adapter))
		JFile::delete($adapter);
	
	echo '<h2>AceSEF succesfully uninstalled.</h2>';
}
?>