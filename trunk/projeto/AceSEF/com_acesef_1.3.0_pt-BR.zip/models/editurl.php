<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport('joomla.application.component.model');

// Model Class
class AcesefModelEditurl extends JModel {
	
	var $_id = NULL;
	var $_data = NULL;
	
	// Main constructer
	function __construct() {
		parent::__construct();
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		
		$this->_id = $cid[0];
	}
	
	// Get data about the URL
	function getData() {
		// Load the record
		$db =& JFactory::getDBO();
		
		if (is_numeric($this->_id)){
			$this->_data =& JTable::getInstance('acesef_urls', 'Table'); 
			$this->_data->load ($this->_id);
		} else {
			$db->setQuery("SELECT * FROM #__acesef_urls WHERE url_sef = '".$this->_id."' ORDER BY used, id");
			$this->_data = $db->loadObject();
		}
	
		return $this->_data;
	}
	
	// Save URL changes
	function save($id = 0) {
		$db =& JFactory::getDBO();
		$row =& JTable::getInstance('acesef_urls', 'Table'); 
		$post = JRequest::get('post');
		
		// Bind the form fields to the table
		if (!$row->bind($post)) {
			return JError::raiseWarning(500, $row->getError());
		}

		// Make sure the record is valid
		if (!$row->check()) {
			return JError::raiseWarning(500, $row->getError());
		}
		
		// Save the changes
		if (!$row->store()) {
			return JError::raiseWarning(500, $row->getError());
		}
		
		// Moved(alias) URLs
		$moved_alias = JRequest::getVar('moved_alias');
		if (!empty($moved_alias)) {
			$url_sef = JRequest::getVar('url_sef');
			
			// First delete all records
			$db->setQuery("DELETE FROM #__acesef_urls_moved WHERE url_new ='".$url_sef."'");
			$db->query();
			
			// Records the new entries
			$urls = explode("\n", trim($moved_alias));
			foreach ($urls as $url_old) {
				if (!empty($url_old)) {
					$row =& JTable::getInstance('acesef_urls_moved', 'Table');
					$row->url_old = $url_old;
					$row->url_new = $url_sef;
					
					// Make sure the record is valid
					if (!$row->check()) {
						return JError::raiseWarning(500, $row->getError());
					}
		
					// Save the changes
					if (!$row->store()) {
						return JError::raiseWarning(500, $row->getError());
					}
				}
			}
		}
		
		return true;
	}
	
	// Save & Moved
	function savemoved($id = 0) {
		$db =& JFactory::getDBO();
		
		// Save SEF URL
		$row =& JTable::getInstance('acesef_urls', 'Table');
		$post = JRequest::get('post');
		
		// Bind the form fields to the table
		if (!$row->bind($post)) {
			return JError::raiseWarning(500, $row->getError());
		}

		// Make sure the record is valid
		if (!$row->check()) {
			return JError::raiseWarning(500, $row->getError());
		}
		
		// Save the changes
		if (!$row->store()) {
			return JError::raiseWarning(500, $row->getError());
		}
		
		//
		// Moved URL
		//
		$row =& JTable::getInstance('acesef_urls_moved', 'Table'); 
        $row->url_old = JRequest::getVar('moved_old');
        $row->url_new = JRequest::getVar('url_sef');
		
		// Make sure the record is valid
		if (!$row->check()) {
			return JError::raiseWarning(500, $row->getError());
		}
		
		// Save the changes
		if (!$row->store()) {
			return JError::raiseWarning(500, $row->getError());
		}
			
		return true;
	}
}
?>