<?php
/*
* @package		AceSEF
* @subpackage	User
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_user extends AceSEFTools {
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();
		
		if (isset($activation) || isset($return)) {
			$title[] = 'dosef_false';
			return $title;
		}

		if (isset($view)) {
			$title[] = $view;
		}
		
		if (isset($task)) {
			switch($task) {
				case 'completereset':
				case 'requestreset':
				case 'remindusername':
				case 'confirmreset':
					$title[] = 'dosef_false';
					break;
				default:
					$title[] = $task;
					break;
			}
		}

		return $title;
	}
}
?>