<?php
/**
* @package		AceSEF
* @subpackage	Mailto
* @copyright	2009 JoomAce LLC, www.joomce.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_mailto extends AceSEFTools {
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();

		$host = "";
		if (isset($_SERVER['HTTP_HOST'])) {
			$host = $_SERVER['HTTP_HOST'];
		}
		
		if(isset($link)){
			// Limit the string length with a substr of 25 this because the standard joomla string is sometimes more then 255 chars..
			$link =  str_replace('http://', '', base64_decode($link));
			$link =  str_replace($host, '', $link);
			if (substr($link,0,1) == '/') {
				$link = substr($link, 1, strlen($link)-1);
			}
			$title[] = rtrim($link,'/');
		}
		
		return $title;
	}
}
?>