<?php
/*
* @package		AceSEF
* @subpackage	Web Links
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_weblinks extends AceSEFTools {

	var $title_cat;
	var $title_item;
	var $desc_cat;
	
	function getCategoryTitle($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT title, alias, description$joomfish FROM #__categories WHERE id =".$id);
        $rows = $database->loadRow();
		
		$name = (($this->params->get('categoryid_inc', '1') != '1') ? $id.'-' : '');
		if(AceSEFTools::urlPart($this->params->get('category_part', 'global')) == 'title'){
			$name .= $rows[0];
		} else {
			$name .= $rows[1];
		}
		
		$this->desc_cat = $rows[2];
		$this->title_cat =  $rows[0];
			
		return $name;
    }
	
	function getLinkTitle($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT title, alias$joomfish FROM #__weblinks WHERE id =".$id);
        $rows = $database->loadRow();
		
		$name = (($this->params->get('linkid_inc', '1') != '1') ? $id.'-' : '');
		if(AceSEFTools::urlPart($this->params->get('link_part', 'global')) == 'title'){
			$name .= $rows[0];
		} else {
			$name .= $rows[1];
		}
		
		$this->title_item = $rows[0];
			
		return $name;
    }
	
	function getCategoryDesc($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT description$joomfish FROM #__categories WHERE id =".$id);
        $desc = $database->loadResult();
		
		return $desc;
    }

	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();
		
		if (isset($view)){
			switch ($view){
				case 'categories': 
					$title[] = JText::_('CATEGORIES');
					break;
				case 'category': 
					if(isset($id)){
						$title[] = $this->getCategoryTitle($id);
					}
					break;
				case 'weblink':
					if(isset($catid)){
						$title[] = $this->getCategoryTitle($catid);
					}
					if(isset($id)){
						$title[] = $this->getLinkTitle($id);
					} else {
						$title[] = JText::_('Submit');
					}
					break;
			}
		}
		
		if (isset($task)){
			$title[] = $task;
		}
		
		return $title;
	}
	
	function metaTags(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		
		$separator			= $this->params->get('separator', '-');
		$desc_length		= $this->params->get('desc_length', '250');
		$keywords_word		= $this->params->get('keywords_word', '3');
		$keywords_count		= $this->params->get('keywords_count', '15');
		$blacklist			= $this->params->get('blacklist', '');
		
		$acesef_title = $acesef_desc = $acesef_key = "";
		
		if (isset($view)){
			switch ($view){
				case 'category': 
					if(isset($id)){
						$acesef_title	= $this->title_cat;
						$acesef_desc	= AceSEFTools::clipDesc($this->desc_cat, $desc_length);
					}
					break;
				case 'weblink': 
					if(isset($catid)){
						$acesef_title = $this->title_cat;
					}
					if(isset($id)){
						$acesef_title = $this->title_item." ".$separator." ".$acesef_title;
					}
					break;
				case 'categories': 
					$acesef_title = AceSEFTools::getMenuTitle($option, $Itemid);
					break;
			}
		}
		
		$meta = AceSEFTools::setMetaData($acesef_title, $acesef_desc, $acesef_key);
	
		return $meta;
	}
}
?>