<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import JModel
jimport('joomla.application.component.model');

// Purge URLs Model Class
class AcesefModelPurge extends JModel {
	
	// Main constructer
	function __construct() {
        parent::__construct();
    }
    
	// Purge URLs
    function purge() {
    	$type = JRequest::getVar('type');
        if($this->getPurgeWhere($where) === false){
			return false;
		}
		
		$db =& JFactory::getDBO();
		
		if ($type == 5){ // Moved URLs
			$db->setQuery("DELETE FROM #__acesef_urls_moved");
		} else {
			if ($type == 2){
				$where = "WHERE ".$where;
			} else {
				if(!empty($where)){
					$where = "WHERE locked = '0' AND ".$where;
				} else {
					$where = "WHERE locked = '0'";
				}
			}
			$db->setQuery("DELETE FROM #__acesef_urls $where");
		}
        return $db->query();
    }
	
	// Purge component URLs
    function purgeComponent($component) {
        $db =& JFactory::getDBO();
		$where = "WHERE (url_real LIKE '%option=$component&%' OR url_real LIKE '%option=$component') AND locked = '0' AND date = '0000-00-00' AND url_real != ''";
        $db->setQuery("DELETE FROM #__acesef_urls $where");
        return $db->query();
    }
    
	// Count URLs
    function getCount() {
		$type = JRequest::getVar('type');
        if($this->getPurgeWhere($where) === false){
            return 0;
		}
        
        $db =& JFactory::getDBO();
		if ($type == 5){ // Moved URLs
			$db->setQuery("SELECT COUNT(*) FROM #__acesef_urls_moved");
		} else {
			$db->setQuery("SELECT COUNT(*) FROM #__acesef_urls WHERE $where");
		}
        $this->count = $db->loadResult();
        return $this->count;
    }
    
	// Purge Filter
    function getPurgeWhere(&$where) {
        $type = JRequest::getVar('type');
        if(($type >= 1) && ($type <= 5)) {
            if($type == 1){
                $where = "date = '0000-00-00' AND url_real != ''"; // SEF URLs
            } elseif($type == 2){
                $where = "locked = '1' "; // Locked URLs
            } elseif($type == 3){
                $where = "date > '0000-00-00' AND url_real != '' "; // Custom URLs
            } elseif($type == 4){
                $where = "url_real = '' "; // 404 URLs
            } elseif($type == 5){
                $where = ""; // Moved URLs
			}
        } else {
            $where = "";
		}
        
        return true;
    }
}
?>