<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport('joomla.application.component.view');

// Support View Class
class AcesefViewSupport extends JView {

	function display($tpl = null) {
	
		$document =& JFactory::getDocument();
		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		JToolBarHelper::title(JText::_('ACESEF_SUPPORT'), 'acesef');		
		JToolBarHelper::back(JText::_('Back'), 'index.php?option=com_acesef');
		
		parent::display($tpl);
	}
}