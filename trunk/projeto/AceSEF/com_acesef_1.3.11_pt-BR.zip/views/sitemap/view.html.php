<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Imports
jimport('joomla.application.component.view');

// View Class
class AcesefViewSitemap extends JView {

	// View URLs
	function view($tpl = null) {
		
		// Import CSS
  		$document =& JFactory::getDocument();
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set Toolbar
		JToolBarHelper::title(JText::_('ACESEF_CPANEL_SITEMAP' ), 'acesef');

		parent::display($tpl);
	}
}
?>