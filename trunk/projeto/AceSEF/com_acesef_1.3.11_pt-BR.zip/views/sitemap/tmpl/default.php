<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

?>
<table>
	<tr>
		<td nowrap="nowrap">
			<br/><br/><b><?php echo JText::_('ACESEF_COMMON_PRO_VERSION'); ?></b><br/><br/><br/>
		</td>
	</tr>
	<tr>
		<td width="430">
			<a href="http://www.joomace.net/e-shop/acesef" target="_blank">
			<img border="0" src="http://www.joomace.net/s-proversion.png" width="400" height="200">
			</a>
		</td>
	</tr>
</table>