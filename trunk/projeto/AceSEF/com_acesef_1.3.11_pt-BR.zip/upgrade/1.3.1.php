<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// XML
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'acesef.xml', 'upgrade', DS.'acesef.xml');

// Classes
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php', 'upgrade', DS.'classes'.DS.'aceseftools.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'mainrouter.php', 'upgrade', DS.'classes'.DS.'mainrouter.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'routertools.php', 'upgrade', DS.'classes'.DS.'routertools.php');

// Controllers
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'acesef.php', 'upgrade', DS.'controllers'.DS.'acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'extensions.php', 'upgrade', DS.'controllers'.DS.'extensions.php');

// Models
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'acesef.php', 'upgrade', DS.'models'.DS.'acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'config.php', 'upgrade', DS.'models'.DS.'config.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'editurl.php', 'upgrade', DS.'models'.DS.'editurl.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'extensions.php', 'upgrade', DS.'models'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'metamanager.php', 'upgrade', DS.'models'.DS.'metamanager.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'movedurls.php', 'upgrade', DS.'models'.DS.'movedurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'sefurls.php', 'upgrade', DS.'models'.DS.'sefurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'sitemap.php', 'upgrade', DS.'models'.DS.'sitemap.php');

// Views
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'config'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'editurl'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'metamanager'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'metamanager'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'movedurls'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'movedurls'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'translators.php', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'translators.php');

// Plugin
$this->_addFileOp(DS.'plugins'.DS.'system'.DS.'acesef.php', 'upgrade', DS.'plugin'.DS.'acesef.php');

// Extensions
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.php', 'upgrade', DS.'extensions'.DS.'com_content.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.xml', 'upgrade', DS.'extensions'.DS.'com_content.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_user.php', 'upgrade', DS.'extensions'.DS.'com_user.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_user.xml', 'upgrade', DS.'extensions'.DS.'com_user.xml');

// DB
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.4' WHERE extension = 'com_content'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.2' WHERE extension = 'com_user'");

// Language files
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'da-DK'.DS.'da-DK.com_acesef.ini', 'upgrade', DS.'languages'.DS.'da-DK'.DS.'da-DK.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'de-DE'.DS.'de-DE.com_acesef.ini', 'upgrade', DS.'languages'.DS.'de-DE'.DS.'de-DE.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'el-GR'.DS.'el-GR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'el-GR'.DS.'el-GR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.com_acesef.ini', 'upgrade', DS.'languages'.DS.'en-GB'.DS.'en-GB.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'es-ES'.DS.'es-ES.com_acesef.ini', 'upgrade', DS.'languages'.DS.'es-ES'.DS.'es-ES.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'fr-FR'.DS.'fr-FR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'fr-FR'.DS.'fr-FR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'hr-HR'.DS.'hr-HR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'hr-HR'.DS.'hr-HR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'hu-HU'.DS.'hu-HU.com_acesef.ini', 'upgrade', DS.'languages'.DS.'hu-HU'.DS.'hu-HU.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'it-IT'.DS.'it-IT.com_acesef.ini', 'upgrade', DS.'languages'.DS.'it-IT'.DS.'it-IT.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'nl-NL'.DS.'nl-NL.com_acesef.ini', 'upgrade', DS.'languages'.DS.'nl-NL'.DS.'nl-NL.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'nl-NL'.DS.'nl-NL.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'nl-NL'.DS.'nl-NL.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pl-PL'.DS.'pl-PL.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pl-PL'.DS.'pl-PL.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-BR'.DS.'pt-BR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pt-BR'.DS.'pt-BR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-PT'.DS.'pt-PT.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pt-PT'.DS.'pt-PT.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'ru-RU'.DS.'ru-RU.com_acesef.ini', 'upgrade', DS.'languages'.DS.'ru-RU'.DS.'ru-RU.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sr-RS'.DS.'sr-RS.com_acesef.ini', 'upgrade', DS.'languages'.DS.'sr-RS'.DS.'sr-RS.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sl-SI'.DS.'sl-SI.com_acesef.ini', 'upgrade', DS.'languages'.DS.'sl-SI'.DS.'sl-SI.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-CN'.DS.'zh-CN.com_acesef.ini', 'upgrade', DS.'languages'.DS.'zh-CN'.DS.'zh-CN.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-TW'.DS.'zh-TW.com_acesef.ini', 'upgrade', DS.'languages'.DS.'zh-TW'.DS.'zh-TW.com_acesef.ini');

?>