<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// XML
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'acesef.xml', 'upgrade', DS.'acesef.xml');

// Classes
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php', 'upgrade', DS.'classes'.DS.'aceseftools.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'mainrouter.php', 'upgrade', DS.'classes'.DS.'mainrouter.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'routertools.php', 'upgrade', DS.'classes'.DS.'routertools.php');

// Controllers
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'acesef.php', 'upgrade', DS.'controllers'.DS.'acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'extensions.php', 'upgrade', DS.'controllers'.DS.'extensions.php');

// Models
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'acesef.php', 'upgrade', DS.'models'.DS.'acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'editurl.php', 'upgrade', DS.'models'.DS.'editurl.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'extensions.php', 'upgrade', DS.'models'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'metamanager.php', 'upgrade', DS.'models'.DS.'metamanager.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'sefurls.php', 'upgrade', DS.'models'.DS.'sefurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'sitemap.php', 'upgrade', DS.'models'.DS.'sitemap.php');

// Views
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'movedurls'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'movedurls'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'translators.php', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'translators.php');

// Plugin
$this->_addFileOp(DS.'plugins'.DS.'system'.DS.'acesef.php', 'upgrade', DS.'plugin'.DS.'acesef.php');

// Extensions
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.php', 'upgrade', DS.'extensions'.DS.'com_content.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.xml', 'upgrade', DS.'extensions'.DS.'com_content.xml');

// DB
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.3.4' WHERE extension = 'com_content'");

// Languages
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'nl-NL'.DS.'nl-NL.com_acesef.ini', 'upgrade', DS.'languages'.DS.'nl-NL'.DS.'nl-NL.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'nl-NL'.DS.'nl-NL.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'nl-NL'.DS.'nl-NL.com_acesef.menu.ini');

?>