<?php
/**
* @version		1.3.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU AGPL
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// AceSEF extension installation adapater
class JInstallerAcesef_Ext extends JObject {

	function __construct(&$parent) {
		$this->parent =& $parent;
	}

	function install() {
		$manifest =& $this->parent->getManifest();
		$this->manifest =& $manifest->document;
		$root =& $manifest->document;
		
		$name 			=& $root->getElementByPath('name');
		$author 		=& $root->getElementByPath('author');
		$authorUrl 		=& $root->getElementByPath('authorurl');
		$version 		=& $root->getElementByPath('version');
		$description	=& $root->getElementByPath('description');
		$extension		=& $root->getElementByPath('extension');
		$params			=& $root->getElementByPath('params');
		$name 			= $name->data();
		$author 		= $author->data();
		$authorUrl 		= $authorUrl->data();
		$version		= $version->data();
		$description 	= $description->data();
		$extension		= $extension->data();
		$params			= $this->parent->getParams($params);
		$router_type 	= '3';
		
		// Check if there is any router.php file
		$router = JPATH_SITE.DS.'components'.DS.$extension.DS.'router.php';
		if(file_exists($router)){
			$router_type = '4';
		}

		// Set the installation path
		$this->parent->setPath('extension_site', JPATH_SITE.DS."administrator".DS."components".DS."com_acesef".DS."extensions");

		$element =& $root->getElementByPath('files');
		$this->parent->parseQueries($this->manifest->getElementByPath('queries'));
		
		// Install the files
		if ($this->parent->parseFiles($element) === false) {
			// Install failed, rollback changes
			$this->parent->abort();
			return false;
		} else {
			
			// Make some updates after installation
			$db =& JFactory::getDBO();
			
			// Check if extension exists and upgrade is performed
			$db->setQuery("SELECT name, router_type FROM `#__acesef_extensions` WHERE `extension` = '".$extension."'");
			$current = $db->loadObject();
			
			// Check if the component is installed
			if(!is_null($current)) {
				// Just update the version
				if($current->name != '') {
					$db->setQuery("UPDATE #__acesef_extensions SET version = '".$version."' WHERE `extension` = '".$extension."'");
				} else {
					// Install a new extension while the component has been installed
					$db->setQuery("UPDATE #__acesef_extensions SET name = '".$name."', description = '".$description."', version = '".$version."', author = '".$author."', author_url = '".$authorUrl."', params = '".$params."', router_type = '".$router_type."', rewrite_rule = '3' WHERE `extension` = '".$extension."'");
				}
				$db->query();
			} else {
				JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'tables');
				$extension_record =& JTable::getInstance('acesef_extensions', 'Table');
				$extension_record->name 			= $name;
				$extension_record->author			= $author;
				$extension_record->author_url		= $authorUrl;
				$extension_record->version			= $version;
				$extension_record->description		= $description;
				$extension_record->extension 		= $extension;
				$extension_record->params 			= $params;
				$extension_record->router_type 		= $router_type;
				$extension_record->rewrite_rule		= '3';
				$extension_record->component_prefix	= '';
				$extension_record->skip_title		= '0';
				$extension_record->store();
				
				// Remove already created URLs for this extension from database
				$db->setQuery("DELETE FROM `#__acesef_urls` WHERE (`url_real` LIKE '%option=".$extension."&%' OR `url_real` LIKE '%option=".$extension."') AND locked = '0'");
				$db->query();
			}
			return true;
		}
		
		}
}
?>