<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('JPATH_BASE') or die('Restricted Access');

// Import Libraries
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

class Tableacesef_extensions extends JTable {
	var $id 	 			= null;
	var $name				= null;
	var $description		= null;
	var $version			= null;
	var $author				= null;
	var $author_url			= null;
	var $params				= null;
	var $extension			= null;
	var $router_type		= null;
	var $rewrite_rule		= null;
	var $component_prefix	= null;
	var $skip_title			= null;
	var $checked_out		= null;

	function Tableacesef_extensions (& $db) {
		parent::__construct('#__acesef_extensions', 'id', $db);
	}

	function delete($id, $extension_name){
		$k = $this->_tbl_key;
		if ($id) {
			$this->$k = intval($id);
		}

		if (parent::delete($id)) {
			// Make some updates after uninstall
			$db =& JFactory::getDBO();
			
			// Remove already created URLs for this extension from database
			$db->setQuery("DELETE FROM `#__acesef_urls` WHERE (`url_real` LIKE '%option=$extension_name&%' OR `url_real` LIKE '%option=$extension_name') AND locked = 0");
			$db->query();
			
			// Set rewrite rule as extension
			$router = JPATH_SITE.DS.'components'.DS.$extension_name.DS.'router.php';
			if(file_exists($router))
				$db->setQuery("UPDATE #__acesef_extensions SET router_type = '2', rewrite_rule = '2' WHERE extension = '".$extension_name."'");
			else
				$db->setQuery("UPDATE #__acesef_extensions SET router_type = '1', rewrite_rule = '1' WHERE extension = '".$extension_name."'");
			$db->query();
			
			// Remove the extension files
			$ext = JPATH_SITE.DS."administrator".DS."components".DS."com_acesef".DS."extensions".DS.$extension_name.'.php';
			if(file_exists($ext)){
				JFile::delete(JPATH_SITE.DS."administrator".DS."components".DS."com_acesef".DS."extensions".DS.$extension_name.'.xml');
				JFile::delete(JPATH_SITE.DS."administrator".DS."components".DS."com_acesef".DS."extensions".DS.$extension_name.'.php');
			}
		}

	}
	function bind($array) {
		if (is_array($array['params'])) {
			$registry = new JRegistry();
			$registry->loadArray($array['params']);
			$array['params'] = $registry->toString();
		}
		return parent::bind($array);
	}
}