<?php
/*
* @package		AceSEF
* @subpackage	Web Links
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_weblinks extends AceSEFTools {

	var $params;
	var $title_cat;
	var $title_item;
	var $desc_cat;
	
	function getCategoryTitle($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT title, alias, description$joomfish FROM #__categories WHERE id =".$id);
        $rows = $database->loadRow();
		
		$name = (($this->params->get('categoryid_inc', '1') != '1') ? $id.'-' : '');
		if(AceSEFTools::urlPart($this->params->get('category_part', 'global')) == 'title')
			$name .= $rows[0];
		else
			$name .= $rows[1];
		
		$this->desc_cat = $rows[2];
		$this->title_cat =  $rows[0];
			
		return $name;
    }
	
	function getLinkTitle($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT title, alias$joomfish FROM #__weblinks WHERE id =".$id);
        $rows = $database->loadRow();
		
		$name = (($this->params->get('linkid_inc', '1') != '1') ? $id.'-' : '');
		if(AceSEFTools::urlPart($this->params->get('link_part', 'global')) == 'title')
			$name .= $rows[0];
		else
			$name .= $rows[1];
		
		$this->title_item = $rows[0];
			
		return $name;
    }
	
	function getCategoryDesc($id) {
		$joomfish = $this->acesef_config->joomfish_trans_url ? ', id' : '';
		
        $database =& JFactory::getDBO();
        $database->setQuery("SELECT description$joomfish FROM #__categories WHERE id =".$id);
        $desc = $database->loadResult();
			
		return $desc;
    }

	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();

        $this->params = AceSEFTools::getExtParams('com_weblinks');
		
		if (isset($view)){
			switch ($view){
				case 'categories': 
					$title[] = JText::_('CATEGORIES');
					break;
				case 'category': 
					if(isset($id))
						$title[] = $this->getCategoryTitle($id);
					break;
				case 'weblink':
					if(isset($catid))
						$title[] = $this->getCategoryTitle($catid);
					if(isset($id))
						$title[] = $this->getLinkTitle($id);
					else
						$title[] = JText::_('Submit');
					break;
			}
		}
		
		if (isset($task))
			$title[] = $task;
		
		return $title;
	}
	
	function metaTags(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$meta = array();

		$config =& JFactory::getConfig();
		
		$enable_title		= AceSEFTools::autoTitle($this->params->get('enable_title', 'global'));
		$enable_desc		= AceSEFTools::autoDesc($this->params->get('enable_desc', 'global'));
		$enable_key			= AceSEFTools::autoKey($this->params->get('enable_key', 'global'));
		$separator			= $this->params->get('separator', '-');
		$sitename			= $config->getValue('sitename');
		$custom_sitename	= $this->params->get('custom_sitename', '');
		$use_sitename		= $this->params->get('use_sitename', '2');
		$title_prefix		= $this->params->get('title_prefix', '');
		$title_suffix		= $this->params->get('title_suffix', '');
		$desc_length		= $this->params->get('desc_length', '250');
		$keywords_word		= $this->params->get('keywords_word', '3');
		$keywords_count		= $this->params->get('keywords_count', '15');
		$blacklist			= $this->params->get('blacklist', '');
		
		$title = $desc = "";
		
		if (isset($view)){
			switch ($view){
				case 'category': 
					if(isset($id)){
						$title	= $this->title_cat;
						$desc	= AceSEFTools::cleanText($this->desc_cat);
					}
					break;
				case 'weblink': 
					if(isset($catid))
						$title	= $this->title_cat;
					if(isset($id))
						$title	= $this->title_item." ".$separator." ".$title;
					break;
				case 'categories': 
					$title = AceSEFTools::getMenuTitle($option, $Itemid);
					break;
			}
		}
		
		// Set meta tags
		if($enable_title && !empty($title)){
			// Prepare meta title			
			if(!empty($custom_sitename))
				$sitename = $custom_sitename;
			
			if($use_sitename == 1)
				$title = $sitename." ".$separator." ".$title;
			elseif ($use_sitename == 2)
				$title = $title." ".$separator." ".$sitename;
				
			if(!empty($title_prefix))
				$title = $title_prefix." ".$separator." ".$title;
				
			if(!empty($title_suffix))
				$title = $title." ".$separator." ".$title_suffix;
			
			$meta['metatitle']	= $title;
		}
	
		if($enable_desc && !empty($desc))
			$meta['metadesc']	= AceSEFTools::clipDesc($desc, $desc_length);
		if($enable_key && !empty($desc))
			$meta['metakey']	= AceSEFTools::generateKeywords($desc, $blacklist, $keywords_count, $keywords_word);
	
		return $meta;
	}
}
?>