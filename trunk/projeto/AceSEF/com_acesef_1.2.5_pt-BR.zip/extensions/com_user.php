<?php
/*
* @package		AceSEF
* @subpackage	User
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSEF_com_user extends AceSEFTools {
	
	var $params;
	
	function buildRoute(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$title = array();
		
		$this->params = AceSEFTools::getExtParams('com_user');

		if(isset($view))
			$title[] = $view;
		
		if(isset($task))
			$title[] = $task;

		return $title;
	}
	
	function metaTags(&$uri) {
		$vars = $uri->getQuery(true);
        extract($vars);
		$meta = array();

		$config =& JFactory::getConfig();
		
		$enable_title		= AceSEFTools::autoTitle($this->params->get('enable_title', 'global'));
		$separator			= $this->params->get('separator', '-');
		$sitename			= $config->getValue('sitename');
		$custom_sitename	= $this->params->get('custom_sitename', '');
		$use_sitename		= $this->params->get('use_sitename', '2');
		$title_prefix		= $this->params->get('title_prefix', '');
		$title_suffix		= $this->params->get('title_suffix', '');
		
		$title = "";
		
		if($enable_title){
			if (isset($view)){
				switch ($view){
					case 'register': 
						$title = JText::_('Register');
						break;
					case 'remind': 
						$title = JText::_('Forgot your Username?');
						break;
					case 'reset': 
						$title = JText::_('Forgot your Password?');
						break;
				}
			} else
				$title = JText::_('REGISTERED AREA');
			
			// Prepare meta title			
			if(!empty($custom_sitename))
				$sitename = $custom_sitename;
			
			if($use_sitename == 1)
				$title = $sitename." ".$separator." ".$title;
			elseif ($use_sitename == 2)
				$title = $title." ".$separator." ".$sitename;
				
			if(!empty($title_prefix))
				$title = $title_prefix." ".$separator." ".$title;
				
			if(!empty($title_suffix))
				$title = $title." ".$separator." ".$title_suffix;
			
			// Set meta tags	
			if(!empty($title))	$meta['metatitle']	= $title;			
		}
		
		return $meta;
	}
}
?>