<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// XML
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'acesef.xml', 'upgrade', DS.'acesef.xml');

// Classes
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php', 'upgrade', DS.'classes'.DS.'aceseftools.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'mainrouter.php', 'upgrade', DS.'classes'.DS.'mainrouter.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'routertools.php', 'upgrade', DS.'classes'.DS.'routertools.php');

// Assets
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'assets'.DS.'images'.DS.'cp-translators.png', 'upgrade', DS.'assets'.DS.'images'.DS.'cp-translators.png');


// Adapters
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'adapters'.DS.'acesef_ext.php', 'upgrade', DS.'adapters'.DS.'acesef_ext.php');
$this->_addFileOp(DS.'libraries'.DS.'joomla'.DS.'installer'.DS.'adapters'.DS.'acesef_ext.php', 'upgrade', DS.'adapters'.DS.'acesef_ext.php');

// Admin
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'configuration.php', 'upgrade', DS.'configuration.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'toolbar.acesef.php', 'upgrade', DS.'toolbar.acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'uninstall.sql', 'upgrade', DS.'uninstall.sql');

// Controllers
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'editurl.php', 'upgrade', DS.'controllers'.DS.'editurl.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'extensions.php', 'upgrade', DS.'controllers'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'controllers'.DS.'support.php', 'upgrade', DS.'controllers'.DS.'support.php');

// Models
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'acesef.php', 'upgrade', DS.'models'.DS.'acesef.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'config.php', 'upgrade', DS.'models'.DS.'config.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'editurl.php', 'upgrade', DS.'models'.DS.'editurl.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'extensions.php', 'upgrade', DS.'models'.DS.'extensions.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'import.php', 'upgrade', DS.'models'.DS.'import.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'movedurls.php', 'upgrade', DS.'models'.DS.'movedurls.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'models'.DS.'repository.php', 'upgrade', DS.'models'.DS.'repository.php');

// Views
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'acesef'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'acesef'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'acesef'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'config'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'config'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'editurl'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'editurl'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'editurl'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'index.html', 'upgrade', DS.'views'.DS.'extensions'.DS.'index.html');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'view.edit.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'view.edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'extension_edit.php', 'upgrade', DS.'views'.DS.'extensions'.DS.'tmpl'.DS.'extension_edit.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'movedurls'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'movedurls'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'movedurls'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'movedurls'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'repository'.DS.'view.html.php', 'upgrade', DS.'views'.DS.'repository'.DS.'view.html.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'repository'.DS.'tmpl'.DS.'default.php', 'upgrade', DS.'views'.DS.'repository'.DS.'tmpl'.DS.'default.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'changelog.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'support.php', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'support.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'views'.DS.'support'.DS.'tmpl'.DS.'translators.php', 'upgrade', DS.'views'.DS.'support'.DS.'tmpl'.DS.'translators.php');

// Extensions
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_banners.php', 'upgrade', DS.'extensions'.DS.'com_banners.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_banners.xml', 'upgrade', DS.'extensions'.DS.'com_banners.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_contact.php', 'upgrade', DS.'extensions'.DS.'com_contact.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_contact.xml', 'upgrade', DS.'extensions'.DS.'com_contact.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.php', 'upgrade', DS.'extensions'.DS.'com_content.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_content.xml', 'upgrade', DS.'extensions'.DS.'com_content.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_mailto.php', 'upgrade', DS.'extensions'.DS.'com_mailto.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_mailto.xml', 'upgrade', DS.'extensions'.DS.'com_mailto.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_newsfeeds.php', 'upgrade', DS.'extensions'.DS.'com_newsfeeds.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_newsfeeds.xml', 'upgrade', DS.'extensions'.DS.'com_newsfeeds.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_poll.php', 'upgrade', DS.'extensions'.DS.'com_poll.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_poll.xml', 'upgrade', DS.'extensions'.DS.'com_poll.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_search.php', 'upgrade', DS.'extensions'.DS.'com_search.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_search.xml', 'upgrade', DS.'extensions'.DS.'com_search.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_user.php', 'upgrade', DS.'extensions'.DS.'com_user.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_user.xml', 'upgrade', DS.'extensions'.DS.'com_user.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_weblinks.php', 'upgrade', DS.'extensions'.DS.'com_weblinks.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_weblinks.xml', 'upgrade', DS.'extensions'.DS.'com_weblinks.xml');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_wrapper.php', 'upgrade', DS.'extensions'.DS.'com_wrapper.php');
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.'com_wrapper.xml', 'upgrade', DS.'extensions'.DS.'com_wrapper.xml');

// Language files
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'da-DK'.DS.'da-DK.com_acesef.ini', 'upgrade', DS.'languages'.DS.'da-DK'.DS.'da-DK.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'da-DK'.DS.'da-DK.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'da-DK'.DS.'da-DK.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'de-DE'.DS.'de-DE.com_acesef.ini', 'upgrade', DS.'languages'.DS.'de-DE'.DS.'de-DE.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'de-DE'.DS.'de-DE.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'de-DE'.DS.'de-DE.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'el-GR'.DS.'el-GR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'el-GR'.DS.'el-GR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'el-GR'.DS.'el-GR.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'el-GR'.DS.'el-GR.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.com_acesef.ini', 'upgrade', DS.'languages'.DS.'en-GB'.DS.'en-GB.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'en-GB'.DS.'en-GB.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'en-GB'.DS.'en-GB.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'es-ES'.DS.'es-ES.com_acesef.ini', 'upgrade', DS.'languages'.DS.'es-ES'.DS.'es-ES.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'es-ES'.DS.'es-ES.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'es-ES'.DS.'es-ES.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'fr-FR'.DS.'fr-FR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'fr-FR'.DS.'fr-FR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'fr-FR'.DS.'fr-FR.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'fr-FR'.DS.'fr-FR.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'hu-HU'.DS.'hu-HU.com_acesef.ini', 'upgrade', DS.'languages'.DS.'hu-HU'.DS.'hu-HU.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'hu-HU'.DS.'hu-HU.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'hu-HU'.DS.'hu-HU.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'it-IT'.DS.'it-IT.com_acesef.ini', 'upgrade', DS.'languages'.DS.'it-IT'.DS.'it-IT.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'it-IT'.DS.'it-IT.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'it-IT'.DS.'it-IT.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pl-PL'.DS.'pl-PL.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pl-PL'.DS.'pl-PL.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pl-PL'.DS.'pl-PL.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'pl-PL'.DS.'pl-PL.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-BR'.DS.'pt-BR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pt-BR'.DS.'pt-BR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-BR'.DS.'pt-BR.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'pt-BR'.DS.'pt-BR.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-PT'.DS.'pt-PT.com_acesef.ini', 'upgrade', DS.'languages'.DS.'pt-PT'.DS.'pt-PT.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'pt-PT'.DS.'pt-PT.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'pt-PT'.DS.'pt-PT.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'ru-RU'.DS.'ru-RU.com_acesef.ini', 'upgrade', DS.'languages'.DS.'ru-RU'.DS.'ru-RU.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'ru-RU'.DS.'ru-RU.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'ru-RU'.DS.'ru-RU.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sr-RS'.DS.'sr-RS.com_acesef.ini', 'upgrade', DS.'languages'.DS.'sr-RS'.DS.'sr-RS.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sr-RS'.DS.'sr-RS.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'sr-RS'.DS.'sr-RS.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sl-SI'.DS.'sl-SI.com_acesef.ini', 'upgrade', DS.'languages'.DS.'sl-SI'.DS.'sl-SI.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'sl-SI'.DS.'sl-SI.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'sl-SI'.DS.'sl-SI.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini', 'upgrade', DS.'languages'.DS.'tr-TR'.DS.'tr-TR.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'tr-TR'.DS.'tr-TR.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'tr-TR'.DS.'tr-TR.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-CN'.DS.'zh-CN.com_acesef.ini', 'upgrade', DS.'languages'.DS.'zh-CN'.DS.'zh-CN.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-CN'.DS.'zh-CN.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'zh-CN'.DS.'zh-CN.com_acesef.menu.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-TW'.DS.'zh-TW.com_acesef.ini', 'upgrade', DS.'languages'.DS.'zh-TW'.DS.'zh-TW.com_acesef.ini');
$this->_addFileOp(DS.'administrator'.DS.'language'.DS.'zh-TW'.DS.'zh-TW.com_acesef.menu.ini', 'upgrade', DS.'languages'.DS.'zh-TW'.DS.'zh-TW.com_acesef.menu.ini');

// Plugin
$this->_addFileOp(DS.'plugins'.DS.'system'.DS.'acesef.php', 'upgrade', DS.'plugin'.DS.'acesef.php');

// Tables
$this->_addFileOp(DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_extensions.php', 'upgrade', DS.'tables'.DS.'acesef_extensions.php');

// DB changes
$this->_addSQL("ALTER TABLE `#__acesef_extensions` ADD COLUMN `router_type` tinyint(1) unsigned NOT NULL DEFAULT '0' AFTER `extension`");
$this->_addSQL("ALTER TABLE `#__acesef_extensions` ADD COLUMN `rewrite_rule` tinyint(1) unsigned NOT NULL DEFAULT '0' AFTER `router_type`");
$this->_addSQL("ALTER TABLE `#__acesef_extensions` ADD COLUMN `component_prefix` varchar(255) NOT NULL DEFAULT '' AFTER `rewrite_rule`");
$this->_addSQL("ALTER TABLE `#__acesef_extensions` ADD COLUMN `skip_title` tinyint(1) unsigned NOT NULL DEFAULT '0' AFTER `component_prefix`");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.2.2', router_type = '4', rewrite_rule = '3' WHERE extension = 'com_newsfeeds'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.2.2', router_type = '4', rewrite_rule = '3' WHERE extension = 'com_weblinks'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.2.2', router_type = '4', rewrite_rule = '3' WHERE extension = 'com_wrapper'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.2.4', router_type = '4', rewrite_rule = '3', skip_title = '1' WHERE extension = 'com_content'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.2.2', router_type = '4', rewrite_rule = '3', skip_title = '1' WHERE extension = 'com_contact'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.2.2', router_type = '4', rewrite_rule = '3', component_prefix = 'poll' WHERE extension = 'com_poll'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.2.2', router_type = '4', rewrite_rule = '3', component_prefix = 'search' WHERE extension = 'com_search'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.2.2', router_type = '4', rewrite_rule = '3', component_prefix = 'banner' WHERE extension = 'com_banners'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.2.2', router_type = '4', rewrite_rule = '3', component_prefix = 'mail' WHERE extension = 'com_mailto'");
$this->_addSQL("UPDATE #__acesef_extensions SET version = '1.2.3', router_type = '4', rewrite_rule = '3', component_prefix = 'user' WHERE extension = 'com_user'");
$this->_addSQL("DROP TABLE #__acesef_routers");
$this->_addSQL("DELETE FROM #__components WHERE admin_menu_link = 'option=com_acesef&controller=routers&task=view'");

?>