<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Imports
jimport('joomla.application.component.model');
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');
jimport('joomla.installer.helper');
require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');

// Control Panel Model Class
class AcesefModelAcesef extends JModel {
	
	// Main constructer
	function __construct() {
		parent::__construct();
		$this->acesef_config = new acesef_configuration();
	}
	
	// Upgrade
    function upgrade($package) {

        // Was the package unpacked?
        if (!$package) {
            $this->setState('message', 'Unable to find install package.');
            return false;
        }
		
		// Get current version
        $curVersion = $this->getInstalledVersion();
        if (empty($curVersion)) {
            $this->setState('message', JText::_('Could not find current version.'));
            JFolder::delete($package['dir']);
            return false;
        }

        // Create an array of upgrade files
        $upgradeDir = $package['dir'].DS.'upgrade';
        $upgradeFiles = JFolder::files($upgradeDir, '.php$');

        if (empty($upgradeFiles)) {
            $this->setState('message', JText::_('This package does not contain any upgrade informations.'));
            JFolder::delete($package['dir']);
            return false;
        }

        natcasesort($upgradeFiles);

        // prepare arrays of upgrade operations and functions to manipulate them
        $this->_fileError = false;
        $this->_fileList = array();
        $this->_sqlList = array();
        $this->_scriptList = array();

		// load each upgrade file starting with current version in ascending order
		foreach ($upgradeFiles as $uFile) {
			if (!eregi("^[0-9]+\.[0-9]+\.[0-9]+\.php$", $uFile)) {
				continue;
			}
			if (strnatcasecmp($uFile, $curVersion.".php") >= 0) {
				require_once($upgradeDir.DS.$uFile);
			}
		}

        if ($this->_fileError == false) {
            // set errors variable
            $errors = false;

            // first of all check if all the files are writeable
            foreach ($this->_fileList as $dest => $op) {
                $file = JPath::clean(JPATH_ROOT.DS.$dest);

                // check if source file is present in upgrade package
                if ($op->operation == 'upgrade') {
                    $from = JPath::clean($package['dir'].DS.$op->packagePath);
                    if( !JFile::exists($from) ) {
                        JError::raiseWarning( 100, JText::_('File does not exist in upgrade package').': '.$op->packagePath );
                        $errors = true;
                    }
                }

                if ((($op->operation == 'delete') && (JFile::exists($file))) || (($op->operation == 'upgrade') && (!JFile::exists($file)))) {

                    // if the file is to be deleted or created, the file's directory must be writable
                    $dir = dirname($file);
                    if (!JFolder::exists($dir)) {
                        // we need to create the directory where the file is to be created
                        if(!JFolder::create($dir)) {
                            JError::raiseWarning( 100, JText::_('Directory could not be created') . ': ' . $dir );
                            $errors = true;
                        }
                    }

                    if (!is_writable($dir)) {
                        if (!JPath::setPermissions($dir, '0755', '0777')) {
                            JError::raiseWarning( 100, JText::_('Directory not writeable') . ': ' . $dir );
                            $errors = true;
                        }
                    }
                }
                elseif ($op->operation == 'upgrade') {

                    // the file itself must be writeable
                    if (!is_writable($file)) {
                        if (!JPath::setPermissions($file, '0755', '0777')) {
                            JError::raiseWarning( 100, JText::_('File not writeable') . ': ' . $file );
                            $errors = true;
                        }
                    }
                }
            }

            if (!$errors) {
                $db =& JFactory::getDBO();

                // execute SQL queries
                foreach ($this->_sqlList as $sql) {
                    $db->setQuery($sql);
                    if( !$db->query() ) {
                        JError::raiseWarning(100, JText::_('Unable to execute SQL query') . ': ' . $sql);
                        $errors = true;
                    }
                }

                // perform file operations
                foreach ($this->_fileList as $dest => $op) {
                    if ($op->operation == 'delete') {
                        $file = JPath::clean(JPATH_ROOT.DS.$dest);
                        if (JFile::exists($file)) {
                            $success = JFile::delete($file);
                            if (!$success) {
                                JError::raiseWarning(100, JText::_('Could not delete file. Please, check the write permissions on').' '.$dest);
                                $errors = true;
                            }
                        }
                    }
                    elseif ($op->operation == 'upgrade') {
                        $from = JPath::clean($package['dir'].DS.$op->packagePath);
                        $to = JPath::clean(JPATH_ROOT.DS.$dest);
                        $destDir = dirname($to);

                        // create the destination directory if needed
                        if (!JFolder::exists($destDir)) {
                            JFolder::create($destDir);
                        }

                        $success = JFile::copy($from, $to);
                        if (!$success) {
                            JError::raiseWarning(100, JText::_('Could not rewrite file. Please, check the write permissions on').' '.$dest);
                            $errors = true;
                        }
                    }
                }

                // run scripts
                foreach ($this->_scriptList as $script) {
                    $file = JPath::clean($package['dir'].DS.$script);
                    if( !JFile::exists($file) ) {
                        JError::raiseWarning(100, JText::_('Could not find script file').': '.$script);
                        $errors = true;
                    } else {
                        include($file);
                    }
                }
            }

            if (!$errors) {
                $this->setState('message', JText::_('ACESEF_UPGRADE_SUCCESS'));
            }
            else {
                $this->setState('message', JText::_('ACESEF_UPGRADE_UNSUCCESS'));
            }
        }

        JFolder::delete($package['dir']);
        return true;
    }
	
	// Adds a file operation to $fileList
    // $joomlaPath - destination file path (e.g. '/administrator/components/com_acesef/admin.acesef.php')
    // $operation - can be 'delete' or 'upgrade'
    // $packagePath - source file path in upgrade package if $operation is 'upgrade' (e.g. '/admin.acesef.php')
	function _addFileOp($joomlaPath, $operation, $packagePath = '') {
        if (!in_array($operation, array('upgrade', 'delete'))) {
            $this->fileError = true;
            JError::raiseWarning(100, JText::_('Invalid upgrade operation') . ': ' . $operation);
            return false;
        }

        // Do not check if file in package exists - it may be deleted in some future version during upgrade
        // It will be checked before running file operations
        $file = new stdClass();
        $file->operation = $operation;
        $file->packagePath = $packagePath;

        $this->_fileList[$joomlaPath] = $file;
    }
	
	function _addSQL($sql) {
        $this->_sqlList[] = $sql;
    }

    function _addScript($script) {
        $this->_scriptList[] = $script;
    }
	
	// Check info
	function &getInfo() {
		
		$info = array();
		if($this->acesef_config->version_checker == 1){
			// Get installed version
			$info['version_installed'] = $this->getInstalledVersion();
			
			// Get latest version
			$url = 'http://www.joomace.net/acesef_info.txt';
			$acesef_version = '';
			
			// Try to connect via cURL
			if(function_exists('curl_init') && function_exists('curl_exec')) {
				$ch = @curl_init();
				
				@curl_setopt($ch, CURLOPT_URL, $url);
				@curl_setopt($ch, CURLOPT_HEADER, 0);
				//http code is greater than or equal to 300 ->fail
				@curl_setopt($ch, CURLOPT_FAILONERROR, 1);
				@curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				//timeout of 5s just in case
				@curl_setopt($ch, CURLOPT_TIMEOUT, 5);
				
				$acesef_version = @curl_exec($ch);
				
				@curl_close($ch);
			}

			// Try to connect via fsockopen
			if($acesef_version == '' && function_exists('fsockopen')) {

				$errno = 0;
				$errstr = '';

				//timeout handling: 5s for the socket and 5s for the stream = 10s
				$fsock = @fsockopen("joomace.net", 80, $errno, $errstr, 5);
			
				if ($fsock) {
					@fputs($fsock, "GET /acesef_info.txt HTTP/1.1\r\n");
					@fputs($fsock, "HOST: joomace.net\r\n");
					@fputs($fsock, "Connection: close\r\n\r\n");
			
					//force stream timeout...bah so dirty
					@stream_set_blocking($fsock, 1);
					@stream_set_timeout($fsock, 5);
					 
					$get_info = false;
					while (!@feof($fsock))
					{
						if ($get_info)
						{
							$acesef_version .= @fread($fsock, 1024);
						}
						else
						{
							if (@fgets($fsock, 1024) == "\r\n")
							{
								$get_info = true;
							}
						}
					}        	
					@fclose($fsock);
					
					//need to chack data cause http error codes aren't supported here
					if(!strstr($acesef_version, '1.')) {
						$acesef_version = '';
					}
				}
			}

			// Try to connect via fopen
			if ($acesef_version == '' && function_exists('fopen') && ini_get('allow_url_fopen')) {
			
				//set socket timeout
				ini_set('default_socket_timeout', 5);
				
				$handle = @fopen ($url, 'r');
				
				//set stream timeout
				@stream_set_blocking($handle, 1);
				@stream_set_timeout($handle, 5);
				
				$acesef_version = @fread($handle, 1000);
				
				@fclose($handle);
			}
			
			// Try to connect via file_get_contents
			if ($acesef_version == '' && function_exists('file_get_contents') && ini_get('allow_url_fopen')) {
				$acesef_version = @file_get_contents($url);
			}
			
			if ($acesef_version == ''){
				$acesef_version = '?.?.?';
			}
			
			$acesef_version = explode("\n", trim($acesef_version));
			$info['version_latest'] = trim(array_shift($acesef_version));
			
			// Set the version status
			$info['version_status'] = version_compare($info['version_installed'], $info['version_latest']);
			$info['version_enabled'] = 1;
		} else {
			$info['version_enabled'] = 0;
		}
		
		$info['download_id'] = $this->acesef_config->download_id;
		
		$db =& JFactory::getDBO();
		
		// Get nr of all SEF URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls WHERE date = '0000-00-00' AND url_real != ''");
  		$info['urls_sef'] = $db->loadResult();
		
		// Get nr of all Locked URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls WHERE locked = '1' ");
  		$info['urls_locked'] = $db->loadResult();
		
		// Get nr of all Custom URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls WHERE date > '0000-00-00' ");
  		$info['urls_custom'] = $db->loadResult();
		
		// Get nr of all 404 URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls WHERE url_real = '' ");
  		$info['urls_404'] = $db->loadResult();
		
		// Get nr of all Moved URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls_moved WHERE published = '1' ");
  		$info['urls_moved'] = $db->loadResult();
		
		// Get nr of all Blocked URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls WHERE blocked = '1' ");
  		$info['urls_blocked'] = $db->loadResult();

  		// Get nr of all Total URLs
		$db->setQuery("SELECT count(*) FROM #__acesef_urls");
		$sef = $db->loadResult();
		
		$info['urls_total'] = $sef + $urls['moved'];
		
		return $info;
	}
	
	function &getInstalledVersion()  {
        static $version;

        if (!isset($version)) {
            $xml = JFactory::getXMLParser('Simple');

            $xmlFile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'acesef.xml';

            if (JFile::exists($xmlFile)) {
                if ($xml->loadFile($xmlFile)) {
                    $root =& $xml->document;
                    $element =& $root->getElementByPath('version');
                    $version = $element ? $element->data() : '';
                }
            }
        }

        return $version;
    }
}
?>