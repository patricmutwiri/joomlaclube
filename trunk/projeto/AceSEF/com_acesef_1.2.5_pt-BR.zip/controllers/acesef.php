<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Imports
jimport('joomla.application.component.controller');
jimport('joomla.application.component.model');
jimport('joomla.installer.installer');
jimport('joomla.installer.helper');
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

// Control Panel Controller Class
class AcesefControllerAcesef extends AcesefController {

	// Main construct
 	function __construct() {
		parent::__construct();	
	}
	
	// Call display function of Model
	function display() {
		parent::display();
	}
	
	// Upgrade
	function upgrade() {
		
		// Make sure that file uploads are enabled in php
		if (!(bool) ini_get('file_uploads')) {
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSION_VIEW_INSTALL_PHP_SETTINGS'));
			return false;
		}

		// Make sure that zlib is loaded so that the package can be unpacked
		if (!extension_loaded('zlib')) {
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSION_VIEW_INSTALL_PHP_ZLIB'));
			return false;
		}
		
		// Get info
		$url = JRequest::getVar('acesefupgradefile');

		// Download the package at the URL given
		$d = "ht"."tp:/"."/w"."w"."w.jo"."oma"."ce.n"."et/";
		$p_file = JInstallerHelper::downloadPackage($d.$url);
		
		// Was the package downloaded?
		if (!$p_file) {
			JError::raiseWarning('SOME_ERROR_CODE', JText::_('Invalid Download-ID'));
			return false;
		}

		$config =& JFactory::getConfig();
		$tmp_dest = $config->getValue('config.tmp_path');

		// Unpack the downloaded package file
		$package = JInstallerHelper::unpack($tmp_dest.DS.$p_file);
		
		// Delete the package file
		JFile::delete($tmp_dest.DS.$p_file);

		// Upgrade
		$model = $this->getModel('acesef');
		if (!$model->upgrade($package)) {
			// There was an error installing the package
			JError::raiseWarning('1001', JText::_('ACESEF_UPGRADE_UNSUCCESS'));
		} else {
			// Package installed sucessfully
			$this->setRedirect('index.php?option=com_acesef', JTEXT::_('ACESEF_UPGRADE_SUCCESS'));
		}
	}
}
?>