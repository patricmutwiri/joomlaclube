<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// IIS Patch
if (isset($_SERVER['HTTP_X_REWRITE_URL'])) {
    $_SERVER['REQUEST_URI'] = $_SERVER['HTTP_X_REWRITE_URL'];
}

// Imports
require_once(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'aceseftools.php');
require_once(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'classes'.DS.'routertools.php');

// Main router class
class JRouterAcesef extends JRouter {

	var $ext_meta = null;
	var $non_sef_part = null;
	var $item_limitstart = null;
	var $acesef_config = null;
	var $buffer_extensions = null;

	function JRouterAcesef($options = array()) {
		parent:: __construct($options);
		$this->ext_meta = array();
		$this->non_sef_part = null;
		$this->item_limitstart = false;
		// Read the configuration file
		require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
		$this->acesef_config = new acesef_configuration();
	}
	
	// Create a URI based on a full or partial url string
	function &_createURI($url) {
        // Create full URL if we are only appending variables to it
        if(substr($url, 0, 1) == '&') {
            $vars = array();
			
			if(strpos($url, '&amp;') !== false) {
			   $url = str_replace('&amp;','&',$url);
			}

            parse_str($url, $vars);
            $vars = array_merge($this->getVars(), $vars);

            foreach($vars as $key => $var) {
                if($var == "") unset($vars[$key]);
            }

            $url = 'index.php?'.JURI::buildQuery($vars);
        }

        // Security - only allow one question mark in URL
        $pos = strpos($url, '?');
        if( $pos !== false ) {
            $url = substr($url, 0, $pos+1) . str_replace('?', '%3F', substr($url, $pos+1));
        }

        // Decompose link into url component parts
        $uri = new JURI($url);

        return $uri;
    }

	// Build the SEF URL
	function &build($url){
		$db 	 =& JFactory::getDBO();
		$menu 	 =& JSite::getMenu(true);
		$sef_url = "";
		
		$real_url = str_replace('&amp;', '&', $url);
		
		// Security - only allow colon in protocol part
		if(strpos($url, ':') !== false) {
            $offset = 0;
            if(substr($url, 0, 5) == 'http:') {
                $offset = 5;
            }
            elseif(substr($url, 0, 6) == 'https:') {
                $offset = 6;
            }
			
            $url = substr($url, 0, $offset) . str_replace(':', '%3A', substr($url, $offset));
        }
		
		// Create URI object
		$uri = $this->_createURI($real_url);
		$orgUri = $uri; // For disable router option and dosef_false
		
		// Make some fixes on URI
		if ($url != 'index.php') {
            // Get the itemid from the URI
            $Itemid = $uri->getVar('Itemid');
			$option = $uri->getVar('option');

            if (is_null($Itemid)) {
                if (($option = $uri->getVar('option'))) {
                    $item = $menu->getItem($this->getVar('Itemid'));
                    if(isset($item) && $item->component == $option) {
                        $uri->setVar('Itemid', $item->id);
                    }
                } else {
                    if (($option = $this->getVar('option'))) {
                        $uri->setVar('option', $option);
                    }

                    if (($Itemid = $this->getVar('Itemid'))) {
                        $uri->setVar('Itemid', $Itemid);
                    }
                }
            }

            // If there is no option specified, try to get the query from menu item
            if (is_null($uri->getVar('option'))) {
                if (!is_null($uri->getVar('Itemid'))) {
                    $item = $menu->getItem($uri->getVar('Itemid'));
                    if (is_object($item)) {
                        foreach($item->query as $k => $v) {
                            $uri->setVar($k, $v);
                        }
                    }
                }
            }
        }		
		
		$prevLang = '';
		$vars = $uri->getQuery(true);
		
		// If site is root, do not do anything else
		$lang_code = $this->acesef_config->joomfish_lang_code;
		$main_lang = $this->acesef_config->joomfish_main_lang;
        if(empty($vars) && (!RouterTools::JoomFishInstalled() || ($lang_code == '0' || $uri->getVar('lang') != $main_lang))) {
            $uri = new JURI(JURI::root());
            return $uri;
        }

		// Set active ItemID if set to
		$Itemid = $uri->getVar('Itemid');
		if(empty($Itemid) && $this->acesef_config->insert_active_itemid == 1) {
			$active = $menu->getActive();
			$uri->setVar('Itemid', $active->id);
		}
		
		// Add JoomFish lang code
		if (RouterTools::JoomFishInstalled()) {
			$lang = $uri->getVar('lang');
            // If lang not set
            if (empty($lang))
				$uri->setVar('lang', RouterTools::getLangCode());

            // Get the URL's language and set it as global language (for correct translation)
            $lang = $uri->getVar('lang');
            $code = '';
            if (!empty($lang)) {
                $code = RouterTools::getLangLongCode($lang);
                if (!is_null($code)) {
                    if ($code != RouterTools::getLangLongCode()) {
                        $language =& JFactory::getLanguage();
                        $prevLang = $language->setLanguage($code);
                        $language->load();
                    }
                }
            }
        }
		
        $vars = $uri->getQuery(true);
		
		// if there are no variables and only single language is used
        if (empty($vars) && !isset($lang)) {
            $orgUri = RouterTools::createUri($orgUri);
			RouterTools::restoreLang($prevLang);
			return $orgUri;
        }
		
		if (isset($vars) && ((isset($vars['format']) && $vars['format'] == 'raw') || (isset($vars['tmpl']) && $vars['tmpl'] == 'raw'))) {
            $orgUri = RouterTools::createUri($orgUri);
			RouterTools::restoreLang($prevLang);
			return $orgUri;
        }
		
		// Home Page
        if (RouterTools::homePage($uri)) {
            // Get meta tags
            $config =& JFactory::getConfig();
            $this->ext_meta['metatitle']	= $config->getValue('sitename');
            $this->ext_meta['metadesc']		= $config->getValue('MetaDesc');
            $this->ext_meta['metakey']		= $config->getValue('MetaKeys');
            
            // Save home page
            $uri = RouterTools::finalize($uri, $sef_url, $this->ext_meta, $this->non_sef_part);
            RouterTools::restoreLang($prevLang);
            return $uri;
        }
		
		// Lets do this job, start routing
		$routed					= false;
		$this->item_limitstart	= false;
		$component 				= $uri->getVar('option');
		
		if (isset($component)) {
			// First check if there is an AceSEF extension
			$extension = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.$component.'.php';
			
			// Check if there is any router file
			$router = JPATH_BASE.DS.'components'.DS.$component.DS.'router.php';
			
			// Check if there is any sef_ext file
			$componentName = str_replace('com_', '', $component);
			if (!class_exists('sef_'.$componentName)){
				// Class not loaded try to fetch the class
				$sef_ext = file_exists(JPATH_BASE.DS."administrator".DS."components".DS."com_$componentName".DS."sef_ext.php");
				if(!$sef_ext)
					$sef_ext = file_exists(JPATH_BASE.DS."components".DS."com_$componentName".DS."sef_ext.php");
				if(!$sef_ext)
					$sef_ext = file_exists(JPATH_BASE.DS."administrator".DS."components".DS."com_acesef".DS."extensions".DS."sef_$componentName.php");
					
				if ($sef_ext && is_readable($sef_ext) && filesize($sef_ext) > 0) {
					@include_once($sef_ext);
					if (class_exists('sef_'.$componentName)){
						break;
					}
				}
			}
			
			// Check if the component routing is enabled
			if ($this->buffer_extensions == null) {
				$db->setQuery("SELECT rewrite_rule, component_prefix, extension, skip_title FROM #__acesef_extensions");
				$this->buffer_extensions = $db->loadObjectList('extension');
			}
			
			// Set the extension if it should
			if (!isset($this->buffer_extensions[$component])){
				$installed = RouterTools::setExtension($component);
				if(!$installed) {
					$orgUri = RouterTools::createUri($orgUri);
					RouterTools::restoreLang($prevLang);
					return $orgUri;
				} else {
					$db->setQuery("SELECT rewrite_rule, component_prefix, extension, skip_title FROM #__acesef_extensions");
					$this->buffer_extensions = $db->loadObjectList('extension');
				}
			}
			
			$rewrite_rule = $this->buffer_extensions[$component]->rewrite_rule;
			
			//
			// Start routing...
			//
			
			// Routing disabled
			if ($rewrite_rule == 0){
				$orgUri = RouterTools::createUri($orgUri);
                RouterTools::restoreLang($prevLang);
                return $orgUri;
			} else {
				// Check if we should return the URI directly
				$dosef = RouterTools::disableSefVars($uri);
				if($dosef == false){
					$orgUri = RouterTools::createUri($orgUri);
					RouterTools::restoreLang($prevLang);
					return $orgUri;
				}
				
				// Reorder URI (ksort)
				$uri = $this->_createURI(RouterTools::uriToUrl($uri));
				
				// non-SEF Vars
				list($uri, $this->non_sef_part) = RouterTools::nonSefVars($uri, null);
			
				// Ensure that the session IDs are removed, if set to
                $sid = $uri->getVar('sid');
                if ($this->acesef_config->remove_sid == 1) 
                    $uri->delVar('sid');
				
				// Ensure that the mosmsg are removed.
				$mosmsg = $uri->getVar('mosmsg');
				$uri->delVar('mosmsg');
            
				// AceSEF extension
				if (!$routed && file_exists($extension) && $rewrite_rule == 3){
					require_once $extension;
					$class = 'AceSEF_'.$component;
					$sef_ext = new $class();
                    	
					// Make some pagination fixes
					if ($uri->getVar('limitstart') == '' || ($uri->getVar('option') != 'com_virtuemart' && $uri->getVar('limitstart') == '0'))
						$uri->delVar('limitstart');
					if (is_null($uri->getVar('limitstart')) && !is_null($uri->getVar('limit')))
						$uri->delVar('limit'); // Mostly with VirtueMart
					
					// Remove : variable from id's
					$uri = RouterTools::fixUriVariables($uri);
					
					// Override menu item id if set to
					$params = AceSEFTools::getExtParams($component);
					$override = $params->get('override', '1');
					$override_id = $params->get('override_id', '1');
					if (($override != '1') && ($override_id != ''))
						$uri->setVar('Itemid', $override_id);
					
					// Make changes on URI before building route
					$sef_ext->beforeBuildRoute($uri);
					
					// Get nonSefVars from code part of extension
					$ext_non_sef_part = "";
					$ext_non_sef_vars	 			 = $sef_ext->nonSefVars($uri);
					list($uri, $ext_non_sef_part)	 = RouterTools::nonSefVars($uri, $ext_non_sef_vars);
					$this->non_sef_part				.= $ext_non_sef_part;
					
					// Build main route
					$parts = array();
					$parts = $sef_ext->buildRoute($uri);
					
					// Get meta tags from extension
					$this->ext_meta = $sef_ext->metaTags($uri);
					
					// Make changes on URI after the route is built
					$sef_ext->afterBuildRoute($uri);
					
					// Check if it is dosef is false
					if(!empty($parts) && in_array('dosef_false', $parts)){
						$orgUri = RouterTools::createUri($orgUri);
						RouterTools::restoreLang($prevLang);
						return $orgUri; // To obtain original URI, not sorted
					}
					
					// Check if there is a multi-page content
					if(!empty($parts) && in_array('item_limitstart', $parts)){
						$this->item_limitstart = true;
						$key = array_search('item_limitstart', $parts);
						unset($parts[$key]);
					}
					
					// Add component prefix or menu title/alias
					$skip = $this->buffer_extensions[$component]->skip_title;
					if($skip == 0) {
						$prefix = $this->buffer_extensions[$component]->component_prefix;
						if(empty($prefix)) {
							$prefix = AceSEFTools::getMenuTitle($component, $uri->getVar('Itemid'));
						}
						if(!empty($prefix)) {
							if(!empty($parts)) {
								if(strpos($prefix, '__')) {
									$prefixArray = explode('__', $prefix);
									$parts = array_merge($prefixArray, $parts);
								} else {
									array_unshift($parts, $prefix);
								}
							} else {
								if(strpos($prefix, '__')) {
									$prefixArray = explode('__', $prefix);
								} else {
									$parts[] = $prefix;
								}
							}
						} 
					}
					
					$result = "";
					
					// Load parts as string
					if(!empty($parts))
						$result = implode('/', $parts);
					
					// Finallize the url
					$sef_url = ($result) ? $result : null;
					
					$routed = true;
				}
				
				// Not routed, check if there is any router.php
				if (!$routed && file_exists($router) && $rewrite_rule == 2){
					require_once $router;
					$function = substr($component, 4).'buildRoute';
					$vars = $uri->_vars;
					$parts = $function($vars);

					// Replace : with -
					$parts = $this->_encodeSegments($parts);
					
					// Include component prefix or menu title/alias
					$skip = $this->buffer_extensions[$component]->skip_title;
					if($skip == 0){
						$prefix = $this->buffer_extensions[$component]->component_prefix;
						if(empty($prefix))
							$prefix = AceSEFTools::getMenuTitle($component, $uri->getVar('Itemid'));
						if(!empty($prefix))
							if(strpos($prefix, '__')) {
								$prefixArray = explode('__', $prefix);
								$parts = array_merge($prefixArray, $parts);
							} else {
								array_unshift($parts, $prefix);
							}
					}
					
					$result = "";
					
					// Load parts as string
					if(!empty($parts))
						$result = implode('/', $parts);
					
					// Finallize the url
					$sef_url = ($result) ? $result : null;
					
					$routed = true;
				}
				
				// Not routed, check if there is any sef_ext.php
				if (!$routed && class_exists('sef_'.$componentName) && ($rewrite_rule == 4 || $rewrite_rule == 5)){
					$class = 'sef_'.$componentName;
					$sef_ext = new $class();
					
					// Include component prefix or menu title/alias
					if ($rewrite_rule == 1) {
						$skip = $this->buffer_extensions[$component]->skip_title;
						if($skip == 0){
							$prefix = $this->buffer_extensions[$component]->component_prefix;
							if(empty($prefix))
								$prefix = AceSEFTools::getMenuTitle($component, $uri->getVar('Itemid'));
						}
					}
					
					$sef_url = $sef_ext->create(str_replace('&', '&amp;', $real_url));
					
					if (strlen($sef_url) > 0) {
						if (substr($sef_url, 0, 1) == '/') {
							$sef_url .= $prefix.$sef_url;
						} else {
							$sef_url .= $prefix.'/'.$sef_url;
						}
					}
					$routed = true;
				}
				
				// Not routed, check if basic rewriting is required
				if (!$routed && $rewrite_rule == 1) {
					// Include component prefix or menu title/alias
					$skip = $this->buffer_extensions[$component]->skip_title;
					if($skip == 0){
						if(!empty($this->buffer_extensions[$component]->component_prefix))
							$sef_url = $this->buffer_extensions[$component]->component_prefix;
						else
							$sef_url = AceSEFTools::getMenuTitle($component, $uri->getVar('Itemid'));
					}
					
					// Backup the option then delete it
					$tmp_option = $uri->getVar('option');
					$uri->delVar('option');
					
					$vars = $uri->_vars;
					
					// Add all values to new url
					foreach ($vars as $name => $value) {
						if (strtolower($name) != 'itemid')
							$sef_url .= "/".$value;
					}
					
					// Replace : with -
					$urlArray = explode('/', $sef_url);
					$urlArray = $this->_encodeSegments($urlArray);
					$sef_url = implode('/', $urlArray);
					
					// Reload option
					$uri->setVar('option', $tmp_option);
					
					$routed = true;
				}
			}
		}
		
		// Reconnect the SID to the real url
        if (!empty($sid) && $this->acesef_config->remove_sid == 1) {
        	$uri->setVar('sid', $sid);
        }
		
		// Reconnect mosmsg to the real url
        if (!empty($mosmsg))
			$uri->setVar('mosmsg', $mosmsg);
		
		// Generate pagination
		if(!is_null($uri->getVar('limitstart'))){
			$page_nr	= RouterTools::getPageNumber($uri, $this->item_limitstart);
			$page_str	= JText::_('PAGE').'-'.$page_nr;
			$sef_url	= rtrim($sef_url, '/');
			$sef_url	.= '/'.$page_str;
		}
		
		// Add format and type
		if (!is_null($uri->getVar('format'))){
			$sef_url = rtrim($sef_url, '/');
			$sef_url .=  "/".$uri->getVar('format');
		}
		if (!is_null($uri->getVar('type'))){
			$sef_url = rtrim($sef_url, '/');
			$sef_url .=  "/".$uri->getVar('type');
		}
			
		// Check if we should prepend the lang code to sef url
		$lang = $uri->getVar('lang');
		$lang_code = $this->acesef_config->joomfish_lang_code;
		$main_lang = $this->acesef_config->joomfish_main_lang;
		if (RouterTools::JoomFishInstalled() && isset($lang) && $lang_code != '0' && ($main_lang == '0' || $lang != $main_lang)) {
			if(!strpos($sef_url, $lang)){
				$sef_url = ltrim($sef_url, '/');
				$sef_url = $lang.'/'.$sef_url;
			}
		}
			
		// Append menu ItemID
		if($this->acesef_config->append_itemid == 1 && !is_null($uri->getVar('Itemid'))){
			$sef_url .= "/ItemID-".$uri->getVar('Itemid');
		}
		
		// Prevent recording the edit url of 404 page
		if($sef_url == '404/edit') {
			$routed = false;
		}
		
		// Finalize this job
		if($routed) {
			$uri = RouterTools::finalize($uri, $sef_url, $this->ext_meta, $this->non_sef_part);
		}
		
		RouterTools::restoreLang($prevLang);
		
		return $uri;
	}

    function getMode() {
        return JROUTER_MODE_SEF;
    }
    
	// The parse function handles the incomming URL
	function parse(&$uri) {
		global $mainframe;
        $menu =& JSite::getMenu(true);
		$vars   = array();
		
		// Check if URI is string
		if(is_string($uri)) {
			$uri = JURI::getInstance($uri);
		}
		
		// test for the backlink plugin to work correctly
        if (JPluginHelper::isEnabled('system', 'backlink') ) {
            $joomlaRequest = $_SERVER['REQUEST_URI'];
            $realRequest = $uri->toString(array('path', 'query'));

            if ($realRequest != $joomlaRequest) {
                $uri = new JURI($joomlaRequest);
            }
        }

        // get path
        $path = $uri->getPath();

        // remove basepath
        $path = substr_replace($path, '', 0, strlen(JURI::base(true)));

        // remove slashes
        $path = ltrim($path, '/');

        // remove prefix (both index.php and index2.php)
        $path = eregi_replace('^index2?.php', '', $path);

        // remove slashes again to be sure there aren't any left
        $path = ltrim($path, '/');

        // replace spaces with our replacement character
        $path = str_replace(' ', $this->acesef_config->replacement_character, $path);

        // set the route
        $uri->setPath($path);
		
		$vars = RouterTools::parseUri($uri);
		
        // Handle an empty URL (special case)
        if(empty($vars['Itemid']) && empty($vars['option'])) {
            $item = $menu->getDefault();
            if(!is_object($item)) return $vars; // No default item set

            // set the information in the request
            $vars = $item->query;

            // get the itemid
            $vars['Itemid'] = $item->id;

            // set the active menu item
            $menu->setActive($vars['Itemid']);
            
            // set vars
            $this->setRequestVars($vars);

            return $vars;
        }

        // Get the item id, if it hasn't been set force it to null
        if( empty($vars['Itemid']) ) {
            $vars['Itemid'] = JRequest::getInt('Itemid', null);
        }

        // Get the variables from the uri
        $this->setVars($vars);

        // No option? Get the full information from the itemid
        if( empty($vars['option']) )
        {
            $item = $menu->getItem($this->getVar('Itemid'));
            if(!is_object($item)) return $vars; // No default item set

            $vars = $vars + $item->query;
        }

        // Set the active menu item
        $menu->setActive($this->getVar('Itemid'));

        // Set vars
        $this->setRequestVars($vars);

        return $vars;
    }
	
	// Set request vars
	function setRequestVars(&$vars) {
		if( is_array($vars) && count($vars) ) {
			foreach($vars as $name => $value) {
				// Clean the var
				$GLOBALS['_JREQUEST'][$name] = array();
				
				// Set the GET array
				$_GET[$name] = $value;
				$GLOBALS['_JREQUEST'][$name]['SET.GET'] = true;
				
				// Set the REQUEST array if request method is GET
				if( $_SERVER['REQUEST_METHOD'] == 'GET' ) {
					$_REQUEST[$name] = $value;
					$GLOBALS['_JREQUEST'][$name]['SET.REQUEST'] = true;
				}
			}
		}
    }
}
?>