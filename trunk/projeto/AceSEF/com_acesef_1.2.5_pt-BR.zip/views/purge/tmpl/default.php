<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

?>
<form action="index.php" method="post" name="adminForm">
	<table class="adminheading">
		<tr>
			<td>
				<p class="message"><?php echo $this->msg; ?><br />
				<?php if( $this->count == 0 ) { ?>
				<input type="submit" name="continue" value=" <?php echo JText::_('ACESEF_PURGE_OK'); ?> " />
				<?php } else { ?>
			    <input type="hidden" name="controller" value="purge" />
			    <input type="hidden" name="task" value="purge" />
			    <input type="hidden" name="type" value="<?php echo JRequest::getVar('type', 1); ?>" />
				<input type="submit" name="do" value=" <?php echo JText::_('ACESEF_PURGE_PROCEED'); ?> " />
			<?php } ?>
				</p>
			</td>
		</tr>
	</table>
	<input type="hidden" name="option" value="com_acesef" />
</form>