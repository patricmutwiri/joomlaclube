<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/
 
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

$state      = &$this->get('State');
$result     = $state->get('result');
$message    = $state->get('message');
?>
<table class="adminform">
<tr>
	<td align="left">
	<strong><?php echo $message; ?></strong>
	</td>
</tr>
<tr>
	<td colspan="2" align="center">
	[&nbsp;<a href="index.php?option=com_acesef&controller=upgrade&task=view" style="font-size: 16px; font-weight: bold">Continue ...</a>&nbsp;]
	</td>
</tr>
</table>
