<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport('joomla.application.component.view');

// Moved URLs View Class
class AcesefViewMovedurls extends JView {

	// View URLs
	function view($tpl = null) {
		global $mainframe, $option;
		
		// Get data from the model
		$items		= & $this->get('Data');
		$total		= & $this->get('Total');
		$pagination = & $this->get('Pagination');
		
		// Import CSS
  		$document =& JFactory::getDocument();
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Import library
		include_once(JPATH_ROOT.DS.'libraries'.DS.'joomla'.DS.'html'.DS.'html'.DS.'select.php');
		
		// Set Toolbar
		JToolBarHelper::title(JText::_('ACESEF_URL_MOVED_TITLE' ), 'acesef');
		$bar =& JToolBar::getInstance();
		JToolBarHelper::custom('add', 'newurl.png', 'newurl.png', JTEXT::_('New'), false);
		JToolBarHelper::custom('edit', 'editurl.png', 'editurl.png', JTEXT::_('Edit'), true);
		JToolBarHelper::custom('publish', 'approve.png', 'approve.png', JTEXT::_('ACESEF_URL_REPOS_TOOLBAR_PUBLISH'), true);
		JToolBarHelper::divider();
		JToolBarHelper::custom('delete', 'deleteselected.png', 'deleteselected.png', JTEXT::_('Delete'), true);
		$bar->appendButton('Confirm', JText::_('ACESEF_URL_REPOS_CONFIRM_DELETE_FILTERED'), 'deletefiltered', JTEXT::_('ACESEF_URL_REPOS_TOOLBAR_DEL_FILTERED'), 'deleteFiltered', false, false);
		JToolBarHelper::divider();
		JToolBarHelper::custom('exportsel', 'exportselected.png', 'exportselected.png', JTEXT::_('ACESEF_URL_REPOS_TOOLBAR_EXPORT_SELECTED'), true);
		JToolBarHelper::custom('exportall', 'exportfiltered.png', 'exportfiltered.png', JTEXT::_('ACESEF_URL_REPOS_TOOLBAR_EXPORT_FILTERED'), false);
		
		// Get filters
        $search_new			= $mainframe->getUserStateFromRequest($option.'.movedurls.search_new', 			'search_new', 			'');
        $search_old			= $mainframe->getUserStateFromRequest($option.'.movedurls.search_old', 			'search_old', 			'');
		$filter_order		= $mainframe->getUserStateFromRequest($option.'.movedurls.filter_order',		'filter_order',			'url_new');
		$filter_order_dir	= $mainframe->getUserStateFromRequest($option.'.movedurls.filter_order_dir',	'filter_order_dir',		'ASC');
		$filter_published	= $mainframe->getUserStateFromRequest($option.'.movedurls.filter_published',	'filter_published',		'-1');
		$search_new			= JString::strtolower($search_new);
		$search_old			= JString::strtolower($search_old);

		// Filter's action
		$javascript 	= 'onchange="document.adminForm.submit();"';
		
		// Make the input box for Real URL search
        $lists['search_new'] = "<input type=\"text\" name=\"search_new\" value=\"{$search_new}\" size=\"50\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";
		
		// Make the input box for SEF URL search
        $lists['search_old'] = "<input type=\"text\" name=\"search_old\" value=\"{$search_old}\" size=\"50\" maxlength=\"255\" onchange=\"document.adminForm.submit();\" />";

		// Table ordering
		$lists['order_dir'] = $filter_order_dir;
		$lists['order'] 	= $filter_order;
	
		// Published Filter
		$published_list[] = JHTMLSelect::Option('-1', JTEXT::_('ACESEF_URL_REPOS_SELECT_PUBLISHED'));
		$published_list[] = JHTMLSelect::Option('1', JTEXT::_('ACESEF_URL_REPOS_SELECT_PUBLISHED_YES'));
		$published_list[] = JHTMLSelect::Option('0', JTEXT::_('ACESEF_URL_REPOS_SELECT_PUBLISHED_NO'));
   	   	$lists['published_list'] = JHTMLSelect::genericlist($published_list, 'filter_published', 'class="inputbox" size="1 "'.$javascript,'value', 'text', $filter_published);
		
		$this->assignRef('lists',		$lists);
		$this->assignRef('items',		$items);
		$this->assignRef('pagination',	$pagination);

		parent::display($tpl);
	}
}
?>