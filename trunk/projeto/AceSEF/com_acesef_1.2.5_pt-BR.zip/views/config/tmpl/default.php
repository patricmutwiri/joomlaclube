<?php
/**
* @version		1.2.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	Copyright (C) 2009 www.joomace.net
* @license		Combined License, http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

// Import JPane
jimport('joomla.html.pane');
$pane =& JPane::getInstance('Tabs');

// Import Editor
jimport('joomla.html.editor');
$editor =& JFactory::getEditor();
?>

<form action="index.php" method="post" name="adminForm">
	<script language="Javascript">
		function submitbutton(pressbutton) {
			<?php echo $editor->save('introtext'); ?>
			submitform(pressbutton);
		}
	</script>
	<table class="adminheading">
		<tr>
			<th>		
		        <?php
				$config =& JFactory::getConfig();
				$htaccess = JPATH_ROOT.DS.'.htaccess';
				if (!$config->getValue('sef')) {
					JError::raiseNotice('100', JText::sprintf('ACESEF_COMMON_SEF_DISABLED', '<a href="index.php?option=com_config">', '</a>'));
				}
				if ($config->getValue('sef') && !$config->getValue('sef_rewrite')) {
					JError::raiseWarning('100', JText::sprintf('ACESEF_COMMON_SEF_MOD_REWRITE', '<a href="index.php?option=com_config">', '</a>'));
				}
				if ($config->getValue('sef') && !file_exists($htaccess)) {
					JError::raiseWarning('100', JText::sprintf('ACESEF_COMMON_NO_HTACCESS'));
				}
				if (!file_exists($htaccess) || !$config->getValue('sef_rewrite') || !$config->getValue('sef')) {
					JError::raiseNotice('100', JText::sprintf('ACESEF_COMMON_ACESE_REQUIREMENTS', '<a href="http://www.joomace.net/documentation/acesef/user-manual/acesef-requirements">', '</a>'));
				}
			?>	
			</th>
		</tr>
		<tr>
			<th>		
		        <?php
				$sef_config_file = JPATH_COMPONENT . DS . 'configuration.php';
				echo 'AceSEF ' . JText::_('configuration.php file is') . (file_exists($sef_config_file) ? (is_writable($sef_config_file) ? (' <b><font color="green">'.JText::_('Writeable').'</font></b>') : (' <b><font color="red">'.JText::_('Unwriteable').'</font></b>')) : (' <b><font color="red">'.JText::_('Using Default Values').'</font></b>'));
				?>		
			</th>
		</tr>
	</table>
	<?php
	echo $pane->startPane('pane');
	echo $pane->startPanel(JText::_('ACESEF_CONFIG_TABS_MAIN'), 'main');
	?>
				<fieldset class="adminform">
				<legend><?php echo JText::_('ACESEF_CONFIG_LEGEND_MAIN'); ?></legend>
				<table class="admintable">
					<tbody>
						<tr>
							<td width="185" class="key">
								<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_MAIN_ENABLE'); ?>::<?php echo JText::_('ACESEF_CONFIG_MAIN_ENABLE_HELP'); ?>">
									<?php echo JText::_('ACESEF_CONFIG_MAIN_ENABLE'); ?>
								</span>
							</td>
							<td>
								<?php echo $this->lists['mode']; ?>
							</td>
						</tr>
						<tr>
							<td width="185" class="key">
								<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_MAIN_VERSION_CHECKER'); ?>::<?php echo JText::_('ACESEF_CONFIG_MAIN_VERSION_CHECKER_HELP'); ?>">
									<?php echo JText::_('ACESEF_CONFIG_MAIN_VERSION_CHECKER'); ?>
								</span>
							</td>
							<td>
								<?php echo $this->lists['version_checker']; ?>
							</td>
						</tr>
						<tr>
							<td width="185" class="key">
								<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_MAIN_LOWERCASE'); ?>::<?php echo JText::_('ACESEF_CONFIG_MAIN_LOWERCASE_HELP'); ?>">
									<?php echo JText::_('ACESEF_CONFIG_MAIN_LOWERCASE'); ?>
								</span>
							</td>
							<td>
								<?php echo $this->lists['url_lowercase']; ?>
							</td>
						</tr>
						<tr>
							<td width="185" class="key">
								<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_MAIN_DUPLICATE_URL'); ?>::<?php echo JText::_('ACESEF_CONFIG_MAIN_DUPLICATE_URL_HELP'); ?>">
									<?php echo JText::_('ACESEF_CONFIG_MAIN_DUPLICATE_URL'); ?>
								</span>
							</td>
							<td>
								<?php echo $this->lists['numeral_duplicated']; ?>
							</td>
						</tr>
						<tr>
							<td width="185" class="key">
								<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_RECORD_DUPLICATED'); ?>::<?php echo JText::_('ACESEF_CONFIG_ADVANCED_RECORD_DUPLICATED_HELP'); ?>">
									<?php echo JText::_('ACESEF_CONFIG_ADVANCED_RECORD_DUPLICATED'); ?>
								</span>
							</td>
							<td>
								<?php echo $this->lists['record_duplicated']; ?>
							</td>
						</tr>
						<tr>
							<td width="185" class="key">
								<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_MAIN_SUFFIX'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_MAIN_SUFFIX_HELP'); ?>">
									<?php echo JText::_('ACESEF_CONFIG_MAIN_SUFFIX'); ?>
								</span>
							</td>
							<td>
								<input type="text" name="url_suffix" id="url_suffix" class="inputbox" size="10" value="<?php echo $this->acesef_config->url_suffix; ?>" />
							</td>
						</tr>
						<tr>
							<td width="185" class="key">
								<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_MAIN_REPLACEMENT_CHAR'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_MAIN_REPLACEMENT_CHAR_HELP'); ?>">
									<?php echo JText::_('ACESEF_CONFIG_MAIN_REPLACEMENT_CHAR'); ?>
								</span>
							</td>
							<td>
								<input type="text" name="replacement_character" id="replacement_character" class="inputbox" size="10" value="<?php echo $this->acesef_config->replacement_character; ?>" />
							</td>
						</tr>
						<tr>
							<td width="185" class="key">
								<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_MAIN_PART_MENU'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_MAIN_PART_MENU_HELP'); ?>">
									<?php echo JText::_( 'ACESEF_CONFIG_MAIN_PART_MENU' ); ?>
								</span>
							</td>
							<td>
								<?php echo $this->lists['menu_url_part']; ?>
							</td>
						</tr>
						<tr>
							<td width="185" class="key">
								<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_MAIN_TITLE_ALIAS'); ?>::<?php echo JText::_('ACESEF_CONFIG_MAIN_TITLE_ALIAS_HELP'); ?>">
									<?php echo JText::_('ACESEF_CONFIG_MAIN_TITLE_ALIAS'); ?>
								</span>
							</td>
							<td>
								<?php echo $this->lists['title_alias']; ?>
							</td>
						</tr>
					</tbody>
				</table>
				</fieldset>
				<fieldset class="adminform">
					<legend><?php echo JText::_('ACESEF_CONFIG_LEGEND_JOOMFISH'); ?></legend>
					<table class="admintable">
						<tbody>
							<tr>
								<td width="185" class="key">
									<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_MAINLANG'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_JOOMFISH_MAINLANG_HELP'); ?>">
										<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_MAINLANG'); ?>
									</span>
								</td>
								<td>
									<?php echo $this->lists['joomfish_main_lang']; ?>
								</td>
							</tr>
							<tr>
								<td width="185" class="key">
									<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_CODE'); ?>::<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_CODE_HELP'); ?>">
										<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_CODE'); ?>
									</span>
								</td>
								<td>
									<?php echo $this->lists['joomfish_lang_code']; ?>
								</td>
							</tr>
							<tr>
								<td width="185" class="key">
									<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_TRANSLATE'); ?>::<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_TRANSLATE_HELP'); ?>">
										<?php echo JText::_('ACESEF_CONFIG_JOOMFISH_TRANSLATE'); ?>
									</span>
								</td>
								<td>
									<?php echo $this->lists['joomfish_trans_url']; ?>
								</td>
							</tr>
						</tbody>
					</table>
				</fieldset>
	<?php
	echo $pane->endPanel();
	echo $pane->startPanel(JText::_('ACESEF_CONFIG_TABS_MEDIUM'), 'medium');
	?>	
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_CONFIG_LEGEND_MEDIUM'); ?></legend>
		<table class="admintable">
			<tbody>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_APPEND_ITEMID'); ?>::<?php echo JText::_('ACESEF_CONFIG_ADVANCED_APPEND_ITEMID_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_APPEND_ITEMID'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['append_itemid']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_TRAILING_SLASH'); ?>::<?php echo JText::_('ACESEF_CONFIG_ADVANCED_TRAILING_SLASH_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_TRAILING_SLASH'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['remove_trailing_slash']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_TOLERANT_WITH_ENDLASH'); ?>::<?php echo JText::_('ACESEF_CONFIG_ADVANCED_TOLERANT_WITH_ENDLASH_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_TOLERANT_WITH_ENDLASH'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['tolerant_to_trailing_slash']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_REDIRECT_WWW'); ?>::<?php echo JText::_('ACESEF_CONFIG_ADVANCED_REDIRECT_WWW_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_REDIRECT_WWW'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['redirect_to_www']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_STRIP_CHARS'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_ADVANCED_STRIP_CHARS_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_STRIP_CHARS'); ?>
						</span>
					</td>
					<td>
						<input type="text" name="url_strip_chars" id="url_strip_chars" class="inputbox" size="40" value="<?php echo $this->acesef_config->url_strip_chars; ?>" />
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_UTF8_URL'); ?>::<?php echo JText::_('ACESEF_CONFIG_ADVANCED_UTF8_URL_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_UTF8_URL'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['utf8_url']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_CHAR_REPLACE'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_ADVANCED_CHAR_REPLACE_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_CHAR_REPLACE'); ?>
						</span>
					</td>
					<td>
						<textarea name="char_replacements" cols="50" rows="6"><?php echo $this->acesef_config->char_replacements; ?></textarea>
					</td>
				</tr>
			</tbody>
		</table>
	</fieldset>
	<?php
	echo $pane->endPanel();
	echo $pane->startPanel(JText::_('ACESEF_CONFIG_TABS_ADVANCED'), 'advanced');
	?>
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_CONFIG_LEGEND_ADVANCED'); ?></legend>
		<table class="admintable">
			<tbody>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_ACTIVE_ITEMID'); ?>::<?php echo JText::_('ACESEF_CONFIG_ADVANCED_ACTIVE_ITEMID_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_ACTIVE_ITEMID'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['insert_active_itemid']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_NONSEF_REDIRECT'); ?>::<?php echo JText::_('ACESEF_CONFIG_ADVANCED_NONSEF_REDIRECT_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_NONSEF_REDIRECT'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['redirect_to_sef']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_REMOVE_SID'); ?>::<?php echo JText::_('ACESEF_CONFIG_ADVANCED_REMOVE_SID_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_REMOVE_SID'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['remove_sid']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_QUERY_STRING'); ?>::<?php echo JText::_('ACESEF_CONFIG_ADVANCED_QUERY_STRING_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_QUERY_STRING'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['set_query_string']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_BASEHREF'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_ADVANCED_BASEHREF_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_BASEHREF'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['base_href']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_FORCE_SSL'); ?>::<?php echo JText::_('ACESEF_CONFIG_ADVANCED_FORCE_SSL_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_FORCE_SSL'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['force_ssl']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_NONSEF_APPEND'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_ADVANCED_NONSEF_APPEND_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_NONSEF_APPEND'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['append_non_sef']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_NONSEF_VARS'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_ADVANCED_NONSEF_VARS_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_NONSEF_VARS'); ?>
						</span>
					</td>
					<td>
						<textarea name="non_sef_vars" id="non_sef_vars" cols="50" rows="3"><?php echo $this->acesef_config->non_sef_vars; ?></textarea>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_DISABLESEF_VARS'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_ADVANCED_DISABLESEF_VARS_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_DISABLESEF_VARS'); ?>
						</span>
					</td>
					<td>
						<textarea name="disable_sef_vars" id="disable_sef_vars" cols="50" rows="3"><?php echo $this->acesef_config->disable_sef_vars; ?></textarea>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_404_DB'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_ADVANCED_404_DB_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_404_DB'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['db_404_errors']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_404_LOG'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_ADVANCED_404_LOG_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_404_LOG'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['log_404_errors']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_ADVANCED_404_LOG_PATH'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_ADVANCED_404_LOG_PATH_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_ADVANCED_404_LOG_PATH'); ?>
						</span>
					</td>
					<td>
						<input type="text" name="log_404_path" id="log_404_path" class="inputbox" size="88" value="<?php echo $this->acesef_config->log_404_path; ?>">
					</td>
				</tr>
			</tbody>
		</table>
	</fieldset>
	<?php
	echo $pane->endPanel();
	echo $pane->startPanel(JText::_('ACESEF_CONFIG_TABS_METATAGS'), 'verify');
	?>
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_CONFIG_LEGEND_METATAGS'); ?></legend>
		<table class="admintable">
			<tbody>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_AUTOTITLE'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_METATAGS_AUTOTITLE_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_AUTOTITLE'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['meta_autotitle']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_AUTODESC'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_METATAGS_AUTODESC_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_AUTODESC'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['meta_autodesc']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_AUTOKEY'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_METATAGS_AUTOKEY_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_AUTOKEY'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['meta_autokey']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_GENERATOR'); ?>::<?php echo JText::_('ACESEF_CONFIG_METATAGS_GENERATOR_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_GENERATOR'); ?>
						</span>
					</td>
					<td>
						<input type="text" name="meta_generator" id="meta_generator" class="inputbox" size="40" value="<?php echo $this->acesef_config->meta_generator; ?>" />
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_ABSTRACT'); ?>::<?php echo JText::_('ACESEF_CONFIG_METATAGS_ABSTRACT_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_ABSTRACT'); ?>
						</span>
					</td>
					<td>
						<input type="text" name="meta_abstract" id="meta_abstract" class="inputbox" size="40" value="<?php echo $this->acesef_config->meta_abstract; ?>" />
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_REVISIT'); ?>::<?php echo JText::_('ACESEF_CONFIG_METATAGS_REVISIT_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_REVISIT'); ?>
						</span>
					</td>
					<td>
						<input type="text" name="meta_revisit" id="meta_revisit" class="inputbox" size="40" value="<?php echo $this->acesef_config->meta_revisit; ?>" />
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_DIRECTION'); ?>::<?php echo JText::_('ACESEF_CONFIG_METATAGS_DIRECTION_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_DIRECTION'); ?>
						</span>
					</td>
					<td>
						<input type="text" name="meta_direction" id="meta_direction" class="inputbox" size="40" value="<?php echo $this->acesef_config->meta_direction; ?>" />
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_V_GOOGLE'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_METATAGS_V_GOOGLE_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_V_GOOGLE'); ?>
						</span>
					</td>
					<td>
						<input type="text" name="meta_googlekey" id="meta_googlekey" class="inputbox" size="88" value="<?php echo $this->acesef_config->meta_googlekey; ?>">
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_V_LIVE'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_METATAGS_V_LIVE_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_V_LIVE'); ?>
						</span>
					</td>
					<td>
						<input type="text" name="meta_livekey" id="meta_livekey" class="inputbox" size="88" value="<?php echo $this->acesef_config->meta_livekey; ?>">
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_V_YAHOO'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_METATAGS_V_YAHOO_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_V_YAHOO'); ?>
						</span>
					</td>
					<td>
						<input type="text" name="meta_yahookey" id="meta_yahookey" class="inputbox" size="88" value="<?php echo $this->acesef_config->meta_yahookey; ?>">
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_ALEXA'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_METATAGS_ALEXA_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_ALEXA'); ?>
						</span>
					</td>
					<td>
						<input type="text" name="meta_alexa" id="meta_alexa" class="inputbox" size="88" value="<?php echo $this->acesef_config->meta_alexa; ?>">
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_NAME_1'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_METATAGS_NAME_1'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_NAME_1'); ?>
						</span>
					</td>
					<td>
						&nbsp;&nbsp;&nbsp;
						<?php echo JText::_('ACESEF_CONFIG_METATAGS_NAME'); ?>
						&nbsp;
						<input type="text" name="meta_name_1" id="meta_name_1" class="inputbox" size="26" value="<?php echo $this->acesef_config->meta_name_1; ?>">
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<?php echo JText::_('ACESEF_CONFIG_METATAGS_CONTENT'); ?>
						&nbsp;&nbsp;
						<input type="text" name="meta_con_1" id="meta_con_1" class="inputbox" size="26" value="<?php echo $this->acesef_config->meta_con_1; ?>">
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_NAME_2'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_METATAGS_NAME_2'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_NAME_2'); ?>
						</span>
					</td>
					<td>
						&nbsp;&nbsp;&nbsp;
						<?php echo JText::_('ACESEF_CONFIG_METATAGS_NAME'); ?>
						&nbsp;
						<input type="text" name="meta_name_2" id="meta_name_2" class="inputbox" size="26" value="<?php echo $this->acesef_config->meta_name_2; ?>">
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<?php echo JText::_('ACESEF_CONFIG_METATAGS_CONTENT'); ?>
						&nbsp;&nbsp;
						<input type="text" name="meta_con_2" id="meta_con_2" class="inputbox" size="26" value="<?php echo $this->acesef_config->meta_con_2; ?>">
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_METATAGS_NAME_3'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_METATAGS_NAME_3'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_METATAGS_NAME_3'); ?>
						</span>
					</td>
					<td>
						&nbsp;&nbsp;&nbsp;
						<?php echo JText::_('ACESEF_CONFIG_METATAGS_NAME'); ?>
						&nbsp;
						<input type="text" name="meta_name_3" id="meta_name_3" class="inputbox" size="26" value="<?php echo $this->acesef_config->meta_name_3; ?>">
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<?php echo JText::_('ACESEF_CONFIG_METATAGS_CONTENT'); ?>
						&nbsp;&nbsp;
						<input type="text" name="meta_con_3" id="meta_con_3" class="inputbox" size="26" value="<?php echo $this->acesef_config->meta_con_3; ?>">
					</td>
				</tr>
			</tbody>
		</table>
	</fieldset>
	<?php
	echo $pane->endPanel();
	echo $pane->startPanel(JText::_('ACESEF_CONFIG_TABS_SEO'), 'seo');
	?>
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_CONFIG_LEGEND_SEO_BASIC'); ?></legend>
		<table class="admintable">
			<tbody>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_SEO_H1'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_SEO_H1_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_SEO_H1'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['seo_h1']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_SEO_NOFOLLOW'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_SEO_NOFOLLOW_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_SEO_NOFOLLOW'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['seo_nofollow']; ?>
					</td>
				</tr>
			</tbody>
		</table>
	</fieldset>
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_CONFIG_LEGEND_SEO_IL'); ?></legend>
		<table class="admintable">
			<tbody>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_SEO_IL'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_SEO_IL'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_SEO_IL'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['seo_il']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_SEO_IL_NOFOLLOW'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_SEO_IL_NOFOLLOW_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_SEO_IL_NOFOLLOW'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['seo_il_nofollow']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_SEO_IL_TARGET'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_SEO_IL_TARGET_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_SEO_IL_TARGET'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['seo_il_target']; ?>
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_SEO_IL_LIMIT'); ?>::<?php echo JText::_('ACESEF_CONFIG_SEO_IL_LIMIT_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_SEO_IL_LIMIT'); ?>
						</span>
					</td>
					<td>
						<input type="text" name="seo_il_limit" id="seo_il_limit" class="inputbox" size="3" value="<?php echo $this->acesef_config->seo_il_limit; ?>" />
					</td>
				</tr>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_SEO_IL_WORDS'); ?>::<?php echo JText::_('ACESEF_CONFIG_SEO_IL_WORDS_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_SEO_IL_WORDS'); ?>
						</span>
					</td>
					<td>
						<textarea name="seo_il_words" cols="90" rows="17"><?php echo $this->acesef_config->seo_il_words; ?></textarea>
					</td>
				</tr>
			</tbody>
		</table>
	</fieldset>
	<?php
	echo $pane->endPanel();
	echo $pane->startPanel(JText::_('ACESEF_CONFIG_TABS_404'), '404');
	?>
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_CONFIG_TABS_404'); ?></legend>
		<table class="admintable">
			<tbody>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_TABS_404'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_TABS_404'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_TABS_404'); ?>
						</span>
					</td>
					<td>
						<?php echo $this->lists['page404']; ?>
					</td>
				</tr>
			</tbody>
		</table>
	</fieldset>
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_CONFIG_LEGEND_404CUSTOM'); ?></legend>
		<table class="admintable">
			<tbody>
				<tr>
					<td>
						<?php echo $editor->display('introtext', $this->lists['custom404'], '600', '350', '50', '11'); ?>
					</td>
				</tr>
			</tbody>
		</table>
	</fieldset>
	<?php
	echo $pane->endPanel();
	echo $pane->startPanel(JText::_('ACESEF_CONFIG_TABS_UPGRADE'), 'upgrade');
	?>
	<fieldset class="adminform">
		<legend><?php echo JText::_('ACESEF_CONFIG_LEGEND_UPGRADE'); ?></legend>
		<table class="admintable">
			<tbody>
				<tr>
					<td>
						<?php echo JText::_('ACESEF_CONFIG_UPGRADE_DOWNLOAD_ID_HELP'); ?>
					</td>
				</tr>
			</tbody>
		</table>
		<table class="admintable">
			<tbody>
				<tr>
					<td width="185" class="key">
						<span class="editlinktip hasTip" title="<?php echo JText::_('ACESEF_CONFIG_UPGRADE_DOWNLOAD_ID'); ?>::<?php echo JTEXT::_('ACESEF_CONFIG_UPGRADE_DOWNLOAD_ID_HELP'); ?>">
							<?php echo JText::_('ACESEF_CONFIG_UPGRADE_DOWNLOAD_ID'); ?>
						</span>
					</td>
					<td>
						<input type="text" name="download_id" id="download_id" class="inputbox" size="88" value="<?php echo $this->acesef_config->download_id; ?>">
					</td>
				</tr>
			</tbody>
		</table>
	</fieldset>
	<?php
	echo $pane->endPanel();
	echo $pane->endPane();
	?>
	<input type="hidden" name="id" value="" />
	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="section" value="config" />
	<input type="hidden" name="controller" value="config" />
	<input type="hidden" name="task" value="edit" />
</form>