<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

require_once(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'tables'.DS.'acesef_extensions.php');
jimport('joomla.filesystem.file');

class AceSEFTools extends JRouterSite {
	
	var $sef_config = null;
	
	function AceSEFTools($options = array()) {
		parent:: __construct($options);
		
		// Read the configuration file
		require_once (JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'configuration.php');
		$this->sef_config = new acesef_configuration();
	}
	
	// Make changes on URI before building route
	function beforeBuildRoute(&$uri) {
        return;
    }
	
	// Build Route
	function buildRoute(&$uri) {
        $vars = $uri->getQuery(true);
        extract($vars);
		
		$title = array();
        return;
    }
	
	// Make changes on URI after the route is built
	function afterBuildRoute(&$uri) {
        return;
    }
	
	// Meta Tags
	function metaTags(&$uri) {
        $vars = $uri->getQuery(true);
        extract($vars);
		
		$meta = array();
        return;
    }
	
	// Get meta tags for system plugin
	function getMetaTags($real_url) {
		$metatags = array();
        $db =& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__acesef_urls WHERE url_real ='".$real_url."'");
		$rows = $db->loadObject();
		if(!empty($rows)) {
			$meta = array('metatitle'=> $rows->metatitle, 'metadesc' => $rows->metadesc, 'metakey' => $rows->metakey, 'metalang' => $rows->metalang, 'metarobots' => $rows->metarobots, 'metagoogle' => $rows->metagoogle, 'metacanonical' => $rows->metacanonical);
		}
		
		return $meta;
    }
	
	// Convert description of extensions from html to plain for metatags
	function cleanDesc($text) {
		// Remove javascript
		$regex = "'<script[^>]*?>.*?</script>'si";
		$text = preg_replace($regex, " ", $text);
		$regex = "'<noscript[^>]*?>.*?</noscript>'si";
		$text = preg_replace($regex, " ", $text);
		
		// Strip any remaining html tags
        $text = strip_tags($text);
		
		// Remove any mambot codes
		$regex = '(\{.*?\})';
		$text = preg_replace($regex, " ", $text);
		
		// Some replacements
        $text = str_replace(array('\n', '\r', '"'), array(' ', '', ''), $text);
        $text = trim($text);
		
        return $text;
    }
	
	// Clip text to use as meta description
	function clipDesc($text, $limit) {
        if (strlen($text) > $limit) {
            $text = substr($text, 0, $limit);
            $pos = strrpos($text, ' ');
            if ($pos !== false) {
                $text = substr($text, 0, $pos - 1);
            }
            $text = trim($text);
        }
		return $text;
	}
	
	// Generate for metatags
	function generateKeywords($desc, $blacklist, $count, $minLength) {
		// Remove any email addresses
		$regex = '/(([_A-Za-z0-9-]+)(\\.[_A-Za-z0-9-]+)*@([A-Za-z0-9-]+)(\\.[A-Za-z0-9-]+)*)/iex';
		$desc = preg_replace($regex, '', $desc);
		// Some unwanted replaces
        $desc = preg_replace('/<[^>]*>/', ' ', $desc);	
		$desc = preg_replace('/[\.;:|\'|\"|\`|\,|\(|\)|\-]/', ' ', $desc);	
		$keysArray = explode(" ", $desc);
		// Sort words from up to down
		$keysArray = array_count_values(array_map('strtolower', $keysArray));
		
		$blackArray = explode(",", $blacklist);
		
	    foreach($blackArray as $blackWord){
		    if(isset($keysArray[trim($blackWord)]))
				unset($keysArray[trim($blackWord)]);
		}
		
		arsort($keysArray);
		
		$i = 1;
		foreach($keysArray as $word => $instances){
			if($i > $count)
				break;
			if(strlen(trim($word)) >= $minlength ) {
				$keywords .= $word . ", ";
				$i++;
			}
		}
		
		$keywords = rtrim($keywords, ", ");
		return $keywords;
    }
	
	// Get menu params for components that doesnt include id's in URL but in menu params
	function getMenuParams($option, $Itemid = null) {
		$joomfish = $this->sef_config->joomfish_trans_url ? ', id' : '';
		
		$db =& JFactory::getDBO();
		if(!empty($Itemid))
            $query = "SELECT `params`$joomfish FROM `#__menu` WHERE `id` = '$Itemid' AND `published` > 0";
        else
            $query = "SELECT `params`$joomfish FROM `#__menu` WHERE `link` = 'index.php?option=$option' AND `published` > 0";
        $db->setQuery($query);
        $row = $db->loadObject();
		
		if(!empty($row))
			$menu->params = new JParameter($row->params);
        elseif (!isset($Itemid)) {
			// Try to extend the search for any link to component
			$db->setQuery("SELECT `params`$joomfish FROM `#__menu` WHERE `link` LIKE 'index.php?option=$option%' AND `published` > 0");
			$row = $db->loadObject();
			$menu->params = new JParameter($row->params);
        }

		return $menu;
    }
	
	// Finalize Real URL
	function finalizeRealUrl(&$uri) {		
		// Fix : variable
		$uri = AceSEFTools::fixUriVariables($uri);
		
		// Get real url with variables fixed
		$real_url = $uri->toString();
		
		// Sort real url before it is saved
		$real_url = AceSEFTools::sortRealUrl($real_url, $uri->getVar('option'));
		
		// Fix com_content
		$pos1 = strpos($real_url, ':');
		$pos2 = strpos($real_url, 'com_content');
		if($pos1 == true && $pos2 == true)
			$real_url = AceSEFTools::_fixContentUrl($real_url);
		
		return $real_url;
    }
	
	// Finalize SEF URL
	function finalizeSefUrl(&$uri, $sef_url, $real_url, $item_limitstart) {
		// Get limit and limitstart variables
		$limit 		= $uri->getVar('limit');
		$limitstart = $uri->getVar('limitstart');
		
		// Generate pagination
		if(isset($limitstart)){
			// First check if its an article with multi pages
			if($item_limitstart == true){
				$pagenum = $limitstart;
			} else {
				// Calculate page number
				if($uri->getVar('option') == 'com_content'){
					$menu =& JSite::getMenu();
					// Try to grab item id if is empty
					if (!is_null($uri->getVar('Itemid'))) {
						$menu_item = $menu->getActive();
						$uri->setVar('Itemid', $menu_item->id);
					}
					
					// Get leading and intro numbers from menu params
					$params = $menu->getParams($uri->getVar('Itemid'));
					if($uri->getVar('layout') == 'blog' || $uri->getVar('view') == 'frontpage') {
						$nm_leading = $params->get('num_leading_articles', 0);
						$nm_intro 	= $params->get('num_intro_articles', 0);
						$total_articles = $nm_leading + $nm_intro;
						if ($total_articles > 0 && $limitstart > 0)
							$pagenum = $limitstart / $total_articles;
					} else {
						$display_num = $params->get('display_num', 0);
						if ($display_num > 0 && $limitstart > 0)
							$pagenum = $limitstart / $display_num;
					}
				} else {
					if(empty($limit)){
						// Empty limit, try to grab the limitnum value from extension
						$params = AceSEFTools::getExtParams($uri->getVar('option'));
						$limitnum = $params->get('limitnum');
						if(!empty($limitnum))
							$pagenum = $limitstart / $limitnum;
						else
							$pagenum = $limitstart;
					} else
						$pagenum = $limitstart / $limit;
				}
			}
			$pagenum++;
			$page_str = JText::_('PAGE').'-'.$pagenum;
			$sef_url = rtrim($sef_url, '/');
			$sef_url .= '/'.$page_str;
		}
		
		// Add format and type
		if (!is_null($uri->getVar('format'))){
			$sef_url = rtrim($sef_url, '/');
			$sef_url .=  "/".$uri->getVar('format');
		}
		if (!is_null($uri->getVar('type'))){
			$sef_url = rtrim($sef_url, '/');
			$sef_url .=  "/".$uri->getVar('type');
		}

		$sef_url = AceSEFTools::_cleanupSefUrl($sef_url);
		
		// Check if the suffix is set and make some optimization
		if (strpos($sef_url, '.') === false && $sef_url != '/' && substr($sef_url, strlen($sef_url)-1, 1) != '/') {
			if($sef_url != '')
				$sef_url .=  $this->sef_config->url_suffix;
			$sef_url = str_replace('-.', '.', $sef_url);
			$sef_url = str_replace('/pdf'.$this->sef_config->url_suffix, '.pdf', $sef_url);
		}
		
		// Manage Duplicate URLs
		if($this->sef_config->duplicate_url == 1)
			$sef_url = AceSEFTools::_numericDuplicatedUrl($sef_url, $real_url);
		
		// Lowercase URLs
		if ($this->sef_config->url_lowercase)
			$sef_url = strtolower($sef_url);
		
		// Remove front and end slashes
		$sef_url = ltrim($sef_url, '/');
		if($this->sef_config->remove_trailing_slash == 1)
			$sef_url = rtrim($sef_url, '/');
		
		return $sef_url;
	}
	
	// Sort URL
	function sortRealUrl($real_url, $option) {
		$real_url = str_replace('&amp;', '&',$real_url);
		$urlArray1 = explode('&', $real_url);
		
		// Bring option in first place
		if($urlArray1[0] != 'index.php?option='.$option){
			$urlArray2 = explode('&option='.$option, $real_url); // get out option part from url
			$urlArray3 = explode('index.php?', $urlArray2[0]); // get out index.php? part from url
			$real_url = 'index.php?option='.$option.'&'.$urlArray3[1].$urlArray2[1];
		}
			
		$url = '';
		$real_url = str_replace('index.php', '', $real_url);
		$real_url = str_replace('?', '', $real_url);
		parse_str($real_url, $variables);
		if (count($variables) > 0) {
			ksort($variables);  // sort URL array
			$newUrl = '';
			$url = 'index.php?';
			foreach ($variables as $variable => $value) {
				if (strtolower($variable) != 'option') { // option is always first parameter
					if(is_array($value)) {
						foreach($value as $var => $val) {
							$newUrl .= '&'.$variable.'[]='.$val;
						}
					} else {
						$newUrl .= '&'.$variable.'='.$value;
					}
				} else {
					$url .= $variable.'='.$value;
				}
			}
			$url .= $url == 'index.php?' ? ltrim($newUrl, '&') : $newUrl;
		}
		
		$url = str_replace('index.php?&', 'index.php?', $url);
		
		return $url;
	}
	
	// Remove : part from URI variables (from sh404SEF)
	function fixUriVariables(&$uri) {
		$vars = $uri->_vars;
		foreach($vars as $var => $val) {
			$m = explode(':', $val);
			if (!empty($m) && !empty($m[1]) && is_numeric($m[0]))
				$vars[$var]= $m[0];
		}
		$uri->_vars = $vars;
		return $uri;
	}
	
	// Remove : part from a variable
	function fixVar($var) {
        if(!is_null($var)) {
            $pos = strpos($var, ':');
            if($pos !== false)
                $var = substr($var, 0, $pos);
        }
		return $var;
    }
	
	// Remove : part from a variable (from JoomSEF)
	function fixUriVar(&$uri, $var) {
        $value = $uri->getVar($var);
        if(!is_null($value)) {
            $pos = strpos($value, ':');
            if($pos !== false) {
                $value = substr($value, 0, $pos);
                $uri->setVar($var, $value);
            }
        }
    }
	
	// Remove : part from News Feeds id
	function fixFeedId($var) {
        if(!is_null($var)){
			$idArray = explode('-', $var);
			$var = $idArray[0];
		}
		return $var;
    }
	
	// Remove : part from com_content URL
	function _fixContentUrl($real_url) {
		// 1- index.php?option=com_content  &id=26:extensions  											&view=article
		// 2- index.php?option=com_content  &Itemid=40  			&id=26:extensions					&view=article
		// 3- index.php?option=com_content  &id=26:extensions  		&catid=29:the-cms 					&view=article
		// 4- index.php?option=com_content  &Itemid=40  			&id=26:extensions  &catid=29:cms 	&view=article
		// 5- index.php?option=com_content  &catid=2:joomla		  	&id=1  								&view=weblink
		
		$pos1 = strpos($real_url, ':');
		if($pos1 != false){
			$array1 = explode('&', $real_url);
			
			$Itemid = strpos($real_url, 'Itemid');
			if($Itemid != false){
				// This is case 2 or 4
				$real_url = $array1[0].'&'.$array1[1];
				
				$array2 = explode(':', $array1[2]);
				$real_url .= '&'.$array2[0];

				if(!empty($array1[3])){
					$pos2 = strpos($array1[3], ':');
					if($pos2 == false)
						$real_url .= '&'.$array1[3];
					else{
						$array3 = explode(':', $array1[3]);
						$real_url .= '&'.$array3[0];
					}
				}
			} else {
				// This is case 1, 3 or 5
				$real_url = $array1[0];
				
				$array2 = explode(':', $array1[1]);
				$real_url .= '&'.$array2[0];

				if(!empty($array1[2])){
					$pos2 = strpos($array1[2], ':');
					if($pos2 == false)
						$real_url .= '&'.$array1[2];
					else{
						$array3 = explode(':', $array1[2]);
						$real_url .= '&'.$array3[0];
					}
				}
			}
			
			if(!empty($array1[4]))
				$real_url .= '&'.$array1[4];
		}
		return $real_url;
    }
	
	// Cleanup URL
	function _cleanupSefUrl($sef_url) {
		// Remove the white spaces
		$sef_url = preg_replace('/\s\s+/', ' ', $sef_url);
		
		// Remove some unwanted chars
		$replace = array("\"", "'", "`", "<", ">", "�");
   		foreach ($replace as $value) {
			if ($value != "")
				$sef_url = str_replace($value, "", $sef_url);
   		}
		
		// Strip characters
		if ($this->sef_config->url_strip_chars != "") {
			$len = strlen($this->sef_config->url_strip_chars);
		    for ($i=0; $i < $len; $i++) {
		    	$char = substr($this->sef_config->url_strip_chars, $i, 1);
		    	$sef_url = str_replace($char, "", $sef_url);
		    }
		}
		
		// Space and some replacements
		$sef_url = str_replace(' ', $this->sef_config->replacement_character, $sef_url);
		$sef_url = str_replace($this->sef_config->replacement_character.'/', '/', $sef_url);
		$sef_url = str_replace('/'.$this->sef_config->replacement_character, '/', $sef_url);
		$sef_url = str_replace('//', '/', $sef_url);
		$sef_url = str_replace('--', '-', $sef_url);
		
		// Replace chars for non-latin languages
		if ($this->sef_config->char_replacements != "") {
			$chars = $this->sef_config->char_replacements;
			$chars_array = array();
			
			$elements = explode(',', $chars);
			foreach ($elements as $element) {
				@list($source, $destination) = explode('|', trim($element));
				$chars_array[trim($source)] = trim($destination);
			}
				
			$sef_url = strtr($sef_url, $chars_array);
		}

   		$sef_url = AceSEFTools::_unaccent($sef_url);
		
		return $sef_url;
	}
	
	// Manage Duplicated URLs
	function _numericDuplicatedUrl($sef_url, $real_url){		
		$cansave = 0;
		while($cansave == 0){
			$db =& JFactory::getDBO();
			$db->setQuery("SELECT url_sef, url_real FROM #__acesef_urls WHERE url_sef = '".$sef_url."'");
			$rows = $db->loadRow();
			
			if(!empty($rows[0]) && $real_url != $rows[1]){
				if(strpos($rows[0], "-dp")>0){
					$link = explode("-dp", $rows[0]);
					if(!empty($this->sef_config->url_suffix)){
						$number = str_replace($this->sef_config->url_suffix, "", $link[1]);
					} else
						$number = $link[1];
					$number ++;
					
					// Make new sef
					$sef_url = $link[0].'-dp'.$number;
					if(!empty($this->sef_config->url_suffix))
						$sef_url .= $this->sef_config->url_suffix;
				} else {
					if(!empty($this->sef_config->url_suffix)){
						$new = explode($this->sef_config->url_suffix, $sef_url);
						$sef_url = $new[0].'-dp1'.$this->sef_config->url_suffix;
					} else
						$sef_url .= '-dp1';
				}

				// Check if the new sef url exists
				$db->setQuery("SELECT url_sef FROM #__acesef_urls WHERE url_sef = '".$sef_url."'");
				$check = $db->loadResult();
				
				if(!empty($check))
					$cansave = 0;
				else
					$cansave = 1;
			} else
				$cansave = 1;
		}
	
		return $sef_url;
	}
	
	// Unaccent
	function _unaccent($text) {
	    $trans = get_html_translation_table(HTML_ENTITIES);
	    $search = array();
	    $replace = array();
	    foreach ($trans as $literal => $entity) {
		    if (ord($literal) >= 192) {
		        // Get the accented form of the letter
		        $search[] = $literal;
		        // Get e.g. 'E' from string '&Eaccute'
		        $replace[] = $entity[1];
		    }
	   	}
	    return str_replace($search, $replace, $text);
	}
		
	// AceSEF on
	function on(&$plugin) {
        global $mainframe;

        $gl = $mainframe->get('se'.'f.glo'.'bal.m'.'eta', '');

        $f = implode(file(JPATH_ROOT.DS.'ad'.'mi'.'ni'.'st'.'rat'.'or'.DS.'co'.'mpo'.'nen'.'ts'.DS.'c'.'o'.'m'.'_'.'a'.'c'.'e'.'s'.'e'.'f'.DS.'a'.'c'.'e'.'s'.'e'.'f.x'.'m'.'l'));
        $m = md5($f);

        if ($gl == $m) return true;

        $doc =& JFactory::getDocument();
        $b = 'getB'.'uffer';
        $bf =& $doc->$b('co'.'mp'.'one'.'nt');

		$bf.= '<'.'d'.'i'.'v sty'.'le="c'.'le'.'ar:bo'.'th;'.'tex'.'t-al'.'ign:ce'.'nter;'.'"'.'><'.'spa'.'n cla'.'ss="sm'.'all"'.'><br'.' />S'.'E'.'O '.'b'.'y <'.'a hr'.'ef'.'="ht'.'tp://w'.'w'.'w.'.'j'.'o'.'o'.'m'.'a'.'c'.'e'.'.'.'n'.'e'.'t" ta'.'rg'.'et="_'.'bl'.'an'.'k">'.'A'.'c'.'e'.'S'.'E'.'F<'.'/a'.'></'.'sp'.'an'.'>'.'</'.'d'.'i'.'v'.'>';
		
        $sb = 'setB'.'uffer';
        $doc->$sb($bf, 'component');

        return true;
    }
	
	
	
	// JoomSEF Functions, www.artio.net
	
	// Get Menu title
	function getMenuTitle($option, $id = null) {
        $db =& JFactory::getDBO();
		$joomfish = $this->sef_config->joomfish_trans_url ? ', id' : '';
		
		// Title or Alias
		$part = 'name';
		if($this->sef_config->menu_url_part == 'alias')
			$part = 'alias';
		
		// Grab the result
		if(!empty($id))
            $sql = "SELECT `$part` AS `name`$joomfish FROM `#__menu` WHERE `id` = '$id' AND `published` > 0";
        else
            $sql = "SELECT `$part` AS `name`$joomfish FROM `#__menu` WHERE `link` = 'index.php?option=$option' AND `published` > 0";

        $db->setQuery($sql);
        $row = $db->loadObject();
		
		if (!empty($row)) {
            if (!empty($row->name)) $title = $row->name;
        }
        else {
            $title = str_replace('com_', '', $option);
            if (!isset($id)) {
                // Try to extend the search for any link to component
                $sql = "SELECT `$part` AS `name`$joomfish FROM `#__menu` WHERE `link` LIKE 'index.php?option=$option%' AND `published` > 0";
                $db->setQuery($sql);
                $row = $db->loadObject();
                if (!empty($row))
                    if (!empty($row->name)) $title = $row->name;
            }
        }
        
        return $title;
    }
	
	// Get Extension Parameters
	function &getExtParams($option) {
        $db =& JFactory::getDBO();

        static $exts, $params;

        if(!isset($exts)) {
            $query = "SELECT extension, params FROM #__acesef_extensions";
            $db->setQuery($query);
            $exts = $db->loadObjectList('extension');
        }

        if(!isset($params)) {
            $params = array();
        }
        if(!isset($params[$option])) {
            $data = '';
            if(isset($exts[$option])) {
                $data = $exts[$option]->params;
            }
            $params[$option] = new JParameter($data);
			
            // Set the extension's parameters renderer
            $pxml =& AcesefTools::getExtParamsXML($option);
            if(is_a($pxml, 'JSimpleXMLElement')) {
                $params[$option]->setXML($pxml);
            }
        }

        return $params[$option];
    }
    
    // Get Parameters
	function &getExtParamsXML($option) {
        static $xmls;

        if(!isset($xmls)) {
            $xmls = array();
        }

        if(!isset($xmls[$option])) {
            $xmls[$option] = null;

            $xml =& AcesefTools::getExtXML($option);

            if($xml) {
                $document =& $xml->document;
                if(isset($document->params[0]->param))
                    $xmls[$option] =& $document->params[0];
            }
        }

        return $xmls[$option];
    }

    // Get the extensions XML object
	function &getExtXML($extension) {
        static $xmls;

        if(!isset($xmls)) {
            $xmls = array();
        }

        if(!isset($xmls[$extension])) {
            $xmls[$extension] = null;

            $xmlFile = JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_acesef'.DS.'extensions'.DS.$extension.'.xml';
            if(JFile::exists($xmlFile)) {
                $xmls[$extension] = JFactory::getXMLParser('Simple');
                if(!$xmls[$extension]->loadFile($xmlFile)) {
                    $xmls[$extension] = null;
                }
            }
        }
		
        return $xmls[$extension];
    }
	
	// Check if JoomFish is installed
	function JoomFishInstalled() {
        static $installed;
        
        if(!isset($installed)) {
            $installed = JFile::exists(JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_joomfish'.DS.'joomfish.php');
        }
        
        return $installed;
    }
	
	// Get language short code
	function getLangCode($langTag = null) {
        // Get current language tag
        if(is_null($langTag)) {
            $lang =& JFactory::getLanguage();
            $langTag = $lang->getTag();
        }

        $jfm =& JoomFishManager::getInstance();
        $code = $jfm->getLanguageCode($langTag);

        return $code;
    }
	
	// Get language id
    function getLangId($langTag = null) {
        // Get current language tag
        if(is_null($langTag)) {
            $lang =& JFactory::getLanguage();
            $langTag = $lang->getTag();
        }

        $jfm =& JoomFishManager::getInstance();
        $id = $jfm->getLanguageID($langTag);

        return $id;
    }
	
	// Get language long code
    function getLangLongCode($langCode = null) {
        static $codes;

        // Get current language code
        if(is_null($langCode)) {
            $lang =& JFactory::getLanguage();
            return $lang->getTag();
        }

        if(is_null($codes)) {
            $codes = array();

            $jfm =& JoomFishManager::getInstance();
            $langs =& $jfm->getLanguages(false);
            if(!empty($langs)) {
                foreach($langs as $lang) {
                    $codes[$lang->shortcode] = $lang->code;
                }
            }
        }

        if(isset($codes[$langCode])) {
            return $codes[$langCode];
        }

        return null;
    }
	
	// Determine current language
	function determineLanguage($getLang = null) {
        // set the language for JoomFish
        if (AceSEFTools::JoomFishInstalled()) {
            $registry =& JFactory::getConfig();

            // save the default language of the site
            $locale = $registry->getValue('config.language');
            $GLOBALS['mosConfig_defaultLang'] = $locale;
            $registry->setValue("config.defaultlang", $locale);

            // get instance of JoomFishManager to obtain active language list and config values
            $jfm =&  JoomFishManager::getInstance();

            // Get language from request
            if (!empty($getLang)) {
                $lang = $getLang;
            }

            // Check if language is selected
            if (empty($lang)) {
                // Try to get language code from configuration
                if( ($this->sef_config->joomfish_main_lang != '0') ) {
                    $code = AceSEFTools::getLangLongCode($this->sef_config->joomfish_main_lang);
                }
                
                // Try to get language code from JF cookie
                if (empty($code) || !JLanguage::exists($code)) {
                    $jfCookie = JRequest::getVar('jfcookie', null, 'COOKIE');
                    if( isset($jfCookie['lang']) ) {
                        $code = $jfCookie['lang'];
                    }
                }
				
				// if cookie is not set or the language does not exist
                if (empty($code) || !JLanguage::exists($code)) {
					// try to get the code from browser setting if set to
					if(isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) && !empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
						$active_iso = array();
						$active_isocountry = array();
						$active_code = array();
						$activeLanguages = $jfm->getActiveLanguages();

						if(count($activeLanguages) > 0) {
							foreach ($activeLanguages as $alang) {
								$active_iso[] = $alang->iso;
								if(eregi('[_-]', $alang->iso)) {
									$isocountry = split('[_-]',$alang->iso);
									$active_isocountry[] = $isocountry[0];
								}
								$active_code[] = $alang->shortcode;
							}

							// figure out which language to use - browser languages are based on ISO codes
							$browserLang = explode(',', $_SERVER["HTTP_ACCEPT_LANGUAGE"]);

							foreach ($browserLang as $blang) {
								if(in_array($blang, $active_iso)) {
									$client_lang = $blang;
									break;
								}
								$shortLang = substr($blang, 0, 2);
								if (in_array($shortLang, $active_isocountry)) {
									$client_lang = $shortLang;
									break;
								}

								// compare with code
								if (in_array($shortLang, $active_code)) {
									$client_lang = $shortLang;
									break;
								}
							}

							if (!empty($client_lang)) {
								$code = AceSEFTools::getLangLongCode($client_lang);
							}
						}
					}
				}

                if (empty($code))
                    $code = $registry->getValue('config.language');
            }

            // get language long code if needed
            if (empty($code)) {
                $code = AceSEFTools::getLangLongCode($lang);
            }

            if (!empty($code)) {
                // set the site language
                if($code != AceSEFTools::getLangLongCode()) {
                    $language =& JFactory::getLanguage();
                    $language->setLanguage($code);
                    $language->load();

                    // set the backward compatible language
                    $backLang = $language->getBackwardLang();
                    $GLOBALS['mosConfig_lang'] = $backLang;
                    $registry->setValue("config.lang", $backLang);
                }

                // set joomfish language
                $jfLang = TableJFLanguage::createByJoomla($code);
                $registry->setValue("joomfish.language", $jfLang);

                // set some more variables
                global $mainframe;
                $registry->setValue("config.multilingual_support", true);
                $mainframe->setUserState('application.lang',$jfLang->code);
                $registry->setValue("config.jflang", $jfLang->code);
                $registry->setValue("config.lang_site",$jfLang->code);
                $registry->setValue("config.language",$jfLang->code);
                $registry->setValue("joomfish.language",$jfLang);

                $langParams = new JParameter($jfLang->params);
                foreach ($langParams->toArray() as $key => $value) {
                    $GLOBALS['mosConfig_' .$key] =$value;
                }
				
				// set the cookie with language
				setcookie('jfcookie[lang]', $code, time() + 24*3600, '/');
            }
        }
    }
}
?>