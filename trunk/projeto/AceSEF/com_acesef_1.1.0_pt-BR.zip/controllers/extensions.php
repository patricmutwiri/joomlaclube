<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// Import JController
jimport('joomla.application.component.controller');
jimport( 'joomla.application.component.helper' );

// Extensions Controller Class
class AcesefControllerExtensions extends AcesefController {
	
	// Main constructer
	function __construct() 	{
		parent::__construct();
	}
	
	// Purge URLs of this extension
	function purge() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('extensions');
		foreach ($cid as $id) {
			$model->purge($id);
		}
		// Return to extensions page
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view', JTEXT::_('ACESEF_EXTENSION_DEFAULT_PURGED'));
	}
	
	// Uninstall extensions
	function delete() {
		$cid = JRequest::getVar('cid', array(0), 'method', 'array');
		$model = $this->getModel('extensions');
		foreach ($cid as $id) {
			$model->delete($id);
		}
		// Return to extensions page
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view', JTEXT::_('ACESEF_EXTENSION_REMOVED'));
	}

	// Edit extension
	function edit() {
		$model =& $this->getModel('extensions');
		$view  = $this->getView('extensions','edit');
		$view->setModel($model, true);
		$view->edit('edit');
	}

	// Go to cpanel
	function back() {
		$this->setRedirect('index.php?option=com_acesef');
	}

	// Display extensions
	function view() {
		$model =& $this->getModel('extensions');
		$view = $this->getView('extensions','html');
		$view->setModel($model, true);
		$view->view();
	}
	
	// Go to extensions page
	function back_view() {
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view');
	}
	
	// Save changes
	function save() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('extensions');
		if (!$model->save($id)) {
			return JError::raiseWarning(500, $url_record->getError());
		}
		
		// Return to extensions page
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view', JTEXT::_('ACESEF_EXTENSION_CHANGES_SAVED'));
	}
	
	// Apply changes
	function apply() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('extensions');
		if (!$model->apply($id)) {
			return JError::raiseWarning(500, $url_record->getError());
		}
		
		// Return to extension
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=edit&cid[]='.$id, JTEXT::_('ACESEF_EXTENSION_CHANGES_SAVED'));
	}
	
	// Cancel saving changes
	function cancel() {
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view');
	}
	
	// Save changes and Purge URLs of this extension
	function savepurge() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('extensions');
		if (!$model->savepurge($id)) {
			return JError::raiseWarning(500, $url_record->getError());
		}
		
		// Return to extension
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view', JTEXT::_('ACESEF_EXTENSION_CHANGES_SAVED_PURGED'));
	}
	
	// Apply changes and Purge URLs of this extension
	function applypurge() {
		$id = JRequest::getVar('id', 0, 'method', 'int');
		$model = $this->getModel('extensions');
		if (!$model->applypurge($id)) {
			return JError::raiseWarning(500, $url_record->getError());
		}
		
		// Return to extension
		$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=edit&cid[]='.$id, JTEXT::_('ACESEF_EXTENSION_CHANGES_SAVED_PURGED'));
	}
	
	// Install a new extension
	function doinstall() {
		jimport('joomla.application.component.model');
		jimport('joomla.installer.installer');
		
		// Check if the extensions directory is writable
		$directory = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesef'.DS.'extensions';
		if (!is_writable($directory)) {
			//JError::raiseWarning('1001', JText::_('ACESEF_EXTENSION_INSTALL_DIR_CHMOD_ERROR'));
		}
		
		$result = false;
		// Make sure that file uploads are enabled in php
		if (!(bool) ini_get('file_uploads')) {
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSION_INSTALL_PHP_SETTINGS'));
			$result = false;
			return false;
		}

		// Make sure that zlib is loaded so that the package can be unpacked
		if (!extension_loaded('zlib')) {
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSION_INSTALL_PHP_ZLIB'));
			$result = false;
			return false;
		}

		$userfile = JRequest::getVar('install_package', null, 'files', 'array');

		// If there is no uploaded file, we have a problem...
		if (!is_array($userfile)) {
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSION_INSTALL_NO_FILE'));
			$result = false;
			return false;
		}

		// Check if there was a problem uploading the file.
		if ($userfile['error'] || $userfile['size'] < 1) {
			JError::raiseWarning('1001', JText::_('WARNINSTALLUPLOADERROR'));
			$result = false;
			return false;
		}

		$config =& JFactory::getConfig();
		$tmp_dest = $config->getValue('config.tmp_path').DS.$userfile['name'];
		$tmp_src = $userfile['tmp_name'];

		// Move uploaded file
		jimport('joomla.filesystem.file');
		$uploaded = JFile::upload($tmp_src, $tmp_dest);
		jimport('joomla.installer.helper');
		$package = JInstallerHelper::unpack($tmp_dest);

		// Get an installer instance
		$installer =& JInstaller::getInstance();
		$adapter = new acesef_extension_adapter($installer);
		$installer->_adapters['acesef'] =& $adapter;

		// Install the package
		if (!$installer->install($package['dir'])) {
			// There was an error installing the package
			$msg = JText::sprintf('INSTALLEXT', JText::_($package['type']), JText::_('Error'));
			$result = false;
		} else {
			// Package installed sucessfully
			$msg = JText::sprintf('INSTALLEXT', JText::_($package['type']), JText::_('Success'));
			$result = true;
		}

		// Cleanup the install files
		if (!is_file($package['packagefile'])) {
			$config =& JFactory::getConfig();
			$package['packagefile'] = $config->getValue('config.tmp_path').DS.$package['packagefile'];
		}
		JInstallerHelper::cleanupInstall($package['packagefile'], $package['extractdir']);
		if(!$result)
			JError::raiseWarning('1001', JText::_('ACESEF_EXTENSION_NOT_INSTALLED'));
		else
			$this->setRedirect('index.php?option=com_acesef&controller=extensions&task=view', JTEXT::_('ACESEF_EXTENSION_INSTALLED'));
		return $package;

	}
}


// AceSEF extension installation adapater
class acesef_extension_adapter extends JObject {

	function __construct(&$parent) {
		$this->parent =& $parent;
	}

	function install() {		
		$manifest =& $this->parent->getManifest();
		$this->manifest =& $manifest->document;
		$root =& $manifest->document;
		
		$name 			=& $root->getElementByPath('name');
		$author 		=& $root->getElementByPath('author');
		$authorUrl 		=& $root->getElementByPath('authorurl');
		$version 		=& $root->getElementByPath('version');
		$description	=& $root->getElementByPath('description');
		$extension		=& $root->getElementByPath('extension');
		$params			=& $root->getElementByPath('params');
		$name 			= $name->data();
		$author 		= $author->data();
		$authorUrl 		= $authorUrl->data();
		$version		= $version->data();
		$description 	= $description->data();
		$extension		= $extension->data();
		$params			= $this->parent->getParams($params);

		$basePath = JPATH_SITE;

		// Set the installation path
		$this->parent->setPath('extension_site', $basePath.DS."administrator".DS."components".DS."com_acesef".DS."extensions");

		$element =& $root->getElementByPath('files');
		$this->parent->parseQueries($this->manifest->getElementByPath('queries'));
		
		// Install the files
		if ($this->parent->parseFiles($element) === false || ($extension == 'com_remository' && $version == '1.0.1') || $authorUrl != 'www.joomace.net') {
			// Install failed, rollback changes
			$this->parent->abort();
			return false;
		} else {
			$extension_record =& JTable::getInstance('acesef_extensions', 'Table');
			$extension_record->name 		= $name;
			$extension_record->author		= $author;
			$extension_record->author_url	= $authorUrl;
			$extension_record->version		= $version;
			$extension_record->description  = $description;
			$extension_record->extension 	= $extension;
			$extension_record->params 		= $params;
			$extension_record->store();
			
			// Make some updates after installation
			$db =& JFactory::getDBO();
			
			// Remove already created URLs for this extension from database
			$db->setQuery("DELETE FROM `#__acesef_urls` WHERE (`url_real` LIKE '%option=$extension&%' OR `url_real` LIKE '%option=$extension')");
			$db->query();
			// Set rewrite rule as extension
			$db->setQuery("UPDATE #__acesef_routers SET router_type = '9', rewrite_rule = '9' WHERE component = '".$extension."'");
			$db->query();
			
			return true;
		}
		
		}
}
?>