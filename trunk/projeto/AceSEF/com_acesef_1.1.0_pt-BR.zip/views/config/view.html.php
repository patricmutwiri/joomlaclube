<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Import View
jimport( 'joomla.application.component.view');

// Configuration View Class
class AcesefViewConfig extends JView {

	// Edit configuration
	function edit($tpl = null) {
		$db =& JFactory::getDBO();
		
		// Import CSS
  		$document =& JFactory::getDocument();
  		$document->addStyleSheet('components/com_acesef/assets/css/acesef.css');
		
		// Set Toolbar
		JToolBarHelper::title(JText::_('ACESEF_CONFIG_TITLE'), 'acesef');
		$bar =& JToolBar::getInstance();
		JToolBarHelper::custom('save', 'save1.png', 'save1.png', JTEXT::_('Save'), false);
		JToolBarHelper::custom('apply', 'approve.png', 'approve.png', JTEXT::_('Apply'), false);
		JToolBarHelper::custom('cancel', 'cancel1.png', 'cancel1.png', JTEXT::_('Cancel'), false);
		JToolBarHelper::divider();
		$bar->appendButton('Confirm', JText::_('ACESEF_ROUTER_WARNING_SAVE'), 'save1', JText::_('ACESEF_CONFIG_SAVE_PURGE'), 'savepurge', false, false);
		$bar->appendButton('Confirm', JText::_('ACESEF_ROUTER_WARNING_SAVE'), 'approve', JText::_('ACESEF_CONFIG_APPLY_PURGE'), 'applypurge', false, false);

		
		// Create the select lists
  		JHTML::_('behavior.mootools');
		$document->addScriptDeclaration("window.addEvent('domready', function(){ var JTooltips = new Tips($$('.hasTip'), { maxTitleChars: 60, fixed: false}); });");


		smart_import('joomla.html.html.select');
		$lists['mode'] 						= JHTMLSelect::booleanlist('mode',					null,	$this->acesef_config->mode);
		$lists['url_lowercase'] 			= JHTMLSelect::booleanlist('url_lowercase',			null,	$this->acesef_config->url_lowercase);
		$lists['duplicate_url'] 			= JHTMLSelect::booleanlist('duplicate_url',			null,	$this->acesef_config->duplicate_url);
		$lists['log_404_errors'] 			= JHTMLSelect::booleanlist('log_404_errors',		null,	$this->acesef_config->log_404_errors);
		$lists['joomfish_lang_code'] 		= JHTMLSelect::booleanlist('joomfish_lang_code',	null,	$this->acesef_config->joomfish_lang_code);
		$lists['joomfish_trans_url'] 		= JHTMLSelect::booleanlist('joomfish_trans_url',	null,	$this->acesef_config->joomfish_trans_url);
		$lists['remove_trailing_slash'] 	= JHTMLSelect::booleanlist('remove_trailing_slash',	null,	$this->acesef_config->remove_trailing_slash);
		$lists['generator'] 				= JHTMLSelect::booleanlist('generator',				null,	$this->acesef_config->generator);
		
		$url_part = array();
  		$url_part[] = JHTMLSelect::Option('alias', JText::_('ACESEF_CONFIG_ALIAS_FIELD'));
		$url_part[] = JHTMLSelect::Option('title', JText::_('ACESEF_CONFIG_TITLE_FIELD'));
		
		// Menu URL part
		$lists['menu_url_part'] 		= JHTMLSelect::genericlist($url_part, 'menu_url_part', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->menu_url_part);
			
		// JoomFish languages list
		$joomfish_main_lang = array();
		$joomfish_main_lang[] = JHTMLSelect::Option('0', JText::_('ACESEF_CONFIG_JOOMFISH_MAINLANG_NONE'));
		
		// Check if languages table exists
		$tables	= $db->getTableList();
		$prefix	= $db->getPrefix();
		$langs	= $prefix."languages";
		if (in_array($langs, $tables)){
			// Get installed languages and add them to list
			$db->setQuery("SELECT `id`, `shortcode`, `name` FROM `#__languages` WHERE `active` = '1' ORDER BY `ordering`");
			$langs = $db->loadObjectList();
			if( @count(@$langs) ) {	
				foreach($langs as $lang) {
					$l = new stdClass();
					$l->code = $lang->shortcode;
					$l->name = $lang->name;
					
					// Load languages
					$joomfish_main_lang[] = JHTMLSelect::Option($l->code, $l->name);
				}
			}
		}
		$lists['joomfish_main_lang'] = JHTMLSelect::genericlist($joomfish_main_lang, 'joomfish_main_lang', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->joomfish_main_lang);
		
		// Google News Position
		$google_news = array();
		$google_news[] = JHTMLSelect::Option('0', JText::_('ACESEF_CONFIG_GOOGLE_NEWS_SELECT_NO'));
		$google_news[] = JHTMLSelect::Option('1', JText::_('ACESEF_CONFIG_GOOGLE_NEWS_SELECT_ID'));
		$google_news[] = JHTMLSelect::Option('2', JText::_('ACESEF_CONFIG_GOOGLE_NEWS_SELECT_DATE'));
		$lists['google_news'] = JHTMLSelect::genericlist($google_news, 'google_news', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->google_news);
		
		// Google News Position
		$google_news_numberpos = array();
		$google_news_numberpos[] = JHTMLSelect::Option('0', JText::_('ACESEF_CONFIG_GOOGLE_NEWS_SELECT_PREPEND'));
		$google_news_numberpos[] = JHTMLSelect::Option('1', JText::_('ACESEF_CONFIG_GOOGLE_NEWS_SELECT_APPEND'));
		$lists['google_news_numberpos'] = JHTMLSelect::genericlist($google_news_numberpos, 'google_news_numberpos', 'class="inputbox" size="1 "' ,'value', 'text', $this->acesef_config->google_news_numberpos);
		
		// 404 Page	
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT `id`, `introtext` FROM `#__content` WHERE `title` = '404'");
        $row = $db->loadObject();
		$lists['notfound'] = isset($row->introtext) ? $row->introtext : JText::_('<h1>404: Not Found</h1><h4>Sorry, but the content you requested could not be found</h4>');
		
		// Check if the 404_logfile is empty
		if ( $this->acesef_config->log_404_path == "") {
			$this->acesef_config->log_404_path = JPATH_ROOT.DS.'logs'.DS.'acesef_404.log';
		}
		
		$this->assignRef('lists', $lists);
		parent::display($tpl) ;
	}
}
?>