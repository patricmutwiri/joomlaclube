<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

?>
<form action="index.php" method="post" name="adminForm">
<div id="editcell">
	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_('ACESEF_COMMON_NUM'); ?>
			</th>
			<th width="5">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
			</th>
			<th class="title">
				<?php echo JTEXT::_('ACESEF_ROUTER_NAME'); ?>
			</th>
			<th>
				<?php echo JTEXT::_('ACESEF_ROUTER_OPTIONS'); ?>
			</th>
			<th class="title">
				<?php echo JTEXT::_('ACESEF_ROUTER_PREFIX'); ?>
			</th>
			<th class="title">
				<?php echo JTEXT::_('ACESEF_ROUTER_SKIP_TITLE'); ?>
			</th>
			<th>
				<?php echo JTEXT::_('ACESEF_ROUTER_BYPASS_POST_REDIRECT'); ?>
			</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="7">
			</td>
		</tr>
	</tfoot>
	<tbody>
	<?php
	$k = 0;
	$count = count($this->items);
	for ($i=0, $n=$count; $i < $n; $i++) {
		$row = &$this->items[$i];
		$checked 		= JHTML::_('grid.checkedout', $row, $i);
		?>
		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $i+1; ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<?php echo $row->component; ?>
			</td>
			<td>
				<?php echo $row->router_select; ?>
				<input type="hidden" name="id[<?php echo $row->id; ?>]" value="<?php echo $row->id; ?>">
			</td>
			<td>
				<input type="text" name="component_prefix[<?php echo $row->id; ?>]" size="25" value="<?php echo $row->component_prefix; ?>" />
			</td>
			<td>
				<?php echo $row->skip_title; ?>
			</td>
			<td>
				<?php echo $row->bypass_post_redirect; ?>
			</td>
		</tr>
	<?php
	}
	?>
	</tbody>
	</table>
</div>
<input type="hidden" name="option" value="com_acesef" />
<input type="hidden" name="controller" value="routers" />
<input type="hidden" name="task" value="view" />
<input type="hidden" name="boxchecked" value="0" />
</form>