<?php
/**
* @version		1.1.0
* @package		AceSEF
* @subpackage	AceSEF
* @copyright	2009 JoomAce LLC, www.joomace.net
* @license		GNU/GPL
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

?>
<form action="index.php" method="post" name="adminForm" id="adminForm">
	<table>
		<tr>
			<td nowrap="nowrap">
				<?php echo JText::_('ACESEF_URL_REPOS_COMMON_URL_SEF').'<br />'.$this->lists['search_sef']; ?>
			</td>
			<td nowrap="nowrap">
				<?php echo JText::_('ACESEF_URL_REPOS_COMMON_URL_REAL').'<br />'.$this->lists['search_real']; ?>
			</td>
			<td nowrap="nowrap">
				<?php echo JText::_('ItemID').'<br />'.$this->lists['search_ItemID']; ?>
			</td>
			<td align="left" width="100%">
				&nbsp;
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['type_list']; ?>
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['components']; ?>
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['published_list']; ?>
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['locked_list']; ?>
			</td>
			<td nowrap="nowrap">
				<?php echo '&nbsp;<br />'.$this->lists['blocked_list']; ?>
			</td>
		</tr>
	</table>
	<div id="editcell">
		<table class="adminlist">
		<thead>
			<tr>
				<th width="1%">
					<?php echo JText::_('ACESEF_COMMON_NUM'); ?>
				</th>
				<th width="1%">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
				</th>
				<th width="20%" class="title">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_URL_REPOS_COMMON_URL_SEF'), 'url_sef', $this->lists['order_Dir'], $this->lists['order']); ?>
				</th>
				<th width="30%" class="title">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_URL_REPOS_COMMON_URL_REAL'), 'url_real', $this->lists['order_Dir'], $this->lists['order']); ?>
				</th>
				<th width="3%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_URL_REPOS_COMMON_PUBLISHED'), 'published', $this->lists['order_Dir'], $this->lists['order']); ?>
				</th>
				<th width="3%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_URL_REPOS_COMMON_USED'), 'used', $this->lists['order_Dir'], $this->lists['order']); ?>
				</th>
				<th width="3%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_URL_REPOS_COMMON_LOCKED'), 'locked', $this->lists['order_Dir'], $this->lists['order']); ?>
				</th>
				<th width="3%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JTEXT::_('ACESEF_URL_REPOS_COMMON_BLOCKED'), 'blocked', $this->lists['order_Dir'], $this->lists['order']); ?>
				</th>
				<th width="1%" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', 'ID', 'id', $this->lists['order_Dir'], $this->lists['order']); ?>
				</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="9">
					<?php echo $this->pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
		<tbody>
		<?php
		$k = 0;
		for ($i=0, $n=count($this->items); $i < $n; $i++) {
			$row = &$this->items[$i];

			$link 			= JRoute::_('index.php?option=com_acesef&controller=editurl&task=edit&cid[]='.$row->id);

			$checked 		= JHTML::_('grid.checkedout',   $row, $i);
			
			// Published icon
			$img_published		= $row->published ? '../components/com_acesef/assets/images/icon-16-published-on.png' : '../components/com_acesef/assets/images/icon-16-published-off.png';
			$task_published		= $row->published ? 'unpublish' : 'publish';
			$alt_published		= $row->published ? JText::_('ACESEF_URL_REPOS_TOOLTIP_PUBLISH_NOT') : JText::_('ACESEF_URL_REPOS_TOOLTIP_PUBLISH');
			$action_published	= $row->published ? JText::_('ACESEF_URL_REPOS_TOOLTIP_PUBLISH_NOT') : JText::_('ACESEF_URL_REPOS_TOOLTIP_PUBLISH');
			
			$href_published = '
			<a href="javascript:void(0);" onclick="return listItemTask(\'cb'.$i.'\',\''.$task_published.'\')" title="'.$action_published.'">
			<img src="images/'.$img_published.'" border="0" alt="'.$alt_published.'" />
			</a>';
			
			// Used icon
			if ($row->used == 1) {
				$task_used = '';
			} else {
				$task_used = 'used';
			}
			if ($row->used == 1) {
				$img_used = '../components/com_acesef/assets/images/icon-16-used-on.png';
				$action_used =  JText::_('ACESEF_URL_REPOS_TOOLTIP_USED');
			} elseif ($row->used == 0) {
				$img_used = '../components/com_acesef/assets/images/icon-16-used-on2.png';
				$action_used =  JText::_('ACESEF_URL_REPOS_TOOLTIP_USED_MAKE');
			} else {
				$img_used = '../components/com_acesef/assets/images/icon-16-used-off.png';
				$action_used =  JText::_('ACESEF_URL_REPOS_TOOLTIP_USED_MAKE');
			}
			
			if ($row->used != 1) {
				$href_used = '
				<a href="javascript:void(0);" onclick="return listItemTask(\'cb'.$i.'\',\''.$task_used.'\')"  title="'.$action_used.'">
				<img src="images/'.$img_used.'" border="0" />
				</a>';
			} else {
				$href_used = '<img src="images/'.$img_used.'" border="0" alt="'.$action_used.'" />';
			}
			
			// Locked icon
			$img_locked		= $row->locked ? '../components/com_acesef/assets/images/icon-16-lock-on.png' : '../components/com_acesef/assets/images/icon-16-lock-off.png';
			$task_locked	= $row->locked ? 'unlock' : 'lock';
			$alt_locked		= $row->locked ? JText::_('ACESEF_URL_REPOS_TOOLTIP_LOCK_NOT') : JText::_('ACESEF_URL_REPOS_TOOLTIP_LOCK');
			$action_locked	= $row->locked ? JText::_('ACESEF_URL_REPOS_TOOLTIP_LOCK_NOT') : JText::_('ACESEF_URL_REPOS_TOOLTIP_LOCK');
			
			$href_locked = '
			<a href="javascript:void(0);" onclick="return listItemTask(\'cb'.$i.'\',\''.$task_locked.'\')" title="'.$action_locked.'">
			<img src="images/'.$img_locked.'" border="0" alt="'.$alt_locked.'" />
			</a>';
			
			// Blocked icon
			$img_blocked	= $row->blocked ? '../components/com_acesef/assets/images/icon-16-block-on.png' : '../components/com_acesef/assets/images/icon-16-block-off.png';
			$task_blocked 	= $row->blocked ? 'unblock' : 'block';
			$alt_blocked	= $row->blocked ? JText::_('ACESEF_URL_REPOS_TOOLTIP_BLOCK_NOT') : JText::_('ACESEF_URL_REPOS_TOOLTIP_BLOCK');
			$action_blocked	= $row->blocked ? JText::_('ACESEF_URL_REPOS_TOOLTIP_BLOCK_NOT') : JText::_('ACESEF_URL_REPOS_TOOLTIP_BLOCK');

			$href_blocked = '
			<a href="javascript:void(0);" onclick="return listItemTask(\'cb'.$i.'\',\''.$task_blocked.'\')" title="'.$action_blocked.'">
			<img src="images/'.$img_blocked.'" border="0" alt="'.$alt_blocked.'" />
			</a>';
			
			?>
			<tr class="<?php echo "row$k"; ?>">
				<td>
					<?php echo $this->pagination->getRowOffset($i); ?>
				</td>
				<td>
					<?php echo $checked; ?>
				</td>
				<td>
					<a href="../<?php echo $row->url_sef; ?>" title="<?php echo JText::_('ACESEF_URL_REPOS_TOOLTIP_SEF_URL'); ?>" target="_blank">
					<?php echo substr($row->url_sef, 0, 173); ?></a>
				</td>
				<td>
					<a href="<?php echo $link; ?>" title="<?php echo JText::_('ACESEF_URL_REPOS_TOOLTIP_REAL_URL'); ?>"><?php echo substr($row->url_real, 0, 173); ?></a>
				</td>
				<td align="center">
					<?php echo $href_published;?>
				</td>
				<td align="center">
					<?php echo $href_used;?>
				</td>
				<td align="center">
					<?php echo $href_locked;?>
				</td>
				<td align="center">
					<?php echo $href_blocked;?>
				</td>
				<td align="center">
					<?php echo $row->id;?>
				</td>
			</tr>
			<?php
			$k = 1 - $k;
		}
		?>
		</tbody>
		</table>
	</div>

	<input type="hidden" name="option" value="com_acesef" />
	<input type="hidden" name="controller" value="repository" />
	<input type="hidden" name="task" value="view" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
</form>