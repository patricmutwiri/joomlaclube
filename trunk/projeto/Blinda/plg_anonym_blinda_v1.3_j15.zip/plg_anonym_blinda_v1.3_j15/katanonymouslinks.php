<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

// Import library dependencies
jimport('joomla.plugin.plugin');
// end

class plgContentKatAnonymousLinks extends JPlugin
{

	function plgContentKatAnonymousLinks(&$subject)
	{
		parent::__construct($subject);

		// load plugin parameters
		$this->plugin = &JPluginHelper::getPlugin('content', 'katanonymouslinks');
		$this->params = new JParameter($this->plugin->params);
	}

	function onPrepareContent(&$article, &$params, $limitstart=0)
	{
		// db params
		$class = $this->params->get('class', 'anonym');
		$all_links = $this->params->get('all_links', 0);
		
		// define the regular expression for the bot
		
		if ($all_links) {
			$regex = '#<a[^>]*?[^>]*?>.*?<\/a>#si';
		} else {
			$regex  = '#<a[^>]*?class="' . $class . '".*?[^>]*?>.*?<\/a>#si';
		}
        
        if (!preg_match($regex, $article->text))
        {
            return;
        }
        
        // define language
        JPlugin::loadLanguage('plg_content_katanonymouslinks', JPATH_ADMINISTRATOR);
        
        // replacement regular expression
        $article->text = preg_replace_callback($regex, array($this, 'replacer'), $article->text);
	}
	/*
	 * Replacer
	 */
	function replacer(&$match) {
		
		// define html anchor link
		$ahref = $match[0];
		
		// find url in href attribute
		preg_match('#href="(.*?)"#', $ahref, $url);
		$url = $url[1];
		
		// exclude domains
		$exclude = $this->params->get('domain_exclude', '');
		
		if ($exclude) {
			$exclude = explode("\n", $exclude);
			foreach ($exclude as $exclude_link) {
				$exclude_link = trim($exclude_link);
				if (strpos($url, trim($exclude_link))) {
					return $ahref;
				}
			}
		}
		
		// check if link is not just anchor <a href="#">anchor</a>
		$is_anchor = strpos($url, '#');
		
		jimport('joomla.enviroment.uri');
		
		if ($is_anchor !== false or JURI::isInternal($url)) {
			return $ahref; // return original ahref
		}
		
		// check if link starts with "http://" which is valid format
		$without_http = strpos($url, 'http://');
		
		if ($without_http === false) {
			JError::raiseNotice('', JText::_('KATANONYMOUS_LINK_WITHOUT_HTTP'));
            return;
		}
		
		// define web service to URL procedure
		$service = $this->params->get('service', 'link.blinda.me');
		
		// set returned link to blank
		$link = '';
		$service_url = '';
		
		switch ($service) {
			case 'link.blinda.me':
			default:
				$service_url = 'http://link.blinda.me/?';
				break;
		}
		
		$link = str_replace('href="' . $url . '"', 'href="' . $service_url . $url . '"', $ahref);
		
		unset($url, $ahref, $service_url);

		// remove "class" if required
		$remove_class = $this->params->get('remove_class', 0);
		$class = $this->params->get('class', 'anonym');
		
		if ($remove_class) {
			// remove class and empty double spaces
			$link = str_replace(array('class="' . $class . '"', '  '), array('', ' '), $link);
			
			unset($remove_class, $class);
		}
		// return modified link
		return $link;
	}
}

?>
