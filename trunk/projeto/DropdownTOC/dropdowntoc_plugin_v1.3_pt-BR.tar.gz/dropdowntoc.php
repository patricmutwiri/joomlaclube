<?php
// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Example Content Plugin
 *
 * @package		Joomla
 * @subpackage	Content
 * @since 		1.5
 */
class plgContentDropDownTOC extends JPlugin
{
	var $mystr;
	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param object $params  The object that holds the plugin parameters
	 * @since 1.5
	 */
	function plgContentDropDownTOC( &$subject, $params )
	{
		parent::__construct( $subject, $params );
	}

	/**
	 * Example prepare content method
	 *
	 * Method is called by the view
	 *
	 * @param 	object		The article object.  Note $article->text is also available
	 * @param 	object		The article params
	 * @param 	int			The 'page' number
	 */
	function onPrepareContent( &$row, &$params, $page )
	{
		global $mainframe;
		global $my, $database;
		JPlugin::loadLanguage( 'plg_content_dropdowntoc', JPATH_BASE."/administrator/" );
		// expression to search for
		$regex = '/{(jospagebreak_scroll)\s*(.*?)}/i';
		$regex1 = '#<hr([^>]*?)class=(\"|\')system-pagebreak(\"|\')([^>]*?)\/*>#iU';
		preg_match_all( $regex1, $row->text, $matches, PREG_SET_ORDER );
		foreach($matches as $k=>$v){
			$attrs2 = JUtility::parseAttributes($v[1]);
			$str = "{jospagebreak_scroll ";
			if($attrs2['title']){
				$str.="title=".$attrs2['title'];
			}
			if($attrs2['alt']){
				$str.="&alt=".$attrs2['alt'];
			}
			$str.="}";
			$row->text = str_replace($v[0],$str,$row->text);
		}

		// Get Plugin info
		$plugin			=& JPluginHelper::getPlugin('content', 'dropdowntoc');
		$pluginParams	= new JParameter( $plugin->params );

		$print   = JRequest::getBool('print');
		$showall = JRequest::getBool('showall');

		if (!$pluginParams->get('enabled', 1)) {
			$print = true;
		}

		if ($print) {
			$row->text = preg_replace( $regex, '<BR />', $row->text );
			return true;
		}


		// simple performance check to determine whether bot should process further
		if ( strpos( $row->text, 'jospagebreak_scroll' ) === false ) {
			return true;
		}


		// check whether mambot has been unpublished
		if ( $params->get( 'intro_only' )|| $params->get( 'popup' )) {
			$row->text = preg_replace( $regex, '<br />', $row->text );
			return;
		}

		// find all instances of mambot and put in $matches
		$matches = array();
		preg_match_all( $regex, $row->text, $matches, PREG_SET_ORDER );

		// split the text around the mambot
		$text = preg_split( $regex, $row->text );

		// count the number of pages
		$n = count( $text );

		// we have found at least one mambot, therefore at least 2 pages
		if ($n > 1) {
			$title = trim($this->params->get("title"));

			// adds heading or title to <site> Title
			if ( $title ) {
				$page_text = $page + 1;
				$row->page_title = JText::sprintf( 'Page #', $page_text );
				if ( !$page ) {
					// processing for first page
					parse_str( html_entity_decode( $matches[0][2] ), $args );

					if ( @$args['heading'] ) {
						$row->page_title = $args['heading'];
//						$row->page_title = '';
					} else {
						$row->page_title = '';
					}
				} else if ( $matches[$page-1][2] ) {
					parse_str( html_entity_decode( $matches[$page-1][2] ), $args );

					if ( @$args['title'] ) {
						$row->page_title = stripslashes( $args['title'] );
					}
				}
			}

			// reset the text, we already hold it in the $text array
			$row->text = '';

			$hasToc = $pluginParams->get( 'multipage_toc', 1 );

			if ( $hasToc ) {
				// display TOC
				createTOC_scroll( $row, $matches, $page );
			} else {
				$row->toc = '';
			}

			// page text
			if(!$showall){
				jimport('joomla.html.pagination');
				$pageNav = new JPagination( $n, $page, 1 );
	
				// page counter
				$row->text .= '<div class="pagenavcounter">';
				$row->text .= $pageNav->getPagesCounter();
				$row->text .= '</div>';
	
				$row->text .= $text[$page];
			} else {
				$row->text .= implode("",$text);
			}

			if(!$showall){
				$row->text .= '<br />';
				$row->text .= '<div class="pagenavbar">';
	
				// adds navigation between pages to bottom of text
				if ( $hasToc ) {
					createNavigation_scroll( $row, $page, $n );
				}
	
				// page links shown at bottom of page if TOC disabled
				if (!$hasToc) {
					$row->text .= $pageNav->getPagesLinks();
				}
			}
			$inbottom = trim($this->params->get("inbottom"));
			if($inbottom) $row->text .= $row->toc;
			if(!$showall){
				$row->text .= '</div><br />';
			}
		}

		return true;

	}
}



function createTOC_scroll( &$row, &$matches, &$page ) {
	global $Itemid;
	$nonseflink = 'index.php?option=com_content&view=article&id='. $row->id .'&catid='. $row->catid.'&Itemid='.$Itemid;
	//	$nonseflink = 'index.php?option=com_content&view=article&id='. $row->id .'&catid='. $row->catid;
	$link = 'index.php?option=com_content&view=article&id='. $row->id .'&catid='. $row->catid.'&Itemid='.$Itemid;
	$link = JRoute::_( $link);

	$heading = $row->title;
	// allows customization of first page title by checking for `heading` attribute in first bot
	if ( @$matches[0][2] ) {
		parse_str( html_entity_decode( $matches[0][2] ), $args );

		if ( @$args['heading'] ) {
			$heading = $args['heading'];
			//$row->title .= ' - '. $heading;
		}
	}
	$limitstart = JRequest::getVar('limitstart',0);
	// TOC Header
	$row->toc = '
	<script language="JavaScript" type="text/JavaScript">
<!--
function mosJumpMenu(selObj,restore){ //v3.0
  parent.location=selObj.options[selObj.selectedIndex].value;
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
	<table cellpadding="0" cellspacing="0" align="right">
	
		<td>
<form name="form1">
	<select name="mosSelect" onChange="mosJumpMenu(this,0)">';
//	<option value="'. $link .'">'.JText::_( 'Article Index' );

	// TOC First Page link
	$row->toc .= '
  <option value="'. $link .'">1. '. $heading."</option>";

	$i = 2;
	$args2 = array();
	foreach ( $matches as $bot ) {
//		$link = $nonseflink .'&limitstart='. ($i-1);
//		$link = JRoute::_( $link);
		$link = JRoute::_( '&showall=&limitstart='. ($i-1) );
		if  ($limitstart==$i-1) {
			$selected = " selected=true ";
		} else {
			$selected = "";
		}
		if ( @$bot[2] ) {
			parse_str( html_entity_decode( $bot[2] ), $args2 );
			if ( @$args2['title'] || @$args2['alt']) {
				$title = $args2['alt']?$args2['alt']:$args2['title'];
				$row->toc .= '
					<option value="'. $link .'" '.$selected.'>' .$i .'. '
				. stripslashes( $title );
			} else {
				$row->toc .= '
					<option value="'. $link .'" '.$selected.'>'
				.JText::sprintf( 'Page #', $i )
				;
			}
		} else {
			$row->toc .= '
				<option value="'. $link . '" '.$selected .'>'
			.JText::sprintf( 'Page #', $i );
		}
		$row->toc .= "</option>";
		$i++;
	}
	$link = JRoute::_( '&showall=1&limitstart=' );
	$showall = JRequest::getBool('showall');
	$selected = '';
	if($showall) {
		$selected = " selected=true ";
	}
	$row->toc .= '
				<option value="'. $link . '" '.$selected .'>'
			.JText::_( 'All Pages' )."</option>";
	$row->toc .= '</select></form></td></tr></table>';
}
// pour la navigation de bas de page
function createNavigation_scroll( &$row, $page, $n ) {
	global $Itemid;

	$link = 'index.php?option=com_content&view=article&id='. $row->id .'&catid='. $row->catid.'&Itemid='.$Itemid;
	//	$link = 'index.php?option=com_content&view=article&id='. $row->id .'&catid='. $row->catid;

	if ( $page < $n-1 ) {
		$link_next = $link .'&limitstart='. ( $page + 1 );
		$link_next = JRoute::_( $link_next );
		//$link_next = JRoute::_( '&limitstart='. ( $page + 1 ) );
		$next = '<a href="'. $link_next .'">' .JText::_( 'Next' ).'</a>';
	} else {
		$next = JText::_( 'Next' );
	}

	if ( $page > 0 ) {
		$link_prev = $link .'&limitstart='. ( $page - 1 );
		$link_prev = JRoute::_( $link_prev );

		$prev = '<a href="'. $link_prev .'">'. JText::_( 'Prev' ) .'</a>';
	} else {
		$prev = JText::_( 'Prev' );
	}

	$row->text .= '<div>' . $prev . ' - ' . $next .'</div>';
}