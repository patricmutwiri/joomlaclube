<?php 
/**
* pollXT Plugin for Joomla!
* @Copyright ((c) 2004 - 2009 JoomlaXT
* @ All rights reserved
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @ http://www.joomlaxt.com
* @version 2.00.01
**/
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
?>

<?php

//load the language file
$lang =& JFactory::getLanguage();
$lang->load("com_pollxt");

$event = 'onPrepareContent';
$pluginname = 'bot_pollxt';

	$mainframe->registerEvent($event, $pluginname);


	function bot_pollxt(&$row, &$params, $page=0 ) {
	
	    $pattern = "/{pollxtbot(.*?)}/s";
	    $resultpattern = "/{pollxtresultbot(.*?)}/s";
	
		// perform the replacement
		$row->text = preg_replace_callback( $pattern, 'pollxtbot_replacer', $row->text );
		$row->text = preg_replace_callback( $resultpattern, 'pollxtresultbot_replacer', $row->text );
	
		return true;
	}

function pollxtbot_replacer(&$matches) {
    global $params;
	require_once(JPATH_SITE."/components/com_pollxt/class/pollxt.frame.php");

    $pollid = trim(preg_replace("/.*?id.*?=/i", "", trim($matches[1])));
	$frame = new xtFrame();
	$frame->pos = "bot";
	$frame->pollid = $pollid;
	$frame->parameters = $params;
	$frame->task = "init";
	return $frame->get();
}

function pollxtresultbot_replacer(&$matches) {
    global $params;
	require_once(JPATH_SITE."/components/com_pollxt/class/pollxt.frame.php");

    $pollid = trim(preg_replace("/.*?id.*?=/i", "", trim($matches[1])));
	$frame = new xtFrame();
	$frame->pos = "bot";
	$frame->pollid = $pollid;
	$frame->parameters = $params;
	$frame->task = "showResult";
	return $frame->get();
  }


