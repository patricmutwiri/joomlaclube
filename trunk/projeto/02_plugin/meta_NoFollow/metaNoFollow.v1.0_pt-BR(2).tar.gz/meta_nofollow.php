<?php
/**
 * Plugin for Joomla 1.5 to insert the meta:nofollow attribute in chosen categories and sections of content.
 * Base on Michiel Bijland plg_nofollow
 * @author John Connolly
 * @package plg_meta_NoFollow
 * @version $Revision: 1.0
 * @license GNU/GPL
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/* no direct access */
defined( '_JEXEC' ) or die( 'Restricted access' );

/* register */
$mainframe->registerEvent( 'onPrepareContent', 'plgContentMetaNoFollow' );

/**
 * Ad rel="nofollow" to non host links
 */
 
function plgContentMetaNoFollow( &$row, &$params, $page=0 ){

	/* First a simple performance check to determine whether bot should process further */
	if ( JString::strpos( $row->text, 'href="' ) === false ) {
		return true;
		
	}
	$plugin =& JPluginHelper::getPlugin('content', 'meta_nofollow');
 	$pluginParams  = new JParameter( $plugin->params );
 	$sections = $pluginParams->get( 'sections','0' );
 	$categories = $pluginParams->get( 'categories','0' );
 	$articles = $pluginParams->get( 'articles' );
	$value_sec = 0;	
	  		$AcceptedSectionsArray = array();
  			$AcceptedSectionsArray = explode( ',', $sections );
			$AcceptedCategoriesArray = array();
  			$AcceptedCategoriesArray = explode( ',', $categories );
  			
  			if(( in_array($row->catid, $AcceptedCategoriesArray) != true )&&( in_array($row->sectionid, $AcceptedSectionsArray) != true )){	
  			return true;
		}
			$IgnoredArticlesArray = array();
  			$IgnoredArticlesArray = explode( ',', $articles );
			if( in_array($row->id, $IgnoredArticlesArray) == true ){
		return true;
		}
	
	
	/* parse urls */
	$regex = '/<a (.*?)href=[\"\'](.*?)\/\/(.*?)[\"\'](.*?)>(.*?)<\/a>/i';
	$row->text = preg_replace_callback($regex, 'plgParseMetaNoFollow', $row->text);
	return true;
}
	
/**
 * Get the Domain Name from the link
 */
function plgGetDomainFromLink($url){
	preg_match("/^(http:\/\/)?([^\/]+)/i", $url, $match);
	$domain = $match[2];
	preg_match("/[^\.\/]+\.[^\.\/]+$/", $domain, $match);
	return $match[0];
}

/**
 * Check if string already contains rel="nofollow" attribute
 */
function plgAlreadyNofollow($text){
	return ( preg_match("/rel=[\"\'].*?nofollow.*?[\"\']/i", $text ) ) ? true : false ;
}

/**
 * Insert the rel="nofollow" attribute
 */

function plgParseMetaNoFollow($match){
	$local	=& JFactory::getURI();

	if ( plgGetDomainFromLink($match[3]) != $local->getHost() && !plgAlreadyNofollow( $match[1] ) && !plgAlreadyNofollow( $match[4] ) ){
		return '<a href="' . $match[2] . '//' . $match[3] . '"' . $match[1] . $match[4] . ' rel="nofollow" >' . $match[5] . '</a>';
	} else {
		return '<a href="' . $match[2] . '//' . $match[3] . '"' . $match[1] . $match[4] . '>' . $match[5] . '</a>';
	}
}

?>