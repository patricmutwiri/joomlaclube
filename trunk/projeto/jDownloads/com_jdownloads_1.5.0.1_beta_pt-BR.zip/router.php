<?php
/**
* @version 1.5
* @package JDownloads
* @copyright (C) 2009 www.jdownloads.com
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*
* 
*
*/  

defined( '_JEXEC' ) or die( 'Restricted access' );
Error_Reporting(E_ERROR);

function jdownloadsBuildRoute(&$query) {
    //var_dump($query);
    $segments = array();
/*       if(isset($query['viewcategory']))
       {
                $segments[] = $query['view'];
                unset( $query['view'] );
       }
       if(isset($query['cid']))
       {
                $segments[] = $query['id'];
                unset( $query['cid'] );
       }
              if(isset($query['catid']))
       {
                $segments[] = $query['catid'];
                unset( $query['catid'] );
       }
  */
       return $segments;
     
  
}

function jdownloadsParseRoute($segments) {
     //var_dump($query);
    $vars = array();
    /* switch($segments[0])
       {
               case 'categories':
                       $vars['view'] = 'categories';
                       break;
               case 'category':
                       $vars['view'] = 'category';
                       $id = explode( ':', $segments[1] );
                       $vars['id'] = (int) $id[0];
                       break;
               case 'article':
                       $vars['view'] = 'article';
                       $id = explode( ':', $segments[1] );
                       $vars['id'] = (int) $id[0];
                       break;
       }
       */
       return $vars;
      
       

} 
?>