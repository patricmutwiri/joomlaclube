<?php defined('_JEXEC') or die('Restricted access');

echo '<div id="phocaexif" >'
.'<h2>'.JText::_('EXIF Information').':</h2>'
.'<table style="width:90%">'
.$this->info
.'</table>'
.'</div>';
