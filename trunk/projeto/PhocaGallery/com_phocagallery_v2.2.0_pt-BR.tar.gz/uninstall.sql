-- --------------------------------------------------------
--
-- Table structure for table `#__phocagallery`
--
DROP TABLE IF EXISTS `#__phocagallery`;
-- --------------------------------------------------------
-- --------------------------------------------------------
--
-- Table structure for table `#__phocagallery_categories`
--
DROP TABLE IF EXISTS `#__phocagallery_categories`;
-- --------------------------------------------------------