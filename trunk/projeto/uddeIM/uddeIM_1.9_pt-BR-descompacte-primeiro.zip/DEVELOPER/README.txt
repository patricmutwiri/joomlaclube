uddeim.api.php
================================================================
This is an experimental interface for providing
udde Intstant Messages to 3rd party components.
To use it copy it into /components/com_uudeim.

This file declares a class uddeIMAPI that provides following
functions:

------------------------------------------------------------
Create an instance
------------------------------------------------------------
require_once("uddeim.api");
$uddeim = new uddeIMAPI();

------------------------------------------------------------
bool $uddeim->isInboxLimitReached($userid);
------------------------------------------------------------
-> userid
<- true if the Inbox limit has been reached.

------------------------------------------------------------
void $uddeim->sendNewMessage($fromid, $toid, $message, 
                   $sendnotification=0, $updatelastsent=0);
------------------------------------------------------------
-> fromid
-> toid
-> message
-> sendnotifications
-> updatelastsent
<- void

Special features supported:
- autoforward

Special features not supported:
- copy2me
- autoresponder
