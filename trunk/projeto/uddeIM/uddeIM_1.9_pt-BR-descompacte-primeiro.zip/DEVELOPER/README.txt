uddeim.api.php
================================================================
This is an experimental interface for providing
udde Intstant Messages to 3rd party components.

In the FAQ document you will find a complete guide 
how to use the API.
