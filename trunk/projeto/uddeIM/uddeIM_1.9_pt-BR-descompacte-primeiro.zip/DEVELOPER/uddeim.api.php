<?php
// ********************************************************************************************
// Title          udde Instant Messages (uddeIM)
// Description    Instant Messages System for Mambo 4.5 / Joomla 1.0 / Joomla 1.5
// Author         � 2007-2008 Stephan Slabihoud
// License        This is free software and you may redistribute it under the GPL.
//                uddeIM comes with absolutely no warranty.
//                Use at your own risk. For details, see the license at
//                http://www.gnu.org/licenses/gpl.txt
//                Other licenses can be found in LICENSES folder.
//                Redistributing this file is only allowed when keeping the header unchanged.
// ********************************************************************************************

if (!(defined('_JEXEC') || defined('_VALID_MOS'))) { die( 'Direct Access to this location is not allowed.' ); }

$uddeim_isadmin = 0;
if ( defined( 'JPATH_ADMINISTRATOR' ) ) {
	require_once(JPATH_SITE.'/components/com_uddeim/uddeimlib15.php');
} else {
	global $mainframe;
	require_once($mainframe->getCfg('absolute_path').'/components/com_uddeim/uddeimlib10.php');
}
require_once( uddeIMgetPath('admin')."/config.class.php");
require_once( uddeIMgetPath('admin')."/admin.shared.php");
require_once( uddeIMgetPath('user')."/includes.php");
require_once( uddeIMgetPath('user')."/includes.db.php");
require_once( uddeIMgetPath('user')."/crypt.class.php");

class uddeIMAPI {
  
	var $config;
	var $absolute_path;
	var $pathtoadmin;
	var $pathtouser;
	var $pathtosite;

	function uddeIMAPI() {
		$this->config 		 = new uddeimconfigclass();
		$this->absolute_path = uddeIMgetPath('absolute_path');
		$this->pathtoadmin   = uddeIMgetPath('admin');
		$this->pathtouser    = uddeIMgetPath('user');
		$this->pathtosite    = uddeIMgetPath('live_site');
		uddeIMloadLanguage($this->pathtoadmin, $this->config);
	}

	function isInboxLimitReached($userid) {
		if($this->config->inboxlimit) {
			if ($this->config->allowarchive) {
				$total = uddeIMgetInboxArchiveCount($userid);
			} else {
				$total = uddeIMgetInboxCount($userid);
			}
			$gid=uddeIMgetGID((int)$userid);
			if($total>$this->config->maxarchive && $gid!=24 && $gid!=25) {
				return true;
			}
		}
		return false;
	}
	
	function sendNewMessage($fromid, $toid, $message, $sendnotification=0, $updatelastsent=0) {

		if ($this->config->cryptmode>=1)
			$savemessage = strip_tags($message);
		else
			$savemessage = addslashes(strip_tags($message));

		$date  = uddetime($this->config->timezone);
		$replyid = 0;
		$cryptmode = $this->config->cryptmode;
		$insID = uddeIMsaveRAWmessage($fromid, $toid, $replyid, $savemessage, $date, $this->config, $cryptmode);

		if ($updatelastsent) {
			if (!uddeIMexistsEMN((int)$fromid))
				uddeIMinsertEMNdefaults((int)$fromid, $this->config);
			uddeIMupdateEMNlastsent($fromid, $date);
		}

		if ($sendnotification) {
			// Check if E-Mail notification or popups are enabled by default, if so create a record for the receiver.
			// Note: Not necessary for "copy to myself" sind the record for the current user has been set at the very beginning...
			if ($this->config->notifydefault>0 || $this->config->popupdefault>0 || $this->config->pubfrontenddefault>0 || $this->config->autoresponder>0 || $this->config->autoforward>0) {
				if (!uddeIMexistsEMN($toid))
					uddeIMinsertEMNdefaults($toid, $this->config);
			}
		}

		// get the group ID of the recipient
		$gid = uddeIMgetGID((int)$toid);

		// ##################################################################################################
		// autoforward code
		// ##################################################################################################
		if ($this->config->autoforward==1 || 
		   ($this->config->autoforward==2 && ($my_gid==24 || $my_gid==25)) ||
		   ($this->config->autoforward==3 && in_array($my_gid,array(19,20,21,23,24,25)))) {
			$ison = uddeIMgetEMNautoforward($toid);						// recipient has autoforward enabled
			if ($ison==1) {
				$autoforwardid = uddeIMgetEMNautoforwardid($toid);	// new recipient

				if (uddeIMgetUserExists($autoforwardid)) {
					if (!uddeIMgetUserBlock($autoforwardid)) {
						$forwardheader="

[i]("._UDDEIM_THISISAFORWARD.uddeIMgetNameFromID($toid, $this->config).")[/i]";
						$savemessagecopy = $savemessage.$forwardheader;

						$insIDforward = uddeIMsaveRAWmessage($fromid, $autoforwardid, 0, $savemessagecopy, $date, $this->config, $this->config->cryptmode, "");
					}
				}
			}
		}

		// ##################################################################################################
		// copy to myself?
		// ##################################################################################################

		// nothing to do

		// ##################################################################################################
		// autoresponder
		// ##################################################################################################

		// nothing to do

		// ##################################################################################################
		// email notification
		// ##################################################################################################

		if ($sendnotification) {
			$currentlyonline = uddeIMisOnline($toid);

			if ($this->config->cryptmode>=1) {
				$email = stripslashes($savemessage);
			} else {
				$email = stripslashes(stripslashes($savemessage));
			}
			
			if($this->config->allowemailnotify==1) {
				$ison = uddeIMgetEMNstatus($toid);
				if (($ison==1) || ($ison==2 && !$currentlyonline) || $ison==10 || ($ison==20 && !$currentlyonline))  {
					uddeIMdispatchEMN($insID, $item_id, $cryptmode, $fromid, $toid, $email, 0, $this->config);
				}
			} elseif($this->config->allowemailnotify==2) {
				if ($gid==24 || $gid==25) {
					$ison = uddeIMgetEMNstatus($toid);
					if (($ison==1) || ($ison==2 && !$currentlyonline) || $ison==10  || ($ison==20 && !$currentlyonline))  {
						uddeIMdispatchEMN($insID, $item_id, $cryptmode, $fromid, $toid, $email, 0, $this->config);
					}
				}
			}
		}
	}
}
