This folder contains extensions and plugins which have
been kindly provided by uddeIM users.

Please don't ask me for support. Usually you will find 
an URL or email within the extension so you can contact
the author directly.

Thanks,
Stephan Slabihoud
