JoomSEF plugin by Denis Dulici
------------------------------

For updates visit the authors website!
