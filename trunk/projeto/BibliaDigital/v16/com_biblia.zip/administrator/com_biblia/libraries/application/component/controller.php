<?php
/**
 * @version		$Id$
 * @package		com_games
 * @subpackage	Libraries
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controller');

class BController extends JController
{
	/**
	 * Method to get a singleton controller instance.
	 *
	 * @param	string	The prefix for the controller.
	 * @param	string	Default view if none is set
	 * @param	array	An array of optional constructor options.
	 * @return	Object	JController derivative class
	 */
	public static function getInstance($prefix, $default = null, $config = array())
	{
		static $instance;

		if (!empty($instance)) {
			return $instance;
		}

		// Get the environment configuration.
		$basePath	= isset($config['base_path']) ? $config['base_path'] : JPATH_COMPONENT;
		$format		= JRequest::getWord('format');
		$default	= ($default) ? $default : $prefix;
		$command	= JRequest::getCmd('task', JRequest::getCmd('view', $default).'.display');
		$config['default_view'] = isset($config['default_view']) ? $config['default_view'] : $default;

		// Check for array format.
		if (is_array($command)) {
			$command = JFilterInput::clean(array_pop(array_keys($command)), 'cmd');
		} else {
			$command = JFilterInput::clean($command, 'cmd');
		}

		// Check for a controller.task command.
		if (strpos($command, '.') !== false) {
			// Explode the controller.task command.
			list($type, $task) = explode('.', $command);

			// Reset the task without the contoller context.
			JRequest::setVar('task', $task);
		}
		else {
			// Default controller.
			$type	= $default;
			$task	= $command;
		}

		// Define the controller filename and path.
		$file	= self::createFileName('controller', array('name' => $type, 'format' => $format));
		$path	= $basePath.'/controllers/'.$file;

		// Get the controller class name.
		$class = ucfirst($prefix).'Controller'.ucfirst($type);

		// Include the class if not present.
		if (!class_exists($class)) {
			// If the controller file path exists, include it.
			if (file_exists($path)) {
				require_once $path;
			} else {
				JError::raiseError(1056, JText::sprintf('JLIB_APPLICATION_ERROR_INVALID_CONTROLLER', $type, $format), $type);
			}
		}

		// Instantiate the class.
		if (class_exists($class)) {
			$instance = new $class($config);
		} else {
			JError::raiseError(1057, JText::sprintf('JLIB_APPLICATION_ERROR_INVALID_CONTROLLER_CLASS', $class), $class);
		}

		return $instance;
	}
}