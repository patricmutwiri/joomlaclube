window.addEvent('domready',function(){

	/*
	 * Valida��o para o formulario de busca
	 */
	Form.Validator.add('validate-positive', {
	    errorMsg: 'The value must be positive!',
	    test: function(field){
	        return field.get('value').test(/^\d+$/,'i');
	    }
	});
	var validator = new Form.Validator('biblia_form');

	/*
	 * Excluir o valor 'ALL' da lista que limita os resultados
	 */
	var option_all;
	document.id('limit').getChildren().each(function(e){
		if(e.value == '0') {
			option_all = e;
		}
	});
	option_all.destroy();

	/*
	 * comportamento para o bot�o buscar(o primeiro bot�o)
	 */
	document.id('button_buscar').getChildren().addEvent('click', function(e){
		var select = this.form.livro, capitulo = this.form.capitulo,
		versiculo = this.form.versiculo, href = new URI(location.href);
		var livro, scheme, host;
		select.getChildren().each(function(option){
			if(option.value == select.value) livro = option.get('text');
		});
		livro = livro.replace(/ /gi, '+');

		scheme = href.get('scheme');
		host = href.get('host');
		href = scheme+'://'+host+this.form.get('action');
		if(livro) {
			href += '/'+livro;
		}
		href = new URI(href);
		validator.validate();
		if(validator.validateField(capitulo)) {
			href.setData('capitulo', capitulo.value);
		}
		if(validator.validateField(versiculo)) {
			href.setData('versiculo', versiculo.value);
		}
		location.href = href.toString();
	});

	/*
	 * comportamento para o bot�o buscar(o segundo bot�o)
	 */
	document.id('filter_search_button').addEvent('click', function(){
		var q = this.form.q.value, search_type_1 = this.form.search_type_1, search_type_2 = this.form.search_type_2, href = new URI(location.href);
		if(search_type_1.get('checked')){
			var data = href.get('data');
			delete data.search_type;
			href.set('data', data);
		}
		if(search_type_2.get('checked')){
			href.setData('search_type', "1");
		}
		if(q){
			href.setData('q', q);
			location.href = href.toString().replace(/%20/gi, '+');;
		}
	});

	// Comportamento para o bot�o Limpar
	document.id('filter_search_clear_button').addEvent('click', function(){
		var href = new URI(location.href), data = href.get('data');
		if('search_type' in data){
			delete data.search_type;
		}
		if('q' in data){
			delete data.q;
		}
		href.set('data', data);
		href.go();
	});

	/* Corre��o para a lista que limita a quantidade de resultados
	 * a fun��o padr�o exclui o livro da url
	 */
	document.id('limit').set('onchange', 'javascript:void(0);');
	document.id('limit').addEvent('change', function(){
		this.form.set('action', location.href);
		this.form.submit();
	});

});