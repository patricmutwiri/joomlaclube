<?php
// No direct access
defined('_JEXEC') or die;

class BibliaControllerAll extends JController
{

}