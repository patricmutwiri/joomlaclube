<?php
// no direct access
defined('_JEXEC') or die;

JHtml::_('behavior.framework', true);
JHtml::_('stylesheet', 'biblia/biblia.css', array(), true);
JHtml::_('script', 'biblia/biblia.js', false, true);

?>
<div id="biblia" class="<?php echo $this->params->get('pageclass_sfx');?>">
	<?php if ($this->params->get('show_page_heading', 1)) : ?>
	<h1>
		<?php echo $this->escape($this->params->get('page_heading', JText::_('COM_BIBLIA'))); ?>
	</h1>
	<?php endif;?>


	<form method="post" action="<?php echo JRoute::_('index.php?option=com_biblia');?>" id="biblia_form">
		<div id="filters">
			<div id="filter_livro">
				<label for="livro"><?php echo JText::_('COM_BIBLIA_LIVRO');?></label>
				<select name="livro" class="inputbox">
				<?php echo JHtml::_('select.options', $this->livros, 'value', 'text', $this->state->get('filter.livro'));?>
				</select>
			</div>

			<div id="filter_capitulo">
				<label for="capitulo"><?php echo JText::_('COM_BIBLIA_CAP');?></label>
				<input type="text" name="capitulo" class="validate-positive" value="<?php echo ($this->state->get('filter.capitulo') ? $this->state->get('filter.capitulo') : '');?>">
			</div>

			<div id="filter_versiculo">
				<label for="versiculo"><?php echo JText::_('COM_BIBLIA_VERS');?></label>
				<input type="text" name="versiculo" class="validate-positive" value="<?php echo ($this->state->get('filter.versiculo') ? $this->state->get('filter.versiculo') : '');?>">
			</div>

			<div id="button_buscar">
				<input type="button" value="<?php echo JText::_('COM_BIBLIA_BUSCAR');?>" />
			</div>

			<div class="clr"></div>

			<div id="filter_search">
				<p><?php echo JText::_('COM_BIBLIA_FRASE_EXATA');?></p>
				<label for="search_type_1"><?php echo JText::_('JNO');?></label>
				<input type="radio" name="search_type" id="search_type_1" value="0" <?php if(!$this->state->get('filter.search_type', 0)) echo 'checked="checked" ';?>class="inputbox">
				<label for="search_type_2"><?php echo JText::_('JYES');?></label>
				<input type="radio" name="search_type" id="search_type_2" value="1" <?php if($this->state->get('filter.search_type', 0)) echo 'checked="checked" ';?>class="inputbox">

				<br/>

				<p><?php echo JText::_('COM_BIBLIA_PALAVRA');?></p>
				<input type="text" name="q" value="<?php echo $this->state->get('filter.search');?>" />

				<input type="button" id="filter_search_button" value="<?php echo JText::_('COM_BIBLIA_BUSCAR');?>" />
				<input type="button" id="filter_search_clear_button" value="<?php echo JText::_('COM_BIBLIA_LIMPAR');?>" />
			</div>
			<input type="hidden" name="option" value="com_biblia" />
		</div>

		<div class="clr"></div>

		<table id="versiculos">
		<tbody>
		<?php foreach ($this->items as $item) : ?>
			<tr class="versiculo">
				<td class="livro">
					<a href="<?php echo JRoute::_('index.php?option=com_biblia&livro='.$item->livro_id)?>" title="<?php echo $item->livro_desc; ?>">
						<?php echo $item->livro; ?>
					</a>
				</td>
				<td class="cap-vers">
					<a href="<?php echo JRoute::_('index.php?option=com_biblia&capitulo='.$item->capitulo.'&versiculo='.$item->versiculo)?>" title="">
						<?php echo $item->capitulo.':'.$item->versiculo; ?>
					</a>
				</td>
				<td class="palavra"><?php echo $item->palavra; ?></td>
			</tr>
		<?php endforeach;?>
		</tbody>
		</table>

		<div class="clr"></div>

		<div id="results_number" ><p><?php echo JText::sprintf('COM_BIBLIA_RESULTS_NUMBER', $this->pagination->total);?><p></div>

		<div class="clr"></div>

		<div id="pagination">
			<div class="display-limit">
				<?php echo JText::_('JGLOBAL_DISPLAY_NUM'); ?>&#160;
				<?php echo $this->pagination->getLimitBox(); ?>
			</div>

			<div class="clr"></div>

			<div class="pagination">
			 	<p class="counter">
					<?php echo $this->pagination->getPagesCounter(); ?>
				</p>

				<?php echo $this->pagination->getPagesLinks(); ?>
			</div>
		</div>

		<div class="clr"></div>
	</form>
</div>
