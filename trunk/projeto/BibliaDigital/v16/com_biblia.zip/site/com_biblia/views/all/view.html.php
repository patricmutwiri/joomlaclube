<?php
// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

class BibliaViewAll extends JView
{
	public function display($tpl = null)
	{
		$this->state	= $this->get('State');
		$this->params	= $this->state->params;
		$this->items	= $this->get('Items');
		$this->livros	= $this->get('Livros');
		$this->pagination	= $this->get('Pagination');

		return parent::display($tpl);
	}
}