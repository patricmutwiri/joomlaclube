<?php
/**
 * @version		$Id: router.php 20233 2011-01-10 03:51:26Z dextercowley $
 * @package		Joomla
 * @copyright	Copyright (C) 2005 - 2011 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

jimport('joomla.application.categories');

function BibliaBuildRoute(&$query)
{
	static $livros;
	$segments = array();
	if(isset($query['livro']))
	{
		$livro = (int)$query['livro'];
		if(!isset($livros[$livro]))
		{
			$db = JFactory::getDbo();
			$db->setQuery('SELECT a.livro_desc FROM #__biblia_livros AS a WHERE a.id = '. $livro );
			$result = $db->loadResult();
		}else{
			$result = $livros[$livro];
		}
		if($result)
		{
			$livros[$livro] = $result;
			$segments[] = str_replace(' ', '+', $result);
			unset($query['livro']);
		}
	}
	unset($query['view']);
	return $segments;
}


function BibliaParseRoute($segments)
{
	// Initialise variables
	$db = JFactory::getDbo();

	// There's only one view
	$vars['view'] = 'all';

	// Get the id
	$db->setQuery('SELECT a.id FROM #__biblia_livros AS a WHERE a.livro_desc = '. $db->quote($segments[0]));
	$vars['livro'] = $db->loadResult();

	return $vars;
}
