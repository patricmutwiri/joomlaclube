<?php
// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.modellist');

class BibliaModelAll extends JModelList
{
	protected $context = 'com_biblia';

	/**
	 * Method to auto-populate the model state.
	 */
	protected function populateState()
	{
		// Initiliase variables.
		$app	= JFactory::getApplication();

		// Load the Menu Item params
		$params = new JRegistry();
		if ($menu = $app->getMenu()->getActive()) {
			$params->loadString($menu->params);
		}
		$this->setState('params', $params);

		// Filtro para livro
		$livro = JRequest::getInt('livro', 1);
		$this->setState('filter.livro', $livro);

		// Filtro para capitulo
		$capitulo = JRequest::getInt('capitulo', 0);
		$this->setState('filter.capitulo', $capitulo);

		// Filtro para versiculo
		$versiculo = JRequest::getInt('versiculo', 0);
		$this->setState('filter.versiculo', $versiculo);

		// Filtro para tipo de busca
		$search_type = (bool) JRequest::getInt('search_type', 0);
		$this->setState('filter.search_type', $search_type);

		// Filtro para busca
		$search = JRequest::getString('q', '');
		$this->setState('filter.search', $search);

		// List state information.
		parent::populateState('l.livro_seq, a.capitulo, a.versiculo', 'ASC');

		// N�o � permitido exibir mais de 100 versiculos
		$value = $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');
		$limit = ($value == 0 || $value > 100) ? 100 : $value;
		$this->setState('list.limit', $limit);
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * @param	string	$id	A prefix for the store id.
	 * @return	string
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id	.= ':'.$this->getState('filter.livro');
		$id	.= ':'.$this->getState('filter.capitulo');
		$id	.= ':'.$this->getState('filter.versiculo');
		$id	.= ':'.$this->getState('filter.search_type');
		$id	.= ':'.$this->getState('filter.search');

		return parent::getStoreId($id);
	}

	/**
	 *
	 *
	 * @return	string
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db = $this->getDbo();
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select',
				'l.livro, a.capitulo, a.versiculo, a.palavra, l.livro_desc, l.livro_seq, l.id AS livro_id'
			)
		);
		$query->from('#__biblia_versiculos AS a');

		// Join over the books
		$query->leftjoin('#__biblia_livros AS l ON l.livro_seq = a.livroseq');

		// Filter by books
		$livro = (int) $this->getState('filter.livro', 1);
		switch ($livro) {
			case 1:
				// do nothing
				break;
			case 2:
				$query->where('a.testamento = '.$db->quote('O'));
				break;
			case 3:
				$query->where('a.testamento = '.$db->quote('N'));
				break;
			default:
				$query->where('l.id = '.$db->quote($livro));
				break;
		}

		// Filtrar por capitulo
		$capitulo = $this->getState('filter.capitulo', 0);
		if($capitulo)
		{
			$query->where('a.capitulo = '.$db->quote($capitulo));
		}

		// Filtrar por versiculo
		$versiculo = $this->getState('filter.versiculo', 0);
		if($versiculo)
		{
			$query->where('a.versiculo >= '.$db->quote($versiculo));
		}

		// Filtrar por busca
		$search_type	= (bool) $this->getState('filter.search_type', false);
		$search			= $this->getState('filter.search', '');
		if ($search_type && $search != '')
		{
			$query->where('LOWER(a.palavra) LIKE "%'.$db->getEscaped(trim($search), true).'%"');
		}
		elseif($search != '')
		{
			$words = explode(' ', $search);

			foreach ($words as $word)
			{
				$word  = $db->Quote( '%'.$db->getEscaped( $word, true ).'%', false );
				$query->where('LOWER(a.palavra) LIKE '.$word);
			}
		}

		// Group by id
		$query->group('a.id');

		// Add the list ordering clause.
		$query->order($db->getEscaped($this->getState('list.ordering', 'l.livro_seq, a.capitulo, a.versiculo')).' '.$db->getEscaped($this->getState('list.direction', 'ASC')));

		//echo nl2br(str_replace('#__','jos_',$query));
		return $query;
	}

	public function getLivros()
	{
		// Create a new query object.
		$db = $this->getDbo();
		$query = $db->getQuery(true);

		$query->select('id AS value, livro_desc AS text');
		$query->from('#__biblia_livros');

		$db->setQuery($query);
		return $db->loadAssocList();
	}
}