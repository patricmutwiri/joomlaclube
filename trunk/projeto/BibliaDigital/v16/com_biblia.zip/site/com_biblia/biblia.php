<?php
// No direct access
defined('_JEXEC') or die;

// Include dependencies
require_once JPATH_COMPONENT_ADMINISTRATOR.'/libraries/application/component/controller.php';

$controller = BController::getInstance('Biblia', 'all');
$controller->execute(JRequest::getCmd('task'));
$controller->redirect();