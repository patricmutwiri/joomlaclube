<?php
/**
* Tab to display recently posted classified ads in the AdsManager component in a Community Builder profile
* Author: Thomas PAPIN (thomas.papin@free.fr)
*/

class AdsManagerTab extends cbTabHandler {

	function getAdsSessionsTab() {
		$this->cbTabHandler();
		}
		
  function getLangDefinition($text) {
		if(defined($text)) $returnText = constant($text); 
		else $returnText = $text;
		return $returnText;
	}
			
  function getDisplayTab($tab,$user,$ui) {
	global $database,$mosConfig_live_site, $mosConfig_absolute_path,$my,$mosConfig_lang,$mainframe;
	// Language:
	if (file_exists($mosConfig_absolute_path .'/components/com_adsmanager/lang/lang_' . $mosConfig_lang . '.php'))
	    include_once( $mosConfig_absolute_path .'/components/com_adsmanager/lang/lang_' . $mosConfig_lang . '.php' );
	else
		include_once( $mosConfig_absolute_path .'/components/com_adsmanager/lang/lang_english.php' );
	
	require_once($mosConfig_absolute_path .'/components/com_adsmanager/adsmanager.html.php');
	
	$mainframe->addCustomHeadTag('<link rel="stylesheet" href="'.$mosConfig_live_site.'/components/com_adsmanager/css/adsmanager.css" type="text/css" />');
	
	$params = $this->params;
	$return="";

	$itemid = intval($params->get('itemid', mosGetParam( $_GET, 'Itemid', 0 )));

    $database->setQuery("SELECT a.*, p.name as parent, p.id as parentid, c.name as cat, c.id as catid, u.username as user ".
						"FROM #__adsmanager_ads as a ".
						"LEFT JOIN #__adsmanager_adcat as adcat ON adcat.adid = a.id ".
						"LEFT JOIN #__users as u ON a.userid = u.id ".
						"LEFT JOIN #__adsmanager_categories as c ON adcat.catid = c.id ".
						"LEFT JOIN #__adsmanager_categories as p ON c.parent = p.id ".
						"WHERE a.userid =".$user->id." AND a.published = 1 AND c.published = 1 ".
						"GROUP BY a.id ORDER BY date_created DESC,id DESC");
    
	$ads = $database->loadObjectList();
	
	$database->setQuery("SELECT c.* ".
						"FROM #__adsmanager_columns as c ".
						"WHERE 1 ".
						"ORDER BY c.ordering ");

	$columns = $database->loadObjectList();
	
	$database->setQuery( "SELECT c.* FROM #__adsmanager_fields AS c ".
						 "WHERE c.columnid != -1 AND c.published = 1 ORDER by c.columnorder,c.fieldid" );

	$fields = $database->loadObjectList();
	
	// establish the hierarchy of the menu
	$fColumn = array();
	// first pass - collect children
	foreach ($fields as $f ) {
		$pt 	= $f->columnid;
		$list 	= @$fColumn[$pt] ? $fColumn[$pt] : array();
		array_push( $list, $f );
		$fColumn[$pt] = $list;
	}
	
	//get value fields
	$database->setQuery( "SELECT * FROM #__adsmanager_field_values ORDER by ordering ");
	$fieldvalues = $database->loadObjectList();
	if ($database -> getErrorNum()) {
		echo $database -> stderr();
		return false;
	}
	
	$field_values = array();
	// first pass - collect children
	foreach ($fieldvalues as $v ) {
		$pt 	= $v->fieldid;
		$list 	= @$field_values[$pt] ? $field_values[$pt] : array();
		array_push( $list, $v );
		$field_values[$pt] = $list;
	}
	
	// get configuration
	$database->setQuery( "SELECT * FROM #__adsmanager_config");
	$confs = $database->loadObjectList();
	if ($database -> getErrorNum()) {
		echo $database -> stderr();
		return false;
	}
	
	$return .='<div align="center" class="adsmanager_write">';
	$link_write_ad = sefRelToAbs("index.php?option=com_adsmanager&amp;page=write_ad&amp;Itemid=$itemid");
	$link_show_rules = sefRelToAbs("index.php?option=com_adsmanager&amp;page=show_rules&amp;Itemid=$itemid");
	$link_show_all = sefRelToAbs("index.php?option=com_adsmanager&amp;page=show_all&amp;Itemid=$itemid");
		
	$return .='<a href="'.$link_write_ad.'">'.ADSMANAGER_MENU_WRITE.'</a> | ';
	$return .='<a href="'.$link_show_all.'">'.ADSMANAGER_MENU_ALL_ADS.'</a> | ';
	$return .='<a href="'.$link_show_rules.'">'.ADSMANAGER_MENU_RULES.'</a>';	
	$return .='</div><br />';
	
	$nb_images = $confs[0]->nb_images;
	if ( file_exists( $mosConfig_absolute_path . "/components/com_paidsystem/api.paidsystem.php")) 
	{
		require_once($mosConfig_absolute_path . "/components/com_paidsystem/api.paidsystem.php");
	}

	if (function_exists("getMaxPaidSystemImages"))
	{
		$nb_images += getMaxPaidSystemImages();
	}
	
	if (count($ads> 0)) 
	{
		$return .='<table class="adsmanager_table">';
		$return .='<tr>';
		$return .='<th>'.ADSMANAGER_AD.'</th>';
		foreach($columns as $col)
		{
			eval("\$str = \$col->name;");
			$return .="<th>".getLangDefinition($str)."</th>";
		}	  
		$return .='<th>'.ADSMANAGER_DATE.'</th>';
		$return .='</tr>';
				
		foreach($ads as $row) {	
			$linkTarget = sefRelToAbs( "index.php?option=com_adsmanager&amp;page=show_ad&amp;adid=".$row->id."&amp;catid=".$row->catid."&amp;Itemid=".$itemid);
			$return.="<tr>";
			$return.='<td class="adsmanager_table_description">';
			$ok = 0;$i=1;
			while(!$ok)
			{
				if ($i < $nb_images + 1)
				{
					$ext_name = chr(ord('a')+$i-1);
					$pic = $mosConfig_absolute_path."/images/com_adsmanager/ads/".$row->id.$ext_name."_t.jpg";
					if (file_exists( $pic)) 
					{
						$return.="<a href='".$linkTarget."'><img src='".$mosConfig_live_site."/images/com_adsmanager/ads/".$row->id.$ext_name."_t.jpg' alt='".htmlentities(stripslashes($row->ad_headline),ENT_QUOTES)."' /></a>";
						$ok = 1;
					}
				}
				else
				{
					$return.="<a href='".$linkTarget."'><img src='".$mosConfig_live_site."/components/com_adsmanager/images/nopic.gif' alt='nopic' /></a>"; 
					$ok = 1;
				}    
				$i++;   	
			}
			$return.="<div>";
			$return.="<h2>";
			$return.='<a href="'.$linkTarget.'">'.stripslashes($row->ad_headline).'</a>';
			$return.='<span class="adsmanager_cat">('.$row->parent." / ".$row->cat.")</span>";
			$return.='</h2>'; 
			$row->ad_text = str_replace ('<br />'," ",stripslashes($row->ad_text));
			$af_text = htmlspecialchars (substr($row->ad_text, 0, 100)."...");
			$return.=$af_text;
			$return.='</div>';
			
			if ($my->id == $row->userid)
			{
				$return.='<div>';
				$target = sefRelToAbs("index.php?option=com_adsmanager&amp;page=write_ad&amp;adid=".$row->id."&amp;Itemid=".$itemid);
				$return.="<a href='".$target."'>".ADSMANAGER_AD_EDIT."</a>";
				$return.="&nbsp;";
				$target = sefRelToAbs("index.php?option=com_adsmanager&amp;page=delete_ad&amp;adid=".$row->id."&amp;Itemid=".$itemid);
				$return.="<a href='".$target."'>".ADSMANAGER_AD_DELETE."</a>";
				$return.='</div>';
			}
			$return.='</td>';
			if(isset($columns[0]))
			{
			foreach($columns as $col) {
				$return.='<td class="center">';
				if (isset($fColumn[$col->id][0]))
				{
				foreach($fColumn[$col->id] as $field)
				{
					$name = $field->name;
					$value = "\$row->".$field->name;
					eval("\$value = \"$value\";");
					switch($field->type)
					{
						case 'checkbox':
							if ($value == 1)
							{
								if (@$field->title)
									$str = $this->getLangDefinition($field->title);
								$return.= $str."<br />";
							}		
							break;
							
						case 'multicheckbox':
							for($i=0,$nb=count($field_values[$field->fieldid]);$i < $nb ;$i++)
							{
								$fieldvalue = @$field_values[$field->fieldid][$i]->fieldvalue;
								$fieldtitle = @$field_values[$field->fieldid][$i]->fieldtitle;
								if (strpos($value, $fieldvalue) !== false)
								{	
									if (@$fieldtitle)
										$str = $this->getLangDefinition($fieldtitle);
									$return.= $str."<br />";
								}
							}
							break;
			
						case 'select':
							foreach($field_values[$field->fieldid] as $v)
							{
								if ($value == $v->fieldvalue)
								{
									if (@$v->fieldtitle)
										$str =  $this->getLangDefinition($v->fieldtitle);
									$return.= $str."<br />";
								}
							}
							break;
			
						case 'multiselect':
							foreach($field_values[$field->fieldid] as $v)
							{
								if (strpos($value, ",".$v->fieldvalue.",") === false)
								{
								}
								else
								{
									if (@$v->fieldtitle)
										$str =  $this->getLangDefinition($v->fieldtitle);
									$return.= $str."<br />";
								}
							}
							break;
						
						case 'emailaddress':
							switch($email_display) {
								case 2:
									$emailForm = sefRelToAbs("index.php?option=$option&amp;page=show_email_form&amp;adid=".$row->id."&amp;Itemid=".$itemid);
									$return.= '<a href="'.$emailForm.'">'.ADSMANAGER_EMAIL_FORM.'</a><br />';
									break;
								case 1:
									echo adsmanager_html::Txt2Png($value,$option);
									break;
								default:
									echo ADSMANAGER_FORM_EMAIL.": <a href='mailto:".$value."'>".$value."</a>";
									break;
							
							}break;
						
						case 'textarea':
						case 'number':
						case 'text':
							$return.= $value."<br />";
							break;
						case 'price':
							if ($value != "")
								$return.= sprintf(ADSMANAGER_DEVICE,$value);
							break;
						case 'radio':	
							for($i=0,$nb=count($field_values[$field->fieldid]);$i < $nb ;$i++)
							{
								$fieldvalue = @$field_values[$field->fieldid][$i]->fieldvalue;
								$fieldtitle = @$field_values[$field->fieldid][$i]->fieldtitle;
								if ($value == $fieldvalue)
									$return.=  $this->getLangDefinition($fieldtitle)."<br />";
							}
							break;
					}
				}
				}
				$return.="</td>";
		    }
		    }
			$return.='<td class="center">';

			$date = $row->date_created;
			if (defined('ADSMANAGER_DATE_FORMAT_LC'))
				$format = ADSMANAGER_DATE_FORMAT_LC;
			else
				$format = _DATE_FORMAT_LC;
			
			if ( $date && ereg( "([0-9]{4})-([0-9]{2})-([0-9]{2})", $date, $regs ) ) {
				$date = mktime( 0, 0, 0, $regs[2], $regs[3], $regs[1] );
				$date = $date > -1 ? strftime( $format, $date) : '-';
			}
			
		    $return.=$date;
		    $return.= "<br/>".sprintf(ADSMANAGER_VIEWS,$row->views); 
			$return.="</td>";
			$return.="</tr>";
		}
		$return.="</table>";
	}
	else
	{
		$return.=ADSMANAGER_NOENTRIES; 
	}
	
	return $return;
  }
}	
?>