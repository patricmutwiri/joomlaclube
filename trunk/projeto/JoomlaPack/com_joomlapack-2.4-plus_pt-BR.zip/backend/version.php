<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('JPSPECIALEDITION', true);
define('_JP_VERSION', '2.4');
define('_JP_DATE', '2009-12-05');