DROP TABLE IF EXISTS `#__jp_profiles`;
DROP TABLE IF EXISTS `#__jp_exclusion`;
DROP TABLE IF EXISTS `#__jp_inclusion`;
DROP TABLE IF EXISTS `#__jp_registry`;
DROP TABLE IF EXISTS `#__jp_temp`;
DROP TABLE IF EXISTS `#__jp_stats`;
