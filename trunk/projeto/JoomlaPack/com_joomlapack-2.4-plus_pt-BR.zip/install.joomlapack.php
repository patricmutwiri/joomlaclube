<?php
/**
 * @package JoomlaPack
 * @copyright Copyright (C) 2009 JoomlaPack Developer. All rights reserved.
 *
 * Modelled after the work done by RocketWerx
 */

// no direct access
defined('_JEXEC') or die('Restricted access');
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

// Schema modification -- BEGIN

// Add "multipart" column to stats table
$db =& JFactory::getDBO();
$sql = "ALTER TABLE ".$db->nameQuote('#__jp_stats')." ADD ".
	$db->nameQuote('multipart')." INT NOT NULL DEFAULT 0 AFTER ".$db->nameQuote('absolute_path');
$db->setQuery($sql);
$db->query(); // This might fail with error 1060, if the column already exists, but I don't really care!

// Schema modification -- END

class Status {
	var $STATUS_FAIL = 'Failed';
	var $STATUS_SUCCESS = 'Success';
	var $infomsg = array();
	var $errmsg = array();
	var $status;
}

$db =& JFactory::getDBO();
$install_status = array();

// Install mod_jpadmin
$module_installer = new JInstaller;
$status = new Status();
$status->status = $status->STATUS_FAIL;
if($module_installer->install(dirname(__FILE__).DS.'mod_jpadmin') )
{
	$status->status = $status->STATUS_SUCCESS;
}
$install_status['mod_jpadmin'] = $status;

// Enable mod_jpadmin
$db->setQuery("UPDATE #__modules SET published = 1, position = 'icon' WHERE ".
	"module = 'mod_jpadmin' ");
$db->query();


function com_install() {
	return component_install();
}

function component_install() {
	global $install_status;

	$status = new Status();
	$status->status = $status->STATUS_SUCCESS;
	$status->component = "com_joomlapack";

	$install_status["com_joomlapack"] = $status;
	return true;
}

?>
<h1>Instalação JoomlaPack</h1>
<p>Bem-vindo ao JoomlaPack!<br />
Antes de fazer qualquer coisa mais, leia o manual, disponível on-line <a href="http://www.joomlapack.net/help-support-documentation/joomlapack-2x-documentation/">na seção da documentação</a> de nosso site oficial. Se você tiver quaisquer perguntas, comentários ou precisar de alguma ajuda, não hesite em postar em nosso <a href="http://forum.joomlapack.net">fórum de suporte</a>.</p>
<p>O próximo passo após a instalação está tendo um olhar <a	href="<?php echo JURI::base() ?>index.php?option=com_joomlapack&view=configeasy">simplificado na configuração</a> do componente ou, se você for um usuário avançado, a página <a href="<?php echo JURI::base() ?>index.php?option=com_joomlapack&view=config">completa</a> (avançado) de configuração. Depois de ter verificado a configuração, vá em frente e <a href="<?php echo JURI::base() ?>index.php?option=com_joomlapack&view=cpanel">aplique filtros de inclusão e exclusão</a> ou pule direto <a href="<?php echo JURI::base() ?>index.php?option=com_joomlapack&view=backup">até a ter o seu primeiro backup do site</a>. Lembre-se, você sempre poderá obter ajuda on-line na página do JoomlaPack você pode visualiza-lá clicando no ícone de ajuda, no canto superior esquerdo da página.
<table class="adminlist">
	<thead>
		<tr>
			<th class="title"><?php echo JText::_('Sub Component'); ?></th>
			<th width="60%"><?php echo JText::_('Status'); ?></th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="2">&nbsp;</td>
		</tr>
	</tfoot>
	<tbody>
	<?php
	$i=0;
	foreach ( $install_status as $component => $status ) {?>
		<tr class="row<?php echo $i; ?>">
			<td class="key"><?php echo $component; ?></td>
			<td><?php echo ($status->status == $status->STATUS_SUCCESS)? '<strong>'.JText::_('Installed').'</strong>' : '<em>'.JText::_('NOT Installed').'</em>'?>
			<?php if (count($status->errmsg) > 0 ) {
				foreach ( $status->errmsg as $errmsg ) {
					echo '<br/>Erro: ' . $errmsg;
				}
			} ?> <?php if (count($status->infomsg) > 0 ) {
				foreach ( $status->infomsg as $infomsg ) {
					echo '<br/>Info: ' . $infomsg;
				}
			} ?></td>
		</tr>
		<?php
		if ($i=0){ $i=1;} else {$i = 0;};
	}?>

	</tbody>
</table>
