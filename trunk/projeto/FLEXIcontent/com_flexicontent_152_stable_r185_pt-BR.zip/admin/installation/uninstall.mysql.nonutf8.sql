DROP TABLE IF EXISTS 
`#__flexicontent_cats_item_relations`,
`#__flexicontent_favourites`,
`#__flexicontent_fields`,
`#__flexicontent_fields_item_relations`,
`#__flexicontent_fields_type_relations`,
`#__flexicontent_files`,
`#__flexicontent_items_ext`,
`#__flexicontent_items_extravote`,
`#__flexicontent_items_versions`,
`#__flexicontent_tags`,
`#__flexicontent_tags_item_relations`,
`#__flexicontent_types`,
`#__flexicontent_versions`;