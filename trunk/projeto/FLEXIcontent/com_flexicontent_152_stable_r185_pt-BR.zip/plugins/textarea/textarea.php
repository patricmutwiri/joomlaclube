<?php
/**
 * @version 1.0 $Id: textarea.php 171 2010-03-20 00:44:02Z emmanuel.danan $
 * @package Joomla
 * @subpackage FLEXIcontent
 * @subpackage plugin.textarea
 * @copyright (C) 2009 Emmanuel Danan - www.vistamedia.fr
 * @license GNU/GPL v2
 *
 * FLEXIcontent is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */
defined( '_JEXEC' ) or die( 'Restricted access' );

//jimport('joomla.plugin.plugin');
jimport('joomla.event.plugin');

class plgFlexicontent_fieldsTextarea extends JPlugin
{
	function plgFlexicontent_fieldsTextarea( &$subject, $params )
	{
		parent::__construct( $subject, $params );
        JPlugin::loadLanguage('plg_flexicontent_fields_textarea', JPATH_ADMINISTRATOR);
	}

	function onDisplayField(&$field, $item)
	{
		// execute the code only if the field type match the plugin type
		if($field->field_type != 'textarea') return;

		$editor 	= & JFactory::getEditor();
		
		// some parameter shortcuts
		$required 			= $field->parameters->get( 'required', 0 ) ;
		$cols				= $field->parameters->get( 'cols', 75 ) ;
		$rows				= $field->parameters->get( 'rows', 20 ) ;
		$height				= $field->parameters->get( 'height', 400 ) ;
		$default_value		= $field->parameters->get( 'default_value' ) ;
		$use_html			= $field->parameters->get( 'use_html', 0 ) ;
						
		$required 	= $required ? ' class="required"' : '';
		
		// initialise property
		if($item->version == 1 && $default_value) {
			$field->value[0] = $default_value;
		} elseif (!$field->value) {
			$field->value[0] = '';
		}

		if ($use_html) {
			$field->html	 = $editor->display( $field->name, $field->value[0], '100%', $height, $cols, $rows, array('pagebreak', 'readmore') );
		} else {
			$field->html	 = '<textarea name="' . $field->name . '" cols="'.$cols.'" rows="'.$rows.'"'.$required.'>';
			$field->html	.= $field->value[0];
			$field->html	.= '</textarea>';
		}
	}


	function onBeforeSaveField( $field, &$post, &$file )
	{
		// execute the code only if the field type match the plugin type
		if($field->field_type != 'textarea') return;
		if(!$post) return;
		
		// create the fulltext search index
		$field->search = flexicontent_html::striptagsandcut($post) . ' | ';		
	}


	function onDisplayFieldValue(&$field, $item, $values=null, $prop='display')
	{
		// execute the code only if the field type match the plugin type
		if($field->field_type != 'textarea') return;
		
		// some parameter shortcuts

		$use_html			= $field->parameters->get( 'use_html', 0 ) ;
		$opentag			= $field->parameters->get( 'opentag', '' ) ;
		$closetag			= $field->parameters->get( 'closetag', '' ) ;

		$values = $values ? $values : $field->value ;

		$field->{$prop}	 = $opentag;
		$field->{$prop}	.= $values ? ($use_html ? $values[0] : nl2br($values[0])) : '';
		$field->{$prop}	.= $closetag;
	}
}