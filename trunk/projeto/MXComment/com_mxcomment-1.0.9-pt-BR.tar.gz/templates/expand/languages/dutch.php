<?php
//*********************************************\\
//* Translationfile: dutch.php  27-juli-2007  *\\
//* Copyright (C) 2007 door l.niemoller       *\\
//* --------- All Rights Reserved ------------*\\     
//* Homepage   : www.niemoller.org            *\\
//* E-Mail     : lion@niemoller.org           *\\
//* Version    : 1_1_NL                       *\\
//* Project    : mXcomment 1.0.2              *\\             
//*********************************************\\

// ensure this file is being included by a parent file
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

DEFINE("_MXC_TPL_WRITTEN_BY","Door");
DEFINE("_MXC_TPL_ON","Op");
DEFINE("_MXC_TPL_EDITORS_RATING","Waardering van moderators");
DEFINE("_MXC_TPL_AVERAGE_USER_RATING","Gemiddelde waardering gebruikers");
DEFINE("_MXC_TPL_VIEWS","Aantal Hits");
DEFINE("_MXC_TPL_LAST_UPDATE","Laatst gewijzigd");
DEFINE("_MXC_TPL_PUBLISHED_IN","Gepubliceerd in");
DEFINE("_MXC_TPL_KEYWORDS","Tags");
DEFINE("_MXC_TPL_EDITORS_COMMENT","Reacties door Moderators");
DEFINE("_MXC_TPL_USERS_COMMENTS","Gebruikers' reacties ");
DEFINE("_MXC_TPL_POSTED_BY","Geplaatst door");
DEFINE("_MXC_TPL_IP","IP");
DEFINE("_MXC_TPL_DISPLAY","Weergave");
DEFINE("_MXC_TPL_OF","Uit");
DEFINE("_MXC_TPL_COMMENTS","reacties");
DEFINE("_MXC_TPL_SHOW_FORM","[+] Editor weergeven");
DEFINE("_MXC_TPL_HIDE_FORM","[-] Verberg editor");
DEFINE("_MXC_TPL_EXPAND_COMMENT","[+] Reactie uitvouwen");
DEFINE("_MXC_TPL_COLLAPSE_COMMENT","[-] Reactie samenvouwen");

?>
