<?php
/*********************************************
* mXcomment - Component                      *
* Copyright (C) 2007 by Bernard Gilly        *
* --------- All Rights Reserved ------------ *      
* Homepage   : www.visualclinic.fr           *
* Version    : 1.0.3                         *
* License    : Creative Commons              *
*********************************************/

// ensure this file is being included by a parent file
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

DEFINE("_MXC_TPL_WRITTEN_BY","Ecrit par");
DEFINE("_MXC_TPL_ON","le");
DEFINE("_MXC_TPL_EDITORS_RATING","Evaluation �diteur");
DEFINE("_MXC_TPL_AVERAGE_USER_RATING","Evaluation utilisateurs");
DEFINE("_MXC_TPL_VIEWS","Pages vues");
DEFINE("_MXC_TPL_LAST_UPDATE","Derni�re mise � jour");
DEFINE("_MXC_TPL_PUBLISHED_IN","Publi� dans");
DEFINE("_MXC_TPL_KEYWORDS","Tags");
DEFINE("_MXC_TPL_EDITORS_COMMENT","Commentaire �diteur");
DEFINE("_MXC_TPL_USERS_COMMENTS","Commentaires utilisateurs");
DEFINE("_MXC_TPL_POSTED_BY","Post� le");
DEFINE("_MXC_TPL_IP","IP");
DEFINE("_MXC_TPL_DISPLAY","Affiche");
DEFINE("_MXC_TPL_OF","de");
DEFINE("_MXC_TPL_COMMENTS","commentaires");
DEFINE("_MXC_TPL_SHOW_FORM","[+] Afficher formulaire");
DEFINE("_MXC_TPL_HIDE_FORM","[-] Cacher formulaire");
DEFINE("_MXC_TPL_EXPAND_COMMENT","[+] Voir commentaire");
DEFINE("_MXC_TPL_COLLAPSE_COMMENT","[-] Fermer commentaire");
DEFINE("_MXC_TPL_FAVOURED","Favoris");
?>