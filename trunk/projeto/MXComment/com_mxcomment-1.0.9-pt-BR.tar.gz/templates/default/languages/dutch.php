<?php
//*********************************************\\
//* Translationfile: dutch.php  27-juli-2007  *\\
//* Copyright (C) 2007 door l.niemoller       *\\
//* --------- All Rights Reserved ------------*\\     
//* Homepage   : www.niemoller.org            *\\
//* E-Mail     : lion@niemoller.org           *\\
//* Version    : 1_1_NL                       *\\
//* Project    : mXcomment 1.0.3              *\\             
//*********************************************\\

// ensure this file is being included by a parent file
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

DEFINE("_MXC_TPL_WRITTEN_BY","Geschreven door");
DEFINE("_MXC_TPL_ON","Op");
DEFINE("_MXC_TPL_EDITORS_RATING","Moderator waardering");
DEFINE("_MXC_TPL_AVERAGE_USER_RATING","Gemiddelde gebruikerswaardering");
DEFINE("_MXC_TPL_VIEWS","Gelezen");
DEFINE("_MXC_TPL_LAST_UPDATE","Laaste wijziging");
DEFINE("_MXC_TPL_PUBLISHED_IN","Gepubliceerd in");
DEFINE("_MXC_TPL_KEYWORDS","Sleutelwoorden");
DEFINE("_MXC_TPL_EDITORS_COMMENT","Reacties moderator");
DEFINE("_MXC_TPL_USERS_COMMENTS","Reacties gebruikers'");
DEFINE("_MXC_TPL_POSTED_BY","Geplaast door");
DEFINE("_MXC_TPL_IP","IP");
DEFINE("_MXC_TPL_FAVOURED","Favoriet");
?>
