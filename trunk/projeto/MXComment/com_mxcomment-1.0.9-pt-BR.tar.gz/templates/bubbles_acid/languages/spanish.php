<?php
/*********************************************
* mXcomment - Component                      *
* Copyright (C) 2007 by Bernard Gilly        *
* --------- All Rights Reserved ------------ *      
* Homepage   : www.visualclinic.fr           *
* Version    : 1.0.4                         *
* License    : Creative Commons              *
*********************************************/

// ensure this file is being included by a parent file
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

DEFINE("_MXC_TPL_WRITTEN_BY","Escrito por");
DEFINE("_MXC_TPL_ON","on");
DEFINE("_MXC_TPL_EDITORS_RATING","Voto del editor");
DEFINE("_MXC_TPL_AVERAGE_USER_RATING","Media de votos");
DEFINE("_MXC_TPL_VIEWS","Visitas");
DEFINE("_MXC_TPL_LAST_UPDATE","Revisado el");
DEFINE("_MXC_TPL_PUBLISHED_IN","Publicado el");
DEFINE("_MXC_TPL_KEYWORDS","Etiquetas");
DEFINE("_MXC_TPL_EDITORS_COMMENT","Comentarios del editor");
DEFINE("_MXC_TPL_USERS_COMMENTS","Comentarios de usuarios");
DEFINE("_MXC_TPL_POSTED_BY","Enviado por");
DEFINE("_MXC_TPL_IP","IP");
DEFINE("_MXC_TPL_DISPLAY","Mostrar");
DEFINE("_MXC_TPL_OF","de");
DEFINE("_MXC_TPL_COMMENTS","Comentarios");
DEFINE("_MXC_TPL_FAVOURED","Favoritos");

?>
