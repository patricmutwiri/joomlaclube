<?php
/*********************************************
* mXcomment - Component                      *
* Copyright (C) 2007 by Bernard Gilly        *
* --------- All Rights Reserved ------------ *      
* Homepage   : www.visualclinic.fr           *
* Version    : 1.0.5                         *
* License    : Creative Commons              *
*********************************************/

// ensure this file is being included by a parent file
defined( '_VALID_MOS' ) or die( 'Pääsy estetty.' );

DEFINE("_MXC_TPL_WRITTEN_BY","Kirjoittanut");
DEFINE("_MXC_TPL_ON","");
DEFINE("_MXC_TPL_EDITORS_RATING","Editoijan arvostelu");
DEFINE("_MXC_TPL_AVERAGE_USER_RATING","Käyttäjien arvostelu keskiarvo");
DEFINE("_MXC_TPL_VIEWS","Osumia");
DEFINE("_MXC_TPL_LAST_UPDATE","Viimeksi päivitetty");
DEFINE("_MXC_TPL_PUBLISHED_IN","Julkaistu");
DEFINE("_MXC_TPL_KEYWORDS","Tagit");
DEFINE("_MXC_TPL_EDITORS_COMMENT","Editoijan kommentit");
DEFINE("_MXC_TPL_USERS_COMMENTS","Käyttäjien kommentit");
DEFINE("_MXC_TPL_POSTED_BY","Lähettänyt");
DEFINE("_MXC_TPL_IP","IP");
DEFINE("_MXC_TPL_DISPLAY","Näytä");
DEFINE("_MXC_TPL_OF","/");
DEFINE("_MXC_TPL_COMMENTS","kommenttia");
DEFINE("_MXC_TPL_FAVOURED","Suosikki");
?>
