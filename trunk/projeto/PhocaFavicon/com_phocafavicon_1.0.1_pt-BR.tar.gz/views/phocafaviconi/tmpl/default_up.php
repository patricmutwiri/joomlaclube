<?php defined('_JEXEC') or die('Restricted access'); ?>

<div class="phocafavicon-box-file-i">
	<center>
		<div class="phocafavicon-box-file-first-i">
			<div class="phocafavicon-box-file-second">
				<div class="phocafavicon-box-file-third">
					<center>
					<a href="index.php?option=com_phocafavicon&amp;view=phocafaviconi&amp;tmpl=component&amp;folder=<?php echo $this->state->parent; ?>" ><?php echo JHTML::_( 'image.administrator', 'components/com_phocafavicon/assets/images/icon-up.gif', ''); ?></a>
					</center>
				</div>
			</div>
		</div>
	</center>
	
	<div class="name"><a href="index.php?option=com_phocafavicon&amp;view=phocafaviconi&amp;tmpl=component&amp;folder=<?php echo $this->state->parent; ?>" >..</a></div>
		<div class="detail" style="text-align:right">&nbsp;</div>
		<div style="clear:both"></div>
	</div>
</div>