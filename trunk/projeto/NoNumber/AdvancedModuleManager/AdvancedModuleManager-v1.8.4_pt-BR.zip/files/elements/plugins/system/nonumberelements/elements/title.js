/**
 * JavaScript file for Element: Title
 * Corrects some style problems
 *
 * @package     NoNumber! Elements
 * @version     1.4.2
 *
 * @author      Peter van Westen <peter@nonumber.nl>
 * @link        http://www.nonumber.nl
 * @copyright   Copyright (C) 2010 NoNumber! All Rights Reserved
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

function nnVersionIsNewer( number1, number2 )
{
	if ( ( number1+'' ).indexOf( '.' ) !== -1 ) {
		number1 = number1.split( '.' );
		number1 = ( number1[0] * 1000000 ) + ( number1[1] * 1000 ) + ( number1[2] * 1 );
	}
	if ( ( number2+'' ).indexOf( '.' ) !== -1 ) {
		number2 = number2.split( '.' );
		number2 = ( number2[0] * 1000000 ) + ( number2[1] * 1000 ) + ( number2[2] * 1 );
	}
	return ( number1 < number2 );
}

if ( typeof( nn_title_version ) == 'undefined' || nnVersionIsNewer( nn_title_version, '1.4.2' ) ) {
	// version number of the script
	// to prevent this from overwriting newer versions if other extensions include the script too
	var nn_title_version = '1.4.2';

	// prevent init from running more than once
	if ( typeof( window['nnTitleSet'] ) == "undefined" ) {
		var nnTitleSet = null;
	}

	window.addEvent( 'domready', function() {
		if ( !nnTitleSet ) {
			nnTitleSet = new nnTitle();
		}
	});

	var nnTitle = new Class({
		initialize: function()
		{
			var table;
			$$('.paramlist_value').each( function( td ) {
				if ( td.getTag() == 'td' ) {
					table = td.getParent().getParent().getParent();
					td.setStyle( 'width', table.offsetWidth-140 );
				}
			});
		}
	});
}