<?php
/**
* @version $Id: version.php v.2.1b7 2007-12-09 05:514:45Z GMT-3 $
* @package ArtForms 2.1b7
* @subpackage ArtForms Component
* @copyright Copyright (C) 2005 Andreas Duswald
* @copyright Copyright (C) 2007 InterJoomla. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
* This version may have been modified pursuant to the
* GNU General Public License, and as distributed it includes or is derivative
* of works licensed under the GNU General Public License or other free
* or open source software licenses.
* See COPYRIGHT.txt for copyright notices and details.
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

function afVersion() {
                       //Build 107
   $ArtForms_version = '2.1b7.2 [For Joomla 1.5] - Build 107';
   return $ArtForms_version;
   
}
  
  
?>
