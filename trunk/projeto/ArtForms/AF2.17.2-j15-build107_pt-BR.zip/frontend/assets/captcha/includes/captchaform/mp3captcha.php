<?php
/********************************************************************************
* output captcha mp3
********************************************************************************/

define( 'DS', DIRECTORY_SEPARATOR );

//require(dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))).DS.'administrator'.DS.'components'.DS.'com_artforms'.DS.'config.artforms.php');

$lang = $_GET['l'];

session_start();

	/* load php5 or php4 class files for demo */
if (version_compare(phpversion(), "5.0.0", ">=")) { 
	require_once(dirname(__FILE__).DS.'mp3captchaform5.php');
} else { 
	require_once(dirname(__FILE__).DS.'mp3captchaform4.php');
} 

	/* init mp3captcha class with captcha value from session*/
$mp3 = new mp3captcha($_SESSION['afcaptchaform']);
	/* use language mapping */
// $mp3->mapping = true;

	/* language switch for use in demo */
$mp3->language = $lang;

	/* output captcha mp3 */
$mp3->mp3stitch();
?>
