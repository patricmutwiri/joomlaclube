<?php
// swfmovie.php - swf output and config

define( 'DS', DIRECTORY_SEPARATOR );

require(dirname(dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))))).DS.'administrator'.DS.'components'.DS.'com_artforms'.DS.'config.artforms.php');
session_start();

if (version_compare(phpversion(), "5.0.0", ">=")) { 
	include_once(dirname(__FILE__).DS.'swfcaptcha5.php');
} else { 
	include_once(dirname(__FILE__).DS.'swfcaptcha4.php');
} 

$swfc = new swfcaptcha();
$swfc->captcha_length 	= $afcfg_captcha_length;
$swfc->fontdir 					= dirname(dirname(dirname(__FILE__))).DS.'fonts';
$swfc->imagesdir 				= dirname(dirname(dirname(__FILE__))).DS.'captcha'.DS.'bg';
$swfc->sounddir 				= dirname(dirname(dirname(__FILE__))).DS.'audio';

if (($afcfg_captcha_mode=='audio') || ($afcfg_captcha_mode=='both')) {
   $swfc->talking = true;
} else {
   $swfc->talking = false;
}

$swfc->swfmovie();

?>
