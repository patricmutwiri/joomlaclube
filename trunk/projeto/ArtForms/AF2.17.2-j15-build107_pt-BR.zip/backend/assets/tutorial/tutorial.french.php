<?php
/**
* @version $Id: tutorial.french.php v.2.1b7 2007-08-31 16:44:59Z GMT-3 $
* @package ArtForms 2.1b7
* @subpackage ArtForms Component
* @copyright Copyright (C) 2005 Andreas Duswald
* @copyright Copyright (C) 2007 InterJoomla. All rights reserved.
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2, see LICENSE.txt
* This version may have been modified pursuant to the
* GNU General Public License, and as distributed it includes or is derivative
* of works licensed under the GNU General Public License or other free
* or open source software licenses.
* See COPYRIGHT.txt for copyright notices and details.
*/

defined( '_JEXEC' ) or die( 'Restricted access' );
	?>
  <table class="adminlist" border="0" cellpadding="3" cellspacing="0">
    <tr>
      <th align="left" colspan="2"><b>Tutorial</b></th>
    </tr>
    <tr>
      <td>
        The tutorial is under development.
      </td>
    </tr>
    <tr>
      <th align="left" colspan="2"><b> </b></th>
    </tr>
  </table>
