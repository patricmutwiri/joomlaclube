<?php
/**
* @version		1.0.1
* @package		Joomla
* @copyright	Copyright (C) 2008 Majunke Michael. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Import library dependencies
jimport('joomla.plugin.plugin');


$plugin =& JPluginHelper::getPlugin('editors-xtd', 'chtmlBtn');
$plugin_params = new JParameter( $plugin->params );
//make the var global so that it can be read in the function below
global $customhtml;
//get the html input from parameters
$incomingtext = $plugin_params->get( 'HTMLcode', 'some custom html' );
//escape the quotes
$customhtml = preg_replace(array("/'/", '/"/'), array("\'", '\"'), $incomingtext);
//remove newlines and tabs
$customhtml = str_replace(array("\r\n", "\r", "\n", "\t"), ' ', $customhtml);
//replace double+ spaces with single space: should be commented if you need to include double+ spaces in the content
$customhtml = ereg_replace(" {2,}", ' ',$customhtml);
//remove not needed spaces in the beggining and the end of the var
$customhtml = trim($customhtml);

/**
* Custom html button
*/
class plgButtonChtmlBtn extends JPlugin
{

    function plgButtonChtmlBtn( &$subject, $config) {
        parent::__construct($subject, $config);
    }

    function onDisplay($name)
    {

		//
  		$doc 		=& JFactory::getDocument();

	 	// button is not active in specific content components
  		$getContent = $this->_subject->getContent($name);
	 	// $present = JText::_('ALREADY EXISTS', true) ;

	 	// insert script
	 	$js.= "function insertChtml(editor) {
		           jInsertEditorText('".$GLOBALS['customhtml']."', editor );
		       }";
  		$doc->addScriptDeclaration($js);

		//
  		$button = new JObject();
  		$button->set('modal', false);
  		$button->set('onclick', 'insertChtml(\''.$name.'\');return false;'); // call script
  		$button->set('text', JText::_('CustomHTML'));
  		$button->set('name', 'blank'); // we dont need a spezial css style class
  		$button->set('link', '#');

  		return $button;

   }

}