<?php
/**
* @version $Id: COPYRIGHT.php 1129 2009-10-23 08:03:43Z mahagr $
* Kunena Component
* @package Kunena
*
* @Copyright (C) 2008 - 2009 Kunena Team All rights reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.kunena.com
*
* Based on FireBoard Component
* @Copyright (C) 2006 - 2007 Best Of Joomla All rights reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.bestofjoomla.com
*/

// no direct access
defined( '_JEXEC' ) or die('Restricted access');
?>
<!-- 

Kunena derives from copyrighted works licensed under the GNU General
Public License.  This version has been modified pursuant to the
GNU General Public License as of September 15, 2005, and as distributed,
it includes or is derivative of works licensed under the GNU General
Public License or other free or open source software licenses, including
works copyrighted by any or all of the following, from 2000 through 2005:
TSMF & Jan de Graaff

Kunena includes or is derivative of works distributed under the following copyright notices:

patTemplate, patError
---
Copyright:	Stephan Schmidt
License:	GNU Lesser General Public License (LGPL)

PEAR
----
Copyright:	1997-2004 The PHP Group
License:	PHP license

phpInputfilter
----
Copyright:	Daniel Morris
License:	GNU General Public License (GPL)

jQuery
----
Copyright:    John Resig
License:    Dual licensed under the MIT (MIT-LICENSE.txt) and GPL (GPL-LICENSE.txt) licenses.

 -->